// Copyright (c) 1998, 2008, Oracle and/or its affiliates.All rights reserved. 
package oracle.toplink.platform.server.wls;

import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.platform.server.ServerPlatformBase;
import oracle.toplink.transaction.wls.WebLogicTransactionController;
import oracle.toplink.logging.SessionLog;
import oracle.toplink.internal.sessions.DatabaseSessionImpl;

/**
 * PUBLIC:
 *
 * This is the concrete subclass responsible for representing WebLogic-specific server behaviour.
 *
 * This platform overrides:
 *
 * getExternalTransactionControllerClass(): to use the WebLogic-specific controller class
 * initializeServerNameAndVersion(): to call the WebLogic library for this information
 */
public class WebLogicPlatform extends ServerPlatformBase {

    /**
     * INTERNAL:
     * Default Constructor: All behaviour for the default constructor is inherited
     */
    public WebLogicPlatform(DatabaseSession newDatabaseSession) {
        super(newDatabaseSession);
        this.disableRuntimeServices();
    }

    /**
     * INTERNAL: 
     * getApplicationName(): Answer the name of the module (EAR name) that this session is associated with.
     * Answer "unknown" if there is no application name available.
     * Default behavior is to return "unknown" - we override this behavior here for WebLogic.
     * 
     * There are 4 levels of implementation.
     * 1) use the property override weblogic.applicationName, or
     * 2) perform a reflective weblogic.work.executeThreadRuntime.getApplicationName() call (build 10.3.3.1), or
     * 3) extract the moduleName:persistence_unit from the weblogic classloader string representation (build 10.3), or
     * 3) defer to superclass - usually return "unknown"
     *
     * @return String applicationName
     */
    public String getApplicationName() {
        return DEFAULT_SERVER_NAME_AND_VERSION;
    }
    
    /**
     * INTERNAL: initializeServerNameAndVersion(): Talk to the relevant server class library, and get the server name
     * and version
     */
    protected void initializeServerNameAndVersion() {
        this.serverNameAndVersion = weblogic.version.getBuildVersion();
    }

    /**
     * INTERNAL: getExternalTransactionControllerClass(): Answer the class of external transaction controller to use
     * for WebLogic. This is read-only.
     *
     * @return Class externalTransactionControllerClass
     *
     * @see oracle.toplink.transaction.JTATransactionController
     * @see ServerPlatformBase.isJTAEnabled()
     * @see ServerPlatformBase.disableJTA()
     * @see ServerPlatformBase.initializeExternalTransactionController()
     */
    public Class getExternalTransactionControllerClass() {
    	if (externalTransactionControllerClass == null){
    		externalTransactionControllerClass = WebLogicTransactionController.class;
    	}
        return externalTransactionControllerClass;
    }

    /**
     * INTERNAL: getServerLog(): Return the correct ServerLog for this platform
     *
     * Return a WlsOutputLog
     *
     * @return oracle.toplink.logging.SessionLog
     */
    public oracle.toplink.logging.SessionLog getServerLog() {
        return new WlsLog();
    }

    /**
     * INTERNAL:  This method is used to unwrap the oracle connection wrapped by
     * the application server.  TopLink needs this unwrapped connection for certain
     * Oracle Specific support. (ie TIMESTAMPTZ)
     */
    public java.sql.Connection unwrapConnection(java.sql.Connection connection){
        try {
            if (connection instanceof weblogic.jdbc.wrapper.Connection){
                return ((weblogic.jdbc.wrapper.Connection)connection).getVendorConnection();
            }
            return connection;
        } catch (java.sql.SQLException e) {
            ((DatabaseSessionImpl)getDatabaseSession()).log(SessionLog.WARNING, SessionLog.CONNECTION, "cannot_unwrap_connection", e);
            return connection;            
        }
    }
}