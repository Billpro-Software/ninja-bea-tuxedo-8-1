// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.expressions.Expression;
import org.eclipse.persistence.internal.expressions.ObjectExpression;
import org.eclipse.persistence.internal.expressions.QueryKeyExpression;
import org.eclipse.persistence.internal.identitymaps.CacheKey;
import org.eclipse.persistence.internal.queries.ContainerPolicy;
import org.eclipse.persistence.internal.queries.ReportItem;
import org.eclipse.persistence.internal.sessions.AbstractRecord;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.internal.sessions.UnitOfWorkImpl;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.queries.ReportQuery;
import org.eclipse.persistence.queries.ReportQueryResult;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap.EntryAggregator;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.aggregator.CompositeAggregator;
import com.tangosol.util.processor.CompositeProcessor;

/**
 * <p>
 * <b>Purpose:</b> This Query Redirector should be set on any class or query
 * where the user wants Coherence to be checked for data instead of the database
 * and CoherenceInterceptor has been set on the Descriptor. With this Redirector
 * set TopLink will not issue any SQL for Reads of data and aggregation unless
 * the query can not be translated into a Coherence filter.
 * 
 * Developers should set the Coherence Cache name that corresponds to this class
 * in a descriptor property called "coherence.cache.name". Each class should
 * have its own Cache unless the PK's of the instances are unique amoung all
 * classes stored in a single cache
 * 
 * This Redirector can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations. This Redirector may be used on a per
 * query basis as well.
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.
 *      setDefaultInsertQueryRedirector(QueryRedirector)
 * @see org.eclipse.persistence.annotations.QueryRedirectors
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.3.0)
 */
public class ReportQueryFromCoherence extends CoherenceRedirector implements QueryRedirector {

    protected static final Boolean RESULT_IGNORED = Boolean.valueOf(true);

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {
        ReportQuery reportQuery = (ReportQuery)query;
        //first translate ReportQuery items to Coherence artifacts.
        List<EntryAggregator> aggregators = new ArrayList<EntryAggregator>();
        List<EntryProcessor> extractors = new ArrayList<EntryProcessor>();
        boolean failedToTranslate = false;
        for (ReportItem item : reportQuery.getItems()){
            if (item.getAttributeExpression() != null){
                if (item.getAttributeExpression().isFunctionExpression()){
                    if (! extractors.isEmpty()){
                        failedToTranslate = true;
                        break;
                    }
                    EntryAggregator aggregator = getFilterFactory(session).createAggregator(item, reportQuery, arguments, (AbstractSession)session);
                    if (aggregator != null){
                        aggregators.add(aggregator);
                    }else{
                        failedToTranslate = true;
                        break;
                    }
                }else{
                    if (! aggregators.isEmpty()){
                        failedToTranslate = true;
                        break;
                    }
                    EntryProcessor extractor = getFilterFactory(session).createValueExtractor(item, reportQuery, arguments, (AbstractSession)session);
                    if (extractor != null){
                        extractors.add(extractor);
                    }else{
                        failedToTranslate = true;
                        break;
                    }
                }
            }else{
                failedToTranslate = true;
                break;
            }
        }
        if (failedToTranslate){
            return getTranslationFailureDelegate(session).translationFailed(reportQuery, arguments, session);
        }else{
            Filter filter = getFilterFactory(session).create( reportQuery, arguments, session);
            if (filter == FilterFactory.NO_FILTER) {
                return getTranslationFailureDelegate(session).translationFailed(reportQuery, arguments, session);
            }
            
            Set<Object> distinctSet = null;
            // GF_ISSUE_395

            //need to execute against Coherence and return results.
            NamedCache cache = getNamedCache(query.getDescriptor().getRootDescriptor(), session);
            if (! aggregators.isEmpty()){
                List aggregateResult = (List) cache.aggregate(filter, CompositeAggregator.createInstance( aggregators.toArray(new EntryAggregator[aggregators.size()])));
                return buildObject(reportQuery, aggregateResult.toArray(), null, (AbstractSession) session);
            }
            if (! extractors.isEmpty()){
                List<Object[]> extractorResult = new ArrayList<Object[]>(cache.invokeAll(filter, new CompositeProcessor( extractors.toArray(new EntryProcessor[extractors.size()]))).values());
                return buildObject(reportQuery, extractorResult, (AbstractSession) session);
            }
        }
        return null;
    }

    public String buildResultKeyForDistinct(Object[] resultRow) {
        StringBuffer key = new StringBuffer();
        for (Object object : resultRow) {
            if (object != null) {
                key.append(object.toString());
            } else {
                key.append("NULL");
            }
            key.append("_");
        }
        return key.toString();
    }

    public Object buildObject(ReportQuery query, Object[] resultRow, Set<Object> distinctSet, AbstractSession session) {
        //GF_ISSUE_395
        if (distinctSet != null) {
            String key = buildResultKeyForDistinct(resultRow);
            if (distinctSet.contains(key)) {
                return RESULT_IGNORED; //distinguish between null values and thrown away duplicates
            } else {
                distinctSet.add(key);
            }
        }
        //end GF_ISSUE_395
        if (query.shouldReturnSingleAttribute()) {
            return processCloning(query, resultRow, session)[0];
        } else if (query.shouldReturnArray()) {
            return processCloning(query, resultRow, session);
        } else if (query.shouldReturnWithoutReportQueryResult()) {
            if (resultRow.length == 1) {
                return processCloning(query, resultRow, session)[0];
            } else {
                return processCloning(query, resultRow, session);
            }
        } else if (query.shouldReturnSingleValue()) {
            return processCloning(query, resultRow, session)[0];
        } else {
            return new ReportQueryResult(Arrays.asList(processCloning(query, resultRow, session)), null);
        }
    }

    protected Object[] processCloning(ReportQuery query, Object[] results, AbstractSession session){
        if (session.isUnitOfWork()){
            UnitOfWorkImpl uow = (UnitOfWorkImpl)session;
            CacheKey parentKey = new CacheKey(3);
            
            int size = results.length;
            for (int i = 0; i < size; ++i){
                ReportItem item = query.getItems().get(i);
                Expression expression = item.getAttributeExpression();
                if (expression != null && expression.isObjectExpression() && !(expression.isQueryKeyExpression() && ((QueryKeyExpression)expression).isAttribute())){
                    ClassDescriptor descriptor = ((ObjectExpression)expression).getDescriptor();
                    Object value = results[i];
                    parentKey.setKey(descriptor.getObjectBuilder().extractPrimaryKeyFromObject(value, session));
                    parentKey.setObject(value);
                    results[i] = uow.cloneAndRegisterObject(value, parentKey, descriptor);
                }
            }
        }
        return results;
    }

    protected  Object buildObject(ReportQuery reportQuery, Collection results, AbstractSession session) {
        if (reportQuery.shouldReturnSingleResult() || reportQuery.shouldReturnSingleValue()) {
            if (results == null || results.isEmpty()) {
                return null;
            }
            return buildObject(reportQuery, (Object[])results.iterator().next(), null, session);
        }

        ContainerPolicy containerPolicy = reportQuery.getContainerPolicy();
        int size = results.size();
        Object reportResults = containerPolicy.containerInstance(size);
        Set<Object> distinctSet = null;
        // GF_ISSUE_395
        if (reportQuery.shouldDistinctBeUsed()) {
            distinctSet = new HashSet(size);
        }
        //end GF_ISSUE
        //If only the attribute is desired, then buildObject will only get the first attribute each time
        for (Iterator rows = results.iterator(); rows.hasNext(); ) {
            // GF_ISSUE_395
            Object result = buildObject(reportQuery, (Object[])rows.next(), null, session);

            if (result != RESULT_IGNORED) {
                containerPolicy.addInto(result, reportResults, session);
            }
            //end GF_ISSUE
        }
        if (reportQuery.shouldCacheQueryResults()) {
            reportQuery.setTemporaryCachedQueryResults(reportResults);
        }
        return reportResults;
    }
}
