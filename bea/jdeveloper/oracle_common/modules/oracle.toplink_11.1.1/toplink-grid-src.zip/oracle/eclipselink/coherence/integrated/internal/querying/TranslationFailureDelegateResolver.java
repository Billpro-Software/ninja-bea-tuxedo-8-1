// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import java.lang.reflect.Constructor;
import java.security.AccessController;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.querying.TranslationFailureDelegate;

import org.eclipse.persistence.internal.security.PrivilegedAccessHelper;
import org.eclipse.persistence.internal.security.PrivilegedGetConstructorFor;
import org.eclipse.persistence.internal.security.PrivilegedInvokeConstructor;
import org.eclipse.persistence.sessions.Session;

/**
 * This class is used to create the configured QueryTranslationFailurePolicy implementation. The
 * QueryTranslationFailurePolicy implementation to use is configured by specifying the
 * QueryTranslationFailurePolicy implementation's class name through the PU/session level
 * property "eclipselink.coherence.query-translation-failure-policy"
 */
public class TranslationFailureDelegateResolver {
    
    protected static TranslationFailureDelegate policy;
    
    public static TranslationFailureDelegate resolve(Session session){
        if (policy != null){
            return policy;
        }
        String className = (String) session.getProperty(IntegrationProperties.TRANSLATION_FAILURE_POLICY);
        if (className == null){
            policy = new EclipseLinkQueryFailurePolicy();
            return policy;
        }
        Class failurePolicy;
        try {
            failurePolicy = session.getPlatform().getConversionManager().getLoader().loadClass(className);
        if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()){
            Constructor constructor = (Constructor)AccessController.doPrivileged(new PrivilegedGetConstructorFor(failurePolicy, new Class[0], true));
            policy = (TranslationFailureDelegate) AccessController.doPrivileged(new PrivilegedInvokeConstructor(constructor, new Object[0]));
        } else {
            Constructor constructor = PrivilegedAccessHelper.getDeclaredConstructorFor(failurePolicy, new Class[0], true);
            policy = (TranslationFailureDelegate) PrivilegedAccessHelper.invokeConstructor(constructor, new Object[0]);
            
        }
        return policy;
        } catch (Exception e) {
            throw IntegrationException.unableToInstantiateFailoverPolicy(className, e);
        }
        
    }

}
