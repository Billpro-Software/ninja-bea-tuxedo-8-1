// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence;

/**
 * This abstract class contains the property names used by the
 * EclipseLink-JPA/Coherence integration. These properties are used to configure
 * the JPA persistence-unit and descriptors for the entities that will use
 * Coherence.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public abstract class IntegrationProperties {

    /**
     * This is the property name that will be used in each descriptor to store
     * the name of the Coherence Cache. If this name is not provided the
     * integration will default to using the descriptor's alias which is the
     * default entity name in JPA.
     * <p>
     * This property name can be used in API or using the @Property annotation.
     * 
     * @see org.eclipse.persistence.descriptors.ClassDescriptor#setProperty(String,
     *      Object)
     * @see org.eclipse.persistence.annotations.Property
     * @deprecated use "eclipselink.coherence.cache.name"
     */
    public static final String CACHE_NAME = "coherence.cache.name";
    
    /**
     * This is a SYSTEM level property used to notify the TopLink-Grid
     * serializer that the current VM is operating without EclipseLink. This
     * would be used in an application that was directly accessing coherence for
     * EclipseLink managed entities with relationships but did not have the JPA
     * Persistence Unit deployed in this VM
     */
    public static final String IS_NOT_ECLIPSELINK = "eclipselink.coherence.not-eclipselink";
    
    /**
     * This is the property name that will be used in each descriptor to store
     * the name of the Coherence Cache. If this name is not provided the
     * integration will default to using the descriptor's alias which is the
     * default entity name in JPA.
     * <p>
     * This property name can be used in API or using the @Property annotation.
     * 
     * @see org.eclipse.persistence.descriptors.ClassDescriptor#setProperty(String,
     *      Object)
     * @see org.eclipse.persistence.annotations.Property
     */
    public static final String COHERENCE_CACHE_NAME = "eclipselink.coherence.cache.name";

    /**
     * This is the property name that will be used to notify TopLink-Grid that a Coherence Index
     * is to be created for this attribute.  The property should be set directly on the mapping for
     * the attribute that is to be indexed.
     * 
     * <code>
     * public class Broker implements Serializable, PortableObject{
     *    ...
     *    @Basic
     *    @Property(name=IntegrationProperties.INDEXED, value = "TRUE")
     *    protected String name;
     *    ...
     * </code>
     * <p>
     * This property name can be used in API or using the @Property annotation.
     * 
     * @see org.eclipse.persistence.mappings.DatabaseMapping#setProperty(String,
     *      Object)
     * @see org.eclipse.persistence.annotations.Property
     */
    public static final String INDEXED = "eclipselink.coherence.indexed";
    
    /**
     * This is the property name that is used to specify a specific FilterFactory implementation
     * to be used to translate EclipseLink queries to Coherence Filters.  The fully qualified
     * class name of the implementation should be used as the value.
     */
    public static final String FILTER_FACTORY_CLASS_NAME = "eclipselink.coherence.filter-factory";
    
    /**
     * This is the property name that is used to specify a specific QueryTranslationFailurePolicy
     * implementation to be used to resolve failures to translate a Query.  The fully qualified
     * class name of the implementation should be used as the value.
     */
    public static final String TRANSLATION_FAILURE_POLICY="eclipselink.coherence.query.translation-failure-delegate";
}
