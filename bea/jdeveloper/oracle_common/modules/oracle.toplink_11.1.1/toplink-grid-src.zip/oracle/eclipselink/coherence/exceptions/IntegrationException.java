// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.exceptions;

import org.eclipse.persistence.exceptions.EclipseLinkException;
import org.eclipse.persistence.sessions.Session;

/**
 * General Exceptions that can occur within the integration. See exception
 * message for details.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class IntegrationException extends EclipseLinkException {

    public static final int UNABLE_TO_FIND_COHERENCE_CACHE = 80000;

    public static final int OPTIMISTIC_LOCKING_POLICY_NOT_SUPPORTED = 80001;

    /**
     * IntegrationException indicating the the EclipseLinkJPACacheLoader/Store
     * (standalone or integrated) was unable to locate a descriptor within the
     * provided persistence unit using the provided cache name. This exception
     * typically indicates that the Coherence configuration for the specified
     * cache does not match the EclipseLink JPA configuration.
     */
    public static final int UNABLE_TO_FIND_DESCRIPTOR = 80002;
    
    public static final int UNABLE_TO_DEFINE_WRAPPER_CLASS_ON_CLASSLOADER = 80003;
    
    public static final int UNABLE_TO_ACCESS_DEFINECLASS_METHOD_OF_CLASSLOADER= 80004;
    
    public static final int ECLIPSELINKSERIALIZER_NOT_SET_AS_CACHE_SERIALIZER=80005;
    
    public static final int FAILED_TO_LOAD_WRAPPER_CLASS = 80006;
    
    public static final int FAILED_TO_CREATE_INSTANCE_OF_WRAPPER = 80007;
    
    public static final int MAPPING_VALUES_NOT_SET_IN_WRAPPER = 80008;
    
    public static final int UNABLE_TO_EVALUATE_SUBCLASS_FILTER = 80009;
    
    public static final int UNABLE_TO_INSTANTIATE_FILTER_FACTORY = 80010;
    
    public static final int UNABLE_TO_INSTANTIATE_FAILOVER_POLICY = 80011;

    public IntegrationException(String message) {
        super(message);
    }

    public IntegrationException(String message, Throwable cause) {
        super(message, cause);
    }

    public static IntegrationException unableToInstantiateFailoverPolicy(String className, Exception rootException) {
        Object[] args = { className };

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_INSTANTIATE_FAILOVER_POLICY, args));
        integrationException.setErrorCode(UNABLE_TO_INSTANTIATE_FAILOVER_POLICY);
        integrationException.setInternalException(rootException);
        return integrationException;
    }

    public static IntegrationException unableToInstantiateFilterFactory(String className, Exception rootException) {
        Object[] args = { className };

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_INSTANTIATE_FILTER_FACTORY, args));
        integrationException.setErrorCode(UNABLE_TO_INSTANTIATE_FILTER_FACTORY);
        integrationException.setInternalException(rootException);
        return integrationException;
    }
    public static IntegrationException unableToFindCoherenceCache(String cacheName, Exception rootException) {
        Object[] args = { cacheName };

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_FIND_COHERENCE_CACHE, args));
        integrationException.setErrorCode(UNABLE_TO_FIND_COHERENCE_CACHE);
        integrationException.setInternalException(rootException);
        return integrationException;
    }

    public static IntegrationException optimisticLockingPolicyNotSupported(String javaClass) {
        Object[] args = { javaClass };

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, OPTIMISTIC_LOCKING_POLICY_NOT_SUPPORTED, args));
        integrationException.setErrorCode(OPTIMISTIC_LOCKING_POLICY_NOT_SUPPORTED);
        return integrationException;
    }

    /**
     * Constructs the UNABLE_TO_FIND_DESCRIPTOR exception.
     * 
     * @see UNABLE_TO_FIND_DESCRIPTOR
     */
    public static IntegrationException unableToFindDescriptor(String cacheName, Session session) {
        Object[] args = { cacheName, session.getName() };

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_FIND_DESCRIPTOR, args));
        integrationException.setErrorCode(UNABLE_TO_FIND_DESCRIPTOR);
        return integrationException;
    }

    public static IntegrationException unableToDefineGeneratedWrapperClass(String className, Exception rootException) {
        Object[] args = {className};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_DEFINE_WRAPPER_CLASS_ON_CLASSLOADER, args));
        integrationException.setErrorCode(UNABLE_TO_DEFINE_WRAPPER_CLASS_ON_CLASSLOADER);
        integrationException.setInternalException(rootException);
        return integrationException;
    }

    public static IntegrationException unableToAccessDefineClassMethodOfClassLader(Exception rootException) {
        Object[] args = {};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_ACCESS_DEFINECLASS_METHOD_OF_CLASSLOADER, args));
        integrationException.setErrorCode(UNABLE_TO_ACCESS_DEFINECLASS_METHOD_OF_CLASSLOADER);
        integrationException.setInternalException(rootException);
        return integrationException;
    }
    
    public static IntegrationException serializerNotSetToEclipseLinkSerializer(String className, String cacheName) {
        Object[] args = {className, cacheName};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, ECLIPSELINKSERIALIZER_NOT_SET_AS_CACHE_SERIALIZER, args));
        integrationException.setErrorCode(ECLIPSELINKSERIALIZER_NOT_SET_AS_CACHE_SERIALIZER);
        return integrationException;
    }
    
    public static IntegrationException failedToLoadWrapperClass(String wrapperName, Exception rootException) {
        Object[] args = {wrapperName};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, FAILED_TO_LOAD_WRAPPER_CLASS, args));
        integrationException.setErrorCode(FAILED_TO_LOAD_WRAPPER_CLASS);
        integrationException.setInternalException(rootException);
        return integrationException;
    }

    public static IntegrationException failedToCreateWrapperInstance(String wrapperName, Exception rootException) {
        Object[] args = {wrapperName};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, FAILED_TO_CREATE_INSTANCE_OF_WRAPPER, args));
        integrationException.setErrorCode(FAILED_TO_CREATE_INSTANCE_OF_WRAPPER);
        integrationException.setInternalException(rootException);
        return integrationException;
    }

    public static IntegrationException mappingValuesNotSent(String attributeName, String className) {
        Object[] args = {attributeName, className};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, MAPPING_VALUES_NOT_SET_IN_WRAPPER, args));
        integrationException.setErrorCode(MAPPING_VALUES_NOT_SET_IN_WRAPPER);
        return integrationException;
    }

    public static IntegrationException noClassFoundSubClassFilter(String className, ClassLoader loader, Throwable cause) {
        Object[] args = {className, loader};

        IntegrationException integrationException = new IntegrationException(ExceptionMessageGenerator.buildMessage(IntegrationException.class, UNABLE_TO_EVALUATE_SUBCLASS_FILTER, args), cause);
        integrationException.setErrorCode(UNABLE_TO_EVALUATE_SUBCLASS_FILTER);
        return integrationException;
    }
}
