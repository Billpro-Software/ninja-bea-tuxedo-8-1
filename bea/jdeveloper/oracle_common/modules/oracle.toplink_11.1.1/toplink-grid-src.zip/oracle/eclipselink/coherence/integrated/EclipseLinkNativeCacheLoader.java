// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import oracle.eclipselink.coherence.integrated.internal.InternalProperties;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;

import org.eclipse.persistence.annotations.CacheKeyType;
import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.identitymaps.CacheId;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.queries.ReadObjectQuery;
import org.eclipse.persistence.sessions.Session;
import org.eclipse.persistence.sessions.UnitOfWork;
import org.eclipse.persistence.sessions.factories.SessionManager;

import com.tangosol.net.cache.CacheLoader;
import com.tangosol.util.Base;

/**
 * This is the Coherence Cache Loader that should be used with native
 * EclipseLink configuration (sessions.xml) when Coherence interceptors and
 * redirectors have been set through a customizer. This is equivalent to the JPA
 * integration but is used when the pre-existing application uses native
 * EclipseLink configuration.
 * 
 * <p>
 * <b>Coherence Configuration:</b> In order to use the integrated
 * EclipseLinkNativeCacheLoader or EclipseLinkNativeCacheStore the Coherence
 * configuration XML file must specify the loader/store class as well as
 * providing parameters for the cache-name and session name. The 'sessions.xml'
 * file must be available on the classpath or packaged within a jar within the
 * META-INF directory.
 * <p>
 * The following is an example of how the integrated
 * EclipseLinkNativeCacheLoader can be configured.
 * 
 * <pre>
 * &lt;cachestore-scheme&gt;
 *    &lt;class-scheme&gt;
 *       &lt;class-name&gt;oracle.eclipselink.coherence.integrated.EclipseLinkNativeCacheLoader&lt;/class-name&gt; 
 *       &lt;init-params&gt; 
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;{cache-name}&lt;/param-value&gt; 
 *          &lt;/init-param&gt;
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;session name&lt;/param-value&gt; 
 *          &lt;/init-param&gt; 
 *       &lt;/init-params&gt;
 *    &lt;/class-scheme&gt;
 * &lt;/cachestore-scheme&gt;
 * </pre>
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.4.0)
 */
public class EclipseLinkNativeCacheLoader extends Base implements CacheLoader {

    protected Session session;
    protected ClassDescriptor descriptor;
    protected ReadObjectQuery roq;
    
    protected static SessionManager localManager = new SessionManager();

    public EclipseLinkNativeCacheLoader(String cacheName, String sessionName) {
        
        session = localManager.getSession(sessionName, true);
        session.setExternalTransactionController(null);
        // must initialize all descriptors here as relationships could cause
        // target object access before loader for that class is initialized.
        Iterator iter = session.getDescriptors().values().iterator();

        while (iter.hasNext()) {
            ClassDescriptor desc = (ClassDescriptor) iter.next();
            if (cacheName.equals(CoherenceCacheHelper.getCacheName(desc))) {
                this.descriptor = desc;
                this.roq = (ReadObjectQuery) descriptor.getQueryManager().getReadObjectQuery();
            }
            if (desc.getProperty(InternalProperties.DESCRIPTOR_INITIALIZED) == null) {
                desc.setProperty(InternalProperties.DESCRIPTOR_INITIALIZED, Boolean.TRUE);
                // Disable any configured query redirectors within the
                // CacheLoader
                desc.setDefaultReadAllQueryRedirector(null);
                desc.setDefaultReadObjectQueryRedirector(null);
                desc.setDefaultReportQueryRedirector(null);
                if (desc.getDefaultInsertObjectQueryRedirector() != null){
                    // write through coherence is configured
                    desc.setDefaultInsertObjectQueryRedirector(null);
                    desc.setDefaultDeleteObjectQueryRedirector(null);
                    desc.setDefaultUpdateObjectQueryRedirector(null);
                }

                // Ensure no caching is done in the CacheLoader/Store
                desc.setIsIsolated(true);
                session.getProject().setHasIsolatedClasses(true);
                desc.setCacheInterceptorClass(null);
                if (!desc.isChildDescriptor() && ! desc.isAggregateCollectionDescriptor()  && ! desc.isAggregateDescriptor()){
                    session.getIdentityMapAccessor().initializeIdentityMap(desc.getJavaClass());
                }

                // Optimistic lock checking cannot be done within the CacheStore
                // so
                // any configured policy is removed
                desc.setOptimisticLockingPolicy(null);

                // Primary keys assigned using sequencing cannot be done within
                // the
                // CacheStore so
                desc.setSequenceNumberName(null);
                desc.setSequenceNumberField(null);
                desc.getQueryManager().checkDatabaseForDoesExist();
                CoherenceCacheHelper.defineWrapperClass(desc, session.getPlatform().getConversionManager().getLoader());
            }
        }
    }

    protected ClassDescriptor getDescriptor() {
        return descriptor;
    }
    

    public Object load(Object id) {
        UnitOfWork localSession = this.session.acquireUnitOfWork();
        try {
            return load(id, localSession);
        } finally {
            localSession.release();
        }
    }

    public Map loadAll(Collection ids) {
        UnitOfWork uow = session.acquireUnitOfWork();
        try{
            Map map = new HashMap(ids.size());
            Iterator iterator = ids.iterator();
            while (iterator.hasNext()) {
                Object key = iterator.next();
                Object result = this.load(key, uow);
                if (result != null) {
                    map.put(key, uow);
                }
            }
            return map;
        }finally{
            uow.release();
        }
    }
    
    protected Object load(Object id, UnitOfWork uow){
        ReadObjectQuery localQuery = (ReadObjectQuery) this.roq.clone();
        localQuery.setIsExecutionClone(true);
        if (this.descriptor.getCacheKeyType() == CacheKeyType.ID_VALUE) {
            localQuery.setSelectionId(id);
        } else {
            localQuery.setSelectionId(new CacheId((Object[]) id));
        }
        Object result = uow.executeQuery(localQuery);
        if (result != null) {
            result = CoherenceCacheHelper.decomposeEntity(result, getDescriptor(), (AbstractSession) uow);
        }
        return result;
    }

}
