// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import oracle.eclipselink.coherence.exceptions.IntegrationException;

import org.eclipse.persistence.descriptors.ClassDescriptor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.ArrayList;
import java.util.Iterator;

import static org.eclipse.persistence.internal.libraries.asm.Constants.*;

import org.eclipse.persistence.internal.helper.ClassConstants;
import org.eclipse.persistence.internal.libraries.asm.ClassWriter;
import org.eclipse.persistence.internal.libraries.asm.CodeVisitor;
import org.eclipse.persistence.internal.libraries.asm.Type;
import org.eclipse.persistence.internal.libraries.asm.attrs.SignatureAttribute;
import org.eclipse.persistence.internal.security.PrivilegedAccessHelper;
import org.eclipse.persistence.internal.security.PrivilegedGetMethod;
import org.eclipse.persistence.internal.security.PrivilegedMethodInvoker;
import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.mappings.ForeignReferenceMapping;

/**
 * <p>
 * <b>Purpose:</b> This class is used to generate wrapper classes for the Cached
 * Entities.
 * 
 * All Entities stored within Coherence will be wrapped by a generated Wrapper.
 * This Wrapper provides a mechanism to cache relationship values while
 * providing access to the default Coherence ReflectionValueExtractor.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

public class WrapperGenerator {

    // stores a reflective reference to the ClassLoader defineClass method.
    protected Method defineClass;

    protected String wrapperClassName;

    public WrapperGenerator() {
        if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
            try {
                this.defineClass = AccessController.doPrivileged(new PrivilegedGetMethod(ClassLoader.class, "defineClass", new Class[] { String.class, byte[].class, int.class, int.class }, true));
            } catch (PrivilegedActionException exception) {
                throw IntegrationException.unableToAccessDefineClassMethodOfClassLader(exception.getException());
            }
        } else {
            try {
                this.defineClass = PrivilegedAccessHelper.getMethod(ClassLoader.class, "defineClass", new Class[] { String.class, byte[].class, int.class, int.class }, true);
            } catch (NoSuchMethodException e) {
                throw IntegrationException.unableToAccessDefineClassMethodOfClassLader(e);
            }
        }
    }

    public String getInternalWrapperClassName(Class javaClass) {
        if (wrapperClassName == null) {
            wrapperClassName = "oracle/eclipselink/coherence/integrated/cache/wrappers/" + Type.getInternalName(javaClass) + "_Wrapper";
        }
        return wrapperClassName;
    }

    // reflectively attempts to define wrapper class on ClassLoader
    protected void defineClass(String className, ClassLoader classloader, byte[] classBytes) {
        try {
            if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
                try {
                    AccessController.doPrivileged(new PrivilegedMethodInvoker(defineClass, classloader, new Object[] { null, classBytes, 0, classBytes.length }));
                } catch (PrivilegedActionException exception) {
                    throw IntegrationException.unableToDefineGeneratedWrapperClass(className, exception.getException());
                }
            } else {
                PrivilegedAccessHelper.invokeMethod(this.defineClass, classloader, new Object[] { null, classBytes, 0, classBytes.length });
            }
        } catch (IllegalAccessException ex) {
            throw IntegrationException.unableToDefineGeneratedWrapperClass(className, ex);
        } catch (InvocationTargetException ex) {
            throw IntegrationException.unableToDefineGeneratedWrapperClass(className, ex);
        }

    }

    // This method will be called when attempting to define a wrapper in a
    // classLoader for a particular descriptor.
    public void createWrapperFor(Class javaClass, ClassLoader classLoader) {
        String wrapperName = getInternalWrapperClassName(javaClass);
        defineClass(wrapperName, classLoader, generateWrapper(javaClass, wrapperName));
    }

    // This method uses descriptor information to generate a wrapper for the
    // Entity Class
    public byte[] generateWrapper(Class javaClass, String wrapperClassName) {
        String castType = Type.getDescriptor(javaClass);
        CodeVisitor cv;
        ClassWriter cw = new ClassWriter(true);

        cw.visit(V1_5, ACC_PUBLIC + ACC_SUPER, wrapperClassName, "java/lang/Object", new String[] { "oracle/eclipselink/coherence/integrated/internal/cache/WrapperInternal" }, javaClass.getSimpleName() + "_Wrapper.java");
        cw.visitField(ACC_PROTECTED, "delegate", castType, null, null);

        SignatureAttribute fieldAttrs1 = new SignatureAttribute("Ljava/util/Map<Ljava/lang/String;[Ljava/lang/Object;>;");
        cw.visitField(ACC_PROTECTED, "relationships", "Ljava/util/Map;", null, fieldAttrs1);

        fieldAttrs1 = new SignatureAttribute("Ljava/util/Map<Ljava/lang/String;[Ljava/lang/Object;>;");
        cw.visitField(ACC_PROTECTED, "rows", "Ljava/util/Map;", null, fieldAttrs1);

        cv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V");
        cv.visitVarInsn(ALOAD, 0);
        cv.visitTypeInsn(NEW, "java/util/HashMap");
        cv.visitInsn(DUP);
        cv.visitMethodInsn(INVOKESPECIAL, "java/util/HashMap", "<init>", "()V");
        cv.visitFieldInsn(PUTFIELD, wrapperClassName, "relationships", "Ljava/util/Map;");
        cv.visitVarInsn(ALOAD, 0);
        cv.visitTypeInsn(NEW, "java/util/HashMap");
        cv.visitInsn(DUP);
        cv.visitMethodInsn(INVOKESPECIAL, "java/util/HashMap", "<init>", "()V");
        cv.visitFieldInsn(PUTFIELD, wrapperClassName, "rows", "Ljava/util/Map;");
        cv.visitInsn(RETURN);
        cv.visitMaxs(3, 1);

        cv = cw.visitMethod(ACC_PUBLIC, "unwrap", "()Ljava/lang/Object;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "delegate", castType);
        cv.visitInsn(ARETURN);
        cv.visitMaxs(1, 1);

        cv = cw.visitMethod(ACC_PUBLIC, "wrap", "(Ljava/lang/Object;)V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitVarInsn(ALOAD, 1);
        cv.visitTypeInsn(CHECKCAST, Type.getInternalName(javaClass));
        cv.visitFieldInsn(PUTFIELD, wrapperClassName, "delegate", castType);
        cv.visitInsn(RETURN);
        cv.visitMaxs(2, 2);

        cv = cw.visitMethod(ACC_PUBLIC, "getForeignKeyValuesFor", "(Ljava/lang/String;)[Ljava/lang/Object;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "rows", "Ljava/util/Map;");
        cv.visitVarInsn(ALOAD, 1);
        cv.visitMethodInsn(INVOKEINTERFACE, "java/util/Map", "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
        cv.visitTypeInsn(CHECKCAST, "[Ljava/lang/Object;");
        cv.visitInsn(ARETURN);
        cv.visitMaxs(2, 2);

        cv = cw.visitMethod(ACC_PUBLIC, "setForeignKeyValuesFor", "(Ljava/lang/String;[Ljava/lang/Object;)V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "rows", "Ljava/util/Map;");
        cv.visitVarInsn(ALOAD, 1);
        cv.visitVarInsn(ALOAD, 2);
        cv.visitMethodInsn(INVOKEINTERFACE, "java/util/Map", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
        cv.visitInsn(POP);
        cv.visitInsn(RETURN);
        cv.visitMaxs(3, 3);

        cv = cw.visitMethod(ACC_PUBLIC, "getPrimaryKeyValuesFor", "(Ljava/lang/String;)[Ljava/lang/Object;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "relationships", "Ljava/util/Map;");
        cv.visitVarInsn(ALOAD, 1);
        cv.visitMethodInsn(INVOKEINTERFACE, "java/util/Map", "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
        cv.visitTypeInsn(CHECKCAST, "[Ljava/lang/Object;");
        cv.visitInsn(ARETURN);
        cv.visitMaxs(2, 2);

        cv = cw.visitMethod(ACC_PUBLIC, "setPrimaryKeyValuesFor", "(Ljava/lang/String;[Ljava/lang/Object;)V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "relationships", "Ljava/util/Map;");
        cv.visitVarInsn(ALOAD, 1);
        cv.visitVarInsn(ALOAD, 2);
        cv.visitMethodInsn(INVOKEINTERFACE, "java/util/Map", "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
        cv.visitInsn(POP);
        cv.visitInsn(RETURN);
        cv.visitMaxs(3, 3);

        cv = cw.visitMethod(ACC_PUBLIC, "setForeignKeys", "(Ljava/util/Map;)V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitVarInsn(ALOAD, 1);
        cv.visitFieldInsn(PUTFIELD, wrapperClassName, "rows", "Ljava/util/Map;");
        cv.visitInsn(RETURN);
        cv.visitMaxs(2, 2);

        cv = cw.visitMethod(ACC_PUBLIC, "setPrimaryKeys", "(Ljava/util/Map;)V", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitVarInsn(ALOAD, 1);
        cv.visitFieldInsn(PUTFIELD, wrapperClassName, "relationships", "Ljava/util/Map;");
        cv.visitInsn(RETURN);
        cv.visitMaxs(2, 2);

        cv = cw.visitMethod(ACC_PUBLIC, "getForeignKeys", "()Ljava/util/Map;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "rows", "Ljava/util/Map;");
        cv.visitInsn(ARETURN);
        cv.visitMaxs(1, 1);

        cv = cw.visitMethod(ACC_PUBLIC, "getPrimaryKeys", "()Ljava/util/Map;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitFieldInsn(GETFIELD, wrapperClassName, "relationships", "Ljava/util/Map;");
        cv.visitInsn(ARETURN);
        cv.visitMaxs(1, 1);

        cv = cw.visitMethod(ACC_PUBLIC, "getWrapperClassName", "()Ljava/lang/String;", null, null);
        cv.visitVarInsn(ALOAD, 0);
        cv.visitMethodInsn(INVOKEVIRTUAL, "java/lang/Object", "getClass", "()Ljava/lang/Class;");
        cv.visitMethodInsn(INVOKEVIRTUAL, "java/lang/Class", "getName", "()Ljava/lang/String;");
        cv.visitInsn(ARETURN);
        cv.visitMaxs(1, 1);

        cv = cw.visitMethod(ACC_PUBLIC, "setWrapperClassName", "(Ljava/lang/String;)V", null, null);
        cv.visitInsn(RETURN);
        cv.visitMaxs(0, 2);

        ArrayList list = new ArrayList();
        Method[] methods = javaClass.getMethods();
        for (int i = 0; i < methods.length; ++i) {
            Method method = methods[i];
            if (method.getParameterTypes().length == 0 && (method.getName().startsWith("get") || method.getName().startsWith("is")) && !method.getName().contains("getClass")) {
                Class attributeClass = method.getReturnType();
                String type = Type.getDescriptor(attributeClass);

                cv = cw.visitMethod(ACC_PUBLIC, method.getName(), "()" + type, null, null);
                cv.visitVarInsn(ALOAD, 0);
                cv.visitFieldInsn(GETFIELD, wrapperClassName, "delegate", castType);
                cv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(javaClass), method.getName(), "()" + type);
                if (attributeClass.isPrimitive()) {
                    if (attributeClass.equals(ClassConstants.PDOUBLE)) {
                        cv.visitInsn(DRETURN);
                    } else if (attributeClass.equals(ClassConstants.PFLOAT)) {
                        cv.visitInsn(FRETURN);
                    } else if (attributeClass.equals(ClassConstants.PLONG)) {
                        cv.visitInsn(LRETURN);
                    } else {
                        cv.visitInsn(IRETURN);
                    }
                } else {
                    cv.visitInsn(ARETURN);
                }
                cv.visitMaxs(1, 1);
            }
        }
        
        
        /**
        Iterator<DatabaseMapping> iterator = descriptor.getMappings().iterator();
        while (iterator.hasNext()) {
            DatabaseMapping mapping = iterator.next();
            String getName = mapping.getGetMethodName();
            if (getName == null) {
                String fieldName = mapping.getAttributeName();
                StringBuffer buffer = new StringBuffer(fieldName.length() + 3);
                buffer.append("get");
                buffer.append(fieldName.substring(0, 1).toUpperCase());
                buffer.append(fieldName.substring(1, fieldName.length()));
                getName = buffer.toString();
            }
            Class attributeClass = null;
            if (mapping.isForeignReferenceMapping()) {
                attributeClass = ((ForeignReferenceMapping) mapping).getReferenceClass();
            } else {
                attributeClass = mapping.getAttributeClassification();
            }
            String type = Type.getDescriptor(attributeClass);

            cv = cw.visitMethod(ACC_PUBLIC, getName, "()" + type, null, null);
            cv.visitVarInsn(ALOAD, 0);
            cv.visitFieldInsn(GETFIELD, wrapperClassName, "delegate", castType);
            cv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(descriptor.getJavaClass()), getName, "()" + type);
            if (attributeClass.isPrimitive()) {
                if (attributeClass.equals(ClassConstants.PDOUBLE)) {
                    cv.visitInsn(DRETURN);
                } else if (attributeClass.equals(ClassConstants.PFLOAT)) {
                    cv.visitInsn(FRETURN);
                } else if (attributeClass.equals(ClassConstants.PLONG)) {
                    cv.visitInsn(LRETURN);
                } else {
                    cv.visitInsn(IRETURN);
                }
            } else {
                cv.visitInsn(ARETURN);
            }
            cv.visitMaxs(1, 1);
        }
    */
        cw.visitEnd();

        return cw.toByteArray();
    }

}
