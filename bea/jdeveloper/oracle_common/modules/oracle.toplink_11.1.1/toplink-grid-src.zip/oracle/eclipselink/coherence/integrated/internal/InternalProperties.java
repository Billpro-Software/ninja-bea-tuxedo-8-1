// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal;

/**
 * This abstract class contains the property names used by the
 * EclipseLink-JPA/Coherence integration. These properties are used to configure
 * the JPA persistence-unit and descriptors for the entities that will use
 * Coherence.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public abstract class InternalProperties {

    /**
     * This is the property name that will be used in each descriptor to store
     * the class reference for the cache wrapper for a particular class.
     */
    public static final String CACHE_WRAPPER = "coherence.cache.wrapper";
    
    /**
     * This property is used by the Cache Loader initialization to track what descriptors have
     * been initialized
     */
    
    public static final String DESCRIPTOR_INITIALIZED = "coherence.descriptor.initialized";

}
