// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import org.eclipse.persistence.internal.sessions.AbstractRecord;

import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import oracle.eclipselink.coherence.integrated.querying.TranslationFailureDelegate;

/**
 * TopLink-Grid's policy is to redirect the query to the database.
 * @author gyorke
 *
 */
public class EclipseLinkQueryFailurePolicy implements TranslationFailureDelegate {

    @Override
    public Object translationFailed(DatabaseQuery query, Record arguments, Session session) {
        query.setDoNotRedirect(true);
        return ((AbstractSession) session).executeQuery(query, (AbstractRecord) arguments);
    }

}
