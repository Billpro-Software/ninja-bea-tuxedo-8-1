// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.standalone;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;
import oracle.eclipselink.coherence.querying.DontMaintainCacheRedirector;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.identitymaps.NoIdentityMap;
import org.eclipse.persistence.jpa.JpaHelper;
import org.eclipse.persistence.sessions.server.Server;

import com.tangosol.net.cache.CacheLoader;
import com.tangosol.util.Base;

/**
 * This is a Coherence Cache Loader that can be used when EclipseLink is is
 * desired as the persistence provider and no Cache Interceptors or Query
 * Redirectors from the EclipseLink-Coherence integration are set within the
 * Persistence Unit for the specific class. This is intended to be used where
 * the application uses Coherence directly and the cache store/loader are used
 * behind the scene to persist and load data.
 * 
 * <p>
 * <b>Coherence Configuration:</b> In order to use the integrated
 * EclipseLinkJPACacheLoader or EclipseLinkJPACacheStore the Coherence
 * configuration XML file must specify the loader/store class as well as
 * providing parameters for the cache-name and JPA persistence unit name.
 * <p>
 * The following is an example of how the standalone EclipseLinkJPACacheLoader
 * can be configured.
 * 
 * <pre>
 * &lt;cachestore-scheme&gt;
 *    &lt;class-scheme&gt;
 *       &lt;class-name&gt;oracle.eclipselink.coherence.standalone.EclipseLinkJPACacheLoader&lt;/class-name&gt; 
 *       &lt;init-params&gt; 
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;{cache-name}&lt;/param-value&gt; 
 *          &lt;/init-param&gt;
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;coherence-pu&lt;/param-value&gt; 
 *          &lt;/init-param&gt; 
 *       &lt;/init-params&gt;
 *    &lt;/class-scheme&gt;
 * &lt;/cachestore-scheme&gt;
 * </pre>
 * 
 * @author gyorke, djclarke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class EclipseLinkJPACacheLoader extends Base implements CacheLoader {

    private EntityManagerFactory emf;
    private ClassDescriptor descriptor;

    public EclipseLinkJPACacheLoader(String cacheName, String puName) {
        emf = Persistence.createEntityManagerFactory(puName);

        Server session = JpaHelper.getServerSession(this.emf);
        this.descriptor = CoherenceCacheHelper.getDescriptor(cacheName, session, false);

        // Ensure no caching is done in the CacheLoader/Store as this would
        // conflict with Coherence
        this.descriptor.setDefaultQueryRedirector(new DontMaintainCacheRedirector());
        this.descriptor.setUnitOfWorkCacheIsolationLevel(descriptor.ISOLATE_CACHE_ALWAYS);

        // Optimistic lock checking cannot be done within the CacheStore so
        // any configured policy is removed
        this.descriptor.setOptimisticLockingPolicy(null);

        // Primary keys assigned using sequencing cannot be done within the
        // CacheStore so
        this.descriptor.setSequenceNumberName(null);
        this.descriptor.setSequenceNumberField(null);
    }

    protected EntityManagerFactory getEMF() {
        return this.emf;
    }

    protected ClassDescriptor getDescriptor() {
        return descriptor;
    }

    public Object load(Object id) {
        EntityManager em = getEMF().createEntityManager();

        try {
            return em.find(getDescriptor().getJavaClass(), id);
        } finally {
            em.close();
        }
    }

    public Map loadAll(Collection ids) {
        EntityManager em = getEMF().createEntityManager();

        try {
            Map map = new HashMap(ids.size());
            Iterator iterator = ids.iterator();
            while (iterator.hasNext()) {
                Object key = iterator.next();
                Object result = this.load(key);
                if (result != null) {
                    map.put(key, result);
                }
            }
            return map;
        } finally {
            em.close();
        }
    }

}
