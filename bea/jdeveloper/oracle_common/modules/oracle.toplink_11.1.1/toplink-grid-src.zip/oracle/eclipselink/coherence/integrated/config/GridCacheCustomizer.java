// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.config;

import oracle.eclipselink.coherence.integrated.cache.CoherenceInterceptor;

import org.eclipse.persistence.config.DescriptorCustomizer;
import org.eclipse.persistence.descriptors.ClassDescriptor;

/*
 * This class should be set on an Entity class to cache instances
 * in Coherence instead of in the internal EclipseLink shared cache.
 * Consider using Grid Cache as an alternative to cache co-ordination
 * when Coherence is available.
 * 
 * This customizer can be set through native code, annotations or xml
 * (persistence.xml)
 * 
 * @see org.eclipse.persistence.annotations.Customizer
 * @see oracle.eclipselink.coherence.integrated.config.CoherenceReadCustomizer
 * @see oracle.eclipselink.coherence.integrated.config.CoherenceReadWriteCustomizer
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.3.0)
 */
public class GridCacheCustomizer implements DescriptorCustomizer {

    public void customize(ClassDescriptor descriptor) throws Exception {
        descriptor.setCacheInterceptorClass(CoherenceInterceptor.class);
    }
    
    public static void afterLoad(ClassDescriptor descriptor) {
        descriptor.setCacheInterceptorClass(CoherenceInterceptor.class);
    }

}
