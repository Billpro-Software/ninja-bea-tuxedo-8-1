// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * <b>Purpose:</b> This class is used to track all objects composed from a
 * coherence get call. This allows us to track what objects this thread has
 * retrieved in the case a cycle is experienced. The depth is the number of time
 * this thread has called getFromCoherence. When depth gets to zero we should
 * empty the thread local to prevent any leakage.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class ComposeIdentityMap {
    protected Map<Class<?>, Map<Object, Object>> composedEntities;
    protected int depth;
    
    public ComposeIdentityMap(){
        this.composedEntities = new HashMap<Class<?>, Map<Object, Object>>();
        this.depth = 0;
    }

    /**
     * @return the composedEntities
     */
    public Object getComposedEntity(Class<?> clazz, Object key) {
        Map<Object, Object> inner = this.composedEntities.get(clazz);
        if (inner!= null)return inner.get(key);
        return null;
    }

    /**
     * @param composedEntities the composedEntities to set
     */
    public void addComposedEntity(Object key, Object object) {
        Map<Object, Object> inner = this.composedEntities.get(object.getClass());
        if (inner == null){
            inner = new HashMap<Object, Object>();
            this.composedEntities.put(object.getClass(), inner);
        }
        inner.put(key, object);
    }

    /**
     * @return true if we are back at the point in the stack where the first entity was composed.
     */
    public boolean atStart() {
        return depth <= 0;
    }

    public void incrementDepth() {
        this.depth++;
    }
    public void decrementDepth() {
        this.depth--;
    }
    

}
