// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 

package oracle.eclipselink.coherence.integrated.cache;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.integrated.internal.cache.WrapperGenerator;
import oracle.eclipselink.coherence.integrated.internal.cache.WrapperInternal;


import com.tangosol.io.ClassLoaderAware;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofSerializer;
import com.tangosol.io.pof.PofWriter;

/**
 * <p>
 * <b>Purpose:</b> This class is used to provide serialization support for the
 * Entity Wrappers within Coherence when wish to access the Coherence Caches
 * directly. This includes users who have custom Value Extractors.
 * 
 * Users who have custom POF serializers will need to create the pof
 * configuration xml for their types. And set the serializer to be the
 * WrapperConfigurablePOFContext instead.
 * 
 * @author gyorke
 * @since TopLink 11g (11.1.1.1.0)
 */
public class WrapperPofSerializer implements PofSerializer, ClassLoaderAware {

    protected WeakReference<ClassLoader> loaderReference;
    protected Map<String, Class> classes;

    protected boolean isNotEclipseLink = false;

    public WrapperPofSerializer() {
        this.classes = new HashMap<String, Class>();
        this.isNotEclipseLink = System.getProperty(IntegrationProperties.IS_NOT_ECLIPSELINK) != null;
    }

    public WrapperPofSerializer(ClassLoader loader) {
        this();
        setContextClassLoader(loader);
    }

    public Object deserialize(PofReader pofreader) throws IOException {
        Object wrapperName = pofreader.readObject(0);
        if (wrapperName instanceof String) {
            Object entity = pofreader.readObject(1);
            if (isNotEclipseLink) {
                pofreader.readRemainder();
                return entity;
            }

            Class wrapperClass = this.classes.get(wrapperName);
            if (wrapperClass == null) {
                synchronized (this.classes) {
                    try {
                        wrapperClass = Class.forName((String) wrapperName, false, getContextClassLoader());
                    } catch (ClassNotFoundException e) {
                        WrapperGenerator generator = new WrapperGenerator();
                        generator.createWrapperFor(entity.getClass(), getContextClassLoader());
                        try {
                            wrapperClass = Class.forName((String) wrapperName, false, getContextClassLoader());
                        } catch (ClassNotFoundException ex2) {
                            pofreader.readRemainder();
                            return entity;
                        }
                    }
                    this.classes.put((String) wrapperName, wrapperClass);
                }
            }
            boolean exception = false;
            WrapperInternal wrapperInstance = null;
            try {
                wrapperInstance = (WrapperInternal) wrapperClass.newInstance();
                wrapperInstance.wrap(entity);
                wrapperInstance.setForeignKeys(pofreader.readMap(2, new HashMap()));
                wrapperInstance.setPrimaryKeys(pofreader.readMap(3, new HashMap()));
                pofreader.readRemainder();
            } catch (InstantiationException e) {
                exception = true;
            } catch (IllegalAccessException e) {
                exception = true;
            }
            if (exception) {
                // we were unable to load the wrapper class, we may be on a
                // client, only return the delegate.
                return entity;
            }
            return wrapperInstance;
        } else {
            return wrapperName;
        }
    }

    public void serialize(PofWriter pofwriter, Object obj) throws IOException {
        if (obj instanceof WrapperInternal) {
            WrapperInternal wrapper = (WrapperInternal) obj;
            pofwriter.writeString(0, wrapper.getWrapperClassName());
            pofwriter.writeObject(1, wrapper.unwrap());
            pofwriter.writeMap(2, wrapper.getForeignKeys());
            pofwriter.writeMap(3, wrapper.getPrimaryKeys());
            pofwriter.writeRemainder(null);
        } else {
            pofwriter.writeObject(0, obj);
        }

    }

    public ClassLoader getContextClassLoader() {
        return loaderReference != null ? (ClassLoader) loaderReference.get() : null;
    }

    public void setContextClassLoader(ClassLoader loader) {
        loaderReference = loader != null ? new WeakReference<ClassLoader>(loader) : null;
    }

    /**
     * @return the isNotEclipseLink
     */
    public boolean isNotEclipseLink() {
        return isNotEclipseLink;
    }

    /**
     * @param isNotEclipseLink
     *            the isNotEclipseLink to set
     */
    public void setNotEclipseLink(boolean isNotEclipseLink) {
        this.isNotEclipseLink = isNotEclipseLink;
    }

}
