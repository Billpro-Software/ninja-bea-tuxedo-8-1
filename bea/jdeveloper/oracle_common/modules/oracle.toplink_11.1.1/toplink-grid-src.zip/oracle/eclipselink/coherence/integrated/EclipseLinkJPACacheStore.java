// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.EntityManager;

import org.eclipse.persistence.internal.jpa.EntityManagerImpl;

import oracle.eclipselink.coherence.integrated.cache.Wrapper;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;

import com.tangosol.net.cache.CacheStore;

/**
 * This is the Coherence Cache Store that should be used with EclipseLink
 * Coherence interceptors and redirectors set in your PeristenceUnit. No special
 * Persistence Unit updates should be required when used with this Cache Store.
 * <p>
 * This cache store is used in cases where Coherence is expected to be writing
 * as would be the case if 'Write behind' functionality was being used.
 * 
 * @see EclipseLinkJPACacheLoader
 * @author gyorke, djclarke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class EclipseLinkJPACacheStore extends EclipseLinkJPACacheLoader implements CacheStore {

    public EclipseLinkJPACacheStore(String cacheName, String puName) {
        super(cacheName, puName);
    }

    public void erase(Object id) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();

            Object dbEntity = em.find(getDescriptor().getJavaClass(), id);
            if (dbEntity != null) {
                em.remove(dbEntity);
            }

            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void eraseAll(Collection ids) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();
            for (Iterator iter = ids.iterator(); iter.hasNext();) {
                Object id = iter.next();
                Object dbEntity = em.find(getDescriptor().getJavaClass(), id);
                if (dbEntity != null) {
                    em.remove(dbEntity);
                }
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void store(Object id, Object entity) {
        EntityManager em = getEMF().createEntityManager();
        try {
            em.getTransaction().begin();
        if (entity instanceof Wrapper){
            entity = CoherenceCacheHelper.composeEntity(id, entity, this.descriptor, ((EntityManagerImpl)em).getActivePersistenceContext(null), true);
            ((EntityManagerImpl)em).getActivePersistenceContext(null).mergeCloneWithReferences(entity);
        }else{
            ((EntityManagerImpl)em).getActivePersistenceContext(null).mergeClone(entity);
        }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void storeAll(Map entities) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();

            for (Iterator<Map.Entry> iter = entities.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = iter.next();
                Object entity = entry.getValue();
                if (entity instanceof Wrapper){
                    entity = CoherenceCacheHelper.composeEntity(entry.getKey(), entity, this.descriptor, ((EntityManagerImpl)em).getActivePersistenceContext(null), true);
                    em.merge(entity);
                }else{
                    ((EntityManagerImpl)em).getActivePersistenceContext(null).mergeClone(entity);
                }
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }
}
