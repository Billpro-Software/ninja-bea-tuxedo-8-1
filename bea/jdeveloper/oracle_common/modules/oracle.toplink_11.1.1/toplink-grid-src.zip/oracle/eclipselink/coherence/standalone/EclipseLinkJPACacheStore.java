// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.standalone;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.EntityManager;

import com.tangosol.net.cache.CacheStore;

/**
 * This is a Coherence Cache Store that can be used when EclipseLink is is
 * desired as the persistence provider and no Cache Interceptors or Query
 * Redirectors from the EclipseLink-Coherence integration are set within the
 * Persistence Unit for the specific class.
 * 
 * @see EclipseLinkJPACacheLoader
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class EclipseLinkJPACacheStore extends EclipseLinkJPACacheLoader implements CacheStore {

    public EclipseLinkJPACacheStore(String cacheName, String puName) {
        super(cacheName, puName);
    }

    public void erase(Object id) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();

            Object dbEntity = em.find(getDescriptor().getJavaClass(), id);
            if (dbEntity != null) {
                em.remove(dbEntity);
            }

            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void eraseAll(Collection ids) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();
            for (Iterator iter = ids.iterator(); iter.hasNext();) {
                Object id = iter.next();
                Object dbEntity = em.find(getDescriptor().getJavaClass(), id);
                if (dbEntity != null) {
                    em.remove(dbEntity);
                }
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void store(Object id, Object entity) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();
            em.merge(entity);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void storeAll(Map entities) {
        EntityManager em = getEMF().createEntityManager();

        try {
            em.getTransaction().begin();

            for (Iterator<Map.Entry> iter = entities.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = iter.next();
                em.merge(entry.getValue());
            }

            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }
}
