// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

/**
 * This policy is invoked when a query can not be translated by the
 * FilterFactory. This policy give the implementor the opportunity to redirect
 * the query or provide further translation.
 * 
 * @author gyorke
 * 
 */
public interface TranslationFailureDelegate {

    /**
     * This method is called when the query can not be translated by the configured FilterFactory.
     * This methods should return the correct results in the form expected by the query (ReadAllQuery.getContainerPolicy).
     * If the results can not be obtained an Exception should be thrown.
     * @param query
     * @param arguments
     * @param session
     * @return
     */
    public Object translationFailed(DatabaseQuery query, Record arguments, Session session);

}
