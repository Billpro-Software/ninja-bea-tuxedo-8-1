// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import java.io.Serializable;

import oracle.eclipselink.coherence.integrated.cache.Wrapper;

import org.eclipse.persistence.mappings.AttributeAccessor;
import org.eclipse.persistence.mappings.DatabaseMapping;

import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;

/**
 * <p>
 * <b>Purpose:</b> This class will be used by the filters to extract values from the objects
 * stored in the caches. It will support both attribute access and method
 * access.
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

/**
 * This class will be used by the filters to extract values from the objects
 * stored in the caches. It will support both attribute access and method
 * access.
 */
public class FilterExtractor extends AbstractExtractor implements Serializable, EclipseLinkExtractor{
   protected static final Class reflectionExtractor = ReflectionExtractor.class;
    
    protected AttributeAccessor attributeAccessor;

    public FilterExtractor(DatabaseMapping mapping) {
        attributeAccessor = (AttributeAccessor) mapping.getAttributeAccessor().clone();
    }

    public FilterExtractor(AttributeAccessor accessor) {
        attributeAccessor = accessor;
    }

    public Object extract(Object obj) {
        if (obj instanceof Wrapper){
            obj = ((Wrapper)obj).unwrap();
        }
        if (!attributeAccessor.isInitialized()) {
            attributeAccessor.initializeAttributes(obj.getClass());
        }try{
            return attributeAccessor.getAttributeValueFromObject(obj);
        }catch(Exception e){
            // obj uses inheritance and this is a filter on a subclass;
            return new InvalidObject();
        }
    }
    
    public Class getAttributeClass(){
        return this.attributeAccessor.getAttributeClass();
    }
    
    /**
     * @return the accessor
     */
    public AttributeAccessor getAccessor() {
        return attributeAccessor;
    }

    /**
     * @param accessor the accessor to set
     */
    public void setAccessor(AttributeAccessor accessor) {
        this.attributeAccessor = accessor;
    }
    
    public static class InvalidObject{
        
        @Override
        public int hashCode(){
            return -1;
        }

        @Override
        public boolean equals(Object obj) {
            return false;
        }

    }

    @Override
    public int hashCode() {
        return ("get" + attributeAccessor.getAttributeName().substring(0,1).toUpperCase() + attributeAccessor.getAttributeName().substring(1)).hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() == obj.getClass()){
            FilterExtractor other = (FilterExtractor) obj;
            return (other.attributeAccessor.getAttributeName().equals(this.attributeAccessor.getAttributeName()));
        }else if (obj.getClass().equals(reflectionExtractor)){
            return ((ReflectionExtractor)obj).getMethodName().length() == attributeAccessor.getAttributeName().length() +3 && ((ReflectionExtractor)obj).getMethodName().contains(attributeAccessor.getAttributeName().substring(1));
        }
        return false;
    }
    
}
