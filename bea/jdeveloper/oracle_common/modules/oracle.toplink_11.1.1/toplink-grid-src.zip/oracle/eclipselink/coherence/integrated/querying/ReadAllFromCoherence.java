// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;
import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.identitymaps.CacheKey;
import org.eclipse.persistence.internal.queries.ContainerPolicy;
import org.eclipse.persistence.internal.sessions.AbstractRecord;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.internal.sessions.UnitOfWorkImpl;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.queries.ReadAllQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;

/**
 * <p>
 * <b>Purpose:</b> This Query Redirector should be set on any class or query
 * where the user wants Coherence to be checked for data instead of the
 * database. With this Redirector set TopLink will not issue any SQL for Reads
 * unless the query can not be translated into a Coherence filter.
 * 
 * Developers should note that Coherence will return only those object that are
 * in the Cache any objects that may fit the query but remain on the database
 * only will not be returned.
 * 
 * Developers should set the Coherence Cache name that corresponds to this class
 * in a descriptor property called "coherence.cache.name". Each class should
 * have its own Cache unless the PK's of the instances are unique amoung all
 * classes stored in a single cache
 * 
 * This Redirector can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations.
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.
 *      setDefaultInsertQueryRedirector(QueryRedirector)
 * @see org.eclipse.persistence.annotations.QueryRedirectors
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class ReadAllFromCoherence extends CoherenceRedirector implements QueryRedirector {

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {

        Filter filter = getFilterFactory(session).create((ReadAllQuery) query, arguments, session);
        if (filter == FilterFactory.NO_FILTER) {
            return getTranslationFailureDelegate(session).translationFailed(query, arguments, session);
        }
        NamedCache cache = getNamedCache(query.getDescriptor().getRootDescriptor(), session);
        Set entries = cache.entrySet(filter);
        ContainerPolicy cp = ((ReadAllQuery) query).getContainerPolicy();
        Object container = cp.containerInstance(entries.size());
        ClassDescriptor descriptor = query.getDescriptor();
        if (session.isUnitOfWork()) {
            CacheKey parent = new CacheKey(3);
            UnitOfWorkImpl uow = (UnitOfWorkImpl) session;
            for (Iterator iterator = entries.iterator(); iterator.hasNext();) {
                Map.Entry entry = (Map.Entry) iterator.next();
                Object value = entry.getValue();
                value = CoherenceCacheHelper.composeEntity(entry.getKey(), value, descriptor, (AbstractSession) session, false);
                parent.setObject(value);
                Object pk = descriptor.getObjectBuilder().extractPrimaryKeyFromObject(value, (AbstractSession) session);

                parent.setKey(pk);
                value = uow.cloneAndRegisterObject(value, parent, descriptor);
                cp.addInto(value, container, (AbstractSession) session);
            }
        } else {
            for (Iterator iterator = entries.iterator(); iterator.hasNext();) {
                Map.Entry entry = (Map.Entry) iterator.next();
                Object value = entry.getValue();
                value = CoherenceCacheHelper.composeEntity(entry.getKey(), value, query.getDescriptor(), (AbstractSession) session, false);
                cp.addInto(value, container, (AbstractSession) session);
            }
        }
        return container;
    }

}
