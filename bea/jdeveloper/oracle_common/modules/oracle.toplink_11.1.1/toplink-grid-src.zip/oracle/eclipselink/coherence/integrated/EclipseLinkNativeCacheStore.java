// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import oracle.eclipselink.coherence.integrated.cache.Wrapper;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;

import org.eclipse.persistence.annotations.CacheKeyType;
import org.eclipse.persistence.config.FlushClearCache;
import org.eclipse.persistence.internal.helper.DatabaseField;
import org.eclipse.persistence.internal.identitymaps.CacheId;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.internal.sessions.RepeatableWriteUnitOfWork;
import org.eclipse.persistence.queries.DeleteAllQuery;
import org.eclipse.persistence.sessions.Session;
import org.eclipse.persistence.sessions.UnitOfWork;
import org.eclipse.persistence.sessions.factories.ReferenceMode;
import org.eclipse.persistence.sessions.server.Server;

import com.tangosol.net.cache.CacheStore;

/**
 * This is the Coherence Cache Store that should be used with native EclipseLink
 * configuration (sessions.xml) when Coherence interceptors and redirectors have
 * been set through a customizer. This is equivalent to the JPA integration but
 * is used when the pre-existing application uses native EclipseLink
 * configuration. The 'sessions.xml' file must be available on the classpath or
 * packaged within a jar within the META-INF directory.
 * 
 * <p>
 * <b>Coherence Configuration:</b> In order to use the integrated
 * EclipseLinkNativeCacheLoader or EclipseLinkNativeCacheStore the Coherence
 * configuration XML file must specify the loader/store class as well as
 * providing parameters for the cache-name and session name.
 * <p>
 * This cache store is used in cases where Coherence is expected to be writing
 * as would be the case if 'Write behind' functionality was being used.
 * 
 * The Coherence Cache configuration is the same as when using the
 * EclipseLinkNativeCacheLoader.
 * 
 * @see EclipseLinkNativeCacheLoader
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.4.0)
 */
public class EclipseLinkNativeCacheStore extends EclipseLinkNativeCacheLoader implements CacheStore {
    
    protected DeleteAllQuery daq;

    public EclipseLinkNativeCacheStore(String cacheName, String sessionName) {
        super(cacheName, sessionName);
        daq = new DeleteAllQuery(this.descriptor.getJavaClass());
        daq.setSelectionCriteria(this.descriptor.getDescriptorQueryManager().getReadObjectQuery().getSelectionCriteria());
        daq.setIsExecutionClone(true);
        for (DatabaseField field: this.descriptor.getPrimaryKeyFields()){
            daq.addArgument(field.getQualifiedName());
        }
    }

    public void erase(Object id) {
        UnitOfWork uow = this.session.acquireUnitOfWork();
        List arguments = null;
        if (descriptor.getCacheKeyType().equals(CacheKeyType.CACHE_ID)) {
           arguments = Arrays.asList(((CacheId)id).getPrimaryKey());
        } else {
            arguments = new ArrayList();
            arguments.add(id);
        }

        uow.executeQuery(this.daq, arguments);
        uow.commit();
    }

    public void eraseAll(Collection ids) {
        for (Iterator iter = ids.iterator(); iter.hasNext();) {
            Object id = iter.next();
            this.erase(id);
        }
    }

    public void store(Object id, Object entity) {
        UnitOfWork uow = acquireUnitOfWork(this.session);
        try {
            store(id, entity, uow);
        } finally {
            uow.commit();
        }
    }

    public void storeAll(Map entities) {
        UnitOfWork uow = acquireUnitOfWork(this.session);
        try {
            for (Iterator<Map.Entry> iter = entities.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = iter.next();
                store(entry.getKey(), entry.getValue(), uow);
            }
            uow.commit();
        } finally {
            uow.release();
        }
    }

    protected void store(Object id, Object entity, UnitOfWork uow) {
        if (entity instanceof Wrapper) {
            entity = CoherenceCacheHelper.composeEntity(id, entity, this.descriptor, (AbstractSession) uow, true);
            uow.mergeCloneWithReferences(entity);
        } else {
            uow.mergeClone(entity);
        }
    }
    
    protected UnitOfWork acquireUnitOfWork(Session session){
        if (session.isServerSession()){
            session = ((Server)session).acquireClientSession();
        }
        RepeatableWriteUnitOfWork uow = new RepeatableWriteUnitOfWork((AbstractSession) session, ReferenceMode.HARD);
        uow.setResumeUnitOfWorkOnTransactionCompletion(true);
        uow.setShouldDiscoverNewObjects(true);
        uow.setDiscoverUnregisteredNewObjectsWithoutPersist(false);
        uow.setFlushClearCache(FlushClearCache.DropInvalidate);
        uow.setShouldValidateExistence(false);
        uow.setShouldOrderUpdates(false);
        uow.setShouldCascadeCloneToJoinedRelationship(true);
        uow.setShouldStoreByPassCache(false);
        
        return uow;

    }
}
