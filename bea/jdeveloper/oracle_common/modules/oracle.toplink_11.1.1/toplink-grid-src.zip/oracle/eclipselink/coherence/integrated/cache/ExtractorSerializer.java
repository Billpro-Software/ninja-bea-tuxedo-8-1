// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 

package oracle.eclipselink.coherence.integrated.cache;

import java.io.IOException;
import java.lang.ref.WeakReference;

import oracle.eclipselink.coherence.integrated.internal.cache.LockVersionExtractor;
import oracle.eclipselink.coherence.integrated.internal.querying.FilterExtractor;

import org.eclipse.persistence.internal.descriptors.InstanceVariableAttributeAccessor;
import org.eclipse.persistence.internal.descriptors.MethodAttributeAccessor;
import org.eclipse.persistence.mappings.AttributeAccessor;

import com.tangosol.io.ClassLoaderAware;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofSerializer;
import com.tangosol.io.pof.PofWriter;

/**
 * <p>
 * <b>Purpose:</b> This class is used to provide serialization support for the
 * Entity Wrappers within Coherence when wish to access the Coherence Caches
 * directly. This includes users who have custom Value Extractors.
 * 
 * Users who have custom POF serializers will need to create the pof
 * configuration xml for their types. And set the serializer to be the
 * WrapperConfigurablePOFContext instead.
 * 
 * @author gyorke
 * @since TopLink 11g (11.1.1.1.0)
 */
public class ExtractorSerializer implements PofSerializer, ClassLoaderAware {

    protected WeakReference<ClassLoader> loaderReference;
    
    protected final int INSTANCE_ACCESSOR = 0;
    protected final int METHOD_ACCESSOR = 1;
    
    protected final int VERSION_EXTRACTOR = 0;
    protected final int FILTER_EXTRACTOR = 1;

    public ExtractorSerializer() {
    }

    public ExtractorSerializer(ClassLoader loader) {
        this();
        setContextClassLoader(loader);
    }

    public Object deserialize(PofReader pofreader) throws IOException {
        if (pofreader.readInt(0) == VERSION_EXTRACTOR){
        String className = pofreader.readString(1);
        AttributeAccessor accessor = null;
        if (pofreader.readInt(2) == INSTANCE_ACCESSOR){
            accessor = new InstanceVariableAttributeAccessor();
            accessor.setAttributeName(pofreader.readString(3));
        }else{
            accessor = new MethodAttributeAccessor();
            ((MethodAttributeAccessor)accessor).setGetMethodName(pofreader.readString(3));
            ((MethodAttributeAccessor)accessor).setSetMethodName(pofreader.readString(4));
        }
        LockVersionExtractor extractor = new LockVersionExtractor(accessor,className);
        pofreader.readRemainder();
        return extractor;
        }else{
            AttributeAccessor accessor = null;
            if (pofreader.readInt(1) == INSTANCE_ACCESSOR){
                accessor = new InstanceVariableAttributeAccessor();
                accessor.setAttributeName(pofreader.readString(2));
            }else{
                accessor = new MethodAttributeAccessor();
                ((MethodAttributeAccessor)accessor).setGetMethodName(pofreader.readString(2));
                ((MethodAttributeAccessor)accessor).setSetMethodName(pofreader.readString(3));
            }
            FilterExtractor extractor = new FilterExtractor(accessor);
            pofreader.readRemainder();
            return extractor;
        }
    }

    public void serialize(PofWriter pofwriter, Object obj) throws IOException {
        if (obj instanceof LockVersionExtractor) {
            LockVersionExtractor extractor = (LockVersionExtractor) obj;
            pofwriter.writeInt(0, VERSION_EXTRACTOR);
            pofwriter.writeString(1, extractor.getClassName());
            if (extractor.getAccessor() instanceof InstanceVariableAttributeAccessor) {
                InstanceVariableAttributeAccessor accessor = (InstanceVariableAttributeAccessor) extractor.getAccessor();
                pofwriter.writeInt(2, INSTANCE_ACCESSOR);
                pofwriter.writeString(3, accessor.getAttributeName());
            } else {
                MethodAttributeAccessor accessor = (MethodAttributeAccessor) extractor.getAccessor();
                pofwriter.writeInt(2, METHOD_ACCESSOR);
                pofwriter.writeString(3, accessor.getGetMethodName());
                pofwriter.writeString(4, accessor.getSetMethodName());
            }
        } else {
            FilterExtractor extractor = (FilterExtractor) obj;
            pofwriter.writeInt(0, FILTER_EXTRACTOR);
            if (extractor.getAccessor() instanceof InstanceVariableAttributeAccessor) {
                InstanceVariableAttributeAccessor accessor = (InstanceVariableAttributeAccessor) extractor.getAccessor();
                pofwriter.writeInt(1, INSTANCE_ACCESSOR);
                pofwriter.writeString(2, accessor.getAttributeName());
            } else {
                MethodAttributeAccessor accessor = (MethodAttributeAccessor) extractor.getAccessor();
                pofwriter.writeInt(1, METHOD_ACCESSOR);
                pofwriter.writeString(2, accessor.getGetMethodName());
                pofwriter.writeString(3, accessor.getSetMethodName());
            }

        }
        pofwriter.writeRemainder(null);
    }

    public ClassLoader getContextClassLoader() {
        return loaderReference != null ? (ClassLoader) loaderReference.get() : null;
    }

    public void setContextClassLoader(ClassLoader loader) {
        loaderReference = loader != null ? new WeakReference<ClassLoader>(loader) : null;
    }

}
