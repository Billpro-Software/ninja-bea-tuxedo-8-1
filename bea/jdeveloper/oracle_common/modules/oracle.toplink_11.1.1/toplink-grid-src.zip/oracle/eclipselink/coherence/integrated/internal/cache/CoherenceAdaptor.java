// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

/**
 * <p>
 * <b>Purpose:</b> Coherence 3.5.1 introduced new APIs for acquiring a named cache
 * scoped to a particular application.  This adaptor allows us to access the older APIs.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.2.0)
 */
public class CoherenceAdaptor{
    /**
     * Lookup the Coherence NamedCache for a provided descriptor.
     * 
     * @param descriptor
     * @param session
     *            used to access the default class-loader for the lookup
     * @return
     */
    public NamedCache getNamedCache(ClassDescriptor descriptor, Session session){
        return CacheFactory.getCache(CoherenceCacheHelper.getCacheName(descriptor), session.getPlatform().getConversionManager().getLoader());
    }


}
