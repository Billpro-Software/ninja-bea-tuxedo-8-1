var LocaleSymbols_da_DK = new LocaleSymbols({
DayNames:["s\xf8ndag", "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "l\xf8rdag"], 
DayAbbreviations:["s\xf8", "ma", "ti", "on", "to", "fr", "l\xf8"], 
DateTimeElements:["2", "4"], 
MonthNames:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thaniah", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"], 
DateTimePatterns:["HH:mm:ss z", "HH:mm:ss z", "HH:mm:ss", "HH:mm", "d. MMMM yyyy", "d. MMMM yyyy", "yyyy-MM-dd", "yy-MM-dd", "{1} {0}"], 
NumberElements:[",", ".", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
AmPmMarkers:["AM", "PM"], 
Eras:["BH", ""], 
MonthAbbreviations:["Muharram", "Safar", "Rabi\x27 Awwal", "Rabi\x27 Thani", "Jamada El Oula", "Jamada El Thani", "Rajab", "Sha\x27Ban", "Ramadan", "Shawwal", "Thoul Ki\x27Dah", "Thoul Hijjah"]
});
