/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemSortChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    jramanat    08/02/05 - jramanat_item_sort_common
    jramanat    08/02/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemSortChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.dataSource.common;

import oracle.dss.selection.sortWrapper.ItemSortWrapper;

/**
 * Informs listeners of changes to one or more <code>ItemSortWrapper</code> objects.
 * This event is fired <I>before</I> the <code>DataChangedEvent</code>.
 * The <code>ItemSortChangedEvent</code> cannot be consumed.
 *
 * @status New
*/
public class ItemSortChangedEvent extends ItemSortEvent {
  /**
   * Constructs the event.
   * 
   * @param source      The source of the event, that is, a reference to the
   *                    object that fired the event.
   * @param sorts  A list of the <code>ItemSortWrapper</code> objects that
   *                    changed.
   *
   * @status New
   */
  public ItemSortChangedEvent(Object source, ItemSortWrapper[] sorts) {
      super(source, sorts, false);
  }    
  
  /**
   * Constructs the event.
   * 
   * @param source      The source of the event, that is, a reference to the
   *                    object that fired the event.
   * @param sorts  A list of the <code>ItemSortWrapper</code> objects that
   *                    changed.
   * @param removed     Were these sorts removed?
   *
   * @status New
   */
  public ItemSortChangedEvent(Object source, ItemSortWrapper[] sorts, boolean removed) {
      super(source, sorts, removed);
  }        
}
