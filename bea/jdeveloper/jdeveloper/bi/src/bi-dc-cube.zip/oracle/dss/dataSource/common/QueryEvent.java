/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Base class for all Query events
 *
 * @status Documented
 */
public abstract class QueryEvent extends java.util.EventObject implements Cloneable
{
    /**
     * Constructs the event.
     * 
     * @param source   The source of the event, that is, the object that fired
     *                 the event.
     *
     * @status Documented
     */
    public QueryEvent(Object source) {
        super(source);
/*        if (source instanceof Query)
        {
            m_id = ((Query)source).getID();
        }*/
    }
    
    /**
     * Clones the event.
     * Note this assumes that cloning event subclasses by a member is OK.
     *
     * @return The cloned event
     *
     * @throws CloneNotSupportedException  If there is a problem copying
     *                                     the event.
     * @status Documented
     */
    public Object clone() throws CloneNotSupportedException {
        //try {
            return super.clone();
        //}
        //catch (CloneNotSupportedException e) {
            //e.printStackTrace();
        //}
    }
    
    /**
     * @hidden
     * Override
     */
    public String toString() {
        return getClass().getName() + "[source=" + source.getClass().getName() + "]";
    }
    
    /**
     * @hidden
     * Set if this was the last event
     *
     * @param last <code>true</code> if last event
     */
    public void setLastEvent(boolean last) {
        m_lastEvent = last;
    }
    
    /**
     * @hidden
     * Determine if this was the last event
     *
     * @return was this the last event?
     */
    public boolean isLastEvent() {
        return m_lastEvent;
    }
    
    
    // Allow setting of the source to reflect client side
    void setSource(Query s) {
        source = s;
    }


    /** 
     * @hidden
     * Consume the event so that action will not be taken by the event source
     */
    public void consume() {
        consumed = true;
    }

    /**
     * @hidden
     * Has the event been consumed?
     */
    public boolean isConsumed() {
        return consumed;
    }
    
    /**
     * @hidden
     * @serial Actually perform action signaled by the event?
     */
    protected boolean consumed = false;        
    
    /**
     * @hidden
     * @serial Was this the last event for this component?
     */
    protected boolean m_lastEvent = false;
 
}
