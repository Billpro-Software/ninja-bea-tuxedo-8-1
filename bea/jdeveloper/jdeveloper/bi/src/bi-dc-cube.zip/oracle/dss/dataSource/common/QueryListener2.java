/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryListener2.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/27/05 - 
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     08/12/05 - 
    bmoroze     07/19/05 - bmoroze_bicommon050719_2
    bmoroze     07/19/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryListener2.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;
import oracle.dss.util.PollingRequiredEvent;

/**
 * Extended QueryListener interface methods
 * 
 * @status New
 */
public interface QueryListener2 extends QueryListener
{
    /**
     * Responds when a data filter change has been executed.
     * This event is fired after the data filter change executes.
     * This event cannot be consumed.
     *
     * @param e DataFilterChangedEvent
     *
     * @status new
     */
    public void dataFilterChanged(DataFilterChangedEvent e);
    
    /**
     * Responds when a data filter change has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     *
     * @param e DataFilterChangingEvent
     *
     * @status New
     */
    public void dataFilterChanging(DataFilterChangingEvent e);    
    
    /**
     * Fired when the query requires a caller to manually poll
     * via the getStatus() method to obtain results.
     * 
     * @param e PollingRequiredEvent
     * 
     * @status New
     */
    public void queryPollingRequired(PollingRequiredEvent e);
    
    /**
     * Fired when a column sort change has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     * 
     * @param e ColumnSortChangingEvent
     * 
     * @status New
     */
    public void columnSortChanging(ColumnSortChangingEvent e);
    
    /**
     * Fired when a column sort change has been executed.
     * This event is fired after the sort change executes.
     * This event cannot be consumed.
     * 
     * @param e ColumnSortChangedEvent
     * 
     * @status New
     */
    public void columnSortChanged(ColumnSortChangedEvent e);
    
    /**
     * Fired when a item sort change has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     * 
     * @param e ItemSortChangingEvent
     * 
     * @status New
     */
    public void itemSortChanging(ItemSortChangingEvent e);
    
    /**
     * Fired when a item sort change has been executed.
     * This event is fired after the sort change executes.
     * This event cannot be consumed.
     * 
     * @param e ItemSortChangedEvent
     * 
     * @status New
     */
    public void itemSortChanged(ItemSortChangedEvent e);    
    
    /**
     * Fired when a item drill has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     * 
     * @param e ItemDrillRequestingEvent
     * 
     * @status New
     */
    public void itemDrillRequesting(ItemDrillRequestingEvent e);
    
    /**
     * Fired when a item drill has been executed.
     * This event is fired after the drill change executes.
     * This event cannot be consumed.
     * 
     * @param e ItemDrillRequestedEvent
     * 
     * @status New
     */
    public void itemDrillRequested(ItemDrillRequestedEvent e);        
}
