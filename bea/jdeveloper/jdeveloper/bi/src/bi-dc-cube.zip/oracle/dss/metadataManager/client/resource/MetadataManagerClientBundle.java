/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.client.resource;

// Imports
import java.util.ListResourceBundle;

/**
 * @hidden
 * @status hidden
 */
public class MetadataManagerClientBundle extends ListResourceBundle
{
    // MetadataManager client messages have been assigned a range from
    // DVT-10100 to DVT-10199.
    // MetadataManager Client messages start at DVT-10100
    public static final String EXC_SET_CONNECTION_FAILURE   = "10100";
    public static final String EXC_HANDLER_FAILURE          = "10101";
    public static final String EXC_NO_BISESSION             = "10105";
    public static final String EXC_ILLEGAL_PROPERTY         = "10107";
    public static final String EXC_CANNOT_DISCONNECT        = "10108";
    public static final String EXC_CANNOT_FREE_CONNECTION   = "10109";
    public static final String EXC_NO_JDBC_CONNECTION       = "10110";
    
    static final Object[][] sMessages =  {
        /**
         * @error DVT-10100 Cannot connect to the database. (Reason: See error DVT-xxxxx)
         * @cause There are a variety of possible reasons why the connection was not made.
         * @action Check the cause and action text for the DVT error message that is specified after "Reason:".
         * @status reviewed
         */
        { EXC_SET_CONNECTION_FAILURE, "Cannot connect to the database. (Reason: See error {0})" },
        /**
         * @error DVT-10101 Handler fails to handle <code>UserObject</code>.
         * @cause A failed attempt was made to bind or look up an object whose state could not be set or retrieved.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_HANDLER_FAILURE, "Handler fails to handle UserObject." },
        /**
         * @error DVT-10105 <code>BISession</code> is not specified.
         * @cause An instance of <code>BISession</code> was not set on the <code>MetadataManager</code> object.
         * @action Set a <code>BISession</code> on the <code>MetadataManager</code> object, using the <code>setSession</code> method.
         *
         * @status documented
         */
        { EXC_NO_BISESSION, "BISession is not specified." },
        /**
         * @error DVT-10107 User cannot set the specified property: {0}.
         * @cause An attempt was made to set a property other than <code>Label</code> on an <code>MDObject</code>.
         * @action Ensure that only the <code>Label</code> property is set on the <code>MDObject</code>.
         * @status documented
         */
        { EXC_ILLEGAL_PROPERTY, "User cannot set the specified property: {0}."},
        /**
         * @error DVT-10108 MetadataManager cannot disconnect the connection.
         * @cause MetadataManager could not disconnect the connection.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_CANNOT_DISCONNECT, "MetadataManager cannot disconnect the connection." },
        /**
         * @error DVT-10109 MetadataManager cannot free the connection.
         * @cause The <code>MetadataManager</code> could not release the connection.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_CANNOT_FREE_CONNECTION, "MetadataManager cannot free the connection." },
        /**
         * @error DVT-10110 MetadataManager cannot retrieve the OracleConnection.
         * @cause The <code>MetadataManager</code> could not retrieve the OracleConnection.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_NO_JDBC_CONNECTION, "MetadataManager cannot retrieve the OracleConnection." }
    };

   /**
    * Return the string resource table.
    *
    * @status protected
    */
    protected Object[][] getContents() {
        return sMessages;
    }
}