/*
 * MDObjectHyperComboRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

 package oracle.dss.datautil.gui.hierLevel;
 
 import java.awt.Component;
 
 import javax.swing.JComponent;
 import javax.swing.JList;
 
 import oracle.dss.metadataManager.common.MDObject;
 import oracle.dss.metadataManager.common.MM;
 
 import oracle.dss.datautil.gui.ComponentContext;
 import oracle.dss.datautil.gui.Utils;
 
 /**
  * @hidden
  * Specialized HyperComboRenderer for rendering MDObjects based upon
  * the given display label type.
  */
 public class MDObjectHyperComboRenderer extends HyperComboRenderer {
    // Holds the current display label type.
    private String m_strDisplayLabelType;
    // Holds the current ComponentContext.
    private ComponentContext m_componentContext;
    // Holds the text for the text field portion of the combo box.
    private String m_strFieldText;
     
    /** 
     * @hidden
     * Constructor that takes the desired display label type.
     * @param hyperLinkCombo       A reference to the HyperLinkCombo object.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     *
     * @status new
     */
     public MDObjectHyperComboRenderer(HyperLinkCombo hyperLinkCombo, String strDisplayLabelType) {
         super(hyperLinkCombo);
         // Set the current display label type.
         setDisplayLabelType(strDisplayLabelType);
     } 
     
    /**
     * @hidden
     * Constructor that takes the ComponentContext.
     * @param componentContext  A ComponentContext that identifies the type of label
     *                             that you want.
     *
     * @status new
     */
     public MDObjectHyperComboRenderer(HyperLinkCombo hyperLinkCombo, ComponentContext componentContext) {
         super(hyperLinkCombo);
        // Set the current display label type.
        setComponentContext(componentContext);
     } 
     
    /** 
     * @hidden
     * Constructor that takes the desired display label type.
     * @param hyperLinkCombo       A reference to the HyperLinkCombo object.
     *
     * @status hidden
     */
     public MDObjectHyperComboRenderer(HyperLinkCombo hyperLinkCombo) {
         this(hyperLinkCombo, (String)null);
     }
     
    /**
     * @hidden
     * Sets the desired display label type.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * 
     * @status hidden
     */
     public void setDisplayLabelType(String strDisplayLabelType) {
         m_strDisplayLabelType = strDisplayLabelType;
     }
     
    /**
     * @hidden
     * Sets the desired ComponentContext.
     * @param componentContext  The ComponentContext that identifies the type of label
     *                             that you want.
     *
     * @status new
     */
    public void setComponentContext(ComponentContext componentContext) {
        m_componentContext = componentContext;
    }
    
    /*
     * @hidden
     * Sets the text used in the text field portion of the combo box.
     * @param strFieldText The text used in the text field.
     * @status new
     */
    public void setFieldText(String strFieldText) {
        m_strFieldText = strFieldText;
        JComponent component = getHyperCombo();
        if ( (component != null) && (component instanceof JComponent) ) {
            ((JComponent)component).revalidate();
        }
    }
    
    /**
     * @hidden
     * Overrides the default implementation of this method from the superclass such that the text
     * is set based upon the appropriate display label type for the MDObject.
     *
     * @status Hidden
     */
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);        
        String strText = null;
        if ( (index == -1) && (m_strFieldText != null) ) {
            strText = m_strFieldText;
        }
        else if (m_strDisplayLabelType != null) {
            strText = Utils.toString(value, m_strDisplayLabelType);    
        }
        else {
            strText = Utils.toString(value, m_componentContext);
        }
        if (strText != null) {
            setText(strText);
        }
        return renderer;
    }
}