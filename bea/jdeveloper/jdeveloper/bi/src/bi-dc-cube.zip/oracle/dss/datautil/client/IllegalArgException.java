/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.client;

/**
 * Thrown if the caller passes in a bad argument to the DataUtil API.
 *
 * @status Documented
 */
public class IllegalArgException extends DataUtilException
    {
    /**
     * @hidden
     *
     * @serial Illegal argument number
     */
    protected int m_nArgument = 0;

    /**
     * @hidden
     *
     * @serial Illegal argument value
     * Note throwers of this exception must make sure that the value they
     * pass can be serialized!
     */
    protected Object m_objArgument = null;

    /**
     * @hidden
     *
     * Constructor.
     *
     * @param strErrorCode A <code>String</code> that represents the error code
     *                     that is the key used to look up the associated
     *                     error string in the resource bundle.
     *
     *                     If the error associated with the error code is not found,
     *                     getMessage() will return the original error code.
     * @param nArgument    Argument number that was illegal, starting with 1.
     * @param objArgument  Argument value that was illegal.
     *
     * @status hidden
     */
    public IllegalArgException (String strErrorCode, int nArgument, Object objArgument)
        {
        super (strErrorCode, null);
        m_nArgument = nArgument;
        m_objArgument = objArgument;
        }

    /**
     * Retrieves the illegal argument number.
     *
     * @return The illegal argument number.
     *
     * @status Documented
     */
    public int getIllegalArgNumber()
        {
        return m_nArgument;
        }

    /**
     * Retrieves the illegal argument value.
     *
     * @return The illegal argument value.
     *
     * @status Documented
     */
    public Object getIllegalArgValue()
        {
        return m_objArgument;
        }

    /**
     * Retrieves this exception's message.
     *
     * @status hidden
     * @hidden
     */
    public String getMessage()
        {
        return super.getMessage() + ": Argument " + m_nArgument +
            " with value " + m_objArgument;
        }
    }