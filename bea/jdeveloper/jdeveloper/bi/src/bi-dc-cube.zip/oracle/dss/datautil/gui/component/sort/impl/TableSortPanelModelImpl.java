/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/impl/TableSortPanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.sort.impl;

import java.util.Vector;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.sort.TableSortPanelModel;
import oracle.dss.datautil.gui.component.sort.resource.SortBundle;
import oracle.dss.datautil.provider.BIProvider;
import oracle.dss.datautil.provider.MetadataProvider;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.util.ColumnSortInfo;
import oracle.dss.util.DataDirector;
import oracle.dss.util.gui.component.ComponentNode;

/**
 * @hidden
 *
 * <pre>
 * <code>TableSortPanelModelImpl</code>
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   04/08/08 - 
 *
 */
public class TableSortPanelModelImpl implements TableSortPanelModel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  private static final String RESOURCE_BUNDLE = "oracle.dss.datautil.gui.component.sort.resource.SortBundle";

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  private ComponentContext m_componentContext = null;
  private DataDirector m_dataDirector = null;
  private MetadataProvider m_metadataProvider = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that takes a <code>ComponentContext</code>
   * 
   * @param context The <code>ComponentContext</code>
   */
  public TableSortPanelModelImpl (ComponentContext context) {
    setComponentContext (context);
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the <code>ComponentContext</code> to use.
   * 
   * @param context The <code>ComponentContext</code>
   */
  public void setComponentContext (ComponentContext context) {
    m_componentContext = context;
    BIProvider provider = getComponentContext().getBIProvider();
    m_dataDirector = provider.getDataDirector();
    m_metadataProvider = provider.makeMetadataProvider();
  }

  /**
   * Retrieves the <code>ComponentContext</code> used.
   * 
   * @return The <code>ComponentContext</code>
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }
  
  // javadoc inherited from interface
  public String getMode() {
    return TABLE_MODE;
  }
  
  // javadoc inherited from interface
  public ColumnSortInfo[] getColumnSorts() {
    try {
      return m_dataDirector.getColumnSorts();
    }
    catch (Exception e) {
      getComponentContext().getErrorHandler().error(e, getClass().getName(), "getColumnSorts");
    }
    return null;
  }

  // javadoc inherited from interface
  public void setColumnSorts(ColumnSortInfo[] sorts) {
    try {
      m_dataDirector.setColumnSorts(sorts);
    }
    catch (Exception e) {
      getComponentContext().getErrorHandler().error(e, getClass().getName(), "setColumnSorts");
    }
  }

  public Vector getSortColumns() {
    Vector v = m_metadataProvider.getItemObjects(true, true);
    Vector items = new Vector();
    
    for (int i = 0; i < v.size(); i++) {
      MDObject object = (MDObject)v.get(i);
      ComponentNode context = new ComponentNode(object.toString(getComponentContext().getDisplayLabelType()));
      context.setValue(object.getUniqueID());
      items.add(context);
    }

    return items;
  }

  public Vector getDirections(String sortItem) {
    Vector directions = new Vector();
    ComponentNode cn1 = new ComponentNode(getResourceString (SortBundle.SORTPANEL_MODEL_TABLE_ASCENDING));
    cn1.setValue(new Integer(ColumnSortInfo.ASCENDING));
    directions.add(cn1);

    ComponentNode cn2 = new ComponentNode(getResourceString (SortBundle.SORTPANEL_MODEL_TABLE_DESCENDING));
    cn2.setValue(new Integer(ColumnSortInfo.DESCENDING));
    directions.add(cn2);
    return directions;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected String getResourceString (String strKey) {
    if (getComponentContext() != null && getComponentContext().getResourceHandler() != null) {
      return getComponentContext().getResourceHandler().getResourceString (RESOURCE_BUNDLE, strKey);
    }

    return strKey;
  }    
}
