/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.persistence;

import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import java.text.SimpleDateFormat;
import java.text.ParseException;

import javax.naming.Name;

import oracle.dss.util.BIException;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.persistence.PersistableUtilities;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 *
 * A helper class with static utility methods.  
 *
 */
public class PSRUtilities extends PersistableUtilities
{

    // Global environment helper methods

    /**
     * @hidden
     * Returns the value of the specified key in the global environment.
     *
     * @param env -- a <code>Hashtable</code> with the overall environment the circulates in PersistenceManager;
     *               one of the keys in this environment is <code>PSRConstants.GLOBAL_ENVIRONMENT</code>
     *               and that's the environment from which we'll be retrieving values; 
     *               env cannot be <code>null</code>!
     * @param key -- the key (<code>PSRConstants.PERSISTENCE_ERRORHANDLER</code> 
     *               or <code>PSRConstants.PERSISTENCE_LOCALE_HELPER</code>) that indexes into 
     *               the global environment
     * @return Object that's the value for the above key in the global environment. If there is no 
     *                value for that key or that key is not present, null is returned.
     */
    public static Object getFromGlobalEnv(Hashtable env, String key)
    {
        Hashtable _globalEnv = (Hashtable)(env.get(PSRConstants.GLOBAL_ENVIRONMENT));
        if (_globalEnv != null && _globalEnv.containsKey(key))
            return _globalEnv.get(key);
        else
            return null;
    }

    /**
     * @hidden
     * Removes the value of the specified key from the global environment.
     *
     * @param env -- a <code>Hashtable</code> with the overall environment the circulates in PersistenceManager;
     *               one of the keys in this environment is <code>PSRConstants.GLOBAL_ENVIRONMENT</code>
     *               and that's the environment from which we'll be removing values; 
     *               env cannot be <code>null</code>!
     * @param key -- the key (<code>PSRConstants.PERSISTENCE_ERRORHANDLER</code> 
     *               or <code>PSRConstants.PERSISTENCE_LOCALE_HELPER</code>) that indexes into 
     *               the global environment
     * @return Hashtable environment w/o the removed value
     */
    public static Hashtable removeFromGlobalEnv(Hashtable env, String key)
    {
        Hashtable _globalEnv = (Hashtable)(env.get(PSRConstants.GLOBAL_ENVIRONMENT));
        if (_globalEnv != null && _globalEnv.containsKey(key)){
            _globalEnv.remove(key);
            return env;
        }else
            return null;
    }

    /**
     * @hidden
     * Associates the key with the value and sets the pair as part of the global environment.
     *
     * @param env -- a Hashtable with the overall environment that circulates in PersistenceManager;
     *               one of the keys in this environment is <code>PSRConstants.GLOBAL_ENVIRONMENT</code>; 
     *               env cannot be <code>null</code>!
     * @param key -- the key (<code>PSRConstants.PERSISTENCE_ERRORHANDLER</code> 
     *               or <code>PSRConstants.PERSISTENCE_LOCALE_HELPER</code>) that indexes into 
     *               the global environment
     * @param value -- the value for the above key
     *
     */
    public static void putInGlobalEnv(Hashtable env, String key, Object value)
    {
        Hashtable _globalEnv = (Hashtable)(env.get(PSRConstants.GLOBAL_ENVIRONMENT));
        // if there is no global environment already in the overall environment then create it 
        if (_globalEnv == null)
        {
            _globalEnv = new Hashtable();
            env.put(PSRConstants.GLOBAL_ENVIRONMENT, _globalEnv);
        }
        _globalEnv.put(key, value);
    }

    /**
     * @hidden
     * We never want to print errors, log and trace messages if errorHandler is null 
     * to avoid NullPointerException. 
     * This helper method tries to retrieve the ErrorHandler and if it's not there,
     * it creates a default one for now. It is guaranteed to never return null!
     */ 
    public static ErrorHandler getErrorHandler(Hashtable m_env)
    {
        if (m_env != null)
        {
            ErrorHandler _eh = (ErrorHandler)(getFromGlobalEnv(m_env, PSRConstants.PERSISTENCE_ERRORHANDLER));
            if (_eh != null)
                return _eh;
        }
        // if m_env is null, return a DefaultErrorHandler for now.
        else
            return new DefaultErrorHandler();
        // m_env is not null and _eh is null
        putInGlobalEnv(m_env, PSRConstants.PERSISTENCE_ERRORHANDLER, new DefaultErrorHandler());
        return (ErrorHandler)(getFromGlobalEnv(m_env, PSRConstants.PERSISTENCE_ERRORHANDLER));
    }

    // Checking for invalid characters in a name: Helper methods from NameChecker
    
    private static String[] s_invalidNames = new String[]{"/", "\\", "*", "?", ":", "\"", "<", ">", "|"};

    public static boolean isValidPath(Name name)
    {
        if (name != null)
        {
            if (name.size() > 0)
            {
                if (name.get(0) != null && name.get(0).equals(""))
                    return false;
            }
        }
        return true;
    }

    // path name
    public static boolean isValid(Name name)
    {
        if (name != null)
        {
            StringBuffer _buf = new StringBuffer();
            Enumeration _enum = name.getAll();
            while (_enum.hasMoreElements())
                _buf.append(_enum.nextElement().toString());
            return isValid(_buf.toString());
        }
        else
            return false;
    }

    // atomic name
    public static boolean isValid(String name)
    {
        if (name != null)
        {
            for (int i=0; i<s_invalidNames.length; i++)
            {
                if (name.indexOf(s_invalidNames[i]) > -1)
                    return false;
            }
            return true;
        }
        else
            return false;
    }

    public static String getInvalidNames()
    {
        StringBuffer _buf = new StringBuffer();
        for (int i=0; i<s_invalidNames.length-1; i++)
        {
            _buf.append(s_invalidNames[i]);
            _buf.append(", ");
        }
        _buf.append(s_invalidNames[s_invalidNames.length-1]);
        return _buf.toString();
    }    

    public static String getInvalidNames2()
    {
        StringBuffer _buf = new StringBuffer();
        for (int i=1; i<s_invalidNames.length-1; i++)
        {
            _buf.append(s_invalidNames[i]);
            _buf.append(", ");
        }
        _buf.append(s_invalidNames[s_invalidNames.length-1]);
        return _buf.toString();
    }    

    /**
     * @hidden
     * This method takes two hashtables and copies elements from the second table 
     * to the first if they are missing.
     * @param toEnv -- Hashtable to which we copy
     * @param fromEnv -- Hashtable from which we copy
     * 
     */

    public static void mergeToEnvironment(Hashtable toEnv, Hashtable fromEnv)
    {
        if (toEnv != null && fromEnv != null)
        {
            Enumeration _enum = fromEnv.keys();
            while (_enum.hasMoreElements())
            {
                Object _key = _enum.nextElement();
                Object _val = fromEnv.get(_key);
                if (_key != null && _val != null && !toEnv.contains(_key))
                    toEnv.put(_key, _val);
            }
        }
    }

    /**
     * @hidden
     * This methods returns the deepest underlying BIException from the stack.
     * @param excep -- BIException that will be unwrapped
     * @return BIException -- the deepest nested BIException
     */
    public static BIException getRootBIException(BIException excep)
    {
        if(excep.getPreviousException() == null || !(excep.getPreviousException() instanceof BIException))
            return excep;
        else
            return getRootBIException((BIException)excep.getPreviousException());
    }

    /**
    * @hidden
    * This method appends size-str.length() number of characters "value" to the front of the String str.
    * @param str -- String for padding
    * @param value -- the character to pad with
    * @param size -- the desired length of the string. If str is shorter than size, the missing
    *                number of characters will be padded to the front.
    * @return -- the padded string
    */
    public static String padString(String str, char value, int size){
        if (str == null || size < 0)
            return str;
        for (int i = size - str.length(); i-- > 0;){
            str = value + str;
        }
        return str;
    }

   /**
    * @hidden
    * Returns an object based on type and value
    * Used by Import and AbstractFileAdapter
    */
    public static Object createAttributeValue(String type, String value)
    {
        int _type = Integer.parseInt(type);
        switch (_type)
        {
            case PersistableConstants.ExtensibleAttributeTypes.BOOLEAN:
                if (value.equals("true"))
                    return Boolean.TRUE;
                else
                    return Boolean.FALSE;
            case PersistableConstants.ExtensibleAttributeTypes.BYTE:
                return new Byte(value);
            case PersistableConstants.ExtensibleAttributeTypes.CHARACTER:
                return new Character(value.charAt(0));
            case PersistableConstants.ExtensibleAttributeTypes.DATE:
                return getDate(value);
            case PersistableConstants.ExtensibleAttributeTypes.DOUBLE:
                return new Double(value);
            case PersistableConstants.ExtensibleAttributeTypes.FLOAT:
                return new Float(value);
            case PersistableConstants.ExtensibleAttributeTypes.INTEGER:
                return new Integer(value);
            case PersistableConstants.ExtensibleAttributeTypes.LONG:
                return new Long(value);
            case PersistableConstants.ExtensibleAttributeTypes.SHORT:
                return new Short(value);
            default:
                return value;
        }
    }

   /**
    * @hidden
    * Returns a formatted Date object
    */
    public static Date getDate(String date)
    {
        try
        {
            SimpleDateFormat _formatter = new SimpleDateFormat (PSRConstants.DATE_FORMAT);
            return _formatter.parse(date);
        }
        catch (ParseException pe){pe.printStackTrace();}
        return null;
    }

    /**
     * Constructs an unique ID given the driver type and the ID.
     *
     * @param  strDriverType      	The driver type.
     * @param  strID      			The ID.
     *
     * @return The unique ID.
     *
     * @status New
     */
    public static String _makeUniqueID(String strDriverType, String strID) {
   		if ( (strDriverType != null) && (strID != null) ) {
            return new StringBuffer(50).append(strDriverType).append("!").append(strID).toString();
   		}
        return null;
    }

    /**
     * Returns the ID from the given unique ID.
     *
     * @param  strID      	The unique ID.
     *
     * @return The ID.
     *
     * @status New
     */
  	public static String _extractID(String strUniqueID) {
        if (strUniqueID != null) {
            int intIndex = strUniqueID.indexOf("!");
            if (intIndex != -1) {
               return strUniqueID.substring(intIndex+1);
            }
        }  
	    return strUniqueID;
  	}
}
