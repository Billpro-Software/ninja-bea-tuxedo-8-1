/*
 * MeasureListDialog.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.dialog;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;

import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.Locale;

import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;

import javax.swing.tree.TreeSelectionModel;

import oracle.dss.bicontext.BIFilter;

import oracle.dss.datautil.gui.panel.MeasureListPanel;
import oracle.dss.datautil.gui.ResourceCache;
import oracle.dss.datautil.gui.StandardDialog;
import oracle.dss.datautil.gui.Utils;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;

/**
 * Allows a user to select from a list of measures. The <code>MeasureListDialog</code> 
 * wraps the <code>MeasureListPanel</code> in a dialog that the user can invoke.  
 * Use the <code>MeasureListDialog</code> when you want to display a list of measures,
 * allow the user to select one, then have the dialog disappear. 
 *
 * @see oracle.dss.datautil.gui.panel.MeasureListPanel
 * @status documented
 */

public class MeasureListDialog extends StandardDialog {
  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   *
   * The MetadataManager instance
   *
   * @status private
   */
  private MetadataManager m_metadataManager;

  /**
   * @hidden
   *
   * The invoking component. Used to find the parent frame and optionally to center over.
   *
   * @status private
   */
  private Component m_component;

  /**
   * @hidden
   *
   * The MeasureListPanel, which contains the tree of folders and measures.
   *
   * @status private
   */
  private MeasureListPanel m_measureListPanel;

  /**
   * @hidden
   *
   * @status private
   */
  private ResourceCache m_resourceCache = 
  	new ResourceCache("oracle.dss.datautil.gui.resource.DataUtilGUIBundle");

  /**
   * @hidden
   *
   * @status private
   */
  private boolean userTitleAdded = false;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that specifies all arguments for displaying the <code>MeasureListDialog</code>
   * with a dialog as its parent.
   *
   * @param parent The dialog to serve as the parent.
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
   * <code>false</code> if the dialog is not modal.
   * @param filter A <code>BIFilter</code> object that filters the tree model.
   *
   * @status documented
   */
  public MeasureListDialog (Dialog parent, MetadataManager metadataManager,
                              Component component, String strTitle,
                              boolean blnModal, BIFilter filter) {
	  super (parent, null, blnModal, null);
	  initDialog(metadataManager, component, strTitle, blnModal, filter);
  }
  
  /**
   * Constructor that specifies all arguments for displaying the <code>MeasureListDialog</code>
   * with a frame as its parent.
   *
   * @param parent The frame to serve as the parent.
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
   * <code>false</code> if the dialog is not modal.
   * @param filter A <code>BIFilter</code> object that filters the tree model.
   *
   * @status documented
   */
  public MeasureListDialog (Frame parent, MetadataManager metadataManager,
                                Component component, String strTitle,
                                boolean blnModal, BIFilter filter) {
    super (parent, null, blnModal, null);
    initDialog(metadataManager, component, strTitle, blnModal, filter);
  }

  /**
   * A <code>MeasureListDialog</code> should have a parent dialog or frame associated with it to 
   * ensure proper focus handling. Use the constructor that accepts all arguments.
   *
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
   * <code>false</code> if the dialog is not modal.
   * @param filter A <code>BIFilter</code> object that filters the tree model.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by {@link #MeasureListDialog(Dialog, MetadataManager, Component, String, boolean, BIFilter)}
   * or by {@link #MeasureListDialog(Frame, MetadataManager, Component, String, boolean, BIFilter)}.
   */
  public MeasureListDialog (MetadataManager metadataManager,
                              Component component, String strTitle,
                              boolean blnModal, BIFilter filter) {
    this((Frame)null, metadataManager, component, strTitle, blnModal, filter);
  }

  /**
   * A <code>MeasureListDialog</code> should have a parent dialog or frame associated with it to 
   * ensure proper focus handling. Use the constructor that accepts all arguments.
   *
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
   * <code>false</code> if the dialog is not modal.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by {@link #MeasureListDialog(Dialog, MetadataManager, Component, String, boolean, BIFilter)}
   * or by {@link #MeasureListDialog(Frame, MetadataManager, Component, String, boolean, BIFilter)}.
   */
  public MeasureListDialog (MetadataManager metadataManager, Component component,
                              String strTitle, boolean blnModal) {
    this ((Frame)null, metadataManager, component, strTitle, blnModal, null);
  }

  /**
   * A <code>MeasureListDialog</code> should have a parent dialog or frame associated with it to 
   * ensure proper focus handling. Use the constructor that accepts all arguments.
   *
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by {@link #MeasureListDialog(Dialog, MetadataManager, Component, String, boolean, BIFilter)}
   * or by {@link #MeasureListDialog(Frame, MetadataManager, Component, String, boolean, BIFilter)}.
   */
  public MeasureListDialog (MetadataManager metadataManager,
                                Component component, BIFilter filter) {
	  this ((Frame)null, metadataManager, component, null, true, filter);
  }

  /**
   * A <code>MeasureListDialog</code> should have a parent dialog or frame associated with it to 
   * ensure proper focus handling. Use the constructor that accepts all arguments.
   *
   * @param metadataManager A <code>MetadataManager</code> object that is used
   * for populating the tree with folders and measures.
   * @param  component The component over which the <code>MeasureListDialog</code>
   * is centered when it is displayed.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by {@link #MeasureListDialog(Dialog, MetadataManager, Component, String, boolean, BIFilter)}
   * or by {@link #MeasureListDialog(Frame, MetadataManager, Component, String, boolean, BIFilter)}.
   */
  public MeasureListDialog (MetadataManager metadataManager, Component component) {
    this ((Frame)null, metadataManager, component, null, true, null);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the <code>MeasureListPanel</code> object that is used to display
   * the folders and measures.
   *
   * @return The <code>MeasureListPanel</code> object.
   *
   * @status documented
   */
  public MeasureListPanel getMeasureListPanel() {
	  return m_measureListPanel;
  }

  /**
   * Displays this <code>MeasureListDialog</code> so that it is centered over  
   * the component that invokes it, which is often a button.
   * You set the component to invoke this dialog in a constructor of this class.
   *
   * @return A constant that represents OK or CANCEL.
   * The valid constants are:
   * <ul>
   * <li><code>OK</code></li>
   * <li><code>CANCEL</code></li>
   * </ul>
   *
   * @see oracle.dss.datautil.gui.StandardDialog#OK
   * @see oracle.dss.datautil.gui.StandardDialog#CANCEL
   *
   * @status documented
   */
  public int display() {
    return (display(m_component));
  }

  /**
   * Retrieves the <code>String</code> that represents a single measure.
   * If only one measure is selected, then it retrieves that measure.
   * If multiple measures are selected, then it retrieves the first selected
   * measure.  
   *
   * @return The selected measure.
   *
   * @status documented
   */
  public String getSelectedMeasure() {
    return m_measureListPanel.getSelectedMeasure();
  }

  /**
   * Retrieves an array that contains a list of all the selected measures.  
   * If only one measure is selected, then it retrieves an array of size 1 
   * that contains the selected measure.  If multiple measures are selected,
   * then it retrieves an appropriately sized array that contains all the 
   * selected measures.
   *
   * @return The list of the selected measures.
   *
   * @status documented
   */
  public String[] getSelectedMeasures() {
    return m_measureListPanel.getSelectedMeasures();
  }

  /**
   * Specifies the locale that this <code>MeasureListDialog</code> uses.
   *
   * @param locale    The <code>Locale</code> for this
   *                   <code>MeasureListDialog</code>.
   *
   * @status documented
   */
  public void setLocale(Locale locale) {
    super.setLocale(locale);
    if (!m_bSuperCalled)
      return;
    m_resourceCache.setLocale(locale);
    updateResources();
  }

  /**
   * @hidden
   *
   * Notifies this component that it now has a parent component.
   *
   * @status hidden
   */
  public void addNotify() {
    super.addNotify();
    updateResources();
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * This routine allows the <code>MouseListener</code> to perform default
   * processing when the user double clicks on a valid measure.
   *
   * This is necessary to avoid <code>IllegalAccessError</code> exceptions.
   * @status protected
   */
  protected void doOK() {
	  super.doOK();
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * Initialization method called by constructors.
   *
   * @status private
   */
  private void initDialog (MetadataManager metadataManager,
                           Component component, String strTitle,
                           boolean blnModal, BIFilter filter) {
    if (strTitle != null) {
      setTitle(strTitle);
      userTitleAdded = true;
    }

    m_component = component;
    m_measureListPanel = makeMeasureListPanel (metadataManager, filter);
    setContent (m_measureListPanel);
    setSize (StandardDialog.SMALL_DIALOG);
    updateEnabled();
  }

  /**
   *
   * @status private
   */  
  private void updateResources() {
    if (!userTitleAdded)
      setTitle(m_resourceCache.getIntlString("selectMeasure"));
  }
  
  /**
   * @hidden
   *
   * Creates a new <code>MeasureListPanel</code>.
   *
   * @param metadataManager a <code>MetadataManager</code> value that is used
   *        to retrieve metadata.
   * @param biFilter a <code>BIFilter</code> value that is used to filter the
   *        metadata displayed in the list panel.
   *
   * @return The <code>MeasureListPanel</code> object.
   *
   * @status private
   */
  private MeasureListPanel makeMeasureListPanel (MetadataManager metadataManager,
                                                 BIFilter filter) {
    MeasureListPanel measureListPanel =
      new MeasureListPanel(metadataManager, filter);

    measureListPanel.getTree().addTreeSelectionListener (
	    new TreeSelectionListener() {
		    public void valueChanged (TreeSelectionEvent e) {
		      MeasureListDialog.this.updateEnabled();
        }
    });

    // gek 05/08/01 Check for double clicks
    measureListPanel.getTree().addMouseListener (new MouseListener());

    // gek 09/09/03 Fix Bug 2787948: Calculation wizard allows multi-select
    //              when only single select is possible
    //
    //              We should set the default tree selection model to 
    //              only allow the selection of a single item.
    measureListPanel.getTree().getSelectionModel().setSelectionMode (
      TreeSelectionModel.SINGLE_TREE_SELECTION);

    return measureListPanel;
  }

  /**
   * @hidden
   *
   * Determines whether the OK button is enabled.
   *
   * @return A <code>boolean</code> value that is <code>true</code> when the
   *         OK button is enabled, and <code>false<code> otherwise.
   *
   * @status private
   */
  private boolean shouldOKButtonBeEnabled() {
    return (getSelectedMeasure() != null);
  }

  /**
   * @hidden
   *
   * Updates the OK button status.
   *
   * @status private
   */
  private void updateEnabled() {
    setOKButtonEnabled(shouldOKButtonBeEnabled());
  }

  /**
   * @hidden
   *
   * Listener for <code>MeasureListPanel</code> mouse events.
   *
   * @status private
   */
  private class MouseListener extends MouseAdapter {
    /**
     * Processes mouse double click events as if the user has pressed the OK
     * button.
     *
     * @param mouseEvent a <code>MouseEvent</code> that represents the mouse
     *        event to process.
     *
     * @status private?
     */
    public void mouseClicked (MouseEvent mouseEvent) {
      // Check for double clicks
      if (mouseEvent.getClickCount() == 2) {
        // Check to see if OK button is enabled
        if (isOKButtonEnabled()) {
          // Perform default OK processing
          doOK();
        }
      }
    }
  }
}