/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/Size.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component;

/**
 * <pre>
 * This class is designed to mimic the functionality of the 
 * <code>java.awt.Dimension</code> class so that it can be used by components
 * that are not based on Java Swing (for example, rich clients based on ADF).
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.16
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   01/13/06 - Update component context to remove awt references. 
 *    gkellam   01/13/06 - Update component context to remove awt references. 
 */
public class Size extends Object {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * The width size; negative values can be used. 
   *
   * @serial
   * @see #getSize
   * @see #setSize(double, double)
   */
  protected int m_nWidth;

  /**
   * The height size; negative values can be used. 
   *
   * @serial
   * @see #getSize
   * @see #setSize(double, double)
   */
  protected int m_nHeight;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /** 
   * Constructs a <code>Size</code> and initializes it to the specified width 
   * and height.
   *
   * @param nWidth A <code>int</code> representing the specified width. 
   * @param nHeight A <code>int</code> representing the specified height.
   * 
   * @status new
   */
  public Size (int nWidth, int nHeight) {
    m_nWidth = nWidth;
    m_nHeight = nHeight;
  }

  /** 
   * Constructs a <code>Size</code> with a width of zero and a height of zero.
   * 
   * @status new
   */
  public Size() {
    this (0, 0);
  }

  /** 
   * Constructs a <code>Size</code> whose width and height are the same 
   * as for the specified <code>size</code>. 
   *
   * @param size A <code>Size</code> used to initialize this instance.
   */
  public Size (Size size) {
    this (size.m_nWidth, size.m_nHeight);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Returns the width of this size in double precision.
   * 
   * @return <code>double</code> which represents the width of this size 
   *         in double precision.
   *         
   * @status new        
   */
  public double getWidth() {
    return m_nWidth;
  }

  /**
   * Returns the height of this size in double precision.
   * 
   * @return <code>double</code> which represents the height of this size 
   *         in double precision.
   *         
   * @status new        
   */
  public double getHeight() {
    return m_nHeight;
  }

  /**
   * Sets the size of this <code>Size</code> object to
   * the specified width and height in double precision.
   * 
   * Note that if <code>width</code> or <code>height</code>
   * are larger than <code>Integer.MAX_VALUE</code>, they will
   * be reset to <code>Integer.MAX_VALUE</code>.
   *
   * @param dWidth A <code>int</code> which represents the new width for the 
   *        <code>Size</code> object.
   * @param dHeight A <code>int</code> which represents the new height for 
   *        the <code>Size</code> object.
   * 
   * @status new
   */
  public void setSize (double dWidth, double dHeight) {
    m_nWidth = (int) Math.ceil (dWidth);
    m_nHeight = (int) Math.ceil (dHeight);
  }

  /**
   * Creates a new <code>Size</code> based on the size of this 
   * <code>Size</code> object.
   *
   * @return <code>Size</code> which represesnts the size of this size, 
   *         a new instance of <code>Size</code> with the same width and height
   * 
   * @status new
   */
  public Size getSize() {
    return new Size (m_nWidth, m_nHeight);
  }	

  /**
   * Sets the size of this <code>Size</code> object to the specified size.
   * 
   * @param size A <code>Size</code> representing the new size for 
   *        this <code>Size</code> object.
   * 
   * @status new
   */
  public void setSize (Size size) {
    setSize ((int)size.m_nWidth, (int)size.m_nHeight);
  }	

  /**
   * Sets the size of this <code>Size</code> object to the specified 
   * width and height.
   *
   * @param nWidth A <code>int</code> which represents the new width for this 
   *        <code>Size</code> object.
   * @param nHeight A <code>int</code> which represents the new height for this 
   *        <code>Size</code> object.
   * 
   * @status new 
   */
  public void setSize (int nWidth, int nHeight) {
    m_nWidth = nWidth;
    m_nHeight = nHeight;
  }	

  /**
   * Checks whether two <code>Size</code> objects have equal values.
   * 
   * @param object A <code>Object</code> which represents the object to compare.
   * 
   * @return <code>boolean</code> which is <code>true</code> if the objects have
   *         equal values and <code>false</code> otherwise.
   * 
   * @status new
   */
  public boolean equals (Object object) {
    if (object instanceof Size) {
      Size size = (Size)object;
      return (m_nWidth == size.m_nWidth) && (m_nHeight == size.m_nHeight);
    }

    return false;
  }

  /////////////////////
  //
  // Protected Methods  
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods  
  //
  /////////////////////

}