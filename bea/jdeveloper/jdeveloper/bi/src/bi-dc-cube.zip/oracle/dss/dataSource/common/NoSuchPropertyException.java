/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if a property is not found when using XML persistence.
 *
 * @status Documented
 */
public class NoSuchPropertyException extends QueryRuntimeException
{
    /**
     * @serial Property name that was missing
     */
    private String m_property = null;
    
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public NoSuchPropertyException(String s, String property, Throwable e)
    {
        super(s, e);
        
        m_property = property;
    }
    
    
    /**
     * Retrieves this exception's message.
     *
     * @return The exception's message.
     *
     * @status Documented
     */
    public String getMessage()
    {
        return super.getMessage() + ": Property: " + getProperty();
    }
    
    /**
     * Retrieves the missing property's name.
     *
     * @return The property name.
     *
     * @status Documented
     */
    public String getProperty()
    {
        return m_property;
    }
}