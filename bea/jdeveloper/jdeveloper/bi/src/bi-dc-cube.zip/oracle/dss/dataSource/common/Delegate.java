/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/Delegate.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     11/01/06 - Move files back to oracle.dss.util
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/13/05 - bmoroze_fix_build_15
    bmoroze     06/13/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/Delegate.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
    
/**
 * @hidden
 */
public interface Delegate extends DataDirector
{
    public void setWrapper(DataDirectorImpl wrapper);
    public DataDirectorImpl getWrapper();
    public DataAccess getDataAccess(DataDirector dd);
}