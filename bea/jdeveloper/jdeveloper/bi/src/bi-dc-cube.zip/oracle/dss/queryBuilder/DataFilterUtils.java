/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFilterUtils.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.queryBuilder;

import java.awt.Component;

import javax.swing.ComboBoxEditor;
import javax.swing.JComboBox;
import javax.swing.JTextField;

import oracle.dss.datautil.gui.OperatorDisplay;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;

/**
 * <pre>
 * <code>DataFilterUtils</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   05/27/08 - 
 *    gkellam   03/21/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   07/29/07 - Add getCurrentItem support for RangeDataFilter.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/15/07 - Put strings in resource files.
 *    gkellam   05/13/07 - Addition numeric class checks.
 *    gkellam   05/11/07 - Tweaks for TopBottomDataFilter.
 *    gkellam   05/03/07 - Fix Bug 6025401 - QueryBuilder: Able to get an
 *                         erroneous filter to be displayed.
 *    gkellam   03/02/07 - Provide more control over member formatting.
 *    gkellam   03/02/07 - Provide ability to retrieve unformatted labels.
 *    gkellam   02/28/07 - Tweak Parameter string generation.
 * 
 */
public class DataFilterUtils {

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public static MDItem getCurrentItem (BaseDataFilter baseDataFilter, 
                                       ComponentContext context) {
    MDItem mdItem = null;
    Object object = null; 

    if (baseDataFilter instanceof DataFilter) {
      object = 
        QBUtils.getObject (((DataFilter)baseDataFilter).getItem(), context);
    }
    else if (baseDataFilter instanceof TopBottomDataFilter) {
      object = 
        QBUtils.getObject (((TopBottomDataFilter)baseDataFilter).getItem(), context);
    }
    else if (baseDataFilter instanceof RangeDataFilter) {
      object = 
        QBUtils.getObject (((RangeDataFilter)baseDataFilter).getItem(), context);
    }

    if (object instanceof MDItem) {
      mdItem = (MDItem)object;
    }

    return mdItem;
  }

  public static OperatorDisplay getCurrentOperator (OperatorDisplay[] operators, 
                                                    BaseDataFilter dataFilter) {
    
    int nOperator = -1;

    if (operators != null) {
      if (dataFilter instanceof DataFilter) {
        nOperator = ((DataFilter)dataFilter).getCmpOperator();
      }
      else if (dataFilter instanceof TopBottomDataFilter) {
        nOperator = ((TopBottomDataFilter)dataFilter).getOperator();
      }
      else if (dataFilter instanceof RangeDataFilter) {
        nOperator = ((RangeDataFilter)dataFilter).getOperator();
      }

      int nSymbol;
      
      for (int nIndex = 0; nIndex < operators.length; nIndex++) {
        try {
          nSymbol = Integer.parseInt (operators [nIndex].getSymbol());

          if (nSymbol == nOperator) {
            return operators [nIndex];
          }
        }

        catch (NumberFormatException numberFormatException) {
        }
      }
    }

    return null;
  }

  public static String getCurrentMembers (BaseDataFilter dataFilter, ComponentContext componentContext, 
                                          boolean bMembersOnly, boolean bUnformatted) {
    String strCurrentMembers = null;

    if (dataFilter instanceof BaseDataFilter) {

      DataFilterItemsTreeNode dataFilterItemsTreeNode = 
        new DataFilterItemsTreeNode (componentContext);
      
      strCurrentMembers = 
        dataFilterItemsTreeNode.getLabel (dataFilter, componentContext, bMembersOnly, bUnformatted);
      
      if (strCurrentMembers == null) {
        strCurrentMembers = 
          QBUtils.getDelimitedString(((DataFilter)dataFilter).getCmpValues(), ",");
      }
    }

    return strCurrentMembers;
  }

  public static String getCurrentMembers (BaseDataFilter dataFilter, ComponentContext componentContext) {
    return getCurrentMembers (dataFilter, componentContext, true, true);
  }

  public static void setSelectedItem (JComboBox jComboBox, Object object) {
    if (jComboBox != null) {
      if (object == null) {
        jComboBox.setSelectedIndex (0);
      }
      else {
        jComboBox.setSelectedItem (object);
      }
    }
  }

  public static void setCurrentMembers (JComboBox jComboBox, String strText) {
    if (jComboBox != null) {
      ComboBoxEditor editor = jComboBox.getEditor();
      
      if (editor != null) {
        Component editorComponent = editor.getEditorComponent();
        
        if (editorComponent instanceof JTextField) {
          ((JTextField)editorComponent).setText (strText);
        }
      }
    }
  }

  public static MDItem getMDItem (JComboBox jComboBox) {
    MDObject mdObject = getMDObject (jComboBox);
    
    return (mdObject instanceof MDItem) ? (MDItem)mdObject : null;
  }

  public static MDObject getMDObject (JComboBox jComboBox) {
    if (jComboBox != null) {
      Object object = jComboBox.getSelectedItem();
      
      if (object instanceof MDObject) {
        return ((MDObject)object);
      }
    }

    return null;
  }

  public static String getItemId (JComboBox jComboBox) {
    if (jComboBox != null) {
      MDObject mdObject = getMDObject (jComboBox);
      
      if (mdObject != null) {
        return (mdObject).getUniqueID();
      }
    }

    return null;
  }

  public static String getItemDatatype (JComboBox jComboBox) {
    if (jComboBox != null) {
      Object object = jComboBox.getSelectedItem();
      
      if (object instanceof MDItem) {
        return ((MDItem)object).getDatatype();
      }
    }
    return null;
  }

  public static String getItemFormatMask (JComboBox jComboBox) {
    if (jComboBox != null) {
      Object object = jComboBox.getSelectedItem();
      
      if (object instanceof MDItem) {
        return ((MDItem)object).getFormatMask();
      }
    }

    return null;
  }

  public static int getOperatorId (JComboBox jComboBox) {
    if (jComboBox != null) {
      Object object = jComboBox.getSelectedItem();
      
      if (object instanceof OperatorDisplay) {
        String strSymbol = ((OperatorDisplay)object).getSymbol();
        
        if (strSymbol != null) {
          return Integer.parseInt (strSymbol);
        }
      }
    }
    return DataFilter.OP_EQUAL;
  }

  public static Class getClass (MDItem mdItem) {
    Class className = null;

    if (mdItem != null) {
      boolean bIsNumeric = false;

      String strDataType = mdItem.getDatatype();

      if (MM.INTEGER.equals (strDataType) ||
          MM.DOUBLE.equals (strDataType)  ||
          MM.SHORT.equals (strDataType)   ||
          MM.LONG.equals (strDataType)   ||
          MM.FLOAT.equals (strDataType)  ) {
        bIsNumeric = true;
      }

      className = (bIsNumeric) ? Number.class : String.class;
    }
    
    return className;
  }
}
