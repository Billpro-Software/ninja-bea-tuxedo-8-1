/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.PixelGrabber;

import javax.swing.JPanel;

import oracle.bali.ewt.LWComponent;
import oracle.bali.ewt.wizard.ImageWizardPage;

/**
 *
 * @hidden
 * The DiscovererColorStrip class adds support for Discoverer's Wizard
 * 3.1 graphic format which stretches as necessary.
 *  @status hidden
 *
 */
public class DiscovererColorStrip extends JPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Top color for the color strip, as defined by the current Discoverer
  // Wizard graphics.
  private static final Color _sTOP_COLOR_DISCOVERER = new Color(0, 0, 255);
  // Bottom color for the color strip, as defined by the current Discoverer
  // Wizard graphics.
  private static final Color _sBOTTOM_COLOR_DISCOVERER = new Color(0, 0, 255);

  // The width of the color strip, as defined by the current Discoverer
  // Wizard graphics.
  private static final int _sSTRIP_WIDTH_DISCOVERER = 76;
  // The width of the wizard image, including the transparent area
  private static final int _sIMAGE_WIDTH_DISCOVERER = 120;
  // The height of the wizard image
  private static final int _sIMAGE_HEIGHT_DISCOVERER = 183;

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  // Image to render within color strip
  private Image m_image = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   *
   * Create a DiscovererColorStrip based on Discoverer's Wizard 3.1 graphic format.
   *
   * @param image a <code>Image</code> value to render within the color strip.
   * @status hidden
   *
   */
  public DiscovererColorStrip (Image image) {
    setImage (image);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Retrieves the preferred size of the color strip panel.
   *
   * @return <code>Dimension</code> value which represents the size of the panel.
   * @status hidden
   *
   */
  public Dimension getPreferredSize() {
    return new Dimension(_sIMAGE_WIDTH_DISCOVERER, _sIMAGE_HEIGHT_DISCOVERER);
  }

  /**
   * @hidden
   *
   * Retrieves the image associated with the color strip.
   *
   * @return <code>Image</code> value which represents the image associated with
   *         the panel.
   * @status hidden
   *
   */
  public Image getImage() {
    return m_image;
  }

  /**
   * @hidden
   *
   * Specifies the image associated with the color strip.
   *
   * @param image a <code>Image</code>value to associate with the color strip.
   * @status hidden   
   *
   */
  public void setImage (Image image) {
    m_image = image;
  }

  /**
   * @hidden
   *
   * Determines whether the specified image is based on Discoverer's Wizard
   * 3.1 graphic format.
   *
   * @param  image a <code>Image</codevalue to verify.
   *
   * @return <code>boolean</code> value which is <code>true</code> when the
   *         image represents a Discoverer's Wizard 3.1 graphic format and
   *         <code>false</code> otherwise.
   * @status hidden
   */
  public static boolean isDiscovererStyle (Image image) {
    // Just bail if we have a null image
    if (image == null)
       return false;

    // Get the width and height of the current image
    int nWidth = image.getWidth(null);
    int nHeight = image.getHeight(null);

    // Verify the correct width and height of the image
    boolean bCorrectSize = nWidth == _sIMAGE_WIDTH_DISCOVERER &&
                          nHeight == _sIMAGE_HEIGHT_DISCOVERER;

    // Return false if the size of the image is incorrect
    if (!bCorrectSize)
      return false;

    // Retrieve the colors used at the top and bottom of the image
    int[] nTopPixel = new int[1];
    int[] nBottomPixel = new int[1];
    PixelGrabber pixelGrabberTopLeft =
      new PixelGrabber(image, 0, 0, 1, 1, nTopPixel, 0, nWidth);

    PixelGrabber pixelGrabberBottomLeft =
      new PixelGrabber(image, 0, nHeight - 1, 1, 1, nBottomPixel, 0, nWidth);

    try {
      pixelGrabberTopLeft.grabPixels();
      pixelGrabberBottomLeft.grabPixels();
    }

    catch (InterruptedException e) {
      return false;
    }

    // Verify that the top and bottom colors are correct
    return (nTopPixel[0] == _sTOP_COLOR_DISCOVERER.getRGB()) &&
           (nBottomPixel[0] == _sBOTTOM_COLOR_DISCOVERER.getRGB());
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   *
   * Paints the ColorStrip.
   *
   * @param graphics a <code>Graphics</code> value to render.
   * @status protected
   *
   */
  protected void paintComponent (Graphics graphics) {
    // This method will only be called if this is a discoverer graphic
    // so you don't have to check
    if (getImage() == null)
      return;

    Dimension dimension = getSize();
    int height = dimension.height/2;
    graphics.setColor (_sTOP_COLOR_DISCOVERER);
    graphics.fillRect (0, 0, _sSTRIP_WIDTH_DISCOVERER, height);

    graphics.setColor (_sBOTTOM_COLOR_DISCOVERER);
    graphics.fillRect (0, height, _sSTRIP_WIDTH_DISCOVERER, height);

    int nImageTop = height - (_sIMAGE_HEIGHT_DISCOVERER/2);

    graphics.drawImage(getImage(), 0, nImageTop, this);
  }
}
