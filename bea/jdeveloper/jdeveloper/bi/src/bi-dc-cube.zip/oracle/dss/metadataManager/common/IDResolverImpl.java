/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import java.util.Hashtable;
import oracle.dss.util.IDResolver;
import oracle.dss.util.persistence.PersistableConstants;

public class IDResolverImpl implements IDResolver
{
    private Hashtable m_ids;    // key is id, value is ""
    
    public IDResolverImpl()
    {
        m_ids = new Hashtable(5);
    }
    
    public String getDependentID(String id)
    {
        if(id != null)
        {
            if(id.startsWith("PERSISTENCE"))
                id = MMUtilities._makeUniqueID(MM.PERSISTENCE, MMUtilities._extractID(id));
            
            if(id.startsWith(MM.PERSISTENCE) && (id.indexOf('-') == -1) && !m_ids.containsKey(id))
                id = PersistableConstants.INVALID_ID;
        }
        return id;
    }
    
    public void setDependentID(String id)
    {
        if(id != null && id.startsWith(MM.PERSISTENCE))
            m_ids.put(id, "");
    }
    
    /**
     * @hidden
     */
    public Hashtable getIDTable()
    {
        return m_ids;
    }

    /**
     * @hidden
     */
    public void setIDTable(Hashtable table)
    {
        m_ids = table;
    }
}