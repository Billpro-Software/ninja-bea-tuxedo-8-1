/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

/**
 * @hidden
 * Generic sorter for tree contents
 */
public class TreeSorter
{
    private DirTreeModel m_model;
    private String[] m_types;
    private boolean m_isAscent;

    /**
     * Constructor used when the order of sort is specified
     * Direction is ascending.
     *
     * @param types order of the sort, based on type (ex: Folder, then Measure, then Dimension)
     *
     * @status New
     */
    public TreeSorter(String[] types)
    {
        this(types, true);
    }

    /**
     * Constructor used when the order of sort and the
     * direction of the sort are both specified
     *
     * @param types order of the sort, based on type (ex: Folder, then Measure, then Dimension)
     * @param isAscent <code>true</code> if ascending order, <code>false</code> if otherwise
     *
     * @status New
     */
    public TreeSorter(String[] types, boolean isAscent)
    {
        m_types = types;
        m_isAscent = isAscent;
    }

    void setModel(DirTreeModel model)
    {
        m_model = model;
    }

   /**
    * Sort the children of the specified object in the specified order
    */
    void sort(Object parent, boolean isAscent)
    {
        int n = m_model.getChildCount(parent);
        int[] indexes = ((SortableModel)m_model).getIndexes(parent);
        int[] oldIndexes = new int[n];
        System.arraycopy(indexes, 0, oldIndexes, 0, n);

        int objIndexes[] = new int[n];
        for (int v=0; v<n; v++)
            objIndexes[v] = 0;
        int objs = 0;

        int[][] _matrix = new int[m_types.length][n];

        int[] _lengths = new int[m_types.length];
        for (int k=0; k<m_types.length; k++)
            _lengths[k] = 0;

        for (int i=0; i<m_types.length; i++)
            for (int j=0; j<n; j++)
                _matrix[i][j] = -1;

        for (int l=0; l<n; l++)
        {
            Object _obj = m_model.getChild(parent, l);
            if (_obj instanceof DirTreeNode)
            {
                DirTreeNode _node = (DirTreeNode)_obj;
                boolean _found = false;
                for (int m=0; m<m_types.length; m++)
                {
                    if (_node.getObjectType().equals(m_types[m]))
                    {
                        _matrix[m][_lengths[m]] = l;
                        _lengths[m]++;
                        _found = true;
                    }
                }

                if (!_found)
                {
                    objIndexes[objs] = l;
                    objs++;
                }
            }
        }

        for (int z=0; z<m_types.length; z++)
            swap(_matrix[z], _lengths[z], parent, isAscent);

        int[] newIndexes = new int[n];

        int _previousLength = 0;
        for (int y=0; y<m_types.length; y++)
        {
            for (int x=0; x<_lengths[y]; x++)
                newIndexes[x+_previousLength] = oldIndexes[_matrix[y][x]];
            _previousLength = _previousLength+_lengths[y];
        }

        for (int z=0; z<objs; z++)
            newIndexes[z+_previousLength] = oldIndexes[objIndexes[z]];

        System.arraycopy(newIndexes, 0, indexes, 0, n);
    }
    
    private void swap(int[] intArray, int length, Object parent, boolean isAscent)
    {
        int n = length;
        for (int i=0; i<n-1; i++)
        {
            int k = i;
            for (int j=i+1; j<n; j++)
            {
                if (isAscent)
                {
                    if (compare(parent, intArray[j], intArray[k]) < 0)
                        k = j;
                }
                else
                {
                    if (compare(parent, intArray[j], intArray[k]) > 0)
                        k = j;
                }
            }
            int tmp = intArray[i];
            intArray[i] = intArray[k];
            intArray[k] = tmp;
        }
    }

    private int compare(Object parent, int index1, int index2)
    {
        Object o1 = m_model.getChild(parent, index1);
        Object o2 = m_model.getChild(parent, index2);
        if (o1 == null && o2 == null)
            return  0;
        else if (o1 == null)
            return -1;
        else if (o2 == null)
            return  1;
        else
        {
            return (o1.toString()).compareTo(o2.toString());
        }
    }

    private int compare(Number o1, Number o2)
    {
        double n1 = o1.doubleValue();
        double n2 = o2.doubleValue();
        if (n1 < n2)
            return -1;
        else if (n1 > n2)
            return 1;
        else
            return 0;
    }

    public int compare(Boolean o1, Boolean o2)
    {
        boolean b1 = o1.booleanValue();
        boolean b2 = o2.booleanValue();
        if (b1 == b2)
            return 0;
        else if (b1)
            return 1;
        else
            return -1;
    }
}



