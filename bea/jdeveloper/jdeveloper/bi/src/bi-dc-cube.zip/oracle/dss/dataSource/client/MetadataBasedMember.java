/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/MetadataBasedMember.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/26/08 - XbranchMerge bmoroze_bug-7353224 from
                           st_jdevadf_drop6_ias
    bmoroze     05/17/06 - 
    jramanat    05/03/06 - 
    bmoroze     02/27/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/MetadataBasedMember.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.client;

import oracle.dss.dataSource.common.CursorUtils;
import oracle.dss.dataSource.common.Query;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.transform.MemberMetadata;
import oracle.dss.util.transform.TransformException;

/**
 * @hidden
 */
public class MetadataBasedMember extends Member
{
    public MetadataBasedMember(Object value, String item, Query query)
    {
        super(value, item, item, query);        
    }
    
    // Handle possible LayerMetadataMap inputs
    protected boolean isLabelType(String type)
    {
        if (type.equals(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME) || type.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL) ||
            type.equals(LayerMetadataMap.LAYER_METADATA_NAME) || type.equals(LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL) ||
            type.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL) || super.isLabelType(type))
            return true;
        return false;
    }
    
    protected String translateType(String type)
    {
        if (type.equals(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME))
            return MetadataMap.METADATA_DISPLAYNAME;
        if (type.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL))
            return MetadataMap.METADATA_LONGLABEL;
        if (type.equals(LayerMetadataMap.LAYER_METADATA_NAME))
            return MetadataMap.METADATA_VALUE;
        if (type.equals(LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL))
            return MetadataMap.METADATA_MEDIUMLABEL;
        if (type.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL))
            return MetadataMap.METADATA_SHORTLABEL;
        return type;
    }
    
    public Object getMetadata(String type) throws TransformException
    {
        if (type.equals(MemberMetadata.LABEL) || isLabelType(type))
        {
            // Use legacy mapping code
            return getExtendedMetadata(type/*LayerMetadataMap.LAYER_METADATA_LONGLABEL*/);
        }
        return super.getMetadata(type);
    }
    
    private Object getExtendedMetadata(String type) throws TransformException
    {
        if (isLabelType(type))
        {
            try
            {
                return CursorUtils.getDBMetadataObject(m_query.getMDObject(MM.UNIQUE_ID, super.getValue(), MM.OBJECT), translateType(type));
            }
            catch (MetadataManagerException e)
            {                
                throw new TransformException(e.getMessage(), e);
            }
        }
        return null;
    }    
}
