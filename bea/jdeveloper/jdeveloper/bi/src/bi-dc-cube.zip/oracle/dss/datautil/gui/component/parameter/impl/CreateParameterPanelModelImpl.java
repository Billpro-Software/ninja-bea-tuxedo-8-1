/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/impl/CreateParameterPanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.parameter.impl;

import java.text.MessageFormat;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.parameter.CreateParameterPanelModel;

import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.parameter.BaseParameter;
import oracle.dss.selection.parameter.ItemValueParameter;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.datautil.gui.Utils;

/**
 * <pre>
 * <code>CreateParameterPanelModelImpl</code>.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   07/19/07 - 
 *    jwtang    06/08/07 - 
 * 
 */
public class CreateParameterPanelModelImpl implements CreateParameterPanelModel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  private static final String RESOURCE_BUNDLE = 
    "oracle.dss.datautil.gui.component.parameter.resource.ParameterBundle";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext = null;
  private boolean m_bFixed = false;
  private ComponentNode m_componentNodeBasedOn = null;
  private BaseParameter m_baseParameter = null;
  private String m_strValueType = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that takes a ComponentContext
   * 
   * @param componentContext The ComponentContext
   */
  public CreateParameterPanelModelImpl (ComponentContext componentContext) {
    setComponentContext (componentContext);
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the ComponentContext that this model is based on
   * 
   * @param componentContext The ComponentContext
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;
  }
  
  public String getValueType() {
    return m_strValueType;
  }
  
  /**
   * Retrieves the ComponentContext that this model is based on
   * 
   * @return The ComponentContext
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }
  
  // javadoc inherited from interface
  public boolean isBasedOnFixed() {
    return m_bFixed;
  }
  
  /**
   * Specifies whether the Item/datatype the Parameter is based is fixed (i.e.
   * can not be changed)
   * 
   * @param bFixed true if the Item/datatype is fixed, false otherwise
   */
  public void setBasedOnFixed (boolean bFixed) {
    m_bFixed = bFixed;
  }

  public void setBasedOn (String strItem, boolean strPrompt) {
    setBasedOn (strItem, strPrompt, null);
  }
  
  // javadoc inherited from interface
  public void setBasedOn (String strItem, boolean strPrompt, Object objDefaultValue) {
    if (m_componentContext != null && m_componentContext.getBIProvider() != null && 
        m_componentContext.getBIProvider().getMetadataManager() != null) {
      
      try {
        MDObject mdObject = 
          m_componentContext.getBIProvider().getMetadataManager().getMDObjectByUniqueID (strItem);
        
        String strLabel = 
          mdObject.toString (m_componentContext.getDisplayLabelType());
        
        m_componentNodeBasedOn = new ComponentNode (strLabel);
        m_componentNodeBasedOn.setValue (strItem);
      
        if (mdObject instanceof MDItem) {
          m_baseParameter = new ItemValueParameter (mdObject.getName(), strItem);
          
          if (strPrompt) {
            m_baseParameter.setPrompt (Utils.makeJavaIdentifier(strLabel, null));
          }

          m_baseParameter.setValidationContext (((MDItem)mdObject).getFormatMask());
          // m_baseParameter.setValueType(((MDItem)obj).getDatatype());
          m_strValueType = ((MDItem)mdObject).getDatatype();
        }

        if (m_baseParameter != null) {
          m_baseParameter.setDefaultValue (objDefaultValue);
        }
        
        return;
      }

      catch (MetadataManagerException metadataManagerException) {
        m_componentContext.getErrorHandler().error (metadataManagerException, 
          getClass().getName(), "setBasedOn");
      }
    }

    m_componentNodeBasedOn = new ComponentNode (strItem);
    m_componentNodeBasedOn.setValue (strItem);
    
    // m_baseParameter = new ItemValueParameter (strItem, strItem);
  }
  
  // javadoc inherited from interface
  public ComponentNode getBasedOn() {
    return m_componentNodeBasedOn;
  }
  
  // javadoc inherited from interface
  public BaseParameter getParameter() {
    return m_baseParameter;
  }
  
  // javadoc inherited from interface
  public String getDefaultName() {  
    if (m_componentNodeBasedOn != null) {
      return MessageFormat.format(getResourceString ("DefaultName"), 
        new String[] {m_componentNodeBasedOn.getName()});
    }

    return null;
  }

  // javadoc inherited from interface
  public void setDataFilter (BaseDataFilter[] baseDataFilters) {
    if (m_baseParameter instanceof ItemValueParameter) {
      //((ItemValueParameter)m_baseParameter).setDataFilter (baseDataFilters);
    }
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  protected String getResourceString (String strKey) {
    if (m_componentContext != null && m_componentContext.getResourceHandler() != null) {
      return m_componentContext.getResourceHandler().getResourceString (RESOURCE_BUNDLE, strKey);
    }
   
    return strKey;
  }  
}