/**
 * JTextAreaExtended.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
  
package oracle.dss.datautil.gui;

import java.awt.event.KeyEvent;

import javax.swing.FocusManager;
import javax.swing.JTextArea;
import javax.swing.text.AttributeSet; 
import javax.swing.text.BadLocationException; 
import javax.swing.text.Document; 
import javax.swing.text.PlainDocument; 

/**
 * @hidden
 * 
 * Provides extended <code>JTextArea</code> functionality.
 * 
 * In particular, this class allows us to limit the number of maximum 
 * characters that the user will be allowed to type.
 *
 * @status hidden
 */
 
public class JTextAreaExtended extends JTextArea {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Specifies the default value for the maximum number of characters allowed.
   *
   * @status private
   */
  private int nMaxChars = 1333; 

  /**
   * @hidden
   * 
   * Java version used to determine if special processing is required.
   *
   * @status private
   */
  protected String JAVA_VERSION_1_4 = "1.4"; 

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   *
   * Default constructor.
   *
   * @status hidden
   */
  public JTextAreaExtended () {
    super();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Specifies the maximum number of characters allowed.
   * 
   * @param nMaxChars A <code>int</code> value used to specify the maximum 
   *        number of characters allowed.
   *
   * @status hidden
   */
  public void setMaxCharacters (int nMaxChars) {
    if (nMaxChars < 0) {
      this.nMaxChars = 0;
    }
    else {
      this.nMaxChars = nMaxChars;
    }
  }

  /**
   * @hidden
   * 
   * Don't allow JTextArea to handle focus so that the tab character
   * moves between components instead of inserting tab characters. 
   * 
   * Note: This only works for JDK 1.3 or earlier.  For JDK 1.4 handling, see
   * processKeyEvent.
   * 
   * @return <code>boolean</code> which is <code>true</code> if managing focus
   *         and <code>false</code> otherwise.
   *         
   * @status hidden
   */
  public boolean isManagingFocus() {
    return false;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////


  /** 
   * @hidden
   * 
   * Overrides <code>processKeyEvent</code> to process events. 
   * 
   * @param keyEvent A <code>KeyEvent</code> to process.
   * 
   * @status hidden
   */
  protected void processKeyEvent (KeyEvent keyEvent) {

    // gek 04/08/04 Fix Bug 3066029 - ADA: Tabbing doesn't work properly in the
    //              description field fo the calc wizard.
    //
    //              Work around focus behavior changes introduced in JDK 1.4.
    //              This allows the user to tab out of the JTextArea instead
    //              of inserting tab characters.
    boolean bTransferFocus = false;
    
    // For JDK 1.4 or greater, perform special tab processing
    if (!isPriorVersion (JAVA_VERSION_1_4)) {
      if ((keyEvent.getKeyCode() == KeyEvent.VK_TAB) && 
           (keyEvent.getID() == KeyEvent.KEY_PRESSED)) {
        bTransferFocus = true;
      }
    }

    if (bTransferFocus) {
      // gek 06/23/04 Fix Bug 3684964 - ADA: CalcBuilder: Step 3 of 3 in 
      //              Wizard has SHIFT+TAB problem

      // Determine whether we should be moving focus forwards or backwards 
      // based on the Shift key.
      if (keyEvent.isShiftDown()) {
        // Move focus to previous component
        if (FocusManager.isFocusManagerEnabled()) {
          FocusManager.getCurrentManager().focusPreviousComponent (this);
        }
      }
      else {      
        // Move focus to next component
        transferFocus(); 
      }    
   
      // Consume the KeyEvent since we are processing it
      keyEvent.consume();
    }
    else {
      // Let the super class handle the KeyEvent
      super.processKeyEvent (keyEvent);
    }
  }

  /**
   * @hidden
   *
   * Creates a default <code>Document</code> model which allows us to override
   * the number of characters allowed.
   *
   * @return <code>Document</code> which represents the default model.
   * 
   * @status hidden
   */
  protected Document createDefaultModel() {
    return new PlainDocument () {

      /**
       * @hidden
       * 
       * Inserts some content into the document.
       * 
       * Inserting content causes a write lock to be held while the
       * actual changes are taking place, followed by notification
       * to the observers on the thread that grabbed the write lock.
       * <p>
       * This method is thread safe, although most Swing methods
       * are not. Please see 
       * <A HREF="http://java.sun.com/products/jfc/swingdoc-archive/threads.html">Threads
       * and Swing</A> for more information.
       *
       * @param nStartingOffset A <code>int</code that represents the starting 
       *        offset >= 0
       * @param strInsert A <code>String</code> that represents the string to 
       *        insert; does nothing with null/empty strings
       * @param attributeSet A <code>AttributeSet</code> that represnt the 
       *        attributes for the inserted content
       *        
       * @throws <code>BadLocationException</code> if the given insert position 
       *         is not a valid position within the document
       *   
       * @status hidden
       */
      public void insertString (int nStartingOffset, String strInsert, 
                      AttributeSet attributeSet) throws BadLocationException {
        if (strInsert == null) {
          return; 
        }

        // Get the length of the text in JTextArea
        int nLength = 0;
          
        if (JTextAreaExtended.this.getText() == null) {
          nLength = 0;
        }
        else {
          nLength = JTextAreaExtended.this.getText().length();
        }

        // Check to see if we have exceeded the maximum number of characters
        if (nLength + strInsert.length() > JTextAreaExtended.this.nMaxChars) {
          // Simply return if the total number of characters is more than 
          // the maximum allowed.
          return;
        }
        else { 
          // Update the text field
          super.insertString (nStartingOffset, strInsert, attributeSet);
        }
      }
    };
  }

  /**
   * @hidden
   * 
   * Determines if the version specified is prior to the running Java version.
   * 
   * @return <code>boolean</code> which is <code>true</code> if the version 
   *         specified is prior to the running Java version or <code>false</code>
   *         otherwise.
   * 
   * @status hidden
   */
  protected boolean isPriorVersion (String strVersion) {
    boolean bIsPriorVersion = false; 
   
    String strJavaVersion = System.getProperty ("java.version");
    if ((strJavaVersion != null) && (strJavaVersion.compareTo (strVersion) < 0)) {
      bIsPriorVersion = true;
    }

    return bIsPriorVersion;
  }
}


