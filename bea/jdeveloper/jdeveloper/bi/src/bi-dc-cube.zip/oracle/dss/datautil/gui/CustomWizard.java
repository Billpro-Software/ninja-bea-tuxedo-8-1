/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;

import javax.swing.JButton;

import oracle.bali.ewt.help.HelpUnavailableException;
import oracle.bali.ewt.help.HelpUtils;

import oracle.bali.ewt.util.WindowUtils;

import oracle.bali.ewt.wizard.ImageWizardPage;
import oracle.bali.ewt.wizard.Wizard;
import oracle.bali.ewt.wizard.WizardPage;

import oracle.bali.share.Assert;

import oracle.dss.datautil.gui.panel.StandardPanel;

import oracle.dss.datautil.Timer;

/**
 * @hidden
 * Extends the BALI <code>Wizard</code> class to provide custom BIBeans
 * functionality.
 *     
 *  Examples:
 *  1) Validate event when the "Previous" button is pressed.
 *  2) Help context ID support for our panels.
 *
 * @status hidden
 */
public class CustomWizard extends Wizard
    {
    //---------------------------------------------------------
    // NON PUBLIC MEMBERS
    //---------------------------------------------------------

    /**
     * Specifies whether all the pages of the wizard must be visited
     * before the Finish button is enabled.
     *
     * @status protected
     */
    protected boolean m_bMustFinish = false;

    /**
     * The wizard size.
     *
     * @status protected
     */
    protected Dimension m_wizardSize = null;

    /**
     * The wizard state.
     *
     * @status protected
     */
    protected int m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;

    //---------------------------------------------------------
    // CONSTRUCTOR
    //---------------------------------------------------------

    /**
     * Constructs a default CustomWizard.
     *
     * @status hidden
     */
    public CustomWizard ()
        {
        super ();
        }

    //---------------------------------------------------------
    // PUBLIC METHODS
    //---------------------------------------------------------

    /**
     * @hidden
     * Indicates whether the user can finish at any time, or must reach the
     * last page before finshing.  By default, returns <code>true</code>.
     *
     * @return <code>true</code> indicates that the user must reach the last
     *         page before finishing; <code>false</code> indicates that the
     *         user can finish at any time.
     *
     * @status hidden
     */
    public boolean getMustFinish ()
        {
        return m_bMustFinish || (getSelectedPage() instanceof CustomWelcomeWizardPage);
        }

    /**
     * @hidden
     * Retrieves the preferred size of the wizard.
     *
     * @return The preferred size of the wizard.
     *
     * @status hidden
     */
    public Dimension getPreferredSize ()
        {
        if (m_wizardSize == null)
            return super.getPreferredSize ();

        return m_wizardSize;
        }

    /**
     * @hidden
     * Retrieves the wizard page for the specified panel ID.
     *
     * @param panelId    The panel ID of the wizard page.
     *
     * @return    The <code>WizardPage</code> object for the specified panel id.
     *
     * @status hidden
     */
    public WizardPage getWizardPage (String panelId)
        {
        Component   panel       = null;
        int         nIndex      = -1;
        WizardPage  wizardPage  = null;

        if (panelId == null)
            return null;

        for (nIndex = 0; nIndex < getPageCount (); nIndex++)
            {
            wizardPage = getPageAt (nIndex);
            if (wizardPage == null)
                continue;

            panel = ((ImageWizardPage) wizardPage).getInteractiveArea ();
            if (panel == null) 
                continue;

            if (panel instanceof StandardPanel)
                {
                if (panelId.equalsIgnoreCase (((StandardPanel) panel).getId ()))
                    return wizardPage;
                }
            }

        return null;
        }

    /**
     * @hidden
     * Retrieves the wizard state.
     *
     * @return The wizard state; one of the constants found in
     *         <code>CustomWizardConst</code> such as CUSTOMWIZARD_PREVIOUS.
     *
     * @see CustomWizard
     *
     * @status hidden
     */
    public int getWizardState ()
        {
        return m_nWizardState;
        }

    /**
     * @hidden
     * Selects the specified wizard page.
     *
     * @param wizardPage   The wizard page to be selected.
     * @param bDoValidate  <code>true</code> if the page is to be validated;
     *                     <code>false</code> if the page is not to be
     *                     validated.
     *
     * @status hidden
     */
    public void selectPage (WizardPage wizardPage, boolean bDoValidate)
        {
        if (wizardPage == null)
            return;

        if (Timer.ON) {
            Timer.getTimer().start("selectPage - wizardPage:" + wizardPage);
        }
            
        super.selectPage (wizardPage, bDoValidate);
        
        if (Timer.ON) {
            Timer.getTimer().stop("selectPage - wizardPage: " + wizardPage);
        }
        }

    /**
     * @hidden
     * Specifies whether the user can finish at any time, or must reach the
     * last page before finshing.  By default, returns <code>true</code>.
     *
     * @param bMustFinish   <code>true</code> if the user must reach the last
     *                      page before finishing; <code>false</code> if the
     *                      user can finish at any time.
     *
     * @status hidden
     */
    public void setMustFinish (boolean bMustFinish)
        {
        m_bMustFinish = bMustFinish;
        }

    /**
     * @hidden
     * Specifies the wizard size.
     *
     * @param wizardSize    The size of the wizard.
     *
     * @status hidden
     */
    public void setWizardSize (Dimension wizardSize)
        {
        m_wizardSize = wizardSize;
        }

    //---------------------------------------------------------
    // NON PUBLIC METHODS
    //---------------------------------------------------------

    /**
     *  Handles the user requesting help.
     *
     *  We currently need to override the BaseWizard doHelp() method so that our
     *  panels (through getInteractiveArea) are returned as the helpComponent
     *  instead of the AccessibleLWComponent container.  This currently only
     *  has to be done when the wizard is run in WIZARD mode and does not affect
     *  TABBED mode.
     *
     *  This is necessary so that we can control how help context IDs are
     *  generated for each of the panels that we add to the Wizard framework.
     *  We currently do this by implementing the HelpContext interface
     *  on DefaultStandardPanel.
     *
     *  When the user requests help, the Bali wizard simply passes our
     *  helpComponent to the DefaultHelpProvider that we have registered with the
     *  wizard framework (for example through QueryBuilder or CalcBuilder).
     *  The DefaultHelpProvider (which implements the HelpProvider interface)
     *  then requests the help context ID from the component if it has
     *  implemented the HelpContext interface or alternatively generates one on
     *  the fly based on the component's class.
     *
     *  The help context ID can then be used to display the appropriate help
     *  topic.
     *
     * @status protected
     */
    protected void doHelp()
        {
        // This code is a slight variation of that found in
        // oracle.bali.ewt.wizard.BaseWizard

        Component helpComponent = null;
        WizardPage selectedPage = getSelectedPage();

        // Try to show help on the currently focused component
        Window window = WindowUtils.getWindow(this);
        if (window != null)
            helpComponent = window.getFocusOwner();

        // But if that fails, or if the focused component
        // is part of the button row...
        if ((helpComponent == null) ||
            // Note: Since with don't have access to the BaseWizards _buttonRow
            //       member, simply check to determine if we got to help pressing
            //       a button
            (helpComponent instanceof JButton) ||

            // Also check if it's a direct child of the wizard,
            // which comes up for tabbed pane of a ReentrantWizard
            (helpComponent.getParent() == this))
            {
            // Then show help on, preferably, the content of the selected
            // page
            if (selectedPage != null)
                {
                helpComponent =
                    ((ImageWizardPage) selectedPage).getInteractiveArea();

                // Can't use getContent() since it returns AccessibleLWComponent
                // container.

                // helpComponent = selectedPage.getContent();
                }
            else
                {
                // Or, in the worst case, the wizard as a whole
                helpComponent = this;
                }
            }

        try
            {
            HelpUtils.showHelp(helpComponent);
            }

        catch (HelpUnavailableException hue)
            {
            if (Assert.DEBUG)
                System.err.println(hue);
            }
        }

    /**
     * @status protected
     */
    protected void resetFocus(WizardPage page) {
      if (page == null)
        return;

      if (!page.getCanAdvance()) {
        Component initialFocus = Utils.getFirstFocusableComponent(page.getContent());
        if (initialFocus != null && initialFocus.isEnabled()) {
          initialFocus.requestFocus();
          return;
        }
      }
      super.resetFocus(page);
    }
          
    /**
     * Handles the user pressing the "Apply" button.
     *
     * @status protected
     */
    protected void doApply()
        {
        if (Timer.ON) {
            Timer.getTimer().start("Apply");
        }
            
        // Mark this as a apply operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_APPLY;

        super.doApply ();

        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Apply");
        }
        }

    /**
     * Handles the user pressing the "Cancel" button.
     *
     * @status protected
     */
    protected void doCancel()
        {
        if (Timer.ON) {
            Timer.getTimer().start("Cancel");
        }
            
        // Mark this as a cancel operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_CANCEL;

        super.doCancel ();

        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Cancel");
        }
        }

    /**
     * Handles the user pressing the "Finish" button.
     *
     * @status protected
     */
    protected void doFinish()
        {
        if (Timer.ON) {
            Timer.getTimer().start("Finish");
        }         
   
        // Mark this as a finish operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_FINISH;

        super.doFinish ();

        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Finish");
        }
        }

    /**
     * Handles the user pressing the "Next" button.
     *
     * @status protected
     */
    protected void doNext ()
        {
        // Mark this as a next operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_NEXT;

        super.doNext ();

        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        }

    /**
     * Handles the user pressing the "Previous" button.
     *
     * @status protected
     */
    protected void doPrevious ()
        {
        WizardPage  previous    = null;

        // Mark this as a previous operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_PREVIOUS;

        // Validate the page up front, so that clients can adjust which
        // page is next in response to the validate event.
        if (validateSelectedPage ())
            {
            previous = getPreviousPage (getSelectedPage ());
            if (previous != null)
                {
                // Don't bother validating _again_
                selectPage (previous, false);
                }
            }

        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        }
    }