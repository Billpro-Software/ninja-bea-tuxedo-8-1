/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Hashtable;
import java.util.Locale;

import javax.naming.Name;
import javax.naming.directory.Attributes;

//import oracle.dss.appmodule.common.CallbackObject;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.OrderedHashtable;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDRoot;
import oracle.dss.util.persistence.Persistable;

/**
 * @hidden
 */
public interface MetadataManagerObject extends MetadataProvider
{
  /************************************************************************
  * Attach and Detach Drivers
  ************************************************************************/
  // Attach all Drivers
  public MDRoot attach( MDRoot mdRoot, PropertyBag attachParams )  throws MetadataManagerException;

  // Detach all Drivers
  public MDRoot detach( PropertyBag detachParams) throws MetadataManagerException;

	// Attach a Metadata Driver
  public int attachDriver ( PropertyBag propertyBag )
																	throws MetadataManagerException;
	// Dech a Metadata Driver
	public int detachDriver (PropertyBag properties)
																	throws MetadataManagerException;
	// Is the Driver Attached?
  public boolean isDriverAttached( PropertyBag properties );

  /************************************************************************
  * Get objects from any tier..
  ************************************************************************/

	// get an mdObject from the server side cache.
	public MDObject[] getMDObjects(PropertyBag properties)
                                  throws MetadataManagerException;

	// get an mdObject from the server side cache.
	public MDObject getMDObjectByID( long mdObjectID )
                                  throws MetadataManagerException;

  //public MDObject getMDObject( PropertyBag propertyBag )
  //                                throws MetadataManagerException;

  // get mdObjects from the server side cache
  public OrderedHashtable getMDObjectTable( OrderedHashtable mdObjectIDs )
                                  throws MetadataManagerException;

  // get children of mdObject from the server side cache
  public OrderedHashtable getChildrenTillDepth( MDObject mdObject, int depth ) throws MetadataManagerException;

  /************************************************************************
  * Connection Support
  ************************************************************************/
	// Set a Connection object to this Metadata Manager Object instance
  public int setConnectionObject( Object connectionObject)
  																throws MetadataManagerException;

  // Set a Connection objects to this Metadata Manager Object instance
  public int setConnectionObjects( Object[] connectionObject)
                                  throws MetadataManagerException;


	// Get all the Connection Objects associated to this Metadata Manager Object.
  public Object[] getConnectionObjects() 
																	throws MetadataManagerException;


	// Get a particular Connection Object
  public Object getConnectionObject( String connectionString ) 
																	throws MetadataManagerException;

  /************************************************************************
  * Support for User Objects ( for example XML object of Graph) 
  * from the driver based on an MDObject. 
  ************************************************************************/

  public UserObject getUserObject( MDObject mdObject, String relation, String driverType, Hashtable env ) throws MetadataManagerException;
/*
  public int setUserObject( MDObject mdObject, UserObject userObject, String relation, String driverType ) throws MetadataManagerException;

  public int removeUserObject( MDObject mdObject, String relation, String driverType ) throws MetadataManagerException;
*/
  /************************************************************************
  * Support for generating ID
  ************************************************************************/
	public long generateMDObjectID();

  /************************************************************************
  * Root
  ************************************************************************/

	// Get the Root.
	public MDRoot getServerMDRoot();

  // set the root
	public int setServerMDRoot( MDRoot mdRoot );

    public Property getServerProperty ( String propertyName );

    public int setServerProperty( Property property );

    //public void setCallbackObject(CallbackObject client);

    /**
     * @hidden
     * Add mdObject to the cache.  This method will not call the driver and
     * save mdObject.
     *
     * @param mdObject MDObject that is to be added to cache.
     *
     * @status New
     */
    public void setMDObjectInCache( MDObject mdObject ) throws MetadataManagerException;
    
    public void addMDObject(MDObject mdObject) throws MetadataManagerException;

    /**
     * Set labels for measure dimension for this <code>MetadataManager</code>.
     *
     * @param propertyBag  PropertyBag that contains labels settings
     *
     * @throws MetadataManagerException If there is a problem retrieving
     * Measure Dimension object or if propertyBag contains a property that
     * is a non-label property. e.g. MM.OBJECT_NAME
     *
     * @status New
     */
    public void setMeasureDimensionLabels(PropertyBag propertyBag) throws MetadataManagerException;

    // object factory proxy methods
    public String getObjectInstanceClassName(String objType, String driverType);
    public void setObjectInstanceClassName(String objType, String instanceClassName, String driverType);
    public String getObjectDefName(String objType, String driverType);
    public void setObjectDefName(String objType, String defName, String driverType);
    public void dump(String driverType);

    public int _setReferencedObject(PropertyBag propertyBag);
    public int _removeReferencedObject(PropertyBag propertyBag);

    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException;
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attrs, Attributes bindAttrs, Hashtable env) throws MetadataManagerException;
    public Object lookup(MDFolder folder, Name name, Persistable persistable, Hashtable args, Attributes options) throws MetadataManagerException;
    
    public Object getObject(String id, String driverType, Hashtable env) throws MetadataManagerException;
    
    public MDObject setOlapObject(MDFolder parent, Object mdmObject) throws MetadataManagerException;

    public void addToLookupScopeCache(String oid, String path, Object sysAgg);
    public void clearLookupScopeCache();
    
    public void deferredObjectSetUp(MDObject obj);
    
    /**
     * Overwrite object in lookup cache
     */
    public void updateLookupScopeCache(String oid, String path, Object sysAgg);
}
