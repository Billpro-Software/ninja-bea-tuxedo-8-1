/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

public class MDTableItemFolder extends MDItemFolder
{
    public MDTableItemFolder()
    {
        setObjectType(MM.TABLE_ITEMFOLDER);
    }
}
