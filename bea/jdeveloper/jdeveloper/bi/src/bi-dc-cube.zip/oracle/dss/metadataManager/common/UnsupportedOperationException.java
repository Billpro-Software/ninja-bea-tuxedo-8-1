/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

import java.util.Locale;

/**
 * Indicates that the requested operation is not supported in this
 * implementation.
 */
public class UnsupportedOperationException extends MetadataManagerException
{
    /**
     * @hidden
     * Constructor that specifies the driver type and the locale.
     *
     * @param driverType The type of driver that initiates this exception.
     * @param locale  The locale to use for the message.
     *
     * @status hidden
     */
    public UnsupportedOperationException(String driverType, Locale locale)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, locale, driverType);
    }	
	
    /**
     * @hidden
     * Constructor that specifies the driver type.
     *
     * @param driverType The type of driver that initiates this exception.
     *
     * @status hidden
     */
    public UnsupportedOperationException(String driverType)
    {
    	this(driverType, null);
    }
}
