/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.common;

    

/**
 * @hidden
 * Object to store hPos ranges & original extent
 */
public class hPosInfo extends Object
{
    protected long m_extent = -1;
    protected IndexRanges m_ir = null;
    
    public hPosInfo(long originalExtent)
    {
        super();
        m_extent = originalExtent;
    }
    
    public IndexRanges getRangeStructure()
    {
        return m_ir;
    }
    
    public long getExtent()
    {
        return m_extent;
    }
    
    public void addIndex(long index)
    {
        if (m_ir == null)
            m_ir = new IndexRanges();
        // This means we're losing one extent unit
        m_extent--;
        m_ir.addIndex(index);
    }
    
    public boolean isCollapsed(long index)
    {                            
        // If the entire thing is collapsed, the extent will be zero
        return (m_extent == 0);
    }
    
    public String toString()
    {
        String retVal = "Extent: " + m_extent ;
        if (m_ir != null)
            retVal += "\n" + m_ir.toString();
        return retVal;
    }
}
