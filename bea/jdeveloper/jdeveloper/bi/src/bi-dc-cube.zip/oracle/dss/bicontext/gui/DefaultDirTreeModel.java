/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.util.Hashtable;
import javax.naming.directory.DirContext;
import javax.swing.tree.DefaultTreeModel;

import javax.swing.event.EventListenerList;

import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;

import oracle.dss.util.ErrorHandler;

/**
 * @hidden
 * This is the default implementation of the DirTreeModel interface.
 * Also known as the Common Tree Model (CTM), this model can take
 * any valid JNDI datasource and populates itself.  The JNDI source
 * can be MetadataManager (MDFolder) or PersistenceManager.
 * This is used by Persistence UI and QueryBuilder, CalcBuilder UI.
 *
 * Most of the calls are delegated to DefaultDirTreeNode class
 */
public class DefaultDirTreeModel extends DefaultTreeModel
{
    private Hashtable m_env;
    private TreeSorter m_sorter;

    private EventListenerList m_listenerList = new EventListenerList();

    /**
     * Constructor
     * @param con the context for the root
     * @param filters the filter used when populating the model
     * @param rootName the name of the root
     * @param rootIcon the icon of the root (key in IconManager)
     * @param factory the node factory
     *
     * @status New
     */
    public DefaultDirTreeModel(DirContext context, Attributes filters, SearchControls controls, String rootName, String rootIcon, TreeNodeFactory factory)
    {
        super(null);
        m_env = new Hashtable(10);
        if (factory != null)
            m_env.put(DefaultDirTreeNode.NODEFACTORY, factory);

        setSearchFilters(filters);
        setSearchControls(controls);
        initialize(context, rootName);
    }

    /**
     * Constructor
     * @param root the root node of the tree
     */
    public DefaultDirTreeModel(DirTreeNode root)
    {
        super(null);
        m_env = root.getEnvironment();

        if (m_env == null)
            m_env = new Hashtable(10);

        setRoot(root);
    }

    /**
     * @hidden
     * Legacy code used by MeasureListPanel in datautil with TreeSorter specified
     */
    public DefaultDirTreeModel(DirContext context, Attributes filters, SearchControls controls, TreeSorter sorter, String rootName, String rootIcon)
    {
        this(context, filters, controls, rootName, rootIcon, null);
        m_sorter = sorter;
    }

    /**
     * Sets the error handler used by the model
     * @param handler the error handler to be used
     *
     * @status New
     */
    public void addErrorHandler(ErrorHandler handler)
    {
        if (handler != null)
            m_env.put(DefaultDirTreeNode.ERRORHANDLER, handler);
    }

    /**
     * Removes the current handler from the model, the default one is used
     *
     * @status New
     */
    public void removeErrorHandler()
    {
        m_env.remove(DefaultDirTreeNode.ERRORHANDLER);
    }

    /**
     * Returns the error handler used by the model
     */
    public ErrorHandler getErrorHandler()
    {
        return (ErrorHandler)m_env.get(DefaultDirTreeNode.ERRORHANDLER);
    }

    /**
     * Returns the search filter used to populate the model
     *
     * @return the search filter used to populate the model
     * @status New
     */
    public Attributes getSearchFilters()
    {
        return (Attributes)m_env.get(DefaultDirTreeNode.ATTRIBUTES);
    }

    /**
     * Sets the search filter to be used to populate the model.  The search filter
     * should be used only to filter the results.
     *
     * @param the search filter used to populate the model
     * @status New
     */
    public void setSearchFilters(Attributes matchingAttrs)
    {
        if (matchingAttrs != null)
            m_env.put(DefaultDirTreeNode.ATTRIBUTES, matchingAttrs);
    }

    /**
     * Retrieves the <code>SearchControls</code> used to populate the model
     *
     * @return the <code>SearchControls</code> used to populate the model
     * @status New
     */
    public SearchControls getSearchControls()
    {
        return (SearchControls)m_env.get(DefaultDirTreeNode.SEARCHCONTROLS);
    }

    /**
     * Sets the <code>SearchControls</code> used to populate the model.  The SearchControls
     * is used only to limit/filter the results
     *
     * @param the <code>SearchControls</code> used to populate the model
     * @status New
     */
    public void setSearchControls(SearchControls controls)
    {
        if (controls != null)
            m_env.put(DefaultDirTreeNode.SEARCHCONTROLS, controls);
    }

    // creates root node and a node for each suffix
    protected void initialize(DirContext context, String rootName)
    {
        if (m_env.get(DefaultDirTreeNode.NODEFACTORY) != null)
            setRoot(((TreeNodeFactory)m_env.get(DefaultDirTreeNode.NODEFACTORY)).createTreeNode(m_env, context, rootName));
        else
            setRoot(new DefaultDirTreeNode(m_env, context, rootName));
    }

    /**
     * Adds a listener that is interested in receiving
     * PropertyChangeListener events. Called by JTable.
     *
     * @param l An object interested in receiving PropertyChangeListener events
     * @status New
     */
    public void addPropertyChangeListener(PropertyChangeListener l)
    {
        m_listenerList.add(PropertyChangeListener.class, l);
    }

    /**
     * Removes a listener that is interested in receiving
     * PropertyChangeListener events. Called by JTable.
     *
     * @param l An object interested in receiving PropertyChangeListener events
     * @status New
     */
    public void removePropertyChangeListener(PropertyChangeListener l)
    {
        m_listenerList.remove(PropertyChangeListener.class, l);
    }

    /**
     * Informs the tree that a particular property has changed
     *
     * @param node The node whose property changed 
     * @param 
     * @status New
     */
    public void firePropertyChanged(DirTreeNode node)
    {
        // Guaranteed to return a non-null array
        Object[] _listeners = m_listenerList.getListenerList();
        PropertyChangeEvent _evt = null;
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i=_listeners.length-2;i >= 0;i -= 2)
        {
            if (_listeners[i] == PropertyChangeListener.class)
            {
                // Lazily create the event:
                if (_evt == null)
                    _evt = new PropertyChangeEvent(this, "DIRECTORY CHANGE", null, node);

                PropertyChangeListener _l = (PropertyChangeListener)_listeners[i + 1];
                _l.propertyChange(_evt);
            }
        }
    }
}
