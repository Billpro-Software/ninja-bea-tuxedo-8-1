/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/filter/MeasureFilter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.filter;

import java.util.Arrays;
import java.util.Vector;

import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.NamingException;

import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;

// import oracle.dss.calculation.client.MDCalcAttributes;

import oracle.dss.dataSource.common.Query;

import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.SetUtils;

import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;

/**
 * <pre>
 * This class allows measures to be filtered from OLAP Business areas and 
 * BI Catalogs based on a wide range of filtering criteria. 
 * 
 * Its primary feature is the ability to specify dimensions (either directly or via 
 * a query) that can be used to filter measures based on intersecting dimensionality.
 * 
 * This functionality for example, improves the usability of the BI Beans 
 * QueryBuilder and CalcBuilder by providing lists of measures based on the end 
 * user's current context.
 * 
 * Measure filtering can be invoked by specifying a CalcBuilder/QueryBuilder
 * QueryFilter or directly through the  MeasureFilter methods (which can be used 
 * to directly retrieve measures or indirectly when used as a BIFilter).
 *
 * <strong>Using MeasureFilter to Retrieve Measures</strong>
 * 
 *   // Static invocation example
 *   //
 *   // Retrieve the first 5 MDMeasures filtered by Query
 *   // Defaults to MM.MEASURE and MM.MEASURE_CALC for the Object types
 *   Vector vMDMeasures = 
 *     MeasureFilter.getMDObjects (metadataManagerServices, query, null, 5);
 *
 *   // Non-Static invocation example of previous static method call
 *   //
 *   // Retrieve the first 5 MDMeasures filtered by Query
 *   // Defaults to MM.MEASURE and MM.MEASURE_CALC for the Object types
 *   MeasureFilter measureFilter = new MeasureFilter (query);
 *
 *   // The following call is optional if a MetadataManager has been associated 
 *   // with the Query
 *   measureFilter.setMetadataManagerServices (metadataManager);
 *   measureFilter.setCountLimit (5);
 *
 *   // Retrieve MDObjects (not recommended for large number of calculations)
 *   Vector vMDMeasures = measureFilter.getMDObjects();
 *
 *   // Retrieve SearchResults (recommended for large number of calculations)
 *   Vector vSearchResults = measureFilter.getSearchResults();
 *
 *   // Retrieve label from a SearchResult
 *   String strLabel = 
 *     measureFilter.getLabel ((MetadataManagerSearchResultImpl)vSearchResults.get(0),
 *       MetadataMap.METADATA_LONGLABEL);
 *     
 * <strong>Using MeasureFilter as a BIFilter</strong>
 *   // Generate a default BI Filter based on the specified Query
 *   BIFilter biFilterMeasureQuery = new MeasureFilter (query); 
 *     
 * <strong>Note:</strong> For performance, using SearchResults is preferable to 
 * MDObjects when processing large numbers of persisted objects such as calculations.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/02/06 - Remove CalcBuilder and olap from JDEVADF.
 *    gkellam   01/10/06 - Implement initial Custom Measure GUI round trip. 
 *
 */
public class MeasureFilter extends MetadataFilter {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Determines whether a measure should be dimensioned by a Time dimension.
   *
   * @status hidden
   */
  private boolean m_bTimeFilter = false;

  /**
   * @hidden
   * 
   * When used in conjunction with the TimeFilter, determines whether the Time 
   * dimensions can contain value-based hierarchies (that contain no levels).
   *
   * This value is <code>true</code> when Time dimensions that contain 
   * value-based hierarchies should be filtered out and <code>false</code> 
   * otherwise.
   *
   * @status hidden
   */
  private boolean m_bTimeValueBasedHierarchyFilter = true;

  /**
   * @hidden
   * 
   * Determines whether rank filter is used.
   * 
   * The rank filter orders measures in a descending order based on the
   * number of dimensions in common with the base dimensionality.
   *
   * @status hidden
   */
  private boolean m_bRankFilter = true;

  /**
   * @hidden
   * 
   * Determines whether the base measures should appear at the top of 
   * the search results.
   *
   * @status hidden
   */
  private boolean m_bBaseMeasuresAtTopFilter = true;

  /**
   * @hidden
   * 
   * The intersection filter to use for Base Measures.  
   * 
   * This filter is off by default, and only applies to objects that meet the 
   * initial dimension filter criteria.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   *
   * @see #setDimension(String)
   * @see #setDimensions(Vector)
   * 
   * @status hidden
   */
  private int m_nIntersectionBaseMeasuresFilter = DIMENSIONALITY_IGNORE;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Create default <code>MeasureFilter</code>.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   *
   * @status New
   */
  public MeasureFilter (MetadataManagerServices metadataManagerServices) {
    super (metadataManagerServices);
    init();
  }

  /**
   * Specifies the dimension that each measure must be dimensioned by.
   *
   * As a result, a measure will only be included if is dimensioned by the
   * dimension.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param strDimension A <code>String</code> value that is used to filter measures by.
   *
   * @status New
   */
  public MeasureFilter (MetadataManagerServices metadataManagerServices, String strDimension) {
    super (metadataManagerServices, strDimension);
    init();
  }
  
  /**
   * Specifies the list of dimensions to filter measures by.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param vstrDimensions A <code>Vector</code> of <code>String</code> values
   *        that are used to filter measures by.
   *
   * @status New
   */
  public MeasureFilter (MetadataManagerServices metadataManagerServices, Vector vstrDimensions) {
    super (metadataManagerServices, vstrDimensions);
    init();
  }

  /**
   * Specifies the <code>Query</code> whose dimensionality is used to filter 
   * measures by.
   *
   * Generally speaking, a measure will only be included if its dimensionality
   * intersects that of the measures specified in the Query.
   *
   * The <code>MeasureFilter</code> data types are automatically updated based
   * on the measures in the query.
   * 
   * @param query A <code>Query</code> used to filter measures by.
   *
   * @see #setDataTypes(String[])
   * 
   * @status New
   */
  public MeasureFilter (Query query) {
    super (query);
    init();

    try {
      if (query != null) {
        setDataTypes (getDataTypes (getMetadataManagerServices(), query.getMeasures()));
      }
    }
    
    catch (MetadataManagerException metadataManagerException) {
      getErrorHandler().log (metadataManagerException.toString(), 
        getClass().getName(), "MetadataFilter (Query query)");
    }
  }

  /**
   * Specifies the <code>Query</code> whose dimensionality is used to filter 
   * measures by along with desired data types.
   *
   * Generally speaking, a measure will only be included if its dimensionality
   * intersects that of the measures specified in the Query.
   *
   * @param query A <code>Query</code> used to filter measures by.
   * @param strDataTypes A <code>String</code> array containing the object
   *        types to use.  
   *        
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#INDETERMINATE
   *
   * @see #setDataTypes(String[])
   * 
   * @status New
   */
  public MeasureFilter (Query query, String[] strDataTypes) {
    super (query);
    init();
    setDataTypes (strDataTypes);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the intersection filter used when comparing dimensionality
   * using the base measures.
   *
   * <pre>
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together to apply multiple intersection filters at one time.
   * 
   * Example:
   *   setIntersectionBaseMeasuresFilter (DIMENSIONALITY_SUBSET | DIMENSIONALITY_EQUAL);
   * 
   * </pre>
   * 
   * @param nIntersectionBaseMeasuresFilter A <code>int</code> value that 
   *        specifies the type of intersection that the search should use.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   *
   * @status New
   */
  public void setIntersectionBaseMeasuresFilter (int nIntersectionBaseMeasuresFilter) {
    m_nIntersectionBaseMeasuresFilter = nIntersectionBaseMeasuresFilter;
  }

  /**
   * Determines the intersection filter used when comparing dimensionality.
   *
   * @return <code>int</code> value that represents the intersection filter used.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   * 
   * @status New
   */
  public int getIntersectionBaseMeasuresFilter() {
    return m_nIntersectionBaseMeasuresFilter;
  }

  /**
   * Specifies whether the measure should be dimensioned by Time.
   *
   * @param bTimeFilter A <code>boolean</code> value that is <code>true</code>
   *        when the measure should be dimensioned by Time and <code>false</code>
   *        otherwise.
   *        
   * @see #setTimeValueBasedHierarchyFilter(boolean)
   * 
   * @status new
   */
  public void setTimeFilter (boolean bTimeFilter) {
    m_bTimeFilter = bTimeFilter;
  }

  /**
   * Determines whether the measure should be dimensioned by Time.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measure
   *         should be dimensioned by Time and <code>false</code> otherwise
   * 
   * @see #isTimeValueBasedHierarchyFilterUsed()
   *
   * @status New
   */
  public boolean isTimeFilterUsed() {
    return m_bTimeFilter;
  }

  /**
   * When used in conjunction with the TimeFilter, specifies whether the Time 
   * dimensions can contain value-based hierarchies (that contain no levels).
   *
   * @param bTimeValueBasedHierarchyFilter A <code>boolean</code> value that is 
   *        <code>true</code> when Time dimensions that contain value-based 
   *        hierarchies should be filtered out and <code>false</code> otherwise.
   *
   * @see #setTimeFilter(boolean)
   * 
   * @status new
   */
  public void setTimeValueBasedHierarchyFilter (boolean bTimeValueBasedHierarchyFilter) {
    m_bTimeValueBasedHierarchyFilter = bTimeValueBasedHierarchyFilter;
  }

  /**
   * When used in conjunction with the TimeFilter, determines whether the Time 
   * dimensions can contain value-based hierarchies (that contain no levels).
   *
   * @return <code>boolean</code> value that is <code>true</code> when Time 
   *         dimensions that contain value-based hierarchies should be filtered 
   *         out and <code>false</code> otherwise.
   *
   * @see #isTimeFilterUsed()
   * 
   * @status new
   */
  public boolean isTimeValueBasedHierarchyFilterUsed() {
    return m_bTimeValueBasedHierarchyFilter;
  }
  
  /**
   * Specifies whether the search results should be sorted based on dimensionality
   * ranking.
   *
   * The rank filter orders measures in a descending order based on the
   * number of dimensions in common with the base dimensionality.
   * 
   * @param bRankFilter A <code>boolean</code> value that is <code>true</code>
   *        when the results should be sorted by dimensionality rank and 
   *        <code>false</code> otherwise.
   *
   * @status New
   */
  public void setRankFilter (boolean bRankFilter) {
    m_bRankFilter = bRankFilter;
  }

  /**
   * Determines whether the search results should be sorted based on dimensionality
   * ranking.
   *
   * The rank filter orders measures in a descending order based on the
   * number of dimensions in common with the base dimensionality.
   *
   * @return <code>boolean</code> value that is <code>true</code>
   *         when the results should be sorted by dimensionality rank and 
   *         <code>false</code> otherwise.
   *
   * @status New
   */
  public boolean isRankFilterUsed() {
    return m_bRankFilter;
  }

  /**
   * Specifies whether the base measures should appear at the top of search 
   * results.
   *
   * @param bBaseMeasuresAtTopFilter A <code>boolean</code> value that is 
   *        <code>true</code> when the base measures should appear at the top of 
   *        the search results and <code>false</code> otherwise.
   *
   * @status New
   */
  public void setBaseMeasuresAtTopFilter (boolean bBaseMeasuresAtTopFilter) {
    m_bBaseMeasuresAtTopFilter = bBaseMeasuresAtTopFilter;
  }

  /**
   * Determines whether the base measures should appear at the top of search 
   * results.
   *
   * @return <code>boolean</code> value which is <code>true</code>
   *         when the base measures should appear at the top of the search 
   *         results and <code>false</code> otherwise.
   *
   * @status New
   */
  public boolean isBaseMeasuresAtTopFilterUsed() {
    return m_bBaseMeasuresAtTopFilter;
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome.
   *
   * @param biSearchResult A <code>BISearchResult</code> to process to determine
   *        if it should be included in the result.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the search result
   *         should be included and <code>false</code> otherwise.
   *         
   * @status New
   */
  public boolean evaluate (BISearchResult biSearchResult) {

    boolean bInclude = true;

    // Check for null search results
    if (biSearchResult == null)
      return false;

    if (biSearchResult instanceof MetadataManagerSearchResultImpl) {
      MetadataManagerSearchResultImpl mmResult = 
        (MetadataManagerSearchResultImpl) biSearchResult;

      String strObjectType = mmResult.getObjectType();
      MDMeasure mdMeasure = null;
      
      // Implement the MeasureDimensionFilter check for the Measure Dimension
      if (MM.DIMENSION.equals (strObjectType)) {
        Object objResult = biSearchResult.getObject();
        if ((objResult != null) && (objResult instanceof MDObject)) {
          MDObject mdObject = (MDObject)objResult;
          if (mdObject.getSubObjectType() == MM.MEASURE_DIMENSION) {
            return false;
          }
        }
      }

      // Determine if we are processing a Measure or Calculation
      if (MM.MEASURE.equals (strObjectType) || (MM.MEASURE_CALC.equals (strObjectType))) {
        MDDimension[] mdDimensions = null;

        try {
          // Dimensions to filter measure by  
          Vector vstrDimensionIDsFilter;  
          
          // Determine dimensions that each measure must be dimensioned by.
          if (getDimension() != null) {
            vstrDimensionIDsFilter = new Vector ();
            vstrDimensionIDsFilter.add (getDimension());
          }
          else {
            vstrDimensionIDsFilter = getDimensions();
          }
        
          // If no dimensions have been specified, assume All dimensions
          //
          // Note: It is more efficient to avoid checking dimensionality, 
          //       if possible.
          if ((vstrDimensionIDsFilter == null) || (vstrDimensionIDsFilter.size() == 0)) {
            if (!isTimeFilterUsed()) {
              return true;
            }
            else {
              // If the time filter is on, make sure that we are dimensioned by
              // an available time dimension.
              vstrDimensionIDsFilter = 
                DataUtils.getTimeDimensions (mmResult.getMetadataManagerServices(), null);
            }
          }

          /* gek 11/02/06          
          // Determine if we are processing a calculation
          if (MM.MEASURE_CALC.equals (strObjectType)) {
            // Retrieve the dimensionality performantly 
            mdDimensions = 
              MDCalcAttributes.getDimensions (mmResult.getMetadataManagerServices(), 
                mmResult.getAttributes(), null);
          } 
          else {
            mdMeasure = (MDMeasure) mmResult.getMDObject();
            
            if (mdMeasure != null) {
              mdDimensions = mdMeasure.getDimensions();
            }
          }
          */
          
          mdMeasure = (MDMeasure) mmResult.getMDObject();
          
          if (mdMeasure != null) {
            mdDimensions = mdMeasure.getDimensions();
          }

          // If we can't retrieve dimensionality simply don't include measure
          if (mdDimensions == null)
            return false;

          // Convert the MDDimension objects to their associated unique IDs
          Vector vstrDimensionIDs = 
            new Vector (Arrays.asList (DataUtils.getUniqueIDs (mdDimensions)));
          
          // Determine whether this SearchResult should be included
          if (getIntersectionFilter() != DIMENSIONALITY_IGNORE) {
            bInclude = isIncluded (vstrDimensionIDsFilter, vstrDimensionIDs, 
              null, getIntersectionFilter()); 
  
            // When checking for intersecting dimensionality, make need to make sure
            // sure that the calculation is valid (e.g. we can load all aggregates).
            
            // Basic algorithm
            //  1) Verify that the user is comparing dimensionality
            //  2) For performance, only retrieve MDMeasureCalc if it is aggregated
            //  3) Verify that MDMeasureCalc is valid
            //     If we can't retrieve all dimensionality, don't include it 
            //     in search result.
            /* gek 11/02/06
            if (bInclude) {
              bInclude = 
                MDCalcAttributes.isValid (mmResult.getMetadataManagerServices(), 
                  mmResult.getAttributes(), getErrorHandler());   
            }
            */
          }
        
          // Apply the base measure filter  
          if (bInclude) {
            if (getIntersectionBaseMeasuresFilter() != DIMENSIONALITY_IGNORE) {
              Vector vstrBaseDimensionIDs =
                DataUtils.getDimensions (mmResult.getMetadataManagerServices(), 
                  getBaseMeasures());
            
              bInclude = isIncluded (vstrBaseDimensionIDs, vstrDimensionIDs, 
                null, getIntersectionBaseMeasuresFilter()); 
            }
          }
        
          // Remember the number of intersecting dimensions so that they
          // can later be used to rank the measures
          if (bInclude && isRankFilterUsed()) {

            // When determining rank, attempt to retrieve dimensionality
            // from base measures.
            Vector vstrBaseDimensionIDs =
              DataUtils.getDimensions (mmResult.getMetadataManagerServices(), 
                getBaseMeasures());
            
            // If no base measures were specified, attempt to retrieve base
            // dimensions.
            if ((vstrBaseDimensionIDs == null) || (vstrBaseDimensionIDs.size() == 0)){
              vstrBaseDimensionIDs = getDimensions();

              // If base dimensions weren't specified, default to original filtering
              // dimensions.
             if ((vstrBaseDimensionIDs == null) || (vstrBaseDimensionIDs.size() == 0)) {
                vstrBaseDimensionIDs = vstrDimensionIDsFilter;
              }
            }
          
            // Determine the number of intersecting dimensions
            Vector vstrIntersection = new Vector();
            SetUtils.compareSets (vstrBaseDimensionIDs, vstrDimensionIDs, 
              vstrIntersection);

            // Remember the number of intersecting dimensions for ranking
            Attributes attributes = mmResult.getAttributes();
            if (attributes != null) {
              if (vstrIntersection != null) {
                attributes.put (FILTER_DIMENSION_RANK, 
                  new Integer (vstrIntersection.size()));
              }
            }
          }
        }
        
        catch (MetadataManagerException metadataManagerException) {
          getErrorHandler().log (metadataManagerException.toString(), 
            getClass().getName(), "evaluate (BISearchResult biSearchResult)");
          
          return false;
        }
            
        // Check to see if we need to check for time dimension
        if (bInclude && isTimeFilterUsed()) {
          boolean bIncludeTime = false;
          
          for (int i = 0; i < mdDimensions.length; i++) {
            if (mdDimensions[i].isTimeDimension()) {
              
              // Determine if the we need to check the time dimension for
              // value-based hierarchies
              if (isTimeValueBasedHierarchyFilterUsed()) {
                Vector vTimeDimensions = new Vector();
                vTimeDimensions.add (mdDimensions[i]);
              
                // Filter out time dimension if it contains a value-based
                // hierarchy.
                vTimeDimensions = 
                  DataUtils.filterByValueBasedHierarchy (
                    mmResult.getMetadataManagerServices(), vTimeDimensions);
  
                // If we still have a time dimension after filtering, include it
                if ((vTimeDimensions != null) || (vTimeDimensions.size() != 0)) {
                  bIncludeTime = true;
                }
              }
              else {
                bIncludeTime = true;
              }
              
              break;
            }
          }
          
          bInclude = bIncludeTime;
        }
      }
    }

    return bInclude;
  }

  /**
   * Retrieves a <code>Vector</code> of <code>SearchResult</code> values based
   * on the chosen <code>MeasureFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated measure
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>SearchResult</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getSearchResults() throws MetadataManagerException, NamingException {
    
    long lCountLimit = getCountLimit();
    
    // Retrieve the list of search results
    Vector vSearchResults = new Vector();
    vSearchResults = getSearchResults (getFolderRoot(), getBasicAttributes(), 
      getSearchControls(), vSearchResults, lCountLimit);

    // Perform post filtering processes
    vSearchResults = 
      getSearchResults (getMetadataManagerServices(), vSearchResults, 
        getBaseMeasures(), isRankFilterUsed(), isBaseMeasuresAtTopFilterUsed(), 
          getErrorHandler(), getBasicAttributes(), getSearchControls());

    // Make sure that we don't return more SearchResults than the count limit
    if ((lCountLimit > -1) && (vSearchResults != null) && (vSearchResults.size() > lCountLimit)) {
      vSearchResults.setSize ((int)lCountLimit);  
    }

    return vSearchResults;
  }

  /**
   * Retrieves a <code>Vector</code> of <code>MDObject</code> values based
   * on the chosen <code>MeasureFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getMDObjects() throws MetadataManagerException, NamingException {
    return getMDObjects (getSearchResults());
  }

  /**
   * Retrieves <code>MDObject</code> objects filtered by <code>Query</code>.
   * 
   * This is useful for populating GUI controls such as <code>JComboBox</code> 
   * and <code>JList</code> or wherever a flat list of measures is required
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        search for metadata.
   * @param query A <code>Query</code> used to filter measures based on its
   *        associated dimensionality.
   * @param strObjectTypes A <code>String</code> array containing the object
   *        types to use.  If null the default MM.MEASURE and MM.MEASURE_CALC
   *        values are used.
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   *        
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDMeasure</code> values cannot be retrieved.
   * 
   * @see oracle.dss.datautil.filter.MeasureFilter#getMDObjects(Vector) 
   * 
   * @status new
   */
  public static Vector getMDObjects (MetadataManagerServices metadataManager, Query query, 
                                  String[] strObjectTypes, long lCountLimit) 
    throws MetadataManagerException, NamingException {

    // Retrieve the base measures      
    Vector vstrBaseMeasureIDs = 
      (query != null) ? DataUtils.getMeasures (query) : null;

    return getMDObjects (metadataManager, vstrBaseMeasureIDs, 
      strObjectTypes, lCountLimit);  
  }

  /**
   * Retrieves <code>MDObject</code> objects filtered by the specified 
   * base <code>Measures</code>.
   * 
   * This is useful for populating GUI controls such as <code>JComboBox</code> 
   * and <code>JList</code> or wherever a flat list of measures is required
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        search for metadata.
   * @param vstrBaseMeasureIDs A <code>Vector</code> of measures referenced by 
   *        unique ID whose dimensionality is used to filter other measures.
   *        The underlying data types (for example, MM.INTEGER) are determined 
   *        from these base measures. 
   * @param strObjectTypes A <code>String</code> array containing the object
   *        types to use.  If null the default MM.MEASURE and MM.MEASURE_CALC
   *        values are used.
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * @see oracle.dss.datautil.filter.MeasureFilter#getMDObjects(Vector) 
   * 
   * @status new
   */
  public static Vector getMDObjects (MetadataManagerServices metadataManager, 
      Vector vstrBaseMeasureIDs, String[] strObjectTypes, long lCountLimit) 
                            throws MetadataManagerException, NamingException {

    // Retrieve data types from measure list
    String[] strDataTypes = 
      getDataTypes (metadataManager, toArray (vstrBaseMeasureIDs));

    return getMDObjects (metadataManager, vstrBaseMeasureIDs, strObjectTypes,
      strDataTypes, lCountLimit);
  }

  /**
   * Retrieves <code>MDMeasure</code> objects filtered by <code>Query</code>.
   * 
   * This is useful for populating GUI controls such as <code>JComboBox</code> 
   * and <code>JList</code> or wherever a flat list of measures is required
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        search for metadata.
   * @param query A <code>Query</code> used to filter measures based on its
   *        associated dimensionality.
   * @param strObjectTypes A <code>String</code> array containing the object
   *        types to use.  If null the default MM.MEASURE and MM.MEASURE_CALC
   *        values are used.
   * @param strDataTypes A <code>String</code> array containing the object
   *        types to use.  For example, MM.INTEGER.          
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDMeasure</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDMeasure</code> values cannot be retrieved.
   * 
   * @see oracle.dss.datautil.filter.MeasureFilter#getMDObjects(Vector) 
   * 
   * @status new
   */
  public static Vector getMDObjects (MetadataManagerServices metadataManager, Query query, 
                String[] strObjectTypes, String[] strDataTypes, long lCountLimit) 
    throws MetadataManagerException, NamingException {

    // Retrieve the base measures      
    Vector vstrBaseMeasureIDs = 
      (query != null) ? DataUtils.getMeasures (query) : null;

    return getMDObjects (metadataManager, vstrBaseMeasureIDs, 
      strObjectTypes, strDataTypes, lCountLimit);  
  }

  /**
   * Retrieves <code>MDMeasure</code> objects filtered by <code>Measures</code>.
   * 
   * This is useful for populating GUI controls such as <code>JComboBox</code> 
   * and <code>JList</code> or wherever a flat list of measures is required
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        search for metadata.
   * @param vstrBaseMeasureIDs A <code>Vector</code> of measures referenced by 
   *        unique ID whose dimensionality is used to filter other measures.
   * @param strObjectTypes A <code>String</code> array containing the object
   *        types to use.  If null the default MM.MEASURE and MM.MEASURE_CALC
   *        values are used.
   * @param strDataTypes A <code>String</code> array containing the object
   *        types to use.  For example, MM.INTEGER.        
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDMeasure</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDMeasure</code> values cannot be retrieved.
   * 
   * @see oracle.dss.datautil.filter.MeasureFilter#getMDObjects(Vector) 
   * 
   * @status new
   */
  public static Vector getMDObjects (MetadataManagerServices metadataManager, 
      Vector vstrBaseMeasureIDs, String[] strObjectTypes, String[] strDataTypes,
        long lCountLimit) throws MetadataManagerException, NamingException {

    Vector vMDMeasures = null;
    
    if (metadataManager != null) {
      MDFolder mdFolder = metadataManager.getMDRoot();
 
      // Determine object types to include
      if (strObjectTypes == null) {
        strObjectTypes = new String[] {MM.MEASURE, MM.MEASURE_CALC};    
      }

      // Determine the object types to include
      BasicAttributes basicAttributes = getBasicAttributes (strObjectTypes, true);
            
      // Set up base filter
      BIFilter biFilterBase = new MeasureFilter (metadataManager, 
        DataUtils.getDimensions (metadataManager, vstrBaseMeasureIDs));

      // Determine search criteria
      SearchControls searchControls = 
        getSearchControls (metadataManager, strDataTypes, biFilterBase, lCountLimit);

      // Retrieve the list of search results
      Vector vSearchResults = new Vector();
      vSearchResults = getSearchResults (mdFolder, basicAttributes, searchControls, 
        vSearchResults, lCountLimit);

      // Perform post filtering processes
      vSearchResults = getSearchResults (metadataManager, vSearchResults, 
        vstrBaseMeasureIDs, true, true, new DefaultErrorHandler(), 
          basicAttributes, searchControls);

      // Make sure that we don't return more SearchResults than the count limit
      if ((lCountLimit > -1) && (vSearchResults != null) && (vSearchResults.size() > lCountLimit)) {
        vSearchResults.setSize ((int)lCountLimit);  
      }

      // Retrieve the MDObjects from the search results    
      vMDMeasures = getMDObjects (vSearchResults);
    }

    return vMDMeasures;    
  }

  /**
   * Retrieves a <code>Vector</code> of <code>MDObject</code> values from the
   * underlying <code>MetadataManagerSearchResultImpl</code> 
   * <code>SearchResult</code> objects.
   *
   * @param vSearchResults A <code>Vector</code> of <code>MetadataManagerSearchResultImpl</code>
   *        SearchResults to retrieve MDObjects for.
   *
   * @return <code>Vector</code> representing the list of <code>MDObject</code> 
   *         values, if any
   *         
   * @see oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl#getMDObject()
   * 
   * @status new
   */
  static public Vector getMDObjects (Vector vSearchResults) { 
    Vector vMDObjects = null;
 
     // Iterate over the search results to retrieve the underlying MDObjects
    if (vSearchResults != null && !vSearchResults.isEmpty()) {
      vMDObjects = new Vector();
      
      SearchResult searchResult;
      for (int nIndex = 0; nIndex < vSearchResults.size(); nIndex++) {
        searchResult = (SearchResult) vSearchResults.get (nIndex);
        
        if ((searchResult != null) && (searchResult instanceof MetadataManagerSearchResultImpl)) {
          vMDObjects.add (((MetadataManagerSearchResultImpl)searchResult).getMDObject());
        }
      }
    }

    return vMDObjects;
  }

  /**
   * Retrieves a dimensionality of the measure <code>SearchResult</code> as a 
   * <code>Vector</code> of <code>MetadataManager</code> <code>MDDimension</code> 
   * unique IDs.
   * 
   * @param searchResult A <code>SearchResult</code> to retrieve the dimensionality
   *        for.
   *        
   * @return <code>Vector</code> of <code>MDDimension</code> unique IDs. 
   *         
   * @throws <code>MetadataManagerException</code> if dimensionsionality cannot
   *         be retrieved.
   *         
   * @status new
   */
  public static Vector getDimensionIDs (SearchResult searchResult) throws MetadataManagerException {
    return getUniqueIDs (getMDDimensions (searchResult));
  }

  /**
   * Retrieves the dimensionality of the measure <code>SearchResult</code> as an 
   * array of <code>MDDimension</code> objects
   * 
   * @param searchResult A <code>SearchResult</code> to retrieve the dimensionality
   *        for.
   *        
   * @return <code>MDDimension[]</code> which represents the measure
   *          <code>SearchResult</code> dimensionalty. 
   *         
   * @throws <code>MetadataManagerException</code> if dimensionsionality cannot
   *         be retrieved.
   *         
   * @status new
   */
  public static MDDimension[] getMDDimensions (SearchResult searchResult) throws MetadataManagerException {
    MDDimension[] mdDimensions = null;
  
    if ((searchResult != null) && (searchResult instanceof MetadataManagerSearchResultImpl)) {
      MetadataManagerSearchResultImpl mmSearchResult = 
        (MetadataManagerSearchResultImpl) searchResult;
        
      String strObjectType = mmSearchResult.getObjectType();

      /* gek 11/02/06      
      // Determine if we are processing a Measure or Calculation
      if (MM.MEASURE.equals (strObjectType) || (MM.MEASURE_CALC.equals (strObjectType))) {
        // Determine if we are processing a calculation
        if (MM.MEASURE_CALC.equals (strObjectType)) {
          // Retrieve the dimensionality performantly 
          mdDimensions = 
            MDCalcAttributes.getDimensions (mmSearchResult.getMetadataManagerServices(), 
              mmSearchResult.getAttributes(), null);
        } 
        else {
          MDMeasure mdMeasure = (MDMeasure) mmSearchResult.getMDObject();
          
          if (mdMeasure != null) {
            mdDimensions = mdMeasure.getDimensions();
          }
        }
      }
      */

      // Determine if we are processing a Measure
      if (MM.MEASURE.equals (strObjectType)) {
        MDMeasure mdMeasure = (MDMeasure) mmSearchResult.getMDObject();
        
        if (mdMeasure != null) {
          mdDimensions = mdMeasure.getDimensions();
        }
      }
    }      

    return mdDimensions;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
  
  /**
   * @hidden
   * 
   * Orders the specified measure <code>SearchResult</code> list based on the 
   * specified filtering options.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param vMeasureSearchResults A <code>Vector</code> of measures to order.
   * @param vstrBaseMeasures A <code>Vector</code> of base measures (normally
   *        associated with a <code>Query</code> that are used in conjuction
   *        with the QueryMeasureTopFilter.
   * @param query A <code>Query</code> used to filter measures based on its
   *        associated dimensionality.
   * @param bUseRankFilter A <code>boolean</code> value which is <code>true</code>
   *        if the measures should be ordered by dimension rank and 
   *        <code>false</code> otherwise.
   * @param bUseQueryMeasureTopFilter A <code>boolean</code> value which is 
   *        <code>true</code> if the measures specified in the query should 
   *        appear at the top of the search results and <code>false</code>
   *        otherwise.
   * @param errorHandler A <code>ErrorHandler</code> used to process errors. 
   * 
   * @return <code>Vector</code> of ordered <code>MDMeasure</code> values. 
   * 
   * @status hidden
   */
  protected static Vector getSearchResults (MetadataManagerServices metadataManagerServices,
    Vector vSearchResults, Vector vstrBaseMeasures, boolean bUseRankFilter, 
      boolean bUseQueryMeasureTopFilter, ErrorHandler errorHandler, 
        BasicAttributes basicAttributes, SearchControls searchControls) {

    if (vSearchResults != null) {
      // Determine if we need to rank the measures by the number of intersecting
      // dimensions
      if (bUseRankFilter) {
        vSearchResults = orderByRank (vSearchResults);    
      }
      
      // Determine if the Query measures should appear at the top of the search
      // results
      if (bUseQueryMeasureTopFilter) {
        vSearchResults = orderByID  (metadataManagerServices, 
          vSearchResults, vstrBaseMeasures, errorHandler, 
            basicAttributes, searchControls);    
      }
    }
  
    return vSearchResults;
  }
        
  /**
   * @hidden
   * 
   * Initializes the <code>MeasureFilter</code>.
   * 
   * @status hidden
   */
  protected void init () {
    // Set default object types
    setObjectTypes (new String[] {MM.MEASURE, MM.MEASURE_CALC});
    
    // Set default data types
    setDataTypes (new String[] {MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE});
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}