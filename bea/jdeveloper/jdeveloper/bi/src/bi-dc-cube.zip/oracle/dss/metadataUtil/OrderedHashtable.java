/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

// Imports
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;

/**
 * @hidden
 */
public class OrderedHashtable implements java.io.Serializable {
    private Hashtable hashtable;
    private Vector orderedKeys = null;
    private Vector orderedValues = null;

    public OrderedHashtable() {
        hashtable = new Hashtable(11);
        orderedKeys = new Vector(11);
        orderedValues = new Vector(11);
    }

    public OrderedHashtable( int initialCapacity ) {
        hashtable = new Hashtable(initialCapacity);
        orderedKeys = new Vector(initialCapacity);
        orderedValues = new Vector(initialCapacity);
    }

    public OrderedHashtable(int initialCapacity, float loadFactor) {
        hashtable = new Hashtable( initialCapacity, loadFactor );
        orderedKeys = new Vector(initialCapacity);
        orderedValues = new Vector(initialCapacity);
    }

    public synchronized Enumeration keys() {
        return orderedKeys.elements();
    }

    public synchronized Enumeration elements() {
        return orderedValues.elements();
    }

    public synchronized Object put(Object key, Object value) {
        Object tempObject = hashtable.put( key, value );

        if (orderedKeys == null) {
            // this is just to get it working and it needs to be fixed. _Anto
            orderedKeys = new Vector();
            System.out.println("********************* ERROR in OrderedHashtable ****************" );
        }

        if( tempObject == null ){
            // new key added to hash table
            orderedKeys.addElement( key );
            orderedValues.addElement( value );
        }
        else {
            int index = orderedKeys.indexOf( key );
            if( index != -1 ) {
                orderedKeys.removeElementAt( index );
                orderedValues.removeElementAt( index );
                
                orderedKeys.insertElementAt( key, index );
                orderedValues.insertElementAt( value, index );
            }
        }
        return tempObject;
    }

    public synchronized Object remove( Object key ) {
        Object tempObject = hashtable.remove( key );
        if( tempObject != null ){
            // key is removed from hashtable
            int index = orderedKeys.indexOf( key );
            orderedKeys.removeElement( key );
            if(index != -1)
                orderedValues.removeElementAt(index);
        }
        return tempObject;
    }

    public synchronized void clear(){
        hashtable.clear();
        orderedKeys.removeAllElements();
        orderedValues.removeAllElements();
    }

    public boolean isEmpty() {
        return hashtable.isEmpty();
    }

    public synchronized boolean contains(Object value) {
        return hashtable.contains( value );
    }

    public synchronized boolean containsKey(Object key) {
        return hashtable.containsKey( key );
    }

    public synchronized Object get(Object key) {
        return hashtable.get( key );
    }

    public synchronized Object clone() {
        OrderedHashtable orderedHashtable = new OrderedHashtable();
        orderedHashtable.hashtable = (Hashtable)hashtable.clone();
        orderedHashtable.orderedKeys = (Vector)orderedKeys.clone();
        orderedHashtable.orderedValues = (Vector)orderedValues.clone();
        return orderedHashtable;
    }

    public synchronized String toString() {
        return hashtable.toString();
    }

    public int size() {
        return hashtable.size();
    }
}
