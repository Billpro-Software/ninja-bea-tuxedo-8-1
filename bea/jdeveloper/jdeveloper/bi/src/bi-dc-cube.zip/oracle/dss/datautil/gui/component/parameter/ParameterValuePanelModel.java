/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValuePanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    11/29/05 - Creation
 */

package oracle.dss.datautil.gui.component.parameter;

import oracle.dss.util.parameters.Parameter;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValuePanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public interface ParameterValuePanelModel {

  /**
   * Retrieves a list of Parameters whose values will be shared
   * 
   * @return The list of Parameters
   */
  public Parameter[] getSharedParameters();
  
  /**
   * Retrieves the number of objects that will have private Parameter values
   * 
   * @return The number of objects
   */
  public int getPrivateCount();
  
  /**
   * Retrieves a list of Parameters whose values will be private to the object
   * with the specified index
   * 
   * @param index The index of the object
   * 
   * @return The list of Parameters
   */
  public Parameter[] getPrivateParameters(int index);
  
  /**
   * Specifies a shared value for a Parameter
   * 
   * @param parameter The Parameter
   * @param value The shared value
   */
  public void setSharedValue(Parameter parameter, Object value);

  /**
   * Retrieves a shared value for a Parameter
   * 
   * @param parameter The Parameter
   * @return The shared value
   */
  public Object getSharedValue(Parameter parameter);
  
  /**
   * Specifies a private value for a Parameter
   * 
   * @param index The index of the object for which the value applies
   * @param parameter The Parameter
   * @param value The private value
   */
  public void setPrivateValue(int index, Parameter parameter, Object value);
  
  /**
   * Retrieves a private value for a Parameter
   * 
   * @param index The index for the object for which the value applies
   * @param parameter The Parameter
   * @return The private value
   */
  public Object getPrivateValue(int index, Parameter parameter);

  /**
   * Retrieves the header label for shared Parameters
   * 
   * @return The label
   */
  public String getSharedLabel();
  
  /**
   * Retrieves the header label for an object with non-shared Parameters
   * 
   * @param index The index of the object
   * @return The label
   */
  public String getPrivateLabel(int index);
  
  /**
   * Updates all dependent objects based on the specified values
   */
  public void apply();
}