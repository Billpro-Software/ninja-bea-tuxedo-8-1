/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners of changes to one or more <code>Selection</code> objects.
 * This event is fired <I>before</I> the <code>DataChangedEvent</code>.
 * The <code>SelectionChangedEvent</code> cannot be consumed.
 *
 * @status Documented
*/
public class SelectionChangedEvent extends SelectionEvent
{
    /**
     * Constructs the event.
     * 
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param selections  A list of the <code>Selection</code> objects that
     *                    changed.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
    public SelectionChangedEvent(Object source /*, Selection[] selections*/) {
        super(source, /*selections, */false);
    }    
    
    /**
     * Constructs the event.
     * 
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param selections  A list of the <code>Selection</code> objects that
     *                    changed.
     * @param removed     Were these selections removed?
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
    public SelectionChangedEvent(Object source, /*Selection[] selections,*/ boolean removed) {
        super(source, /*selections, */removed);
    }        
}
