/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import oracle.dss.metadataUtil.UserObject;
import oracle.dss.util.NumberFormat;
import oracle.dss.util.NumberFormatType;
import oracle.dss.util.Utility;

public class MDDimensionCalc extends MDObject implements NumberFormatType
{
    /**
     * Constructor
     */
    public MDDimensionCalc()
    {
        setStrPropertyValue(MM.OBJECT_TYPE, MM.DIMENSIONCALC);
    }

    /**
     * Constructor.
     *
     * @param mmServices   The <code>MetadataManagerServices</code> that this
     *                     object exists in.
     * @param MDDimensionCalc  The name of this dimension calc.
     * @param parent       The object that contains this object.
     *
     * @status New
     */
    public MDDimensionCalc(MetadataManagerServices mmServices, String mdObjName, MDObject parent) 
    {
        super(mmServices, mdObjName, parent);
        setStrPropertyValue(MM.OBJECT_TYPE, MM.DIMENSIONCALC);
    }

    //-------------------------------------------------------------------
    // Start implementation of NumberFormatType interface
    //-------------------------------------------------------------------

    /**
     * Specifies how a number should be formatted based on the specified format
     * mask.
     *
     * @param strNumberFormatString A <code>String</code> value which contains the
     *        number format mask.
     *
     * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
     *
     * @status New
     */
    public void setNumberFormatString (String strNumberFormatString) 
    {
        if (strNumberFormatString != null)
            setStrPropertyValue(MM.NUMBER_FORMAT_STRING, strNumberFormatString);
    }

    /**
     * @hidden
     *
     * Specifies the number format type associated with the number format string.
     *
     * @param strNumberFormatType A <code>String</code> that represents the type of
     *        number format string.
     *
     * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_TYPE
     *
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
     *
     * @see oracle.dss.util.NumberFormatType#setNumberFormatString
     *
     * @status New
     */
    public void setNumberFormatType (String strNumberFormatType)
    {
        if (strNumberFormatType != null)
            setStrPropertyValue (MM.NUMBER_FORMAT_TYPE, strNumberFormatType);
    }

    /**
     * @hidden
     *
     * Specifies how a number should be formatted based on its number format type
     * and associated number format string.
     *
     * @param strNumberFormatString A <code>String</code> value which contains the
     *        number format mask.
     * @param strNumberFormatType A <code>String</code> that represents the type of
     *        number format string.
     *
     * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
     * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_TYPE
     *
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
     *
     * @status New
     */
    public void setNumberFormat (String strNumberFormatString, String strNumberFormatType)
    {
        if (strNumberFormatString != null) {
            setStrPropertyValue(MM.NUMBER_FORMAT_STRING, strNumberFormatString);
        }

        if (strNumberFormatType != null) {
            setStrPropertyValue(MM.NUMBER_FORMAT_TYPE, strNumberFormatType);
        }
    }

    /**
     * Retrieves the number format mask that specifies how a number should be
     * formatted.
     *
     * @return <code>String</code> which is the number format mask being used.
     *
     * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
     *
     * @status New
     */
    public String getNumberFormatString()
    {
        return getStrPropertyValue(MM.NUMBER_FORMAT_STRING);
    }

    /**
     * @hidden
     *
     * Retrieves the number format type associated with the number format string.
     *
     * @return <code>String</code> which is the number format type being used.
     *         If no value is set, the default value is returned which is
     *         <code>NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS</code>.
     *
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
     * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
     *
     * @see oracle.dss.util.NumberFormat#getNumberFormatString
     *
     * @status New
     */
    public String getNumberFormatType()
    {
        String strNumberFormatType = getStrPropertyValue(MM.NUMBER_FORMAT_TYPE);
        if (strNumberFormatType != null)
            return strNumberFormatType;

        return NumberFormatType.NUMBER_FORMAT_TYPE_ORACLE;
    }

    //-------------------------------------------------------------------
    // End implementation of NumberFormatType interface
    //-------------------------------------------------------------------

    /**
     * @hidden
     */
    public void setMemberID(String memberID)
    {
        setOLAPIRuntimeID(memberID);
    }

    /**
     * @hidden
     */
    public String getMemberID()
    {
        return getOLAPIRuntimeID();
    }

    /**
     * @hidden
     * Retrieves the <code>UserObject</code> for this object.
     * If the user object is not available locally, then this method
     * attempts to retrieve the user object from the underlying driver.
     *
     * @param relation  The relationship between this object and its user object.
     * @param driverType  The type of driver that the user object uses.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @return  The <code>UserObject</code> for this object, or <code>null</code>
     *          if there is no <code>MetadataManagerServices</code> set for
     *          this object, or if <code>relation</code> or <code>driverType</code>
     *          is <code>null</code>.
     *
     * @status hidden
     */
    public UserObject getUserObject (String relation, String driverType) throws MetadataManagerException 
    {
        // Call the super class to load the user object
        UserObject userObject = super.getUserObject (relation, driverType);

        // Check to see if we have load a non-null object
        if (userObject != null) {
            Object object = userObject.getObject();

            // Check to see if this object supports number formatting
            if (object instanceof NumberFormat) {
                setNumberFormatString (((NumberFormatType)object).getNumberFormatString());
            }

            // Check to see if this object supports number formatting type
            if (object instanceof NumberFormatType) {
                // Update the MDMeasure with the format number type and string
                setNumberFormatType (((NumberFormatType)object).getNumberFormatType());
            }
        }
        return userObject;
    }
}