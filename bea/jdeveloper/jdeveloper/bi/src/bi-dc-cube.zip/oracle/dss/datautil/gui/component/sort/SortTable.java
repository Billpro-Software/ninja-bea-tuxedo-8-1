/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortTable.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.sort;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Hashtable;
import java.util.Vector;

import javax.swing.AbstractCellEditor;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.sort.resource.SortBundle;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.queryBuilder.ItemsTree;
import oracle.dss.util.ColumnSortInfo;
import oracle.dss.util.DimensionSortInfo;
import oracle.dss.util.HierarchicalQDR;
import oracle.dss.util.QDR;
import oracle.dss.util.QDRSortInfo;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.swing.ComponentNodeComboBoxModel;

import oracle.javatools.icons.OracleIcons;
import oracle.javatools.ui.ComponentWithTitlebar;
import oracle.javatools.ui.ControlBar;

/**
 * @hidden
 *
 * <pre>
 * Class that provides a JTable for displaying and editing Sort information
 * complete with reorder and add/remove functionality.
 * </pre>
 *
 * @author jramanat
 *
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   07/17/08 - Fix Bug 6677244 - QueryBuilder: 'Clear All' button
 *                         is Sort Dialog not disabling.
 *    gkellam   09/11/07 - Fix typo.
 *    gkellam   09/11/07 - Fix Bug 6339671 - QueryBuilder: Sort By/Then By
 *                         mnemonics in sort dialog should be removed.
 *    gkellam   08/24/07 - Bug 6341664 - QueryBuilder: Delete icon in 'Sort'
 *                         gets erroneously disabled.
 *    gkellam   07/16/07 - More DataFilter GUI bug fixes.
 *    gkellam   04/25/07 - Fix Bug 5941845 - Use standard buttons in
 *                         'definition' subsection of BI model flat editor.
 *    gkellam   04/25/07 - Introduce flat buttons.
 *    gkellam   04/24/07 - Addition Sort Dialog updates.
 *    gkellam   04/23/07 - Fix Bug 5941896 - UI changes to sort dialog popup in
 *                         BI Model Flat Editor.
 */
public class SortTable extends JPanel implements TreeCellRenderer {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  public static final String COLUMN = "Column";
  public static final String CROSSTAB = "Crosstab";
    
  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext = null;

  private DefaultMutableTreeNode m_defaultMutableTreeNodeRoot;
  private DefaultTreeModel m_defaultTreeModel;
  private Object m_objRenderer;
  private TreeEditor m_treeEditor;
  private JTree m_jTree;
  private SortPanelModel m_sortPanelModel;
  private JPanel m_jPanelHeader;
  private SortPanel m_sortPanel;
  private JPanel m_jPanelReorder = null;
  private JPanel m_jPanelAddRemove = null;

  private Color m_colorBorder;
  private Color m_colorSelectionBackground;
  private Color m_colorSelectionForeground;

  /**
   * Add button.
   * 
   * @status hidden
   */
  protected SortTableButton m_jButtonAdd = null;

  /**
   * Clear button.
   * 
   * @status hidden
   */
  protected SortTableButton m_jButtonClear = null;

  /**
   * Delete button.
   * 
   * @status hidden
   */
  protected SortTableButton m_jButtonDelete = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  public SortTable (SortPanel sortPanel) {
    m_defaultMutableTreeNodeRoot = new DefaultMutableTreeNode();
    m_treeEditor = new TreeEditor();
    m_sortPanelModel = sortPanel.getModel();
    
    JTable jTableColor = new JTable();
    m_colorBorder = jTableColor.getGridColor();
    m_colorSelectionBackground = jTableColor.getSelectionBackground();
    m_colorSelectionForeground = jTableColor.getSelectionForeground();
    m_sortPanel = sortPanel;

    if (sortPanel != null) {
      setComponentContext (sortPanel.getComponentContext());      
    }

    update();
    initialize();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Specifies the <code>ComponentContext</code> to use.
   * 
   * @param componentContext The <code>ComponentContext</code>
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;
  }

  /**
   * Retrieves the <code>ComponentContext</code> used.
   * 
   * @return The <code>ComponentContext</code>
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }

  public void update() {
    m_defaultMutableTreeNodeRoot.removeAllChildren();
    if (isTableMode()) {
      TableSortPanelModel tableModel = (TableSortPanelModel)m_sortPanelModel;
      ColumnSortInfo[] sorts = tableModel.getColumnSorts();
      
      if (sorts == null || sorts.length == 0) {
        sorts = new ColumnSortInfo[] {new ColumnSortInfo()};
      }

      for (int i = 0; i < sorts.length; i++) {
        m_defaultMutableTreeNodeRoot.add (new DefaultMutableTreeNode (sorts[i], false));
      }
    }
    else if (isDimensionMode()) {
      CrosstabSortPanelModel crosstabModel = (CrosstabSortPanelModel)m_sortPanelModel;
      DimensionSortInfo sort = (DimensionSortInfo)crosstabModel.getSorts();
      
      if (sort == null) {
        sort = new DimensionSortInfo(crosstabModel.getSortItem());
      }
      int count = 0;
      if (sort.getDirection() != null) {
        count = sort.getDirection().length;
      }

      for (int i = 0; i < count; i++) {
        DimensionSort dimensionSort = new DimensionSort();
        dimensionSort.m_direction = sort.getDirection()[i];
        dimensionSort.m_object = sort.getObject()[i];
        dimensionSort.m_type = sort.getType()[i];
        dimensionSort.m_qdr = sort.getQDR()[i];
        m_defaultMutableTreeNodeRoot.add (new DefaultMutableTreeNode (dimensionSort, false));
      }
      if (count == 0) {
        m_defaultMutableTreeNodeRoot.add (new DefaultMutableTreeNode (new DimensionSort(), false));
      }      
    }
    else {
      CrosstabSortPanelModel crosstabModel = (CrosstabSortPanelModel)m_sortPanelModel;
      QDRSortInfo sort = (QDRSortInfo)crosstabModel.getSorts();
      
      if (sort == null) {
        sort = new QDRSortInfo();
      }
      
      int count = 0;
      if (sort.getDirection() != null) {
        count = sort.getDirection().length;
      }
      
      for (int i = 0; i < count; i++) {
        ItemSort itemSort = new ItemSort();
        itemSort.m_direction = sort.getDirection()[i];
        itemSort.m_measure = sort.getMeasure()[i];
        itemSort.m_qdr = sort.getQDR()[i];
        m_defaultMutableTreeNodeRoot.add (new DefaultMutableTreeNode (itemSort, false));
      }
      
      if (count == 0) {
        m_defaultMutableTreeNodeRoot.add (new DefaultMutableTreeNode (new ItemSort(), false));
      }
    }

    if (m_defaultTreeModel != null) {
      m_defaultTreeModel.reload();
    }
  }

  public Object getData() {
    m_jTree.getSelectionModel().clearSelection();
    m_jTree.stopEditing();

    if (isTableMode()) {
      ColumnSortInfo[] sorts = new ColumnSortInfo[m_defaultMutableTreeNodeRoot.getChildCount()];

      for (int i = 0; i < m_defaultMutableTreeNodeRoot.getChildCount(); i++) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i);
        sorts[i] = (ColumnSortInfo)node.getUserObject();
      }

      return sorts;
    }
    else if (isDimensionMode()) {
      CrosstabSortPanelModel crosstabModel = (CrosstabSortPanelModel)m_sortPanelModel;      
      int count = m_defaultMutableTreeNodeRoot.getChildCount();
      
      String[] hierarchy = new String[count];
      int[] type = new int[count];
      int[] direction = new int[count];
      String[] object = new String[count];
      HierarchicalQDR[] qdr = new HierarchicalQDR[count];
      String[] label = new String[count];
      
      for (int i = 0; i < count; i++) {
        DimensionSort dimensionSort = 
          (DimensionSort)((DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i)).getUserObject();
      
        if (!dimensionSort.isValid()) {
          return null;
        }
      
        hierarchy[i] = crosstabModel.getHierarchy();
        type[i] = dimensionSort.m_type;
        direction[i] = dimensionSort.m_direction;
        object[i] = dimensionSort.m_object;
        qdr[i] = dimensionSort.m_qdr;
        label[i] = m_sortPanel.getComponentContext().getDisplayMemberLabelType();
      }
      
      return new DimensionSortInfo (crosstabModel.getSortItem(), hierarchy, type, direction, object, qdr, label);
    }
    else {
      int count = m_defaultMutableTreeNodeRoot.getChildCount();
      int[] direction = new int[count];
      String[] measure = new String[count];
      QDR[] qdr = new QDR[count];
      
      for (int i = 0; i < count; i++) {
        ItemSort itemSort = 
          (ItemSort)((DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i)).getUserObject();
        
        if (!itemSort.isValid()) {
          return null;
        }
      
        direction[i] = itemSort.m_direction;
        measure[i] = itemSort.m_measure;
        qdr[i] = itemSort.m_qdr;
      }
      
      return new QDRSortInfo(((CrosstabSortPanelModel)m_sortPanelModel).getSortItem(), direction, measure, qdr);
    }
  }
  
  public Component getTreeCellRendererComponent (JTree jTree, Object value, 
      boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
    if (isTableMode()) {
      ColumnRenderer renderer = (ColumnRenderer)m_objRenderer;
      renderer.update (jTree, value, selected, expanded, leaf, row, hasFocus);
      return renderer;
    }
    else if (isDimensionMode()) {
      DimensionRenderer renderer = (DimensionRenderer)m_objRenderer;
      renderer.update (jTree, value, selected, expanded, leaf, row, hasFocus);
    }
    else {
      ItemRenderer renderer = (ItemRenderer)m_objRenderer;
      renderer.update (jTree, value, selected, expanded, leaf, row, hasFocus);
      return renderer;
    }

    return null;
  }

  /**
   * Specifies the Add button.
   * 
   * @param jButtonAdd A <code>JButton</code>.
   * 
   * @status hidden
   */
  public void setButtonAdd (SortTableButton jButtonAdd) {
    m_jButtonAdd = jButtonAdd;
  }

  /**
   * Retrieves the Add button.
   *
   * @return <code>JButton</code> which represents the add button.
   * 
   * @status new
   */
  public SortTableButton getButtonAdd() {
    return m_jButtonAdd;
  }

  /**
   * Specifies the Clear button.
   * 
   * @param jButtonClear A <code>JButton</code>.
   * 
   * @status hidden
   */
  public void setButtonClear (SortTableButton jButtonClear) {
    m_jButtonClear = jButtonClear;
  }

  /**
   * Retrieves the Clear button.
   *
   * @return <code>JButton</code> which represents the clear button.
   * 
   * @status new
   */
  public JButton getButtonClear() {
    return m_jButtonClear;
  }

  /**
   * Specifies the Delete button.
   * 
   * @param jButtonDelete A <code>JButton</code>.
   * 
   * @status hidden
   */
  public void setButtonDelete (SortTableButton jButtonDelete) {
    m_jButtonDelete = jButtonDelete;
  }

  /**
   * Retrieves the Delete button.
   *
   * @return <code>JButton</code> which represents the delete button.
   * 
   * @status new
   */
  public JButton getButtonDelete() {
    return m_jButtonDelete;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Select the first node.
   * 
   * @param jTree A <code>JTree</code> to select node for.
   * 
   * @return <code>TreePath</code> associated with the selection.
   * 
   * @status new
   */
  protected static TreePath selectFirstNode (JTree jTree) {
    
    TreePath treePathSelection = null;
    
    if (jTree != null) {
    
      if (jTree.getModel() instanceof DefaultTreeModel) {
        DefaultTreeModel defaultTreeModel = 
          (DefaultTreeModel)jTree.getModel();
    
        if (defaultTreeModel.getRoot() instanceof DefaultMutableTreeNode) {
          // When gaining focus attempt to select the first available node
          DefaultMutableTreeNode defaultMutableTreeNode = 
            (DefaultMutableTreeNode) defaultTreeModel.getRoot();            
          
          // NOTE: Calling root.getFirstChild() when a tree has no children
          // results in an exception, hence the check for children first!
          if (defaultMutableTreeNode.getChildCount() > 0) {
            TreePath treePath = 
              new TreePath (defaultTreeModel.getPathToRoot (defaultMutableTreeNode.getFirstChild()));
         
            jTree.startEditingAtPath (treePath);
          }
        }
    
        treePathSelection = jTree.getSelectionPath();
      }   
    }
  
    return treePathSelection;
  }

  /**
   * Make a <code>ControlBar</code> used to display Value buttons.
   * 
   * @return <code>ControlBar</code> containing the <code>ControlBar</code>. 
   */
  protected ControlBar makeControlBar (final JTree jTree) {
   
    ControlBar controlBar = new ControlBar();
    
    // Add Button
    setButtonAdd (new SortTableButton());

    Utils.initializeIconButton (getButtonAdd(), 
      m_sortPanel.getResourceString (SortBundle.SORTTABLE_PANEL_ADD), 
        OracleIcons.getIcon (OracleIcons.ADD));

    controlBar.add (getButtonAdd());

    getButtonAdd().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        jTree.getSelectionModel().clearSelection();
        jTree.stopEditing();
        
        DefaultMutableTreeNode node = null;
        
        if (isTableMode()) {
          node = new DefaultMutableTreeNode (new ColumnSortInfo(), false);
        }
        else if (isDimensionMode()) {
          node = new DefaultMutableTreeNode (new DimensionSort(), false);
        }
        else {
          node = new DefaultMutableTreeNode (new ItemSort(), false);
        }
        
        m_defaultMutableTreeNodeRoot.add (node);
        m_defaultTreeModel.nodesWereInserted (
          m_defaultMutableTreeNodeRoot, new int[] {m_defaultMutableTreeNodeRoot.getChildCount() - 1});
        
        TreePath treePath = new TreePath (node.getPath());
        jTree.getSelectionModel().addSelectionPath (treePath);
        jTree.startEditingAtPath (treePath);
        updateButtons (jTree);
      }
    });

    // Delete Button
    setButtonDelete (new SortTableButton());

    Utils.initializeIconButton (getButtonDelete(), 
      m_sortPanel.getResourceString (SortBundle.SORTTABLE_PANEL_DELETE), 
        OracleIcons.getIcon (OracleIcons.DELETE));

    controlBar.add (getButtonDelete());

    getButtonDelete().setEnabled (false);
    
    getButtonDelete().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        removeRow (jTree, jTree.getSelectionRows()[0]);
      }
    });

    // Clear Button
    setButtonClear (new SortTableButton());

    Utils.initializeIconButton (getButtonClear(), 
      m_sortPanel.getResourceString (SortBundle.SORTTABLE_PANEL_CLEAR), 
        OracleIcons.getIcon (OracleIcons.CLEAR));

    controlBar.add (getButtonClear());

    getButtonClear().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        jTree.getSelectionModel().clearSelection();
        jTree.stopEditing();
        
        if (m_defaultMutableTreeNodeRoot.getChildCount() > 0) {
          int[] indices = new int[m_defaultMutableTreeNodeRoot.getChildCount()];
        
          for (int i = 0; i < m_defaultMutableTreeNodeRoot.getChildCount(); i++) {
            indices[i] = i;
            
            DefaultMutableTreeNode node = 
              (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i);
            
            if (isTableMode()) {
              node.setUserObject (new ColumnSortInfo());
            }
            else if (isDimensionMode()) {
              node.setUserObject (new DimensionSort());
            }
            else {
              node.setUserObject (new ItemSort());
            }
          }

          m_defaultTreeModel.nodesChanged (m_defaultMutableTreeNodeRoot, indices);
        }

        // When clearing, remove all rows but the first one.        
        if (jTree != null) {
          int nRowCount = jTree.getRowCount();
          for (int nRow = nRowCount - 1; nRow > 0; nRow--) {
            removeRow (jTree, nRow);
          }
        }
      }
    });

    jTree.addTreeSelectionListener (new TreeSelectionListener() {
      public void valueChanged (TreeSelectionEvent treeSelectionEvent) {
        updateButtons (jTree);
      }
    });

    return controlBar;
  }
  
  protected void updateButtons (final JTree jTree) {
    if (jTree != null) {
      int[] rows = jTree.getSelectionRows();
      
      int selectedRow = 
        (rows == null || rows.length == 0) ? -1 : jTree.getSelectionRows()[0];
     
      if (getButtonDelete() != null) { 
        getButtonDelete().setEnabled (selectedRow != -1);
      }
   
      if (getButtonClear() != null) {
        if (jTree.getModel() != null) {
          int nRootChildCount = jTree.getModel().getChildCount (jTree.getModel().getRoot());

          getButtonClear().setEnabled (nRootChildCount > 0);
        }
      }
    }
  }
  
  protected JPanel getReorderPanel (final JTree jTree) {
    if (m_jPanelReorder == null) {
      m_jPanelReorder = new JPanel();
      BoxLayout layout = new BoxLayout(m_jPanelReorder, BoxLayout.Y_AXIS);
      m_jPanelReorder.setLayout(layout);
  
      /*
      Image imageUp = 
        Utils.getImageResource (OracleLookAndFeel.class, "icons/reorderUpLeft.gif");
      final JButton jButtonUp = new JButton (new ImageSetIcon (new ImageStrip (imageUp, ImageSet.STATE_SELECTED)));    
      jButtonUp.setDisabledIcon (new ImageSetIcon(new ImageStrip (imageUp, ImageSet.STATE_DISABLED)));    

      jButtonUp.setToolTipText (m_sortPanel.getResourceString (SortBundle.SORTTABLE_MOVE_UP));
      */

      final JButton jButtonUp = new JButton();
      Utils.initializeIconButton (jButtonUp, 
        m_sortPanel.getResourceString (SortBundle.SORTTABLE_MOVE_UP), 
          OracleIcons.getIcon (OracleIcons.UP));

      jButtonUp.setMargin (new Insets(0,0,0,0));
      jButtonUp.setEnabled (false);

      jButtonUp.addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          int selectedRow = jTree.getSelectionRows()[0];
          jTree.getSelectionModel().clearSelection();
          jTree.stopEditing();
          
          DefaultMutableTreeNode node = 
            (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt (selectedRow);
          
          m_defaultMutableTreeNodeRoot.remove (node);
          m_defaultMutableTreeNodeRoot.insert (node, selectedRow - 1);
          m_defaultTreeModel.nodesChanged (m_defaultMutableTreeNodeRoot, new int[] {selectedRow - 1, selectedRow});
          if (isTableMode()) {
            verifyGroupsReverse();
          }

          TreePath treePath = new TreePath (node.getPath());
          jTree.getSelectionModel().addSelectionPath (treePath);
          jTree.startEditingAtPath (treePath);
        }
      });

      /*
      Image imageDown = 
        Utils.getImageResource (OracleLookAndFeel.class, "icons/reorderDownLeft.gif");
      final JButton jButtonDown = new JButton (new ImageSetIcon (new ImageStrip (imageDown, ImageSet.STATE_SELECTED)));    
      jButtonDown.setDisabledIcon (new ImageSetIcon (new ImageStrip (imageDown, ImageSet.STATE_DISABLED)));    

      jButtonDown.setToolTipText (m_sortPanel.getResourceString (SortBundle.SORTTABLE_MOVE_DOWN));
      */
    
      final JButton jButtonDown = new JButton();
      Utils.initializeIconButton (jButtonDown, 
        m_sortPanel.getResourceString (SortBundle.SORTTABLE_MOVE_DOWN), 
          OracleIcons.getIcon (OracleIcons.DOWN));

      jButtonDown.setMargin (new Insets(0,0,0,0));
      jButtonDown.setEnabled (false);
      
      jButtonDown.addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          int selectedRow = jTree.getSelectionRows()[0];
          jTree.getSelectionModel().clearSelection();
          jTree.stopEditing();
          
          DefaultMutableTreeNode node = (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(selectedRow);
          m_defaultMutableTreeNodeRoot.remove (node);
          m_defaultMutableTreeNodeRoot.insert (node, selectedRow + 1);
          m_defaultTreeModel.nodesChanged (m_defaultMutableTreeNodeRoot, new int[] {selectedRow, selectedRow + 1});
          
          if (isTableMode()) {
            verifyGroupsReverse();
          }

          TreePath treePath = new TreePath (node.getPath());
          jTree.getSelectionModel().addSelectionPath (treePath);
          jTree.startEditingAtPath (treePath);
        }
      });
  
      jTree.addTreeSelectionListener (new TreeSelectionListener() {
        public void valueChanged (TreeSelectionEvent treeSelectionEvent) {
          int[] rows = jTree.getSelectionRows();
          int selectedRow = (rows == null || rows.length == 0) ? -1 : jTree.getSelectionRows()[0];
          jButtonUp.setEnabled (selectedRow > 0);
          jButtonDown.setEnabled (selectedRow > -1 && selectedRow < jTree.getRowCount() - 1);
        }
      });
  
      m_jPanelReorder.add (jButtonUp);
      m_jPanelReorder.add (jButtonDown);
    }

    return m_jPanelReorder;    
  }

  /**
   * Remove the selected from from the specified tree.
   * 
   * @param jTree A <code>JTree</code>
   * @param nSelectedRow
   * 
   * @status hidden
   */
  protected void removeRow (JTree jTree, int nSelectedRow) {
    if (jTree != null) {
   
      jTree.getSelectionModel().clearSelection();
      jTree.stopEditing();
      
      DefaultMutableTreeNode node = 
        (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt (nSelectedRow);
      m_defaultTreeModel.removeNodeFromParent (node);
      
      int newSelectedRow = 
        (int)Math.min (nSelectedRow, m_defaultMutableTreeNodeRoot.getChildCount() - 1);
      
      if (newSelectedRow != -1) {
        node = (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt (newSelectedRow);
        
        TreePath treePath = new TreePath (node.getPath());
        jTree.getSelectionModel().setSelectionPath (treePath);
        jTree.startEditingAtPath (treePath);
      }
      
      updateButtons (jTree);
    }
  }

  protected JLabel makeLabel (String strLabel) {
    JLabel jLabel = null;
    
    if (strLabel != null) {
      jLabel = DataUtils.getLabel (strLabel, SwingConstants.LEFT);
    }

    return jLabel;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
  
  private boolean isTableMode() {
    return m_sortPanelModel.getMode().equals(SortPanelModel.TABLE_MODE);
  }

  private boolean isDimensionMode() {
    return m_sortPanelModel.getMode().equals (
      SortPanelModel.CROSSTAB_MODE) && ((CrosstabSortPanelModel)m_sortPanelModel).isDimension();
  }

  private void initialize() {
    if (isTableMode()) {
      m_objRenderer = new ColumnRenderer();
      m_treeEditor.setRenderer (new ColumnRenderer());
      m_jPanelHeader = new ColumnHeader();
    }
    else if (isDimensionMode()) {
      m_objRenderer = new DimensionRenderer();
      m_treeEditor.setRenderer (new DimensionRenderer());
      m_jPanelHeader = new DimensionHeader();
    }
    else {
      m_objRenderer = new ItemRenderer();
      m_treeEditor.setRenderer (new ItemRenderer());
      m_jPanelHeader = new ItemHeader();
    }

    boolean bAdd = true;

    // jScrollPane including table
    m_defaultTreeModel = new DefaultTreeModel (m_defaultMutableTreeNodeRoot);
    m_jTree = new JTree (m_defaultTreeModel);
    m_jTree.setVisibleRowCount (5);
    m_jTree.getSelectionModel().setSelectionMode (TreeSelectionModel.SINGLE_TREE_SELECTION);
    m_jTree.setRowHeight (25);
    m_jTree.setRootVisible (false);
    m_jTree.setCellRenderer (this);
    m_jTree.setEditable (true);
    m_jTree.setCellEditor (m_treeEditor);
    
    GridBagLayout gridBagLayout = new GridBagLayout();
    GridBagConstraints gridBagConstraints = new GridBagConstraints();    
    setLayout (gridBagLayout);

    // Add/Remove Panel
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 0;
    gridBagConstraints.weightx = 1;
    gridBagConstraints.weighty = 0;
    gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_END;
    
    // addComponent (this, getAddRemovePanel (m_jTree), gridBagLayout, gridBagConstraints);    

    // JScrollPanel Sort Table
    GridBagLayout l = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();

    JScrollPane jScrollPane = 
      new JScrollPane (m_jTree, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    JPanel jPanel = new JPanel(l);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridwidth = 1;
    c.weightx = 1;

    addComponent (jPanel, 
      Box.createHorizontalStrut (jScrollPane.getVerticalScrollBar().getPreferredSize().width), l, c);

    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.weighty = 1;
    gridBagConstraints.insets = new Insets (10, 0, 0, 0);

    addComponent (this, jPanel, gridBagLayout, gridBagConstraints);

    // Add the Control Bar which has the button options to the Members JList
    JLabel jLabel = 
      makeLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_CRITERIA));

    jLabel.setLabelFor (jScrollPane);

    ComponentWithTitlebar componentWithTitlebar = 
      new ComponentWithTitlebar (jScrollPane, jLabel, makeControlBar (m_jTree));
 
    addComponent (this, componentWithTitlebar, gridBagLayout, gridBagConstraints);    

    // addComponent (this, jScrollPane, gridBagLayout, gridBagConstraints);

    // Reorder Panel
    gridBagConstraints.gridx = 1;
    gridBagConstraints.gridy = 1;
    gridBagConstraints.insets = new Insets (0, 10, 0, 0);
    gridBagConstraints.anchor = GridBagConstraints.CENTER;
    addComponent (this, getReorderPanel (m_jTree), gridBagLayout, gridBagConstraints);
  
    selectFirstNode (m_jTree); 
  }

  private static void setItems(Hashtable combos, Object key, Vector items)  {
    JComboBox combo = (JComboBox)combos.get (key);
    
    ComponentNodeComboBoxModel model = 
      (ComponentNodeComboBoxModel)combo.getModel();
    
    model.removeAllElements();
    
    for (int i = 0; i < items.size(); i++) {
      model.addElement(items.get(i));
    }    
  }

  private static void setSelectedItem (Hashtable combos, Object key, Object item) {
    JComboBox combo = (JComboBox)combos.get(key);
    ComponentNodeComboBoxModel model = 
      (ComponentNodeComboBoxModel)combo.getModel();
    model.setSelectedItem(item);    
  }

  /**
   * Adds a component to a Panel using GridBagLayout
   */
  private static void addComponent (JPanel jPanel, Component component, 
      GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    gridBagLayout.setConstraints (component, gridBagConstraints);
    jPanel.add (component);
  }

  private void verifyGroups() {
    boolean endGroup = false;
    Vector nodes = new Vector();
    
    for (int i = 0; i < m_defaultMutableTreeNodeRoot.getChildCount(); i++) {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i);
      ColumnSortInfo info = (ColumnSortInfo)node.getUserObject();
    
      if (!info.isGrouped()) {
        endGroup = true;
      }
      else if (endGroup) {
        info.setGrouped(false);
        nodes.add (new Integer(i));
      }
    }
    
    if (nodes.size() > 0) {
      int[] indices = new int[nodes.size()];
    
      for (int i = 0; i < nodes.size(); i++) {
        indices[i] = ((Integer)nodes.get(i)).intValue();
      }
    
      m_defaultTreeModel.nodesChanged(m_defaultMutableTreeNodeRoot, indices);
    }
  }

  private void verifyGroupsReverse() {
    boolean startGroup = false;
    Vector nodes = new Vector();
    
    for (int i = m_defaultMutableTreeNodeRoot.getChildCount() - 1; i >= 0; i--) {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt(i);
      ColumnSortInfo info = (ColumnSortInfo)node.getUserObject();
      if (info.isGrouped()) {
        startGroup = true;
      }
      else if (startGroup) {
        info.setGrouped (true);
        nodes.add (new Integer(i));
      }
    }
    
    if (nodes.size() > 0) {
      int[] indices = new int[nodes.size()];
      for (int i = 0; i < nodes.size(); i++) {
        indices[i] = ((Integer)nodes.get(i)).intValue();
      }
    
      m_defaultTreeModel.nodesChanged(m_defaultMutableTreeNodeRoot, indices);
    }
  }

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  private class ColumnRenderer extends JPanel {
    private JLabel m_label;
    private Hashtable m_components;
    private final String CRITERIA = "Criteria";
    private final String DIRECTIONS = "Directions";
    private final String GROUP = "Group";
    
    public ColumnRenderer() {
      super(new GridLayout(1, 3, 1, 0));
      m_components = new Hashtable();
      setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, m_colorBorder));

      // Left Side has Sort By/Then By Label and criteria drop down
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      JPanel left = new JPanel(gridBagLayout);
      left.setOpaque(false);
      left.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      gridBagConstraints.anchor = GridBagConstraints.WEST;
      gridBagConstraints.gridwidth = 1;
      gridBagConstraints.weightx = 0;
      gridBagConstraints.fill = GridBagConstraints.NONE;
      
      JLabel sortBy = DataUtils.getLabel (
        m_sortPanel.getResourceString (SortBundle.SORTTABLE_SORT_BY), 
          SwingConstants.LEADING);
      
      JLabel thenBy = DataUtils.getLabel (
        m_sortPanel.getResourceString (SortBundle.SORTTABLE_THEN_BY), 
          SwingConstants.LEADING);

      int width = (int)Math.max (sortBy.getPreferredSize().getWidth(), thenBy.getPreferredSize().getWidth());
      int height = (int)Math.max (sortBy.getPreferredSize().getHeight(), thenBy.getPreferredSize().getHeight());
      
      m_label = new JLabel();
      m_label.setHorizontalAlignment (SwingConstants.CENTER);
      m_label.setPreferredSize (new Dimension (width + 2, height));
      addComponent (left, m_label, gridBagLayout, gridBagConstraints);
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;

      final JComboBox criteria = new JComboBox (new ComponentNodeComboBoxModel());
      addComponent (left, criteria, gridBagLayout, gridBagConstraints);
      m_components.put (CRITERIA, criteria);
      
      m_label.setLabelFor (criteria);
      add (left);
      
      // Middle has direction drop down
      JPanel middle = new JPanel (gridBagLayout);
      middle.setOpaque (false);
      middle.setBorder (BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      JComboBox directions = new JComboBox (new ComponentNodeComboBoxModel());
      addComponent (middle, directions, gridBagLayout, gridBagConstraints);
      m_components.put (DIRECTIONS, directions);
      add (middle);
      
      // Right has group sort
      if (SortTableContext.isGroupDuplicatesAvailable (getComponentContext())) {
        JPanel right = new JPanel(gridBagLayout);
        right.setOpaque(false);
        
        final JCheckBox group = new JCheckBox();
        group.setEnabled (false);
        group.setSelected (false);
        group.setMargin (new Insets(0, 0, 0, 0));
        gridBagConstraints.anchor = GridBagConstraints.CENTER;
        gridBagConstraints.fill = GridBagConstraints.NONE;
        addComponent (right, group, gridBagLayout, gridBagConstraints);
        
        m_components.put (GROUP, group);
        add(right);
        
        group.addActionListener (new ActionListener() {
          public void actionPerformed (ActionEvent actionEvent) {
            boolean selected = group.isSelected();
            int selectedRow = m_jTree.getSelectionRows()[0];
            m_jTree.getSelectionModel().clearSelection();
            m_jTree.stopEditing();
            
            DefaultMutableTreeNode node = 
              (DefaultMutableTreeNode)m_defaultMutableTreeNodeRoot.getChildAt (selectedRow);
            
            if (selected) {
              verifyGroupsReverse();
            }
            else {
              verifyGroups();
            }

            TreePath treePath = new TreePath(node.getPath());
            m_jTree.getSelectionModel().addSelectionPath (treePath);
            m_jTree.startEditingAtPath (treePath);          
          }
        });
      
      criteria.addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          if (criteria.getSelectedItem() == null) {
            group.setEnabled(false);
            group.setSelected(false);
          }
          else {
            group.setEnabled(true);
          }
        }
      });
      }
    }
    
    public void update (JTree jTree, Object value, boolean selected, 
        boolean expanded, boolean leaf, int row, boolean hasFocus) {
      
      if (row != -1) {
        TableSortPanelModel sortModel = (TableSortPanelModel)m_sortPanelModel;
        ColumnSortInfo sortInfo = (ColumnSortInfo)((DefaultMutableTreeNode)value).getUserObject();
        
        String strLabel = 
          m_sortPanel.getResourceString (row == 0 ? SortBundle.SORTTABLE_SORT_BY : SortBundle.SORTTABLE_THEN_BY);
        
        m_label.setDisplayedMnemonic (StringUtils.getMnemonicKeyCode (strLabel));
        m_label.setText (StringUtils.stripMnemonic (strLabel));
        
        setItems (m_components, CRITERIA, sortModel.getSortColumns());
        setSelectedItem (m_components, CRITERIA, sortInfo.getLayerName());
        setItems (m_components, DIRECTIONS, sortModel.getDirections (sortInfo.getLayerName()));
      
        m_label.setLabelFor ((JComboBox)m_components.get (CRITERIA));
      
        int[] sortDirection = sortInfo.getDirection();
        Integer direction = 
          (sortDirection == null || sortDirection.length == 0) ? null : new Integer(sortDirection[0]);
        
        setSelectedItem (m_components, DIRECTIONS, direction);

        JCheckBox jCheckBox = (JCheckBox)m_components.get (GROUP);
        if (jCheckBox != null) {
          if (sortInfo.getLayerName() == null) {
            (jCheckBox).setSelected(false);
            (jCheckBox).setEnabled(false);          
          }
          else {
            (jCheckBox).setSelected(sortInfo.isGrouped());
            (jCheckBox).setEnabled(true);
          }
        }

        setBackground (selected ? m_colorSelectionBackground : jTree.getBackground());
        m_label.setForeground(selected ? m_colorSelectionForeground : jTree.getForeground());
        if (jTree.getWidth() > 0) {
          setPreferredSize (new Dimension(jTree.getWidth(), (int)getPreferredSize().getHeight()));
        }
      }
    }
    
    public Object getValue() {
      JComboBox criteria = (JComboBox)m_components.get(CRITERIA);
      ComponentNode criteriaItem = (ComponentNode)criteria.getSelectedItem();
      JComboBox directions = (JComboBox)m_components.get(DIRECTIONS);
      ComponentNode directionItem = (ComponentNode)directions.getSelectedItem();
      
      String layer = criteriaItem == null ? null : criteriaItem.getID();
      int direction = directionItem == null ? -1 : ((Integer)directionItem.getValue()).intValue();
      ColumnSortInfo sort = new ColumnSortInfo(layer, direction, false);
      sort.setDirection(direction == -1 ? null : new int[] {direction});

      JCheckBox jCheckBox = (JCheckBox)m_components.get (GROUP);
      if (jCheckBox != null) {
        sort.setGrouped(jCheckBox.isSelected());
      }

      return sort;
    }    
  }

  private class ColumnHeader extends JPanel {  
    public ColumnHeader() {
      super(new GridLayout(1, 3, 0, 0));
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.anchor = GridBagConstraints.WEST;

      // Left Side has Sort By/Then By Label and criteria drop down
      JPanel left = new JPanel(gridBagLayout);
      left.setBorder (BorderFactory.createRaisedBevelBorder());

      /*
      JLabel jLabelSort = new JLabel(m_sortPanel.getResourceString (SortBundle.SORTTABLE_TABLE_ITEM));
      addComponent (left, jLabelSort, gridBagLayout, gridBagConstraints);
      add (left);
      */
      
      // Middle has direction drop down
      JPanel middle = new JPanel(gridBagLayout);
      middle.setBorder (BorderFactory.createRaisedBevelBorder());

      /*
      JLabel direction = new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_TABLE_DIRECTION));
      addComponent (middle, direction, gridBagLayout, gridBagConstraints);
      add (middle);
      */
      
      if (SortTableContext.isGroupDuplicatesAvailable (getComponentContext())) {
        // Right has group sort
        JPanel right = new JPanel(gridBagLayout);
        right.setBorder (BorderFactory.createRaisedBevelBorder());
        JLabel group = new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_TABLE_GROUP));
        addComponent (right, group, gridBagLayout, gridBagConstraints);
        add (right);
      }
    }    
  }

  private class ItemRenderer extends JPanel {
    private JLabel m_label;
    private Hashtable m_components;
    private final String CRITERIA = "Criteria";
    private final String DIRECTIONS = "Directions";
    
    public ItemRenderer() {
      super (new GridLayout(1, 2, 1, 0));
      m_components = new Hashtable();
      setBorder(BorderFactory.createMatteBorder (1, 1, 1, 1, m_colorBorder));

      // Left Side has Sort By/Then By Label and criteria drop down
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      
      JPanel left = new JPanel(gridBagLayout);
      left.setOpaque(false);
      left.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      gridBagConstraints.anchor = GridBagConstraints.WEST;
      gridBagConstraints.gridwidth = 1;
      gridBagConstraints.weightx = 0;
      gridBagConstraints.fill = GridBagConstraints.NONE;
      
      JLabel sortBy = 
        new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_SORT_BY));
      
      JLabel thenBy = 
        new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_THEN_BY));
      
      int width = 
        (int)Math.max (sortBy.getPreferredSize().getWidth(), thenBy.getPreferredSize().getWidth());
      
      int height = 
        (int)Math.max (sortBy.getPreferredSize().getHeight(), thenBy.getPreferredSize().getHeight());
      
      m_label = new JLabel();
      m_label.setHorizontalAlignment (SwingConstants.CENTER);
      m_label.setPreferredSize (new Dimension(width + 2, height));
      addComponent (left, m_label, gridBagLayout, gridBagConstraints);
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      
      final JComboBox criteria = new JComboBox (new ComponentNodeComboBoxModel());
      addComponent (left, criteria, gridBagLayout, gridBagConstraints);
      m_components.put (CRITERIA, criteria);
      m_label.setLabelFor (criteria);
      add(left);
      
      // Right has direction drop down
      JPanel middle = new JPanel(gridBagLayout);
      middle.setOpaque (false);
      middle.setBorder (BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      
      JComboBox directions = new JComboBox(new ComponentNodeComboBoxModel());
      addComponent (middle, directions, gridBagLayout, gridBagConstraints);
      m_components.put (DIRECTIONS, directions);
      add(middle);      
    }
    
    public void update (JTree jTree, Object value, boolean selected, 
        boolean expanded, boolean leaf, int row, boolean hasFocus) {
      
      if (row != -1) {
        CrosstabSortPanelModel sortModel = (CrosstabSortPanelModel)m_sortPanelModel;
        ItemSort sortInfo = (ItemSort)((DefaultMutableTreeNode)value).getUserObject();
        if (sortInfo == null) {
          return;
        }
      
        m_label.setText (
          m_sortPanel.getResourceString (row == 0 ? SortBundle.SORTTABLE_SORT_BY : SortBundle.SORTTABLE_THEN_BY));
        setItems (m_components, CRITERIA, sortModel.getSortCriteria());
        setSelectedItem (m_components, CRITERIA, sortInfo.m_measure);
        setItems (m_components, DIRECTIONS, sortModel.getDirections (sortInfo.m_measure));
        setSelectedItem (m_components, DIRECTIONS, sortInfo.m_direction == -1 ? null : new Integer (sortInfo.m_direction));
        setBackground (selected ? m_colorSelectionBackground : jTree.getBackground());
        
        m_label.setForeground(selected ? m_colorSelectionForeground : jTree.getForeground());
        if (jTree.getWidth() > 0) {
          setPreferredSize(new Dimension(jTree.getWidth(), (int)getPreferredSize().getHeight()));
        }
      }
    }
    
    public Object getValue() {
      JComboBox criteria = (JComboBox)m_components.get(CRITERIA);
      ComponentNode criteriaItem = (ComponentNode)criteria.getSelectedItem();
      
      JComboBox directions = (JComboBox)m_components.get(DIRECTIONS);
      ComponentNode directionItem = (ComponentNode)directions.getSelectedItem();
      
      String measure = criteriaItem == null ? null : criteriaItem.getID();
      int direction = directionItem == null ? -1 : ((Integer)directionItem.getValue()).intValue();
      
      ItemSort sort = new ItemSort();
      sort.m_measure = measure;
      sort.m_direction = direction;
      return sort;
    }    
  }
  
  private class ItemHeader extends JPanel {  
    public ItemHeader() {
      super (new GridLayout(1, 2, 0, 0));
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.anchor = GridBagConstraints.WEST;

      // Left Side has Sort By/Then By Label and criteria drop down
      JPanel left = new JPanel(gridBagLayout);
      left.setBorder(BorderFactory.createRaisedBevelBorder());
      JLabel sort = new JLabel(m_sortPanel.getResourceString (SortBundle.SORTTABLE_CROSSTAB_ITEM));
      addComponent(left, sort, gridBagLayout, gridBagConstraints);
      add(left);
      
      // Right has direction drop down
      JPanel right = new JPanel(gridBagLayout);
      right.setBorder(BorderFactory.createRaisedBevelBorder());
      JLabel group = new JLabel(m_sortPanel.getResourceString (SortBundle.SORTTABLE_CROSSTAB_DIRECTION));
      addComponent(right, group, gridBagLayout, gridBagConstraints);
      add(right);
    }    
  }

  private class DimensionRenderer extends JPanel {
    private JLabel m_label;
    private Hashtable m_components;
    private final String CRITERIA = "Criteria";
    private final String DIRECTIONS = "Directions";
    
    public DimensionRenderer() {
      super (new GridLayout (1, 2, 1, 0));
      m_components = new Hashtable();
      setBorder (BorderFactory.createMatteBorder (1, 1, 1, 1, m_colorBorder));

      // Left Side has Sort By/Then By Label and criteria drop down
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      
      JPanel left = new JPanel(gridBagLayout);
      left.setOpaque(false);
      left.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      gridBagConstraints.anchor = GridBagConstraints.WEST;
      gridBagConstraints.gridwidth = 1;
      gridBagConstraints.weightx = 0;
      gridBagConstraints.fill = GridBagConstraints.NONE;
      
      JLabel sortBy = 
        new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_SORT_BY));
      
      JLabel thenBy = 
        new JLabel (m_sortPanel.getResourceString (SortBundle.SORTTABLE_THEN_BY));
      
      int width = 
        (int)Math.max (sortBy.getPreferredSize().getWidth(), thenBy.getPreferredSize().getWidth());
      
      int height = 
        (int)Math.max (sortBy.getPreferredSize().getHeight(), thenBy.getPreferredSize().getHeight());
      
      m_label = new JLabel();
      m_label.setHorizontalAlignment(SwingConstants.CENTER);
      m_label.setPreferredSize(new Dimension(width + 2, height));
      addComponent(left, m_label, gridBagLayout, gridBagConstraints);
      
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      
      final JComboBox criteria = new JComboBox(new ComponentNodeComboBoxModel());
      addComponent (left, criteria, gridBagLayout, gridBagConstraints);
      m_components.put (CRITERIA, criteria);
      m_label.setLabelFor (criteria);
      add (left);
      
      // Right has direction drop down
      JPanel middle = new JPanel (gridBagLayout);
      middle.setOpaque (false);
      middle.setBorder (BorderFactory.createMatteBorder(0, 0, 0, 1, m_colorBorder));
      
      JComboBox directions = new JComboBox (new ComponentNodeComboBoxModel());
      addComponent (middle, directions, gridBagLayout, gridBagConstraints);
      m_components.put (DIRECTIONS, directions);
      add (middle);      
    }
    
    public void update (JTree jTree, Object value, boolean selected, 
        boolean expanded, boolean leaf, int row, boolean hasFocus) {
      
      if (row != -1) {
        CrosstabSortPanelModel sortModel = (CrosstabSortPanelModel)m_sortPanelModel;
        DimensionSort sortInfo = (DimensionSort)((DefaultMutableTreeNode)value).getUserObject();
      
        if (sortInfo == null) {
          return;
        }
      
        m_label.setText (
          m_sortPanel.getResourceString(row == 0 ? SortBundle.SORTTABLE_SORT_BY : SortBundle.SORTTABLE_THEN_BY));
        
        setItems (m_components, CRITERIA, sortModel.getSortCriteria());
        setSelectedItem (m_components, CRITERIA, new Integer(sortInfo.m_type));
        setItems (m_components, DIRECTIONS, sortModel.getDirections(new Integer(sortInfo.m_type)));
        setSelectedItem (m_components, DIRECTIONS, sortInfo.m_direction == -1 ? null : new Integer(sortInfo.m_direction));
        setBackground (selected ? m_colorSelectionBackground : jTree.getBackground());
        m_label.setForeground (selected ? m_colorSelectionForeground : jTree.getForeground());
      
        if (jTree.getWidth() > 0) {
          setPreferredSize (new Dimension (jTree.getWidth(), (int)getPreferredSize().getHeight()));
        }
      }
    }
    
    public Object getValue() {
      JComboBox criteria = (JComboBox)m_components.get(CRITERIA);
      ComponentNode criteriaItem = (ComponentNode)criteria.getSelectedItem();
      
      JComboBox directions = (JComboBox)m_components.get(DIRECTIONS);
      ComponentNode directionItem = (ComponentNode)directions.getSelectedItem();
      String measure = criteriaItem == null ? null : criteriaItem.getID();
      int direction = directionItem == null ? -1 : ((Integer)directionItem.getValue()).intValue();
      
      ItemSort sort = new ItemSort();
      sort.m_measure = measure;
      sort.m_direction = direction;
      return sort;
    }    
  }

  private class DimensionHeader extends JPanel {  
    public DimensionHeader() {
      super(new GridLayout(1, 2, 0, 0));
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      gridBagConstraints.weightx = 1;
      gridBagConstraints.anchor = GridBagConstraints.WEST;

      // Left Side has Sort By/Then By Label and criteria drop down
      JPanel left = new JPanel(gridBagLayout);
      left.setBorder(BorderFactory.createRaisedBevelBorder());
      
      JLabel sort = new JLabel(m_sortPanel.getResourceString("CrosstabItem"));
      addComponent(left, sort, gridBagLayout, gridBagConstraints);
      add(left);
      
      // Right has direction drop down
      JPanel right = new JPanel(gridBagLayout);
      right.setBorder(BorderFactory.createRaisedBevelBorder());
      
      JLabel group = new JLabel(m_sortPanel.getResourceString("CrosstabDirection"));
      addComponent(right, group, gridBagLayout, gridBagConstraints);
      add(right);
    }    
  }

  private class TreeEditor extends AbstractCellEditor implements TreeCellEditor {
    Object m_objRenderer;
    DefaultMutableTreeNode m_editNode;

    public TreeEditor() {      
    }
    
    public void setRenderer(Object renderer) {
      m_objRenderer = renderer;
    }
    
    public Component getTreeCellEditorComponent (JTree jTree, Object value, 
        boolean isSelected, boolean expanded, boolean leaf, int row) {
      
      m_editNode = (DefaultMutableTreeNode)value;
      
      if (isTableMode()) {
        ColumnRenderer renderer = (ColumnRenderer)m_objRenderer;
        renderer.update (jTree, value, true, expanded, leaf, row, true);
        return renderer;
      }
      else if (isDimensionMode()) {
        DimensionRenderer renderer = (DimensionRenderer)m_objRenderer;
        renderer.update (jTree, value, true, expanded, leaf, row, true);
        return renderer;
      }
      else {
        ItemRenderer renderer = (ItemRenderer)m_objRenderer;
        renderer.update (jTree, value, true, expanded, leaf, row, true);
        return renderer;
      }
    }
    
    public Object getCellEditorValue() {
      if (isTableMode()) {
        ColumnRenderer renderer = (ColumnRenderer)m_objRenderer;
        m_editNode.setUserObject(renderer.getValue());
        return m_editNode;
      }
      else if (isDimensionMode()) {
        DimensionRenderer renderer = (DimensionRenderer)m_objRenderer;
        m_editNode.setUserObject(renderer.getValue());
        return m_editNode;
      }
      else {
        ItemRenderer renderer = (ItemRenderer)m_objRenderer;
        m_editNode.setUserObject(renderer.getValue());
        return m_editNode;
      }
    }
  }
  
  private class ItemSort {
    public int m_direction = -1;
    public String m_measure = null;
    public QDR m_qdr = null;
    
    public boolean isValid() {
      return m_direction != -1 && m_measure != null;
    }
  }
  
  private class DimensionSort {
    public int m_direction = -1;
    public String m_object = null;
    public HierarchicalQDR m_qdr = null;
    public int m_type = -1;

    public boolean isValid() {
      return m_direction != -1 && m_type != -1;
    }
  }

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  /**
   * Inner class used to control the buttons in the <code>SortTable</code>.
   * 
   * 
   * @status new
   */
  public class SortTableButton extends JButton {
  
    /////////////////////
    //
    // Constants
    //
    /////////////////////

    /**
     * Perform default button processing, which includes enabling/disabling 
     * as necessary when items are shuttled in the <code>DataFilterPanel</code>.
     * 
     * @status new
     */
    public static final int DEFAULT  = -1;

    /**
     * Disable button regardless of current <code>DataFilterPanel</code> state.
     * 
     * @status new
     */
    public static final int DISABLED = 0;

    /**
     * Enable button regardless of current <code>DataFilterPanel</code> state.
     * 
     * @status new
     */
    public static final int ENABLED  = 1;
  
    /////////////////////
    //
    // Members
    //
    /////////////////////

    /**
     * Button state
     */
    private int m_nState = DEFAULT;

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Retrieves the button state.
     * 
     * @see #DEFAULT
     * @see #DISABLED
     * @see #ENABLED
     * 
     * @return <code>int</code> representing the button state. 
     */
    public int getState() {
      return m_nState;      
    }  

    /**
     * Specifies the button state.
     * 
     * @param nState A <code>int</code> representing the button state.
     * 
     * @see #DEFAULT
     * @see #DISABLED
     * @see #ENABLED
     * 
     */
    public void setState (int nState) {
      m_nState = nState;    
    }  
  
    /**
     * Enables (or disables) the button.
     * 
     * @param bEnabled A <code>boolean</code> which is <code>true</code> to 
     *        enable the button, otherwise <code>false</code>.
     */
    public void setEnabled (boolean bEnabled) {
      switch (getState()) {
        case DISABLED:
          bEnabled = false;
          break;

        case ENABLED:
          bEnabled = true;
          break;        

        case DEFAULT:
        default:
          break;  
      }
      
      super.setEnabled (bEnabled);
    }
  }
}
