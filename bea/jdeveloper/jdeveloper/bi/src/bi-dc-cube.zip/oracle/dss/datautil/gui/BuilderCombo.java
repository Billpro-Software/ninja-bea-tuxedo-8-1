/**
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Cursor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.EventListener;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

import javax.swing.ComboBoxEditor;
import javax.swing.JComboBox;

import oracle.dss.datautil.DimensionMember;

import oracle.dss.util.gui.LightWeightComboBox;

/**
 * @hidden
 * 
 * The component allows users to display a combo box with sticky
 * and non sticky items.
 *
 * @status hidden
 */

public class BuilderCombo extends LightWeightComboBox implements CustomList {

  //-------------------------------------------------------------------
  // PUBLIC CONSTANTS
  //-------------------------------------------------------------------

  /**
   * The "more" sticky item.
   *
   * @status hidden
   */
  public static final String STICKYITEM_MORE = "more";

  /**
   * The "qualify" sticky item.
   *
   * @status hidden
   */
  public static final String STICKYITEM_QUALIFY = "qualify";

  //-------------------------------------------------------------------
  // NON PUBLIC CONSTANTS
  //-------------------------------------------------------------------
  
  /**
   * The default count for the non sticky item list
   *
   * @status private
   */
  private static final int NONSTICKYITEM_DEFCOUNT = 10;

  //-------------------------------------------------------------------
  // NON PUBLIC MEMBERS
  //-------------------------------------------------------------------

  /**
   * The action listener for the items registered by the application developer
   *
   * @status private
   */
  private ActionListener m_userListener = null;

  /**
   * The count of non sticky items in the combo.
   *
   * @status private
   */
  private int m_nNonStickyItemCount = -1;

  /**
   * The non sticky objects in the combo
   *
   * @status private
   */
  private Vector m_listNonStickyItems = null;

  /**
   * The sticky objects in the combo
   *
   * @status private
   */
  private Vector m_listStickyItems = null;

  /**
   * Force addition of the "More..." item.
   *
   * @status private
   */
  private boolean m_bForceMoreItem = false;
  
  /**
   * The previously selected item.
   *  
   * @status private
   */
  private Object m_previouslySelectedItem = null;

  /**
   * The <code>Locale</code> associated with the <code>BuilderCombo</code>.
   *  
   * @status private
   */
  private Locale m_locale = null;
  
  //-------------------------------------------------------------------
  // CONSTRUCTORS
  //-------------------------------------------------------------------

  /**
   * Default constructor.
   *
   * @status hidden
   */
  public BuilderCombo () {
    super ();
        
    initializeMembers ();

    updateEditorCursorState ();
  }            
      
  //-------------------------------------------------------------------
  // PUBLIC METHODS
  //-------------------------------------------------------------------

  /** 
   * @hidden
   * 
   * Add the specified <code>Object</code> to the <code>BuilderCombo</code>
   * and selects it.  If the <code>Object</code> is null, the first
   * entry is selected.
   * 
   * @param objItem A <code>Object</code> to add to the <code>ComboBox</code>.
   *        
   * @return <code>int</code> which represents the selected index.
   * 
   * @status hidden
   */
  public int addSelectedItem (Object objItem) {                                       
    if (objItem == null) {
      // Restore the previous value
      setSelectedIndex (getPreviouslySelectedIndex());
    }
    else {
      int nIndexFound =  
        getIndex (getListUserObjects (CustomList.CUSTOMLIST_NONSTICKYITEM), objItem);
     
      if (nIndexFound < 0) {
        // Replace a non sticky item with the new selection.
        replaceNonStickyItem (objItem, null);
      }
      else {
        // Set the selected index
        setSelectedIndex (nIndexFound);
      }
    }
  
    return getSelectedIndex();
  }

  public void setLocale(Locale locale) {
    m_locale = locale;
  }
  
  /**
   * @hidden
   * Add a user action listener for the combo.
   *
   * @param The action listener for the combo.
   *
   * @status hidden
   */
  public void addUserListener (ActionListener listener) {
    m_userListener = listener;
  }

  /** 
   * @hidden
   * Checks if the item can be added to the combo.
   * 
   * @status hidden
   */
  public boolean canAddItemToCombo (Vector listDefContents, Object item) {                                       
    String defaultItem = null;
    
    if (listDefContents == null)
        return false;
        
    defaultItem = isValidDefaultItem (item);
    if (defaultItem == null)
        return false;
    
    if (defaultItem.equalsIgnoreCase (STICKYITEM_QUALIFY)) {   
      return true;
    }
    else if (defaultItem.equalsIgnoreCase (STICKYITEM_MORE)) {   
      // Add the more item only if the the default list contains more elements
      // than the non sticky elements count.
      int nCount = getNonStickyItemCount ();
      if ((nCount == -1) || (nCount >= listDefContents.size ()))
        return false;
            
      return true;                
    }
    
    return false;
  }
  
  /**
   * @hidden
   * Flush the contents of the combo.
   *   
   * @status hidden
   */
  public void flushContents () {
    if (getItemCount () > 0)
        removeAllItems ();
    
    if (m_listNonStickyItems != null && 
      m_listNonStickyItems.size () > 0) {             
      m_listNonStickyItems.removeAllElements ();
    }

    if (m_listStickyItems != null &&
        m_listStickyItems.size () > 0) {
      m_listStickyItems.removeAllElements ();
    }
  }

  /**
   * @hidden
   * Returns the list of user specified objects. It does not include
   * the default sticky items like the more and qualify
   *
   * @param nTypeFilter Retrieves the list of user specified object
   * filtered by the type i.e. sticky, non sticky or both
   *
   * @return Return the list of user specified objects.
   *
   * @status hidden
   */
  public Vector getListUserObjects (int nTypeFilter) {
    int     nIndex          = -1;
    Item    item            = null;
    Object  userObject      = null;
    String  defaultItem     = null;
    Vector  listUserObjects = null;
    
    listUserObjects = new Vector ();

    if (nTypeFilter == CustomList.CUSTOMLIST_ALLITEMS ||
        nTypeFilter == CustomList.CUSTOMLIST_NONSTICKYITEM) {
      for (nIndex = 0; nIndex < m_listNonStickyItems.size (); nIndex++) {
        item = (Item) m_listNonStickyItems.elementAt (nIndex);
        userObject = item.getUserObject ();
        if (userObject == null)
          continue;

        listUserObjects.addElement (userObject);
      }
    }

    if (nTypeFilter == CustomList.CUSTOMLIST_ALLITEMS ||
        nTypeFilter == CustomList.CUSTOMLIST_STICKYITEM) {
      for (nIndex = 0; nIndex < m_listStickyItems.size (); nIndex++) {
        item = (Item) m_listStickyItems.elementAt (nIndex);
        userObject = item.getUserObject ();
    
        defaultItem = isValidDefaultItem (userObject);
        if (defaultItem == null)
            continue;

        listUserObjects.addElement (userObject);
      }
    }            

    return listUserObjects;
  }

  /**
   * @hidden
   * Returns the user object of the selected item. This method
   *
   * @return Return the user object of the selected item.
   *
   * @status hidden
   */
  public Object getSelectedItem () {
    int     nIndex          = -1;
    Item    item            = null;
    Object  selectedItem    = null;
    String  strSelectedItem = null, strCompare = null;
    Vector  listItems       = null;

    selectedItem = super.getSelectedItem ();
    if (selectedItem == null)
      return null;

    strSelectedItem = selectedItem.toString ();
    if (strSelectedItem == null)
      return null;

    listItems = new Vector ();
    Utils.buildListContents (this, listItems);
    if (listItems == null)
      return null;

    for (nIndex = 0; nIndex < listItems.size (); nIndex++) {
      item = (Item) listItems.elementAt (nIndex);
      if (item == null)
        continue;

      strCompare = item.toString ();
      if (strCompare == null)
        continue;

      if (strSelectedItem.equalsIgnoreCase (strCompare)) {
        // Assume that the selected item was found, unless proven otherwise
        boolean bFound = true;
        
        // gek 08/11/03 Fix Bug 3084207: OW issue: OLAP returning incorrect
        //              dimension list for calculation
        //
        //              For DimensionMember objects, we cannot simply use the
        //              Item.toString() method to check for equality since this
        //              returns the display label instead of the underlying ID.
        //  
        //              As a result, the wrong DimensionMember could be chosen
        //              if the BuilderCombo had duplicate labels (i.e. it would
        //              always choose the first object in the item list with the
        //              specified display label).
        //
        //              As a result, we will perform an additional check when
        //              DimensionMembers are involved.
        //        
        //              Note: The "More..." option is represented by a String
        //                    UserObject

        // Verify that the selected item represents an Item object        
        if (selectedItem instanceof Item) {
          // Retrieve the underlying user object for the selected Item
          Object userObjectSelected = ((Item)selectedItem).getUserObject();

          // Check to see if the user object is a Dimension Member
          if (userObjectSelected instanceof DimensionMember) {
            // Retrieve the underlying user object for the current Item
            Object userObject = item.getUserObject();

            // Verify that the DimensionMembers are really the same
            if (!userObjectSelected.equals (userObject)) {
              // Do not exit loop if the DimensionMembers do not match
              bFound = false;     
            }
          }
        }

        // Return the selected user object
        if (bFound) { 
          return item.getUserObject ();
        }
      }
    }

    return selectedItem;
  }

  /**
   * @hidden
   * Initialize the contents of the combo.
   *
   * @status hidden
   */
  public void initializeContents () {
    if (getItemCount () > 0)
        removeAllItems ();
    
    addContents (m_listStickyItems, CustomList.CUSTOMLIST_ITEMPOS_NORTH);
    addContents (m_listNonStickyItems, CustomList.CUSTOMLIST_ITEMPOS_DEFAULT);
    addContents (m_listStickyItems, CustomList.CUSTOMLIST_ITEMPOS_SOUTH);

    // Set the initial selected index to 0 if the item count > 0.
    if (getItemCount () > 0)
      setSelectedIndex (0);

    // Add the action listener, if any was registered with us.
    if (m_userListener != null)
      addActionListener (m_userListener);
 
    // gek 03/25/04 Fix Bug 3473653 - UI: Expand dropdowns to accommodate 10+
    //              items without scrolling.
    int nStickyItems = (m_listStickyItems != null) ? m_listStickyItems.size() : 0;
    setMaximumRowCount (NONSTICKYITEM_DEFCOUNT + nStickyItems);
    }

  /**
   * @hidden
   * Initialize the members of the object.
   *
   * @status hidden
   */
  public String isValidDefaultItem (Object item) {
    if (item == null || !(item instanceof String))
        return null;
    
    if (((String) item).equalsIgnoreCase (STICKYITEM_MORE) || 
        ((String) item).equalsIgnoreCase (STICKYITEM_QUALIFY))
      return (String) item;

    return null;
  }
  
  /**
   * @hidden
   * 
   * Retrieve the previously selected item.
   * 
   * @return <code>Object</code> which represents the previously selected item.
   * 
   * @status hidden
   */
 	public Object getPreviouslySelectedItem() {
    return m_previouslySelectedItem;
 	}  

  /**
   * @hidden
   * 
   * Sets the selected item.
   * 
   * @param anObject A <code>Object</code> which represents the item to select.
   *
   * @status hidden
   */
  public void setSelectedItem (Object anObject) {
    int     nIndex          = -1;
    Item    item            = null;
    Item    selectedItem    = null;
    String  strSelectedItem = null;
    String  strCompare      = null;
    Vector  listItems       = null;

    setPreviouslySelectedItem (getSelectedItem());
    strSelectedItem = anObject.toString ();
    if (strSelectedItem == null)
        return;

    listItems = new Vector ();
    Utils.buildListContents (this, listItems);
    if (listItems == null)
        return;

    for (nIndex = 0; nIndex < listItems.size (); nIndex++) {
      item = (Item) listItems.elementAt (nIndex);
      if (item == null)
          continue;

      strCompare = item.toString ();
      if (strCompare == null)
          continue;

      if (strSelectedItem.equalsIgnoreCase (strCompare)) {
        selectedItem = item;

        // gek 06/07/02 Fix Bug 2401061: Duplicate dropdown items prevents
        //              arrow key navigation of dropdown.
        //
        //              Only break out of the loop if we have found the specific
        //              item requested.  This allows us to find objects that share the
        //              the same string value but represent different objects
        //              (for example two different measures which share the same
        //              name 'Sales').
        //
        //              If for some reason we can't find the actual object, simply
        //              return the object with the associated string value.
        if (anObject == item)
          break;
      }
    }

    if (selectedItem != null) {
      super.setSelectedItem (selectedItem);
    }
    else {
      super.setSelectedItem (anObject);
    }
  }

  /**
   * @hidden
   * Enables or disables this component, depending on the value of the
   * parameter <code>bEnabled</code>. An enabled component can respond to user
   * input and generate events. Components are enabled initially by default.
   *
   * @param <code>bEnabled</code> If <code>true</code>, this component is
   * enabled; otherwise this component is disabled.
   *
   * @status hidden
   */
  public void setEnabled (boolean bEnabled) {
    super.setEnabled (bEnabled);

    updateEditorCursorState ();
  }

  /**
   * @hidden
   * Determines whether the addition of the "More..." item is forced or not.
   *
   * @param bForceMoreItem a <code>boolean</code> value which is
   *        <code>true</code> when the user wishes to forcr the addition of the
   *        "More..." item and <code>false</code> otherwise.
   * @status hidden
   */
  public void setForceMoreItem (boolean bForceMoreItem) {
    m_bForceMoreItem = bForceMoreItem;
  }

  /**
   * @hidden
   * Determines whether the addition of the "More..." item is forced or not.
   *
   * @return <code>boolean</code> which is <code>true</code> when the
   *         addition of the "More..." item is forced and <code>false</code>
   *         otherwise.
   * @status hidden
   */
  public boolean isForceMoreItem () {
    return m_bForceMoreItem;
  }

  //-------------------------------------------------------------------
  // Start implementation of CustomList interface
  //-------------------------------------------------------------------

  /**
   * @hidden
   * Adds an item of specified type to the list. Registers the listener
   * with the item.
   *
   * @param anObject The user object to associate with the item.
   * @param itemType The type of the item.
   * @param listener The listener for the item. This implementation disregards
   * the listener parameter.
   *
   * @status hidden
   */
  public boolean addItem (Object anObject, int itemType, EventListener listener) {
    return addItem (anObject, itemType,
      CustomList.CUSTOMLIST_ITEMPOS_DEFAULT, listener);
  }
  
  /**
   * @hidden
   * Adds an item of specified type to the list. Registers the listener 
   * with the item.
   *
   * @param anObject The user object to associate with the item.
   * @param itemType The type of the item.
   * @param itemPosition The relative position of the item
   * @param listener The listener for the item.
   *
   * @status hidden
   */
  public boolean addItem (Object anObject, int itemType,
                           int itemPosition, EventListener listener) {                             
    String  defaultItem = null, strItemName = null;
    
    // Validation...
    if (anObject == null || itemType < 0)
        return false;
        
    if (itemType == CustomList.CUSTOMLIST_STICKYITEM) {
      if (itemPosition == CustomList.CUSTOMLIST_ITEMPOS_DEFAULT)
          itemPosition = CustomList.CUSTOMLIST_ITEMPOS_SOUTH;
          
      defaultItem = isValidDefaultItem (anObject);
      if (defaultItem != null) {
        if (defaultItem.equalsIgnoreCase (STICKYITEM_MORE))
            strItemName = Utils.getIntlString ("moreItem", m_locale);
        else if (defaultItem.equalsIgnoreCase (STICKYITEM_QUALIFY))
            strItemName = Utils.getIntlString ("qualifyItem", m_locale);
      }                
      else {
        strItemName = anObject.toString ();
      }
      
      m_listStickyItems.addElement (
        new Item (anObject, strItemName, itemPosition));
    }            
    else if (itemType == CustomList.CUSTOMLIST_NONSTICKYITEM) {
      if (m_nNonStickyItemCount != -1 && 
           m_listNonStickyItems.size () >= m_nNonStickyItemCount)
          return false;

      m_listNonStickyItems.addElement (new Item (
                                        anObject, 
                                        anObject.toString (),
                                        CustomList.CUSTOMLIST_ITEMPOS_DEFAULT));
    }           
    
    return true;
  }
  
  /**
   * @hidden
   * Returns the count of non sticky items in the list.
   *   
   * @return The count of non sticky items in the list.
   *
   * @status hidden
   */
  public int getNonStickyItemCount () {
    return m_nNonStickyItemCount;
  }
  
  /**
   * @hidden
   * Replaces one item in the non sticky group with the specified item. Registers
   * the listener with the item.
   *
   * @param anObject The user object to associate with the item.
   * @param listener The listener for the item. This implementation disregards
   * the listener parameter.
   *
   * @status hidden
   */
  public void replaceNonStickyItem (Object anObject, EventListener listener) {
    int nIndex = -1, nExtraItemCount = -1;

    if (anObject == null)
        return;

    // gek 03/09/04 Fix Bug 3199964: Index calc dim members listed multiple
    //              times after wizard next and back.
    //
    //              Make sure that we remove any previous entries before we
    //              add the "new" one on top.
    for (int nPos = 0; nPos < m_listNonStickyItems.size(); nPos++) {
      if (isSameDimensionMember (m_listNonStickyItems.get (nPos), anObject)) {
        m_listNonStickyItems.remove (nPos);
        break;
      }
    }

    m_listNonStickyItems.insertElementAt (
                         new Item (anObject, anObject.toString (), 
                         CustomList.CUSTOMLIST_ITEMPOS_DEFAULT), 0);
    if (m_nNonStickyItemCount == -1) {
      initializeContents();
      return;
    }

    // Remove extra items from the non sticky item list            
    if (m_listNonStickyItems.size () > m_nNonStickyItemCount) {
      nExtraItemCount = m_listNonStickyItems.size () - m_nNonStickyItemCount;
      for (nIndex = 0; nIndex < nExtraItemCount; nIndex++)
        m_listNonStickyItems.removeElementAt (m_listNonStickyItems.size () - 1);
    }

    // Remove any previous listener registered with the combo. The initializeContents
    // method will update the listener after updating the combo contents...
    if (m_userListener != null)
      removeActionListener (m_userListener);

    // Re-initialize the contents of the combo here.
    initializeContents ();
  }

  /**
   * @hidden
   * Specifies the count of non sticky items in the list.
   *
   * @param itemCount The count of non sticky items in the list.
   *
   * @status hidden
   */
  public void setNonStickyItemCount (int itemCount) {
    m_nNonStickyItemCount = itemCount;
  }

  //-------------------------------------------------------------------
  // End implementation of CustomList interface
  //-------------------------------------------------------------------

  //-------------------------------------------------------------------
  // NON PUBLIC METHODS
  //-------------------------------------------------------------------

  /**
   * @hidden
   */
  protected void setPreviouslySelectedItem (Object objItem) {
    boolean bUpdate = true;

    // Check for More...
    if (objItem != null) {
      if (objItem instanceof Item) {
        if (((Item)objItem).getUserObject().toString().equalsIgnoreCase (STICKYITEM_MORE)) {
          bUpdate = false;
        }
      }    
      else {
        if (objItem.toString().equalsIgnoreCase (STICKYITEM_MORE)) {
          bUpdate = false;
        }
      }
    }

    if (bUpdate) {    
      m_previouslySelectedItem = objItem;
      setPreviouslySelectedIndex (getSelectedIndex());
    }
  }  

  /** 
   * @hidden
   * 
   * Add the specified <code>Object</code> to the <code>BuilderCombo</code>
   * and selects it.  If the <code>Object</code> is null, the first
   * entry is selected.
   * 
   * @param objItem A <code>Object</code> to add to the <code>ComboBox</code>.
   * @param bUseString A <code>boolean</code> which is true when the 
   *        <code>String</code> representation of the objects should be used
   *        and <code>false</code> otherwise.
   *        
   * @return <code>int</code> which represents the selected index.
   * 
   * @status hidden
   */
  protected int addSelectedItem (Object objItem, boolean bUseString) {                                       
    if (objItem == null) {
      setSelectedIndex (0);
    }
    else {
      int nIndexFound =  
        getIndex (getListUserObjects (CustomList.CUSTOMLIST_NONSTICKYITEM), 
          objItem, bUseString);
     
      if (nIndexFound < 0) {
        // Replace a non sticky item with the new selection.
        replaceNonStickyItem (objItem, null);
      }
      else {
        // Set the selected index
        setSelectedIndex (nIndexFound);
      }
    }
  
    return getSelectedIndex();
  }

  /**
   * @hidden
   * 
   * Determine if the specified <code>Object</code> already exists in the
   * <code>Vector</code> of objects to search.
   * 
   * @param vobjItems A <code>Vector</code> of objects to search.
   * @param objItem A <code>Object</code> to search for.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the 
   *         <code>Object</code> is found in the <code>Vector</code> of objects 
   *         to search box and <code>false</code> otherwise.
   *         
   * @status hidden
   */
  protected int getIndex (Vector vobjItems, Object objItem) {
    return getIndex (vobjItems, objItem, false);  
  }

  /**
   * @hidden
   * 
   * Determine if the specified <code>Object</code> already exists in the
   * <code>Vector</code> of objects to search.
   * 
   * @param vobjItems A <code>Vector</code> of objects to search.
   * @param objItem A <code>Object</code> to search for.
   * @param bUseString A <code>boolean</code> which is true when the 
   *        <code>String</code> representation of the objects should be used
   *        and <code>false</code> otherwise.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the 
   *         <code>Object</code> is found in the <code>Vector</code> of objects 
   *         to search box and <code>false</code> otherwise.
   *         
   * @status hidden
   */
  protected int getIndex (Vector vobjItems, Object objItem, boolean bUseString) {
    int nIndexFound = -1;

    if ((vobjItems != null) && (objItem != null)) {
      for (int nIndex = 0; nIndex < vobjItems.size(); nIndex++) {
        Object objCurrent = vobjItems.elementAt (nIndex);
        
        if (objCurrent != null) {
          if (bUseString) {
            if (objItem.toString().equals (objCurrent.toString())) {
              nIndexFound = nIndex;
              break;
            }
          }
          else {
            if (objItem.equals (objCurrent)) {
              nIndexFound = nIndex;
              break;
            }
          }
        }
      }
    }
    
    return nIndexFound;
  }

  /**
   * @hidden
   * 
   * Determines if the two specified objects represent the same 
   * <code>DimensionMember</code> object.
   * 
   * @param objItem A <code>Object</code> which represents an <code>Item</code>
   *        which contains a <code>DimensionMember</code>.
   * @param objDimensionMember A <code>Object</code> which represents a
   *        <code>DimensionMember</code>.
   *   
   * @return <code>boolean</code> which is <code>true</code> if the two specified 
   *         objects represent the same <code>DimensionMember</code> object and
   *         <code>false</code> otherwise.  
   *   
   * @status hidden
   */
  protected boolean isSameDimensionMember (Object objItem, Object objDimensionMember) { 
    boolean bResult = false;
    
    if ((objItem instanceof Item) && (objDimensionMember instanceof DimensionMember)) {
      Item item = (Item) objItem;
      DimensionMember dimensionMember = (DimensionMember) objDimensionMember;      
   
      // Check if the labels are the same
      if (item.toString().equals (dimensionMember.toString())) {
        // Check to see if the IDs are the same
        objItem = item.getUserObject();

        if (objItem instanceof DimensionMember) {
          if (((DimensionMember)objItem).getObject().equals (dimensionMember.getObject())) {
            bResult = true;
          }
        }
      }
    }

    return bResult;
  }

  /**
   * Adds content to the combo box.
   *   
   * @status private
   */
  private void addContents (Vector listItems, int nPositionFilter) {
    int         nIndex      = -1;
    Item        item        = null;
    Object      userObject  = null;

    if (listItems == null || listItems.size() == 0)
        return;
        
    for (nIndex = 0; nIndex < listItems.size (); nIndex++) {
      item = (Item) listItems.elementAt (nIndex);
      if (item == null)
          continue;
      
      if (item.getItemPosition() == nPositionFilter) {
          addItem (item);
      }
    }
  }
  
  /**
   * Initialize the members of the object.
   *   
   * @status private
   */
  private void initializeMembers () {
    m_nNonStickyItemCount = NONSTICKYITEM_DEFCOUNT;

    m_listNonStickyItems = new Vector ();
    m_listStickyItems = new Vector ();
  }

  /**
   * Set the cursor of the combo box editor based on the enabled/disabled state of 
   * the combo box
   *
   * @status private
   */
   private void updateEditorCursorState () {
    ComboBoxEditor  editor          = null;
    Component       editorComponent = null;
    
    editor = getEditor ();
    
    if (editor != null)
        editorComponent = editor.getEditorComponent ();
        
    if (editorComponent == null)
        return;

    if (isEnabled ()) {
      editorComponent.setCursor (Cursor.getPredefinedCursor (Cursor.TEXT_CURSOR));
    }         
    else {
      editorComponent.setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
    }
  }
   
  //-------------------------------------------------------------------
  // Inner Classes
  //-------------------------------------------------------------------
  
  private class Item extends Object {
    private int     m_nItemPosition = -1;
    private Object  m_userObject    = null;    
    private String  m_strDisplay    = null;
      
    public Item (Object userObject, String strDisplay, int nItemPosition) {
      m_userObject = userObject;
      m_strDisplay = strDisplay;
      m_nItemPosition = nItemPosition;
    }
      
    public int getItemPosition () {
      return m_nItemPosition;
    }
  
    public String toString () {
      return m_strDisplay;
    }
  
    public Object getUserObject () {
      return m_userObject;
    }            
  }
}
