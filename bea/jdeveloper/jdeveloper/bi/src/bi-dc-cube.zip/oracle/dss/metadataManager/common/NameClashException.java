/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * Indicates an attempt to give two different objects the same name.
 *
 * @status Reviewed
 */
public class NameClashException extends MetadataManagerException
{
    private boolean m_isRebindAllowed = true;
    
    /**
     * @hidden
     * Constructor.
     *
     * @param name The name that was attempted.
     * @param driverType The type of driver that initiates this exception.
     *
     * @status hidden
     */
    public NameClashException(String name, String driverType)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new Object[]{name}, driverType, null);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param name The name that was attempted.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public NameClashException(String name, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new Object[]{name}, driverType, prevException);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param name The name that was attempted.
     * @param locale The locale to use for the message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public NameClashException(String name, Locale locale, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new Object[]{name}, locale, driverType, prevException);
    }

    /**
     * @hidden
     * The bind method could result in <code>BINameAlreadyBoundException</code> if
     * there is already an object bounded by the specified name.  This can be
     * remedied by calling the rebind method to override the existing object.
     * However, in the case where the existing object is not a <code>Persistable</code>
     * object, the rebind would still failed.
     * This method determines if the object can be rebind successfully without causing a 
     * <code>BINameAlreadyBoundException</code>
     */
    public boolean isRebindAllowed()
    {
        return m_isRebindAllowed;
    }

    /**
     * @hidden
     * Internal.  Sets the isRebindAllowed flag.
     */
    public void setRebindAllowed(boolean isRebindAllowed)
    {
        m_isRebindAllowed = isRebindAllowed;    
    }
}
