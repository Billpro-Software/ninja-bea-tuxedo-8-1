/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.io.Serializable;
import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;

/**
 * @hidden
 */
public class MeasureDimensionFilter implements BIFilter, Serializable {
	public MeasureDimensionFilter() {
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome
   *
   * @return  <code>true</code> if the search result should be included
   *          <code>false</code> otherwise
   * @status New
   */
  public boolean evaluate (BISearchResult searchResult) {
    // Check for null search results
    if (searchResult == null)
      return false;

    if (MM.CALCULATION.equals(searchResult.getObjectType())) {
      return true;
    }
    // Convert result to an MDObject.
    if (searchResult instanceof MetadataManagerSearchResultImpl) {
      Object objResult = searchResult.getObject();
      if ((objResult != null) && (objResult instanceof MDObject)) {
        MDObject mdObject = (MDObject)objResult;
        if (mdObject.getSubObjectType() == MM.MEASURE_DIMENSION) {
          return false;
        }
      }
    }
    return true;
  }
}