/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;
import java.util.Locale;



/**
 * Indicates an attempt to read an object which has been modified since the 
 * start of a consistent read set.
 *
 * To handle this exception in particular, catch it before you catch a
 * <code>NamingException</code>.
 * 
 * @status New
 */
public final class ReadConsistencyException extends BINamingException
{
   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    * bundle that does not have a language extension in its
    * name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params A replacement for each token in the <code>String</code>
    * that will be retrieved from the resource bundle.
    */
    public ReadConsistencyException(Class resBundleClass, String errorCode, String[] params, Locale locale)
    {
        super(resBundleClass, errorCode, params, locale, null);
    }
  
}
