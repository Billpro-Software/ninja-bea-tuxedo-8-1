/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/DataTableIterator.java /bibeans_root/12 2008/09/23 00:36:26 bmoroze Exp $ */

/* Copyright (c) 2006, 2008, Oracle and/or its affiliates. All rights reserved.*/

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/11/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/DataTableIterator.java /bibeans_root/12 2008/09/23 00:36:26 bmoroze Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.bi.client;

import java.util.Hashtable;

import oracle.dss.dataSource.client.CloneableRowIterator;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.transform.DataCell;
import oracle.dss.util.transform.DataCellInterface;
import oracle.dss.util.transform.DataTable;
import oracle.dss.util.transform.MemberCell;
import oracle.dss.util.transform.MemberInterface;
import oracle.dss.util.transform.TransformException;

/**
 * @hidden
 * RowIterator for DataTables
 */
public class DataTableIterator extends Object implements CloneableRowIterator
{
    protected DataTable m_dt = null;
    protected long m_row = 0;
    protected Hashtable<String, String> m_layerNameLookup = new Hashtable<String, String>();
    protected Hashtable<String, String> m_IDLookup = new Hashtable<String, String>();
    protected String[] m_cols = null;
        
    public DataTableIterator(DataTable dt, Hashtable<String, String> layerNameLookup, Hashtable<String, String> IDLookup)
    {
        super();
        m_dt = dt;
        m_layerNameLookup = layerNameLookup;
        m_IDLookup = IDLookup;
    }
   
    public Object clone()
    {
        return new DataTableIterator(m_dt, m_layerNameLookup, m_IDLookup);
    }
    
    public String[] getColumns()
    {
        return getColumns(LayerMetadataMap.LAYER_METADATA_NAME);
    }
    
    public Object getValue(String column) throws TransformException
    {
        if (m_row > 0)
        {
            DataCell data = m_dt.getRow(m_row-1).getCell(getRealLayerID(column));
            if (data != null)
                return data.getDataCellInterface();
            MemberInterface member = m_dt.getRow(m_row-1).getMember(getRealLayerID(column));
            if (member != null)
                return member.getValue();
        }
        return null;
    }
    
    public String[] getColumns(String type)
    {
        if (m_cols == null)
        {
            // Construct this once out of the lookup tables
            m_cols = m_dt.getColumns();
        }
        // m_cols is the original ID, but is that what's wanted?
        if (type.equals(LayerMetadataMap.LAYER_METADATA_NAME))
            return m_cols;
        // If not, must use the lookup table
        String[] colRet = new String[m_cols.length];
        String temp = null;
        for (int i = 0; i < m_cols.length; i++)
        {
            temp = m_IDLookup.get(m_cols[i]);
            colRet[i] = temp == null ? m_cols[i] : temp;
        }
        return colRet;
    }
    
    public boolean hasMoreRows() throws TransformException
    {
        return m_row < m_dt.getRowCount();            
    }
    
    public boolean nextRow() throws TransformException
    {
        boolean hasMore = hasMoreRows();
        if (hasMore)
        {
            m_dt.getRow(m_row);
            m_row++;
        }
        return hasMore;
    }
    
    public void close() throws TransformException
    {        
    }
    
    private String getRealLayerID(String column)
    {
        if (m_layerNameLookup != null)
        {
            String newVal = m_layerNameLookup.get(column);
            if (newVal != null)
                return newVal;
        }
        return column;
    }
    
    public MemberInterface getMember(String column) throws TransformException
    {
        if (m_row > 0)
        {
            return m_dt.getRow(m_row-1).getMember(getRealLayerID(column));
        }
        return null;
    }
            
    public DataCellInterface getCell(String column) throws TransformException
    {
        if (m_row > 0)
            return m_dt.getRow(m_row-1).getCell(getRealLayerID(column)).getDataCellInterface();
        return null;
    }
}