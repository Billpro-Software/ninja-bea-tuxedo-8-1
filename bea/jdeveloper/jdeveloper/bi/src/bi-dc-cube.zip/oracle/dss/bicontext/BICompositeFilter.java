/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

/**
 * A custom filter for filtering each of the search results after the main search
 * is finished using the intersection of several filters.
 *
 * @hidden
 * @status New
 */
public class BICompositeFilter implements BIFilter {

  /**
   * @hidden
   * 
   * Array of <code>BIFilter</code> objects to apply to each search.
   *
   * @status hidden
   */
  private BIFilter[] m_filters;
  
  /**
   * @hidden
   * 
   * Constructor
   * 
   * @param filters A <code>BIFilter</code> array of filters to apply to each 
   *        search.
   *
   * @status hidden
   */
  public BICompositeFilter (BIFilter[] filters) {
    m_filters = filters;
  }

  /**
   * Determines whether to include a particular search result in the
   * final search outcome.
   *
   * @param   result The result to evaluate.
   * 
   * @return  <code>true</code> if <code>result</code> should be included,
   *          <code>false</code> otherwise
   * @status New
   */
  public boolean evaluate (BISearchResult result) {
    if (m_filters != null && m_filters.length > 0) {
      for (int i = 0; i < m_filters.length; i++) {
        if (m_filters[i] != null && !m_filters[i].evaluate(result)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Specifies an array of filters to apply to each search.
   *
   * @param filters A <code>BIFilter</code> array of filters to apply to each 
   *        search.
   *
   * @status New
   */
  public void setBIFilters (BIFilter[] filters) {
    m_filters = filters;
  }
  
  /**
   * Retrieves an array of filters to apply to each search.
   *
   * @return <code> BIFilter[]</code> of filters to apply to each search.
   * 
   * @status New
   */
  public BIFilter[] getBIFilters () {
    return m_filters;
  }
}