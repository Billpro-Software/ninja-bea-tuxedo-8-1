/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFilterPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.BorderLayout;

import oracle.dss.datautil.gui.component.ComponentContext;


/**
 * <pre>
 * <code>DataFilterPanel</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/26/07 - Fix Bug 6051430 - DataFilter GUI: Missing support
 *                         for between and not between RangeDataFilter.
 *    gkellam   07/08/07 - Implement new BI Model UI for DataFilters.
 *    gkellam   07/05/07 - Continue updating DataFilter GUI.
 *    gkellam   05/10/07 - Fix Bug 5901482 - Missing Top/Bottom filters in the
 *                         QB add filter GUI.
 *    gkellam   05/08/07 - Fix Bug 6037092 - QueryBuilder: Add data filter
 *                         dialog should display warning message.
 *    gkellam   04/21/07 - Remove JTabbedPanes.
 *    gkellam   04/04/07 - Modify m_treeListComboMembers retrieval.
 *    gkellam   03/18/07 - Simplify TreeListComboMembers handling.
 *    gkellam   03/14/07 - Fix Bug 5918743 - QueryBuilder: 'Edit DataFilter'
 *                         dialog, 3rd drop down not initialized.
 *    gkellam   03/12/07 - Fix Bug 5766378 - QUERYBUILDER: ITEM DROP DOWN IN
 *                         NEW/EDIT DATA FILTER NOT WORKING.
 *    gkellam   03/10/07 - Allow ComponentContext to be passed to DataFilter
 *                         GUI components.
 *    gkellam   03/09/07 - Fix Bug 5918712 - QUERYBUILDER: 'ADD' ICON IN
 *                         'QUERIES' TAB SHOULD BE RENAMED.
 *    gkellam   03/09/07 - Update data filter members when a parameter is
 *                         added.
 *    gkellam   03/07/07 - Update DataFilter from Parameter GUI results.
 *    gkellam   03/05/07 - Tweak TreeListCombo mouse/selection handling.
 *    gkellam   03/04/07 - Continue parameter GUI tweaks.
 *    gkellam   03/02/07 - Enhance parameter GUI.
 *    gkellam   03/02/07 - Update parameter GUI.
 *    gkellam   03/01/07 - Tweak operator parameter label.
 *    gkellam   02/28/07 - Add ability to parameterize operators.
 *    gkellam   02/28/07 - Tweak Parameter string generation.
 *    gkellam   02/27/07 - Explore various options for Parameter GUI.
 *    gkellam   02/25/07 - Continue Parameter parsing support.
 *    gkellam   02/24/07 - Tweak measure support.
 */
public class DataFilterPanel extends BaseDataFilterPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public DataFilterPanel (ComponentContext componentContext) {
    this (componentContext, null);
  }

  public DataFilterPanel (ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
    super (new BorderLayout());
    setDataFilterPanelModel (dataFilterPanelModel);
    initGUI (componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * @status hidden
   */
  public static void main (String[] strArguments) {
    DataFilterPanel dataFilterPanel = new DataFilterPanel (null);
    dataFilterPanel.refresh();
    QBUtils.makeFrame (dataFilterPanel);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private void initGUI (ComponentContext componentContext) {
    setContext (componentContext);
    setOperatorDisplays (makeOperatorDisplays());
    setConditionPanel (makeConditionPanel());
    add (getConditionPanel(), BorderLayout.NORTH);
  }
}
