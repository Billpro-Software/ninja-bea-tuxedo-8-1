/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;

import oracle.dss.util.NumberFormat;
import oracle.dss.util.NumberFormatType;
import oracle.dss.util.Utility;

/**
 * A client-side representation of a measure in an analytic workspace.
 * An <code>MDMeasure</code> provides, to a java client, information about
 * a measure in the workspace.
 * <P>
 * A measure represents data in an analytic workspace.
 * The data is usually numeric and additive.
 * Examples of measures are Sales, Cost, and Profit.
 *
 * @status Reviewed
 */
public class MDMeasure extends MDObject implements NumberFormatType {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Data type classes
  private static final int CLASS_UNKNOWN      = -1;
  private static final int CLASS_NUMERIC      = 0;
  private static final int CLASS_NON_NUMERIC  = 1;

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   *
   * @hidden
   *
   */
  public MDMeasure() {
    setObjectType(MM.MEASURE);
  }

  /**
   * @hidden
   * Constructor.
   * You should construct an <code>MDMeasure</code> only if you are creating
   * a custom measure.
   * <p>
   * For measures that are stored in the analytic workspace, you should
   * call the <code>getMeasure</code> or <code>getMeasures</code> method
   * of another object.
   * For example, if you want a measure when you are constructing a query,
   * call the <code>MetadataManagerServices.getMeasure</code> method, in
   * a call such as the following:
   * <pre>
   * MetadataManagerServices mmgr = new MetadataManager();
   * MDMeasure mSales = mmgr.getMeasure("NAME", "Sales");
   * </pre>
   * To get the measures that are dimensioned by a dimension, call the
   * <code>MDDimension.getMeasures</code> method.
   *
   * @param mmServices   The <code>MetadataManagerServices</code> that this
   *                     measure exists in.
   * @param measureName  The name of this measure.
   * @param parent       The object that contains this object.
   *
   * @see MetadataManagerServices#getMeasure(String, String)
   * @see MDDimension#getMeasures
   *
   * @status hidden
   */
  public MDMeasure (MetadataManagerServices mmServices, String measureName, 
                    MDObject parent) {
    super (mmServices, measureName, parent);
    setObjectType(MM.MEASURE);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the folder that contains this <code>MDMeasure</code>.
   *
   * @return The folder that contains this <code>MDMeasure</code>.
   *
   * @throws MetadataManagerException If the connection fails during the
   *          execution of this method or if there is a problem retrieving
   *          objects from the server.
   *
   * @status Reviewed
   */
  public MDFolder getFolder() throws MetadataManagerException {
    MDObject parent = getParent();
    if ( (parent != null) && (parent instanceof MDFolder) ) {
      return (MDFolder)parent;
    }
    return null;
  }

  /**
   * Retrieves the folders that contain this measure.
   *
   * @return The folders that contain this measure.
   *
   * @throws MetadataManagerException If the connection fails during the
   *          execution of this method or if there is a problem retrieving
   *          objects from the server.
   *
   * @status Reviewed
   */
  public MDFolder[] getFolders() throws MetadataManagerException {
    Vector folders = new Vector();
    MDFolder parent = getFolder();
    if (parent != null) {
      folders.addElement(parent);
    }

    MDFolder[] relatives = MDFolder.getFolderArray(getRelatives(MM.FOLDER));
    if (relatives != null) {
      for (int i=0; i<relatives.length; i++) {
        folders.addElement(relatives[i]);
      }
    }
    return (MDFolder[])Utility.copyVectorToArray(folders);
  }
    
  /**
   * Specifies a folder that contains this measure.
   * Call this method on a custom measure only.
   * You cannot change the location of a measure that is stored in the
   * analytic workspace.
   *
   * @param folder A <code>MDFolder</code> object that this
   *                measure uses.
   *
   * @return A constant that represents success or failure.
   *         Possible constants are listed in the See Also section.
   *
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @status Reviewed
   */
  public int setFolder(MDFolder folder) throws MetadataManagerException {
    if (getParent() == null) {
      return setParent(folder);
    }
    else {
      return setRelative(folder, MM.FOLDER);
    }
  }
    
  /**
   * Retrieves the dimensions of this measure.
   * For example, for a Sales measure, the dimensions might be Product,
   * Time, and Geography.
   *
   * @return The dimensions of this measure.
   *
   * @throws MetadataManagerException If the connection fails during the
   *          execution of this method or if there is a problem retrieving
   *          objects from the server.
   *
   * @status Reviewed
   */
  public MDDimension[] getDimensions() throws MetadataManagerException {
    return MDDimension.getDimensionArray(getRelatives(MM.DIMENSION));
  }

  /**
   * Specifies the dimensions of this measure.
   * Call this method on a custom measure only.
   * You cannot change the dimensionality of a measure that is stored in the
   * analytic workspace.
   *
   * @param dimensions An array of <code>MDDimension</code> objects, one
   *                   for each dimension of this measure.
   *
   * @return A constant that represents success or failure.
   *         Possible constants are listed in the See Also section.
   *
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @status Reviewed
   */
  public int setDimensions(MDDimension[] dimensions) {
    if ( (dimensions == null) || (dimensions.length == 0) ) {
      return MDU.FAILURE;
    }
    for (int i=0; i<dimensions.length; i++) {
      setRelative(dimensions[i], MM.DIMENSION);
    }
    return MDU.SUCCESS;
  }

  /**
   * Retrieves the data type of this measure.
   *
   * @return A constant that represents the data type.
   *         The valid constants are listed in the See Also section.
   *
   * @see MM#BOOLEAN
   * @see MM#SHORT
   * @see MM#INTEGER
   * @see MM#LONG
   * @see MM#FLOAT
   * @see MM#DOUBLE
   * @see MM#STRING
   *
   * @status Reviewed
   */
  public String getDataType() {
    return getStrPropertyValue(MM.DATA_TYPE);
  }

  /**
   * @hidden
   * Specifies the data type of this measure.
   * Call this method on a custom measure only.
   * You cannot change the data type of a measure that is stored in the
   * analytic workspace.
   *
   * @param dataType A constant that represents the data type.
   *                 Valid constants are defined in the <code>MM</code>
   *                 class, and they are listed in the See Also section.
   *
   * @return A constant that represents success or failure.
   *           The valid constants are defined in the <code>MDU</code> class,
   *           and they are listed in the See Also section.
   *
   * @see MM#BOOLEAN
   * @see MM#SHORT
   * @see MM#INTEGER
   * @see MM#LONG
   * @see MM#FLOAT
   * @see MM#DOUBLE
   * @see MM#STRING
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @status hidden
   */
  public int setDataType (String dataType) {
    if (dataType == null)
      return MDU.FAILURE;
          
    if ((!dataType.equals(MM.BOOLEAN))  &&
        (!dataType.equals(MM.SHORT))    &&
        (!dataType.equals(MM.INTEGER))  &&
        (!dataType.equals(MM.LONG))     &&
        (!dataType.equals(MM.FLOAT))    &&
        (!dataType.equals(MM.DOUBLE))   &&
        (!dataType.equals(MM.DATE))     &&
        (!dataType.equals(MM.STRING))) {
      return (MDU.FAILURE);
    }

    setStrPropertyValue(MM.DATA_TYPE, dataType, MDU.UI_ALL);
    return MDU.SUCCESS;
  }

  /**
   *
   * @hidden
   *
   */
  public static MDMeasure[] getMeasureArray(MDObject[] objects) {
    if (objects == null)
      return null;
  
    MDMeasure[] measures = new MDMeasure[objects.length];
    for (int i=0; i<objects.length; i++) {
      measures[i] = (MDMeasure)objects[i];
    }
    
    return measures;    
  }
  
  /**
   *
   * @hidden
   *
   */
  public static MDMeasure[] getMeasureArray(PropertyBag[] propertyBag) {
    if (propertyBag == null)
      return null;
    MDMeasure[] measures = new MDMeasure[propertyBag.length];
    for (int i=0; i<propertyBag.length; i++) {
      measures[i] = (MDMeasure)propertyBag[i];
    }
    
    return measures;    
  }

  /**
   * @deprecated
   * @hidden
   * Specifies an object that depends on this object.
   * Calling this method specifies the object in an array of dependent objects.
   * The relation between the two objects is "DEPENDENT".
   *
   * NOTE: Setting twice with the same position will replace the object.
   *
   * @param mdObject  The dependent object.
   * @param intPosition The index into the array of dependent objects in
   *                     which to place the dependent object.
   *                   If an object is already at this position, then
   *                   <code>mdObject</code> replaces that object.
   *
   * @return      A constant that indicates whether the object type was
   *              successfully set. Valid constants are listed in the See Also
   *              section.
   *
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @status hidden
   */
  public int setDependent(MDObject mdObject, int intPosition) {
    // Call the base class
    int nResult = super.setDependent (mdObject, intPosition);

    // Update the dimensionality of the MDMeasure based on the newly added
    // dependent object
    if (nResult == oracle.dss.metadataUtil.MDU.SUCCESS) {
      updateDimensionality();
    }

    // Return the result
    return nResult;
  }

  /**
   * @deprecated
   * @hidden
   * Updates the dimensionality of custom <code>MDMeasure</code> objects based
   * on their dependent measures.
   *
   * @return <code>MDDimension[]</code> which represents the measure's
   *         updated dimensionality.
   *
   */
  public MDDimension[] updateDimensionality () {
    // Make sure that we have a custom measure
    String strSubObjectType = getSubObjectType();
    if ((strSubObjectType == null) || (!strSubObjectType.equals(MM.CALCULATION)))
      return null;

    // Create our MDDimension hash table
    // Note: We are using a hash table here instead of a vector so that
    //       we don't unnecessarily duplicate dimensions
    Hashtable hashTableDimensions = new Hashtable();

    // List if MDDimensions
    MDDimension[] mdDimensions = null;

    try {
      // Get our list if dependent objects
      MDObject[] mdObjects = getDependents();

      // If we have no dependent objects, simply return null.
      if (mdObjects == null)
        return null;

      // Loop through all of the dependent MDMeasures
      for (int nIndex = 0; nIndex < mdObjects.length; nIndex++) {

        // Retrieve the current dependent MDMeasure
        if (mdObjects[nIndex] != null && mdObjects[nIndex] instanceof MDMeasure) {
          MDMeasure mdMeasure = (MDMeasure)mdObjects [nIndex];

          // Update the data type based on each new measure
          updateDataType (mdMeasure.getDataType());

          // Retrieve the dimensionality of the current measure
          mdDimensions = mdMeasure.getDimensions();

          if (mdDimensions != null) {
            // Add this dimensionality to the overall list
            for (int nPosition = 0; nPosition < mdDimensions.length; nPosition++) {
              hashTableDimensions.put (mdDimensions [nPosition].getUniqueID(),
                mdDimensions [nPosition]);
            }
          }
        }
      }
    }

    catch (MetadataManagerException mme) {
      // If we generated an exception, return null
      return null;
    }

    // Check to see if we have actually retrieved any dimensions
    if (!hashTableDimensions.isEmpty()) {
      int nIndex = 0;

      // Allocate enough space for our MDDimension
      mdDimensions = new MDDimension [hashTableDimensions.size()];

      // Enumerate over each dimension in the hash table
      Enumeration enumeration = hashTableDimensions.elements();
      while (enumeration.hasMoreElements ()) {
        // Retrieve the dimension at the current position
        MDDimension mdDimension = (MDDimension)enumeration.nextElement();

        // Add it to the dimension array
        mdDimensions [nIndex++] = mdDimension;
      }

      // Update the measure's dimensionality
      setDimensions (mdDimensions);
    }

    return mdDimensions;
  }

  /////////////////////
  //
  // Public Overidden Methods
  //
  /////////////////////

  /**
   * @deprecated
   * @hidden
   * Retrieves the <code>UserObject</code> for this object.
   * If the user object is not available locally, then this method
   * attempts to retrieve the user object from the underlying driver.
   *
   * @param relation  The relationship between this object and its user object.
   * @param driverType  The type of driver that the user object uses.
   *
   * @throws  MetadataManagerException If the connection fails during the
   *          execution of this method or if there is a problem retrieving
   *          the object from the server.
   *
   * @return  The <code>UserObject</code> for this object, or <code>null</code>
   *          if there is no <code>MetadataManagerServices</code> set for
   *          this object, or if <code>relation</code> or <code>driverType</code>
   *          is <code>null</code>.
   *
   * @status hidden
   */
  public UserObject getUserObject (String relation, String driverType) throws MetadataManagerException {
    // Call the super class to load the user object
    UserObject userObject = super.getUserObject (relation, driverType);

    // Check to see if we have load a non-null object
    if (userObject != null) {
      Object object = userObject.getObject();

      // Check to see if this object supports number formatting
      if (object instanceof NumberFormat) {
        setNumberFormatString (((NumberFormatType)object).getNumberFormatString());
      }

      // Check to see if this object supports number formatting type
      if (object instanceof NumberFormatType) {
        // Update the MDMeasure with the format number type and string
        setNumberFormatType (((NumberFormatType)object).getNumberFormatType());
      }
    }

    return userObject;
    }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Updates the <code>MDMeasure</code> data type based on current value and
   * the specified one.
   *
   * @param  mdMeasure The <code>MDMeasure</code> object to update.
   * @param  strDataType The new data type.
   *
   * @return A constant that represents success or failure.
   *         The valid constants are defined in the <code>MDU</code> class,
   *         and they are listed in the See Also section.
   *
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @status New
   */
  private int updateDataType (String strDataType){

    if (strDataType != null) {
      // Get the current data type
      String strDataTypeCurrent = getDataType();

      // Get the classes of each data type
      int nClassCurrent = getClass (strDataTypeCurrent);
      int nClass = getClass (strDataType);

      // If the data type classes don't match, we have an indeterminante
      // state
      if (nClassCurrent != nClass) {
        if ((nClassCurrent != CLASS_UNKNOWN) || (nClass == CLASS_UNKNOWN))
          return setDataType (MM.INDETERMINATE);
        else
          return setDataType (strDataType);
      }

      // Check the numeric classes, promoting if necessary
      if (nClass == CLASS_NUMERIC) {
        if (strDataTypeCurrent.equals (MM.SHORT)) {
          if (strDataType.equals (MM.INTEGER)) {
            return setDataType (MM.INTEGER);
          }

          if (strDataType.equals (MM.LONG)) {
            return setDataType (MM.LONG);
          }

          if (strDataType.equals (MM.FLOAT)) {
              return setDataType (MM.FLOAT);
          }

          if (strDataType.equals (MM.DOUBLE)) {
            return setDataType (MM.DOUBLE);
          }
        }

        if (strDataTypeCurrent.equals (MM.INTEGER)) {
          if (strDataType.equals (MM.LONG)) {
            return setDataType (MM.LONG);
          }

          if (strDataType.equals (MM.FLOAT)) {
            return setDataType (MM.FLOAT);
          }

          if (strDataType.equals (MM.DOUBLE)) {
            return setDataType (MM.DOUBLE);
          }
        }

        if (strDataTypeCurrent.equals (MM.LONG)) {
          if (strDataType.equals (MM.FLOAT)) {
            return setDataType (MM.FLOAT);
          }

          if (strDataType.equals (MM.DOUBLE)) {
            return setDataType (MM.DOUBLE);
          }
        }

        if (strDataTypeCurrent.equals (MM.FLOAT)) {
          if (strDataType.equals (MM.DOUBLE)) {
            return setDataType (MM.DOUBLE);
          }
        }
      }
      else if (nClass == CLASS_NON_NUMERIC) {
        // Check non-numeric classes
        if (strDataTypeCurrent.equals (MM.BOOLEAN)) {
          if (!strDataType.equals (MM.BOOLEAN)) {
            return setDataType (MM.INDETERMINATE);
          }
        }

        if (strDataTypeCurrent.equals (MM.STRING)) {
          if (!strDataType.equals (MM.STRING)) {
            return setDataType (MM.INDETERMINATE);
          }
        }

        if (strDataTypeCurrent.equals (MM.DATE)) {
          if (!strDataType.equals (MM.DATE)) {
            return setDataType (MM.INDETERMINATE);
          }
        }
      }
    }

  return MDU.SUCCESS;
  }

  /**
   * @hidden
   *
   * Returns the class of of the specified data type.
   *
   * @param  strDataType The new data type.
   *
   * @status New
   */
  public int getClass (String strDataType) {
    int nClass = CLASS_UNKNOWN;

    if (strDataType == null)
        return nClass;

    if (strDataType.equals (MM.SHORT) ||
      strDataType.equals (MM.INTEGER) ||
      strDataType.equals (MM.LONG)    ||
      strDataType.equals (MM.FLOAT)   ||
      strDataType.equals (MM.DOUBLE)) {
      return CLASS_NUMERIC;
    }

    if (strDataType.equals (MM.BOOLEAN) ||
      strDataType.equals (MM.STRING)  ||
      strDataType.equals (MM.DATE)) {
      return CLASS_NON_NUMERIC;
    }

    return nClass;
  }

  //-------------------------------------------------------------------
  // Start implementation of NumberFormatType interface
  //-------------------------------------------------------------------

  /**
   * Specifies how a number should be formatted based on the specified format
   * mask.
   *
   * @param strNumberFormatString A <code>String</code> value which contains the
   *        number format mask.
   *
   * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
   *
   * @status New
   */
  public void setNumberFormatString (String strNumberFormatString) {
    if (strNumberFormatString != null)
      setStrPropertyValue(MM.NUMBER_FORMAT_STRING, strNumberFormatString);
  }

  /**
   * @hidden
   *
   * Specifies the number format type associated with the number format string.
   *
   * @param strNumberFormatType A <code>String</code> that represents the type of
   *        number format string.
   *
   * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_TYPE
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   *
   * @see oracle.dss.util.NumberFormatType#setNumberFormatString
   *
   * @status New
   */
  public void setNumberFormatType (String strNumberFormatType) {
    if (strNumberFormatType != null)
      setStrPropertyValue (MM.NUMBER_FORMAT_TYPE, strNumberFormatType);
  }

  /**
   * @hidden
   *
   * Specifies how a number should be formatted based on its number format type
   * and associated number format string.
   *
   * @param strNumberFormatString A <code>String</code> value which contains the
   *        number format mask.
   * @param strNumberFormatType A <code>String</code> that represents the type of
   *        number format string.
   *
   * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
   * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_TYPE
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   *
   * @status New
   */
  public void setNumberFormat (String strNumberFormatString, String strNumberFormatType) {
    if (strNumberFormatString != null) {
      setStrPropertyValue(MM.NUMBER_FORMAT_STRING, strNumberFormatString);
    }

    if (strNumberFormatType != null) {
      setStrPropertyValue(MM.NUMBER_FORMAT_TYPE, strNumberFormatType);
    }
  }

  /**
   * Retrieves the number format mask that specifies how a number should be
   * formatted.
   *
   * @return <code>String</code> which is the number format mask being used.
   *
   * @see oracle.dss.metadataManager.common.MM#NUMBER_FORMAT_STRING
   *
   * @status New
   */
  public String getNumberFormatString() {
    return getStrPropertyValue(MM.NUMBER_FORMAT_STRING);
  }

  /**
   * @hidden
   *
   * Retrieves the number format type associated with the number format string.
   *
   * @return <code>String</code> which is the number format type being used.
   *         If no value is set, the default value is returned which is
   *         <code>NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS</code>.
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   *
   * @see oracle.dss.util.NumberFormat#getNumberFormatString
   *
   * @status New
   */
  public String getNumberFormatType() {
    String strNumberFormatType = getStrPropertyValue(MM.NUMBER_FORMAT_TYPE);
    if (strNumberFormatType != null)
      return strNumberFormatType;

    return NumberFormatType.NUMBER_FORMAT_TYPE_ORACLE;
  }

  //-------------------------------------------------------------------
  // End implementation of NumberFormatType interface
  //-------------------------------------------------------------------
}
