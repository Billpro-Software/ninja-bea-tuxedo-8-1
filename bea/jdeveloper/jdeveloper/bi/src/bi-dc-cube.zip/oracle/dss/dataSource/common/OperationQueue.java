/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.Enumeration;
import java.util.EventObject;
import java.util.Vector;
import oracle.dss.util.Operation;

/**
 * @hidden
 * Class responsible for queueing up operations to execute in order in batch.
 * This is the client-side-only version of the op queue.
 */
public class OperationQueue extends BaseOperationQueue
{
    // Event stackadd (pre events)
    protected transient EventList    eventList  = new EventList();

    // Listener list
    private transient ListenerLists m_listeners    = new ListenerLists();
    
    /**
     * Class constructor.
     *
     * @param b <code>true</code> if auto update is to be on     
     * @param qm QueryManager containing this op queue's query
     * @param id id of query using queue
     * @param l list of listeners to fire pending events to
     *
     */
    public OperationQueue(boolean b, QueryManager qm, Query q, ListenerLists l)
    {
        super(b, qm, q);
        
        try
        {
            //setProxy(d);
        }
        catch (Throwable e)
        {
        }
                
        m_listeners = l;
    }    

    /**
     * Add an operation to the end of the queue.
     *
     * @param o operation to add
     * @param e event that goes with it (may be null)
     * @return return value from last operation if auto updating
     * @throws any middle tier exception
     *
     */
/*    public Object addOperation(Operation o, QueryEvent e) throws Throwable {
        // Put event on stack
        eventList.addElement(e);
        
        // Put operation on stack and execute, if necessary
        return super.addOperation(o);
    }
*/    
    // Insert the given operation at the given location in the queue
    public Object insertOperation(Operation o, int pos) throws Throwable
    {
        return super.addOperation(o, pos);
    }
    
    /**
     * Put an operation on the queue with a list of events.
     *
     * @param o operation to add
     * @param el list of events to add
     * @throws any middle tier exception
     *
     */
    public Object addOperation(Operation o, EventList el) throws Throwable {
        // Put events on stack
        el.setParentList(eventList);
        eventList.addElement(el);
        
        // Put operation on stack and execute, if necessary
        return super.addOperation(o);
    }
    
    /**
     * Clean out queue without sending items.
     *
     */
    public void flush() {
        m_heldOps = false;
        super.flush();
        eventList.removeAllElements();
    }
    
    /**
     * Remove the referenced operation from the queue.
     *
     * @param o operation to remove
     *
     */
/*    public void removeOperation(Operation o) {
        int index = m_operations.indexOf(o);
        if (index > -1) {
            super.removeOperation(o);
            eventList.removeElementAt(index);
        }
        if (m_operations.size() == 0)
        {
            m_heldOps = false;
        }                
    }*/
    
    /**
     * Execute contents of operation queue.
     * Send the contents to the middle tier.
     *
     * @return return value from last call in queue
     * @throws Throwable any middle tier exception
     */
    public Object update() throws Throwable {
        if (isHoldForProxy())
        {
            return null;
        }
        m_heldOps = false;
        // Go through events and remove operations that get consumed
        Vector consumed = new Vector();
        eventList.fire(m_client, getQuery(), consumed, false);
        
        Boolean b;
        // Remove all the operations that were consumed
        ConsumedOperations cOp = null;
        Operation op = null;
        for (int operation = 0; operation < consumed.size(); operation++) {
            b = (Boolean)consumed.elementAt(operation);
            if (b.booleanValue())
            {
                if (cOp == null)
                {
                    cOp = new ConsumedOperations();
                }
                op = (Operation)m_operations.elementAt(operation);
                super.removeOperation(op);
                cOp.addElement(op);
            }
        }
        // Transfer the operation list
/*        Operation o;
        Object retVal = null;
        Enumeration ops = getOperations().elements();
        while (ops.hasMoreElements()) {
            o = (Operation)ops.nextElement();
            retVal = o.execute(getQuery());
            
        }*/

        final String evalOpName = "setEvaluateCursor";

        Operation o;
        Object retVal = null;
        Operation lastOperation = getLastCursorGeneratingOperation();
        Enumeration oplist = getOperations().elements();
        boolean cursorEvalSetting = getQuery().isEvaluateCursor();
        if (lastOperation != null && !lastOperation.getName().equals(evalOpName))
        {
            // Temporarily shut off cursors
            getQuery().getPropertySupport().setEvaluateCursor(false);
        }

        while (oplist.hasMoreElements()) {
            o = (Operation)oplist.nextElement();
            if (lastOperation != null && lastOperation == o && !lastOperation.getName().equals(evalOpName))
            {
                // Turn cursor eval back to original setting
                getQuery().getPropertySupport().setEvaluateCursor(cursorEvalSetting);
            }

            retVal = o.execute(getQuery());
        }

        // Turn cursor evaluation back on
        if (lastOperation != null && !lastOperation.getName().equals(evalOpName))
        {
            getQuery().getPropertySupport().setEvaluateCursor(cursorEvalSetting);
        }
        
        // blm - Selection code moved to dvt-olap
/*        if (retVal != null && retVal instanceof ValidationObject)
        {
            // Make sure to convert query references to tokens
            ((ValidationObject)retVal)._convertTokens();
        }*/

        // Flush the real queue before sending
        flush();
                
        if (getQuery().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS) && !getQuery().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_ASYNCHRONOUS))
            getQuery().fireEvents();
        
        if (retVal == null && cOp != null)
        {
            // Return the consumed operations flag
            return cOp;
        }
        return retVal;
    }    

    // Normally this would be whatever the MT piggyback manager wants it to
    // be, but here's where we hand out our event list
    protected EventObject[] getEventList()
    {
        EventList newEvents = (EventList)m_events.clone();
        
        EventObject[] evts = new EventObject[newEvents.size()];
        for (int i=0; i<newEvents.size(); i++)
        {
            evts[i] = (EventObject)newEvents.elementAt(i);
        }

        // Clean out the list for next time
        m_events = new EventList();
        
        return evts;
    }
}
