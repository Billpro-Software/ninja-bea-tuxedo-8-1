/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataManager.common.MDContentBag;
import oracle.dss.metadataManager.common.MetadataManagerEvent;

/**
 * Describes changes to metadata.
 * To listen for these events, implement the
 * <code>MetadataManagerListener</code> interface, and register the
 * listener by calling <code>MetadataManager.addListener</code> method.
 *
 * @see MetadataManagerListener
 * @see oracle.dss.metadataManager.client.MetadataManager#addListener
 *
 * @status Reviewed
 */
public class MetadataModifiedEvent extends MetadataManagerEvent
{
    /**
     * An <code>MDObject</code> has been added to its parent or has
     * been replaced in its parent.
     *
     * @status Reviewed
     */
    public static final int SET = 0;

    /**
     * An <code>MDObject</code> has been removed from its
     * parent.
     *
     * @status Reviewed
     */
    public static final int REMOVE = 1;

    /**
     * All the children have been removed from the <code>MDObject</code>.
     *
     * @status Reviewed
     */
    public static final int REMOVEALL = 2;

    /**
     * An <code>MDObject</code> has been copied to another folder.
     *
     * @status Reviewed
     */
    public static final int COPY = 3;

    /**
     * An <code>MDObject</code> has been moved to another folder.
     *
     * @status Reviewed
     */
    public static final int MOVE = 4;

    /**
     * The properties of an <code>MDObject</code> has been modified.
     *
     * @status New
     */
    public static final int MODIFY = 5;

    /**
     * The depedents of an <code>MDObject</code> has been loaded
     * during the retrieve of UserObject
     *
     * @status New
     */
    public static final int DEPENDENT_LOAD = 6;

    /**
     * An <code>MDObject</code> has been renamed.
     *
     * @status new
     */
    public static final int RENAME = 7;

    /**
     * @hidden
     * An referenced <code>MDObject</code> has been set.
     *
     * @status new
     */
    public static final int SET_REFERENCE = 8;

    /**
     * @hidden
     * An referenced <code>MDObject</code> has been removed.
     * 
     * @status new
     */
    public static final int REMOVE_REFERENCE = 9;

    public static final int RUNTIME_DATASOURCE_REFRESH = 10;

    private int m_op;
    private boolean m_isPiggyback = false;

  /**
   * @hidden
   * Constructor that specifies the modificaton.
   *
   * @param source         The source of this event.
   * @param isConsumable  <code>true</code> if the event can be consumed,
   *                      <code>false</code> if it cannot be consumed.
   * @param modifiedObject  The object that has been modified.
   * @param operation      A constant that indicates how the object has
   *                       been modified.
   *
   * @see #SET
   * @see #COPY
   * @see #MOVE
   * @see #REMOVE
   * @see #REMOVEALL
   *
   * @status hidden
   */
  public MetadataModifiedEvent( Object source, boolean isConsumable, Object modifiedObject, int operation ) {
    super( source, isConsumable, modifiedObject );
    m_op = operation;
  }

  /**
   * @hidden
   * Constructor that does not specify the modification.
   *
   * @param source         The source of this event.
   * @param isConsumable  <code>true</code> if the event can be consumed,
   *                      <code>false</code> if it cannot be consumed.
   * @param modifiedObject  The object that has been modified.
   *
   * @status hidden
   */
  public MetadataModifiedEvent( Object source, boolean isConsumable, Object modifiedObject ) {
    super( source, isConsumable, modifiedObject );
  }

  /**
   * Indicates whether the modified object contains a specified object.
   * This method indicates whether the modified object is a parent or
   * ancestor of the specified object.
   * You can call this method to find out if an object is affected by the
   * modification.
   *
   * @param listenerObject The object that might be affected by the modification.
   *
   * @return      <code>true</code> if <code>listenerObject</code> is affected
   *                                 by the change,
   *              <code>false</code> if it is not.
   *
   * @status Reviewed
   */
  public boolean isParentModified( Object listenerObject )
                                                throws MetadataManagerException
  {
     if( object == null || listenerObject == null )
        return false;
     if( (object instanceof MDContentBag) && (listenerObject instanceof MDObject) ){
        PropertyBag[] propertyBag = ((MDContentBag)object).getContents();
        PropertyBag tempPropertyBag;
        for( int i = 0; i < propertyBag.length; i++ ) {
           tempPropertyBag = propertyBag[i];
           if( (tempPropertyBag instanceof MDObject) &&
                traverseTheTree( (MDObject)tempPropertyBag, (MDObject)listenerObject ) )
              return true;
        }
     }
     else if( (object instanceof MDObject) && (listenerObject instanceof MDObject) )
         return traverseTheTree( (MDObject)object, (MDObject)listenerObject );
     return false;
  }

  /**
   * Recursive method to traverse the tree.
   *
   * @param modifiedObject     One of the modified objects
   * @param listenerParent     Either listener or it's parent
   *
   * @return      <code>true</code> modified object is parent of listener
   *              <code>false</code> modified object is not parent of listener
   * @status private
   */
  private boolean traverseTheTree( MDObject modifiedObject,
                                   MDObject listenerParent )
                                   throws MetadataManagerException
  {
     if( modifiedObject == null || listenerParent == null )
        return false;

     MDObject parentObject = listenerParent.getParent();

     if( modifiedObject.getObjectID() == parentObject.getObjectID() )
        return true;
     if( parentObject instanceof MDRoot )
        return false;

     return traverseTheTree( modifiedObject, parentObject );
  }

  /**
   * Retrieves the kind of change that was made to the modified object.
   *
   * @return A constant that indicates how the modified object was changed, or
   *         <code>null</code> if not modification operation was specified in
   *         the constructor.
   *         Valid constants are listed in the See Also section.
   *
   * @see #SET
   * @see #COPY
   * @see #MOVE
   * @see #REMOVE
   * @see #REMOVEALL
   *
   * @status Reviewed
   */
  public int getModOperation()
  {
    return m_op;
  }

  /**
   * @hidden
   */
  public boolean isPiggybacked()
  {
    return m_isPiggyback;
  }

  /**
   * @hidden
   */
  public void setPiggybacked(boolean isPiggybacked)
  {
    m_isPiggyback = isPiggybacked;
  }
}
