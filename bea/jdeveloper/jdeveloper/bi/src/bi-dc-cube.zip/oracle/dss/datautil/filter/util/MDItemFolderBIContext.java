/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/filter/util/MDItemFolderBIContext.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.filter.util;

import java.util.Enumeration;
import java.util.Vector;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;

import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MMUtilities;

import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;

/**
 * @hidden
 * 
 * This is a *temporary* class is designed to provide a <code>BIContext</code>
 * that can be used for searches on <code>MDItemFolder</code> objects.
 *
 * This was needed to work around Bug 4753060: Search does not work for item
 * object types.
 *
 * @status new
 */
public class MDItemFolderBIContext extends DefaultBIContext {
  MDItemFolder m_mdItemFolder = null;
  
  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * <code>MDItemFolderBIContext</code> constructor.
   * 
   * @param mdItemFolder A <code>MDItemFolder</code>.
   * 
   * @status new
   */
  public MDItemFolderBIContext (MDItemFolder mdItemFolder) {
    m_mdItemFolder = mdItemFolder;  
  }

  /**
   * Perform search.
   * 
   * @param name A <code>String</code>
   * @param matchingAttributes A <code>Attributes</code>
   * @param searchControls A <code>SearchControls</code>
   * @return <code>NamingEnumeration</code>
   * 
   * @throws NamingException
   */
  public NamingEnumeration search (String name, Attributes matchingAttributes, 
                      SearchControls searchControls) throws NamingException {
    NamingEnumeration namingEnumeration = null;
    
    if (m_mdItemFolder != null) {
      Vector vMDItems = new Vector();
      MDObject mdObject;

      try {
        MDItemFolder[] mdItemFolders = m_mdItemFolder.getItemFolders();
        MDItem[] mdItems = m_mdItemFolder.getItems();
        int size = ((mdItemFolders != null)? mdItemFolders.length : 0) + ((mdItems != null)? mdItems.length : 0);
        Vector mdObjects = new Vector(size);
        for (int i=0; mdItemFolders != null && i < mdItemFolders.length; i++)
          mdObjects.addElement(mdItemFolders[i]);
        for (int i=0; mdItems != null && i < mdItems.length; i++)
          mdObjects.addElement(mdItems[i]);
        for (int nIndex= 0; nIndex < mdObjects.size(); nIndex++) {

          mdObject = (MDObject)mdObjects.elementAt(nIndex);

          String[] strAttributeKeys = searchControls.getReturningAttributes();
          Attributes attributes = null;

          // Returns all properties if returning attributes is null
          if (strAttributeKeys == null) {
            PropertyBag propertyBag = mdObject.getPropertyBag();    
            attributes = MMUtilities.propertyBagToAttributes (propertyBag);
          }
          else {
            attributes = new BasicAttributes();

            for (int nIndexProps=0; nIndexProps < strAttributeKeys.length; nIndexProps++) {
              Property property = mdObject.getProperty (strAttributeKeys[nIndexProps]);
              
              if (property != null && property.getObjValue() != null) {
                attributes.put(strAttributeKeys[nIndexProps], property.getObjValue());
              }
            }
          }

          // Generate a SearchResult based on the MDMeasure
          MetadataManagerSearchResultImpl mmSearchResult = 
            new MetadataManagerSearchResultImpl (mdObject.toString(), 
              mdObject.getClassName(), mdObject.getUniqueID(), 
                attributes, mdObject.getObjectType(), 
                  mdObject.getMetadataManagerServices());
          
          // Specify the underlying SearchResult object
          mmSearchResult.setObject (mdObject);

          // Add the search result
          vMDItems.add (mmSearchResult);  
        }
      }
      
      catch (MetadataManagerException metadataManagerException) {
        
      }
 
      // Convert the vector of MDObjects to a NamingEnumeration
      namingEnumeration = new NamingEnumerationImpl (vMDItems);  
    }
    
    return namingEnumeration;
  }

  ///////////////////////
  //
  // Inner Classes
  //
  ///////////////////////

  /**
   * @hidden
   * 
   * <code>Vector</code> <code>NamingEnumeration</code> wrapper.
   *
   * This was needed to work around Bug 4753060: Search does not work for item
   * object types.
   *
   * @status new
   */
  public class NamingEnumerationImpl implements NamingEnumeration, java.io.Serializable {
    Enumeration m_enumeration;

    NamingEnumerationImpl (Vector vObjects) {
      m_enumeration = vObjects.elements();
    }

    public boolean hasMoreElements() {
      return m_enumeration.hasMoreElements();
    }

    public boolean hasMore() throws NamingException {
      return hasMoreElements();
    }

    public Object nextElement() {
      return m_enumeration.nextElement();
    }

    public Object next() throws NamingException {
      return nextElement();
    }

    public void close() {
    }
  }
}
