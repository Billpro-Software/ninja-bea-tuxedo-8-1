/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.QDR;

import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * Represents an edited cell that is specified by a QDR.
 * A QDRoverride object is added to the writeback collection as soon as a cell
 * is edited.
 * If auto submission is set for cell editing, then each
 * <code>QDRoverride</code> is submitted to the database immediately.
 * If auto submission is not set for cell editing, then the
 * <code>QDRoverride</code> objects accumulate in the writeback collection until
 * changes are submitted explicitly to the database.
 *
 * @see  oracle.dss.util.DataAccess#isAutoSubmit
 * @see  oracle.dss.util.DataAccess#setAutoSubmit
 * @see  oracle.dss.util.DataAccess#submitChanges
 *
 * @status Documented
 */

public class QDRoverride extends QDR
{
  public static final int WB_OK = 0;
  public static final int WB_FAILED = 1;
  public static final int VALIDATION_FAILED = 2;
  /**
   * Constructor for this class.
   *
   * @status Documented
   */
    public QDRoverride(QDR qdr)
    {
        super(qdr);
    }

/**
 * Retrieves the edited data from the cell that is represented by the QDR
 * object.
 *
 * @return The edited data from the overridden cell.
 *
 * @status Documented
 */

    public Object getData()
    {
        return _curData;
    };

/**
 * Specifies the edited data for the cell that is represented by the QDR object.
 *
 * @param data The edited data from the overridden cell.
 *
 * @status Documented
 */
    public void   setData(Object data)
    {
        _curData = data;
    };

    // Override
    public String toString() {

        boolean first = true;

        String measure = "";
        StringBuffer qdrBuffer = new StringBuffer();
        StringBuffer buffer = new StringBuffer();

        buffer.append("(");

        Enumeration keys = m_dimensions.elements();
        Enumeration values = m_members.elements();
        if(keys == null)
            return null;
        else //if more than one dimension, then create str dim:val;dim:val
        {
            while(keys.hasMoreElements())
            {
                String key = (String)keys.nextElement();
                String member = values.nextElement().toString();

                if (key.equals(getMeasureDim())) {
                    try
                    {
                        measure = getDimensionNameFromId(member, MM.MEASURE);
                    }
                    catch (MetadataManagerException mme)
                    {
                        throw new QueryRuntimeException(mme.getMessage(), mme);
                    }

                    continue;
                }

                if(!first)
                    buffer.append(",");

                try
                {
                    buffer.append(getDimensionNameFromId(key, MM.DIMENSION));
                }
                catch (MetadataManagerException mme)
                {
                    throw new QueryRuntimeException(mme.getMessage(), mme);
                }

                buffer.append(" '");
                buffer.append(member);
                buffer.append("'");
                first = false;
            }
        }
        buffer.append(")");

        qdrBuffer.append(measure);
        qdrBuffer.append(buffer);

        return qdrBuffer.toString();
    }

    public Object clone()
    {
        QDRoverride copy = new QDRoverride(this);

        copy.setData(getData());
        copy.setQueryState(m_queryState);
        copy.m_wbStatus = m_wbStatus;
        copy.m_wbErrorText = m_wbErrorText;        
        return copy;
    }
    
    /**
     * @hidden
     */
    public void setQueryState(QueryState queryState)
    {
        m_queryState = queryState;
    }

   private String getDimensionNameFromId( String Id , String type) throws MetadataManagerException
    {
        //return ((MDObject)m_query.getMDObject(MM.UNIQUE_ID, Id, type
                    //)).getOLAPIMetadataID();
//          return ((MDObject)m_query.getMDObject(MM.UNIQUE_ID, Id, type)).getName();
        return ((MDObject)m_queryState.getMDObject(MM.UNIQUE_ID, Id, type)).getAWObjectName();
    }

/**
 * Retrieves 0 if the edited datacell that is represented by the QDR was written back successfuly.
 *
 * @return True or false.
 *
 */
    public int getWritebackStatus()
    {
      return m_wbStatus;
    }

    public void setWritebackStatus(int status)
    {
      m_wbStatus = status;
    }
    public void setWritebackError(String errorText)
    {
      m_wbErrorText = errorText;
    }

/**
 * Retrieves the error message associated with an unsuccessfull writing back of the edited datacell that is represented by the QDR.
 *
 * @return Error message.
 *
 */

    public String getWritebackError()
    {
      return m_wbErrorText;
    }
    // the current data
    private Object _curData;

    private QueryState m_queryState = null;

    public int m_wbStatus = QDRoverride.WB_OK;
    public String m_wbErrorText;
};