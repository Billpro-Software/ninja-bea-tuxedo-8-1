/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import oracle.dss.metadataUtil.MDU;

/**
 * A client-side representation of a dimension member in an analytic workspace.
 * An <code>MDMemberMetadata</code> provides, to a java client, information about
 * a dimension member in the workspace.
 * <P>
 * An OLAP dimension is a structure that categorizes data.
 * For example, in analyzing Sales data, typical dimensions would be
 * Product, Time, and Geography.
 * A dimension member is one item in a dimension.
 * For example, January 2002 might be a member of the Time dimension.
 *
 * @status Reviewed.
 */
public class MDMemberMetadata extends MDObject {

    /**
     *
     * @hidden
     *
     */
    public MDMemberMetadata() {
        setObjectType(MM.MEMBER_METADATA);
    }

   	/**
     * @hidden
     * Constructor.
     *
     * @param mmServices     The <code>MetadataManagerServices</code> that this
     *                       member metadata exists in.
     * @param memberMMName   Name for this object.
     * @param parent         The object that contains this object.
     *
     * @status hidden
     */
    public MDMemberMetadata( MetadataManagerServices mmServices, String memberMMName, MDObject parent ) {
        super( mmServices, memberMMName, parent );
        setObjectType(MM.MEMBER_METADATA);
    }

    /**
     * @hidden
     * Retrieves an object that is dependent upon this object.
     *
     * @return The dependent object.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDObject getDependency() throws MetadataManagerException {
  		return (MDObject)getFirstRelative(MM.DEPENDENCY);
  	}

    /**
     * @hidden
     * Specifies that an object is dependent on this object.
     *
     * @param dependency The object that depends on this object.
     *
     * @return A constant that indicates whether the dependent object was
     *         successfully set. Possible constants are listed in the
     *         See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
  	public int setDependency(MDObject dependency) {
		  if (dependency == null) {
			  return (MDU.FAILURE);
		  }
		  return setRelative(dependency, MM.DEPENDENCY);
  	}

    /**
     * @hidden
     */
  	public String getDependencyType() {
		  return null;
  	}
  
    /**
     * @hidden
     */
  	public int setDependencyType(String dependencyType) {
	  	return 0;
  	}

    /**
     * @hidden
     */
  	public String getDataType() {
		  return null;
  	}
  
    /**
     * @hidden
     */
  	public int setDataType(String dataType) {
		  return 0;
  	}
}