/*
** Copyright (c) 2000, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.server;

/****************************************************
* Imports
****************************************************/
import java.lang.ClassNotFoundException;
import java.lang.InstantiationException;
import java.lang.IllegalAccessException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;
import java.util.Hashtable;
//import oracle.jbo.JboContext;
//import oracle.jbo.ComponentObject;
//import oracle.jbo.server.ComponentObjectImpl;
//import oracle.jbo.ApplicationModule;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.connection.common.CB;
import oracle.dss.connection.common.ConnectionObj;
import oracle.dss.connection.common.ConnectionObject;
import oracle.dss.connection.common.ConnectionException;
import oracle.dss.connection.common.ConnectionEventSupport;
import oracle.dss.connection.common.ConnectionListener;
import oracle.dss.connection.server.drivers.ConnectionDriver;
import oracle.dss.connection.server.resource.ConnectionServerBundle;
import oracle.dss.metadataUtil.MDU;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.VersionInfo;

/**
 * The middle-tier component for the Connection bean.
 * In most cases, application developers call the methods on
 * the <code>Connection</code> object in
 * the <code>oracle.dss.connection.client</code> package.
 * The <code>Connection</code> methods call the methods in this class.
 *
 * @see oracle.dss.connection.client.Connection
 *
 * @status documented
 */

/**
 * @hidden
 */
public class ConnectionImpl implements ConnectionObject 
{
    private static int m_InstanceID = 0;

    private Locale m_locale = null;

    // The connection structure. This contains all connection
    // information. This class will be send across the tiers.
    private ConnectionObj m_ConnectionObj = null;

    private ConnectionDriver m_ConnectionDriver = null;

	// To run the applet mode.
    private java.applet.Applet m_Applet = null;

    /**
     *  Event handling support
     */
    private ConnectionEventSupport eventSupport;

    private ErrorHandler m_eh = null;

    private Hashtable m_driverImpl;
    /**************************************************
    * Constructors
    ***************************************************/
    /**
     * Constructor.
     * This constructor is called by the <code>Connection</code>
     * object when you call its default constructor.
     *
     * @see #ConnectionImpl(Applet)
     *
     * @status documented
     */
   public ConnectionImpl() {
      super();
      m_ConnectionObj = new ConnectionObj();
      initConnectionImpl();
    }

    /**
     * Constructor that takes an <code>Applet</code>.
     * This constructor is called if you are developing an <code>Applet</code>.
     *
     * @param applet The <code>Applet</code> that uses this
     *               <code>ConnectionImpl</code>.
     *
     * @see #ConnectionImpl()
     *
     * @status documented
     */
    public ConnectionImpl(java.applet.Applet applet) {
      super();
      setApplet ( applet );
      m_ConnectionObj = new ConnectionObj();
      initConnectionImpl();
    }

    /**
     * @hidden
     * Constructor with ORB intialization structures
     *
     * @param args  String Array containing ORB Arguments
     * @param properties   Properties containing ORB Properties
     *
     * @status hidden
     */
    public ConnectionImpl(String[] args, Properties properties) {
      super();
      m_ConnectionObj = new ConnectionObj();
      m_ConnectionObj.setORBArgs( args );
      m_ConnectionObj.setORBProperties( properties );
      m_ConnectionObj.setOrbInitStatus( true );
      initConnectionImpl();
    }
   
    /************************************************************************
    * Event Support.
    ************************************************************************/
    /**
     * Adds a <code>ConnectionListener</code> to this connection.
     * A <code>ConnectionListener</code> listens for connection events.
     *
     * @param listener  The listener to add.
     *
     * @status documented
     */
    public void addListener( ConnectionListener listener ) {
        eventSupport.addConnectionListener( listener );
    }

    /**
     * Removes a <code>ConnectionListener</code> from this connection.
     *
     * @param listener The listener to remove.
     *
     * @status documented
     */
    public void removeListener( ConnectionListener listener ) {
        eventSupport.removeConnectionListener( listener );
    }

  /************************************************************************
  * Connection Support
  ************************************************************************/
    /**
     * Indicates whether this connection instance is connected to the server.
     *
     * @return  <code>true</code> if this connection is connected,
     *          <code>false</code> if it is not connected.
     *
     * @status documented
     */
	public boolean isConnected() {
		return m_ConnectionObj.isConnected();
  }

    /**
     * Indicates whether this connection instance is failded during the connection to the server.
     *
     * @return  <code>true</code> if this connection failed,
     *          <code>false</code> if it is not connected.
     *
     * @status new
     */
    public boolean isConnectionFailed() {
      return m_ConnectionObj.isConnectionFailed();
    }    

    /**
     * Connects this connection to the server.
     *
     * @return A constant that represents connection status.
     *         Possible values are listed in the See Also section.
     *
     * @throws ConnectionException If the connection process fails
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status documented
     */
    public int connect() throws ConnectionException {
		  m_ConnectionObj = connect ( m_ConnectionObj, (PropertyBag) null ) ;
  	  return getConnectionStatus();
	  }

    /**
     * Disconnects this connection from the server.
     *
     * @return A constant that represents connection status.
     *         Possible values are listed in the See Also section.
     *
     * @throws ConnectionException If the disconnection process fails
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status documented
     */
    public int disconnect() throws ConnectionException {
		  m_ConnectionObj = disconnect ( (PropertyBag) null ) ;
  	  return getConnectionStatus();
	  }

     /**
     * @hidden
     * Connect the Bean instance to the Server.
     *
     * @return Integer constant representing connection status.
     *                  Possible values are:
     *                  <code>CONNECTED</code> if connected.
     *                  <code>NOT_CONNECTED</code> if not connected.
     *                  <code>FAILURE</code> if connection failed
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @param connectParams  PropertyBag
     *  
     * @throws ConnectionException if connection process is failed
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */
    public ConnectionObj connect( ConnectionObj connectionObj, PropertyBag connectProperties ) throws ConnectionException {
        // connectProperties is not used at this time.
        eventSupport.fireConnectingEvent();
        ErrorHandler errHandler = (ErrorHandler)connectionObj.getObjPropertyValue("ErrorHandler");
        if(errHandler != null)
        {
            m_eh = errHandler;
            connectionObj.removeProperty("ErrorHandler");
        }
        Locale _locale = (Locale)connectionObj.getObjPropertyValue("locale");
        if (_locale != null)
        {
            m_locale = _locale;
            connectionObj.removeProperty("locale");
        }

        if(connectionObj.getObjPropertyValue(CB.CONNECTION_DRIVER) != null)
            m_driverImpl = (Hashtable)connectionObj.getObjPropertyValue(CB.CONNECTION_DRIVER);

        m_ConnectionObj = connectionObj;
        if ( null == getConnectionDriver( getDriverType() ) )
            return null;
        m_eh.trace("-ConnectionBean-Server: is going to connect - (DriverType=" + getDriverType() + ")", getClass().getName(), "connect" ) ;

        // set ORB related properties on the driver
        //setDriverSpecificObject(CB.DEPLOYMENT_PLATFORM, getDeploymentPlatform());
        //if(m_Applet != null)
        //    setDriverSpecificObject(CB.APPLET, m_Applet);

        // set error handler on driver
        PropertyBag errBag = new PropertyBag();
        errBag.setStrPropertyValue("ErrorHandler", "ErrorHandler");
        m_ConnectionDriver.setDriverSpecificObject(m_eh, errBag);

        // set locale on driver
        PropertyBag localeBag = new PropertyBag();
        localeBag.setStrPropertyValue("Locale", "Locale");
        m_ConnectionDriver.setDriverSpecificObject(m_locale, localeBag);

        long b = System.currentTimeMillis();
        PropertyBag return_props = m_ConnectionDriver.connect( getPropertyBag() );
        long a = System.currentTimeMillis();
        if(m_ConnectionDriver.isConnected())
            m_eh.trace("-ConnectionBean-MDMDriver: Connected Successfully: Time=" + (a-b) + "ms" , getClass().getName(), "connect" ) ;
        setPropertyBag ( return_props, CB.KEEP );
        eventSupport.fireConnectedEvent();
        return m_ConnectionObj;
    }

    /**
     * @hidden
     * Disonnect the Bean instance from the Server.
     *
     * @return Integer constant representing connection status.
     *                  Possible values are:
     *                  <code>CONNECTED</code> if connected.
     *                  <code>NOT_CONNECTED</code> if not connected.
     *                  <code>FAILURE</code> if connection failed
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @param disconnectParams  PropertyBag
     *  
     * @throws ConnectionException if disconnect process is failed
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */
	public ConnectionObj disconnect ( PropertyBag disconnectProperties ) throws ConnectionException {
    // disconnectProperties is not used at this time.
    if( eventSupport.fireDisconnectingEvent() ) {
      m_eh.trace("-ConnectionBean-Server: disconnecting event is consumed ", getClass().getName(), "disconnect" ) ;
      return null;
    }
    m_eh.trace("-ConnectionBean-Server: is going to disconnect ", getClass().getName(), "disconnect" ) ;
		setConnectionStatus ( CB.NOT_CONNECTED );
		if ( null == getConnectionDriver( getDriverType() ) ) {
			return m_ConnectionObj;
		}
		PropertyBag return_props = m_ConnectionDriver.disconnect( getPropertyBag() );
		setPropertyBag ( return_props , CB.KEEP );
    eventSupport.fireDisconnectedEvent();
		return m_ConnectionObj;
  }
  
    /**
     * @hidden
     *
     * @status hidden
     */
  public ConnectionDriver getConnectionDriver() {
    return m_ConnectionDriver;
  }

  /************************************************************************
  * SPL Support.
  ************************************************************************/
    /**
     * Executes an command on the server.
     * The command must be correct for the stored procedure language of the
     * server to which this connection connects.
     *
     * @return The result of execution of the command.
     *
     * @param command  The command to execute.
     *
     * @throws ConnectionException If the execution fails.
     *
     * @status documented
     */
	public String executeCommand ( String command ) throws ConnectionException {
		PropertyBag propBag = new PropertyBag();
		return executeCommand ( command, propBag );
	}

    /**
     * Executes an command on the server.
     * The command must be correct for the stored procedure language of the
     * server to which this connection connects.
     *
     * @return The result of execution of the command.
     *
     * @param command  The command to execute.
     * @param properties  Properties of the command.
     *
     * @throws ConnectionException If the execution fails.
     *
     * @status documented
     */
	public String executeCommand ( String command, PropertyBag properties ) throws ConnectionException {
		if ( null == getConnectionDriver( getDriverType() ) )
			return null;
		return m_ConnectionDriver.executeCommand ( command, properties );
	}

    /**
     * Evaluates an expression and retrieves results of the expression.
     * The expression should be in terms of the stored procedure language
     * of the server.
     *
     * @return The result of evaluated expression.
     *
     * @param expression The expression to evaluate.
     * @param properties Properties of the expression.
     *
     * @throws ConnectionException If the evaluation fails.
     *
     * @status documented
     */
    public Object evaluateExpression(String expression, PropertyBag properties ) throws ConnectionException {
		  if ( null == getConnectionDriver( getDriverType() ) )
			  return null;
		  return m_ConnectionDriver.evaluateExpression ( expression, properties );
    }

  /************************************************************************
  * Operations on the objects that only exist on the source platform.
  ************************************************************************/
    /**
     * @hidden
     * Retrieve the driver specific objects from the driver
     *
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              driver specific object
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public Object getDriverSpecificObject( String name ) throws ConnectionException {
		PropertyBag propBag = new PropertyBag();
		propBag.createProperty ( name );
		return getDriverSpecificObject ( propBag );
  }

    /**
     * @hidden
     * Set the driver specific objects on the driver
     *
     * @param properties    the driver specific object to be set.
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public int setDriverSpecificObject( String name, Object object ) throws ConnectionException {
		PropertyBag propBag = new PropertyBag();
		propBag.createProperty ( name );
		return setDriverSpecificObject ( object, propBag );
  }

    /**
     * @hidden
     * Remove the driver specific objects at the driver level
     *
     * @param properties    properties needed to remove driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public int removeDriverSpecificObjects( String name ) throws ConnectionException {
		PropertyBag propBag = new PropertyBag();
		propBag.createProperty ( name );
		return removeDriverSpecificObjects ( propBag );
  }

    /**
     * @hidden
     * Retrieve the driver specific objects from the driver
     *
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              driver specific object
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public Object getDriverSpecificObject( PropertyBag properties ) throws ConnectionException    {
		if ( null == getConnectionDriver( getDriverType() ) )
			return null;
		return m_ConnectionDriver.getDriverSpecificObject ( properties );
  }

    /**
     * @hidden
     * Set the driver specific objects on the driver
     *
     * @param properties    the driver specific object to be set.
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
    public int setDriverSpecificObject( Object object, PropertyBag properties ) throws ConnectionException     {
        if ( null == getConnectionDriver( getDriverType() ) )
            return CB.FAILURE;

        if(properties != null) {
            String errorHandler = properties.getStrPropertyValue("ErrorHandler");
            if(errorHandler != null)
            {
                if(errorHandler.equals("add"))
                    m_eh = (ErrorHandler)object;
                else if(errorHandler.equals("remove")) {
                    m_eh = new DefaultErrorHandler();
                    object = m_eh;
                }
            }
        }
        return m_ConnectionDriver.setDriverSpecificObject ( object, properties );
    }

    /**
     * @hidden
     * Remove the driver specific objects at the driver level
     *
     * @param properties    properties needed to remove driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public int removeDriverSpecificObjects( PropertyBag properties ) throws ConnectionException {
		if ( null == getConnectionDriver( getDriverType() ) )
			return CB.FAILURE;
		return m_ConnectionDriver.removeDriverSpecificObjects ( properties );
  }

    /**
     * @hidden
     *
     * @status hidden
     */
  public Property getServerProperty( String propertyName ) throws ConnectionException {
		return m_ConnectionObj.getProperty( propertyName );
  }

    /**
     * @hidden
     *
     * @status hidden
     */
  public int setServerProperty( Property property ) throws ConnectionException {
		m_ConnectionObj.setProperty( property );
		return CB.SUCCESS;
  }

    /**
     * @hidden
     *
     * @status hidden
     */
	public ConnectionObj getConnectionObj() throws ConnectionException {
    return m_ConnectionObj;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public int setConnectionObj( ConnectionObj connectionObj) throws ConnectionException {
		m_ConnectionObj = connectionObj;
  	return CB.SUCCESS;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public ConnectionObj getServerConnectionObj() throws ConnectionException {
    return getConnectionObj();
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public int setServerConnectionObj( ConnectionObj connectionObj) throws ConnectionException {
      	return setConnectionObj( connectionObj );
	}

    /**
     * @hidden
     *
     * @status hidden
     */
  public int free() throws ConnectionException {
    if ( getConnectionStatus() == CB.CONNECTED ) {
	     if ( disconnect() == CB.CONNECTED );
	  	 return CB.FAILURE;
    }

    if ( m_ConnectionObj != null )
    m_ConnectionObj.free();
		m_ConnectionObj = null;
		return CB.SUCCESS;
  }

	/****************************************************
	 * Generic methods for property Setting from Property Bag
	 ****************************************************/
    /**
     * @hidden
     *
     * @status hidden
     */
	public Property[] getServerProperties() {
		return m_ConnectionObj.getProperties();
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public void setServerProperty ( String name, Object object, int dataType, int flags) {
		m_ConnectionObj.setProperty ( name, object, dataType, flags );
	}

    /**
     * @hidden
     *
     * @status hidden
     */
 	public void removeServerProperty(String name) {
		m_ConnectionObj.removeProperty( name );
 	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public PropertyBag getPropertyBag() {
		return m_ConnectionObj.getPropertyBag();
  }

      /**
     * @hidden
     *
     * @status hidden
     */
  public int setPropertyBag( PropertyBag propertyBag , int keepRemoveFlags ) {
		return m_ConnectionObj.setPropertyBag ( propertyBag, keepRemoveFlags );
  }

	/****************************************************
	 * Short cut methods for property setting
	 ****************************************************/
    /**
     * Retrieves the name of this <code>ConnectionImpl</code>.
     *
     * @return The name of <code>ConnectionImpl</code>.
     *
     * @status documented
     */
    public String getConnectionName() {
      String name = m_ConnectionObj.getName();
      if ( ( name == null ) || ( name.equals ("") ) ) {
        name = "Connection_" + Integer.toString(getInstanceID()).trim();
        m_ConnectionObj.setName( name );
      }
      return m_ConnectionObj.getName();
    }

    /**
     * Specifies the name of this <code>ConnectionImpl</code>.
     *
     * @param name The name for this <code>ConnectionImpl</code>.
     *
     * @status documented
     */
    public void setConnectionName(String name) {
 		  m_ConnectionObj.setName( name );
    }

    /**
     * Retrieves the type of service that this connection is for.
     * If this connection is for MOLAP (Multidimensional OLAP), then this
     * method returns "ExpressServer".
     * If this connection is for ROLAP (Relational OLAP), then this method
     * returns "OlapServer".
     *
     * @return The type of service that this connection is for.
     *
     * @status documented
     *
     */
    public String getServerType() {
  	  return m_ConnectionObj.getServerType();
    }

    /**
     * Specifies the type of service that this connection is for.
     *
     * @param serverType "ExpressServer" for a MOLAP (Multidimensional OLAP) connection,
     *        "OlapServer" for a ROLAP (Relational OLAP) connection.
     *
     * @status documented
     */
    public void setServerType( String serverType ) {
  	  m_ConnectionObj.setServerType( serverType );
    }

    /**
     * Retrieves the type of driver that this connection uses.
     * Possible return values are:
     * <p>
     * <ul><li>"MDM" for a MetadataManager connection</li>
     * <li>"Persistence" for a connection to the persistence service</li>
     * </ul>
     * @return The type of driver that this connection uses.
     *
     * @status documented
     */
    public String getDriverType() {
        return (m_ConnectionObj != null)? m_ConnectionObj.getDriverType() : "";
    }

    /**
     * Specifies the type of driver that this connection uses.
     *
     * @param driverType "MDM" for a connection to the MetadataManager,
     *        "Persistence" for a connection to the persistence service.
     *
     * @status documented
     */
    public void setDriverType( String driverType ) {
        if(m_ConnectionObj != null)
            m_ConnectionObj.setDriverType( driverType );
    }

    /**
     * Retrieves the status of this connection.
     *
     * @return  A constant that represents the status of this connection.
     *          Possible values are listed in the See Also section.
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.connection.common.CB#CONNECTING
     *
     * @status documented
     */
    public int getConnectionStatus() {
  	  return m_ConnectionObj.getConnectionStatus();
    }

    /**
     * Specifies the current status of this connection.
     *
     * @param status A constant that represents the status of this connection.
     *         Possible values are listed in the See Also section.
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.connection.common.CB#CONNECTING
     *
     * @status documented
     */
    public void setConnectionStatus( int status ) {
  	  m_ConnectionObj.setConnectionStatus( status );
    }

    /**
     * Retrieves the connection string.
     * The connection string is the string that was used to connect to the
     * server.
     *
     * @return The connection string for this connection.
     *
     * @status documented
     */
    public String getConnectionString() {
  	  return m_ConnectionObj.getConnectionString();
    }

     /**
     * Specifies the string to use to connect.
     * The string should be a valid connection string for the server to which
     * this connection connects.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the connection string from the DAD.
     *
     * @param connectionString The connection string for this connection.
     *
     * @status documented
     */
    public void setConnectionString(String connectionString) {
      m_ConnectionObj.setConnectionString(connectionString);
    }

    /**
     * @hidden
     */
    public String getOLAPServiceName() {
        return m_ConnectionObj.getStrPropertyValue(CB.OLAP_SERVICE);
    }

    /**
     * Retrieves the user name for this connection.
     *
     * @return  The user name for this connection.
     *
     * @status documented
     */
    public String getUsername() {
  	  return m_ConnectionObj.getUsername();
    }

    /**
     * Specifies the user name for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the user name from the DAD.
     *
     * @param username The user name for this connection.
     *
     * @status documented
     */
    public void setUsername(String username) {
  	  m_ConnectionObj.setUsername(username);
    }

    /**
     * Retrieves the password for this connection.
     *
     * @return  The password for this connection.
     *
     * @status documented
     */
    public String getPassword() {
  	  return m_ConnectionObj.getPassword();
    }

    /**
     * Specifies the password for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the password from the DAD.
     *
     * @param password The password for this connection.
     *
     * @status documented
     */
    public void setPassword(String password) {
  	  m_ConnectionObj.setPassword(password);
    }
    /**
     * Retrieves the SecurityPrincipal for this connection.
     *
     * @return  The SecurityPrincipal for this connection.
     *
     * @status new
     */
    public String getSecurityPrincipal() {
      return m_ConnectionObj.getSecurityPrincipal();
    }

    /**
     * Specifies the SecurityPrincipal for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the user name from the DAD.
     *
     * @param SecurityPrincipal The user name for this connection.
     *
     * @status new
     */

    public void setSecurityPrincipal(String securityPrincipal) {
      m_ConnectionObj.setSecurityPrincipal(securityPrincipal);
    }

    /**
     * Retrieves the SecurityCredentials for this connection.
     *
     * @return  The SecurityCredentials for this connection.
     *
     * @status new
     */
    public String getSecurityCredentials() {
      return m_ConnectionObj.getSecurityCredentials();
    }

    /**
     * Specifies the SecurityCredentials for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the user name from the DAD.
     *
     * @param SecurityCredentials The user name for this connection.
     *
     * @status new
     */
    public void setSecurityCredentials(String securityCredentials) {
      m_ConnectionObj.setSecurityCredentials(securityCredentials);
    }

    /**
     * Retrieves the Service for this connection.
     *
     * @return  The Service for this connection.
     *
     * @status new
     */
    public String getService() {
      return m_ConnectionObj.getService();
    }

    /**
     * Specifies the Service for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the user name from the DAD.
     *
     * @param Service The user name for this connection.
     *
     * @status new
     */
    public void setService(String service) {
      m_ConnectionObj.setService(service);
    }

   /****************************************************
    * Unpublished public shortcut methods
    *****************************************************/

    /**
     * @hidden
     *
     * @status hidden
     */
	public Object getExpressConnection() throws ConnectionException {
		return (Object) getDriverSpecificObject(CB.CONNECTION) ;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public Object getExpressDataProvider() throws ConnectionException {
		return (Object) getDriverSpecificObject( "ExpressDataProvider" ) ;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public Object getDataProvider() throws ConnectionException {
		return (Object) getDriverSpecificObject( "DataProvider" ) ;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public Object getTransactionProvider() throws ConnectionException {
		return (Object) getDriverSpecificObject( "TransactionProvider" ) ;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
  public Object getTransaction() throws ConnectionException {
    return (Object) getDriverSpecificObject( "Transaction" ) ;
  }

    /**
     * @hidden
     *
     * @status hidden
     */
	public int setTransactionProvider( Object object) throws ConnectionException{
		return setDriverSpecificObject( "TransactionProvider", object ) ;
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public int setORB( Object object) throws ConnectionException {
		return setDriverSpecificObject( "ORB", object ) ;
	}

   /****************************************************
    * BC4J/Appmodule Stuff
    ************************************************************************/
    /**
     * Specifies an <code>Applet</code> that uses this connection.
     *
     * @param applet   The <code>Applet</code> that uses this connection.
     *
     * @return       A constant that indicates whether the <code>Applet</code>
     *               was successfully set.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented
     */
  public int setApplet( java.applet.Applet applet ) {
		//String mode = getDeploymentPlatform();
		//if ( ( mode.equals(oracle.jbo.JboContext.PLATFORM_LOCAL )) && ( applet != null ) ){
  		    m_Applet = applet;
  		    return CB.SUCCESS;
		//}
  	    //return CB.FAILURE;
  }

    /**
     * @hidden
     *
     * @status hidden
     */
     /*
	public String getDeploymentPlatform(){
		return (String)getApplicationModule().getSession().getEnvironment().get(JboContext.DEPLOY_PLATFORM);
	}*/

    /**
     * @hidden
     *
     * @status hidden
     */
    public Object getORB() throws ConnectionException
    {
        if(m_ConnectionDriver != null)
        {
            PropertyBag bag = new PropertyBag();
            bag.setStrPropertyValue("ORB", CB.ORB);
            return m_ConnectionDriver.getDriverSpecificObject(bag);
        }
        return null;
    }
	/****************************************************
	* private methods
	****************************************************/
    /**
     * @status private
     */
    private ConnectionDriver getConnectionDriver ( String driverType ) throws ConnectionException
    {
        if ( m_ConnectionDriver != null )
            return m_ConnectionDriver;

        if ( driverType == null )
            return null;

        try 
        {
            if(driverType != null && m_driverImpl != null)
            {
                String _str = (m_driverImpl.containsKey(driverType))? (String)m_driverImpl.get(driverType) : "";
                m_ConnectionDriver = (ConnectionDriver)(Class.forName(_str).newInstance());
            }
            else 
                return null;

            //m_ConnectionDriver.setSecurityDriverManager((SecurityDriverManager)getApplicationModule());
        }
        catch ( ClassNotFoundException cnfe ) {
            throw new ConnectionException( ConnectionServerBundle.class,
                                           ConnectionServerBundle.EXC_DRIVER_NOT_FOUND,
                                           new Object[]{cnfe.getLocalizedMessage() },
                                           cnfe,
                                           driverType );
        }
        catch ( InstantiationException ie ) {
            throw new ConnectionException( ConnectionServerBundle.class,
                                           ConnectionServerBundle.EXC_INSTANTIATION,
                                           new Object[]{ie.getLocalizedMessage() },
                                           ie,
                                           driverType );
        }
        catch ( IllegalAccessException iae ) {
            throw new ConnectionException( ConnectionServerBundle.class,
                                           ConnectionServerBundle.EXC_ILLEAGAL_ACCESS,
                                           new Object[]{iae.getLocalizedMessage() },
                                           iae,
                                           driverType );
        }
        return m_ConnectionDriver;
    }

    /**
     * @status private
     */
    private int initConnectionImpl() {
        //setupClasses();
        eventSupport = new ConnectionEventSupport( this );
        setConnectionStatus( CB.NOT_CONNECTED );
        m_InstanceID ++;
        m_driverImpl = new Hashtable();
        m_driverImpl.put(MDU.MDM, "oracle.dss.connection.server.drivers.mdm.MDMConnectionDriverImpl");
        m_driverImpl.put(MDU.ECM, "oracle.dss.connection.server.drivers.ecm.ECMConnectionDriverImpl");
        m_driverImpl.put(MDU.PERSISTENCE, "oracle.dss.connection.server.drivers.persistence.PersistenceConnectionDriverImpl");
        m_driverImpl.put(MDU.DISCOVERER, "oracle.dss.connection.server.drivers.disco.DiscovererConnectionDriverImpl");
        m_driverImpl.put(MDU.SBA, "oracle.dss.connection.server.drivers.sba.SBAConnectionDriverImpl");
        m_eh = new DefaultErrorHandler();
        return CB.SUCCESS;
    }

    /**
     * @status private
     */
     /*
	  private void setupClasses(){
      setProxyClassName(JboContext.PLATFORM_VB, "oracle.dss.appmodule.client.corba.ConnectionObjectImpl");
      setProxyClassName(JboContext.PLATFORM_ORACLE8I, "oracle.dss.appmodule.client.corba.ConnectionObjectImpl");
      setProxyClassName(JboContext.PLATFORM_EJB, "oracle.dss.appmodule.client.ejb.ConnectionObjectImpl");
    }*/

    /**
     * @status private
     */
    private static int getInstanceID() {
  	  return m_InstanceID;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
    public Locale getLocale() {
      //if (m_locale == null)
      //  m_locale = getApplicationModule().getSession().getLocale();
      return m_locale;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
    public void setLocale(Locale locale)
    {
        m_locale = locale;

        PropertyBag propBag = new PropertyBag();
        propBag.setStrPropertyValue("Locale", "set");
        try
        {
            setDriverSpecificObject(m_locale, propBag);
        }
        catch(ConnectionException mme)
        {
            m_eh.error(mme, getClass().getName(), "setLocale");
        }
    }

    /**
     * @hidden
     *
     * @status hidden
     */
     
    public Object getRemoteConnection() {
      return (Object)getConnectionDriver().getRemoteConnection();
    }

    /**
     * @hidden
     *
     * @status hidden
     */
     
    public void setRemoteConnection(Object remoteConnection){
      getConnectionDriver().setRemoteConnection(remoteConnection);
    }

    /**
     * @hidden
     */
    public void setLoadParameter(String loadType)
    {
        Property prop = new Property();
        prop.setStrValue(MDU.LOAD_TYPE, loadType, MDU.UI_NONE);
        m_ConnectionObj.setProperty(prop);
    }

    /**
     * @hidden
     */
    public String getLoadParameter()
    {
        Property prop = m_ConnectionObj.getProperty(MDU.LOAD_TYPE);
        if(prop != null)
        {
            return prop.getStrValue();
        }
        return null;
    }

    public boolean isAlive()
    {
      if(m_ConnectionDriver == null)
      {
        return false;
      }
      if(m_ConnectionDriver.getClass().getName().equals("oracle.dss.connection.server.drivers.mdm.MDMConnectionDriverImpl"))
      {
        // I have to reflection because we dont want any dependencies on MDMDriver from this class
        try
        {
          Method method = m_ConnectionDriver.getClass().getMethod("isAlive",new Class[0]);
          if(method != null)
          {
            Object _val = method.invoke(m_ConnectionDriver,new Object[0]);         
            if (_val instanceof Boolean)
                return ((Boolean)_val).booleanValue();
            else
                return false;
          }
          else
          {
            return false;
          }         
        }
        catch (Exception e){
          return false;
        }
      }
      //else return true for now, other drivers do not have this implementation      
      return true;
    }

    /**
     * This method validates the internal connection version.  For OLAP connection,
     * the "OLAPI Interface" module version is checked for validation and for
     * persistence connection, the schema/java version is used.
     *
     * @return <code>true</code>  If version is valid
     *         <code>false</code> If version is invalid.
     * @status new
     */
    public boolean verifyVersion()
    {
        int _flag = m_ConnectionObj.getIntPropertyValue(CB.VERSION);

        if(_flag == CB.NOT_VALID)
            return false;
        else
            return true;
    }

    public PropertyBag getVersionInfo()
    {
        PropertyBag _bag = null;
        if(m_ConnectionDriver != null)
            _bag = m_ConnectionDriver.getVersionInfo();
        if(_bag == null)
            _bag = new PropertyBag();

        String _beanVersion = VersionInfo.getProperty(this, VersionInfo.BUILD_VERSION);
        if(_beanVersion != null)
            _bag.setStrPropertyValue(CB.CONNECTION_BEAN_VERSION, _beanVersion);
            
        return _bag;
    }

    public boolean getFeature(String feature)
    {
        if (m_ConnectionDriver != null)
            return m_ConnectionDriver.getFeature(feature);
        else
            return false;
    }
}
