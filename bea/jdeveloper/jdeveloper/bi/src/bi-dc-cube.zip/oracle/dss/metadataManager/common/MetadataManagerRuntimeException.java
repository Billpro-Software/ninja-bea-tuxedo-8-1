/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import oracle.dss.util.BIBaseRuntimeException;

/**
 * @hidden
 */
public class MetadataManagerRuntimeException extends BIBaseRuntimeException
{
    /**
     * Constructor
     * @hidden
     */
    public MetadataManagerRuntimeException(String message, Throwable prevException)
    {
        super(message, prevException);
    }
}
