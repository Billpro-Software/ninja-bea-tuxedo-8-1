/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.builder;

public class BuilderModel {

    /*
     * Public
     */
     
    public BuilderModel(BuilderContext bc) {
        m_bc = bc;
    }
    
    public BuilderContext getContext() {
        return m_bc;
    }
    
    /*
     * Private
     */
     
    private BuilderContext m_bc = null;
}
