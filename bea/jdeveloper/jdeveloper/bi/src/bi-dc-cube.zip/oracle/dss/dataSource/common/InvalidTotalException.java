/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if an invalid total is found.
 *
 * @status New
 */
public class InvalidTotalException extends QueryException
{
    /**
     * Cannot total measure dimension
     * @status New
     */
    public static final int INVALID_TOTAL_MEASURE = 1;

    /**
     * Cannot total with measure dimension on same edge faster varying than total dim
     * @status New
     */
    public static final int INVALID_TOTAL_MEASURE_EDGE = 2;

    /**
     * Cannot aggregate a non-numeric measure
     * @status New
     */
    public static final int INVALID_TOTAL_MEASURE_TYPE = 3;
    
    // Dimension involved
    /**
     * @hidden
     */
    protected String m_dim = null;

    // Reason code
    /**
     * @hidden
     */
    protected int m_reason = -1;

    /**    
     * Constructor for an invalid TotalStep exception
     *
     * @param s       Message to display.
     * @param dimension Dimension for which the invalid total was specified
     * @param reason Enumerated reason code
     * @param e       Previous exception to carry (may be null).
     *
     * @status New
     */
    public InvalidTotalException(String s, String dimension, int reason, Throwable e)
    {
        super(s, e);
        m_dim = dimension;
        m_reason = reason;
    }

    /**
     * Return the reason code for this invalid TotalStep
     *
     * @return enumerated reason code
     * @status New
     */
    public int getReason()
    {
        return m_reason;
    }

    /**
     * Return the dimension for which the invalid TotalStep was specified
     *
     * @return dimension name
     *
     * @status New
     */
    public String getDimension()
    {
        return m_dim;
    }
}
