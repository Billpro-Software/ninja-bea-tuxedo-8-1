/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Base class for data change events.
 *
 * @status Documented
 */
public abstract class DataChangeEvent extends QueryEvent implements MergeEvent
{
    /**
     * Constructs the event.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param dataChanged  <code>true</code> if the data cursor changed,
     *                     <code>false</code> if not.
     * @param  type        One of the oracle.dss.util.DataChangedEvent types indicating the type of operation that changed the data, if known     
     *
     * @status Documented
     */
    public DataChangeEvent(Object source, boolean dataChanged, int changeType) {
        super(source);
        
        data = dataChanged;
        m_changeType = changeType;
    }    
    
    /**
     * Indicates whether the data cursor changed.
     *
     * @return <code>true</code> if the data cursor changed,
     *         <code>false</code> if not.
     *
     * @status Documented
     */
    public boolean isDataChanged() {
        return data;
    }

    /**
     * Retrieves the type of operation that changed the data (if known)
     *
     * @return oracle.dss.util.DataChangedEvent change type
     *
     * @status New
     */
    public int getChangeType() 
    {
        return m_changeType;
    }

    /**
     * @hidden
     * Merge another DataChangeEvent into this one.
     *
     * @param event change event to merge
     */
    public void merge(MergeEvent event) {
        DataChangeEvent dce = (DataChangeEvent)event;
        // Data will change if either this event or the parameter event say it will
        data = dce.data || data;
        // Take latest type
        m_changeType = dce.getChangeType();
    }

    // Fields
    /**
     * @hidden
     * @serial if true, data has changed in the cursor
     */
    protected boolean               data;
    /**
     * @hidden
     * @serial type of data change
     */
    protected int m_changeType  = oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE;    
}
