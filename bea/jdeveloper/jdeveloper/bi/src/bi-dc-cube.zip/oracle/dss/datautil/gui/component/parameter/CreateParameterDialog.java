/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/CreateParameterDialog.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.parameter;

import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;

import oracle.dss.datautil.gui.StandardDialog;
import oracle.dss.datautil.gui.component.ComponentContext;

/**
 * <pre>
 * <code>CreateParameterDialog</code>.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   05/15/07 - Fix Bug 6048121 - Please add help context_ids to BI
 *                         Model dialog.
 *    gkellam   04/13/07 - Fix Bug 5985624 - QueryBuilder: New parameter dialog
 *                         missing help button.
 *    gkellam   03/06/07 - Limit size of parameter dialog.
 * 
 */
public class CreateParameterDialog extends StandardDialog {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Help Context ID for <code>CreateParameterDialog</code>.
   * 
   * @status new
   */
  public static String CREATE_PARAMETER_DIALOG_HELP_CONTEXT_ID = "f1_dvt_bidc_new_parameter_html";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private CreateParameterPanel m_createParameterPanel = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <pre>
   * Constructor that takes a parent Dialog.  
   * 
   * Note that setModel and initialize must be called on the contained 
   * CreateParameterPanel (obtained by calling getCreateParameterPanel)
   * before this Dialog is used.
   * </pre>
   * 
   * @param dialogParent A <code>Dialog</code> representing the parent.
   * 
   * @status new 
   */
  public CreateParameterDialog (Dialog dialogParent) {
    super (dialogParent, null, true, null);
    initDialog();
  }

  /**
   * <pre>
   * Constructor that takes a parent Frame.  
   * 
   * Note that setModel and initialize must be called on the contained 
   * CreateParameterPanel (obtained by calling getCreateParameterPanel)
   * before this Dialog is used.
   * </pre>
   * 
   * @param frameParent A <code>Dialog</code> representing the parent.
   * 
   * @status new 
   */
  public CreateParameterDialog (Frame frameParent) {
    super (frameParent, null, true, null);
    initDialog();
  }
  
  /**
   * Constructor that takes a parent Dialog and ComponentContext.
   * 
   * @param dialogParent A <code>Dialog</code> representing the parent.
   * @param componentContext A <code>ComponentContext</code> representing the context.
   * 
   * @status new 
   */
  public CreateParameterDialog (Dialog dialogParent, ComponentContext componentContext) {
    super (dialogParent, null, true, null);
    initDialog();
  }

  /**
   * Constructor that takes a parent Frame and ComponentContext.
   * 
   * @param frameParent A <code>Dialog</code> representing the parent.
   * @param componentContext A <code>ComponentContext</code> representing the context.
   * 
   * @status new 
   */
  public CreateParameterDialog (Frame frameParent, ComponentContext componentContext) {
    super (frameParent, null, true, null);
    initDialog();
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  // javadoc inherited from base class
  public String getTitle() {
    return m_createParameterPanel.getResourceString ("NewParameter");
  }
  
  /**
   * Retrieves the CreateParameterPanel contained in this Dialog
   * 
   * @return The CreateParameterPanel
   */
  public CreateParameterPanel getCreateParameterPanel() {
    return m_createParameterPanel;
  }
  
  public void dismissDialog (boolean bCancelled) {
    if (!bCancelled) {
      m_createParameterPanel.apply();
    }

    super.dismissDialog (bCancelled );
  }
  
  /**
   * Retrieves the Help context ID that is associated with this dialog.
   *
   * This Help context ID is used to enable Help systems to map a particular
   * component to the proper help topic.
   *
   * @return A <code>string</code> that represents the Help context ID.
   *
   * @status documented
   */
  public String getHelpContextID() {
		return CREATE_PARAMETER_DIALOG_HELP_CONTEXT_ID;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected void initDialog() {
    m_createParameterPanel = new CreateParameterPanel();
    setContent (m_createParameterPanel);
    setResizable (true);

    setPreferredSize (new Dimension (320, 240));
  }
}