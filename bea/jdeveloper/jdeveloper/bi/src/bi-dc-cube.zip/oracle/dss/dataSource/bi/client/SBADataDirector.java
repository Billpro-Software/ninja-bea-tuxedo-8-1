/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBADataDirector.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     10/31/06 - Move files back to oracle.dss.util
    bmoroze     05/12/06 - 
    jramanat    05/10/06 - 
    bmoroze     05/04/06 - 
    jramanat    04/20/06 - SBA-style drilling 
    bmoroze     03/03/06 - 
    jramanat    02/17/06 - Creation
 */

package oracle.dss.dataSource.bi.client;

import java.text.MessageFormat;

import java.util.BitSet;

import java.util.Vector;

import oracle.dss.dataSource.client.QueryClient;
import oracle.dss.dataSource.common.CommonDataDirector;
import oracle.dss.dataSource.common.CursorUtils;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.util.ColumnOutOfRangeException;
import oracle.dss.util.ColumnSortInfo;
import oracle.dss.util.CubeDataDirector;
import oracle.dss.util.DimensionSortInfo;
import oracle.dss.util.InvalidDrillPathException;
import oracle.dss.util.InvalidDrillTargetException;
import oracle.dss.util.MemberSortInfo;
import oracle.dss.util.RelationalDataDirector;
import oracle.dss.util.SortInfo;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataChangedEvent;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataDirectorException;
import oracle.dss.util.DataMap;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.RowOutOfRangeException;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.transform.DataAccessLong;
import oracle.dss.util.transform.TabularDataAccess;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBADataDirector.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public class SBADataDirector extends CommonDataDirector implements CubeDataDirector, RelationalDataDirector {
  private TabularDataAccess m_dataAccess;

  public SBADataDirector(Query query) {
    super(query);
  }
  
  protected boolean isNoData() throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException {
    if (m_dataAccess != null) {
      // Check if any extents are 0--if no data, can't pivot
      int edgeCount = m_dataAccess.getEdgeCount();
      // Don't look at page edge right now--extent may very well be zero
      for (int e = 0; e < edgeCount; e++) {
        int layerCount = m_dataAccess.getLayerCount(e);
        if (layerCount > 0) {
          // If below the page edge, check the extent
          if (e < DataDirector.PAGE_EDGE) {
            if (m_dataAccess.getEdgeExtent(e) == 0) {
              return true;
            }
          }
          else {
            // Check each layer for non zero
            int[] hPos = m_dataAccess.getEdgeCurrentHPos(e);
            for (int l = 0; l < layerCount; l++) {
              if (m_dataAccess.getMemberSiblingCount(e, hPos, l) == 0)
                return true;
            }
          }
        }
      }
      return false;
    }
    else {
      return true;
    }
  }

    protected DataAccessLong getDataAccessLong()
    {
        return (DataAccessLong)m_dataAccess;
    }
    
    public DataAccess getDataAccess(DataDirector dd)
    {
        // Just give the caller their own data access
        try
        {
            return ((QueryClient)m_query).generateDataAccess(dd, DataChangedEvent.UNKNOWN_CHANGE);
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        
    }
    
  public DataAccess getDataAccess()
  {
      return getDataAccess(this);
  }
  
    
  public DataAccess getCurrentDataAccess()
  {
      return m_dataAccess;
  }
  
  protected void setDataAccess(TabularDataAccess da) {
    m_dataAccess = da;
  }

  // javadoc from interface
  public void update() throws DataDirectorException {
      try
      {
          if (!m_query.isAutoUpdate())
          {
              m_query.update();
              m_query.setAutoUpdate(true);
          }
      }
      catch (Exception e)
      {
          throw new DataDirectorException(e.getMessage(), e);
      }
  }

  // javadoc from interface
  public void setManualUpdate() {
      try
      {
        m_query.setAutoUpdate(false);
      }
      catch (Exception e)
      {
          throw new QueryRuntimeException(e.getMessage(), e);
      }
  }

  public boolean revalidate() {
    return refresh();
  }

  public boolean refresh() 
  {
      try
      {
            m_query.refresh(QueryConstants.REFRESH_REBUILD);
            return true;
      }
      catch (Exception e)
      {
          throw new QueryRuntimeException(e.getMessage(), e);
      }
  }

  // javadoc from interface
  public boolean insertValueCalc(int row, int column, int flags, Object calc) throws RowOutOfRangeException, ColumnOutOfRangeException, DataDirectorException {
      return false;
  }

  // javadoc from interface
  public boolean insertMemberCalc(int edge, int layer, int slice, int flags, Object calc) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException {
      return false;
  }

  // javadoc from interface
  public boolean deleteValueCalc(int row, int column) throws RowOutOfRangeException, ColumnOutOfRangeException, DataDirectorException {
      return false;
  }    
  
  // javadoc from interface
  public boolean deleteMemberCalc(int edge, int layer, int slice) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException {
      return false;
  }

  public boolean reorder(int edge, int fromLayer, int toLayer, int flags) throws DataDirectorException {
    return false;
  }

    // javadoc from interface
    public Object getProperty(String name) throws DataDirectorException
    {
        if (name == null)
            return null;
            
        if (name.equals(DataDirector.PROP_DEFAULT_DRILL_TYPE))
            return new Integer(DataDirector.DRILL_REPLACE | DRILL_MEMBERS_BELOW);
        else if (name.equals(DataDirector.PROP_SUPPORTED_DRILL_TYPES))
            return new Integer[] {new Integer(DataDirector.DRILL_REPLACE),
                                  new Integer(DataDirector.DRILL_REPLACE | DataDirector.DRILL_MEMBERS_ABOVE),
                                  new Integer(DataDirector.DRILL_REPLACE | DataDirector.DRILL_MEMBERS_BELOW)};
            
        return super.getProperty(name);
    }    

  public boolean changeEdgeCurrentHPos(int edge, int[] hPos, int maxLayerSpecified) throws DataDirectorException
  {
        try
        {
            if (edge == DataDirector.PAGE_EDGE)
            {
                long slice = m_dataAccess.getSliceFromHPos(edge, hPos);
                m_dataAccess.setCurrentPosition(edge, slice);
                ((QueryClient)m_query).setCurrentPage(slice, null, this);
            }
            else
            {
                // Set it only in our da
                m_dataAccess.setCurrentPosition(edge, m_dataAccess.getSliceFromHPos(edge, hPos));
                // And let our director listeners know about it
                super.fireDataChanged(oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, true, false, false, false, m_dataAccess);                
            }
        }
        catch (Exception e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
        return true;
  }

  public boolean changeEdgeCurrentSlice(int edge, int slice) throws EdgeOutOfRangeException, SliceOutOfRangeException, DataDirectorException {
    try {
      int layerCount = m_dataAccess.getLayerCount(edge);
      return changeEdgeCurrentHPos(edge, m_dataAccess.getMemberHPos(edge, layerCount - 1, slice), layerCount - 1);
    }
    catch (LayerOutOfRangeException e) {
      throw new DataDirectorException(e.getMessage(), e);
    }
  }

  public boolean drill(int edge, int layer, int slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException {
    return false;
  }    

  // javadoc from interface
  public boolean drillOK(int edge, int layer, int slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException {
      return false;
  }

  // javadoc from interface
  public boolean drill(int edge, int layer, int[] slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException {
    if (slice == null)
      return false;
    
    boolean retVal = true;
    for (int i = 0; i < slice.length; i++) {
      if (!drill(edge, layer, slice[i], pathID, targetID, flags))
        retVal = false;
    }
    return retVal;
  }

    protected boolean bitSet(int flags, int bit)
    {
        return (flags & bit) > 0;
    }
    
  // javadoc from interface
  public boolean drillOK(int edge, int layer, int[] slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException {
    if (slice == null)
      return false;
    
    boolean retVal = true;
    for (int i = 0; i < slice.length; i++) {
      if (!drillOK(edge, layer, slice[i], pathID, targetID, flags))
        return false;
    }
    return true;
  }

  // javadoc from interface        
  public boolean drill(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException {
    DataAccess dp = getCurrentDataAccess();
    if (dp == null)
      return false;
        
    if (layer >= dp.getLayerCount(edge)) {
      throw new LayerOutOfRangeException(MessageFormat.format(
          m_query.getQueryManager().getResourceString(
          "Dimension out of range in metadata cursor for edge, dimension: "), new String[] {
              Integer.toString(edge), Integer.toString(layer)}));
    }

    String dim = getDimName(edge, layer, true, false)[0];
    try {
      int drillState = ((Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DRILLSTATE)).intValue();
      int direction = bitSet(drillState, DataDirector.DRILLSTATE_IS_DRILLED) ? -1 : 0;
      direction = bitSet(drillState, DataDirector.DRILLSTATE_DRILLABLE) ? 1 : direction;
      if (direction != 0 || (direction == 0 && bitSet(flags, DataDirector.DRILL_BACK))) {
        MDItem item = (MDItem)m_query.getMDObject(MM.UNIQUE_ID, dim, MM.ITEM);
        Vector paths = item.getDrillDownPaths();
        String path = paths == null ? null : ((MDItem)paths.get(0)).getUniqueID();
        OlapQDR qdr = _getOutsideLayerQDR(edge, layer, slice, dim);
        String target = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_VALUE));
        BitSet queryFlags = new BitSet();
        // Temporary: caller could have to pass us the proper flags--i.e., drill members above or below, to do
        // an insert drill?
        // Flags == 0 is a "defaulting" mechanism for old crosstab
        if (flags == 0)
            flags = DataDirector.DRILL_REPLACE | DataDirector.DRILL_MEMBERS_BELOW;
        if (bitSet(flags, DataDirector.DRILL_REPLACE) || bitSet(flags, DataDirector.DRILL_BACK))
        {
            // Relational drilling of some kind
            // Indicates layer should be inserted vs. replaced
            if (bitSet(flags, DataDirector.DRILL_MEMBERS_BELOW))
            {
                queryFlags.set(DataDirector.DRILL_MEMBERS_BELOW);
                queryFlags.set(direction > 0 ? DataDirector.DRILL_REPLACE : DataDirector.DRILL_BACK);
            }
            else if (bitSet(flags, DataDirector.DRILL_MEMBERS_ABOVE))
            {
                queryFlags.set(DataDirector.DRILL_MEMBERS_ABOVE);
                queryFlags.set(direction > 0 ? DataDirector.DRILL_REPLACE : DataDirector.DRILL_BACK);
            }
            else
            {
                // Pure replace or back
                if (bitSet(flags, DataDirector.DRILL_BACK))
                    queryFlags.set(DataDirector.DRILL_BACK);
                else
                    queryFlags.set(DataDirector.DRILL_REPLACE);
            }
            m_query.drill(dim, edge, new QDR[] {qdr}, new String[] {path}, new String[] {target}, queryFlags);
            return true;
        }
/*        else
        {
            // Insert members drill
            if (m_query.isAsymmetricDrilling()) {
              // Determine the QDR for layers "outside" this layer, if any
              qdr = _getOutsideLayerQDR(edge, layer, slice, dim);
            }
            String parent = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_PARENT));
            Integer levelObj = (Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_INDENT);
            int level = -1;
            if (levelObj != null)
                level = levelObj.intValue();
            m_query.drill(dim, new String[] {target}, new String[] {path}, new int[] {direction}, new boolean[] {bitSet(flags, DataDirector.DRILL_MEMBERS_ABOVE)}, new String[] {parent}, null, new int[] {level}, new OlapQDR[] {qdr});
        }*/
      }                
    }
    catch (QueryException dse) {
      throw new DataDirectorException(dse.getMessage(), dse);
    }
    catch (LayerOutOfRangeException dore) {
      throw dore;
    }
    catch (SliceOutOfRangeException iore) {
      throw iore;
    }
    catch (MetadataManagerException de) {
      throw new DataDirectorException(de.getMessage(), de);
    }
    return false;
  }

     
  public boolean drillOK(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException {            
    DataAccess dp = getCurrentDataAccess();
    if (dp == null)
      return false;
        
    String dimArray[] = getDimName(edge, layer, true, false);
    if (dimArray == null || dimArray.length == 0) {
      // Probably a layer problem
      throw new LayerOutOfRangeException(layer, dp.getLayerCount(edge));
    }
    String dim = dimArray[0];
    int drillState = ((Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DRILLSTATE)).intValue();
    int direction = ((drillState & DataDirector.DRILLSTATE_IS_DRILLED) > 0) ? -1 : 0;
    direction = ((drillState & DataDirector.DRILLSTATE_DRILLABLE) > 0) ? 1 : direction;
    if (direction != 0 || (direction == 0 && bitSet(flags, DataDirector.DRILL_BACK))) {
      return true;
    }
    return false;
  }

  // javadoc from interface    
  public boolean setDimensionSorts(DimensionSortInfo[] dimensionSortInfo) throws DataDirectorException {        
    return false;
  }
  
  // javadoc from interface
  public DimensionSortInfo[] getDimensionSorts() throws DataDirectorException {
    return null;
  }

  // javadoc from interface    
  public boolean setMemberSorts(MemberSortInfo[] dimensionSortInfo) throws DataDirectorException {        
    return false;
  }
  
  // javadoc from interface
  public MemberSortInfo[] getMemberSorts() throws DataDirectorException {
    return null;
  }

    public void setDataMap(DataMap map, int sizeRow, int sizeColumn) throws DataDirectorException
    {
        m_query.setDataMap(map);
    }

   public void setMetadataMap(int edge, int layer, MetadataMap map, int size) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
   {
       String[] layerNames = getDimName(edge, layer, false, true);
       try
       {
           String layerName = layerNames != null && layerNames.length > 0 ? layerNames[0] : null;           
           m_query.setMetadataMap(layerName, map);
       }
       catch (Exception e)
       {
           throw new DataDirectorException(e.getMessage(), e);
       }
   }

  // javadoc from interface
  public boolean setSorts(SortInfo[] sortInfo) throws LayerOutOfRangeException, DataDirectorException {
    return false;
  }

  // javadoc from interface
  public SortInfo[] getSorts() throws LayerOutOfRangeException, DataDirectorException {
    return null;
  }

  // javadoc from interface
  public boolean setColumnSorts(ColumnSortInfo[] sortInfo) throws LayerOutOfRangeException, DataDirectorException {
    try {
      ColumnSortWrapper[] wrappers = null;
        Vector<ColumnSortWrapper> wrapVec = new Vector<ColumnSortWrapper>();
      if (sortInfo != null) {
        for (int i = 0; i < sortInfo.length; i++) {  
            if (sortInfo[i].getLayerName() != null && sortInfo[i].getDirection() != null && sortInfo[i].getDirection().length > 0)
          wrapVec.addElement(new ColumnSortWrapper(sortInfo[i]));
        }
      }
        wrappers = (ColumnSortWrapper[])wrapVec.toArray(new ColumnSortWrapper[] {});
      m_query.setColumnSorts(wrappers);
      return true;
    }
    catch (Exception e) {
      throw new DataDirectorException(e.getMessage(), e);
    }
  }

  // javadoc from interface
  public ColumnSortInfo[] getColumnSorts() throws LayerOutOfRangeException, DataDirectorException {
    return m_query.getColumnSorts();
  }
}
