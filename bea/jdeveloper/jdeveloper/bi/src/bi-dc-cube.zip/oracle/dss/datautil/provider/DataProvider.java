/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/provider/DataProvider.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.provider;

import java.util.Vector;

import oracle.dss.datautil.QueryEditorException;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.util.DataAccess;

 /**
  * <pre>
  * Defines data provider interfaces used to provide data.
  * </pre>
  *
  * @see oracle.dss.datautil.provider.MetadataProvider
  * 
  * @author gkellam 
  * @since  11.0.0.0.3
  * @status new
  *
  * MODIFIED    (MM/DD/YY)
  *  bmoroze     03/15/07 - 
  *  gkellam     03/06/07 - Provide more DataAccess options used to control
  *                         data retrieval.
  *  rbalexan    10/28/05 - Remove apply method - moved to QB model.
  *  gkellam     08/22/05 - 
  *  rbalexan    07/12/05 - add a public apply method 
  *  rbalexan    07/07/05 - 
  *  gkellam     06/23/05 - Initial R11 CalcBuilder framework. 
  *  gkellam     06/17/05 - Creation
  */

public interface DataProvider {

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Returns up to 10 DimensionMembers for the specified item
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for
   * @param strLabelType A <code>String</code> representing the labelType to use.
   * 
   * @return <code>Vector</code> of members.
   * 
   * @throws <code>QueryEditorException</code>
   */
  public Vector getMembers (String strItemID, String strLabelType) throws QueryEditorException;

  /**
   * Evaluates a Selection and returns the resulting DimensionMembers
   * 
   * @param selection A <code>Selection</code> to evaluate.
   * 
   * @return <code>DataAccess</code>
   * 
   * @throws QueryEditorException
   */
   // blm - Selection code moved to dvt-olap
/*  public DataAccess getDataAccess (Selection selection) throws QueryEditorException;*/
  
  /**
   * Returns the DataAccess for the specified item id.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for
   *                  
   * @return <code>DataAccess</code>
   *
   * @throws QueryEditorException
   */
  public DataAccess getDataAccess (String strItemID) throws QueryEditorException;

  /**
   * Retrieves the <code>DataAccess</code> object for a specified item (LOV query) 
   * and optional set of data filters.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for.
   * @param dataFilters A <code>BaseDataFilter[]</code> which specifies data filters 
   *        to use in the LOV query.
   * @return A <code>DataAccess</code>.
   *
   * @status Documented
   */
  public DataAccess getDataAccess (String strItemID, BaseDataFilter[] dataFilters);
  
  /**
   * Retrieves a <code>DataAccess</code> object that contains dimension
   * member metadata positioned at the stored selection for the specified
   * item.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for.
   * @param nInstance A <code>int</code> which represents the caller-defined ID 
   *        that determines which item DataAccess to get.
   * 
   * @return A <code>DataAccess</code> object that contains the specified
   *         item; an empty <code>DataAccess</code> object, which
   *         contains zero values, if there is no selection available to
   *         evaluate.
   *
   * @throws QueryEditorException thrown if an error occurs.
   * 
   * @status New
   */
  public DataAccess getDataAccess (String strItemID, int nInstance) throws QueryEditorException;

}
