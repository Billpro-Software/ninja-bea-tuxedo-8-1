/**
 * QueryUtils.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */
package oracle.dss.datautil.query;

import java.util.Vector;

import oracle.dss.datautil.client.DataUtilRuntimeException;
import oracle.dss.datautil.client.IllegalArgException;
import oracle.dss.datautil.client.resource.DataUtilClientBundle;

import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.QueryAccess;
import oracle.dss.datautil.QueryContext;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.MetadataMap;

/**
 * @hidden
 *
 * Utility class containing data beans related query methods.
 *
 * @status hidden
 */
public class QueryUtils extends Object {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   *
   * Determines number of levels to retrieve when creating a dimension member list.
   * 
   * @status hidden
   */
  protected int m_nLevels = 2;

  /**
   * @hidden
   *
   * Determines the number of levels used as threshold to determine when
   * levels should be limited.
   * 
   * @status hidden
   */
  protected int m_nLevelsThreshold = 1;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   * Constructs a default QueryUtils object.
   *
   * @status hidden
   */
  public QueryUtils() {
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Retrieves a <code>Vector</code> of <code>DimensionMember</code> objects
   * associated with the specified dimension, hierarchy, levels and label type.
   *
   * @param queryContext A <code>QueryContext</code> object from which to
   *        retrieve the dimension members.
   * @param strDimensionID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the dimension whose 
   *        members are to be retrieved.
   * @param strHierarchyID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the hierarchy whose 
   *        members are to be retrieved.      
   * @param vstrLevelIDs A <code>Vector/code> of <code>String</code> values 
   *        that represents the <code>MetadataManager</code> unique IDs of the 
   *        levels whose members are to be retrieved.      
   * @param strLabelType A <code>String</code> that represents the type of labels 
   *        to be retrieved.
   * @param vDimensionMembers A <code>Vector</code> of <code>DimensionMember</code>
   *        objects that represent the dimension members found.
   *
   * @return <code>boolean</code> which is <code>true</code> if the dimension 
   *         members were retrieved successfully and <code>false</code> otherwise.
   *
   * @see oracle.dss.util.LayerMetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_VALUE
   * @see oracle.dss.util.LayerMetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_SHORTLABEL
   *
   * @status hidden
   */
   // blm - Selection code moved to dvt-olap
/*  static public boolean getDimensionMembers (QueryContext queryContext,
    String strDimensionID, String strHierarchy, Vector vstrLevels, String strLabelType,
      Vector vDimensionMembers) throws IllegalArgException {

    boolean         bRetVal         = false;
    DataAccess      dataAccess      = null;
    DimensionMember dimensionMember = null;
    int             nIndex          = -1;
    int             nCount          = -1;
    QueryAccess     queryAccess     = null;

    // If the user hasn't specified a QueryContext, there isn't much we can do.
    if (queryContext == null) {
      throw new IllegalArgException (
        DataUtilClientBundle.EXC_QUERYCONTEXT_NOT_SET, 1, queryContext);
    }
    
    if (strDimensionID == null || strDimensionID.length() == 0 || 
        strLabelType == null || vDimensionMembers == null) {
      return false;
    }

    try {
      // Create a QueryAccess that can be used to evaluate the Query
      queryAccess = queryContext.createQueryAccess ();

      // Let the user know if we can create a QueryAccess.
      if (queryAccess == null) {
        throw new DataUtilRuntimeException (
          DataUtilClientBundle.EXC_QUERYACCESS_NOT_CREATED, null);
      }

      // Build a selection based on the specified dimension
      Selection selection = 
        getDimensionMembersSelection (strDimensionID, strHierarchy, vstrLevels);
 
      dataAccess = queryAccess.getDataAccess (selection);

      if (dataAccess != null) {
        // Add all the dimension member info into the list.
        nCount = dataAccess.getEdgeExtent (DataDirector.COLUMN_EDGE);
        
        String strDimensionMemberID;
        String strDimensionMemberLabel;
        String strLevelID;
        String strLevelName;
        
        for (nIndex = 0; nIndex < nCount; nIndex++) {
          // Create the DimensionMember ID
          strDimensionMemberID =
            DataUtils._makeString (dataAccess.getMemberMetadata (0, 0, nIndex,
              MetadataMap.METADATA_VALUE));

          // Create the DimensionMember Label
          strDimensionMemberLabel =
            DataUtils._makeString (dataAccess.getMemberMetadata (0, 0, nIndex,
              DataUtils.mapToMetadataMapType (strLabelType)));

          // Create the Level ID
          strLevelID = 
            DataUtils._makeString (
              dataAccess.getMemberMetadata (0, 0, nIndex, MetadataMap.METADATA_LEVEL));
          
          // Create the Level Name
          strLevelName = 
            DataUtils._makeString (
              dataAccess.getMemberMetadata (0, 0, nIndex, MetadataMap.METADATA_LEVEL_NAME));

          // Create the DimensionMember
          dimensionMember = 
            new DimensionMember (strDimensionMemberID, strDimensionMemberLabel, 
              strHierarchy, strLevelID, strLevelName);
         
          // Add the DimensionMember to the list
          vDimensionMembers.addElement (dimensionMember);
        }
      }

      bRetVal = true;
    }

    catch (Exception exception) {
      bRetVal = false;
    }

    // Release the DataAccess resources
    if (dataAccess != null) {
      dataAccess.release();
    }

    // Release the QueryAccess resources
    if (queryAccess != null) {
      queryAccess.release();
    }

    // Return the result
    return bRetVal;
  }
*/
  /**
   * @hidden
   * 
   * Retrieves a <code>Selection</code> that can be evaluated to retrieve
   * dimension members, where levels are limited for performance.
   *
   * @param metadataManager a <code>MetadataManager</code> value from which
   *        to retrieve the levels.
   * @param strDimensionID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the dimension whose 
   *        members are to be retrieved.
   * @param strHierarchyID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the hierarchy whose 
   *        members are to be retrieved.      
   *
   * @return <code>Selection</code> that can be evaluated to retrieve dimension
   *         members.
   *
   * @status hidden
   */
   // blm - Selection code moved to dvt-olap
/*  static public Selection getDimensionMembersSelection (MetadataManager metadataManager,
                                  String strDimensionID, String strHierarchyID) {
  
    QueryUtils queryUtils = new QueryUtils();
  
    // Limit the number of levels retrieved for performance.
    Vector vstrLevels = 
      queryUtils.getAdjustedLevels (metadataManager, strHierarchyID);

    // Return the selection
    return getDimensionMembersSelection (strDimensionID, strHierarchyID, vstrLevels);
  }
*/
  /**
   * @hidden
   * 
   * Retrieves a <code>Selection</code> that can be evaluated to retrieve
   * dimension members.
   *
   * @param strDimensionID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the dimension whose 
   *        members are to be retrieved.
   * @param strHierarchyID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the hierarchy whose 
   *        members are to be retrieved.      
   * @param vstrLevelIDs A <code>Vector/code> of <code>String</code> values 
   *        that represents the <code>MetadataManager</code> unique IDs of the 
   *        levels whose members are to be retrieved.      
   *
   * @return <code>Selection</code> that can be evaluated to retrieve dimension
   *         members.
   *
   * @status hidden
   */
   // blm - Selection code moved to dvt-olap
/*  static public Selection getDimensionMembersSelection (String strDimensionID, 
    String strHierarchyID, Vector vstrLevels) {

    if ((strDimensionID == null || strDimensionID.length() == 0)) {
      return null;
    }

    // Build a selection based on the specified dimension
    Selection selection = new Selection (strDimensionID);

    // Create an allStep for the query based on the specified dimension
    AllStep allStep = new AllStep (strDimensionID);

    // Update the hierarchy associated with the selection  
    if (strHierarchyID != null && strHierarchyID.length () > 0) {
      selection.setHierarchy (strHierarchyID);
      allStep.setHierarchy (strHierarchyID);
    }

    // Update the levels associated with the selection  
    // Although not required, specifying fewer levels can speed up some queries.
    if (vstrLevels != null && vstrLevels.size () > 0) {
      allStep.setLevels (vstrLevels);
    }

    // Add the AllStep to the selection
    selection.addStep (allStep);

    // Return the selection
    return selection;
  }
*/
  /**
   * @hidden
   * 
   * Retrieves the number of levels to retrieve from the specified hierarchy,
   * adjusted based on the level threshold count.
   *
   * @param metadataManager a <code>MetadataManager</code> value from which
   *        to retrieve the levels.
   * @param strHierarchy a <code>String</code> value which represents the
   *        hierarchy that we wish to retrieve level count for.
   *
   * @return A <code>int</code> value that represents the number of levels
   *         associated with the specified hierarchy.
   *
   * @status hidden
   */
  public Vector getAdjustedLevels (MetadataManager metadataManager, String strHierarchy) {


    // Check for null parameters
    if (metadataManager == null || strHierarchy == null)
      return null;

    // Get the number of levels associated with the hierarchy
    int nLevelCount = getLevelCount (metadataManager, strHierarchy);

    // Determine if the number of levels is greater than our threshold
    if (nLevelCount > getLevelThresholdCount()) {
      // Set the number of levels to be retrieved
      
      // We are basically just trying to avoid a situation where we end up
      // with a large number of dimension members, which can occur if we
      // include the bottom levels
      int nLevels = (nLevelCount > 2) ? getLevelCount() : 1;
        
      nLevelCount = Math.min (nLevelCount, nLevels);
    }

    // Return the list of levels, if any
    return getLevels (metadataManager, strHierarchy, nLevelCount);
  }

  /**
   * @hidden
   * 
   * Retrieve a list of level IDs associated with the specified hierarchy, if any.
   *
   * @param metadataManager a <code>MetadataManager</code> value from which
   *        to retrieve the levels.
   * @param strHierarchy a <code>String</code> value which represents the
   *        hierarchy that we wish to retrieve levels for.
   * @param nLevels a <code>int</code> value which represents the number
   *        of levels to retrieve.  A value of -1 retrieves all levels.
   *
   * @return A <code>Vector</code> value of level IDs associated with the
   *         specified hierarchy.  This value may be null if no levels are found.
   *
   * @status hidden
   */
  public Vector getLevels (MetadataManager metadataManager, 
                           String strHierarchy, int nLevels) {
    Vector vLevels = null;

    // If we have an invalid parameter, return null
    if ((metadataManager == null) || (strHierarchy == null) || (nLevels == 0))
      return null;

    try {

      // Retrieve the MDHierarchy associated with the specified ID
      MDHierarchy mdHierarchy =
        (MDHierarchy)metadataManager.getMDObject (MM.UNIQUE_ID,
          strHierarchy, MM.HIERARCHY);

      // Retrieve the level IDs associated with this hierarchy, if any
      if (mdHierarchy != null) {
        // Retrieve the MDLevels
        MDLevel[] mdLevels = mdHierarchy.getLevels();
        
        if ((mdLevels != null) && (mdLevels.length > 0)) {
          // Determine the number of levels to retrieve
          int nLevelCount = mdLevels.length;
          if (nLevels != -1) {
            nLevelCount = Math.min (nLevels, mdLevels.length);
          }

          vLevels = new Vector();

          // Iterate over each level and add its ID
          for (int nIndex = 0; nIndex < nLevelCount; nIndex++) {
            if (mdLevels[nIndex] != null) {
              String strLevelID = mdLevels[nIndex].getUniqueID();
              if (strLevelID != null)
                vLevels.addElement (strLevelID);
            }
          }
        }
      }
    }

    // If we have an exception, return no level IDs
    catch (MetadataManagerException e) {
      return null;
    }

    // Return the Level IDs found, if any  
    return vLevels;
  }

  /**
   * @hidden
   *
   * Retrieves the number of levels associated with the specified hierarchy.
   *
   * @param metadataManager a <code>MetadataManager</code> value from which
   *        to retrieve the levels.
   * @param strHierarchy a <code>String</code> value which represents the
   *        hierarchy that we wish to retrieve level count for.
   *
   * @return A <code>int</code> value that represents the number of levels
   *         associated with the specified hierarchy.
   *
   * @status hidden
   */
  public int getLevelCount (MetadataManager metadataManager, String strHierarchy) {
    int nLevelCount = 0;

    // If we have an invalid parameter, return null
    if ((metadataManager == null) || (strHierarchy == null))
      return 0;

    try {
      // Retrieve the MDHierarchy associated with the specified ID
      MDHierarchy mdHierarchy =
        (MDHierarchy)metadataManager.getMDObject (MM.UNIQUE_ID,
          strHierarchy, MM.HIERARCHY);

      // Retrieve the level IDs associated with this hierarchy, if any
      if (mdHierarchy != null) {
        // Retrieve the MDLevels
        MDLevel[] mdLevels = mdHierarchy.getLevels();
        nLevelCount = (mdLevels != null) ? mdLevels.length : 0;
      }
    }

    // If we have an exception, return no level IDs
    catch (MetadataManagerException e) {
      return 0;
    }

    // Return the number of levels found, if any
    return nLevelCount;
  }

  /**
   * @hidden
   *
   * Determines the number of levels to retrieve when creating a dimension
   * member list when a hierarchy's level threshold has been exceeded.
   *
   * @return A <code>int</code> value that represents the number of levels
   *         to retrieve when creating a dimension member list.
   * @status hidden
   */
  public int getLevelCount() {
    return m_nLevels;
  }

  /**
   * @hidden
   *
   * Determines the number of levels to retrieve when creating a dimension
   * member list when a hierarchy's level threshold has been exceeded.
   *
   * @param nLevels a <code>int</code> value that represents the number of levels
   *                to retrieve when creating a dimension member list.
   * @status hidden
   */
  public void setLevelCount (int nLevels) {
    m_nLevels = nLevels;
  }

  /**
   * @hidden
   *
   * Determines the number of levels used as threshold to determine when
   * levels should be limited.
   *
   * @return A <code>int</code> value that represents the number of levels.
   * @status hidden
   */
  public int getLevelThresholdCount() {
    return m_nLevelsThreshold;
  }

  /**
   * @hidden
   *
   * Determines the number of levels used as threshold to determine when
   * levels should be limited.
   *
   * @param nLevels a <code>int</code> value that represents the number of levels.
   * @status hidden
   */
  public void setLevelThresholdCount (int nLevelsThreshold) {
    m_nLevelsThreshold = nLevelsThreshold;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
}
