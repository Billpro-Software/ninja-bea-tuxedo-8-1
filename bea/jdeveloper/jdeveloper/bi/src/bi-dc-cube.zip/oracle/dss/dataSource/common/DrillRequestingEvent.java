/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

import oracle.dss.selection.OlapQDR;


/**
 * Informs listeners when a drill operation is requested. A listener has the
 * option to veto the drill operation by calling the <code>consume</code>
 * method of this event. If a listener vetoes the operation, then subsequent
 * listeners are not notified and the operation is cancelled (that is, not
 * added to the pending operation queue).
 *
 * @status Documented
 */
public class DrillRequestingEvent extends DrillEvent implements Consumable
{
    // javadoc from superclass
    public DrillRequestingEvent(Object source, String dimension, String[] value, String[] hierarchy, int[] delta, boolean[] above, String[] valueParent, String[] queryParent, int[] levelDepth, OlapQDR[] parentQDR)
    {
        super(source, dimension, value, hierarchy, delta, above, valueParent, queryParent, levelDepth, parentQDR);
    }


    /**
     * Constructor to use to drill to a relative level of the specified
     * hierarchy.
     * 
     * @param source     The source of the event, that is, the object that
     *                   fired the event.
     * @param dimension  The dimension to drill.
     * @param value      The dimension value, also known as dimension member
     *                   to be drilled.
     * @param hierarchy  The target hierarchy that defines the drill semantics.
     * @param delta      The relative number of levels to traverse within the
     *                   specified hierarchy. Positive numbers drill down,
     *                   negative numbers drill up.
     * @param valueParent  Value's parent dimension value; used for
     *                     optimizing later potential drill up requests.
     * @param queryParent  The item from the original query members under
     *                     which this drill occurs.
     * @param levelDepth   Optional performance hint that indicates the numeric 
     *                     level at which the drill target sits within its 
     *                     hierarchy.
     * @param parentQDR    An optional OlapQDR that specifies dimension/member 
     *                     pairs that limit where this drill (down) should take 
     *                     place (parents of the target).
     *
     * @status Documented
     */
    public DrillRequestingEvent(Object source, String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent, int levelDepth, OlapQDR parentQDR) {
        this(source, dimension, new String[] {value}, new String[] {hierarchy}, new int[] {delta}, new boolean[] {false}, new String[] {valueParent}, new String[] {queryParent}, new int[] {levelDepth}, new OlapQDR[] {parentQDR});
    }
    
    /**
     * Constructor to use to drill to a specific level of the specified
     * hierarchy.
     *
     * @param source     The source of the event, that is, the object that
     *                   fired the event.
     * @param dimension  The dimension to drill
     * @param value      dimension value to drill
     * @param hierarchy  The target hierarchy that defines the drill semantics.
     * @param level      The name of the target level to traverse to.
     * @param action     A constant (<code>Step.ADD</code>,
     *                   <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                   <code>Step.SELECT</code>) that represents the
     *                   selection step action.
     * @param flags      A list of optional flags. These flags are drill
     *                   constants that begin with the prefix DRILL_EXCLUDE_.
     *
     * @see  DrillConstants#DRILL_EXCLUDE_RANGE
     * @see  DrillConstants#DRILL_EXCLUDE_SELF
     * @see  DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see  oracle.dss.selection.step.Step#ADD
     * @see  oracle.dss.selection.step.Step#KEEP
     * @see  oracle.dss.selection.step.Step#REMOVE
     * @see  oracle.dss.selection.step.Step#SELECT
     *
     * @status Documented
     */
    public DrillRequestingEvent(Object source, String dimension, String value, String hierarchy, String level, int action, BitSet flags) {
        super(source, dimension, value, hierarchy, level, action, flags);
    }
    
    /**
     * Consumes this event.
     *
     * @status Documented
     */
    public void consume() {
        super.consume();
    }
    
    /**
     * Indicates whether this event was consumed.
     *
     * @return <code>true</code> if the event was consumed,
     *         <code>false</code> if not.
     *
     * @status Documented
     */
    public boolean isConsumed() {
        return super.isConsumed();
    }    
}
