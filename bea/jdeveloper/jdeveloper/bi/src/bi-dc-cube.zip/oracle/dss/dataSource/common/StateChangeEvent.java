/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.Operation;

import oracle.dss.util.AbstractMap;

/**
 * Base class for events that indicate that the state of a
 * <code>Query</code> object has been changed or
 * is about to be changed.
 *
 * @status Documented
 */
public abstract class StateChangeEvent extends QueryEvent
{
    /**
     * A constant that represents the Undo type of state change for a
     * <code>Query</code> object.
     * This type of change occurs when the <code>undo</code> method of the
     * <code>QueryEdit</code> object is called.
     *
     * @deprecated As of 3.1, replaced by {@link #STATE}
     * 
     * @status Documented
     */
    public static final int UNDO    = 0;
    
    /**
     * A constant that represents the Redo type of state change for a
     * <code>Query</code> object.
     * This type of change occurs when the <code>redo</code> method of the
     * <code>QueryEdit</code> object is called.
     *
     * @deprecated As of 3.1, replaced by {@link #STATE}
     * 
     * @status Documented
     */
    public static final int REDO    = 1;
    
    /**
     * A constant that represents a state marker type of change
     * for a <code>Query</code> object.
     * This constant is used when constructing a <code>StateChangedEvent</code>
     * after the state of a <code>Query</code> object has been reset to a
     * previous state by invoking the
     * <code>BaseManager.setQueryState</code> method.
     *
     * @status Documented
     */
    public static final int STATE   = 2;

    /**
     * A constant that represents a Metadata map change for a
     * <code>Query</code> object.
     *
     * @status Documented
     */
    public static final int METADATA_MAP = 3;
    
    /**
     * A constant that represents a Data map change for a
     * <code>Query</code> object.
     *
     * @status Documented
     */
    public static final int DATA_MAP = 4;
    
    /**
     * A constant that represents a Universe selection change for a
     * <code>Query</code> object.
     *
     * @status Documented
     */
    public static final int UNIVERSE = 5;
    
    /**
     * Constructs the event for a specific operation.
     * 
     * @param source The source of the event, that is, a reference to the
     *               object that fired the event.
     * @param op     An <code>Operation</code> object.
     * @param t      A constant (<code>STATE</code>) that represents the type of state
     *               change for the <code>Query</code> object.
     *
     * @see #STATE
     *
     * @status Documented
     */
    public StateChangeEvent(Object source, Operation op, int t) {
        super(source);
        
        operation = op;
        type = t;
    }    
    
    /**
     * Constructs the event with maps for a change in one or more dimensions.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of the dimension of the map that is involved;
     *               <code>null</code> means all dimensions.
     * @param m      The <code>Map</code> object that is involved.
     * @param t      A constant (<code>DATA_MAP</code>, or
     *               <code>METADATA_MAP</code>) that indicates the type of map
     *                state change to the <code>Query</code> object.
     *
     * @see #DATA_MAP
     * @see #METADATA_MAP
     *
     * @status Documented
     */
    public StateChangeEvent(Object source, String d, AbstractMap m, int t) {
        super(source);
        
        dimension = d;
        map = m;        
        type = t;
    }

    /**
     * Constructs the event with maps for a change on a specific edge of the
     * query.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param e      A constant (such as <code>DataDirector.ROW_EDGE</code>)
     *               that represents the edge for which the map has changed.
     * @param m      The <code>Map</code> object that is involved.
     * @param t      A constant (<code>DATA_MAP</code>, or
     *               <code>METADATA_MAP</code>) that indicates the type of map
     *               state change to the <code>Query</code> object.
     *
     * @see #DATA_MAP
     * @see #METADATA_MAP
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public StateChangeEvent(Object source, int e, AbstractMap m, int t) {
        this(source, null, m, t);
        edge = e;
    }

    /**
     * Constructs the event with a selection
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of the dimension of the universe selection
     *               that is involved in the query change.
     * @param s      The <code>Selection</code> object that will be used after
     *               the change.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public StateChangeEvent(Object source, String d, Selection s) {
        super(source);
        
        dimension = d;
        type = UNIVERSE;
        selection = s;        
    }*/
    
    /**
     * Retrieves the <code>Operation</code> object that will be undone or
     * redone.
     *
     * @return The <code>Operation</code> object that will be undone or redone.
     *
     * @status Documented
     */
    public Operation getOperation() {
        return operation;
    }
    
    /**
     * Retrieves the type of state change: undo, redo, or state change
     *
     * @return A constant (<code>STATE</code>) that represents the type of state change.
     *
     * @see #STATE
     *
     * @status Documented
     */
    public int getType() {
        return type;
    }
    
    /**
     * @hidden
     * @serial operation changing state to
     */
    protected Operation operation = null;

    /**
     * @hidden
     * @serial selection for universe change
     */
     // blm - Selection code moved to dvt-olap
/*    protected Selection selection = null;*/
    
    /**
     * @hidden
     * @serial type of state change
     */
    protected int type  = -1;

    /**
     * @hidden
     * @serial dimension involved if map
     */
    protected String    dimension   = null;
    
    /**
     * @hidden
     * @serial map instead of operation
     */
    protected AbstractMap map   = null;
    
    /**
     * @hidden
     * @serial edge edge for which change has been made, -1 if not edge specific
     */
    protected int   edge = -1;
}
