/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.CompoundName;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.NameParser;
import javax.naming.LinkRef;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import oracle.dss.bicontext.ImpactReport;
//import oracle.jbo.ComponentObject;
import oracle.dss.bicontext.Acl;
import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BINameClassPair;
import oracle.dss.bicontext.BIBinding;
import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.Privilege;
import oracle.dss.bicontext.BIComparator;
import oracle.dss.bicontext.BISortUtils;

import oracle.dss.bicontext.BIAttributeModificationException;
import oracle.dss.bicontext.BICircularReferenceException;
import oracle.dss.bicontext.BIInvalidAttributesException;
import oracle.dss.bicontext.BIInvalidNameException;
import oracle.dss.bicontext.BIInvalidSearchControlsException;
import oracle.dss.bicontext.BINameAlreadyBoundException;
import oracle.dss.bicontext.BINameNotFoundException;
import oracle.dss.bicontext.BINamingException;
import oracle.dss.bicontext.BINotContextException;
import oracle.dss.bicontext.BINoPermissionException;
import oracle.dss.bicontext.BIOperationNotSupportedException;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.MDAggregateInfo;
import oracle.dss.metadataUtil.MDPersistable;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * The directory service class for the MetadataManager.
 * An <code>MDFolder</code> represents a folder in the hierarchy of
 * metadata objects.
 * <P>
 * An <code>MDFolder</code> is a <code>DirContext</code> in the
 * Java Naming and Directory Interface (JNDI).
 *
 * @see javax.naming.directory.DirContext
 *
 * @status reviewed
 */
public class MDFolder extends MDObject implements BIContext
{
    private static final String NAMEPARSER = "np";
    private transient NameParser m_parser;
    private transient ErrorHandler m_handler;
    private transient Acl m_acl;
    private boolean m_closed;
    private Hashtable m_env;

    /**
     * @hidden
     * Constructor that does not specify environment properties or an error
     * handler.
     *
     * @status documented
     */
    public MDFolder()
    {
        m_env = new Hashtable(10, 10);
        setObjectType(MM.FOLDER);
        setClassName("oracle.dss.metadataManager.common.MDFolder");
        m_parser = new NameParserImpl();
        m_env.put(NAMEPARSER, m_parser);
    }

    /**
     * @hidden
     * Constructor that specifies environment properties and an error handler.
     * Environment properties are defined in the <code>Context</code>
     * interface in JNDI.
     *
     * @param env  Environment properties for this folder.
     * @param handler  The error handler for this folder.
     *
     * @status documented
     */
    public MDFolder(Hashtable env, ErrorHandler handler)
    {
        m_env = env;
        setObjectType(MM.FOLDER);
        setClassName("oracle.dss.metadataManager.common.MDFolder");
        if (handler != null)
            m_handler = handler;

        m_parser = (NameParser)m_env.get(NAMEPARSER);
        if (m_parser == null)
        {
            m_parser = new NameParserImpl();
            m_env.put(NAMEPARSER, m_parser);
        }
    }

    /**
     * @hidden
     * Constructor that specifies the MetadataManager, a name, a parent,
     * and environment variables for this folder.
     *
     * @param mmServices   The <code>MetadataManagerServices</code> that this
     *                     folder exists in.
     * @param folderName     A name for this folder.
     * @param parent       The parent of this folder.
     * @param env          Environment properties.
     * @param handler      The error handler for this folder.
     *
     * @status documented
     */
    public MDFolder(MetadataManagerServices mmServices, String folderName, MDObject parent, Hashtable env, ErrorHandler handler)
    {
        super( mmServices, folderName, parent );
        setObjectType(MM.FOLDER);
        setClassName("oracle.dss.metadataManager.common.MDFolder");
        m_env = env;
        if (handler != null)
            m_handler = handler;

        m_parser = (NameParser)m_env.get(NAMEPARSER);
        if (m_parser == null)
        {
            m_parser = new NameParserImpl();
            m_env.put(NAMEPARSER, m_parser);
        }
    }

    /**
     * Retrieves the error handler for this folder.
     *
     * @return The error handler for this folder.
     *
     * @status reviewed
     */
    public ErrorHandler getErrorHandler()
    {
        if (m_handler == null)
        {
            MetadataManagerServices mms = getMetadataManagerServices();
            ErrorHandler eh = null;
            if(mms != null)
                eh = mms.getErrorHandler();

            if(eh != null)
                return eh;
            else
                return new DefaultErrorHandler();
        }
        else
            return m_handler;
    }

    /**
     * Loads a <code>Persistable</code> object or folder from the MetadataManager.
     * If you are retrieving an object, then this method instantiates a new
     * <code>Persistable</code> object.
     * To reuse an existing <code>Persistable</code>, call one of the
     * <code>lookup</code> methods that takes a <code>Persistable</code>
     * as a parameter.
     *
     * @param name  The name of the object to load.
     *              Do not pass <code>null</code>.
     *
     * @return      The requested object or folder. The object implements
     *              the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException if any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(String)
     * @see #lookup(Name, Persistable)
     * @see #lookup(Name, Persistable, Hashtable)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status documented
     */
    public Object lookup(Name name) throws NamingException
    {
        return lookup(name, (Hashtable)null);
    }


    /**
     * Loads a <code>Persistable</code> object or folder from the MetadataManager.
     *
     * @param name  The name of the object to load.
     *              Do not pass <code>null</code>.
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @return      The requested object or folder. The object implements
     *              the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException if any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(String, Hashtable)
     * @see oracle.dss.metadataManager.common.MDObject
     * @see oracle.dss.dataSource.common.Query
     * @see oracle.dss.dataSource.client.QueryManager
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(Name name, Hashtable referenceResolver) throws NamingException
    {
      return lookup(name, referenceResolver, true);
    }

    public Object lookup(Name name, Hashtable referenceResolver, boolean resolveLink) throws NamingException
    {
        return lookup(name, null, referenceResolver, resolveLink);
    }

    /**
     * Applies XML from a <code>Persistable</code> object from the MetadataManager
     * to an existing <code>Persistable</code> object.
     *
     * @param name  The name of the object whose XML to read.
     *              Do not pass <code>null</code>.
     * @param obj   The <code>Persistable</code> object into which to read
     *              the XML from <code>name</code>.
     *              It must be the same object type as <code>name</code>.
     * @return      The requested object or folder. The object is the same
     *              object that you passed in <code>obj</code>, with the
     *              saved XML applied to it.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException if any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(String, Persistable)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(Name name, Persistable obj) throws NamingException
    {
        return lookup(name, obj, null);
    }

    /**
     * Applies XML from a <code>Persistable</code> object 
     * to an existing <code>Persistable</code> object.
     *
     * @param name  The name of the object whose XML to read.
     *              Do not pass <code>null</code>.
     * @param _pObj   The <code>Persistable</code> object into which to read
     *              the XML from <code>name</code>.
     *              It must be the same object type as <code>name</code>.
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @return      The requested object or folder. The object is the same
     *              object that you passed in <code>obj</code>, with the
     *              saved XML applied to it.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object
     *
     * @see #lookup(String, Persistable, Hashtable)
     * @see oracle.dss.util.persistence.Persistable
     * @see oracle.dss.dataSource.common.Query
     * @see oracle.dss.dataSource.client.QueryManager
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(Name name, Persistable _pObj, Hashtable referenceResolver) throws NamingException
    {
      return lookup(name, _pObj, referenceResolver, true);
    }

    /**
     * The actual lookup implementation, served both the lookup and the lookupLink method
     * depending on the value of resolveLink
     * to an existing <code>Persistable</code> object.
     *
     * @param name  The name of the object whose XML to read.
     *              Do not pass <code>null</code>.
     * @param _pObj   The <code>Persistable</code> object into which to read
     *              the XML from <code>name</code>.
     *              It must be the same object type as <code>name</code>.
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @param resolveLink, true when the Shortcuts need to be resolved to the underlying objects
     *             false when a linkRef should be returned when it is a shortcut. All
     *             other object types behave the same.
     *
     * @return      The requested object or folder. The object is the same
     *              object that you passed in <code>obj</code>, with the
     *              saved XML applied to it.
     *
     * @status hidden
     *
     */
    private Object lookup(Name name, Persistable persistable, Hashtable referenceResolver, boolean resolveLink) throws NamingException
    {
        long _start = System.currentTimeMillis();

        // first check whether name is empty or null
        checkNullName(name);

        // if the name is empty, return a clone of this MDFolder
        // see JNDI spec for detail
        if (name.size() == 0)
            return this;
            
        Persistable _persistableObj = null;
        try
        {
            Attributes _attrs = new BasicAttributes();
            _attrs.put(MDU.LOOKUP_OPTION, resolveLink?MDU.LOOKUP:MDU.LOOKUP_LINK);

            Object _obj = getMetadataManagerServices().lookup(this, name, persistable, referenceResolver, _attrs);            
            getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "lookup");

            return _obj;
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{name.toString()}, getLocale(), nnbe);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), uoe);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

/*
        MDObject _mdObj = lookupMDObject(name);

        // if _obj is a folder, there is no userObject there.
        if (_mdObj instanceof MDFolder)
            return _mdObj;

        Persistable _persistableObj = null;
        if (_mdObj instanceof MDObject)
        {
            try
            {
                // If called from lookup (resolvelink == true then set the LOOKUP property
                // else set the LOOKUPLINK property. This will be picked by the server part
                _mdObj.setStrPropertyValue(MDU.LOOKUP_OPTION, (resolveLink?MDU.LOOKUP:MDU.LOOKUP_LINK));

                // Load the user object
                if (MDU.MDM.equals(_mdObj.getDriverType()))
                    return null;
                UserObject _usrObj = getMetadataManagerServices().getUserObject(_mdObj, persistable, MM.PERSISTENCE_OBJECT, _mdObj.getDriverType(), referenceResolver);

                if (_usrObj != null && _usrObj.getObject() instanceof LinkRef)
                {
                    getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "lookup");
                    return _usrObj.getObject();
                }
                
                _persistableObj = (Persistable)_usrObj.getObject();
            }
            catch (NameNotBoundException nnbe)
            {
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new Object[]{name.toString()}, getLocale(), nnbe);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), uoe);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new Object[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            finally
            {
                // Anyway remove the property.
                _mdObj.removeProperty(MDU.LOOKUP_OPTION);

            }
        }
        else
            return null;

        if (_persistableObj instanceof MDPersistable)
        {
            // retrieve COMPSUBTYPE3 "id1:pos1,id2:pos2,..."
            // where id is and OLAPI runtime ID and pos is the position
            PersistableAttributes _pa = new PersistableAttributes();
            String _props = _persistableObj.getPersistableAttributes(_pa).getCompSubType3();
            if (_props == null)
                throw new BINamingException("No COMPSUBTYP3 parameter retrieved in " + this.getClass() + " in public Object lookup(Name name)");
            if ( !_props.startsWith("MDM!") )
                throw new BINamingException("Invalid COMPSUBTYPE3 property " + this.getClass() + " in public Object lookup(Name name)");
            StringTokenizer _tokenizer = new StringTokenizer(_props, ",");
            MDAggregateInfo[] _aggrs = new MDAggregateInfo[_tokenizer.countTokens() + 1];
            int i = 0; // counter for _aggrs
            while (_tokenizer.hasMoreTokens())
            {
                String _temp = _tokenizer.nextToken();
                int _sep = _temp.indexOf(':');

                if (_sep != -1)
                {
                    String _olapiID = _temp.substring(0, _sep);
                    int _pos = Integer.parseInt(_temp.substring(_sep+1, _temp.length()));
                    MDAggregateInfo _mdAggrInfo = new MDAggregateInfo(_olapiID, _pos);
                    _aggrs[i++] = _mdAggrInfo;
                }
            }
            ((MDPersistable)_persistableObj).setMDComponents(_aggrs);
        }
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "lookup");
        return _persistableObj;
*/
    }

    /**
     * Loads a <code>Persistable</code> object or folder from the MetadataManager.
     * If you are looking up an object, then this method instantiates a new
     * <code>Persistable</code> object.
     * To reuse an existing <code>Persistable</code>, call one of the
     * <code>lookup</code> methods that takes a <code>Persistable</code>
     * as a parameter.
     *
     * @param name  The name of the object to load.
     *              Do not pass <code>null</code>.
     *
     * @return      The requested object or folder. The object will implement
     *              the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(Name)
     * @see #lookup(String, Persistable)
     * @see #lookup(String, Persistable, Hashtable)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(String name) throws NamingException
    {
        return lookup(getNameParser().parse(name));
    }

    /**
     * Loads a <code>Persistable</code> object or folder from the MetadataManager.
     *
     * @param name  The name of the object to load.
     *              Do not pass <code>null</code>.
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @return      The requested object or folder. The object will implement
     *              the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(Name, Hashtable)
     * @see oracle.dss.dataSource.common.Query
     * @see oracle.dss.dataSource.client.QueryManager
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(String name, Hashtable referenceResolver) throws NamingException
    {
        return lookup(getNameParser().parse(name), referenceResolver);
    }

    /**
     * Applies XML from a <code>Persistable</code> object
     * to an existing <code>Persistable</code> object.
     *
     * @param name  The name of the object whose XML to read.
     *              Do not pass <code>null</code>.
     * @param obj   The <code>Persistable</code> object into which to read
     *              the XML from <code>name</code>.
     *              It must be the same object type as <code>name</code>.
     *
     * @return      The requested object. The object is the same
     *              object that you passed in <code>obj</code>, with the
     *              saved XML applied to it.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *                       
     * @see #lookup(Name, Persistable)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status needschange - the first line should say something about loading object
     *                       as in the case of other lookup methods except this one
     *                       applies the state to an existing object
     *         
     */
    public Object lookup(String name, Persistable obj) throws NamingException
    {
        return lookup(getNameParser().parse(name), obj);
    }

    /**
     * Applies XML from a <code>Persistable</code> object 
     * to an existing <code>Persistable</code> object.
     *
     * @param name  The name of the object to load.
     *              Do not pass <code>null</code>.
     * @param obj   The <code>Persistable</code> object into which to read
     *              the XML from <code>name</code>.
     *              It must be the same object type as <code>name</code>.
     * @param referenceResolver Any arguments that the object needs in order to be loaded.
     *             For example, if you are loading a <code>Query</code> object,
     *             pass a <code>QueryManager</code> in the <code>referenceResolver</code>
     *             hash table.
     *
     * @return      The requested object. The object is the same
     *              object that you passed in <code>obj</code>, with the
     *              saved XML applied to it.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     * @throws BINoPermissionException if user does not have permission to load
     *                       the object.
     *
     * @see #lookup(Name, Persistable, Hashtable)
     * @see oracle.dss.dataSource.common.Query
     * @see oracle.dss.dataSource.client.QueryManager
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status needschange - same as above
     */
    public Object lookup(String name, Persistable obj, Hashtable referenceResolver) throws NamingException
    {
        return lookup(getNameParser().parse(name), obj, referenceResolver);
    }


    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public void bind(Name name, Object object) throws NamingException
    {
        bind(name, object, null);
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.metadataManager.common.MDObject
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public void bind(String name, Object object) throws NamingException
    {
        bind(getNameParser().parse(name), object);
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINamingException  If <code>object</code>
     *               is a <code>PersistenceManagerImpl</code>.
     *               Call <code>createSubcontext</code> to create a folder.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws NamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #rebind(String, Object)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
     public void rebind(Name name, Object object) throws NamingException
     {
       rebind(name, object, null);
     }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINamingException  If <code>object</code>
     *               is a <code>PersistenceManagerImpl</code>.
     *               Call <code>createSubcontext</code> to create a folder.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws NamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #rebind(Name, Object)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
     public void rebind(String name, Object object) throws NamingException
     {
        rebind(getNameParser().parse(name), object);
     }

    /**
     * Removes a <code>Persistable</code> object from the MetadataManager.
     * This method removes the binding of the object.
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The name of the object to remove.
     * @throws   BINameNotFoundException   If the named object is not
     *              found in the MetadataManager.
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIOperationNotSupportedException If <code>name</code> identifies
     *               an OLAP object, such as a dimension.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #unbind(String)
     *
     * @status reviewed
     */
    public void unbind(Name name) throws NamingException
    {
        long _start = System.currentTimeMillis();

        try
        {
            getMetadataManagerServices().removeMDObject(this, name, false);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{name.toString()}, getLocale(), nnbe);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "unbind");
    }

    /**
     * Removes a <code>Persistable</code> from the MetadataManager.
     * This method removes the binding of the object.
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The name of the object to remove.
     * @throws   BINameNotFoundException   If the named object is not
     *              found in the MetadataManager.
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIOperationNotSupportedException If <code>name</code> identifies
     *               an OLAP object, such as a dimension.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #unbind(String)
     *
     * @status reviewed
     */
    public void unbind(String name) throws NamingException
    {
        unbind(getNameParser().parse(name));
    }

    /**
     * Renames a <code>Persistable</code> object or folder in the 
     * MetadataManager in this context.
     * The <code>oldName</code> and the <code>newName</code> arguments must
     * both specify the same context.
     * To move an object from one folder to another, use the <code>move</code>
     * method.
     * <P>
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param oldName  The current name of an existing object or folder.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     * @param newName  The new name to assign to this object or folder.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If <code>oldName</code> cannot be found
     *         in this context.
     * @throws BINameAlreadyBoundException If <code>newName</code> is already
     *         bound to an object.
     * @throws BINoPermissionException If the caller does not have permission
     *         to rename objects in this context.
     * @throws BINamingException If any other naming error occurs.
     *
     * @see #rename(String, String)
     *
     * @status Documented
     */
    public void rename(Name oldName, Name newName) throws NamingException
    {
    	// first check whether name is empty or null
        checkValidName(oldName);
        checkValidName(newName);

        long _start = System.currentTimeMillis();

        MDObject _obj = (MDObject)lookupMDObject(oldName);
        try
        {
            if (_obj != null)
                //getMetadataManagerServices().renameMDObject(_obj, newName);
                getMetadataManagerServices().renameMDObject(this, oldName, newName);
            else
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{oldName.toString()}, getLocale(), null);
        }
        catch (NameClashException nce)
        {
            throw new BINameAlreadyBoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new String[]{newName.toString()}, getLocale(), nce);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{oldName.toString()}, getLocale(), nnbe);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        getErrorHandler().trace("["+newName+"] "+(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "rename");
    }

    /**
     * Renames a <code>Persistable</code> object or folder in the 
     * MetadataManager in this context.
     * The <code>oldName</code> and the <code>newName</code> arguments must
     * both specify the same context.
     * To move an object from one folder to another, use the <code>move</code>
     * method.
     * <P>
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param oldName  The current name of an existing object or folder.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     * @param newName  The new name to assign to this object or folder.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If <code>oldName</code> cannot be found
     *         in this context.
     * @throws BINameAlreadyBoundException If <code>newName</code> is already
     *         bound to an object.
     * @throws BINoPermissionException If the caller does not have permission
     *         to rename objects in this context.
     * @throws BINamingException If any other naming error occurs.
     *
     * @see #rename(Name, Name)
     *
     * @status Documented
     */
    public void rename(String oldName, String newName) throws NamingException
    {
        rename(getNameParser().parse(oldName), getNameParser().parse(newName));
    }

    /**
     * Enumerates the names and class names of the objects in a folder.
     * This method returns an enumeration of names and class names of the
     * objects in a specified folder.
     * If you want access to the objects, call <code>listBindings</code>.
     *
     * @param name  The name of the folder whose contents you want.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @return      An enumeration of <code>NameClassPair</code>
     *              objects, one for each object in the folder.
     *              Each <code>NameClassPair</code> contains the name
     *              and the class name of an object.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #listBindings
     * @see #list(String)
     * @see javax.naming.NameClassPair
     *
     * @status reviewed
     */
    public NamingEnumeration list(Name name) throws NamingException
    {
        long _start = System.currentTimeMillis();

        checkNullName(name);

        try
        {
            // find the direct parent folder (for path name)
            /*
            MDObject _mdObj = lookupMDObject(name);
            if (!(_mdObj instanceof MDFolder))
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_mdObj.getName()}, getLocale(), null);

            MDFolder _folder = (MDFolder)_mdObj;
            */

            Vector _results = getMetadataManagerServices().search(this, name, null, new BISearchControls());

            Vector _ncPairs = null;
            if (_results != null)
            {
                _ncPairs = new Vector(_results.size());
                for (int i=0; i<_results.size(); i++)
                {
                    BISearchResult _sr = (BISearchResult)_results.elementAt(i);
                    _ncPairs.addElement(new BINameClassPair(_sr.getName(), _sr.getClassName(), _sr.getObjectType()));
                }
            }
            else
                _ncPairs = new Vector(0);

            getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "list");
            return new NamingEnumerationImpl(_ncPairs);
        }
        catch(MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }
    }

    /**
     * Enumerates the names and class names of the objects in a folder.
     * This method returns an enumeration of names and class names of the
     * objects in a specified folder.
     * If you want access to the objects, call <code>listBindings</code>.
     *
     * @param name  The name of the folder whose contents you want.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @return      An enumeration of <code>NameClassPair</code>
     *              objects, one for each object in the folder.
     *              Each <code>NameClassPair</code> contains the name
     *              and the class name of an object.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #listBindings
     * @see #list(Name)
     * @see javax.naming.NameClassPair
     *
     * @status reviewed
     */
    public NamingEnumeration list(String name) throws NamingException
    {
        return list(getNameParser().parse(name));
    }

    /**
     * Enumerates the objects in a folder, with their names and class names.
     * If you do not need access to the objects, call <code>list</code>.
     *
     * @param name  The name of the folder whose contents you want.
     *              Do not pass <code>null</code>.
     *              To specify the current folder, pass an empty <code>Name</code>.
     *
     * @return      An enumeration of <code>Binding</code>
     *              objects, one for each object in the folder.
     *              Each <code>Binding</code> contains the name of an object,
     *              its class name, and the object itself.
     *
     * @throws BIInvalidNameException if <code>name</code> is <code>null</code>.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #list
     * @see #listBindings(String)
     * @see javax.naming.Binding
     *
     * @status reviewed
     */
    public NamingEnumeration listBindings(Name name) throws NamingException
    {
        long _start = System.currentTimeMillis();

        checkNullName(name);

        // find the appropriate folder first
        //MDObject _folder = lookupMDObject(name);
        //if (!(_folder instanceof MDFolder))
        //    throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_folder.getName()}, getLocale(), null);

        Vector _results = null;
        try
        {
            //_results = _folder.getChildren();
            _results = getMetadataManagerServices().search(this, name, null, new BISearchControls());
        }
        catch(MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }

        Vector _bindings = null;
        if (_results == null)
            _bindings = new Vector(0);
        else
        {
            _bindings = new Vector(_results.size());
            for (int i=0; i<_results.size(); i++)
            {
                 BISearchResult _sr = (BISearchResult)_results.elementAt(i);
                _bindings.addElement(new MetadataManagerBindingImpl(_sr.getName(), _sr.getClassName(), _sr, _sr.getObjectType(), getMetadataManagerServices()));
            }
        }
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "listBindings");

        return new NamingEnumerationImpl(_bindings);
    }

    /**
     * Enumerates the objects in a folder, with their names and class names.
     * If you do not need access to the objects, call <code>list</code>.
     *
     * @param name  The name of the folder whose contents you want.
     *              Do not pass <code>null</code>.
     *              To specify the current folder, pass an empty <code>Name</code>.
     *
     * @return      An enumeration of <code>Binding</code>
     *              objects, one for each object in the folder.
     *              Each <code>Binding</code> contains the name of an object,
     *              its class name, and the object itself.
     *
     * @throws BIInvalidNameException if <code>name</code> is <code>null</code>.
     * @throws   BINamingException If any other naming error occurs.
     *
     * @see #list
     * @see #listBindings(Name)
     * @see javax.naming.Binding
     *
     * @status reviewed
     */
    public NamingEnumeration listBindings(String name) throws NamingException
    {
        return listBindings(getNameParser().parse(name));
    }

    /**
     * Removes a folder from the MetadataManager.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the folder to remove.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If the caller does not have the
     *               level of privilege necessary to remove the folder.
     *               You must have permission to all folders in the path.
     * @throws BINotContextException If <code>name</code> is not a context.
     *               To remove an object, call <code>unbind</code>.
     * @throws BINamingException  If any other naming error occurs.
     *
     * @see #destroySubcontext(String)
     *
     * @status reviewed
     */
    public void destroySubcontext(Name name) throws NamingException
    {
        checkValidName(name);

        long _start = System.currentTimeMillis();

        try
        {
            getMetadataManagerServices().removeMDObject(this, name, true);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{name.toString()}, getLocale(), nnbe);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "destroySubcontext");
    }

    /**
     * Removes a folder from the MetadataManager.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the folder to remove.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If the caller does not have the
     *               level of privilege necessary to remove the folder.
     *               You must have permission to all folders in the path.
     * @throws BINamingException  If any other naming error occurs.
     *
     * @see #destroySubcontext(Name)
     *
     * @status reviewed
     */
    public void destroySubcontext(String name) throws NamingException
    {
        destroySubcontext(getNameParser().parse(name));
    }

    /**
     * Creates an <code>MDFolder</code> that represents a folder.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name for the folder to create.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @return  The <code>MDFolder</code> for the new folder.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>.
     * @throws BINoPermissionException If the caller does not have permission to
     *               create folders in this context.
     * @throws BIOperationNotSupportedException If <code>name</code> identifies
     *               an OLAP object.
     * @throws NamingException If any other naming error occurs.
     *
     * @see #createSubcontext(String)
     *
     * @status reviewed
     */
    public Context createSubcontext(Name name) throws NamingException
    {
        return createSubcontext(name, null);
    }

    /**
     * Creates an <code>MDFolder</code> that represents a folder.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object.
     *
     * @param name  The name for the folder to create.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     *
     * @return  The <code>MDFolder</code> for the new folder.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>.
     * @throws BINoPermissionException If the caller does not have permission to
     *               create folders in this context.
     * @throws NamingException If any other naming error occurs.
     *
     * @see #createSubcontext(Name)
     *
     * @status Documented
     */
    public Context createSubcontext(String name) throws NamingException
    {
        return createSubcontext(getNameParser().parse(name));
    }

    /**
     * Loads a <code>Persistable</code> object or folder through the MetadataManager.
     * Currently, this method simply calls the <code>lookup</code> method.
     * <P>
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to load. The object must
     *              implement the <code>Persistable</code> interface.
     *              Do not pass <code>null</code>.
     *
     * @return      The requested object or folder.
     *
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     *
     * @see #lookupLink(String)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public Object lookupLink(Name name) throws NamingException
    {
        return lookup(name, null, false);
    }

    /**
     * Loads a <code>Persistable</code> object or folder from the MetadataManager.
     * Currently, this method simply calls the <code>lookup</code> method.
     * <P>
     * This method is useful only for <code>Persistable</code> objects.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to load. The object must
     *              be an instance of the <code>MDObject</code> class or any of its
     *              subclasses.
     *              Do not pass <code>null</code>.
     *
     * @return      The requested object or folder.
     *
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException If any other naming error occurs.
     *
     * @see #lookupLink(Name)
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public Object lookupLink(String name) throws NamingException
    {
        return lookupLink(getNameParser().parse(name));

    }

    private NameParser getNameParser()
    {
        if (m_parser == null)
        {
            m_parser = new NameParserImpl();
            m_env.put(NAMEPARSER, m_parser);
        }
        return m_parser;
    }

    /**
     * Retrieves the name parser for a folder.
     *
     * @param name  The name of the folder for which to get the parser.
     *              Currently, all folders uses the same name parser, so you
     *              can pass the name of any context.
     *
     * @return The name parser for the specified folder.
     *
     * @throws   NamingException     If a naming error occurs.
     *
     * @see #getNameParser(String)
     *
     * @status reviewed
     */
    public NameParser getNameParser(Name name) throws NamingException
    {
        return getNameParser();
    }

    /**
     * Retrieves the name parser for a folder.
     *
     * @param name  The name of the folder for which to get the parser.
     *              Currently, all folders uses the same name parser, so you
     *              can pass the name of any context.
     *
     * @return The name parser for the specified folder.
     *
     * @throws   NamingException     If a naming error occurs.
     *
     * @see #getNameParser(String)
     *
     * @status reviewed
     */
    public NameParser getNameParser(String name) throws NamingException
    {
        return getNameParser();
    }

    /**
     * Combines parts of a path name to a single <code>Name</code>.
     * Normally, you use this method to combine the name of an object
     * relative to this context with the name of this context, to create
     * a full path name.
     *
     * @param name      The name of an object in this context or one of its
     *                  subcontexts.
     * @param prefix    The name of this context, as it relates to one of its
     *                  ancestors. Do not pass <code>null</code>.
     *
     * @return The name that is composed from <code>prefix</code> and
     * <code>name</code>.
     *
     * @throws InvalidNameException If <code>name</code> is not a valid name,
     *         or if the resulting name is not valid.
     * @throws NamingException If any other naming error occurs.
     *
     * @see #composeName(String, String)
     *
     * @status reviewed
     */
    public Name composeName(Name name, Name prefix) throws NamingException
    {
        return prefix.addAll(name);
    }

    /**
     * Combines parts of a path name to a single <code>Name</code>.
     * Normally, you use this method to combine the name of an object
     * relative to this context with the name of this context, to create
     * a full path name.
     *
     * @param name      The name of an object in this context or one of its
     *                  subcontexts.
     * @param prefix    The name of this context, as it relates to one of its
     *                  ancestors. Do not pass <code>null</code>.
     *
     * @return The name that is composed from <code>prefix</code> and
     * <code>name</code>.
     *
     * @throws InvalidNameException If <code>name</code> is not a valid name,
     *         or if the resulting name is not valid.
     * @throws NamingException If any other naming error occurs.
     *
     * @see #composeName(Name, Name)
     *
     * @status reviewed
     */
    public String composeName(String name, String prefix) throws NamingException
    {
        return composeName(getNameParser().parse(name), getNameParser().parse(prefix)).toString();
    }

    /**
     * Adds a property to the current environment setting.
     * If the property already exists, then this method replaces the existing
     * property and returns the replaced property.
     *
     * @param propName  The name of the property to add. Do not pass
     *                  <code>null</code>.
     * @param propValue The value of the property to add. Do not pass
     *                  <code>null</code>.
     *
     * @return          The name of the replaced property, if one exists.
     *                  Otherwise, returns <code>null</code>.
     *
     * @throws NamingException     If a naming error occurs.
     *
     * @status reviewed
     */
    public Object addToEnvironment(String propName, Object propValue) throws NamingException
    {
        if (propName != null && propValue != null)
        {
            Object oldValue = m_env.get(propName);
            m_env.put(propName, propValue);
            return oldValue;
        }
        else
            return null;
    }

    /**
     * Removes a property from the environment setting.
     *
     * @param propName  The property to remove. Do not pass <code>null</code>.
     *
     * @return The value that was stored for the removed property, or
     *         <code>null</code>.
     *
     * @throws NamingException   If a naming error occurs.
     *
     * @status reviewed
     */
    public Object removeFromEnvironment(String propName) throws NamingException
    {
        if (propName != null)
            return m_env.remove(propName);
        else
            return null;
    }

    /**
     * Retrieves the environment for this context.
     * This method returns a copy of the environment <code>Hashtable</code>.
     * Changes you make to the returned <code>Hashtable</code> are not
     * reflected in the original environment.
     * To modify the environment, call <code>addToEnvironment</code> or
     * <code>removeFromEnvironment</code>.
     *
     * @return      A copy of the environment settings for this context.
     *
     * @exception   NamingException     If a naming error occurs.
     *
     * @see #addToEnvironment
     * @see #removeFromEnvironment
     *
     * @status reviewed
     */
    public Hashtable getEnvironment() throws NamingException
    {
        Hashtable _env = (Hashtable)m_env.clone();
        if (getMetadataManagerServices() != null)
        {
            Hashtable _mmEnv = getMetadataManagerServices().getEnvironment();
            if (_mmEnv != null)
            {
                Enumeration _enum = _mmEnv.keys();   
                while (_enum.hasMoreElements())
                {
                    Object _key = _enum.nextElement();
                    _env.put(_key, _mmEnv.get(_key));
                }
            }
        }
        return _env;
    }

    /**
     * Closes this context and releases all the resources that it held.
     *
     * @throws NamingException   If a naming error occurs.
     *
     * @status reviewed
     */
    public void close() throws NamingException
    {
        m_closed = true;
        free();
    }

    /**
     * Retrieves all of the predefined (that is, fixed) persistence attributes 
     * for an object, and for an OLAP object, all OLAP-specific properties of 
     * the object.
     *
     * @param name The name of the object that you want attributes for.
     *             Do not pass <code>null</code>.
     *
     * @return The predefined attributes for <code>name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is the root
     *              folder.
     * @throws NamingException  If any other naming error occurs.
     *
     * @see #getAttributes(String)
     *
     * @status reviewed
     */
    public Attributes getAttributes(Name name) throws NamingException
    {
        return getAttributes(name, null);
    }

    /**
     * Retrieves all of the predefined (that is, fixed) persistence attributes 
     * for an object, and for an OLAP object, all OLAP-specific properties of 
     * the object.
     *
     * @param name The name of the object that you want attributes for.
     *             Do not pass <code>null</code>.
     *
     * @return The predefined attributes for <code>name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is the root
     *              folder.
     * @throws NamingException  If any other naming error occurs.
     *
     * @see #getAttributes(Name)
     *
     * @status reviewed
     */
    public Attributes getAttributes(String name) throws NamingException
    {
        return getAttributes(getNameParser().parse(name));
    }

    /**
     * Retrieves the specified persistence attributes for an object.
     * For an OLAP object, this method also retrieves specified OLAP-specific
     * properties.
     *
     * @param name The name of the object that you want attributes for.
     *             Do not pass <code>null</code>.
     * @param attrIds  The attributes that you want to retrieve.
     *        To indicate individual predefined attributes, use constants  
     *        from <code>oracle.dss.persistence.PSRConstants.Attributes</code>
     *        such as OBJECT_NAME and OBJECT_TYPE. 
     *        To indicate groups of extensible attributes, use constants from
     *        <code>oracle.dss.persistence.PSRConstants.ExtensibleAttributes</code>
     *        such as COMPONENT for all the extensible component attributes or 
     *        CURRENT_APPLICATION for all the extensible application attributes
     *        that are in the scope of the current application.
     *        To indicate specific extensible attributes, append the specific 
     *        identification after the extensible group constant. For example,
     *        for an extensible application attribute named "Author" in the 
     *        scope of the current application, code the attrIds parameter as
     *        follows:
     *        <pre>
     *        PSRConstants.ExtensibleAttributes.CURRENT_APPLICATION + "/Author"
     *        </pre>
     *
     * @return The requested attributes for <code>name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BINamingException             If any other naming error occurs.
     *
     * @see #getAttributes(String, String[])
     * @see oracle.dss.persistence.PSRConstants.Attributes
     * @see oracle.dss.persistence.PSRConstants.ExtensibleAttributes
     *
     * @status reviewed
     */
    public Attributes getAttributes(Name name, String[] attrIds) throws NamingException
    {
        long _start = System.currentTimeMillis();

        try
        {
            Attributes _attrs = getMetadataManagerServices().getAttributes(this, name, attrIds, -1);
            getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "getAttributes");
            return _attrs;
        }
        catch (NameNotBoundException nne)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{(name.size()>0)? name.get(name.size()-1) : ""}, getLocale(), nne);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
    }

    /**
     * Retrieves the specified persistence attributes for an object.
     * For an OLAP object, this method also retrieves specified OLAP-specific
     * properties.
     *
     * @param name The name of the object that you want attributes for.
     *             Do not pass <code>null</code>.
     * @param attrIds  The attributes that you want to retrieve.
     *        To indicate individual predefined attributes, use constants  
     *        from <code>oracle.dss.persistence.PSRConstants.Attributes</code>
     *        such as OBJECT_NAME and OBJECT_TYPE. 
     *        To indicate groups of extensible attributes, use constants from
     *        <code>oracle.dss.persistence.PSRConstants.ExtensibleAttributes</code>
     *        such as COMPONENT for all the extensible component attributes or 
     *        CURRENT_APPLICATION for all the extensible application attributes
     *        that are in the scope of the current application.
     *        To indicate specific extensible attributes, append the specific 
     *        identification after the extensible group constant. For example,
     *        for an extensible application attribute named "Author" in the 
     *        scope of the current application, code the attrIds parameter as
     *        follows:
     *        <pre>
     *        PSRConstants.ExtensibleAttributes.CURRENT_APPLICATION + "/Author"
     *        </pre>
     *
     * @return The requested attributes for <code>name</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BINamingException             If any other naming error occurs.
     *
     * @see #getAttributes(Name, String[])
     * @see oracle.dss.persistence.PSRConstants.Attributes
     * @see oracle.dss.persistence.PSRConstants.ExtensibleAttributes

     * @status reviewed
     */
    public Attributes getAttributes(String name, String[] attrIds) throws NamingException
    {
        return getAttributes(getNameParser().parse(name), attrIds);
    }

    /**
     * Modifies persistence attributes for an object.
     * Use this method when you want to use the same modification operation
     * on multiple attributes.
     *
     * @param name The name of the object whose attributes you want to set.
     *             Do not pass <code>null</code>.
     * @param mod_op  A constant that identifies the modification that
     *             you want to make. For predefined attributes, this 
     *             implementation supports only
     *             <code>javax.naming.directory.DirContext.REPLACE_ATTRIBUTE</code>.
     *             For extensible attributes, you can use any of the following
     *             constants from DirContext: ADD_ATTRIBUTE, 
     *             REPLACE_ATTRIBUTE, or REMOVE_ATTRIBUTE.
     * @param attrs A list of attributes that you want to modify.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BIAttributeModificationException  If the modification fails.
     * @throws BINamingException                 If any other naming error occurs.
     *
     * @see #modifyAttributes(String, int, Attributes)
     *
     * @status reviewed
     */
    public void modifyAttributes(Name name, int mod_op, Attributes attrs) throws NamingException
    {
        ModificationItem[] _mods = new ModificationItem[attrs.size()];

        int i     = 0;
        Attribute _attr;

        for (NamingEnumeration en = attrs.getAll(); en.hasMore();)
            _mods[i++] = new ModificationItem(mod_op, (Attribute)en.next());

        modifyAttributes(name, _mods);
    }

    /**
     * Modifies persistence attributes for an object.
     * Use this method when you want to use the same modification operation
     * on multiple attributes.
     *
     * @param name The name of the object whose attributes you want to set.
     *             Do not pass <code>null</code>.
     * @param mod_op  A constant that identifies the modification that
     *             you want to make. For predefined attributes, this 
     *             implementation supports only
     *             <code>javax.naming.directory.DirContext.REPLACE_ATTRIBUTE</code>.
     *             For extensible attributes, you can use any of the following
     *             constants from DirContext: ADD_ATTRIBUTE, 
     *             REPLACE_ATTRIBUTE, or REMOVE_ATTRIBUTE.
     * @param attrs A list of attributes that you want to modify.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BIAttributeModificationException  If the modification fails.
     * @throws BINamingException             If any other naming error occurs.
     *
     * @see #modifyAttributes(Name, int, Attributes)
     *
     * @status reviewed
     */
    public void modifyAttributes(String name, int mod_op, Attributes attrs) throws NamingException
    {
        modifyAttributes(getNameParser().parse(name), mod_op, attrs);
    }

    /**
     * Modifies persistence attributes for an object.
     *
     * @param name The name of the object whose attributes you want to set.
     *             Do not pass <code>null</code>.
     * @param mods An array of modifications that you want to make.
     *             Each <code>ModificationItem</code> identifies the modification
     *             that you want and the attribute that you want to change.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BIAttributeModificationException  If the modification fails.
     * @throws NamingException                 If any other naming error occurs.
     *
     * @see #modifyAttributes(String, ModificationItem[])
     *
     * @status reviewed
     */
    public void modifyAttributes(Name name, ModificationItem[] mods) throws NamingException
    {
        long _start = System.currentTimeMillis();
        MDObject _obj = (MDObject)lookupMDObject(name);

        try
        {
            //getMetadataManagerServices().modifyMDObject(_obj, mods);
            getMetadataManagerServices().modifyMDObject(this, name, mods);
        }
        catch (InvalidPropertyException ipe)
        {
            throw new BIAttributeModificationException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_ATTR_MOD, null, getLocale(), ipe);
        }
        catch (NameClashException nce)
        {
            throw new BIAttributeModificationException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_ATTR_MOD, null, getLocale(), nce);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BIAttributeModificationException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_ATTR_MOD, null, getLocale(), nnbe);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "modifyAttributes");
    }

    /**
     * Modifies persistence attributes for an object.
     *
     * @param name The name of the object whose attributes you want to set.
     *             Do not pass <code>null</code>.
     * @param mods An array of modifications that you want to make.
     *             Each <code>ModificationItem</code> identifies the modification
     *             that you want and the attribute that you want to change.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINoPermissionException If <code>name</code> is in the root
     *              folder.
     * @throws BIAttributeModificationException  If the modification fails.
     * @throws NamingException                 If any other naming error occurs.
     *
     * @see #modifyAttributes(Name, ModificationItem[])
     * @see javax.naming.directory.ModificationItem
     *
     * @status reviewed
     */
    public void modifyAttributes(String name, ModificationItem[] mods) throws NamingException
    {
        modifyAttributes(getNameParser().parse(name), mods);
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public void bind(Name name, Object object, Attributes attrs) throws NamingException
    {
        bind(name, object, attrs, null);
    }

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable 
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status new
     */
    public void bind(Name name, Object object, Attributes attrs, Hashtable env) throws NamingException
    {
        long _start = System.currentTimeMillis();
        bindCommon(name, object, attrs, false, env);
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "bind");
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public void bind(String name, Object object, Attributes attrs) throws NamingException
    {
        bind(name, object, attrs, null);
    }

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable 
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status reviewed
     */
    public void bind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException
    {
        bind(getNameParser().parse(name), object, attrs, env);
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public void rebind(Name name, Object object, Attributes attrs) throws NamingException
    {
        rebind(name, object, attrs, null);
    }

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable 
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public void rebind(Name name, Object object, Attributes attrs, Hashtable env) throws NamingException
    {
        long _start = System.currentTimeMillis();
        bindCommon(name, object, attrs, true, env);
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "rebind");
    }

    /**
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs Attributes for <code>object</code>.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public void rebind(String name, Object object, Attributes attrs) throws NamingException
    {
        rebind(name, object, attrs, null);
    }

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable 
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public void rebind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException
    {
        rebind(getNameParser().parse(name), object, attrs, env);
    }

    /**
     * Creates an <code>MDFolder</code> that represents a folder.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name for the folder to create.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     * @param attrs The attributes for the folder.
     *
     * @return  The <code>MDFolder</code> for the new folder.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>.
     * @throws BINoPermissionException If the caller does not have permission to
     *               create folders in this context.
     * @throws NamingException If another naming error occurs.
     *
     * @see #createSubcontext(String, Attributes)
     *
     * @status reviewed
     */
    public DirContext createSubcontext(Name name, Attributes attrs) throws NamingException
    {
        long _start = System.currentTimeMillis();

        // first check whether name is empty or null
        checkValidName(name);

        Name _folderName = (Name)name.clone();
        String _objName = (_folderName.remove(name.size()-1)).toString();

        MDFolder _folder = lookupMDFolder(_folderName);
        if (_folder == null)
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_folder.getName()}, getLocale(), null);

        MDObject _newFolder = null;
        String _path = MMUtilities.composePath(_folder, _objName);
        try
        {
            _newFolder = getMetadataManagerServices().getMDObjectByPath(_path);
        }
        catch (MetadataManagerException mme)
        {
            // ignore;
        }

        if (_newFolder == null || !(_newFolder instanceof MDFolder))
        {
            _newFolder = new MDFolder(getMetadataManagerServices(), _objName, _folder, (Hashtable)m_env.clone(), getErrorHandler());
            if(_folder != null)
                _newFolder.setDriverType(_folder.getDriverType());
            else
                _newFolder.setDriverType(MDU.PERSISTENCE);
        }
        else {
          if(_folder != null)
              _newFolder.setDriverType(_folder.getDriverType());
          else
              _newFolder.setDriverType(MDU.PERSISTENCE);
        }

        _newFolder.setParent(_folder);
        _newFolder.setStrPropertyValue(MM.RELATION, MM.FOLDER);

        try
        {
            _newFolder = getMetadataManagerServices().setMDObject(_newFolder, attrs);
            _newFolder.setParent(_folder);
        }
        catch (NameClashException nce)
        {
            throw new BINameAlreadyBoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new String[]{_objName}, getLocale(), nce);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (InvalidPropertyException ipe2)
        {
            throw new BIInvalidAttributesException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_ATTRS, null, getLocale(), ipe2);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "createSubcontext");

        return (MDFolder)_newFolder;
    }

    /**
     * Creates an <code>MDFolder</code> that represents a folder.
     * This method is useful only when the <code>MDFolder</code> is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name for the folder to create.
     *              Do not pass <code>null</code> or an empty <code>Name</code>.
     * @param attrs The attributes for the folder.
     *
     * @return  The <code>MDFolder</code> for the new folder.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>.
     * @throws BINoPermissionException If the caller does not have permission to
     *               create folders in this context.
     * @throws NamingException If another naming error occurs.
     *
     * @see #createSubcontext(Name, Attributes)
     *
     * @status reviewed
     */
    public DirContext createSubcontext(String name, Attributes attrs) throws NamingException
    {
        return createSubcontext(getNameParser().parse(name), attrs);
    }

    /**
     * Searches a folder for objects that have specified attributes.
     * This method retrieves specified attributes of the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     * @param  attributesToReturn The attributes that you want this search
     *                      to retrieve for objects that have
     *                      <code>matchingAttributes</code>.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in
     *         <code>attributesToReturn</code>, and the name of the object,
     *         relative to <code>name</code>.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see javax.naming.directory.DirContext#search(Name, Attributes, String[])
     *
     * @status reviewed
     */
    public NamingEnumeration search(Name name, Attributes matchingAttributes, String[] attributesToReturn) throws NamingException
    {
        long _start = System.currentTimeMillis();

        BISearchControls _controls = new BISearchControls();
        _controls.setSearchScope(BISearchControls.ONELEVEL_SCOPE);
        _controls.setReturningAttributes(attributesToReturn);

        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "search");

        return search(name, matchingAttributes, _controls);
    }

    /**
     * Searches a folder for objects that have specified attributes.
     * This method retrieves specified attributes of the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     * @param  attributesToReturn The attributes that you want this search
     *                      to retrieve for objects that have
     *                      <code>matchingAttributes</code>.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in
     *         <code>attributesToReturn</code>, and the name of the object,
     *         relative to <code>name</code>.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see javax.naming.directory.DirContext#search(String, Attributes, String[])
     *
     * @status reviewed
     */
    public NamingEnumeration search(String name, Attributes matchingAttributes, String[] attributesToReturn) throws NamingException
    {
        return search(getNameParser().parse(name), matchingAttributes, attributesToReturn);
    }

    /**
     * Searches a folder for objects that have specified attributes.
     * This method retrieves the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The
     *         objects match the search criteria.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see javax.naming.directory.DirContext#search(Name, Attributes)
     *
     * @status reviewed
     */
    public NamingEnumeration search(Name name, Attributes matchingAttributes) throws NamingException
    {
        return search(name, matchingAttributes, (String[])null);
    }

    /**
     * Searches a folder for objects that have specified attributes.
     * This method retrieves the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The
     *         objects match the search criteria.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see javax.naming.directory.DirContext#search(String, Attributes)
     *
     * @status reviewed
     */
    public NamingEnumeration search(String name, Attributes matchingAttributes) throws NamingException
    {
        return search(getNameParser().parse(name), matchingAttributes, (String[])null);
    }

    /**
     * Searches a folder for objects that have specified attributes, using the
     * specified search scope.
     * This method retrieves specified attributes of the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in
     *         <code>attributesToReturn</code>, and the name of the object,
     *         relative to <code>name</code>.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BIInvalidSearchControlsException If <code>SearchControls</code> is not valid
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see #search(String, Attributes, SearchControls)
     *
     * @status reviewed
     */
    public NamingEnumeration search(Name name, Attributes matchingAttributes, SearchControls controls) throws NamingException
    {
        long _start = System.currentTimeMillis();
        int _scope = controls.getSearchScope();

        // this should be remove since SearchControl supports sorting
        boolean _sorted = false;
        if (matchingAttributes != null && matchingAttributes.get(MM.SORT) != null)
        {
            _sorted = ((Boolean)matchingAttributes.get(MM.SORT).get()).booleanValue();
            matchingAttributes.remove(MM.SORT);
        }

        BIFilter _filter = ((BISearchControls)controls).getResultFilter();

        Vector _results = null;
        String _name = null;
        try
        {
            String[] _retAttrs = controls.getReturningAttributes();

            // This is the actual search.  Checks if multiple search roots is specified
            if (controls instanceof MDSearchControls && ((MDSearchControls)controls).getSearchPaths() != null)
            {
                // find the direct parent folder (for path name)
                MDObject _mdObj = lookupMDObject(name);
                if (!(_mdObj instanceof MDFolder))
                    throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_mdObj.getName()}, getLocale(), null);
    
                MDFolder _folder = (MDFolder)_mdObj;
    
                // get the name for exception use
                _name = _folder.getName();

                MDSearchControls _mdCon = (MDSearchControls)controls;
                String[] _searchPaths = _mdCon.getSearchPaths();
                String[] _searchPathNames = _mdCon.getSearchPathNames();

                // clear the search paths so that subsequent search won't pick it up
                _mdCon.clear();

                if (_searchPathNames == null || _searchPathNames.length == 0)
                {
                    // this is the normal case
                    _results = searchFolders(_folder, _searchPaths, matchingAttributes, (MDSearchControls)controls);
                }
                else
                {
                    // the length must match!
                    if (_searchPathNames.length != _searchPaths.length)
                        throw new BIInvalidSearchControlsException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_SEARCH_CONTROL, null, getLocale(), null);

                    if (validateSearchPaths(_searchPaths))
                        getErrorHandler().log(getClass().getName(), "search", "Warning: duplicate results might appear as one of the search path is the parent of another search path");

                    // find duplicate paths and merge them
                    Hashtable _entries = new Hashtable(_searchPathNames.length);
                    for (int i=0; i<_searchPathNames.length; i++)
                    {
                        if (_searchPathNames[i] != null)
                        {
                            Object _obj = _entries.get(_searchPathNames[i]);
                            if (_obj == null)
                                _entries.put(_searchPathNames[i], _searchPaths[i]);
                            else if (_obj instanceof Vector)
                                ((Vector)_obj).addElement(_searchPaths[i]);
                            else if (_obj instanceof String)
                            {
                                Vector _paths = new Vector(5, 5);
                                _paths.addElement(_obj);
                                _paths.addElement(_searchPaths[i]);
                                _entries.put(_searchPathNames[i], _paths);
                            }
                        }
                    }

                    Vector _msrs = new Vector(50, 50);
                    Enumeration _names = _entries.keys();
                    while (_names.hasMoreElements())
                    {
                        String _objName = (String)_names.nextElement();
                        Object _obj = _entries.get(_objName);
                        // there should be exactly only one entry for the root path
                        if (_objName.equals(""))
                        {
                            if (_obj instanceof String)
                                _results = searchFolders(_folder, new String[]{(String)_obj}, matchingAttributes, (MDSearchControls)controls);
                            else if (_obj instanceof Vector)
                            {
                                Vector _v = (Vector)_obj;
                                String[] _paths = new String[_v.size()];
                                _v.copyInto(_paths);

                                _results = searchFolders(_folder, _paths, matchingAttributes, (MDSearchControls)controls);
                            }
                        }
                        else
                        {
                            // can't add result directly to _results as it would
                            // be wiped out by the root search (above)
                            if (_obj instanceof String)
                            {
                                try
                                {
                                    MDFolder _folderResult = (MDFolder)_folder.lookup((String)_obj);

                                    // don't check folders is empty if the scope is one level scope
                                    // with folders
                                    Enumeration _enum = null;
                                    if (controls.getSearchScope() != BISearchControls.ONELEVEL_SCOPE_WITH_FOLDERS)
                                        _enum = _folderResult.search("", matchingAttributes, controls);

                                    if(controls.getSearchScope() == BISearchControls.SUBTREE_SCOPE)
                                    {
                                        while(_enum.hasMoreElements())
                                        {
                                            MetadataManagerSearchResultImpl _impl = (MetadataManagerSearchResultImpl)_enum.nextElement();
                                            _impl.setName(_objName + '/' + _impl.getName());
                                            _msrs.addElement(_impl);
                                        }
                                    }
                                    else if (controls.getSearchScope() == BISearchControls.ONELEVEL_SCOPE_WITH_FOLDERS || _enum.hasMoreElements())
                                    {
                                        MDFolder _parent = (MDFolder)_folderResult.getParent(); // work around for a bug in PersistenceManager
                                        Attributes _attrs = null;
                                        if(_parent != null)
                                            _attrs = _parent.getAttributes(_folderResult.toString(), controls.getReturningAttributes());
                                        else
                                            _attrs = _folderResult.getAttributes("", controls.getReturningAttributes());
                                        fillObjectLabel(_attrs, _objName, controls.getReturningAttributes());

                                        Vector _temp = new Vector(1);
                                        _temp.addElement(_folderResult);
                                        MDMergedFolder _wrapper = new MDMergedFolder(_objName, _temp, getLocale(), getErrorHandler());
                                        MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(_objName, _wrapper, _attrs, MM.FOLDER, getMetadataManagerServices());
                                        _msr.setLabel(_objName);
                                        _msrs.addElement(_msr);
                                    }
                                }
                                catch (Exception e)
                                {
                                    // ignore the path
                                }
                            }
                            else if (_obj instanceof Vector)
                            {
                                Vector _v = (Vector)_obj;
                                String[] _paths = new String[_v.size()];
                                _v.copyInto(_paths);

                                Vector _folders = lookupFolders(_folder, _paths, (MDSearchControls)controls);
                                if (_folders.size() > 0)
                                {
                                    // don't check folders is empty if the scope is one level scope
                                    // with folders
                                    boolean _notEmpty = true;
                                    if (controls.getSearchScope() != BISearchControls.ONELEVEL_SCOPE_WITH_FOLDERS)
                                        _notEmpty = areFoldersEmpty(_folders, matchingAttributes, controls);

                                    if (_notEmpty)
                                    {
                                        // attributes of the merged user defined root folders
                                        Attributes _attrs = getAttributes(_folders, controls.getReturningAttributes());
                                        fillObjectLabel(_attrs, _objName, controls.getReturningAttributes());

                                        MDMergedFolder _folderResult = new MDMergedFolder(_objName, _folders, getLocale(), getErrorHandler());
                                        MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(_objName, _folderResult, _attrs, MM.FOLDER, getMetadataManagerServices());
                                        _msr.setLabel(_objName);
                                        _msrs.addElement(_msr);
                                    }
                                }
                            }
                        }
                    }

                    if (_results == null && _msrs.size() > 0)
                        _results = new Vector(_msrs.size());

                    // finally copy the contents to _results
                    for (int k=0; k<_msrs.size(); k++)
                        _results.addElement(_msrs.elementAt(k));
                }
            }
            else
            {
                Vector _v = getMetadataManagerServices().search(this, name, matchingAttributes, (BISearchControls)controls);
                //Vector _v = getMetadataManagerServices().search(_folder.getUniqueID(), matchingAttributes, (BISearchControls)controls);
                if (_v != null)
                {
                    _results = new Vector(_v.size());
                    for (int i=0; i<_v.size(); i++)
                    {
                        _results.addElement(_v.elementAt(i));
                    }
                }
            }
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (NameNotBoundException nnbe)
        {
            _name = (name.size() > 0)? name.get(name.size()-1) : "";
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_name}, getLocale(), null);
        }
        catch (InvalidPropertyException ipe)
        {
            throw new BIInvalidAttributesException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_ATTRS, null, getLocale(), ipe);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }

        Vector _finalResults = null;
        if (_filter != null)
        {
            if(_results != null)
            {
                _finalResults = new Vector(_results.size());
                for (int i=0; i<_results.size(); i++)
                {
                    boolean _addme = _filter.evaluate((MetadataManagerSearchResultImpl)_results.elementAt(i));
                    if (_addme)
                        _finalResults.addElement(_results.elementAt(i));
                }
            }
        }
        else
            _finalResults = _results;

        // create dummy list for sorting and enumeration
        if (_finalResults == null)
            _finalResults = new Vector(0);
            
        if ( (controls != null) && (controls.getCountLimit() > 0) && (_finalResults.size() > controls.getCountLimit()) )
            _finalResults.setSize((int)controls.getCountLimit());
        
        if (_sorted)
            _finalResults = sortSpecial(_finalResults);

        // if sorting option is on, sort search results before returning.
        if (controls instanceof BISearchControls)
        {
            BISearchControls sc = (BISearchControls)controls;
            if (sc.isSortingOn())
            {
                BIComparator comp = sc.getSortingComparator();
                if (comp != null)
                {
                    if (comp.getErrorHandler() == null)
                        comp.setErrorHandler(m_handler);
                    // make sure that sorting is performed in the correct Locale
                    comp.setLocale(getLocale());
                }
                BISortUtils _sortUtils = new BISortUtils();
                _finalResults = _sortUtils.sortSearchResults(_finalResults, comp);
            }
        }

        return new NamingEnumerationImpl(_finalResults);
    }

    // check to see if object label is needed in the returning attributes
    // fill in the value if necessary
    private void fillObjectLabel(Attributes attrs, String label, String[] returningAttributes)
    {
        if (returningAttributes == null)
        {
            attrs.put(MDU.OBJECT_LABEL, label);
            return;
        }

        for (int i=0; i<returningAttributes.length; i++)
        {
            if (returningAttributes[i].equals(MDU.OBJECT_LABEL))
            {
                attrs.put(MDU.OBJECT_LABEL, label);
                return;
            }
        }
    }

    // checks whether all the folders are empty (from the search)
    private boolean areFoldersEmpty(Vector folders, Attributes matchingAttributes, SearchControls controls)
    {
        for (int i=0; i<folders.size(); i++)
        {
            BIContext _ctx = (BIContext)folders.elementAt(i);
            try
            {
                Enumeration _enum = _ctx.search("", matchingAttributes, controls);
                if (_enum.hasMoreElements())
                    return true;
            }
            catch (NamingException ne) { }
        }
        return false;
    }

    // checks if there are duplicate search path or search path
    // that is the parent path of another search path
    private boolean validateSearchPaths(String[] searchPaths)
    {
        for (int i=0; i<searchPaths.length; i++)
        {
            for (int j=0; j<searchPaths.length; j++)
            {
                if (i != j)
                {
                    if (searchPaths[i] != null && searchPaths[j] != null)
                    {
                        if (searchPaths[i].equals("") || searchPaths[j].equals(""))
                            return true;
                        else if (searchPaths[i].startsWith(searchPaths[j]))
                            return true;
                    }
                }
            }
        }
        return false;
    }

    // lookup the folders based on the search paths
    private Vector lookupFolders(MDFolder parent, String[] paths, MDSearchControls controls)
    {
        Vector _folders = new Vector(paths.length);
        for (int i=0; i<paths.length; i++)
        {
            try
            {
                Object _obj = parent.lookup(paths[i]);
                if (_obj instanceof MDFolder)
                {
                    MDFolder _folder = (MDFolder)_obj;
                    if (controls.isExcludeSubfolders(paths[i]))
                        _folder.setStrPropertyValue("excludeSubfolders", "true");
                    _folders.addElement(_folder);
                }
            }
            catch (Exception e)
            {
                // ignore if search path not found
            }
        }
        return _folders;
    }

    private Vector searchFolders(MDFolder parent, String[] paths, Attributes attrs, MDSearchControls controls)
    {
        Vector _rootFolders = lookupFolders(parent, paths, controls);
        if (_rootFolders.size() == 0)
            return _rootFolders;
        else
            return MDMergedFolder.search(_rootFolders, "", attrs, controls, getLocale(), getErrorHandler());
    }

    // returns multi-valued attributes for merged folders
    private Attributes getAttributes(Vector folders, String[] attrsToReturn)
    {
        BasicAttributes _results = new BasicAttributes();
        for (int i=0; i<folders.size(); i++)
        {
            try
            {
                BIContext _ctx = (BIContext)folders.elementAt(i);
                Attributes _attrs = _ctx.getAttributes("", attrsToReturn);
                if (_attrs != null)
                {
                    Enumeration _enum = _attrs.getIDs();
                    while (_enum.hasMoreElements())
                    {
                        String _key = (String)_enum.nextElement();
                        Object _val = _attrs.get(_key).get();
                        if (_results.get(_key) != null)
                            _results.get(_key).add(_val);
                        else
                            _results.put(_key, _val);
                    }
                }
            }
            catch (NamingException ne) {}
        }
        return _results;
    }

    /**
     * Searches a folder for objects that have specified attributes, using the
     * specified search scope.
     * This method retrieves specified attributes of the found objects.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The attributes of the objects that you
     *                      want to find.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in
     *         <code>attributesToReturn</code>, and the name of the object,
     *         relative to <code>name</code>.
     *
     * @throws BINameNotFoundException If <code>name</code> cannot be found.
     * @throws BIInvalidSearchControlsException If <code>SearchControls</code> is not valid
     * @throws BINoPermissionException If the caller does not have appropriate
     *         permission to search in <code>name</code>.
     * @throws BINamingException If another naming error occurs.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see #search(Name, Attributes, SearchControls)
     *
     * @status reviewed
     */
    public NamingEnumeration search(String name, Attributes matchingAttributes, SearchControls controls) throws NamingException
    {
        return search(getNameParser().parse(name), matchingAttributes, controls);
    }

    /**
     * @hidden
     * Searches a folder for objects that meet criteria that you specify
     * in a filter.
     * The filter uses RFC 2254 syntax. For more information about filters, see
     * <code>http://java.sun.com/products/jndi/tutorial/basics/directory/filter.html</code>.
     *
     * @param  name         The name of the folder to search.
     * @param  filterExpr   The filter expression.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The objects
     *         satisfy the search criteria.
     *
     * @throws BIOperationNotSupportedException Because this operation is currently not
     *         supported.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see javax.naming.directory.DirContext#search(Name, String, SearchControls)
     *
     * @status documented
     */
    public NamingEnumeration search(Name name, String filterExpr, SearchControls searchControls) throws NamingException
    {
        return search(name, filterExpr, null, searchControls);
    }

    /**
     * @hidden
     * Searches a folder for objects that meet criteria that you specify
     * in a filter.
     * The filter uses RFC 2254 syntax. For more information about filters, see
     * <code>http://java.sun.com/products/jndi/tutorial/basics/directory/filter.html</code>.
     *
     * @param  name         The name of the folder to search.
     * @param  filterExpr   The filter expression.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The objects
     *         satisfy the search criteria.
     *
     * @throws BIOperationNotSupportedException Because this operation is currently not
     *         supported.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see javax.naming.directory.DirContext#search(Name, String, SearchControls)
     *
     * @status documented
     */
    public NamingEnumeration search(String name, String filterExpr, SearchControls searchControls) throws NamingException
    {
        return search(getNameParser().parse(name), filterExpr, searchControls);
    }

    /**
     * @hidden
     * Searches a folder for objects that meet criteria that you specify
     * in a filter.
     * The filter uses RFC 2254 syntax. For more information about filters, see
     * <code>http://java.sun.com/products/jndi/tutorial/basics/directory/filter.html</code>.
     *
     * @param  name         The name of the folder to search.
     * @param  filterExpr   The filter expression.
     * @param  filterArgs   The arguments passed into the filter expression.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The objects
     *         satisfy the search criteria.
     *
     * @throws BIOperationNotSupportedException Because this operation is currently not
     *         supported.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see javax.naming.directory.DirContext#search(Name, String, SearchControls)
     *
     * @status documented
     */
    public NamingEnumeration search(Name name, String filterExpr, Object[] filterArgs, SearchControls searchControls) throws NamingException
    {
        throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
    }

    /**
     * @hidden
     * Searches a folder for objects that meet criteria that you specify
     * in a filter.
     * The filter uses RFC 2254 syntax. For more information about filters, see
     * <code>http://java.sun.com/products/jndi/tutorial/basics/directory/filter.html</code>.
     *
     * @param  name         The name of the folder to search.
     * @param  filterExpr   The filter expression.
     * @param  filterArgs   The arguments passed into the filter expression.
     * @param  searchControls The search controls that specify the scope of the
     *                      search. This argument can be null.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The objects
     *         satisfy the search criteria.
     *
     * @throws BIOperationNotSupportedException Because this operation is currently not
     *         supported.
     *
     * @see oracle.dss.bicontext.BISearchControls
     * @see javax.naming.directory.DirContext#search(Name, String, SearchControls)
     *
     * @status documented
     */
    public NamingEnumeration search(String name, String filterExpr, Object[] filterArgs, SearchControls searchControls) throws NamingException
    {
        return search(getNameParser().parse(name), filterExpr, filterArgs, searchControls);
    }

    /**
     * @hidden
     * Retrieves the schema of a folder.
     * This function is not supported.
     *
     * @param name The name of the folder whose schema you want.
     *
     * @throws BIOperationNotSupportedException Because this function is not
     * supported.
     *
     * @status hidden since not supported and not specified by any interface.
     */
    public DirContext getSchema(Name name) throws NamingException
    {
        throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
    }

    /**
     * @hidden
     * Retrieves the schema of a folder.
     * This function is not supported.
     *
     * @param name The name of the folder whose schema you want.
     * 
     * @throws BIOperationNotSupportedException Because this function is not
     * supported.
     *
     * @status hidden since not supported and not specified by any interface.
     */
    public DirContext getSchema(String name) throws NamingException
    {
        throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
    }

    /**
     * @hidden
     * Retrieves the schema definition of a folder.
     * This function is not supported.
     *
     * @param name The name of the folder whose schema definition you want.
     *
     * @throws BIOperationNotSupportedException Because this function is not
     * supported.
     *
     * @status hidden since not supported and not specified by any interface.
     */
    public DirContext getSchemaClassDefinition(Name name) throws NamingException
    {
        throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
    }

    /**
     * @hidden
     * Retrieves the schema definition of a folder.
     * This function is not supported.
     *
     * @param name The name of the folder whose schema definition you want.
     *
     * @throws BIOperationNotSupportedException Because this function is not
     * supported.
     *
     * @status hidden since not supported and not specified by any interface.
     */
    public DirContext getSchemaClassDefinition(String name) throws NamingException
    {
        throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
    }

    /**
     * @hidden
     */
    public void refresh() throws NamingException
    {
        try
        {
            MDFolder _this = (MDFolder)getMetadataManagerServices().refresh(this, 1);

            // required for VB mode, must update current MDFolder properties after
            // refresh
            if (_this.hashCode() != this.hashCode())
            {
                this.setPropertyBag(_this.getPropertyBag(), MDU.REMOVE);
                this.setChildrenID(_this.getChildrenID());
                this.setChildrenBag(_this.getChildrenBag());
                this.setRelativesBag(_this.getRelativesBag());
                this.setDependentID(_this.getDependentID());
            }
        }
        catch (MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }
    }

    /**
     * Copies an existing context or object.
     * This method is useful only when the object being copied is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to copy. Use a slash (/) to separate
     *              folder names.
     *              The path in <code>name</code> is relative to this
     *              context.
     * @param context The context into which to copy <code>name</code>.
     * @param newName The name given to the copy of the object in the target context.  If the
     *                value is null, then the name is the same as the name of the original
     *                object.
     * @param mode  A constant that identifies whether to copy related objects
     *              or only <code>name</code>.
     *
     * @throws      NameAlreadyBoundException If there is already an object with the name specified
     *              in newName in the target context.
     * @throws      NameNotFoundException If the named object to be copied cannot be found.
     * @throws      NoPermissionException If the user does not have enough permission to copy the object
     *              to the target context.
     * @throws      BIOperationNotSupportedException If either <code>name</code>
     *              identifies an OLAP object or if <code>context</code> is
     *              an OLAP folder.
     * @throws      BICircularReferenceException If circular reference is detected.
     * @throws      NamingException If there is a problem during copy.
     *
     * @see oracle.dss.persistence.PSRConstants#NORMAL_COPY
     * @see oracle.dss.persistence.PSRConstants#DEEP_COPY
     *
     * @status reviewed
     *                     
     */
    public void copy(Name name, DirContext context, Name newName, int mode) throws NamingException
    {
        checkValidName(name);
        long _start = System.currentTimeMillis();

       if (newName != null && newName.toString().equals(""))
          throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{""}, getLocale(), null);

        if (context == null)
            throw new BINotContextException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NOT_CONTEXT, null, getLocale(), null);

        if (context instanceof MDFolder)
        {
            MDFolder _target = (MDFolder)context;
            try
            {
                PropertyBag _bag = new PropertyBag();
                _bag.setIntPropertyValue(MDU.COPY_MODE, mode);
                if (newName != null)
                    _bag.setObjPropertyValue(MDU.COPY_NAME, newName.toString());

                //getMetadataManagerServices().copy(_source, _target, _bag);
                getMetadataManagerServices().copy(this, name, _target, _bag);
            }
            catch (NameClashException nce)
            {
                throw new BINameAlreadyBoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new String[]{name.toString()}, getLocale(), null);
            }
            catch (NameNotBoundException nne)
            {
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_target.getName()}, getLocale(), nne);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (CircularReferenceException cre)
            {
                throw new BICircularReferenceException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_CIRCULAR_REF, null, getLocale(), cre);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
        }
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "copy");
    }

    /**
     * Copies an existing context or object.
     * This method is useful only when the object being copied is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to copy. Use a slash (/) to separate
     *              folder names.
     *              The path in <code>name</code> is relative to this
     *              context.
     * @param context The context into which to copy <code>name</code>.
     * @param newName The name given to the copy of the object in the target context.  If the
     *                value is null, then the name is the same as the name of the original
     *                object.
     * @param mode  A constant that identifies whether to copy related objects
     *              or only <code>name</code>.
     *
     * @throws      NameAlreadyBoundException If there is already an object with the name specified
     *              in newName in the target context.
     * @throws      NameNotFoundException If the named object to be copied cannot be found.
     * @throws      NoPermissionException If the user does not have enough permission to copy the object
     *              to the target context.
     * @throws      BIOperationNotSupportedException If either <code>name</code>
     *              identifies an OLAP object or if <code>context</code> is
     *              an OLAP folder.
     * @throws      BICircularReferenceException If circular reference is detected.
     * @throws      NamingException If there is a problem during copy.
     *
     * @see oracle.dss.persistence.PSRConstants#NORMAL_COPY
     * @see oracle.dss.persistence.PSRConstants#DEEP_COPY
     *
     * @status reviewed
     */
    public void copy(String name, DirContext context, String newName, int mode) throws NamingException
    {
        Name _name = null;
        if (newName != null)
            _name = getNameParser().parse(newName);

        copy (getNameParser().parse(name), context, _name, mode );
    }

    /**
     * Moves an existing context or object.
     * This method is useful only when the object being moved is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to move. The path in
     *              <code>name</code> is relative to this context.
     * @param context The context into which to move <code>name</code>.
     *
     * @throws      NameAlreadyBoundException If there is already an object with the name specified
     *              in newName in the target context.
     * @throws      NameNotFoundException If the named object to be copied cannot be found.
     * @throws      NoPermissionException If the user does not have enough permission to copy the object
     *              to the target context.
     * @throws      BIOperationNotSupportedException If <code>name</code>
     *              identifies an OLAP object or if <code>context</code> is
     *              an OLAP folder.
     * @throws      BICircularReferenceException If circular reference is detected.
     * @throws      NamingException If there is a problem during move.
     *
     * @status reviewed
     */
    public void move(Name name, DirContext context) throws NamingException
    {
        checkValidName(name);
        long _start = System.currentTimeMillis();

        if (context == null)
            throw new BINotContextException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NOT_CONTEXT, null, getLocale(), null);

        if (context instanceof MDFolder)
        {
            MDFolder _target = (MDFolder)context;
            try
            {
                //getMetadataManagerServices().move(_source, _target, null);
                getMetadataManagerServices().move(this, name, _target, null);
            }
            catch (NameClashException nce)
            {
                throw new BINameAlreadyBoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new String[]{name.toString()}, getLocale(), null);
            }
            catch (NameNotBoundException nne)
            {
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_target.getName()}, getLocale(), nne);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (CircularReferenceException cre)
            {
                throw new BICircularReferenceException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_CIRCULAR_REF, null, getLocale(), cre);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
        }
        getErrorHandler().trace("[" + name + "] " +(System.currentTimeMillis()-_start) + "ms ", this.getClass().getName(), "move");
    }

    /**
     * Moves an existing context or object.
     * This method is useful only when the object being moved is not
     * a metadata object, such as an <code>MDDimension</code>.
     * Calling this method on a metadata object is not useful.
     *
     * @param name  The name of the object to move. The path in
     *              <code>name</code> is relative to this context.
     * @param context The context into which to move <code>name</code>.
     *
     * @throws    NamingException If there is a problem with the name.
     * @throws      NameAlreadyBoundException If there is already an object with the name specified
     *              in newName in the target context.
     * @throws      NameNotFoundException If the named object to be copied cannot be found.
     * @throws      NoPermissionException If the user does not have enough permission to copy the object
     *              to the target context.
     * @throws      BIOperationNotSupportedException If <code>name</code>
     *              identifies an OLAP object or If <code>context</code> is
     *              an OLAP folder.
     * @throws      BICircularReferenceException If circular reference is detected.
     * @throws      NamingException If there is a problem during copy.
     *
     * @status reviewed
     */
    public void move(String name, DirContext context) throws NamingException
    {
        move(getNameParser().parse(name), context);
    }

    /**
     * Retrieves the access control list for this context.
     * The access control list is a list of permissions.
     *
     * @return The access control list for this context.
     *
     * @throws BINamingException If a naming error occurs.
     *
     * @status reviewed
     */
    public Acl getAcl() throws NamingException
    {
        if (m_acl == null)
            m_acl = new AclImpl(this);
        return m_acl;
    }

    /**
     * Adds a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to add to the access control list of the
     *                specified object.
     * @param name The name of the object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add entries
     *            to the access control list of the specified object.
     *
     * @status New
     */
    public boolean addEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        boolean _flag = false;
        try
        {
            _flag = getMetadataManagerServices().addEntries(this, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _flag;
    }

    /**
     * Adds a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to add to the access control list of the
     *                specified object.
     * @param name The name of the object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add entries
     *            to the access control list of the specified object.
     *
     * @status New
     */
    public boolean addEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        return addEntries(getNameParser().parse(name), entries, cascadeToSubFolders, cascadeToObjects);
    }

    /**
     * Removes a <code>Vector</code> of entries from the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to remove from the access control list of the
     *                specified object.
     * @param name The name of the object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully removed
     *                           from the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to remove entries
     *            from the access control list of the specified object.
     *
     * @status New
     */
    public boolean removeEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        boolean _flag = false;
        try
        {
            _flag = getMetadataManagerServices().removeEntries(this, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _flag;
    }

    /**
     * Removes a <code>Vector</code> of entries from the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to remove from the access control list of the
     *                specified object.
     * @param name The name of the object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully removed
     *                           from the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to remove entries
     *            from the access control list of the specified object.
     *
     * @status New
     */
    public boolean removeEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        return removeEntries(getNameParser().parse(name), entries, cascadeToSubFolders, cascadeToObjects);
    }

    /**
     * Sets a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * This method replaces all existing entries in the access control list
     * with the specified entries.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to be set as the access control list of the
     *                specified object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add/remove
     *            entries to/from the access control list of the specified object.
     *
     * @status New
     */
    public boolean setEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        boolean _flag = false;
        try
        {
            _flag = getMetadataManagerServices().setEntries(this, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _flag;
    }

    /**
     * Sets a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * This method replaces all existing entries in the access control list
     * with the specified entries.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to be set as the access control list of the
     *                specified object.
     * @param cascadeToSubFolders <code>true</code> to have these entries apply to
     *                            all of the subfolders if the specified object
     *                            is a folder.
     *                            <code>false</code> to have these entries apply to
     *                            this object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> to have these entries apply to all
     *                         of the objects within the folder if the specified object
     *                         is a folder.
     *                         <code>false</code> to have these entries apply to
     *                         this object only.
     *                         This flag is ignored if the specified object is not
     *                         a folder
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add/remove
     *            entries to/from the access control list of the specified object.
     *
     * @status New
     */
    public boolean setEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException
    {
        return setEntries(getNameParser().parse(name), entries, cascadeToSubFolders, cascadeToObjects);
    }

    /**
     * Retrieves the <code>Vector</code> of entries from the access control list
     * of the specified object.
     *
     * @param name The name of the object.
     *
     * @return A <code>Vector</code> of entries from the access control list
     *         of the specified object.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to list entries
     *            of the specified object.
     *
     * @status New
     */
    public Vector entries(Name name) throws NamingException
    {
        Vector _entries = null;
        try
        {
            _entries = getMetadataManagerServices().entries(this, name);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _entries;
    }

    /**
     * Retrieves the <code>Vector</code> of entries from the access control list
     * of the specified object.
     *
     * @param name The name of the object.
     *
     * @return A <code>Vector</code> of entries from the access control list
     *         of the specified object.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to list entries
     *            of the specified object.
     *
     * @status New
     */
    public Vector entries(String name) throws NamingException
    {
        return entries(getNameParser().parse(name));
    }

    /**
     * Retrieves the <code>Vector</code> of all the <code>User</code> objects from
     * the BI Beans Catalog.
     *
     * @return A <code>Vector</code> of all the <code>User</code> objects from
     *         the BI Beans Catalog.
     *
     * @throws NamingException If an error has occurred.
     *
     * @status New
     */
    public Vector getAllUsers() throws NamingException
    {
        Vector _users = null;
        try
        {
            _users = getMetadataManagerServices().getAllUsers();
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _users;
    }

    /**
     * Retrieves the privilege that the caller has, either as a user or
     * as a member of a group, on the specified object.
     *
     * @param name The name of the object.
     *
     * @return The highest privilege of the caller, either as a user or as a
     *         member of a group, on the specified object.
     *
     * @status New
     */
    public Privilege getPrivilege(Name name) throws NamingException
    {
        Privilege _priv = null;
        try
        {
            _priv = getMetadataManagerServices().getPrivilege(this, name);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (UnsupportedOperationException uoe)
        {
            throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
        }
        catch (MetadataManagerException mpe)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
        }
        return _priv;
    }

    /**
     * Retrieves the privilege that the caller has, either as a user or
     * as a member of a group, on the specified object.
     *
     * @param name The name of the object.
     *
     * @return The highest privilege of the caller, either as a user or as a
     *         member of a group, on the specified object.
     *
     * @status New
     */
    public Privilege getPrivilege(String name) throws NamingException
    {
        return getPrivilege(getNameParser().parse(name));
    }

    private PropertyBag attributeToPropertyBag(Attributes attrs)
    {
        PropertyBag _bag = new PropertyBag();
        if (attrs != null)
        {
            try
            {
                NamingEnumeration _enum = attrs.getIDs();
                while (_enum.hasMoreElements())
                {
                    String _key = (String)_enum.nextElement();
                    Object _value = attrs.get(_key).get();
                    if (_value != null)
                    {
                        if (_value instanceof String)
                            _bag.setStrPropertyValue(_key, (String)_value, MDU.UI_ALL);
                        else
                            _bag.setObjPropertyValue(_key, _value, MDU.UI_ALL);
                    }
                }
            }
            catch (NamingException ne)
            {
                getErrorHandler().error(ne, getClass().getName(), "attributeToPropertyBag");
            }
        }
        return _bag;
    }

    private void bindAttributes(MDObject obj, Attributes attrs) throws NamingException
    {
        NamingEnumeration _enum = attrs.getIDs();
        while (_enum.hasMoreElements())
        {
            String _key = (String)_enum.nextElement();
            Object _value = attrs.get(_key).get();
            if (_value != null)
                obj.setObjPropertyValue(_key, _value, MDU.UI_ALL);
        }
    }

    private MDFolder findFolder(Name name, MDFolder folder) throws NamingException
    {
        if (name.size() == 0)
            return folder;
        else
        {
            String _child = (String)name.remove(0);
            MDObject _childFolder = null;
            try {
                _childFolder = folder.getChild(_child);
            }
            catch( MetadataManagerException e ) {
            }
            if (_childFolder == null || !(_childFolder instanceof MDFolder))
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{name.toString()});

            return findFolder(name, (MDFolder)_childFolder);
        }
    }

    Attributes getAttributes(MDObject obj, String[] attrIds) throws NamingException
    {
        if (isPersistableObj(obj))
        {
            try
            {
                //return getMetadataManagerServices().getAttributes(obj, attrIds, -1);
                return getMetadataManagerServices().getAttributes(this, this.getNameParser((String)null).parse(obj.getName()), attrIds, -1);
            }
            catch (NameNotBoundException nne)
            {
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{obj.getName()}, getLocale(), nne);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
        }
        else
        {
            BasicAttributes _attrs = new BasicAttributes();
            if (attrIds == null)
            {
                Property[] _props = obj.getProperties();
                for (int i=0; i<_props.length; i++)
                    _attrs.put(_props[i].getName(), _props[i].getObjValue());
            }
            else
            {
                for (int i=0; i<attrIds.length; i++)
                {
                    String _key = attrIds[i];
                    Object _value = obj.getObjPropertyValue(_key);
                    if (_value != null)
                        _attrs.put(_key, _value);
                }
            }
            return _attrs;
        }
    }

    private boolean isPersistableObj(MDObject mdObj)
    {
        Vector _types = mdObj.getDriverTypes();
        if (_types != null)
        {
            for (int i=0; i<_types.size(); i++)
            {
                if (_types.elementAt(i).equals(MDU.PERSISTENCE))
                    return true;
            }
        }
        return false;
    }

    // converts a property bag into attributes
    private Attributes propertyBagToAttributes(PropertyBag properties)
    {
        if (properties != null)
        {
            BasicAttributes _attrs = new BasicAttributes();
            Property[] _props = properties.getProperties();
            if (_props != null) {
              for (int i=0; i<_props.length; i++)
              {
                  String _key = _props[i].getName();
                  Object _val = _props[i].getObjValue();
                  if (_key != null && _val != null)
                      _attrs.put(_key, _val);
              }
            }
            
            return _attrs;
        }
        else
            return null;
    }

    // checks whether name is null
    private void checkNullName(String name) throws NamingException
    {
        if (name == null)
          throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{name}, getLocale(), null);
    }

    private String getRelativeName(MDFolder folder, MDObject obj)
    {
        String _path = folder.getPath();
        if (_path == null || _path.equals(""))
            return obj.getPath();
        else
        {
            String _objPath = obj.getPath();
            if (_objPath != null)
            {
                int _index = _objPath.indexOf(_path);
                if (_index > -1)
                    return _objPath.substring(_index+_path.length()+1, _objPath.length());
                else
                    return _objPath;
            }
            else
                return obj.toString();
        }
    }

    // checks whether name is null
    private void checkNullName(Name name) throws NamingException
    {
        if (name == null)
          throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{"NULL"}, getLocale(), null);
    }

    // checks whether name is invalid
    private void checkValidName(Name name) throws NamingException
    {
        checkNullName(name);
        if (name.toString().trim().equals(""))
            throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{name.toString()}, getLocale(), null);
    }

    // fast short-cut methods for accessing cache
    /**
     * @hidden
     */
    public MDObject getChild(String name) throws MetadataManagerException
    {
        Property _prop = new Property();
        _prop.setStrValue(MDU.OBJECT_NAME, name, MDU.UI_ALL);
        MDObject[] _ret = getChildren(_prop);
        if (_ret != null)
            return _ret[0];
        else
        {
            _prop = new Property();
            _prop.setStrValue(MM.LONG_LABEL, name, MDU.UI_ALL);
            _ret = getChildren(_prop);
            if (_ret != null)
                return _ret[0];
            else
                return null;
        }
    }

    private Attributes getRetAttrsFromMDObject(MDObject mdObj, String[] retAttrs)
    {
        BasicAttributes _attrs = new BasicAttributes();

        if (retAttrs == null)
        {
            Property[] _prop = mdObj.getProperties();
            if (_prop != null)
            {
                for (int i=0; i<_prop.length; i++)
                {
                    String _key = _prop[i].getName();
                    Object _val = _prop[i].getObjValue();
//                    if (_val != null)
                    _attrs.put(_key, _val);
                }
            }
        }
        else
        {
            for (int i=0; i<retAttrs.length; i++)
            {
                Property _prop = mdObj.getProperty(retAttrs[i]);
                if (_prop != null)
                    _attrs.put(retAttrs[i], _prop.getObjValue());
            }
        }
        return _attrs;
    }

    /**
     *
     * @hidden
     *
     */
    private Vector sortSpecial(Vector results)
    {
        Vector _folders = new Vector(results.size());
        Vector _measures = new Vector(results.size());
        Vector _dimensions = new Vector(results.size());
        Vector _others = new Vector(results.size());

        for (int i=0; i<results.size(); i++)
        {
            MetadataManagerSearchResultImpl _result = (MetadataManagerSearchResultImpl)results.elementAt(i);
            if (_result.getObjectType().equals(MM.FOLDER))
                orderInsert(_folders, _result);
            else if (_result.getObjectType().equals(MM.MEASURE))
                orderInsert(_measures, _result);
            else if (_result.getObjectType().equals(MM.DIMENSION))
                orderInsert(_dimensions, _result);
            else
                orderInsert(_others, _result);
        }

        Vector _sorted = new Vector(results.size());
        for (int j=0; j<_folders.size(); j++)
            _sorted.addElement(_folders.elementAt(j));

        for (int k=0; k<_measures.size(); k++)
            _sorted.addElement(_measures.elementAt(k));

        for (int l=0; l<_dimensions.size(); l++)
            _sorted.addElement(_dimensions.elementAt(l));

        for (int m=0; m<_others.size(); m++)
            _sorted.addElement(_others.elementAt(m));

        return _sorted;
    }

    /**
     * @hidden
     *
     */
    private int orderInsert(Vector v, MetadataManagerSearchResultImpl result)
    {
        String _myName = result.getName();

        int _count = v.size();
        for (int i=0; i<_count; i++)
        {
            MetadataManagerSearchResultImpl _result = (MetadataManagerSearchResultImpl)v.elementAt(i);
            if (_myName.compareTo(_result.getName()) < 0)
            {
                v.insertElementAt(result, i);
                return i;
            }
        }
        v.insertElementAt(result, _count);
        return _count;
    }

    /**
     * @hidden
     */
    private void dump()
    {
        ErrorHandler _errHandler = getErrorHandler();

        try
        {
            NamingEnumeration _enum = list("");
            _errHandler.trace("current directory content:", "", "");
            while (_enum.hasMoreElements())
            {
                BINameClassPair _nc = (BINameClassPair)_enum.nextElement();
                _errHandler.trace(_nc.getName(), "", "");
            }
        }
        catch (NamingException ne){}
    }

    /**
     * @hidden
     */
    public class NameParserImpl implements NameParser, java.io.Serializable
    {
        public Name parse(String name) throws NamingException
        {
            checkNullName(name);
            Properties syntax = new Properties();

            syntax.put("jndi.syntax.direction", "left_to_right");
            syntax.put("jndi.syntax.separator", "/");

            return new CompoundName(name, syntax);
        }
    }

    // NamingEnumeration wrapper around Vector
    /**
     * @hidden
     */
    public class NamingEnumerationImpl implements NamingEnumeration, java.io.Serializable
    {
      Enumeration m_enum;

      NamingEnumerationImpl(Vector v)
      {
          m_enum = v.elements();
      }

      public boolean hasMoreElements()
      {
          return m_enum.hasMoreElements();
      }

      public boolean hasMore() throws NamingException
      {
          return hasMoreElements();
      }

      public Object nextElement()
      {
          return m_enum.nextElement();
      }

      public Object next() throws NamingException
      {
            return nextElement();
      }

      public void close()
      {
      }
    }

    /**
     * @hidden
     */
    public class AclImpl implements Acl
    {
        private MDFolder _folder;

        AclImpl(MDFolder folder)
        {
            _folder = folder;
        }

        public boolean addEntries(Vector entries, boolean cascade) throws NamingException
        {
            boolean _flag = false;
            try
            {
                _flag = _folder.getMetadataManagerServices().addEntries(_folder, getNameParser().parse(""), entries, cascade, false);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            return _flag;
        }

        public boolean removeEntries(Vector entries, boolean cascade) throws NamingException
        {
            boolean _flag = false;
            try
            {
                _flag = _folder.getMetadataManagerServices().removeEntries(_folder, getNameParser().parse(""), entries, cascade, false);
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            return _flag;
        }

        public Vector entries() throws NamingException
        {
            Vector _entries = null;
            try
            {
                _entries = _folder.getMetadataManagerServices().entries(_folder, getNameParser().parse(""));
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            return _entries;
        }

        public Vector getAllUsers() throws NamingException
        {
            Vector _users = null;
            try
            {
                _users = _folder.getMetadataManagerServices().getAllUsers();
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            return _users;
        }

        public Privilege getPrivilege() throws NamingException
        {
            Privilege _priv = null;
            try
            {
                _priv = _folder.getMetadataManagerServices().getPrivilege(_folder, getNameParser().parse(""));
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
            return _priv;
        }
    }

    /**
     * Retrieves the folders that are children of this folder.
     *
     * @return All of the folders in this folder.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status reviewed
     */
    public MDFolder[] getFolders() throws MetadataManagerException {
      return MDFolder.getFolderArray(getChildren(MM.FOLDER));
    }
    
    /**
     * Specifies folders to be children of this folder.
     *
     * @param folders The folders that you want this folder to contain.
     *
     * @return A constant that represents success or failure.
     *         Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status reviewed
     */
    public int setFolders(MDFolder[] folders) {
      if ( (folders == null) || (folders.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<folders.length; i++) {
        setChild(folders[i], MM.FOLDER);
      }
    return MDU.SUCCESS;
    }

   /**
     * Retrieves the measures in this folder.
     *
     * @return The measures that this folder contains, or <code>null</code>
     *         if this folder contains no measures.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status reviewed
     */
    public MDMeasure[] getMeasures() throws MetadataManagerException {
      return MDMeasure.getMeasureArray(getChildren(MM.MEASURE));
    }

    /**
     * @hidden
     * Specifies measures in this folder.
     * The measures must be custom measures.
     * You cannot use this method to change the way that data is stored in
     * the analytic workspace.
     *
     * @param measures The measures that you want this folder to contain.
     *
     * @return A constant that represents success or failure.
     *         Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented
     */
    public int setMeasures(MDMeasure[] measures) {
      if ( (measures == null) || (measures.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<measures.length; i++) {
        setChild(measures[i], MM.MEASURE);
      }
      return MDU.SUCCESS;
    }
    
    /**
     * Retrieves the selections in this folder.
     *
     * @return The selections that this folder contains, or <code>null</code>
     *         if this folder contains no selections.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status reviewed
     */
    public MDSelection[] getSelections() throws MetadataManagerException {
    return MDSelection.getSelectionArray(getChildren(MM.SELECTION));
    }
  
    /**
     * @hidden
     * Specifies the set of selections in this folder.
     *
     * @param selections The selections that you want this folder to contain.
     *
     * @return A constant that represents success or failure.
     *         Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented
     */
    public int setSelections(MDSelection[] selections) {
      if ( (selections == null) || (selections.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<selections.length; i++) {
        setChild(selections[i], MM.SELECTION);
      }
      return MDU.SUCCESS;
    }
    
    /**
     * Retrieves the dimensions in this folder.
     *
     * @return The dimensions that this folder contains, or <code>null</code>
     *         if this folder contains no dimensions.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status reviewed
     */
    public MDDimension[] getDimensions() throws MetadataManagerException {
      return MDDimension.getDimensionArray(getChildren(MM.DIMENSION));
    }
  
   /**
     * @hidden
     * Specifies the set of dimensions in this folder.
     * You cannot use this method to change the way that data is stored in
     * the analytic workspace.
     *
     * @param dimensions The dimensions that you want this folder to contain.
     *
     * @return A constant that represents success or failure.
     *         Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented-PriorityReview Is this right? Or can I change the
     * folders that a dimension is in?
     */
    public int setDimensions(MDDimension[] dimensions) {
      if ( (dimensions == null) || (dimensions.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<dimensions.length; i++) {
        setChild(dimensions[i], MM.DIMENSION);
      }
      return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the components in this folder.
     *
     * @return The components that this folder contains, or <code>null</code>
     *         if this folder contains no components.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented
     */
    public MDComponent[] getComponents() throws MetadataManagerException {
      return MDComponent.getComponentArray(getChildren(MM.COMPONENT));
    }

    /**
     * @hidden
     * Specifies the set of components in this folder.
     *
     * @param components The components that you want this folder to contain.
     *
     * @return A constant that represents success or failure.
     *         Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented
     */
    public int setComponents(MDComponent[] components) {
      if ( (components == null) || (components.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<components.length; i++) {
        setChild(components[i], MM.COMPONENT);
      }
      return MDU.SUCCESS;
    }

    /**
     *
     * @hidden
     *
     */
    public static MDFolder[] getFolderArray(MDObject[] objects) {
      if (objects == null)
      return null;
    MDFolder[] folders = new MDFolder[objects.length];
    for (int i=0; i<objects.length; i++) {
      folders[i] = (MDFolder)objects[i];
    }
    return folders;
  }

    /**
     *
     * @hidden
     *
     */
    public static MDFolder[] getFolderArray(PropertyBag[] propertyBag) {
    if (propertyBag == null)
      return null;
    MDFolder[] folders = new MDFolder[propertyBag.length];
    for (int i=0; i<propertyBag.length; i++) {
      folders[i] = (MDFolder)propertyBag[i];
    }
    return folders;    
  }

    /**
     * Retrieves the locale of the MetadataManager.
     *
     * @return The locale of this folder.
     *
     * @status Documented
     */
    public Locale getLocale()
    {
        Locale _locale = null;
        if(getMetadataManagerServices() != null)
            _locale = getMetadataManagerServices().getLocale();
        if (_locale == null)
            return Locale.getDefault();
        else
            return _locale;
    }

    /**
     * Specifies the locale of the MetadataManager.
     * This method also changes the locale in the MetadataManager.
     *
     * @param locale The locale that the MetadataManager should use.
     *
     * @status Documented
     */
    public void setLocale(Locale locale)
    {
        getMetadataManagerServices().setLocale(locale);
    }

    /**
     * @hidden
     */
    public String getNameInNamespace() {
        return null;
    }

    /**
     * @hidden
     * Retrieves the object type associated with the specified
     * <code>MDObject</code>.
     *
     * In the case of custom measures, the MDObject's subtype (MM.CALCULATION)
     * is returned instead of the type (MM.MEASURE).
     *
     * @param  mdObject a <code>MDObject</code> that we need to retrieve
     *         the object type for.
     *
     * @return <code>String</code> associated with the MDObject's object type.
     */
    private String getObjectType (MDObject mdObject)
    {
        if (mdObject == null)
            return null;

        return mdObject.getObjectType();
    }

    private void bindCommon(Name name, Object object, Attributes attrs, boolean isRebind, Hashtable env) throws NamingException
    {
        long _start = System.currentTimeMillis();

        // first check whether name is empty or null
        checkValidName(name);

        if (object == null)
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_OBJ, null, getLocale(), null);
        else if (object instanceof MDFolder)
            // cannot use bind to save a context, use createSubcontext to create a new context
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_BIND_CONTEXT, null, getLocale(), null);
        else if (object instanceof Persistable || object instanceof LinkRef)
        {
            Attributes _bindOptions = new BasicAttributes();
            if (isRebind)
                _bindOptions.put(MDU.BIND_OPTION, MDU.REBIND);
            else
                _bindOptions.put(MDU.BIND_OPTION, MDU.BIND);

            try
            {
                getMetadataManagerServices().bind(this, name, object, attrs, _bindOptions, env);
            }
            catch (NameClashException nce)
            {
                BINameAlreadyBoundException _nb = null;
                _nb = new BINameAlreadyBoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND, new String[]{name.get(name.size()-1)}, getLocale(), nce);
                _nb.setRebindAllowed(nce.isRebindAllowed());
                throw _nb;
            }
            catch (InsufficientPrivilegeException ipe)
            {
                throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
            }
            catch (InvalidPropertyException ipe2)
            {
                throw new BIInvalidAttributesException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_ATTRS, null, getLocale(), ipe2);
            }
            catch (UnsupportedOperationException uoe)
            {
                throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
            }
            catch (NameNotBoundException nnbe)
            {
                Throwable _exp = nnbe.getBIRootCause();
                if(_exp instanceof BINameNotFoundException)
                {
                    String _errMsg = ((BINameNotFoundException)_exp).getMessage();
                    if(_errMsg != null && _errMsg.startsWith("DVT-14681"))
                        throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_FOLDER, null, getLocale(), nnbe);
                }
                else if (_exp instanceof java.io.FileNotFoundException)
                    throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_FOLDER, null, getLocale(), nnbe);
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{name.toString()}, getLocale(), nnbe);
            }
            catch (CircularReferenceException cre)
            {
                throw new BICircularReferenceException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_CIRCULAR_REF, null, getLocale(), cre);
            }
            catch (MetadataManagerException mpe)
            {
                throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mpe.getLocalizedMessage()}, getLocale(), mpe);
            }
        }
        else
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_OBJ, null, getLocale(), null);    
    }
    
    // a private method to be used by the unbind, move, rename, etc. methods internally
    // (we don't want to return a Persistable object but rather an MDObject to these methods).
    private MDObject lookupMDObject(Name name) throws NamingException
    {
        // first check whether name is empty or null
        checkNullName(name);

        // if the name is empty, return a clone of this MDFolder
        // see JNDI spec for detail
        if (name.size() == 0)
            return this;

        Name _folderName = (Name)name.clone();
        String _objName = (_folderName.remove(name.size()-1)).toString();

        String _path = getPath();
        if (_path == null)
            _path = "";

        String _fullPathName = composeName(name.toString(), _path);
        MDObject _obj = null;
        try
        {
            _obj = getMetadataManagerServices().getMDObjectUsingFullPath(_fullPathName);
            if (_obj == null)
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_objName}, getLocale(), null);
                
            _obj.setMetadataManagerServices(getMetadataManagerServices());
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_objName}, getLocale(), null);
        }
        catch (MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }

        return _obj;
    }

    private MDFolder lookupMDFolder(Name name) throws NamingException
    {
        // first check whether name is empty or null
        checkNullName(name);

        // if the name is empty, return a clone of this MDFolder
        // see JNDI spec for detail
        if (name.size() == 0)
            return this;

        Name _folderName = (Name)name.clone();
        String _objName = (_folderName.remove(name.size()-1)).toString();

        String _path = getPath();
        if (_path == null)
            _path = "";

        String _fullPathName = composeName(name.toString(), _path);
        MDFolder _obj = null;
        try
        {
            _obj = getMetadataManagerServices().getMDFolderUsingFullPath(_fullPathName);
            if (_obj == null)
                throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_objName}, getLocale(), null);
                
            _obj.setMetadataManagerServices(getMetadataManagerServices());
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{_objName}, getLocale(), null);
        }
        catch (MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }

        return _obj;
    }

    /**
     * @hidden
     */
    public boolean getFeature(String feature)
    {
        return getMetadataManagerServices().getFeature(feature);
    }
    
    public Vector listAssociates(String relativeSourceName, String[] attrsToReturn, Attribute identifier) throws NamingException
    {
        return listAssociates(getNameParser().parse(relativeSourceName), attrsToReturn, identifier);
    }

    public Vector listAssociates(Name relativeSourceName, String[] attrsToReturn, Attribute identifier) throws NamingException
    {
        checkValidName(relativeSourceName);
        try
        {
            return getMetadataManagerServices().listAssociates(this, relativeSourceName, attrsToReturn, identifier);
        }
        catch (InsufficientPrivilegeException ipe)
        {
            throw new BINoPermissionException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, getLocale(), ipe);
        }
        catch (NameNotBoundException nnbe)
        {
            throw new BINameNotFoundException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new String[]{relativeSourceName.toString()}, getLocale(), null);
        }
        catch (MetadataManagerException mme)
        {
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, new String[]{mme.getLocalizedMessage()}, getLocale(), mme);
        }
    }
    
    public ImpactReport rebindImpact(Name name, Object obj, Attributes attrs, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(Name name, Object obj, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(String name, Object obj, Attributes attrs, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(String name, Object obj, boolean dryRun)
    {
        return null;
    }
    public ImpactReport unbindImpact(Name name, boolean dryRun)
    {
        return null;
    }
    public ImpactReport unbindImpact(String name, boolean dryRun)
    {
        return null;
    }
    public void endConsistentRead()
    {
        
    }
    public void startConsistentRead()
    {
        
    }
}
