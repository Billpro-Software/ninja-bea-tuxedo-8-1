/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import java.text.MessageFormat;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.BINamingException;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * MetadataManager extension of the BISearchResult class.  An enumeration of 
 * these objects is returned by the <code>listBinding</code> and 
 * <code>search</code> methods on <code>MDFolder</code>
 * 
 * @see oracle.dss.bicontext.BISearchResult
 * @see oracle.dss.metadataManager.common.MDFolder
 * 
 * @status Documented
 */
public class MetadataManagerSearchResultImpl extends BISearchResult
{
    private MetadataManagerServices m_mms = null;
    private Vector m_driverTypes = null;
    private String m_fullPathName = null;

    /**
     * @hidden
     */
    public MetadataManagerSearchResultImpl (String name, Object obj, Attributes attrs, String type, MetadataManagerServices mms)
    {
        super(name, obj, attrs, type);
        m_mms = mms;
    }

    /**
     * @hidden
     */
    public MetadataManagerSearchResultImpl (String name, Object obj, Attributes attrs, boolean isRelative, String type, MetadataManagerServices mms)
    {
        super(name, obj, attrs, isRelative, type);
        m_mms = mms;
    }

    /**
     * @hidden
     */
    public MetadataManagerSearchResultImpl (String name, String className, Object obj, Attributes attrs, String type, MetadataManagerServices mms)
    {
        super(name, className, obj, attrs, type);
        m_mms = mms;
    }

    /**
     * @hidden
     */
    public MetadataManagerSearchResultImpl(String name, String className, Object obj, Attributes attrs, boolean isRelative, String type, MetadataManagerServices mms)
    {
        super(name, className, obj, attrs, isRelative, type);
        m_mms = mms;
    }

    /**
     * @hidden
     * this is to prevent the super class toString method
     * to call toString on whatever returned from getObject()
     * all we need is just a name for rendering
     */
    public String toString()
    {
        return getName();
    }

    /**
     * Retrieves the actual object that this 
     * SearchResult references.
     * If the SearchResult refers to an object that is stored in the 
     * BI Beans Catalog,
     * then a <code>Persistable</code> object is returned.
     * Otherwise, an <code>MDObject</code> is returned.
     *
     * @return The actual object that this object references.
     * 
     * @status Documented
     */
    public Object getObject()
    {
        Object _obj = super.getObject();
        if(_obj instanceof MDObject)
        {
            MDObject _mdObj = (MDObject)_obj;
            _mdObj.setMetadataManagerServices(m_mms);
            return _mdObj;
        }
        try
        {
            if(_obj instanceof String)
            {
                return m_mms.getObject((String)_obj, getDriverType());
            }
        }
        catch (MetadataManagerException me)
        {
            throw new MetadataManagerRuntimeException(getExceptionMessage(), me);
        }
        return _obj;
    }

    /**
     * Retrieves the <code>MDObject</code> that this object references.
     * 
     * @return An <code>MDObject</code> to which this object refers.
     * 
     * @status Documented
     */
    public MDObject getMDObject()
    {
        MDObject _mdObj = (MDObject)getObjectDefinition();
        if(_mdObj != null)
            _mdObj.setMetadataManagerServices(m_mms);
        return _mdObj;
    }
    
    /**
     * @hidden
     */
    public Object getObjectDefinition()
    {
        Object object = super.getObject();
        if (object instanceof String)
        {
            try
            {
                return m_mms.getMDObject(MM.PATH, m_fullPathName, getObjectType());
            }
            catch(MetadataManagerException me)
            {
                throw new MetadataManagerRuntimeException(getExceptionMessage(), me);
            }
        }

        return object;
    }

    private String getExceptionMessage()
    {
        Locale _locale = null;
        if (m_mms != null)
            _locale = m_mms.getLocale();

        if (_locale == null)
            _locale = Locale.getDefault();

        ResourceBundle _bundle = ResourceBundle.getBundle("oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle", _locale);
        if (_bundle != null)
        {
            String _msg = _bundle.getString(MetadataManagerCommonBundle.EXC_UNKNOWN);
            String _exMsg = MessageFormat.format("{0}-{1} {2}", new Object[] { "DVT", MetadataManagerCommonBundle.EXC_UNKNOWN, _msg });
            return _exMsg;
        }
        else
            return null;
    }

    /**
     * @hidden
     */
    public String getDriverType()
    {
        if(m_driverTypes != null && m_driverTypes.size() > 0)
            return (String)m_driverTypes.firstElement();
        return null;
    }

    /**
     * @hidden
     */
    public Vector getDriverTypes()
    {
        return m_driverTypes;
    }

    /**
     * @hidden
     */
    public void setDriverType(String driverType)
    {
        if(m_driverTypes == null)
            m_driverTypes = new Vector(2);
        if(driverType != null)
            m_driverTypes.addElement(driverType);
    }

    /**
     * @hidden
     */
    public void setMetadataManagerServices(MetadataManagerServices mms)
    {
        m_mms = mms;
    }

    /**
     * @hidden
     */
    public MetadataManagerServices getMetadataManagerServices()
    {
        return m_mms;
    }

    public void setFullPathName(String fullPathName)
    {
        m_fullPathName = fullPathName;
    }

    public String getFullPathName()
    {
        return m_fullPathName;
    }
}
