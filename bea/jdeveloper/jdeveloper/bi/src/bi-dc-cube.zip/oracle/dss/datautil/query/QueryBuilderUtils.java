/**
 * QueryBuilderUtils.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 *
 */

package oracle.dss.datautil.query;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.NamingException;

import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.CB;

import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.QueryAccess;
import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.filter.MeasureFilter;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDAttribute;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;

import oracle.dss.metadataUtil.PropertyBag;

import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.OlapQDRMember;

import oracle.dss.util.ValidationProperties;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.Utility;

//import oracle.jdbc.driver.OracleTypes;

/**
 * @hidden
 */

public class QueryBuilderUtils
{
 	public static final int SAVE_STEPS = 0;
 	public static final int SAVE_MEMBERS = 1;
        
    private static String m_strNAttributeValueSQL = 
                    "declare \n" +
                    "v_hier_name all_olap2_dim_level_attr_maps.hierarchy_name%type := null; \n"+
                    "v_dim_name all_olap2_dim_level_attr_maps.dimension_name%type := null; \n"+
                    "v_attr_name all_olap2_dim_level_attr_maps.attribute_name%type := null; \n"+                    
                    "v_sql varchar2(32000) := null; \n" +
                    "rc sys_refcursor; \n" +
                    
                    "counter integer := 0; \n" +
                    "rn integer := 0; \n"+
                    "innerrn integer := 0; \n"+
                    "v_owner varchar2(30); \n"+
                    "v_count integer := 0; \n"+
                    "begin \n" +
                        "begin \n"+
                            "select count(*) into v_count from ALL_OLAP_ALTER_SESSION \n"+
                            "where CLAUSE_TEXT ='ALTER SESSION SET \"_QUERY_COST_REWRITE\"=FALSE'; \n"+
                            "exception \n"+
                            "when others then \n"+
                            "null; \n"+
                        "end; "+
                        "if v_count > 0 then \n"+
                            "execute immediate 'alter session set \"_query_cost_rewrite\" = true'; \n"+
                        "end if; \n"+
                        "counter := 0; \n" +
                        "rn := ? ;\n"+
                        "v_owner := ? ;\n"+
                        "v_dim_name := ?; \n"+
                        "v_hier_name := ?; \n"+
                        "v_attr_name := ?; \n"+
                        "innerrn := rn * 10; \n"+
                        "if v_hier_name is not null AND length(v_hier_name) <> 0 then \n"+
                            "for i in( select distinct table_name, column_name \n" +
                                "from all_olap2_dim_level_attr_maps \n" +
                                "where owner=v_owner \n" +
                                "and dimension_name= v_dim_name \n" +
                                "and hierarchy_name=v_hier_name \n" +
                                "and attribute_name=v_attr_name) loop \n" +        
                                "counter := counter + 1; \n" +
                                "if counter <> 1 then \n" +
                                    "v_sql := v_sql || ' union select distinct ' || i.column_name || ' BIBEANSATTRSVALS from '|| v_owner ||'.'|| i.table_name ||' where lengthb(' || i.column_name || ' ) <> 0 and rownum <= '|| innerrn ; \n" +
                                "else \n" +
                                    "v_sql := 'select distinct ' || i.column_name || ' BIBEANSATTRSVALS from '|| v_owner ||'.'|| i.table_name ||' where lengthb(' || i.column_name || ' ) <> 0 and rownum <= ' || innerrn ; \n" +
                                "end if; \n" +
                            "end loop; \n" +
                            "if counter <> 0 then \n"+
                                "v_sql := 'select distinct BIBEANSATTRSVALS from ('|| v_sql || ') where rownum <= '||  rn ; \n" +
                            "end if; \n"+
                        "else \n"+
                            "for i in( select distinct table_name, column_name \n" +
                                "from all_olap2_dim_level_attr_maps \n" +
                                "where owner=v_owner \n" +
                                "and dimension_name= v_dim_name \n" +
                                "and attribute_name=v_attr_name) loop \n" +        
                                "counter := counter + 1; \n" +
                                "if counter <> 1 then \n" +
                                    "v_sql := v_sql || ' union select distinct ' || i.column_name || ' BIBEANSATTRSVALS from '|| v_owner ||'.'|| i.table_name ||' where lengthb(' || i.column_name || ' ) <> 0 and rownum <= '|| innerrn ; \n" +                    
                                "else \n" +
                                    "v_sql := 'select distinct ' || i.column_name || ' BIBEANSATTRSVALS from '|| v_owner ||'.'|| i.table_name ||' where lengthb(' || i.column_name || ' ) <> 0 and rownum <= ' || innerrn ; \n" +
                                "end if; \n" +
                            "end loop; \n" +
                            "if counter <> 0 then \n"+
                                "v_sql := 'select distinct BIBEANSATTRSVALS from ('|| v_sql || ') where rownum <= '||  rn ; \n" +
                            "end if; \n"+
                        "end if;\n"+
                        "if v_sql is not null AND length(v_sql) <> 0 then \n"+
                            "open rc for v_sql; \n" +
                        "end if; \n"+
                        "if v_count > 0 then \n"+
                            "execute immediate 'alter session set \"_query_cost_rewrite\" = false'; \n"+
                        "end if; \n"+
                        "? := rc; \n" +
                    "end; \n";

    private static String m_strGetAllAttrsSQL = 
                    "declare \n" +
                    "v_hier_name all_olap2_dim_level_attr_maps.hierarchy_name%type := null; \n"+
                    "v_dim_name all_olap2_dim_level_attr_maps.dimension_name%type := null; \n"+
                    "v_attr_name all_olap2_dim_level_attr_maps.attribute_name%type := null; \n"+                                        
                    "v_sql varchar2(32000) := null; \n" +
                    "rc sys_refcursor; \n" +
                    
                    "counter integer := 0; \n" +
                    "v_owner varchar2(30); \n"+
                    "v_count integer := 0; \n"+
                    "begin \n" +
                        "begin \n"+
                            "select count(*) into v_count from ALL_OLAP_ALTER_SESSION \n"+
                            "where CLAUSE_TEXT ='ALTER SESSION SET \"_QUERY_COST_REWRITE\"=FALSE'; \n"+
                            "exception \n"+
                            "when others then \n"+
                            "null; \n"+
                        "end; "+
                        "if v_count > 0 then \n"+
                            "execute immediate 'alter session set \"_query_cost_rewrite\" = true'; \n"+
                        "end if; \n"+
                        "counter := 0; \n" +
                        "v_owner := ? ;\n"+
                        "v_dim_name := ?; \n"+
                        "v_hier_name := ?; \n"+
                        "v_attr_name := ?; \n"+
                        "if v_hier_name is not null AND length(v_hier_name) <> 0 then \n"+                    
                            "for i in( select distinct table_name, column_name \n" +
                                "from all_olap2_dim_level_attr_maps \n" +
                                "where owner=v_owner \n" +
                                "and dimension_name= v_dim_name \n" +
                                "and hierarchy_name=v_hier_name \n" +
                                "and attribute_name=v_attr_name) loop \n" +        
                                "counter := counter + 1; \n" +
                                "if counter <> 1 then \n" +
                                    "v_sql := v_sql || ' union select distinct ' || i.column_name || ' BEANSATTRVALS from '|| v_owner ||'.'|| i.table_name  ; \n" +
                                "else \n" +
                                    "v_sql := 'select distinct ' || i.column_name || ' BEANSATTRVALS from '|| v_owner ||'.'|| i.table_name ; \n" +
                                "end if; \n" +
                            "end loop; \n" +
                            "if counter <> 0 then \n"+
                                "v_sql := 'select * from ('|| v_sql || ') order by BEANSATTRVALS '; \n" +
                            "end if;\n"+
                        "else \n"+
                            "for i in( select distinct table_name, column_name \n" +
                                "from all_olap2_dim_level_attr_maps \n" +
                                "where owner=v_owner \n" +
                                "and dimension_name= v_dim_name \n" +
                                "and attribute_name=v_attr_name) loop \n" +        
                                "counter := counter + 1; \n" +
                                "if counter <> 1 then \n" +
                                    "v_sql := v_sql || ' union select distinct ' || i.column_name || ' BEANSATTRVALS from '|| v_owner ||'.'|| i.table_name  ; \n" +
                                "else \n" +
                                    "v_sql := 'select distinct ' || i.column_name || ' BEANSATTRVALS from '|| v_owner ||'.'|| i.table_name ; \n" +
                                "end if; \n" +
                            "end loop; \n" +
                            "if counter <> 0 then \n"+                    
                                "v_sql := 'select * from ('|| v_sql || ') order by BEANSATTRVALS '; \n" +
                            "end if; \n"+
                        "end if; \n"+
                        "if v_sql is not null AND length(v_sql) <> 0 then \n"+
                            "open rc for v_sql; \n" +
                        "end if; \n"+
                        "if v_count > 0 then \n"+
                            "execute immediate 'alter session set \"_query_cost_rewrite\" = false'; \n"+
                        "end if; \n"+
                        "? := rc; \n" +
                    "end; \n";

    /**
     * Converts an array of DBObjects to an array of OLAPI IDs
     *
     * @param array of DBObjects
     * @return String array of OLAPI IDs
     *
     * @status hidden
     */
    public static String[] convertToUniqueID(MDObject[] mdObjects)  {
        String[] strUniqueIDs = null;
        if (mdObjects != null) {
            int count = mdObjects.length;
            strUniqueIDs = new String[count];
            for (int i=0; i<count; i++) {
                strUniqueIDs[i] = mdObjects[i].getUniqueID();   
            }
        }
        return strUniqueIDs;
    }
  
   /**
   * Used to save Selections
   *
   * @status hidden
   */
    // blm - Selection code moved to dvt-olap
/*  public static boolean save (Selection selection, String strPath, int intSaveType,
                                QueryContext queryContext, MetadataManager mm, ErrorHandler eh, MetadataInfo mi) {
    return save(selection, strPath, mm.getMDRoot(), intSaveType, queryContext, mm, eh, mi);  
  }*/

   /**
   * Used to save Selections
   *
   * @status hidden
   */
    // blm - Selection code moved to dvt-olap
/*  public static boolean save (Selection selection, String strName, MDFolder parent,
  													int intSaveType, QueryContext queryContext, MetadataManager mm, ErrorHandler eh, MetadataInfo mi) {
    try {
      if (intSaveType == SAVE_MEMBERS) {
        Selection tmpSelection = convertToMembers(selection, queryContext, eh);
        // Scan tmpSelection for missing level info
        tmpSelection.setMetadataInfo(mi);

        // Bind selection to folder.
        return save (tmpSelection, strName, parent, SAVE_STEPS,
                     queryContext, mm, eh, mi);
      }
      else if (intSaveType == SAVE_STEPS) {
        // Set up to scan tmpSelection for missing level info
        selection.setMetadataInfo(mi);

        // Bind selection to folder.
        parent.rebind(strName, selection);
        return true;
      }
    }

    catch(Exception e) {
      eh.error(e, "QueryBuilderUtils", "save");
    }
    return false;
  }

  public static Selection convertToMembers(Selection selection, QueryContext queryContext, ErrorHandler eh) {
    // Replace all steps with a single MemberStep.
    Selection tmpSelection = null;
    try {
      tmpSelection = (Selection)(selection.clone());
    }
    catch (CloneNotSupportedException csne) {
      eh.error(csne, QueryBuilderUtils.class.getName(), "convertToMembers");
    }

    QueryAccess qa = queryContext.createQueryAccess();
    qa.setSelection(tmpSelection);

    MemberStep ms = DataUtils.getDataAccessMembers(qa.getDataAccess(tmpSelection.getDimension()));
    if (ms == null)
      ms = new MemberStep(tmpSelection.getDimension());

    ms.setDimension(tmpSelection.getDimension());
    ms.setHierarchy(tmpSelection.getHierarchy());
    try {
      ms.setAction(Step.SELECT);
    }
    catch (InvalidStepArgException isae) {
      eh.error(isae, QueryBuilderUtils.class.getName(), "convertToMembers");
    }

    tmpSelection.removeAllSteps();
    tmpSelection.addStep(ms);
    qa.release();

    return tmpSelection;
  }
*/
    /*
     * @hidden
     */
    public static Vector getMeasureIDs(QueryAccess queryAccess) {
        if (queryAccess != null) {    
            return queryAccess.getValues(MetadataMap.METADATA_VALUE, 1000, queryAccess.getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME), null, null);
        }
        return null;
    }
    
  /**
   * Returns the measures in queryBuilder's selected queryAcess
   */
  public static MDMeasure[] getSelectedMeasures(QueryAccess selected, MetadataManagerServices mm, ErrorHandler eh) {
    if (mm == null || selected == null)
      return null;
    String dimension = selected.getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME);
    if (dimension != null) {
		  Vector vMeasureValues = selected.getValues(MetadataMap.METADATA_VALUE, 1000, dimension, null, null);
      if (vMeasureValues != null && vMeasureValues.size() > 0) {
        Vector vMeasures = new Vector();
				MDMeasure measure;
        for (int i = 0; i < vMeasureValues.size(); i++) {
          if (vMeasureValues.elementAt(i) instanceof String) {
            try {
              measure = mm.getMeasureByUniqueID((String)vMeasureValues.elementAt(i));
              if (measure != null)
                vMeasures.addElement(measure);
            }
            catch (MetadataManagerException mme) {
              eh.error(mme, QueryBuilderUtils.class.getName(), "getSelectedMeasures");
            }
          }
        }
				if (vMeasures.size() > 0) {
          MDMeasure[] measures = new MDMeasure[vMeasures.size()];
          for (int i = 0; i < vMeasures.size(); i++)
            measures[i] = (MDMeasure)vMeasures.elementAt(i);

		      return (measures);
        }
      }
    }
    return null;
  }

  /**
   * Returns the dimensions in queryBuilder's selected queryAcess
   */
  public static MDDimension[] getSelectedDimensions(QueryAccessUtilities selected, MetadataManager mm, ErrorHandler eh) {
    if (mm == null || selected == null)
      return null;
    Vector allDimensions = selected.getQueryAccess().getDimensions(LayerMetadataMap.LAYER_METADATA_NAME);
    Vector vDimensions = new Vector();
    MDDimension dimension;
    for (int i = 0; i < allDimensions.size(); i++) {
      try {
        dimension = mm.getDimensionByUniqueID((String)allDimensions.elementAt(i));
        if (dimension != null)
          vDimensions.addElement(dimension);
      }
      catch (MetadataManagerException mme) {
        eh.error(mme, QueryBuilderUtils.class.getName(), "getSelectedDimensions");
      }
    }
    if (vDimensions.size() > 0) {
      MDDimension[] dimensions = new MDDimension[vDimensions.size()];
      for (int i = 0; i < vDimensions.size(); i++)
        dimensions[i] = (MDDimension)vDimensions.elementAt(i);

      return dimensions;
    }
    return null;
  }

  /**
   * Updates the dimension member pairs in the newQDR from the old QDR,
   * keeping the members from oldQDR when they exist.
   */
  public static OlapQDR keepOldDimensionMembers(OlapQDR oldQDR, OlapQDR newQDR) {
    // If one of the QDRs is null, there is nothing to update
    if ((oldQDR == null) || (newQDR == null))
        return newQDR;

    for (Enumeration dims = newQDR.getDimensions(); dims.hasMoreElements();) {
      String dimensionID = (String)dims.nextElement();

      // Do not update the measure dimension
      if (!dimensionID.equals(newQDR.getMeasureDim())) {
        // Get the old and new members for that dimension
        OlapQDRMember newMember = (OlapQDRMember)newQDR.getDimMember(dimensionID);
        OlapQDRMember oldMember = (OlapQDRMember)oldQDR.getDimMember(dimensionID);

        // If the old member exists for that dimension, and is different from the new member,
        // keep the old member
        if ((newMember != null) && (oldMember != null) && !oldMember.equals(newMember, null)) {
          newQDR.addDimMemberPair(dimensionID, oldMember);
        }
      }
    }
    
    return (newQDR);
  }
      
    // blm - Selection code moved to dvt-olap
/*	public static DataAccess getDataAccessForAttributeListStep (String strDimension, 
  		String strHierarchy, String strAttribute, QueryAccess available, int numVals) {
  	
    Selection tmpSelection = new Selection(strDimension);
  	tmpSelection.setHierarchy(strHierarchy);

    AttributeListStep attributeListStep = new AttributeListStep(strDimension, strHierarchy, strAttribute);
    attributeListStep.setNumValues(numVals);
    tmpSelection.addStep(attributeListStep);
  	
    MetadataMap metadataMap = new MetadataMap(new String[] {MetadataMap.METADATA_VALUE});
  	return available.getDataAccess(tmpSelection, metadataMap);
  }
  */
  public static MDAttribute[] getFilteredAttributes (MDDimension dimension, ErrorHandler eh) {
    MDAttribute[] attributes = null;
    try {
	    attributes = dimension.getAttributes();
      if (attributes != null) {
        Vector vAttributes = new Vector();
        for (int i=0; i<attributes.length; i++) {
          if ( (attributes[i].getStrPropertyValue(MM.DATA_TYPE).equals(MM.STRING)) &&
               (!MM.HIDE_ALWAYS.equals(attributes[i].getStrPropertyValue(MM.HIDDEN))) ) {
              vAttributes.addElement(attributes[i]);
          }
	      }
    
      attributes = (MDAttribute[])Utility.copyVectorToArray(vAttributes);
  	  }
    }
    
    catch(MetadataManagerException e) {
    	eh.error(e, "QueryBuilderUtils", "getFilteredAttributes");
    }
    
    return attributes;
  }

    // Determines whether the given data types are compatible with each other.
    public static boolean areCompatibleDataTypes(String strDataType1, String strDataType2) {
        if ( (strDataType1 != null) && (strDataType2 != null) ) {
            return ( ( strDataType1.equals(MM.BOOLEAN) && strDataType2.equals(MM.BOOLEAN) ) ||
                     ( strDataType1.equals(MM.DATE) && strDataType2.equals(MM.DATE) ) || 
                     ( strDataType1.equals(MM.STRING) && strDataType2.equals(MM.STRING) ) ||
                     ( isNumeric(strDataType1) && isNumeric(strDataType2) ) );
        }
        return false;
    }
  
  public static Vector getFilteredMeasures(MetadataManagerServices metadataManager, Vector baseMeasures,
                                           String dimension, String[] dataTypes, int maxCount, ErrorHandler eh) {
    MeasureFilter filter = new MeasureFilter(metadataManager, dimension);
    filter.setBaseMeasures(baseMeasures);
    filter.setDataTypes(dataTypes);
    filter.setCountLimit(maxCount);
    filter.setDriverType(MM.MDM);
    filter.setIncludeShortCuts(false);
    if ((baseMeasures == null) || (baseMeasures.size() == 0))
      filter.setIntersectionBaseMeasuresFilter(MeasureFilter.DIMENSIONALITY_IGNORE);
    else
      filter.setIntersectionBaseMeasuresFilter (~MeasureFilter.DIMENSIONALITY_DISJOINT);
    try {
      return filter.getObjects();
    }
    catch (MetadataManagerException mme) {
      eh.error(mme, QueryBuilderUtils.class.getName(), "getFilteredMeasures");
    }
    catch (NamingException ne) {
      eh.error(ne, QueryBuilderUtils.class.getName(), "getFilteredMeasures");
    }
    return null;
  }


  public static Vector getComparisonMeasures(Vector mdMeasures, String[] dataTypes) {
    if (mdMeasures == null || mdMeasures.size() == 0)
      return null;

    Vector comparisonMeasures = new Vector();

    Vector vDataTypes = new Vector();
    if (dataTypes != null) {
      for (int i = 0; i < dataTypes.length; i++) {
        if (!MM.STRING.equals(dataTypes[i])) {
          vDataTypes.add(dataTypes[i]);
        }
      }
    }
    else {
      vDataTypes.add(MM.BOOLEAN);
      vDataTypes.add(MM.DATE);
      vDataTypes.add(MM.INTEGER);
      vDataTypes.add(MM.SHORT);
      vDataTypes.add(MM.FLOAT);
      vDataTypes.add(MM.DOUBLE);
      vDataTypes.add(MM.LONG);
    }

    MDMeasure numericMeasure = null;
    MDMeasure booleanMeasure = null;
    MDMeasure dateMeasure = null;
    MDMeasure preferredMeasure = null;
    String strPreferredDataType = null;
    MDMeasure measure = null;
    String strDataType = null;
    for (int i = 0; i < mdMeasures.size(); i++) {
      measure = (MDMeasure)mdMeasures.get(i);
      strDataType = measure.getDataType();
      if (vDataTypes.contains(strDataType)) {
        if (preferredMeasure == null) {
          preferredMeasure = measure;
          strPreferredDataType = strDataType;
        }
        else {
          if (areCompatibleDataTypes(strDataType, strPreferredDataType)) {
            if (!measure.getUniqueID().equals(preferredMeasure.getUniqueID())) {
              comparisonMeasures = new Vector();
              comparisonMeasures.add(preferredMeasure);
              comparisonMeasures.add(measure);
              break;
            }
          }
          else if (comparisonMeasures.size() < 2) {
            if (strDataType.equals(MM.BOOLEAN)) {
              if (booleanMeasure == null) {
                booleanMeasure = measure;
              }
              else if (!booleanMeasure.getUniqueID().equals(measure.getUniqueID())) {
                comparisonMeasures.addElement(booleanMeasure);
                comparisonMeasures.addElement(measure);
              }
            }
            else if (strDataType.equals(MM.DATE)) {
              if (dateMeasure == null) {
                dateMeasure = measure;
              }
              else if (!dateMeasure.getUniqueID().equals(measure.getUniqueID())) {
                comparisonMeasures.addElement(dateMeasure);
                comparisonMeasures.addElement(measure);
              }    
            }
            else if (isNumeric(strDataType)) {
              if (numericMeasure == null) {
                numericMeasure = measure;
              }
              else if (!numericMeasure.getUniqueID().equals(measure.getUniqueID())) {
                comparisonMeasures.addElement(numericMeasure);
                comparisonMeasures.addElement(measure);
              } 
            }
          }
        }
      }
    }
    if (comparisonMeasures.size() == 2) {
      return comparisonMeasures;
    }
    if (preferredMeasure != null) {
      comparisonMeasures = new Vector();
      comparisonMeasures.add(preferredMeasure);
      comparisonMeasures.add(preferredMeasure);
      return comparisonMeasures;
    }
    return null;
  }

  public static MDMeasure getComparisonMeasure(Vector mdMeasures, String measure) {
    if (mdMeasures == null || mdMeasures.size() == 0 || measure == null)
      return null;
    MDMeasure mdMeasure = null;
    for (int i = 0; i < mdMeasures.size(); i++) {
      mdMeasure = (MDMeasure)mdMeasures.get(i);
      if (!measure.equals(mdMeasure.getUniqueID())) {
        return mdMeasure;
      }
    }
    return (MDMeasure)mdMeasures.elementAt(0);
  }

  public static Vector filterMeasures (MetadataManagerServices metadataManagerServices, 
  																			Vector measures, String strDimension, String strDataType, ErrorHandler errorHandler) {
    Vector filteredMeasures = new Vector();
    if ((metadataManagerServices != null) && (measures != null) && (errorHandler != null) ) {
      Object object;
      MDMeasure mdMeasure = null;
      String strMeasure;

      for (Enumeration e=measures.elements(); e.hasMoreElements();) {
        object = e.nextElement();
        if ( (object instanceof DimensionMember) || (object instanceof MDMeasure) ) {
          if (object instanceof DimensionMember) {
            try {
              mdMeasure = metadataManagerServices.getMeasure(MM.UNIQUE_ID, ((DimensionMember)object).getDimMemberID());
            }
            catch (MetadataManagerException mme) {
              errorHandler.error(mme, QueryBuilderUtils.class.getName(), "filterMeasures");
            }
          }
          else {
            mdMeasure = (MDMeasure)object;
          }
          if (mdMeasure != null) {
            if ( ( (strDimension == null) || (DataUtils.isDimensionedBy(metadataManagerServices, mdMeasure.getUniqueID(), strDimension)) ) &&
                 ( (strDataType == null) || (areCompatibleDataTypes(mdMeasure.getDataType(), strDataType)) ) &&
                 ( !MM.HIDE_ALWAYS.equals(mdMeasure.getStrPropertyValue(MM.HIDDEN)))) {
              filteredMeasures.addElement(object);
            }
	        }
        }
        else {
            filteredMeasures.addElement(object);
        }
      }
    }
    return filteredMeasures;
  }
  
  public static MDMeasure[] filterMeasures(MetadataManagerServices metadataManagerServices, 
  																	MDMeasure[] measures, String strDimension, String strDataType, ErrorHandler errorHandler) {
    return ((MDMeasure[])Utility.copyVectorToArray(filterMeasures(metadataManagerServices, 
    	Utility.copyArrayToVector(measures), strDimension, strDataType, errorHandler)));
  }
/*
  public static void updateEditor(QueryBuilder queryBuilder, HyperLinkCombo editor,
                                  String strDimension, String strHierarchy) {
    editor.restoreSilently();

    // Bring up the DimensionListDialog.
    QueryAccessUtilities qau =
      new QueryAccessUtilities(queryBuilder.getQueryContext().createQueryAccess(),
        null, queryBuilder.getErrorHandler());
            
    QueryAccessDimensionModel qadm = 
      new QueryAccessDimensionModel(qau, strDimension, strHierarchy, 
        queryBuilder.getMetadataManager());
    
    DimensionListDialog dlg;
    if (queryBuilder.getContainer() instanceof Dialog) {
      dlg = new DimensionListDialog((Dialog)queryBuilder.getContainer(), qadm, editor, true);
    }
    else if (queryBuilder.getContainer() instanceof Frame) {
      dlg = new DimensionListDialog((Frame)queryBuilder.getContainer(), qadm, editor, true);
    }
    else {
      dlg = new DimensionListDialog((Frame)null, qadm, editor, true);
    }

    dlg.setHelpProvider(queryBuilder.getHelpProvider());
    dlg.setLocale(queryBuilder.getLocale());
    // dlg.getDimensionListPanel().getDimensionList().setModel(qadm);
    dlg.getDimensionListPanel().setLabelType(queryBuilder.getDisplayMemberLabelType());
    dlg.getDimensionListPanel().getHierLevelComponent().setDisplayLabelType(queryBuilder.getDisplayLabelType());
    
    if (dlg.display() == DimensionListDialog.OK) {
      // Get the selected member from the DimensionListDialog.
      String strSelectedMember = 
          dlg.getSelectedMemberUsingDataAccess(qadm.getDataAccess());

      if (strSelectedMember != null) {
        DimensionMember dimValue = 
          queryBuilder.m_qautil.getDimMember(queryBuilder.getAvailableQueryAccess(), 
            strDimension, strHierarchy, strSelectedMember, queryBuilder.getDisplayMemberLabelType());
        
        if (dimValue != null) {
          // Check if this object already exists in the editor.
          if (!QueryBuilderUtils.contains(editor, dimValue)) {
            // Insert this DimensionMember at the beginning of the list of items
            // in the editor (i.e. the JComboBox).
            editor.insertItemAt(dimValue, 0);
          }
              
          // Select this item.
          editor.setSelectedIndex(Utils.indexOf(editor, dimValue));
          }
        }
      }
  	else {
  		editor.restore();
  	}
      
  qau.getQueryAccess().release();
  }
*/
        
    private static Vector getDimensionIDs(MDMeasure[] mdMeasures, ErrorHandler errorHandler) {
        if (mdMeasures != null) {
            Vector dimensionIDs = new Vector();
            MDDimension[] mdDimensions = null;
            String strDimensionID;
            for (int i=0; i<mdMeasures.length; i++) {
                try {
                    mdDimensions = mdMeasures[i].getDimensions();
                }
                catch (MetadataManagerException mme) {
                    errorHandler.error(mme, QueryBuilderUtils.class.getName(), "getDimensionIDs");
                }
                if (mdDimensions != null) {
                    for (int j=0; j<mdDimensions.length; j++) {
                        strDimensionID = mdDimensions[j].getUniqueID();
                        if ( (strDimensionID != null) && (!dimensionIDs.contains(strDimensionID)) ) {
                            dimensionIDs.addElement(strDimensionID);
                        }
                    }
                }
            }
            return dimensionIDs;
        }
        return null;
    }
    
    private static void merge(Vector v1, Vector v2) {
        if ( (v1 != null) && (v2 != null) ) {
            Object o;
            for (Enumeration e=v2.elements(); e.hasMoreElements(); ) {
                o = e.nextElement();
                if ( (o != null) && (!v1.contains(o)) ) {
                    v1.addElement(o);
                }
            }
        }
    }
    
    private static boolean _isJoinPath(Vector v) {
        boolean blnJoinPath = false;
        if ( (v != null) && (!v.isEmpty()) ) {
            Vector v1 = new Vector();
            Vector remaining = (Vector)v.clone();
            Object o1 = remaining.firstElement();
            if ( (o1 != null) && (o1 instanceof Vector) ) {
                Vector union = (Vector)((Vector)o1).clone();
                Object o2;
                Vector v2;
                int intBeforeSize = remaining.size() + 1;
                while (remaining.size() < intBeforeSize) {
                    intBeforeSize = remaining.size();
                    for (int i=remaining.size()-1; i>=0; i--) {
                        o2 = remaining.elementAt(i); 
                        if ( (o2 != null) && (o2 instanceof Vector) ) {
                            v2 = (Vector)o2;
                            if (SetUtils.hasIntersection(SetUtils.compareSets(union, v2, null))) {
                                merge(union, v2);
                                remaining.removeElement(o2);
                            }
                        }
                    }
                }
            }
            blnJoinPath = remaining.isEmpty();
        }
        return blnJoinPath;
    }

    public static boolean isJoinPath(MDMeasure[] measures, ErrorHandler errorHandler) {    
        if (measures != null) {
            try {
                Vector measureDimensionIDs = new Vector();
                for (int i=0; i<measures.length; i++) {
                    measureDimensionIDs.addElement(Utility.copyArrayToVector(convertToUniqueID(measures[i].getDimensions())));
                }
                return _isJoinPath(measureDimensionIDs);
            }
            catch (MetadataManagerException mme) {
                errorHandler.error(mme, QueryBuilderUtils.class.getName(), "areDimensionsRelated");
            }
        }
        return true;
    }

	public static boolean areDimensionsRelated(MDMeasure[] measures, MDDimension[] dimensions, boolean checkJoinPath, ErrorHandler errorHandler) {
        // Check if the intersection of the union of the measures with the dimensions is empty.
        Vector measureDimensionIDs = getDimensionIDs(measures, errorHandler);
        Vector dimensionIDs = Utility.copyArrayToVector(convertToUniqueID(dimensions));
        if (!SetUtils.hasIntersection(SetUtils.compareSets(measureDimensionIDs, dimensionIDs, null))) {
            return false;
        }
        if (checkJoinPath) {
          // Check if a "join path" of shared dimensionality between the measures exists.
          return isJoinPath(measures, errorHandler);
        }
        return true;
	}

  public static MDDimension[] getUnrelatedDimensions(MDMeasure[] measures, MDDimension[] dimensions, ErrorHandler eh) {
		if ((measures == null) || (measures.length == 0) ||
        (dimensions == null) || (dimensions.length == 0))
			return dimensions;

    Vector dims = new Vector();
		for (int i=0; i<dimensions.length; i++) {
      boolean contained = false;
			for (int j=0; j<measures.length; j++) {
				try {
          if (MMUtilities._contains(measures[j].getDimensions(), dimensions[i])) {
            contained = true;
            break;
					}
				}
				catch (MetadataManagerException mme) {
					eh.error(mme, QueryBuilderUtils.class.getName(), "getUnrelatedDimensions");
				}
			}
      if (!contained)
        dims.addElement(dimensions[i]);
		}
    if (dims.size() == 0)
      return null;

    MDDimension[] mdDims = new MDDimension[dims.size()];
    for (int i = 0; i < dims.size(); i++)
      mdDims[i] = (MDDimension)dims.elementAt(i);
    return mdDims;
  }

  public static MDDimension[] getOrphanedDimensions(MDMeasure[] measToRemove, MDMeasure[] measToKeep, MetadataManager mm, ErrorHandler eh) {
    Vector measToRemoveDims = new Vector();
    Vector measToKeepDims = new Vector();
    try {
      measToRemoveDims = Utility.copyArrayToVector(mm.dimensionalityOfMeasures(measToRemove, MM.UNION));
      measToKeepDims = Utility.copyArrayToVector(mm.dimensionalityOfMeasures(measToKeep, MM.UNION));
    }
    catch (MetadataManagerException mme) {
      eh.error(mme, QueryBuilderUtils.class.getName(), "getOrphanedDimensions");
    }
    Vector dimsToRemove = new Vector();

    for (int i = 0; i < measToRemoveDims.size(); i++) {
      if (!(measToKeepDims.contains(measToRemoveDims.elementAt(i)))) {
        dimsToRemove.addElement(measToRemoveDims.elementAt(i));
      }
    }
      
    return (MDDimension[])dimsToRemove.toArray(new MDDimension[dimsToRemove.size()]);
  }
  
  /**
   * @hidden
   */
   // blm - Selection code moved to dvt-olap
/*  public static Selection addDefaultStep(Selection sel, String dimension, MetadataManager mm, ErrorHandler eh) {
    if (sel == null) {
      sel = new Selection(dimension);
    }
    try {
      MDDimension mdDim = mm.getDimensionByUniqueID(dimension);
      MDHierarchy mdHier = null;
      if (sel.getHierarchy() == null)
        mdHier = mdDim.getDefaultHierarchy();
      else
        mdHier = mm.getHierarchyByUniqueID(sel.getHierarchy());
      MDLevel[] mdLev = null;
      if (mdHier != null) {
        mdLev = mdHier.getLevels();
      }
      if ( (mdHier == null) || (mdLev == null) ) {
        if (mdHier == null)
        {
            // Create First/Last Step
            FirstLastStep fls = new FirstLastStep(dimension, null, null, FirstLastStep.FIRST, new Integer(1));
            fls.setAction((sel.getStepCount() > 0) ? Step.ADD : Step.SELECT);
            sel.addStep(fls);
        }
        else
        {
            // we have a hierarchy, but no levels
            FamilyStep fs = new FamilyStep(dimension, mdHier.getUniqueID(), FamilyStep.OP_FIRSTANCESTORS, null, false);
            sel.addStep(fs);
        }
      }
      else {
        // Create AllStep
        Vector levels = new Vector();
        levels.addElement(mdLev[0].getUniqueID());
        AllStep as = new AllStep(dimension, mdHier.getUniqueID(), levels);
        as.setAction((sel.getStepCount() > 0) ? Step.ADD : Step.SELECT);
        sel.setHierarchy(mdHier.getUniqueID());
        sel.addStep(as);
      }
    }
    catch (Exception e) {
      eh.error(e, QueryBuilderUtils.class.getName(), "addDefaultStep");
    }
    if (sel.getStepCount() == 1)
        sel.setFirstStepDefault(true);    
    return sel;
  }
*/
  /*
   * Returns whether or not the given data type is numeric.
   *  
   * @param strDataType The data type.
   * @hidden
   */
    public static boolean isNumeric(String strDataType) {
        return ( (MM.INTEGER.equals(strDataType)) ||
                 (MM.SHORT.equals(strDataType)) ||
                 (MM.FLOAT.equals(strDataType)) ||
                 (MM.DOUBLE.equals(strDataType)) ||
                 (MM.LONG.equals(strDataType)) );
  }
  
  /**
   *  Returns a default int used in setting the comparison operator
   *  for a MeasValStep based upon the given datatype.
   *  
   *  @param strDataType The data type.
   *  @param twoMeas Indicates whether constants should come from TwoMeasNumStep or MeasValStep
   *  @hidden
   */
   // blm - Selection code moved to dvt-olap
/*  public static int getDefaultOperator(String strDataType, boolean twoMeas) {
    if (strDataType != null) {
      if (strDataType.equals(MM.BOOLEAN)) {
        return twoMeas ? TwoMeasNumStep.OP_EQUAL : MeasValStep.OP_EQUAL;
      }
      else if (strDataType.equals(MM.DATE)) {
        return twoMeas ? TwoMeasNumStep.OP_LESS : MeasValStep.OP_LESS;
      }
      else if (strDataType.equals(MM.STRING)) {
        return twoMeas ? -1 : MeasValStep.OP_CONTAINS;
      }
      else if (isNumeric(strDataType)) {
        return twoMeas ? TwoMeasNumStep.OP_GREATER : MeasValStep.OP_GREATER;
      }
    }
    return -1;  
  }

  public static int[] getOperators(String dataType, boolean twoMeas) {
    if (dataType != null) {
      if (dataType.equals(MM.BOOLEAN)) {
        return twoMeas ? m_twoMeasBool : m_measBool;
      }
      else if (dataType.equals(MM.DATE)) {
        return twoMeas ? m_twoMeasDate : m_measDate;
      }
      else if (dataType.equals(MM.STRING)) {
        return twoMeas ? m_twoMeasString : m_measString;
      }
      else if (isNumeric(dataType)) {
        return twoMeas ? m_twoMeasNum : m_measNum;
      }
    }
    return null;
  }*/

     // Return a Vector containing the unique ids of all the measures in the MetadataManager.
    public static Vector getMeasures(MetadataManager metadataManager, ErrorHandler errorHandler) {
        Vector measures = new Vector();
        if  ( (metadataManager != null) && (errorHandler != null) ) {
            try {
                MDMeasure[] mdMeasures = metadataManager.getMeasures();
                measures = Utility.copyArrayToVector(mdMeasures);
            }
            catch (MetadataManagerException e) {
                errorHandler.error(e, "QueryBuilderUtils", "getMeasures");
            }
        }
        return measures;
    }

    // Get all the measures in the given QueryAccessUtilities and MetadataManager, in that order.
    public static Vector getAllMeasures(QueryAccessUtilities queryAccessUtilities, MetadataManager metadataManager, ErrorHandler errorHandler) {
        Vector measures = new Vector();
        if ( (queryAccessUtilities != null) && (metadataManager != null) && (errorHandler != null) ) {
            // Get all the measures from the QueryAccess.
            String strMeasureDimensionID = queryAccessUtilities.getQueryAccess().getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME);
            Vector measureDimensionMeasures = queryAccessUtilities.getValues(strMeasureDimensionID, null,  -1, metadataManager);
            if (measureDimensionMeasures != null) {
                for (int i=0; i<measureDimensionMeasures.size(); i++) {
                    measures.addElement(getMeasure(metadataManager, measureDimensionMeasures.elementAt(i), errorHandler));
                }
            }
            // Add all the measures from the MetadataManager.
            Vector metadataManagerMeasures = getMeasures(metadataManager, errorHandler);
            if (metadataManagerMeasures != null) {
                for (int i=0; i<metadataManagerMeasures.size(); i++) {
                    if (!measures.contains(metadataManagerMeasures.elementAt(i))) {
                        measures.addElement(metadataManagerMeasures.elementAt(i));
                    }
                }
            }
        }
        return measures;
    }
    
    // blm - Selection code moved to dvt-olap
/*    public static Vector validateLayout(QueryAccessUtilities qau, Step step) {
        Vector dimensions = new Vector();
        String strError = null;
        if ( (qau != null) && (step != null) ) {
            Vector dims = qau.getQueryAccess().getDimensions(LayerMetadataMap.LAYER_METADATA_NAME);
            Vector sels = new Vector();
            boolean asymmetric = false;
            Selection selection;
            for (int i = 0; i < dims.size(); i++) {
                selection = qau.getQueryAccess().getSelection((String)dims.elementAt(i));
                if (selection.getDimension().equals(step.getDimension())) {
                    selection.addStep(step);
                }
                if (selection != null && selection.isAsymmetric()) {
                    asymmetric = true;
                }
                sels.addElement(selection);
            }
            if (asymmetric) {    
                // Make space
                Vector layout = new Vector();
                for (int i = 0; i < 4; i++) {
                    layout.addElement(new Vector());
                    for (int j = 0; j < dims.size(); j++) {
                        ((Vector)layout.elementAt(i)).addElement(null);
                    }
                }
        
                // Fill in dims
                for (int i = 0; i < dims.size(); i++) {
                    String dim = (String)dims.elementAt(i);
                    int edge = qau.getDimEdge(dim);
                    int layer = qau.getDimLayer(dim, edge);
                    ((Vector)layout.elementAt(edge)).setElementAt(dim, layer);
                }
        
                // Validate (based on asymmetric QDRs)
                for (int i = 0; i < dims.size(); i++) {
                    Selection sel = (Selection)sels.elementAt(i);
                    if (sel != null) {
                        Vector depDims = sel.getDependentDimensions();
                        if (depDims != null && depDims.size() > 0) {
                            // Find driven
                            String driven = (String)dims.elementAt(i);
                            int drivenEdge = -1;
                            int drivenLayer = -1;
                            for (int k = 0; k < 3; k++) {
                                if (((Vector)layout.elementAt(k)).contains(driven)) {
                                    drivenEdge = k;
                                    drivenLayer = ((Vector)layout.elementAt(k)).indexOf(driven);
                                    break;
                                }
                            }
                            for (int j = 0; j < depDims.size(); j++) {
                                // Find driver
                                String driver = (String)depDims.elementAt(j);
                                int driverEdge = -1;
                                int driverLayer = -1;
                                for (int k = 0; k < 3; k++) {
                                    if (((Vector)layout.elementAt(k)).contains(driver)) {
                                        driverEdge = k;
                                        driverLayer = ((Vector)layout.elementAt(k)).indexOf(driver);
                                        break;
                                    }
                                }
                                if ((drivenEdge != driverEdge && driverEdge != DataDirector.PAGE_EDGE) || 
                                    (drivenEdge == driverEdge && drivenLayer < driverLayer)) {
                                    // Bad layout
                                    dimensions.addElement(driver);
                                }
                            }
                        }
                    }
                }
            }
            if (!dimensions.isEmpty()) {
                dimensions.addElement(step.getDimension());
            }
        }
        return dimensions;
    }
        
    public static boolean validateQuery(QueryAccessUtilities qau) {
        if (qau != null) {
            Vector dims = qau.getQueryAccess().getDimensions(LayerMetadataMap.LAYER_METADATA_NAME);
            Vector sels = new Vector();
            boolean asymmetric = false;
            for (int i = 0; i < dims.size(); i++) {
                Selection sel = qau.getQueryAccess().getSelection((String)dims.elementAt(i));
                if (sel != null && sel.isAsymmetric()) {
                    asymmetric = true;
                }
                sels.addElement(qau.getQueryAccess().getSelection((String)dims.elementAt(i)));
            }
            if (!asymmetric) {
                return true;
            }
    
            // Make space
            Vector layout = new Vector();
            for (int i = 0; i < 4; i++) {
                layout.addElement(new Vector());
                for (int j = 0; j < dims.size(); j++) {
                    ((Vector)layout.elementAt(i)).addElement(null);
                }
            }
    
            // Fill in dims
            for (int i = 0; i < dims.size(); i++) {
                String dim = (String)dims.elementAt(i);
                int edge = qau.getDimEdge(dim);
                int layer = qau.getDimLayer(dim, edge);
                ((Vector)layout.elementAt(edge)).setElementAt(dim, layer);
            }
    
            // Validate (based on asymmetric QDRs)
            for (int i = 0; i < dims.size(); i++) {
                Selection sel = (Selection)sels.elementAt(i);
                if (sel != null) {
                    Vector depDims = sel.getDependentDimensions();
                    if (depDims != null && depDims.size() > 0) {
                        // Find driven
                        String driven = (String)dims.elementAt(i);
                        int drivenEdge = -1;
                        int drivenLayer = -1;
                        for (int k = 0; k < 3; k++) {
                            if (((Vector)layout.elementAt(k)).contains(driven)) {
                                drivenEdge = k;
                                drivenLayer = ((Vector)layout.elementAt(k)).indexOf(driven);
                                break;
                            }
                        }
                        for (int j = 0; j < depDims.size(); j++) {
                            // Find driver
                            String driver = (String)depDims.elementAt(j);
                            int driverEdge = -1;
                            int driverLayer = -1;
                            for (int k = 0; k < 3; k++) {
                                if (((Vector)layout.elementAt(k)).contains(driver)) {
                                    driverEdge = k;
                                    driverLayer = ((Vector)layout.elementAt(k)).indexOf(driver);
                                    break;
                                }
                            }
                            if ((drivenEdge != driverEdge && driverEdge != DataDirector.PAGE_EDGE) || 
                                (drivenEdge == driverEdge && drivenLayer < driverLayer)) {
                                // Bad layout
                                return false;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    private static boolean isValid(MDMeasure[] measures, Selection selection, String[] dimHier) {
        if (selection != null) {
            String strHierarchyID = QueryBuilderUtils.getDefaultValidationHierarchyID(measures, selection.getDimension());
            if ( (strHierarchyID != null) && (selection.getHierarchy() != null) ) {
                if (!strHierarchyID.equals(selection.getHierarchy())) {
                    if (dimHier != null && dimHier.length == 2) {
                      dimHier[0] = selection.getDimension();
                      dimHier[1] = strHierarchyID;
                    }
                    return false;
                }
                
            }
        }
        if (dimHier != null && dimHier.length == 2) {
          dimHier[0] = null;
          dimHier[1] = null;
        }
        return true;
    }
    
    public static boolean isValid(MDMeasure[] measures, Hashtable selections) {
      return isValid(measures, selections, null);
    }
    
    public static boolean isValid(MDMeasure[] measures, Hashtable selections, String[] dimHier) {
        boolean blnValid = true;
        if ( (measures != null) && (selections != null) ) {
            Object object;
            for (Enumeration e=selections.elements(); e.hasMoreElements(); ) {
                object = e.nextElement();
                if ( (object != null) && (object instanceof Selection) ) {
                    blnValid = isValid(measures, (Selection)object, dimHier);                    
                    if (!blnValid) {
                        return false;
                    }
                }
            }
        }
        return blnValid;
    }
*/
    /*
     * Returns a hashtable containing all the Selections for the given QueryAccess.
     */
    // blm - Selection code moved to dvt-olap
/*    public static Hashtable getSelections(QueryAccess queryAccess) {
        Hashtable selections = new Hashtable();
        if (queryAccess != null) {
            Vector dimensions = queryAccess.getDimensions(LayerMetadataMap.LAYER_METADATA_NAME);
            if (dimensions != null) {
                Selection selection;
                for (Enumeration e=dimensions.elements(); e.hasMoreElements(); ) {
                    selection = queryAccess.getSelection(e.nextElement().toString());
                    if (selection != null) {
                        selections.put(selection.getDimension(), selection);
                    }
                }
            }
        }
        return selections;        
    }
*/
    /**
     * Applies a Hashtable of Selections to the given QueryAccess
     */
     // blm - Selection code moved to dvt-olap
/*    public static void applySelections(Hashtable selections, QueryAccess queryAccess) {
      if (selections != null && queryAccess != null) {
        for (Enumeration e = selections.elements(); e.hasMoreElements(); ) {
          queryAccess.setSelection((Selection)e.nextElement());
        }
      }
    }*/
    


    /*
     * Returns a vector containing all the Steps for the given Selection array.
     */
    // blm - Selection code moved to dvt-olap
/*    private static Vector getSteps(Hashtable selections, String strIgnoreDimensionID) {
        Vector steps = new Vector();
        if (selections != null) {
            Selection selection;
            SortSpec sortSpec;
            for (Enumeration e=selections.elements(); e.hasMoreElements(); ) {
                selection = (Selection)e.nextElement();
                if ( (strIgnoreDimensionID == null) || ( (strIgnoreDimensionID != null) && (!strIgnoreDimensionID.equals(selection.getDimension())) ) ) {
                    for (int i=0; i<selection.getStepCount(); i++) { 
                        steps.addElement(selection.getStep(i));
                    }
                }
                sortSpec = selection.getSortSpec();
                if (sortSpec != null) {
                    int stepCount = sortSpec.getConditionSortStepCount();
                    for (int i=0; i<stepCount; i++) {
                        steps.addElement(sortSpec.getConditionSortStepAt(i));
                    }
                }
            }
        }
        return steps;
    }
    
    private static String[] getErrorCodes(Selection selection, Step step, MetadataManagerServices mm) {
        Vector errorCodes = new Vector();
        if (step != null) {
            if (selection != null) {
                String strSelectionDimension = selection.getDimension();
                String strSelectionHierarchy = selection.getHierarchy();
                String strStepDimension = (String)step.getValidationProperty(ValidationProperties.DIMENSION);
                String strStepHierarchy = (String)step.getValidationProperty(ValidationProperties.HIERARCHY);
                if ( (strStepDimension != null) && (strStepHierarchy != null) ) {
                    if (strStepDimension.equals(strSelectionDimension)) {
                        if (!strStepHierarchy.equals(strSelectionHierarchy)) {
                            errorCodes.add(ValidationProperties.HIERARCHY);
                        }
                    }
                }
            }
            if (step instanceof ConditionStep) {
                if (!Utils.areLevelsValidForHierarchy(mm, (ConditionStep)step)) {
                    errorCodes.add(ValidationProperties.LEVEL);
                }
            }
        }
        return (String[])Utility.copyVectorToArray(errorCodes);
    }

    private static boolean isValid(Selection selection, Step step, MetadataManagerServices mm) {
        return (getErrorCodes(selection, step, mm) == null);
    }
        
    public static boolean isValid(Hashtable selections, Step step, String[][] layout, MetadataManagerServices mm) {
        return (getErrorCodes(selections, step, layout, mm) == null);
    }
    
    private static String[] getErrorCodes(Hashtable selections, Step step, String[][] layout, MetadataManagerServices mm) {
        Vector errorCodes = new Vector();
        String[] errors;
        if (layout != null) {
          errors = getErrorCodes(step, layout);
          if (errors != null) {
            for (int i = 0; i < errors.length; i++) {
              errorCodes.addElement(errors[i]);
            }
          }
        }
        if (selections != null) {
            Object object;
            for (Enumeration e=selections.elements(); e.hasMoreElements(); ) {
                object = e.nextElement();            
                if ( (object != null) && (object instanceof Selection) ) {
                    errors = getErrorCodes((Selection)object, step, mm);
                    if (errors != null) {
                        for (int i=0; i<errors.length; i++) {
                            if (!errorCodes.contains(errors[i])) {
                                errorCodes.addElement(errors[i]);
                            }
                        }
                    }
                }
            }
        }
        return (String[])Utility.copyVectorToArray(errorCodes);
    }
*/
    private static int[] getEdgeAndLayer(String dimension, String[][] layout) {
      if (dimension != null && layout != null) {
        for (int edge = 0; edge < layout.length; edge++) {
          if (layout[edge] != null) {
            for (int layer = 0; layer < layout[edge].length; layer++) {
              if (dimension.equals(layout[edge][layer])) {
                return new int[] {edge, layer};
              }
            }
          }
        }
      }
      return null;
    }

    // blm - Selection code moved to dvt-olap
/*
    private static String[] getErrorCodes(Step step, String[][] layout) {
      if (step != null && layout != null) {
        String drivenDim = step.getDimension();
        int[] driven = getEdgeAndLayer(drivenDim, layout);
        if (driven != null) {
          String[] dims = (String[])step.getValidationProperty(ValidationProperties.DEPENDENT_DIMENSIONS);
          if (dims != null) {
            for (int i = 0; i < dims.length; i++) {
              String driverDim = dims[i];
              int[] driver = getEdgeAndLayer(driverDim, layout);
              if (driver != null) {
                boolean valid = (driver[0] == DataDirector.PAGE_EDGE && driven[0] < driver[0]) ||
                                (driver[0] == driven[0] && driven[1] > driver[1]);
                if (!valid) {
                  return new String[] {ValidationProperties.DEPENDENT_DIMENSIONS};
                }
              }
            }
          }
        }
      }
      return null;
    }
    
    private static String[] getErrorCodes(Hashtable selections, Step step, String[][] layout, boolean blnCheckEnabled, MetadataManagerServices mm, ErrorHandler eh) {
        Vector errors = new Vector();
        if ( (step != null) && ( (!blnCheckEnabled) || (blnCheckEnabled && step.isEnabled()) ) ) {
            String[] errorCodes = getErrorCodes(selections, step, layout, mm);
            if (errorCodes != null) {
                for (int i=0; i<errorCodes.length; i++) {
                    errors.addElement(errorCodes[i]);
                }
            }
  
        }
        return (String[])Utility.copyVectorToArray(errors);
    }
    
    private static boolean isValid(Hashtable selections, Step step, String[][] layout, boolean blnCheckEnabled, MetadataManagerServices mm, ErrorHandler eh) {
        return (getErrorCodes(selections, step, layout, blnCheckEnabled, mm, eh) == null);
    }
  */  
    public static String getDefaultValidationHierarchyID(MDMeasure[] measures, String strDimensionID) {
        return null;
    }

    // blm - Selection code moved to dvt-olap
/*               
    public static boolean isValid(QueryAccess queryAccess, Selection testSelection, String[][] layout, MetadataManagerServices mm, ErrorHandler eh) {
        Hashtable selections = QueryBuilderUtils.getSelections(queryAccess);
        String strIgnoreDimensionID = null;
        if (testSelection != null) {
            if (selections != null) {    
                selections.put(testSelection.getDimension(), testSelection);
            }
            strIgnoreDimensionID = testSelection.getDimension();
        }
        MDMeasure[] measures = QueryBuilderUtils.getSelectedMeasures(queryAccess, mm, eh);
        if (!QueryBuilderUtils.isValid(measures, selections)) {
            return false;
        }
        Vector steps = getSteps(selections, strIgnoreDimensionID);
        if (steps != null) {
            Object object;
            for (Enumeration e=steps.elements(); e.hasMoreElements(); ) {
                object = e.nextElement();
                if ( (object != null) && (object instanceof Step) ) {
                    if (!isValid(selections, (Step)object, layout, true, mm, eh)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public static boolean validateSteps(Hashtable selections, String[][] layout, MetadataManagerServices mm, ErrorHandler eh) {
        boolean blnNewInvalidSteps = false;
        if (selections != null) {                
            Vector steps = getSteps(selections, null);
            Step step;
            boolean blnValid;
            String[] errorCodes;
            for (Enumeration e=steps.elements(); e.hasMoreElements(); ) {
                step = (Step)e.nextElement();
                if (step != null) {                   
                    errorCodes = getErrorCodes(selections, step, layout, false, mm, eh);
                    // Only request confirmation if the step was previously valid.
                    if ( (step.isValid()) && (errorCodes != null) && (!blnNewInvalidSteps) && (step.isEnabled()) ) {
                        blnNewInvalidSteps = true;
                    }
                    step.setErrorCodes(errorCodes);
                }
            }   
        }
        return blnNewInvalidSteps;
    }
    
    private static boolean isValid(SavedSelectionStep savedSelectionStep, String strHierarchyID) {
        boolean blnValid = false;
        if ( (savedSelectionStep != null) && (strHierarchyID != null) ) {
            Selection selection = savedSelectionStep.getSelection();
            if (selection != null) {
                blnValid = strHierarchyID.equals(selection.getHierarchy());
            }
        }
        return blnValid;
    }
    
    public static boolean validateLevels(Selection selection, MetadataManager mm, ErrorHandler eh) {
        boolean blnInvalidSteps = false;
        if ((selection != null)) {
            MDHierarchy hierarchy = null;
            try {
                hierarchy = mm.getDimensionByUniqueID(selection.getDimension()).getDefaultHierarchy();
            }
            catch (MetadataManagerException mme) {
                eh.error(mme, QueryBuilderUtils.class.getName(), "validateLevels");
            }
            if ((selection.getHierarchy() != null) || hierarchy != null) {
                Step step;
                boolean blnValid;
                for (int i = 0; i < selection.getStepCount(); i++) {
                    step = selection.getStep(i);
                    if (step != null) {
                        if ( (step instanceof ConditionStep) || (step instanceof SavedSelectionStep) ) {
                            if (step instanceof ConditionStep) {
                                blnValid = Utils.areLevelsValidForHierarchy(mm, (ConditionStep)step);
                            }
                            else {
                                blnValid = isValid((SavedSelectionStep)step, selection.getHierarchy());
                            }
                            // Only request confirmation if the step was previously valid.
                            if ((step.isValid()) && (!blnValid) && (!blnInvalidSteps)) {
                                blnInvalidSteps = true;
                            }
                            step.setValid(blnValid);
                        }
                    }
                }
            }
        }
        return blnInvalidSteps;
    }

    // Returns an operator that will be valid for the given data type.
    public static int validateOperator(int operator, String dataType, boolean twoMeas) {
      int[] ops = {};
      if (dataType != null) {
        if (dataType.equals(MM.BOOLEAN))
          ops = twoMeas ? m_twoMeasBool : m_measBool;
        else if (dataType.equals(MM.STRING))
          ops = twoMeas ? m_twoMeasString : m_measString;
        else if (dataType.equals(MM.DATE))
          ops = twoMeas ? m_twoMeasDate : m_measDate;
        else if (isNumeric(dataType))
          ops = twoMeas ? m_twoMeasNum : m_measNum;
      }
      for (int i = 0; i < ops.length; i++)
        if (ops[i] == operator)
          return operator;

      return getDefaultOperator(dataType, twoMeas);
    }    */

    public static String getAttributeValue(MetadataManager metadataManager, String strOwner, String strDimension, String strHierarchy, MDAttribute attribute, ErrorHandler errorHandler) {
//HBR: Persistence removal
/*        Vector attributeValues = getAttributeValues(metadataManager, 1, strOwner, strDimension, strHierarchy, attribute, errorHandler);
        if ( (attributeValues != null) && (!attributeValues.isEmpty()) ) {
            return attributeValues.firstElement().toString();
        }*/
        return null;
    }
    
    private static String getAWAttributeName(MetadataManager metadataManager, MDAttribute mdAttribute) {
        try {
            if ( (mdAttribute != null) && (mdAttribute.isAWObject()) ) {
                return mdAttribute.getAWObjectName();
            }
        }
        catch (MetadataManagerException e) {
        }
        return null;
    }
    
    private static String getAWProgram() {
        String strProgram = "arg _txtAttribute  text -\n";
        strProgram += "arg _N             int -\n";
        strProgram += "vrb _txtDimension   text -\n";
        strProgram += "trap on ATTRERROR noprint -\n";
        strProgram += "if obj(type _txtAttribute) eq 'VARIABLE' -\n";
        strProgram += "then do -\n";
        strProgram += "   if not exists('_qb.attribute_values') -\n";
        strProgram += "   then define _qb.attribute_values dimension text session -\n";
        strProgram += "   else maintain _qb.attribute_values delete all -\n";
        strProgram += "   _txtDimension = extlines(Obj(Dims _txtAttribute) 1 1) -\n";
        strProgram += "   tempstat &_txtDimension -\n";
        strProgram += "   do -\n";
        strProgram += "      maintain _qb.attribute_values merge &_txtAttribute -\n";
        strProgram += "      if NAFill(_N, -1) gt 0 -\n";
        strProgram += "      then limit _qb.attribute_values keep first _N -\n";
        strProgram += "      sort _qb.attribute_values a _qb.attribute_values -\n";
        strProgram += "   doend -\n";
        strProgram += "   return values(_qb.attribute_values) -\n";
        strProgram += "doend -\n";
        strProgram += "if obj(type _txtAttribute) eq 'RELATION' -\n";
        strProgram += "then do -\n";
        strProgram += "   _txtDimension = Obj(data _txtAttribute) -\n";
        strProgram += "   tempstat &_txtDimension -\n";
        strProgram += "   do -\n";
        strProgram += "      if NAFill(_N, -1) gt 0 -\n";
        strProgram += "      then limit &_txtDimension to first _N -\n";
        strProgram += "      else limit &_txtDimension to all -\n";
        strProgram += "      sort &_txtDimension a &_txtDimension -\n";
        strProgram += "      return values(_txtDimension) -\n";
        strProgram += "   doend -\n";
        strProgram += "doend -\n";
        strProgram += "ATTRERROR: -\n";
        strProgram += "   return '-1'";
        return strProgram;
    }
    
    /** gek 11/03/06
    private static void setupProgram(OlapDmlUtil olapDmlUtil, ErrorHandler errorHandler) {
        try {
            String strCommand = "&(if exists('_qb.get_attribute_values') then 'consider _qb.get_attribute_values' else 'define _qb.get_attribute_values program session')";
            String strResult = olapDmlUtil.executeCommand(strCommand);
            strCommand = "program get(raw text) \n";
            strCommand += getAWProgram();
            strResult = olapDmlUtil.executeCommand(strCommand);
        }
        catch (Exception e) {
            errorHandler.error(e, QueryBuilderUtils.class.getName(), "setupProgram");   
        }
    }
    */

  //HBR: Persistence removal
/*    public static Vector getAttributeValues(MetadataManager metadataManager, int intMaximum, String strOwner, String strDimension, String strHierarchy, MDAttribute mdAttribute, ErrorHandler errorHandler) {
        Vector attributeValues = new Vector();
        if ( (metadataManager != null) && (mdAttribute != null) ) {
            try {
                String strAWAttributeName = getAWAttributeName(metadataManager, mdAttribute);
                if (strAWAttributeName != null) {
                    OlapDmlUtil olapDmlUtil = new OlapDmlUtil(metadataManager);
                    String strCommand = "show _qb.get_attribute_values('" + strAWAttributeName + "', " + intMaximum + ")";
                    String strResult = null;
                    try {
                        strResult = olapDmlUtil.executeCommand(strCommand);
                    }
                    catch (SQLException e) {
                        setupProgram(olapDmlUtil, errorHandler);  
                        strResult = olapDmlUtil.executeCommand(strCommand);
                    }
                    if (!"-1".equals(strResult)) {
                        attributeValues = DataUtils.parseDelimitedStringVector(strResult, OlapDmlUtil.RESULTSET_ROW_DELIMITER);
                    }
                }
                else {
                    OlapSqlUtil olapSqlUtil = new OlapSqlUtil(metadataManager);
                    ResultSet resultSet = null;
                    if (intMaximum == -1) {
                        resultSet = getPLSQLResultSet(olapSqlUtil, m_strGetAllAttrsSQL, intMaximum, strOwner, strDimension, strHierarchy, mdAttribute.getName());
                    }
                    else {
                        resultSet = getPLSQLResultSet(olapSqlUtil, m_strNAttributeValueSQL, intMaximum, strOwner, strDimension, strHierarchy, mdAttribute.getName());
                    }
                    attributeValues = olapSqlUtil.getValues(resultSet);
                    if (resultSet != null) {
                        Statement statement = resultSet.getStatement();
                        resultSet.close();
                        if (statement != null) {
                            statement.close();
                        }
                    }
                }
            }
            catch (Exception e) {
                errorHandler.error(e, QueryBuilderUtils.class.getName(), "getAttributeValues");
            }
        }
        return attributeValues;
    }
*/

        // blm - Selection code moved to dvt-olap
/*
    public static void addModifiedSelection(String selectionID, Selection selection, Vector IDs, Vector sels) {
      if (IDs.contains(selectionID)) {
        int i = IDs.indexOf(selectionID);
        IDs.removeElementAt(i);
        sels.removeElementAt(i);
      }
      updateSelections(selectionID, selection, sels);
      IDs.insertElementAt(selectionID, 0);
      sels.insertElementAt(selection, 0);
    }

    private static void updateSelections(String selectionID, Selection selection, Vector sels) {
      for (int i = 0; i < sels.size(); i++) {
        Vector id = new Vector();
        id.add(selectionID);
        Vector sel = new Vector();
        sel.add(selection);
        updateSelection(id, sel, (Selection)sels.elementAt(i));
      }
    }

    public static void updateSelection(Vector IDs, Vector sels, Selection staleSelection) {
      if (IDs.size() == 0)
        return;
      for (int i = 0; i < staleSelection.getStepCount(); i++) {
        Step s = staleSelection.getStep(i);
        if (s instanceof SavedSelectionStep) {
          SavedSelectionStep sss = (SavedSelectionStep)s;
          if (IDs.contains(sss.getRuntimePath())) {
            staleSelection.removeStep(i);
            try {
              sss.setSelection((Selection)sels.elementAt(IDs.indexOf(sss.getRuntimePath())));
            }
            catch (SelectionException e) {
              e.printStackTrace();
            }
            staleSelection.addStep(sss, i);
          }
          else {
            updateSelection(IDs, sels, sss.getSelection());
          }
        }
      }
    }

    public static void appendSelections(Vector fromIDs, Vector fromSels, Vector toIDs, Vector toSels) {
      for (int i = toIDs.size() - 1; i >= 0; i--) {
        if (fromIDs.contains(toIDs.elementAt(i))) {
          toIDs.removeElementAt(i);
          toSels.removeElementAt(i);
        }
        else
          QueryBuilderUtils.updateSelection(fromIDs, fromSels, (Selection)toSels.elementAt(i));
      }
      for (int i = fromIDs.size() - 1; i >= 0; i--) {
        toIDs.insertElementAt(fromIDs.elementAt(i), 0);
        toSels.insertElementAt(fromSels.elementAt(i), 0);
      }
    }

    private Vector getVector(String s) {
        Vector v = new Vector();
        if (s != null) {
            StringTokenizer st = new StringTokenizer(s, "\n");
            if (st.hasMoreTokens()) {
                v.addElement(st.nextToken());
            }
        }
        return v;
    }

*/
    //HBR: Persistence removal
    /*
    private static ResultSet getPLSQLResultSet(OlapSqlUtil olapSqlUtil, String strPLSQL, int intMaximum, String strOwner, String strDimension, String strHierarchy, String strAttribute) throws Exception {
        ResultSet resultSet = null;
        if ( (olapSqlUtil != null) && (strPLSQL != null) ) {
            String strCommand = null;
            java.sql.Connection connection = olapSqlUtil.getConnection();
            CallableStatement cs = connection.prepareCall(strPLSQL);
            int bBindVar = 1;
            if (intMaximum != -1) {
                cs.setLong(bBindVar++,intMaximum);
            }
            cs.setString(bBindVar++,strOwner);
            cs.setString(bBindVar++,strDimension);
            cs.setString(bBindVar++,strHierarchy);
            cs.setString(bBindVar++,strAttribute);
            cs.registerOutParameter(bBindVar, OracleTypes.CURSOR);
            cs.execute();
            resultSet = (ResultSet)cs.getObject(bBindVar);
        }
        return resultSet;
    }
    */
    
    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.3
     * server or beyond for special handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is9203(MetadataManager metadataManager) {
        return Utility.compareVersionStrings(getConnectionVersionInfo(metadataManager), "9.2.0.3");
    }

    private static String getConnectionVersionInfo(MetadataManager metadataManager) {
        Connection connection = getConnection(metadataManager);
        if (connection != null) {
            PropertyBag propertyBag = connection.getVersionInfo();
            return propertyBag.getStrPropertyValue(CB.DATABASE_VERSION);
        }
        return null;
    }

    private static Connection getConnection(MetadataManager metadataManager) {
        if (metadataManager != null) {
            // Find the MDM driver connection
            Connection connections[] = metadataManager.getConnections();
            if (connections != null) {
                for (int i=0; i<connections.length; i++) {
                    if (connections[i].getDriverType().equals(MM.MDM)) {
                        return connections[i];
                    }
                }
            }
        }
        return null;
    }

    /*
     * @hidden
     * Get the measure given the unique id.
     */
    public static MDMeasure getMeasure(MetadataManagerServices mm, String strUniqueID, ErrorHandler eh) {
        MDMeasure measure = null;
        if ((mm != null) && (strUniqueID != null)) {
            try {
                measure = mm.getMeasureByUniqueID(strUniqueID);
            }
            catch (MetadataManagerException e) {
                processError(eh, e, QueryBuilderUtils.class, "getMeasure");
            }
        }
        return measure;
    }
        
    /*
     * @hidden
     * Get the object given the unique id.
     */
    public static MDObject getMDObject(MetadataManagerServices mm, String strUniqueID, String strObjectType, ErrorHandler errorHandler) {
        if (mm != null) {
            try {
                return mm.getMDObject(MM.UNIQUE_ID, strUniqueID, strObjectType);
            }
            catch (MetadataManagerException e) {
                processError(errorHandler, e, QueryBuilderUtils.class, "getMDObject");
            }
        }
        return null;
    }
    
    /*
     * @hidden
     */
    public static void processError(ErrorHandler errorHandler, Throwable t, Class c, String strMethod) {
        if (errorHandler != null) {
            errorHandler.error(t, (c != null) ? c.getName() : null, strMethod);
        }
        else if (t != null) {
            t.printStackTrace();
        }        
    }

    // Get the measure given the object.
    private static MDMeasure getMeasure(MetadataManagerServices mm, Object object, ErrorHandler eh) {
      MDMeasure mdMeasure = null;
      if ((mm != null) && (object != null)) {
        if (object instanceof DimensionMember) {
          mdMeasure = getMeasure(mm, ((DimensionMember)object).getDimMemberID(), eh);
        }
        else if (object instanceof String) {
          mdMeasure = getMeasure(mm, (String)object, eh);
        }
        else if (object instanceof MDMeasure) {
          mdMeasure = (MDMeasure)object;
        }
      }
      return mdMeasure;
    }
    
    // Get the default comparison measures.
    public static Vector getDefaultComparisonMeasures(MetadataManager metadataManager, Vector measures, String strPreferredMeasure, ErrorHandler eh) {
      Vector backupComparisonMeasures = new Vector();
      if ((metadataManager != null) && (measures != null)) {
        String strNumericMeasure = null;
        String strBooleanMeasure = null;
        String strDateMeasure = null;
        MDMeasure mdMeasure = null;
        String strDataType = null;
        String strPreferredDataType = null;
        if (strPreferredMeasure != null) {
          MDMeasure mdPreferredMeasure = getMeasure(metadataManager, strPreferredMeasure, eh);
          if (mdPreferredMeasure != null) {
            strPreferredDataType = mdPreferredMeasure.getDataType();
          }
        }
        Object object;
        for (Enumeration e=measures.elements(); e.hasMoreElements(); ) {
          mdMeasure = getMeasure(metadataManager, e.nextElement(), eh);
          if (mdMeasure != null) {
            strDataType = mdMeasure.getDataType();
            if (strDataType != null) {
              if ((strDataType.equals(strPreferredDataType)) && (!mdMeasure.getUniqueID().equals(strPreferredMeasure))) {
                Vector preferredComparisonMeasures = new Vector();
                preferredComparisonMeasures.addElement(strPreferredMeasure);
                preferredComparisonMeasures.addElement(mdMeasure.getUniqueID());
                return preferredComparisonMeasures;
              }
              if (backupComparisonMeasures.size() < 2) {
                if (strDataType.equals(MM.BOOLEAN)) {
                  if (strBooleanMeasure == null) {
                    strBooleanMeasure = mdMeasure.getUniqueID();
                  }
                  else if (!strBooleanMeasure.equals(mdMeasure.getUniqueID())) {
                    backupComparisonMeasures.addElement(strBooleanMeasure);
                    backupComparisonMeasures.addElement(mdMeasure.getUniqueID());
                  }
                }
                else if (strDataType.equals(MM.DATE)) {
                  if (strDateMeasure == null) {
                    strDateMeasure = mdMeasure.getUniqueID();
                  }
                  else if (!strDateMeasure.equals(mdMeasure.getUniqueID())) {
                    backupComparisonMeasures.addElement(strDateMeasure);
                    backupComparisonMeasures.addElement(mdMeasure.getUniqueID());
                  }    
                }
                else if (isNumeric(strDataType)) {
                  if (strNumericMeasure == null) {
                    strNumericMeasure = mdMeasure.getUniqueID();
                  }
                  else if (!strNumericMeasure.equals(mdMeasure.getUniqueID())) {
                    backupComparisonMeasures.addElement(strNumericMeasure);
                    backupComparisonMeasures.addElement(mdMeasure.getUniqueID());
                  } 
                }
              }
            }
          }
        }
      }
      return backupComparisonMeasures;
    }
    
    /**
     *  Return a vector containing two comparison measures, dimensioned by the given dimension and of the given
     *  data type. Measures are returned first from the QueryAccessUtilities, then the MetadataManager, as needed.
     */
    public static Vector getDefaultComparisonMeasures(QueryAccessUtilities queryAccessUtilities, MetadataManager metadataManager, String strDimension, String strDataType, int intMaximum, ErrorHandler errorHandler) {
        Vector measures = new Vector();
        if ((queryAccessUtilities != null) && (metadataManager != null) && (strDataType != null)) {
            // Get all the measures from the QueryAccess and the MetadataManager.
            Vector filteredMeasures = getAllMeasures(queryAccessUtilities, metadataManager, errorHandler);
            // Filter out measures not of the given data type.
            filteredMeasures = filterMeasures(metadataManager, filteredMeasures, strDimension, strDataType, errorHandler);
            // Return the first n measures.
            if (intMaximum == -1) {
                return filteredMeasures;
            }
            else {
                int intMax = Math.min(filteredMeasures.size(), intMaximum);
                for (int i=0; i<intMax; i++) {
                    measures.addElement(filteredMeasures.elementAt(i));
                }
            }
        }
        return measures;
    }

    /**
     *  Return a vector containing two comparison measures, dimensioned by the given dimension and of the given
     *  data type. Measures are returned first from the QueryAccessUtilities, then the MetadataManager, as needed.
     */
    public static Vector getDefaultComparisonMeasures(QueryAccessUtilities queryAccessUtilities, MetadataManager metadataManager, String strDimensionID, String strDataType, ErrorHandler eh) {
      Vector measures = new Vector();
      if ((queryAccessUtilities != null) && (metadataManager != null) && (strDimensionID != null) && (strDataType != null)) {
        // Get all the measures from the QueryAccess and the MetadataManager.
        //measures = getAllMeasures(queryAccessUtilities, metadataManager);
        measures = getAllMeasures(queryAccessUtilities, metadataManager, eh);
        // Filter out measures not dimensioned by the given dimension.
        measures = filterMeasures(metadataManager, measures, strDimensionID, null, eh);
        // Return the first two measures of the given data type.
        measures = getFirstTwoMeasuresByType(metadataManager, measures, strDataType, eh);
      }
      return measures;
    }

    // Get the first two measures among the given measures whose data type is compatible with the given data type.
    private static Vector getFirstTwoMeasuresByType(MetadataManager metadataManager, Vector measures, String strDataType, ErrorHandler eh) {
      Vector firstTwoMeasures = new Vector();
      if ((metadataManager != null) && (measures != null) && (strDataType != null)) {
        String strMeasure1 = null;
        String strMeasure2 = null;
        MDMeasure mdMeasure = null;
        for (Enumeration e=measures.elements(); e.hasMoreElements(); ) {
          mdMeasure = getMeasure(metadataManager, e.nextElement(), eh);
          if (mdMeasure != null) {
            if (areCompatibleDataTypes(mdMeasure.getDataType(), strDataType)) {       
              if (strMeasure1 == null) {
                strMeasure1 = mdMeasure.getUniqueID();
              }
              else if (!strMeasure1.equals(mdMeasure.getUniqueID())) {
                strMeasure2 = mdMeasure.getUniqueID();
                break;
              }
            }
          }
        }
        // If no matching second measure could be found, set it to the first measure.
        if (strMeasure2 == null) {
          strMeasure2 = strMeasure1;
        }
        firstTwoMeasures.addElement(strMeasure1);
        firstTwoMeasures.addElement(strMeasure2);
      }
      return firstTwoMeasures;
    }

    // Return a vector of valid data types for the given data type.
    public static String[] getValidDataTypes(String strDataType) {
      if (strDataType != null) {
        if (strDataType.equals(MM.BOOLEAN))
          return new String[] {MM.BOOLEAN};
        else if (strDataType.equals(MM.DATE))
          return new String[] {MM.DATE};
        else if (strDataType.equals(MM.STRING))
          return new String[] {MM.STRING};
        else if (isNumeric(strDataType))
          return new String[] {MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE, MM.LONG};
      }
      return null;
    }

    // blm - Selection code moved to dvt-olap
/*    public static String[] getValidDataTypes(Step step) {
      String[] dataTypes = null;
      if (step instanceof TwoMeasNumRangeStep ||
          step instanceof TopBottomStep ||
          step instanceof TopBottomSumStep)
        dataTypes = new String[] {MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE, MM.LONG};
      else if (step instanceof MeasValRangeStep)
        dataTypes = new String[] {MM.DATE, MM.STRING, MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE, MM.LONG};
      else if (step instanceof TwoMeasNumStep) {
        if (((TwoMeasNumStep)step).isOffsetCalculated())
         dataTypes = new String[] {MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE, MM.LONG};
        else
         dataTypes = new String[] {MM.BOOLEAN, MM.DATE, MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE, MM.LONG};
      }
      return dataTypes;
    }
*/
    public static DateFormat getDateFormat(Locale locale) {
      DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, locale == null ? Locale.getDefault() : locale);
      if (locale != null && locale.getLanguage().compareTo("th") == 0 && locale.getCountry().compareTo("TH") == 0) {
        df.setCalendar(new GregorianCalendar());  
      }      
      if (df instanceof SimpleDateFormat) {
        SimpleDateFormat sdf = (SimpleDateFormat)df;
        String origPattern = sdf.toPattern();
        int yStart = origPattern.indexOf("y");
        int yEnd = origPattern.lastIndexOf("y");
        StringBuffer sb = new StringBuffer();
        sb.append(origPattern.substring(0, yStart));
        sb.append("yyyy");
        if ((yEnd + 1) < origPattern.length()) {
          sb.append(origPattern.substring(yEnd + 1, origPattern.length()));
        }
        sdf.applyPattern(sb.toString());
      }
      return df;
    }

    public static DimensionMember getDimMember(QueryAccessUtilities qau, 
                                               String dimension, 
                                               String hierarchy, 
                                               String value, 
                                               String level,
                                               String strDisplayMemberLabelType,
                                               QueryContext qc,
                                               MetadataManager mm,
                                               ErrorHandler eh) {
      if (qau != null)
      {
          DimensionMember val = qau.getCachedValue(dimension, hierarchy, value, strDisplayMemberLabelType);
          if (val != null)
            return val;
      }
      Vector valList = new Vector();
      valList.addElement(value);
      Vector levels = new Vector();
      if (level != null) {
        levels.addElement(level);
      }
      Vector retList = getDimMembers(qau, dimension, hierarchy, valList, levels, strDisplayMemberLabelType, qc, mm, eh);
      if (retList != null && retList.size() > 0)
      {
            DimensionMember val = (DimensionMember)retList.elementAt(0);
            if (qau != null)
            {
                qau.putCachedValue(dimension, hierarchy, value, strDisplayMemberLabelType, val);
            }
            return val;
      }

      return null;
	  }

    /**
     * @hidden
     * Return a list of dimension members (value/label pairs) 
     * on the given dimension
     *
     * @param dimension dimension to scan for value/label pairs
     * @param values values to pair with their labels
     * @param strDisplayMemberLabelType
     * @return list of DimensionMember value/label pairs
     * @status hidden
     */
    public static Vector getDimMembers(QueryAccessUtilities qau, 
                                       String dimension, 
                                       String hierarchy, 
                                       Vector values,
                                       Vector levels,
                                       String strDisplayMemberLabelType,
                                       QueryContext qc,
                                       MetadataManager mm,
                                       ErrorHandler eh) {
        if (qau == null)
            return new Vector();
      DataAccess da = qau.getQueryAccess().getDataAccess(dimension);
      Vector retList = new Vector();    
      if (da == null)
        return retList;
      boolean hasLevels = levels != null && levels.size() == values.size();
      Vector notFound = new Vector();
      Vector notFoundLevels = new Vector();
      String dimVal;
      try {
        for (int i = 0; i < values.size(); i++)
        {
          dimVal = DataUtils._makeString(values.elementAt(i));
          // Do a findvalues on it
          int result = da.findMember(0, new int[0], 0, dimVal, MetadataMap.METADATA_VALUE, DataAccess.FIND_EXACT);
          if (result > -1) {
            String[] levelID = qau.getLevelOfMember(da, hierarchy, result, mm);
            retList.addElement(new DimensionMember(DataUtils._makeString(da.getMemberMetadata(0, 0, result, MetadataMap.METADATA_VALUE)),
                                                   DataUtils._makeString(da.getMemberMetadata(0, 0, result, strDisplayMemberLabelType)),
                                                   hierarchy, levelID[0], levelID[1]));
          }
          else {
            // Put it in the not found list
            notFound.addElement(dimVal);
            if (hasLevels)
              notFoundLevels.addElement(levels.elementAt(i));
          }
        }
      }
      catch (Exception e) {
        // Shouldn't happen
        eh.error(e, QueryBuilderUtils.class.getName(), "getDimMembers");                            
      }
        
        // blm - Selection code moved to dvt-olap
      /*
      // When out of status findvalue is supported, won't need this
      if (notFound.size() > 0) {
        // Now execute a custom selection...
        Selection sel = new Selection(dimension);
        sel.setHierarchy(hierarchy);
        // Put these in a value step
        MemberStep ms = new MemberStep(dimension);
        ms.setHierarchy(sel.getHierarchy());
        for (int i = 0; i < notFound.size(); i++) {
          if (hasLevels) {
            ms.addMember((String)notFound.elementAt(i), (String)notFoundLevels.elementAt(i));
          }
          else {
            ms.addMember((String)notFound.elementAt(i));
          }          
        }
        sel.addStep(ms);
        try {
          //QueryAccess qa = qc.createQueryAccess();
          //qa.setMetadataMap(new MetadataMap(new String[] {MetadataMap.METADATA_VALUE, MetadataMap.METADATA_INDENT, strDisplayMemberLabelType}));
          //qa.setSelection(sel);
          da = qau.getQueryAccess().getDataAccess(sel);
          int numVals = da.getEdgeExtent(DataDirector.COLUMN_EDGE);
          for (int i = 0; i < numVals; i++) {
            String[] levelID = qau.getLevelOfMember(da, sel.getHierarchy(), i, mm);
            retList.addElement(new DimensionMember(DataUtils._makeString(da.getMemberMetadata(0, 0, i, MetadataMap.METADATA_VALUE)),
                                                   DataUtils._makeString(da.getMemberMetadata(0, 0, i, strDisplayMemberLabelType)),
                                                   sel.getHierarchy(), levelID[0], levelID[1]));
          }
          da.release();
          //qa.release();
        }
        catch (Exception e) {
          eh.error(e, QueryBuilderUtils.class.getName(), "getDimMembers");
          return retList;
        }
      }*/
      return retList;
    }
    
   // blm - Selection code moved to dvt-olap
    /*
    public static String getLevelName(String levelID, MetadataManagerServices mm, ErrorHandler eh) {
      if (levelID != null) {
        try {
          MDLevel mdLevel = mm.getLevel(MM.UNIQUE_ID, levelID);
          if (mdLevel != null) {
            return mdLevel.getName();
          }
        }
        catch (MetadataManagerException mme) {
          eh.error(mme, QueryBuilderUtils.class.getName(), "getLevelName");
        }
      }
      return null;
    }

    //  returns a list of values at a given level, in a given hierarchy, in a given dimension
    //  constants for getValuesAtLevel method: DEFAULT, VALUES, SHORTLABEL, LONGLABEL
    public static Vector getValuesAtLevel(QueryAccessUtilities qau, 
                                          String dimension, 
                                          String hierarchy,
                                          String level, 
                                          String labelType, 
                                          int maxValues, 
                                          ErrorHandler errorHandler) {
      Vector members = null;
      Selection selection = new Selection(dimension);
      selection.setHierarchy(hierarchy);
      Vector vLevel = new Vector();
      vLevel.addElement(level);

      try {
        if (maxValues > 0) {
          FirstLastStep fls = new FirstLastStep(dimension, hierarchy, vLevel, FirstLastStep.FIRST, new Integer(maxValues));
          selection.addStep(fls);
        }
        else {
          AllStep step = new AllStep(dimension, hierarchy, vLevel);
          selection.addStep(step);
        }
      }
      catch (InvalidStepArgException isae) {
        errorHandler.error(isae, QueryBuilderUtils.class.getName(), "getValuesAtLevel");
      }

      // Get a one-off cursor
      DataAccess dataAccess = qau.getQueryAccess().getDataAccess(selection);

      if (dataAccess != null) {
        members = new Vector();
        try {
          int[] dimArray = new int[0];
          int count = dataAccess.getMemberSiblingCount(0, dimArray, 0);
          for (int value = 0; value < count; value++) {
            members.addElement(new DimensionMember(
                DataUtils._makeString(dataAccess.getMemberMetadata(0, dimArray, 0, value, MetadataMap.METADATA_VALUE)),
                DataUtils._makeString(dataAccess.getMemberMetadata(0, dimArray, 0, value, labelType)), 
                hierarchy,
                DataUtils._makeString(dataAccess.getMemberMetadata(0, dimArray, 0, value, MetadataMap.METADATA_LEVEL)),
                DataUtils._makeString(dataAccess.getMemberMetadata(0, dimArray, 0, value, MetadataMap.METADATA_LEVEL_NAME))));
          }
        }
        catch (Exception e)  {
          errorHandler.error(e, QueryBuilderUtils.class.getName(), "getValuesAtLevel");
        }
        dataAccess.release();
      }
      return members;
    }

    // Operator support
    private static final int[] m_measBool      = {MeasValStep.OP_EQUAL};

    private static final int[] m_measString    = {MeasValStep.OP_CONTAINS,
                                                  MeasValStep.OP_BEGINS_WITH,
                                                  MeasValStep.OP_ENDS_WITH,
                                                  MeasValStep.OP_EQUAL,
                                                  MeasValStep.OP_NOT_EQUAL,
                                                  MeasValStep.OP_GREATER,
                                                  MeasValStep.OP_LESS,
                                                  MeasValStep.OP_GREATER_EQUAL,
                                                  MeasValStep.OP_LESS_EQUAL};

   private static final int[] m_measDate       = {MeasValStep.OP_GREATER,
                                                  MeasValStep.OP_LESS,
                                                  MeasValStep.OP_GREATER_EQUAL,
                                                  MeasValStep.OP_LESS_EQUAL,
                                                  MeasValStep.OP_EQUAL,
                                                  MeasValStep.OP_NOT_EQUAL};

   private static final int[] m_measNum        = {MeasValStep.OP_GREATER, 
                                                  MeasValStep.OP_LESS,
                                                  MeasValStep.OP_GREATER_EQUAL, 
                                                  MeasValStep.OP_LESS_EQUAL,
                                                  MeasValStep.OP_EQUAL, 
                                                  MeasValStep.OP_NOT_EQUAL};

   private static final int[] m_twoMeasBool    = {TwoMeasNumStep.OP_EQUAL, 
                                                  TwoMeasNumStep.OP_NOT_EQUAL};

   private static final int[] m_twoMeasString  = {}; 

   private static final int[] m_twoMeasDate    = {TwoMeasNumStep.OP_GREATER,
                                                  TwoMeasNumStep.OP_LESS,
                                                  TwoMeasNumStep.OP_GREATER_EQUAL,
                                                  TwoMeasNumStep.OP_LESS_EQUAL,
                                                  TwoMeasNumStep.OP_EQUAL,
                                                  TwoMeasNumStep.OP_NOT_EQUAL};

   private static final int[] m_twoMeasNum     = {TwoMeasNumStep.OP_GREATER,
                                                  TwoMeasNumStep.OP_LESS,
                                                  TwoMeasNumStep.OP_GREATER_EQUAL,
                                                  TwoMeasNumStep.OP_LESS_EQUAL,
                                                  TwoMeasNumStep.OP_EQUAL,
                                                  TwoMeasNumStep.OP_NOT_EQUAL};*/
}