/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Provides a message when a redo operation cannot be performed.
 *
 * @status Documented
 */
public class RedoException extends QueryRuntimeException
{
    /**
     * Constructor for this class.
     *
     * @param msg   The message to display.
     * @param exception The exception that was trapped to generate this exception.
     *
     * @status documented
     */
    public RedoException(String msg, Exception exception) {
        super(msg, exception);
    }
}
