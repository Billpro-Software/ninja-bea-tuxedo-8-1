/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
**
*/

package oracle.dss.datautil.gui;

import java.awt.Dimension;
import java.awt.Window;
import java.awt.Component;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

import oracle.bali.ewt.util.WindowUtils;
import oracle.bali.ewt.wizard.WizardPage;
import oracle.bali.ewt.wizard.ReentrantWizard;

import oracle.dss.datautil.Timer;

/**
 * @hidden
 * Extends the BALI <code>ReentrantWizard</code> class to provide the validate
 * event when the "Previous" button is pressed.
 *
 * @status hidden
 */
public class CustomReentrantWizard extends ReentrantWizard
{
    //---------------------------------------------------------
    // NON PUBLIC MEMBERS
    //---------------------------------------------------------
    
    /**
     * Indicates whether all the pages of the wizard must be visited
     * before the "Finish" button is enabled.
     *
     * @status protected
     */
    protected boolean m_bMustFinish = false;
    
    /**
     * The wizard size.
     *
     * @status protected
     */
    protected Dimension m_wizardSize = null;
    
    /**
     * The wizard state.
     *
     * @status protected
     */
    protected int m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
    
    //---------------------------------------------------------
    // CONSTRUCTOR
    //---------------------------------------------------------
    
    //---------------------------------------------------------
    // PUBLIC METHODS
    //---------------------------------------------------------
    
    /**
     * @hidden
     * Indicates whether the user can finish at any time, or must reach the
     * last page before finshing.  By default, this method returns
     * <code>true</code>.
     *
     * @return <code>true</code> indicates that the user must reach the last
     *         page before finishing; <code>false</code> indicates that the
     *         user can finish at any time.
     *
     * @status hidden
     */
    public boolean getMustFinish ( )
    {
        return m_bMustFinish;
    }
    
    /**
     * @hidden
     * Retrieves the preferred size of the wizard.
     *
     * @return The preferred size of the wizard.
     *
     * @status hidden
     */
    public Dimension getPreferredSize ( )
    {
        if ( null == m_wizardSize )
            return super.getPreferredSize ( );
            
        return m_wizardSize;            
    }
    
    /**
     * @hidden
     * Retrieves the wizard state.
     *
     * @return   The wizard state. One of the constants found in
     *           <code>CustomWizardConst</code> such as
     *           CUSTOMWIZARD_PREVIOUS, which indicates that the "Previous"
     *           button was pressed.
     *
     * @see CustomWizardConst
     *
     * @status hidden
     */
    public int getWizardState ( )
    {
        return m_nWizardState;
    }
    
    /**
     * @hidden
     * Selects the specified wizard page.
     *
     * @param wizardPage  The wizard page to be selected.
     * @param bDoValidate <code>true</code> if the page is to be validated;
     *                    <code>false</code> if the page is not to be validated.
     *
     * @status hidden
     */
    public void selectPage ( WizardPage wizardPage, boolean bDoValidate )
    {
        if ( null == wizardPage )
            return;
            
        super.selectPage ( wizardPage, bDoValidate );
    }

    /**
     * @hidden
     * Specifies whether the user can finish at any time, or must reach the
     * last page before finshing.  By default, this setting is
     * <code>true</code>.
     *
     * @param bMustFinish <code>true</code> if the user must reach the last
     *                    page before finishing; <code>false</code> if the user
     *                    can finish at any time.
     * 
     * @status hidden
     */
    public void setMustFinish ( boolean bMustFinish )
    {
        m_bMustFinish = bMustFinish;
    }
    
    /**
     * @hidden
     * Specifies the wizard size.
     *
     * @param wizardSize    The size of the wizard.
     *
     * @status hidden
     */
    public void setWizardSize ( Dimension wizardSize )
    {
        m_wizardSize = wizardSize;
    }

  /**
   * @hidden
   * Notifies the component that it has been added to a container.
   * This method should be called by Container.add, and never by user
   * code directly.
   *
   * @status hidden
   */
    public void addNotify()
    {
      super.addNotify();
      final Window w = WindowUtils.getWindow(this);
      w.addWindowListener(new WindowAdapter()
      {
        public void windowOpened(WindowEvent e)
        {
          CustomWizardPage.setFirst(true);
          WizardPage page = getSelectedPage();

          if (page != null)
          {
            Component initialFocus = page.getInitialFocus();
              if ((initialFocus != null) &&
                  (initialFocus.isEnabled()))
                initialFocus.requestFocus();
          }
          w.removeWindowListener(this);
        }
      });
    }

    //---------------------------------------------------------
    // NON PUBLIC METHODS
    //---------------------------------------------------------

    /**
     * Handles the user pressing the "Apply" button.
     *
     * @status protected
     */
    protected void doApply()
    {
        if (Timer.ON) {
            Timer.getTimer().start("Apply");
        }
        
        // Mark this as an apply operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_APPLY;
        
        super.doApply ( );
        
        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Apply");
        }
    }

    /**
     * Handles the user pressing the "Cancel" button.
     *
     * @status protected
     */
    protected void doCancel()
    {
        if (Timer.ON) {
            Timer.getTimer().start("Cancel");
        }
        
        // Mark this as a cancel operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_CANCEL;
        
        super.doCancel ( );
        
        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Cancel");
        }
    }

    /**
     * Handles the user pressing the "Finish" button.
     *
     * @status protected
     */
    protected void doFinish()
    {
        if (Timer.ON) {
            Timer.getTimer().start("Finish");
        } 
        
        // Mark this as a finish operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_FINISH;
        
        super.doFinish ( );
        
        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("Finish");
        } 
    }

    /**
     * Handles the user pressing the "Next" button.
     */
    protected void doNext ( )
    {
        // Mark this as a next operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_NEXT;
        
        super.doNext ( );
        
        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
    }
    
    /**
     * Handles the user pressing the "Previous" button.
     */
    protected void doPrevious ( )
    {
        WizardPage  previous    = null;
        
        // Mark this as a previous operation
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_PREVIOUS;
        
        // Validate the page up front, so that clients can adjust which
        // page is next in response to the validate event.
        if ( validateSelectedPage ( ) )
        {
            previous = getPreviousPage ( getSelectedPage ( ) );
            if ( previous != null )
            {
                // Don't bother validating _again_
                selectPage ( previous, false );
            }                
        }
        
        // Reset the wizard state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
    }        
    
    /**
     * Called before the selection in the ReentrantWizard has changed,
     * either in response to a programmatic call, or in response to
     * a user action.  Returning false prevents the selection from changing.
     * Most clients should use the VALIDATE_PAGE event, which is delivered
     * after this function is called, but some clients may find this hook
     * useful.
     *
     * @param toPage The page to which the selection is changing.
     */
    protected boolean pageSelectionChanging ( WizardPage toPage )
    {
        if (Timer.ON) {
            Timer.getTimer().start("pageSelectionChanging - toPage:" + toPage);
        }
        
        boolean bRetVal = false;

        bRetVal = super.pageSelectionChanging ( toPage );
        if ( ! bRetVal )
            return bRetVal;
        
        if ( null == toPage )
            return false;
            
        if ( ! ( toPage instanceof CustomWizardPage ) && 
             ! ( toPage instanceof CustomImageWizardPage ) )
            return false;

        // Mark the wizard state as page changing.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_PAGECHANGING;
        
        if ( toPage instanceof CustomWizardPage )
        {
            bRetVal = ( ( CustomWizardPage ) toPage ).validatePage ( );
        }
        else if ( toPage instanceof CustomImageWizardPage )
        {
            bRetVal = ( ( CustomImageWizardPage ) toPage ).validatePage ( );
        }
        
        // Reset the wizard state to inavlid state.
        m_nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
        
        if (Timer.ON) {
            Timer.getTimer().stop("pageSelectionChanging - toPage:" + toPage);
        }
        
        return bRetVal;                
    }
}