/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

// Imports
import java.util.Locale;
import oracle.dss.bicontext.BIRemoteException;
 
public class ConnectionException extends BIRemoteException
{
    private String m_driverType;

   /**
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale    The Locale object.  It is used to load the locale 
    *                  sensitive error message.
    * @param prevException  The exception that underlies this exception.
    * @param driverType The String representing the driver type of the 
    *                   Connection driver that is throwing the exception.
    *                  
    *
    * @status NeedsChange  Added javadoc for locale, prevException and 
    *                      driverType params.
    */
    public ConnectionException(Class resBundleClass, String errorCode, Object[] params, Locale locale, Throwable prevException, String driverType)
    {
        super(resBundleClass, errorCode, params, locale, prevException);
        m_driverType = driverType;
    }

   /**
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    * @param driverType The String representing the driver type of the 
    *                   Connection driver that is throwing the exception.
    *
    * @status NeedsChange  Added javadoc for driverType param.
    */
    public ConnectionException(Class resBundleClass, String errorCode, Object[] params, Throwable prevException, String driverType)
    {
        super(resBundleClass, errorCode, params, prevException);
        m_driverType = driverType;
    }

    /**
     * Constructor for an exception that cannot be localized and that passes
     * on an underlying exception.
     *
     * @param msg  The text of the error message.
     * @param prevException The exception that underlies this exception.
     * @param driverType The String representing the driver type of the 
     *                   Connection driver that is throwing the exception.
     *
     * @status NeedsChange  Added javadoc for driverType param.
     */
    public ConnectionException(String msg, Throwable prevException, String driverType)
    {
        super(msg, prevException);
        m_driverType = driverType;
    }

    /**
     * @hidden
     */
    public String getDriverType()
    {
        return m_driverType;
    }

    /**
     * @hidden
     */
    public String toString()
    {
        return getClass().getName() + ": " + getMessage();
    }
}