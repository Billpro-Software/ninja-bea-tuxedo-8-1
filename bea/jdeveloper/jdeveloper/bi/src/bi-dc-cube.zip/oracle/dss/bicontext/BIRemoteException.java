/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.text.MessageFormat;

import oracle.dss.util.BIBaseException;
import oracle.dss.util.BIExceptionSupport;

/**
 * Indicates a problem with a driver on the middle tier.
 *
 * @status documented
 */
public class BIRemoteException extends BIBaseException 
implements ExtendedBIException
{
    private Locale m_locale = null;
    private Class m_resBundleClass = null;
    private String m_errorCode = "";
    private Object[] m_errorParams = null;
    private String m_baseMsg = null;

    private static Hashtable m_bundles = new Hashtable();

   /**
    * @hidden
    * Constructor for a formattable, localizable exception for a specific locale
    * that passes on a previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale The locale in which this message should localized.
    * @param prevException  The exception that underlies this exception.
    */
    public BIRemoteException(Class resBundleClass, String errorCode, Object[] params, Locale locale, Throwable prevException)
    {
        super("", prevException);
        m_resBundleClass = resBundleClass;
        m_errorCode = errorCode;
        m_errorParams = params;
        if (locale == null)
            m_locale = Locale.getDefault();
        else
            m_locale = locale;
    }

   /**
    * @hidden
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    */
    public BIRemoteException(Class resBundleClass, String errorCode, Object[] params, Throwable prevException)
    {
        this(resBundleClass, errorCode, params, Locale.getDefault(), prevException);
    }

   /**
    * @hidden
    * Constructor for an exception that cannot be localized and that passes
    * on an underlying exception.
    *
    * @param message  The text of the error message.
    * @param prevException The exception that underlies this exception.
    */
    public BIRemoteException(String message, Throwable prevException)
    {
        super(message, prevException);
        m_baseMsg = message;
    }

   /**
    * @hidden
    * Indicates whether the message for this exception can be localized.
    *
    * @return <code>true</code> if the message can be localized,
    *         <code>false</code> if it cannot.
    */
    public boolean isLocalizable()
    {
        return (m_resBundleClass != null);
    }

   /**
    * Retrieves a message that is localized for the default locale.
    *
    * @return The localized message.
    *
    * @status documented
    */
    public String getMessage()
    {
        return getLocalizedMessage();
    }

   /**
    * Retrieves a message that is localized for the default locale
    * that was set in the exception.
    *
    * @return The localized message.
    *
    * @status documented
    */
    public String getLocalizedMessage()
    {
        return getLocalizedMessage(m_locale);
    }

   /**
    * @hidden
    * Retrieves a message that is localized for a specified <code>Locale</code>.
    *
    * @param l The locale whose translation to retrieve.
    *
    * @return The localized message.
    */
    public String getLocalizedMessage(Locale l)
    {
        if (!isLocalizable())
            return m_baseMsg;

        String fmtString = getErrorMsgFormat(l);
        Object[] params = getErrorParameters();

        //
        // MessageFormat is _supposed_ to use toString on things
        // that it doesn't know about, unfortunately it doesn't
        // do this correctly, so we work around that here.
        //
        if (params != null)
        {
            for (int i = params.length - 1; i >= 0; i--)
            {
                Object param = params[i];

                if (param != null && !(param instanceof String ||
                                       param instanceof Number ||
                                       param instanceof Date))
                {
                    params[i] = param.toString();
                }
                else  if (param == null)
                {
                    params[i] = "" + param;
                }
            }
        }

        String _msg = getErrorMsg(l, params);

        return MessageFormat.format(fmtString, new Object[] { getProductCode(), getErrorCode(), _msg });
    }

    /**
     * @hidden
     */
    protected String getErrorMsg(Locale locale, Object[] params)
    {
        String _bundle = m_resBundleClass.getName();
        MsgBundleKey _bKey = new MsgBundleKey(locale, m_resBundleClass.getName());
        ResourceBundle _msgBundle = (ResourceBundle) m_bundles.get(_bKey);

        if (_msgBundle == null)
        {
            try
            {
                _msgBundle = ResourceBundle.getBundle(_bundle, locale);
            }
            catch(MissingResourceException ex)
            {
            }

	    // If _msgBundle is still null, give up but don't crack up
            if (_msgBundle == null)
                return getErrorCode();

             m_bundles.put(_bKey, _msgBundle);
        }

        return MessageFormat.format(_msgBundle.getString(getErrorCode()), params);
    }

    protected String getErrorMsgFormat(Locale l)
    {
        return (m_errorCode.length() == 0) ? "{2}" : "{0}-{1} {2}";
    }

   /**
    * @hidden
    * Retrieves the parameters for the error message.
    *
    * @return An array that contains an object for each token in the
    *         error message.
    */
    public Object[] getErrorParameters()
    {
        return m_errorParams == null ? new Object[0] : (Object[])m_errorParams.clone();
    }

   /**
    * @hidden
    * Retrieves the error code for this exception.
    * The error code is the key into the resource bundle for the message.
    *
    * @return The error code for this exception.
    */
    public String getErrorCode()
    {
        return m_errorCode;
    }

   /**
    * @hidden
    * Retrieves the product code for this exception.
    *
    * @return The product code for this exception.
    */
    public String getProductCode()
    {
        return "DVT";
    }
    
    // these package methods are for NamingException which aggregates
    // BIRemoteException
    String toString(Throwable exception) 
    {
        if (exception != null)
            return m_support.toString(exception);
        else
            return m_support.toString(this);
    }

    Throwable getBIRootCause(Throwable exception) 
    {
        if (exception != null)
            return m_support.getBIRootCause(exception);
        else
            return m_support.getBIRootCause(this);
    }

    Throwable elementAt (int index, Throwable exception) 
    {
        if (exception != null)
            return m_support.elementAt(index, exception);
        else
            return m_support.elementAt(index, this);
    }

    Enumeration elements(Throwable exception) 
    {
        if (exception != null)
            return m_support.elements(exception);
        else
            return m_support.elements(this);
    }

    private void writeObject(ObjectOutputStream out) throws IOException
    {
        String _msg = getLocalizedMessage();
        String _errorCode = getErrorCode();
        Object[] _errParams = getErrorParameters();

        if (_msg == null)
            _msg = "";

        out.writeUTF(_msg);
        out.writeUTF(_errorCode);
        out.writeInt(_errParams.length);

        for (int j = 0; j < _errParams.length; j++)
        {
            out.writeObject(_errParams[j]);
        }

        out.writeObject(m_support);
    }

   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
   {
      m_baseMsg = in.readUTF();
      m_errorCode = in.readUTF();
      m_errorParams = new Object[in.readInt()];

      for (int j = 0; j < m_errorParams.length; j++)
      {
         m_errorParams[j] = in.readObject();
      }

      m_support = (BIExceptionSupport)in.readObject();
   }
   
private static final class MsgBundleKey
{
   private final Locale loc;
   private final String bundleName;
   private int    hashcode = -1;

   MsgBundleKey(Locale l, String b)
   {
      loc = l;
      bundleName = b;
   }

   public int hashCode()
   {
      if (hashcode == -1)
      {
         hashcode = loc.hashCode() ^ bundleName.hashCode();
      }

      return hashcode;
   }

   public boolean equals(Object other)
   {
      if (!(other instanceof MsgBundleKey))
      {
         return false;
      }

      MsgBundleKey otherKey = (MsgBundleKey) other;

      return loc.equals(otherKey.getLocale()) &&
             bundleName.equals(otherKey.getBundleName());
   }

   public Locale getLocale()
   {
      return loc;
   }

   public String getBundleName()
   {
      return bundleName;
   }
}
}

