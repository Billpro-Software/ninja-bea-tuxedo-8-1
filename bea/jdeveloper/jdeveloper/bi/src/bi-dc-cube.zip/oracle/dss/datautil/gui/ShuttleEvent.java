/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/ShuttleEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui;

import java.awt.AWTEvent;

/**
 * <pre>
 * <code>ShuttleEvent</code>s.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/06/07 - Fix Bug 6656686 - Double click on items in the QB
 *                         should shuttle them over to the select.
 */
public class ShuttleEvent extends AWTEvent {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Constant indicating that an Selected operation has taken place.
   * 
   * @status new
   */
  public static final int SELECTED = 0;

  /**
   * Constant indicating that an Add operation has taken place.
   * 
   * @status new
   */
  public static final int ADD = 1;

  /**
   * Constant indicating that an Add All operation has taken place.
   * 
   * @status new
   */
  public static final int ADD_ALL = 2;

  /**
   * Constant indicating that a Remove operation has taken place.
   * 
   * @status new
   */
  public static final int REMOVE = 4;

  /**
   * Constant indicating that a Remove All operation has taken place.
   * 
   * @status new
   */
  public static final int REMOVE_ALL = 8;

  /**
   * Constant indicating that a Double Click operation has taken place.
   * 
   * @status new
   */
  public static final int DOUBLE_CLICK = 16;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>ShuttleEvent</code> Constructor.
   * 
   * @param objSource A <code>Object</code> representing the object that the
   *        <code>ShuttleEvent</code> is associated with.
   * @param nID A <code>int</code> representing the ID of the <code>ShuttleEvent</code>.
   * 
   * @see oracle.dss.datautil.gui.ShuttleEvent#SELECTED
   * @see oracle.dss.datautil.gui.ShuttleEvent#ADD
   * @see oracle.dss.datautil.gui.ShuttleEvent#ADD_ALL
   * @see oracle.dss.datautil.gui.ShuttleEvent#REMOVE
   * @see oracle.dss.datautil.gui.ShuttleEvent#REMOVE_ALL
   * 
   * @status new
   */
  public ShuttleEvent (Object objSource, int nID) {
    super (objSource, nID);
  }
}
