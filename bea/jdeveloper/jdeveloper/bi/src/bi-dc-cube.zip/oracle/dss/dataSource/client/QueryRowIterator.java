/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryRowIterator.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     11/08/07 - 
    jramanat    06/15/06 - Creation
 */

package oracle.dss.dataSource.client;

import oracle.dss.util.transform.TransformException;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryRowIterator.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public interface QueryRowIterator extends CloneableRowIterator {
  // Retrieves the raw value for a column
  public Object getValue(Object columnKey) throws TransformException;
}