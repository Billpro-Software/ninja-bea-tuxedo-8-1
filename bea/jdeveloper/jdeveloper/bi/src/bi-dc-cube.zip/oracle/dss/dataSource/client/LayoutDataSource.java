/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.client;

import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.metadataManager.common.MetadataManagerException;


/**
 * @hidden
 * Data Source clone maintainer for layout
 */
class LayoutDataSource extends Object
{
    /**
     * Data Source reference
     */
    protected transient Query m_query   = null;
    
    private boolean m_empty = false;    

    protected transient boolean m_cursorEvaluation = false;
    
    /**
     * @hidden
     * Data Source copy to store layouts
     */
    private transient Query m_ds = null;

    /**
     * Constructor.
     */
    public LayoutDataSource(Query ds) {
        m_query = ds;        
    }
                
    public Query getDataSource()
    {
        if (m_ds == null) {
            // Make sure data source doesn't create a default query if
            // there's not one there...
            boolean tempQuery = m_query.isDefaultQuery();
            m_query.setDefaultQuery(false);
                
            // This might be the wrong kind of director if the view isn't cube-centric!
            // Layout work implies QB is view-knowledgable
            try {
                createDataSource();
            }
            catch (Exception e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
                
            m_query.setDefaultQuery(tempQuery);            
        }
        return m_ds;
    }    
    
    public boolean isEmpty() {
        return m_empty;
    }
    
    public void setEmpty(boolean empty) {
        m_empty = empty;
    }
    
    public boolean isInitialized() {
        return m_ds != null;
    }
    
    public void release() {
        if (m_ds != null) {
            m_ds.close();
        }
    }
    
    protected void setCursorEvaluation(boolean on) throws MetadataManagerException, QueryException   {
        m_cursorEvaluation = on;
        if (m_ds != null)
        {
            m_ds.setEvaluateCursor(m_cursorEvaluation);
        }
    }
    
    private void createDataSource() throws MetadataManagerException, QueryException, CloneNotSupportedException
    {
        // Copy the selected data source into the layout ds
        m_ds = (Query)m_query.clone(m_cursorEvaluation);
        // Make sure m_ds uses its own properties, not the asynch/event properties inherited
        try
        {
            m_ds.setProperty(QueryConstants.PROPERTY_ASYNCHRONOUS, new Boolean(false));
            m_ds.setProperty(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS, new Boolean(true));
        }
        catch (Exception e)
        {
            throw new CloneNotSupportedException(e.getMessage());
        }
        // Clean out the selections
/*        String measDim = m_query.getMeasureDim();
        
        if (measDim != null)
            m_empty = m_ds.findSelection(measDim) == null;
        else*/
            m_empty = m_ds.getDataItems() == null;
            
        //m_ds.applySelections(null);
        m_ds.setEvaluateCursor(m_cursorEvaluation);
        // Add listeners to the layout Query
//        listenToLayoutQuery();
    }            
    
}