/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/filter/util/DefaultBIContext.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.filter.util;

import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;

import oracle.dss.bicontext.Acl;
import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BIOperationNotSupportedException;
import oracle.dss.bicontext.ImpactReport;
import oracle.dss.bicontext.Privilege;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

import oracle.dss.util.persistence.Persistable;

/**
 * @hidden
 * 
 * <pre>
 * This is an abstract base class that contains a default implementation for
 * <code>BIContext</code>.  This is particularly useful when a class only
 * needs to implement a small subset of the functionality exposed by
 * <code>BIContext</code>.
 * </pre>
 *
 * @author gkellam
 * @since  11.0.0.0.17
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   01/17/06 - QueryBuilder item filter integration. 
 *    gkellam   01/17/06 - QueryBuilder item filter integration. 
 *
 */
public abstract class DefaultBIContext implements BIContext {

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * BIContext methods
   */
  public void refresh() throws NamingException {
  }
  
  public Acl getAcl() throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void move(Name name, DirContext context) throws NamingException {
  }
  
  public void move(String name, DirContext context) throws NamingException {
  }
  
  public void copy(Name name, DirContext context, Name newName, int mode) throws NamingException {
  }
  
  public void copy(String name, DirContext context, String newName, int mode) throws NamingException {
  }
  
  public NamingEnumeration search(String name, Attributes matchingAttributes, 
                                  SearchControls searchControls) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public NamingEnumeration search(Name name, Attributes matchingAttributes, 
                                  SearchControls searchControl) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object lookup(String name, Persistable persistable) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object lookup(Name name, Persistable persistable) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object lookup(String name, Persistable persistable, Hashtable args) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object lookup(Name name, Persistable persistable, Hashtable args) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Locale getLocale() {
    return null;
  }
  
  public void setLocale(Locale locale) {
  }
  
  public boolean addEntries(Name name, Vector entries, boolean cascadeToSubFolders, 
                            boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean addEntries(String name, Vector entries, boolean cascadeToSubFolders, 
                            boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean removeEntries(Name name, Vector entries, boolean cascadeToSubFolders, 
                               boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean removeEntries(String name, Vector entries, boolean cascadeToSubFolders, 
                               boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean setEntries(Name name, Vector entries, boolean cascadeToSubFolder, 
                            boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean setEntries(String name, Vector entries, boolean cascadeToSubFolder, 
                            boolean cascadeToObjects) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Vector entries(Name name) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Vector entries(String name) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Vector getAllUsers() throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Privilege getPrivilege(Name name) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Privilege getPrivilege(String name) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public boolean getFeature(String feature) {
    return false;
  }
  
  public void bind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void bind(Name name, Object object, Attributes attrs, Hashtable env) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void rebind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void rebind(Name name, Object object, Attributes attrs, Hashtable env) throws NamingException {
    throw new BIOperationNotSupportedException (MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  /**
   * DirContext
   */
  public void destroySubcontext(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void destroySubcontext(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public ImpactReport rebindImpact(Name name, Object obj, Attributes attrs, boolean dryRun) {
    return null;
  }
  
  public ImpactReport rebindImpact(Name name, Object obj, boolean dryRun) {
    return null;
  }
  
  public ImpactReport rebindImpact(String name, Object obj, Attributes attrs, boolean dryRun) {
    return null;
  }
  
  public ImpactReport rebindImpact(String name, Object obj, boolean dryRun) {
    return null;
  }
  
  public ImpactReport unbindImpact(Name name, boolean dryRun) {
    return null;
  }
  
  public ImpactReport unbindImpact(String name, boolean dryRun) {
    return null;
  }
  
  public void close() throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object addToEnvironment(String propName, Object propVal) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public NamingEnumeration search(Name name, Attributes matchingAttributes, String[] attributesToReturn)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(String name, Attributes matchingAttributes, String[] attributesToReturn)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(Name name, Attributes matchingAttributes)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(String name, Attributes matchingAttributes)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(Name name, String filter, SearchControls cons)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(String name, String filter, SearchControls cons)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(Name name, String filterExpr, Object[] filterArgs, SearchControls cons)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration search(String name, String filterExpr, Object[] filterArgs, SearchControls cons)
    throws NamingException {
      throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
        MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext getSchema(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext getSchema(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext getSchemaClassDefinition(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext getSchemaClassDefinition(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Attributes getAttributes(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Attributes getAttributes(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Attributes getAttributes(Name name, String[] attrIds) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Attributes getAttributes(String name, String[] attrIds) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void modifyAttributes(Name name, int mod_op, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void modifyAttributes(String name, int mod_op, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void modifyAttributes(Name name, ModificationItem[] mods) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void modifyAttributes(String name, ModificationItem[] mods) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public String getNameInNamespace() throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object removeFromEnvironment(String propName) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Hashtable getEnvironment() throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Name composeName(Name name, Name prefix) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public String composeName(String name, String prefix) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NameParser getNameParser(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NameParser getNameParser(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Object lookupLink(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Object lookupLink(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public NamingEnumeration listBindings(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration listBindings(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public NamingEnumeration list(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public NamingEnumeration list(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Object lookup(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public Object lookup(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void bind(Name name, Object obj) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void rebind(Name name, Object obj) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void unbind(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void rename(Name oldName, Name newName) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void rename(String oldName, String newName) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void endConsistentRead() {
  }
  
  public void startConsistentRead() {
  }

  public Context createSubcontext(Name name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public Context createSubcontext(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void unbind(String name) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void rebind(String name, Object obj, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void rebind(Name name, Object obj, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void bind(String name, Object object) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void rebind(String name, Object object) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
  
  public void bind(Name name, Object obj, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public void bind(String name, Object obj, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext createSubcontext(Name name, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }

  public DirContext createSubcontext(String name, Attributes attrs) throws NamingException {
    throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, 
      MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null);
  }
}
