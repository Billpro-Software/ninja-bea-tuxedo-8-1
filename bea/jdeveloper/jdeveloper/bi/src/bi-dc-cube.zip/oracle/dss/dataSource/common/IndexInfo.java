/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.common;

/**
 * @hidden
 */
public class IndexInfo extends Object
{
    // Original slice at which this range of suppressed slices starts
    protected long m_startSlice = -1;
    // Number of consecutive slices suppressed in this range, including m_startSlice
    protected long m_size = -1;
    // Cumulative number of slices suppressed since slice 0, including this range
    protected long m_cumulativeSupp = -1;
    
    public IndexInfo(long startSlice, long size, long cumulativeSlicesSuppressed)
    {
        super();
        m_startSlice = startSlice;
        m_size = size;
        m_cumulativeSupp = cumulativeSlicesSuppressed;
    }
    
    public long getStartSlice()
    {
        return m_startSlice;
    }
    
    public long getSuppressedCount()
    {
        return m_size;
    }
    
    public long getSliceToSearch(boolean searchSuppressed)
    {
        long startSlice = getStartSlice();
        if (searchSuppressed)
        {
            // Must subtract the cumulative slices suppressed before this range
            return startSlice - (m_cumulativeSupp - m_size);
        }
        return startSlice;
    }
    
    // Add a new suppressed slice to the "end" of this run
    public void addToRun()
    {
        // Additional slice
        m_size++;
        // That's one more we're suppressing up to now
        m_cumulativeSupp++;
    }
    
    // Return the cumulative suppressed slices up to but not including a specific original slice
    public long getCumulativeSlicesSuppressedForOriginal(long originalSlice, boolean includeOriginal)
    {
        if (originalSlice == -1)
            return m_cumulativeSupp;
        
        // If the slice we're checking is greater than the max represented by this range, then return the max
        if (includeOriginal)        
        {
            if (originalSlice >= m_startSlice + m_size - 1)
                return m_cumulativeSupp;
        }
        else
        {
            if (originalSlice > m_startSlice + m_size - 1)
                return m_cumulativeSupp;
        }
        
/*        // If the slice we're checking is the initial one in the range, return 1
        if (originalSlice == m_startSlice)
            return 1;*/
            
        // Otherwise, the maximum number suppressed in the range must be tempered by where the originalSlice falls
        // within the range
        // Temper the reduction by 1 if we want to include the original slice's contribution in the number
        // of suppressed slices.  We know that the original is "in range" of this group because of the 
        // test above
        long positionalReduction = m_size - (originalSlice - m_startSlice) - (includeOriginal ? 1 : 0);
    
        return m_cumulativeSupp - positionalReduction;
    }

    // Return the cumulative suppressed slices up to but not including a specific suppressedSlice slice
    public long getCumulativeSlicesSuppressedForTransformed(long suppressedSlice)
    {
        return m_cumulativeSupp;
    }

    public String toString()
    {
        return "Suppress slices " + m_startSlice + "-" + (m_startSlice + m_size - 1) + ".  Cumulatively: " + m_cumulativeSupp;
    }
}
