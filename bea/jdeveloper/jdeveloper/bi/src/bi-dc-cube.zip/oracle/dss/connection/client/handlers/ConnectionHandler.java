/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.connection.client.handlers;

import oracle.dss.metadataUtil.PropertyBag;

/**
 * @hidden
 */
public interface ConnectionHandler
{
    public abstract Object handleGetRemoteConnection(Object remoteConnection, PropertyBag properties);
    public abstract Object handleSetRemoteConnection(Object remoteConnection, PropertyBag properties);
}
