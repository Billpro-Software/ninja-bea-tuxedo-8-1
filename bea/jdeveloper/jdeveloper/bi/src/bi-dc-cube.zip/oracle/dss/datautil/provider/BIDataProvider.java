/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/provider/BIDataProvider.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.provider;

import java.util.Vector;

import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.QueryEditor;
import oracle.dss.datautil.QueryEditorException;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.util.DataAccess;

/**
 * <pre>
 * Default <code>DataProvider</code> implementation for BI Beans.
 * </pre>
 *
 * @see oracle.dss.datautil.provider.DataProvider
 * 
 * @author gkellam 
 * @since  11.0.0.0.3
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *  bmoroze     03/15/07 - 
 *  gkellam     03/06/07 - Provide more DataAccess options used to control data
 *                         retrieval.
 *  rbalexan    10/28/05 - Remove apply method - moved to QB model.
 *  jramanat    09/23/05 - 
 *  gkellam     08/22/05 - 
 *  rbalexan    07/12/05 - default implementation of apply 
 *  rbalexan    07/07/05 - 
 *  gkellam     06/23/05 - Initial R11 CalcBuilder framework. 
 *  gkellam     06/17/05 - Creation
 */
public class BIDataProvider implements DataProvider {

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  private BIProvider m_biProvider = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default constructor.
   *
   * @status new
   */
  public BIDataProvider(BIProvider biProvider) {
    m_biProvider = biProvider;
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specfies the <code>BIProvider</code>.
   * 
   * @param biProvider A <code>BIProvider</code> that provides data.
   * 
   * @status new 
   */
  public void setBIProvider (BIProvider biProvider) {
    m_biProvider = biProvider;
  }

  /**
   * Retrieves the <code>BIProvider</code>.
   * 
   * @return A <code>BIProvider</code> that provides data.
   * 
   * @status new 
   */
  public BIProvider getBIProvider() {
    return m_biProvider;
  }

  /**
   * Retrieve Item members.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for.
   * @param strLabelType A <code>String</code> representing the label type.
   * 
   * @return <code>Vector</code> of item members.
   * 
   * @throws <code>QueryEditorException</code>
   */
  public Vector getMembers (String strItemID, String strLabelType) throws QueryEditorException {
    if (m_biProvider != null && m_biProvider.getQueryEditor() != null) {

        // blm - Selection code moved to dvt-olap
/*      Selection selection = 
        m_biProvider.getQueryEditor().getSelection (strItemID, 0);*/
      
      String strHierarchyID = null;
      
        // blm - Selection code moved to dvt-olap
/*      if (selection != null) {
        strHierarchyID = selection.getHierarchy();
      }*/

      return m_biProvider.getQueryEditor().getValues (
        strItemID, 0, strHierarchyID, strLabelType, 10);
    }

    return null;
  }

  /**
   * Retrieve a <code>DataAccess</code> from a <code>Selection</code>.
   * 
   * @param selection A <code>Selection</code> used to retrieve a <code>DataAccess</code>
   *        for.
   * 
   * @return <code>DataAccess</code>
   * 
   * @throws QueryEditorException
   */
   // blm - Selection code moved to dvt-olap
/*  public DataAccess getDataAccess (Selection selection) throws QueryEditorException {
    DataAccess dataAccess = null;
    QueryEditor queryEditor = getQueryEditor();

    if (queryEditor != null) {
      dataAccess = queryEditor.getDataAccess (selection);
    }

    return dataAccess;
  }*/


  /**
   * Retrieve a <code>DataAccess</code> from a Item ID.
   * 
   * @param strItemID A <code>String</code> representing an item ID.
   * 
   * @return <code>DataAccess</code>
   * 
   * @throws <code>QueryEditorException</code>
   */
  public DataAccess getDataAccess (String strItemID) throws QueryEditorException {
    return getDataAccess (strItemID, 0);
  }

  /**
   * Retrieves a <code>DataAccess</code> object that contains dimension
   * member metadata positioned at the stored selection for the specified
   * item.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for.
   * @param nInstance A <code>int</code> which represents the caller-defined ID 
   *        that determines which item DataAccess to get.
   * 
   * @return A <code>DataAccess</code> object that contains the specified
   *         item; an empty <code>DataAccess</code> object, which
   *         contains zero values, if there is no selection available to
   *         evaluate.
   *
   * @throws QueryEditorException thrown if an error occurs.
   * 
   * @status New
   */
  public DataAccess getDataAccess (String strItemID, int nInstance) throws QueryEditorException {
    DataAccess dataAccess = null;
    QueryEditor queryEditor = getQueryEditor();

    if (queryEditor != null) {
      dataAccess = queryEditor.getDataAccess (strItemID, nInstance);
    }

    return dataAccess;
  }

  /**
   * Retrieves the <code>DataAccess</code> object for a specified item (LOV query) 
   * and optional set of data filters.
   * 
   * @param strItemID A <code>String</code> representing the item or dimension ID
   *        to return members for.
   * @param dataFilters A <code>BaseDataFilter[]</code> which specifies data filters 
   *        to use in the LOV query.
   * @return A <code>DataAccess</code>.
   *
   * @status new
   */
  public DataAccess getDataAccess (String strItemID, BaseDataFilter[] dataFilters) {
    DataAccess dataAccess = null;
    QueryEditor queryEditor = getQueryEditor();

    if (queryEditor != null) {
      dataAccess = queryEditor.getDataAccess (strItemID, dataFilters);
    }

    return dataAccess;
  }

  /**
   * Retrieves the <code>QueryEditor</code> object associated with this
   * <code>BIDataProvider</code>.
   * 
   * @return A <code>QueryEditor</code>.
   *
   * @status new
   */
  public QueryEditor getQueryEditor () {
    QueryEditor queryEditor = null;

    if (m_biProvider != null) {
      queryEditor = m_biProvider.getQueryEditor();

      if (queryEditor == null) {
        QueryContext queryContext = m_biProvider.getQueryContext();
        
        if (queryContext != null) {
          queryEditor = queryContext.createQueryEditor();
          m_biProvider.setQueryEditor (queryEditor);
        }
      }
    }
    
    return queryEditor;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
