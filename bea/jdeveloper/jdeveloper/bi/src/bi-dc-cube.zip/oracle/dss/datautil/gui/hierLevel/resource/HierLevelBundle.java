/*
 * QueryBuilderBundle.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel.resource;

import java.util.ListResourceBundle;

/**
 * @hidden
 */

public class HierLevelBundle extends ListResourceBundle
{
  static final Object[][] resources =
  {

    // Hierarchy/Level resources
    {"strAllLevels",        "All Levels"},
    {"strAllToken",         "All {0}"},
    {"strNoHierarchy",      "List"},
    {"strLevelsAndHierarchy",   "{0} in {1}"},
  	{"strHierarchyPanelCaption", "Select a hierarchy of {0} to which you want the condition to apply."},
  	{"strHierarchyLevelPanelCaption", "Select a hierarchy and a level of {0} to which you want the condition to apply."},
  	{"strHierarchyLevelsPanelCaption", "Select a hierarchy and levels of {0} to which you want the condition to apply."},
  	{"strLevelPanelCaption", "Select a level of {0} to which you want the condition to apply."},
  	{"strLevelsPanelCaption", "Select levels of {0} to which you want the condition to apply."},
  	{"strHierarchy",		"\''{0}\'' hierarchy"},
    {"titleLevels",         "&Levels: "},
    {"titleHierarchy",      "H&ierarchy: "},

    // The sign for the percent setting
    {"strPercent",              "%"},

    {"strMore",             "More..."},
    {"dialogTitle",         "Select Hierarchy/Levels"}
  };

  public Object[][] getContents()
  {
    return resources;
  }
}