/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;

/**
 * A client-side representation of a level in an analytic workspace.
 * An <code>MDLevel</code> provides, to a java client, information about
 * a level in a hierarchy in the workspace.
 * <P>
 * An OLAP level is a position in a hierarchy.
 * For example, a Time dimension might have a hierarchy that represents data
 * at the "Month," "Quarter," and "Year" levels.
 *
 * @see MDHierarchy
 *
 * @status Reviewed
 */
public class MDLevel extends MDObject {

    /**
     * @hidden
     * Constructor.
     * Application developers should never construct an <code>MDLevel</code>.
     * Levels are actually defined in the analytic workspace on the
     * server.
     * You cannot use the MetadataManager to create levels in the
     * workspace.
     * <P>
     * To find the <code>MDLevel</code> that you want, call the
     * <code>getLevel</code> or <code>getLevels</code> method of another object.
     * For example, to get the levels in a hierarchy, call
     * <code>MDHierarchy.getLevels</code>.
     *
     * @see MetadataManagerServices#getLevel
     * @see MDHierarchy#getLevels
     *
     * @status hidden
     */
    public MDLevel() {
        setObjectType(MM.LEVEL);
    }

    /**
     *
     * @hidden
     *
     */
    public MDLevel( MetadataManagerServices mmServices, String levelName, MDObject parent ) {
        super( mmServices, levelName, parent );
        setObjectType(MM.LEVEL);
    }

  	/**
     * Retrieves the hierarchy that contains this level.
     *
     * @return The hierarchy that contains this level.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDHierarchy getHierarchy() throws MetadataManagerException {
		  return (MDHierarchy)super.getParent();
  	}

  	/**
     * Retrieves the attributes that apply to this level.
     *
     * @return The attributes that apply to this level.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDAttribute[] getAttributes() throws MetadataManagerException {
		  return MDAttribute.getAttributeArray(getRelatives(MM.ATTRIBUTE));
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setAttributes(MDAttribute[] attributes) {
  		if ( (attributes == null) || (attributes.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<attributes.length; i++) {
  			setRelative(attributes[i], MM.ATTRIBUTE);
  		}
		return MDU.SUCCESS;
  	}

    /**
     * Retrieves the data type of this level.
     *
     * @return A constant that represents the datatype.
     *
     * @see MM#BOOLEAN
     * @see MM#SHORT
     * @see MM#INTEGER
     * @see MM#LONG
     * @see MM#FLOAT
     * @see MM#DOUBLE
     * @see MM#STRING
     *
     * @status Reviewed
     */
  	public String getDataType() {
		  return getStrPropertyValue(MM.DATA_TYPE);
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setDataType(String dataType) {
	    if ((dataType != MM.BOOLEAN) && (dataType != MM.SHORT) &&
	        (dataType != MM.INTEGER) && (dataType != MM.LONG) &&
	        (dataType != MM.FLOAT) && (dataType != MM.DOUBLE) &&
	        (dataType != MM.STRING)) {
	    	return (MDU.FAILURE);
		}
  		setStrPropertyValue(MM.DATA_TYPE, dataType, MDU.UI_ALL);
		return MDU.SUCCESS;
  	}
  	
    /**
     *
     * @hidden
     *
     */
  	public static MDLevel[] getLevelArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDLevel[] levels = new MDLevel[objects.length];
		for (int i=0; i<objects.length; i++) {
			levels[i] = (MDLevel)objects[i];
		}
		return levels;		
	}
  
    /**
     *
     * @hidden
     *
     */
  	public static MDLevel[] getLevelArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDLevel[] levels = new MDLevel[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			levels[i] = (MDLevel)propertyBag[i];
		}
		return levels;		
	}

    /**
     * Typically specifies the current member for a level on a
     * time dimension.
     *
     * @param currentMember  String that represents the currentMember
     *
     * @status Documented
     */
    public void setCurrentMember(String currentMember)
    {
        setStrPropertyValue(MM.CURRENT_MEMBER, currentMember);
    }

    /**
     * Typically retrieves the current member for a level on a
     * time dimension.
     *
     * @return currentMember  String that represents the currentMember.
     *
     * @status Documented
     */
    public String getCurrentMember()
    {
        return getStrPropertyValue(MM.CURRENT_MEMBER);
    }
}