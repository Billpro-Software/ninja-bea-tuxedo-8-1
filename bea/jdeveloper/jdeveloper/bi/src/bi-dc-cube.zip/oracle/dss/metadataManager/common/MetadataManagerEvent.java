/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import oracle.dss.metadataUtil.BaseEvent;

/**
 * Describes something that has happened in the MetadataManager.
 *
 * @status Reviewed
 */
public class MetadataManagerEvent extends BaseEvent {

  protected Object object;

  /**
   * @hidden
   * Constructor.
   *
   * @param source    The source of this event.
   * @param isConsumable  <code>true</code> if the event can be consumed,
   *                      <code>false</code> if it cannot be consumed.
   * @param generalObject  The object that has been affected by this event.
   *
   * @status hidden
   */
  public MetadataManagerEvent( Object source, boolean isConsumable, Object generalObject ) {
    super( source, isConsumable );
    object = generalObject;
  }

  /**
   * Retrieves the object that has been affected by the event.
   * The object might be a connection, a property bag, a metadata object,
   * or other object.
   *
   * @return  The object that has been affected.
   *
   * @status Reviewed
   */
  public Object getObject() {
     return object;
  }
}