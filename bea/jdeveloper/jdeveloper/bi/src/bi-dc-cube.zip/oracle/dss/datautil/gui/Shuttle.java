/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/Shuttle.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.event.EventListenerList;

import oracle.bali.ewt.graphics.ImageSet;
import oracle.bali.ewt.graphics.ImageSetIcon;
import oracle.bali.ewt.graphics.ImageStrip;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.Timer;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.resource.DataUtilGUIBundle;
import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.queryBuilder.AvailableItemsPanel;
import oracle.dss.queryBuilder.AvailableItemsTree;
import oracle.dss.queryBuilder.SelectedItemsTree;
import oracle.dss.queryBuilder.ShuttleList;
import oracle.dss.util.gui.component.ComponentNames;
import oracle.dss.util.gui.component.ComponentNode;


/**
 * @hidden
 *
 * <pre>
 * The Shuttle class handles moving the items from the available list to the
 * selected list. Both sides can contain multiple lists of items in which case
 * they are organized using tabs.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/10/07 - Continue to fix Bug 6656686 - Double click on items
 *                         in the QB should shuttle them over to the select.
 *    gkellam   12/06/07 - Fix Bug 6656686 - Double click on items in the QB
 *                         should shuttle them over to the select.
 *    gkellam   09/12/07 - Fix Bug 6034455 - QueryBuilder: 'Add/Remove Select
 *                         Values' should provide shortcuts/tool tips'.
 *    gkellam   07/24/07 - Continue DataFilter updates.
 *    gkellam   07/23/07 - Select Values updates.
 *    gkellam   07/22/07 - More DataFilter updates.
 *    gkellam   04/26/07 - Fix Bug 5941845 - Use standard buttons in
 *                         'definition' subsection of BI model flat editor.
 *    gkellam   04/18/07 - Fix Bug 5986113 - APPS3:EXCEPTION SHUTTLING ITEM
 *                         FOLDERS.
 *    gkellam   08/17/06 - Add shuttle item listener support.
 *    gkellam   01/19/06 - Do not allow users to shuttle disabled nodes.
 */
public class Shuttle extends JPanel implements ActionListener, ShuttleListener {
    
  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Constant indicating that the Shuttle should display the "Add" button.
   * Can be combined with other button constants and set on the Shuttle using
   * <code>setButtonsShown()</code>.
   * 
   * @status new
   */
  public static final int ADD_BUTTON = 1;

  /**
   * Constant indicating that the Shuttle should display the "Add All" button.
   * Can be combined with other button constants and set on the Shuttle using
   * <code>setButtonsShown()</code>.
   * 
   * @status new
   */
  public static final int ADD_ALL_BUTTON = 2;

  /**
   * Constant indicating that the Shuttle should display the "Remove" button.
   * Can be combined with other button constants and set on the Shuttle using
   * <code>setButtonsShown()</code>.
   * 
   * @status new
   */
  public static final int REMOVE_BUTTON = 4;

  /**
   * Constant indicating that the Shuttle should display the "Remove All" button.
   * Can be combined with other button constants and set on the Shuttle using
   * <code>setButtonsShown()</code>.
   * 
   * @status new
   */
  public static final int REMOVE_ALL_BUTTON = 8;

  /////////////////////
  //
  // Members
  //
  /////////////////////
   
  // Tabbed panes containing available and selected component arrays
  private Component m_componentAvailable = null;
  private Component m_componentSelected = null;
  
  // Holder panels that have the title at the top
  private HolderPanel m_holderPanelAvailable = null;
  private HolderPanel m_holderPanelSelected = null;               
  
  // Stores a resource cache.
  private ResourceCache m_resourceCache = new ResourceCache();

  private JSplitPane m_jSplitPane = null;
  private int m_nWidth = -1;
  
  // Buttons for adding and removing items.
  private JButton m_jButtonAdd = null;
  private JButton m_jButtonAddAll = null;
  private JButton m_jButtonRemove = null;
  private JButton m_jButtonRemoveAll = null;

  private boolean m_bSuperCalled = false;
  private EventListenerList m_shuttleListeners = null;
  private int m_nButtonsShown = 
    ADD_BUTTON | ADD_ALL_BUTTON | REMOVE_BUTTON | REMOVE_ALL_BUTTON;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
 
  /**
   * Shuttle constructor which creates a shuttle control using the given
   * components. If there are multiple shuttle components in the available and selected arrays,
   * the components are organized in tabbed panes.
   *
   * @param vComponentsAvailable A <code>Vector</code> of shuttle components which will 
   *        be put in a tabbed pane on the available side of the shuttle
   * @param vComponentsSelected A <code>Vector</code> of shuttle components which will 
   *        be put in a tabbed pane on the selected side of the shuttle
   *
   * @status new
   */
  public Shuttle (Vector vComponentsAvailable, Vector vComponentsSelected) {
  }

  /**
   * Shuttle constructor which creates a shuttle control using the given
   * components.
   *
   * @param componentAvailableSide A <code>Component</code> representing the 
   *        available side of the shuttle.
   * @param componentSelectedSide A <code>Component</code> representing the 
   *        selectedside of the shuttle.
   * 
   * @status new
   */
  public Shuttle (Component componentAvailableSide, Component componentSelectedSide) {
    this (componentAvailableSide, componentSelectedSide, null);
  }

  /**
   * Shuttle constructor which creates a shuttle control using the given
   * components.
   *
   * @param componentAvailableSide A <code>Component</code> representing the 
   *        available side of the shuttle.
   * @param componentSelectedSide A <code>Component</code> representing the 
   *        selected side of the shuttle.
   * @param componentSelectedSideToolbar A <code>Component</code> representing an 
   *        optional selected side toolbar.
   * 
   * @status hidden
   */
  public Shuttle (Component componentAvailableSide, Component componentSelectedSide, 
                  Component componentSelectedSideToolbar) {
    this (componentAvailableSide, componentSelectedSide, null, componentSelectedSideToolbar);
  }

  /**
   * Shuttle constructor which creates a shuttle control using the given
   * components.
   *
   * @param componentAvailableSide A <code>Component</code> representing the 
   *        available side of the shuttle.
   * @param componentSelectedSide A <code>Component</code> representing the 
   *        selected side of the shuttle.
   * @param componentAvailableSideToolbar A <code>Component</code> representing an 
   *        optional available side toolbar.
   * @param componentSelectedSideToolbar A <code>Component</code> representing an 
   *        optional selected side toolbar.
   * 
   * @status hidden
   */
  public Shuttle (Component componentAvailableSide, Component componentSelectedSide, 
                  Component componentAvailableSideToolbar, Component componentSelectedSideToolbar) {
    m_bSuperCalled = true;
    setAvailableSide (componentAvailableSide);
    setSelectedSide (componentSelectedSide);
    initShuttleComponents (componentAvailableSideToolbar, componentSelectedSideToolbar);

    // Allow available side to listen to shuttle events  
    if (componentAvailableSide != null) {
      if (componentAvailableSide instanceof ShuttleListener) {
        addShuttleListener ((ShuttleListener)componentAvailableSide);  
      }
    }
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieve the <code>JButton</code> associated with the specified ID.
   * 
   * @param nButtonID A <code>int</code> representing the ID of the button to retrieve.
   * 
   * @return <code>JButton</code> associated with the specified ID.
   * 
   * @see #ADD_BUTTON
   * @see #ADD_ALL_BUTTON
   * @see #REMOVE_BUTTON
   * @see #REMOVE_ALL_BUTTON
   */
  public JButton getButton (int nButtonID) {
    JButton jButton = null;
    
    switch (nButtonID) {
      case ADD_BUTTON:
        jButton = m_jButtonAdd;
        break;

      case ADD_ALL_BUTTON:
        jButton = m_jButtonAddAll;
        break;

      case REMOVE_BUTTON:
        jButton = m_jButtonRemove;
        break;

      case REMOVE_ALL_BUTTON:
        jButton = m_jButtonRemoveAll;
        break;
        
      default:
        break;
    }
  
    return jButton;
  }

  /**
   * @hidden
   * Set the locale for this component.
   * 
   * @param locale The locale.
   *
   * @status hidden
   */
  public void setLocale (Locale locale) {
    super.setLocale(locale);

    if (!m_bSuperCalled) {
      return;
    }

    m_resourceCache.setLocale (locale);
    updateResources();
  }
    
  /**
   * @hidden
   *
   * Called when the Add or Remove buttons have been pressed.
   *
   * If the "Add" button was pressed, the selected nodes from the
   * currently active shuttle component on the available side are inserted
   * into all of the shuttle components on the selected side.
   *
   * If the "Remove" button was pressed, the selected nodes are removed
   * from the currently active shuttle component on the selected side.
   * 
   * @status hidden
   */
  public void actionPerformed (ActionEvent actionEvent) {
    Object objSource = actionEvent.getSource();
    
    if (actionEvent != null) {
      if ((objSource == m_jButtonAdd) || (objSource == m_jButtonAddAll) || 
          (objSource == m_jButtonRemove) || (objSource == m_jButtonRemoveAll)) {
        // Set the cursor to hourglass
        Utils.setParentWindowCursor (this, Cursor.WAIT_CURSOR);
        
        if (Timer.ON) {
          Timer.getTimer().start (((JButton)objSource).getToolTipText());
        }
        
        try {
          
          if (objSource == m_jButtonAdd) {
            // Insert the selected items from the available component
            // into the shuttle components on the selected side
            addItems();
            setFocus ((Component)getSelectedSide());
          
            // gek 08/18/06 Fire ShuttleEvent
            fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.ADD));
          } 
          else if (objSource == m_jButtonAddAll) {
            // Insert all items from the available component
            // into the shuttle components on the selected side
            addAllItems();
            setFocus ((Component)getSelectedSide());

            // gek 08/18/06 Fire ShuttleEvent
            fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.ADD_ALL));
          } 
          else if (objSource == m_jButtonRemove) {
            // Remove the selected items from the currently active
            // component on the selected side
            removeItems();
            setFocus ((Component)getSelectedSide());

            // gek 08/18/06 Fire ShuttleEvent
            fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.REMOVE));
          } 
          else if (objSource == m_jButtonRemoveAll) {
            // Remove all items from the currently active
            // component on the selected side
            removeAllItems();
            setFocus ((Component)getAvailableSide());

            // gek 08/18/06 Fire ShuttleEvent
            fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.REMOVE_ALL));
          }
        } 

        catch (Throwable throwable) {
          throwable.printStackTrace();
        }
        
        if (Timer.ON) {
          Timer.getTimer().stop (((JButton)objSource).getToolTipText());
        }
        
        // Set the cursor back to normal
        Utils.setParentWindowCursor (this, Cursor.DEFAULT_CURSOR);
      }
    }
  }

  /**
   * Updates the available side based on the contents of the selected side.
   *
   * For instance, nodes on the available side may dynamically enabled or
   * disabled based on what has been shuttled.
   *
   */
  public void updateAvailableSide() {
    Component componentAvailableSide = getAvailableSide();
    Component componentSelectedSide = getSelectedSide();
    Object[] objectsSelected = null;
    
    if (componentSelectedSide instanceof ShuttleComponent) {
      objectsSelected = ((ShuttleComponent) componentSelectedSide).getAllItems();
      
      if (componentAvailableSide instanceof ShuttleComponent) {
            
      }
    }
  }

  /**
   * @hidden
   * 
   * Updates the <code>Shuttle</code> button status based on the selected items.
   * 
   * @status hidden
   */
  public void updateEnabled() {
    if ((getAvailableSide() instanceof ShuttleComponent) && 
        (getSelectedSide() instanceof ShuttleComponent)) {
      
      if (m_jButtonAdd != null) {
        Object[] selectedItems = 
          ((ShuttleComponent)getAvailableSide()).getSelectedItems();
        
        m_jButtonAdd.setEnabled (((selectedItems != null) && (selectedItems.length > 0)) && 
          !hasDisabled (selectedItems) && !containsItemFolder (selectedItems));
      }
      
      if (m_jButtonAddAll != null) {
        Object[] selectedItems = 
          ((ShuttleComponent)getAvailableSide()).getSelectedItems();
        
        m_jButtonAddAll.setEnabled(((ShuttleComponent)getAvailableSide()).isSelectableItemPresent() && 
          !hasDisabled(selectedItems) && !containsItemFolder(selectedItems));
      }
      
      if (m_jButtonRemove != null) {
        Object[] selectedItems = 
          ((ShuttleComponent)getSelectedSide()).getSelectedItems();
        
        m_jButtonRemove.setEnabled (((selectedItems != null) && (selectedItems.length > 0)));
      }
      
      if (m_jButtonRemoveAll != null) {
        m_jButtonRemoveAll.setEnabled (
          ((ShuttleComponent)getSelectedSide()).isSelectableItemPresent());
      }
    }
  }

  /**
   * @hidden
   *
   * Determines whether any of the specified objects are disabled.
   *
   * @param objects A <code>Object[]</code> which contains the objects to check.
   *
   * @status hidden
   */
  public boolean hasDisabled (Object[] objects) {
    boolean bHasDisabled = false;
    
    if (objects != null) {
      for (int nIndex = 0; nIndex < objects.length; nIndex++) {
        if (objects[nIndex] instanceof ComponentNode) {
          ComponentNode componentNode = (ComponentNode)objects[nIndex];
          
          if (!componentNode.isEnabled()) {
            bHasDisabled = true;
            break;
          }
        } 
      }
    }
    
    return bHasDisabled;
  }

  /**
   * @hidden
   * 
   * Specify the <code>Component</code> which represents the available side of 
   * the shuttle.
   *
   * @param componentAvailableSide A <code>Component</code> which represents the 
   *        available side of the shuttle.
   * 
   * @status hidden
   */
  public void setAvailableSide (Component componentAvailableSide) {
    m_componentAvailable = componentAvailableSide;
  }

  /**
   * @hidden
   * Retrieve the <code>Component</code> which represents the available side of 
   * the shuttle.
   * 
   * @return <code>Component</code> which represents the available side of the 
   *         shuttle.
   *         
   * @status hidden
   */
  public Component getAvailableSide() {
    return m_componentAvailable;
  }
  
  /**
   * @hidden
   * 
   * Specify the <code>Component</code> which represents the selected side of 
   * the shuttle.
   *
   * @param componentSelectedSide A <code>Component</code> which represents the 
   *        selected side of the shuttle.
   * 
   * @status hidden
   */
  public void setSelectedSide (Component componentSelectedSide) {
    m_componentSelected = componentSelectedSide;
  }

  /**
   * @hidden
   * Retrieve the <code>Component</code> which represents the selected side of 
   * the shuttle.
   * 
   * @return <code>Component</code> which represents the selectedside of the 
   *         shuttle.
   *         
   * @status hidden
   */
  public Component getSelectedSide() {
    return m_componentSelected;
  }

  /**
   * @hidden
   * 
   * Specify the <code>ResourceCache</code>.
   *
   * @param resourceCache A <code>ResourceCache</code>.
   * 
   * @status hidden
   */
  public void setResourceCache (ResourceCache resourceCache) {
    m_resourceCache = resourceCache;
  }

  /**
   * @hidden
   * Retrieve the <code>ResourceCache</code>.
   * 
   * @return <code>ResourceCache</code>.
   *         
   * @status hidden
   */
  public ResourceCache getResourceCache() {
    return m_resourceCache;
  }

  /**
   * @hidden
   * Notification to this component that it now has a parent component. When this method is
   * invoked, the chain of parent components is set up with KeyboardAction event listeners.
   *
   * @status hidden
   */
  public void addNotify() {
    super.addNotify();
    
    updateResources();
    updateEnabled();
  } 

  // Implement the ShuttleListener interface.

  //.........................................................
  // Start - Implement the ShuttleListener interface.
  //.........................................................

  /**
   * Process Shuttle items selected <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing the items 
   *        selected.
   * 
   * @status new
   */
  public void shuttleItemsSelected (ShuttleEvent shuttleEvent) {
    updateEnabled();
    fireShuttleEvent (shuttleEvent);
  }
  
  /**
   * Process Shuttle items shuttled <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing the items 
   *        shuttled.
   * 
   * @status new
   */
  public void shuttleItemsShuttled (ShuttleEvent shuttleEvent) {
    fireShuttleEvent (shuttleEvent);
  }

  /**
   * Process Shuttle items double clicked <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing the items 
   *        double clicked.
   * 
   * @status new
   */
  public void shuttleItemsDoubleClicked (ShuttleEvent shuttleEvent) {
    fireShuttleEvent (shuttleEvent);

    if (shuttleEvent != null) {
      Object objSource = shuttleEvent.getSource();
      
      int nType = ShuttleList.TYPE_UNDEFINED;
      
      if (objSource instanceof ShuttleList) {
        nType = ((ShuttleList)objSource).getType();
      }
      
      if ((objSource instanceof AvailableItemsTree) || (nType == ShuttleList.TYPE_AVAILABLE)) {
        if ((m_jButtonAdd != null) && (m_jButtonAdd.isEnabled())) {
          // User has double clicked on an item in the available side, so turn this into
          // and ADD shuttle event.
  
          // Insert the selected items from the available component
          // into the shuttle components on the selected side
          addItems();
          setFocus ((Component)getSelectedSide());
        
          // Fire ShuttleEvent
          fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.ADD));
        }
      }
      else if ((objSource instanceof SelectedItemsTree) || (nType == ShuttleList.TYPE_SELECTED)) {
        // User has double clicked on an item in the selected side, so turn this into
        // and REMOVE shuttle event.

        // Remove the selected items from the currently active
        // component on the selected side
        removeItems();
        setFocus ((Component)getSelectedSide());

        // Fire ShuttleEvent
        fireShuttleEvent (new ShuttleEvent (this, ShuttleEvent.REMOVE));
      }
    }
  }

  //.........................................................
  // End - Implement the ShuttleListener interface.
  //.........................................................

  public JPanel getAvailableTitlePanel() {
    if (m_holderPanelAvailable != null) {
      return m_holderPanelAvailable.getTitlePanel();
    }

    return null;
  }
  
  public JPanel getSelectedTitlePanel() {
    if (m_holderPanelSelected != null) {
      return m_holderPanelSelected.getTitlePanel();
    }

    return null;
  }
  
  /**
   * @hidden
   * Set a mask of the constants indicating which of the Shuttle buttons
   * should be shown. The available buttons are: ADD_BUTTON, ADD_ALL_BUTTON,
   * REMOVE_BUTTON, and REMOVE_ALL_BUTTON.
   * <p>
   * By default, all four are shown.
   */
  public void setButtonsShown (int nButtonsShown) {
    m_nButtonsShown = nButtonsShown;
    updateButtonVisibility();
  }
  
  /**
   * @hidden
   * Returns a mask of the constants indicating which of the Shuttle
   * buttons are currently shown. The available buttons are: ADD_BUTTON,
   * ADD_ALL_BUTTON, REMOVE_BUTTON, and REMOVE_ALL_BUTTON.
   * <p>
   * By default, all four are shown.
   */
  public int getButtonsShown() {
    return m_nButtonsShown;
  }
  
  public void addShuttleListener (ShuttleListener listener) {
    m_shuttleListeners.add (ShuttleListener.class, listener);
  }
  
  public void removeShuttleListener (ShuttleListener listener) {
    m_shuttleListeners.remove (ShuttleListener.class, listener);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Retrieve a <code>ComponentContext</code>.
   * 
   * @return <code>ComponentContext</code>. 
   */
  protected ComponentContext getComponentContext () {
   ComponentContext componentContext = null;
  
   Object objAvailableSide = getAvailableSide();
   if (objAvailableSide instanceof AvailableItemsPanel) {
     AvailableItemsPanel availableDataPanel = 
       (AvailableItemsPanel) objAvailableSide;
    
      componentContext = availableDataPanel.getContext(); 
   }
  
   return componentContext;
  }

  /**
   * Retrieve a <code>MetadataManager</code>.
   * 
   * @return <code>MetadataManager</code>. 
   */
  protected MetadataManager getMetadataManager() {
    MetadataManager metadataManager = null;

    ComponentContext componentContext = getComponentContext();
    if (componentContext != null) {
      if (componentContext.getBIProvider() != null) {
        metadataManager = componentContext.getBIProvider().getMetadataManager();
      }
    }
  
    return metadataManager;
  }
  
  /**
   * Determines if the list contains an item folder.
   * 
   * @param objItems A <code>Object[]</code> of items to check.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the list
   *         contains an items folder and <code>false</code> otherwise. 
   */
  protected boolean containsItemFolder (Object[] objItems) {
    boolean bContainsItemFolder = false;

    if (objItems != null) {
          
      Object objItem = null;
      MDObject mdObject = null;
      ComponentNode componentNode = null;

      MetadataManager metadataManager = getMetadataManager();

      if (metadataManager != null) {
        for (int nIndex = 0; nIndex < objItems.length; nIndex++) {
          objItem = objItems [nIndex];            
          
          if (objItem instanceof ComponentNode) {
            componentNode = (ComponentNode) objItem;
    
            try {
              mdObject = 
                metadataManager.getMDObjectByUniqueID (componentNode.getValue().toString());
    
              if (mdObject instanceof MDItemFolder) {
                bContainsItemFolder = true;
                break;
              }
            }
    
            catch (MetadataManagerException metadataManagerException) {
              // Ignore exceptions
  
            }
          }
        }
      }
    }

    return bContainsItemFolder;
  }

  /**
   * Update the text for the buttons.
   *
   * @status private
   */
  protected void updateResources() {
    if (m_jButtonAdd != null) {
      m_jButtonAdd.setToolTipText (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_ADD));
    }
    
    if (m_jButtonAddAll != null) {
      m_jButtonAddAll.setToolTipText (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_ADD_ALL));
    }
    
    if (m_jButtonRemove != null) {
      m_jButtonRemove.setToolTipText (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_REMOVE));
    }
    
    if (m_jButtonRemoveAll != null) {
      m_jButtonRemoveAll.setToolTipText (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_REMOVE_ALL));
    }   
    
    if (m_holderPanelAvailable != null) {
      m_holderPanelAvailable.setTitle (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_AVAILABLE));
    }
    
    if (m_holderPanelSelected != null) {
      m_holderPanelSelected.setTitle (
        getResourceCache().getIntlString (DataUtilGUIBundle.SHUTTLE_SELECTED));
    }
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * Inializes the components for the shuttle.
   *
   * @param componentAvailableSideToolbar A <code>Component</code> representing an 
   *        optional available side toolbar.
   * @param componentSelectedSideToolbar A <code>Component</code> representing an 
   *        optional selected side toolbar.
   *
   * @status private
   */
  private void initShuttleComponents (Component componentAvailableSideToolbar, Component componentSelectedSideToolbar) {    
    // Create the Add button.
    Image image = 
      Utils.getImageResource (oracle.bali.ewt.elaf.oracle.OracleLookAndFeel.class, 
        "icons/rightArrow.gif");
    
    m_jButtonAdd = new JButton (new ImageSetIcon (new ImageStrip(image, ImageSet.STATE_SELECTED)));      
    m_jButtonAdd.setName (ComponentNames.SHUTTLE_ADD_BUTTON);
    m_jButtonAdd.setDisabledIcon (new ImageSetIcon (new ImageStrip(image, ImageSet.STATE_DISABLED)));
    m_jButtonAdd.setMargin (new Insets (0,0,0,0));
    m_jButtonAdd.addActionListener (this);

    // Create the Add All button.
    image = 
      Utils.getImageResource(oracle.bali.ewt.elaf.oracle.OracleLookAndFeel.class, 
        "icons/rightAllArrow.gif");
    
    m_jButtonAddAll = new JButton (new ImageSetIcon (new ImageStrip (image, ImageSet.STATE_SELECTED)));
    m_jButtonAddAll.setName (ComponentNames.SHUTTLE_ADD_ALL_BUTTON);
    m_jButtonAddAll.setDisabledIcon (new ImageSetIcon(new ImageStrip (image, ImageSet.STATE_DISABLED)));
    m_jButtonAddAll.setMargin (new Insets (0,0,0,0));
    m_jButtonAddAll.addActionListener (this);

    // Create the Remove button.
    image = 
      Utils.getImageResource(oracle.bali.ewt.elaf.oracle.OracleLookAndFeel.class, 
        "icons/leftArrow.gif");
    
    m_jButtonRemove = new JButton (new ImageSetIcon (new ImageStrip (image, ImageSet.STATE_SELECTED)));
    m_jButtonRemove.setName (ComponentNames.SHUTTLE_REMOVE_BUTTON);
    m_jButtonRemove.setDisabledIcon (new ImageSetIcon (new ImageStrip (image, ImageSet.STATE_DISABLED)));
    m_jButtonRemove.setMargin (new Insets(0,0,0,0));
    m_jButtonRemove.addActionListener (this);

    // Create the Add All button.
    image = 
      Utils.getImageResource(oracle.bali.ewt.elaf.oracle.OracleLookAndFeel.class, 
        "icons/leftAllArrow.gif");
    
    m_jButtonRemoveAll = new JButton (new ImageSetIcon (new ImageStrip(image, ImageSet.STATE_SELECTED)));
    m_jButtonRemoveAll.setName (ComponentNames.SHUTTLE_REMOVE_ALL_BUTTON);
    m_jButtonRemoveAll.setDisabledIcon (new ImageSetIcon (new ImageStrip (image, ImageSet.STATE_DISABLED)));
    m_jButtonRemoveAll.setMargin (new Insets (0,0,0,0));
    m_jButtonRemoveAll.addActionListener (this);
    
    m_shuttleListeners = new EventListenerList();
        
    layoutShuttleComponents (componentAvailableSideToolbar, componentSelectedSideToolbar);
  }

  private Component getFocusableComponent (Component c) {
    Component component = c;
    
    while (component instanceof JPanel) {
      if (((JPanel)component).getComponentCount() > 0) {
        component = ((JPanel)component).getComponent(0);
    
        if (component instanceof JScrollPane) {
          component = ((JScrollPane)component).getViewport().getView();
        }
      }
      else {
        break;
      }
    }
    
    return component;
  }

  private void setFocus (Component c) {
    Component component = getFocusableComponent(c);
    if (component != null) {
      component.requestFocus();
    }
  }

  // Insert the selected items from the available component
  // into all the shuttle components on the selected side

  private void addItems() {
    if ((m_componentAvailable instanceof ShuttleComponent) && 
        (m_componentSelected instanceof ShuttleComponent)) {

      try {
        // Insert the selected items from the available component
        // into the active component on the selected side
        ((ShuttleComponent)m_componentSelected).insertItems (
          ((ShuttleComponent)m_componentAvailable).getSelectedItems());

        // Clear the selection after having added it.
        ((ShuttleComponent)m_componentAvailable).clearSelection();
        updateEnabled();
      }
      
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  // Insert all items from the available component
  // into the shuttle components on the selected side

  private void addAllItems() {
    if ((m_componentAvailable instanceof ShuttleComponent) && 
        (m_componentSelected instanceof ShuttleComponent)) {
      
      try {
        // Insert the selected items from the available component
        // into the active component on the selected side
        ((ShuttleComponent)m_componentSelected).insertItems(
          ((ShuttleComponent)m_componentAvailable).getAllItems());

        // Clear the selection after having added it.
        ((ShuttleComponent)m_componentAvailable).clearSelection();
        updateEnabled();
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  // If the "Remove" button was pressed, remove the
  // selected nodes from the currently active component
  // on the selected side

  private void removeItems() {
    if (m_componentSelected instanceof ShuttleComponent) {
      ((ShuttleComponent)m_componentSelected).removeSelectedItems();
      updateEnabled();
    }
  }

  // Remove all items from the currently active
  // component on the selected side

  private void removeAllItems() {
    if (m_componentSelected instanceof ShuttleComponent) {
      ((ShuttleComponent)m_componentSelected).removeAllItems();
      updateEnabled();
    }
  }

  // Get a panel containing all the shuttle buttons layed out on a GridBag.

  private JPanel getButtonPanel() {
    JPanel jPanelButtons = new JPanel();
    jPanelButtons.setBorder (BorderFactory.createEmptyBorder(0, 4, 0, 5));
    
    GridBagLayout gridBagLayout = new GridBagLayout();
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    
    jPanelButtons.setLayout(gridBagLayout);
    gridBagConstraints.gridy = 0;
    gridBagLayout.setConstraints (m_jButtonAdd, gridBagConstraints);
    gridBagConstraints.gridy = 1;
    gridBagLayout.setConstraints (m_jButtonAddAll, gridBagConstraints);
    gridBagConstraints.gridy = 2;
    
    Component componentRigidArea = Box.createRigidArea (new Dimension (0, 10));
    gridBagLayout.setConstraints (componentRigidArea, gridBagConstraints);
    gridBagConstraints.gridy = 3;
    gridBagLayout.setConstraints (m_jButtonRemove, gridBagConstraints);
    gridBagConstraints.gridy = 4;
    gridBagLayout.setConstraints (m_jButtonRemoveAll, gridBagConstraints);
    
    jPanelButtons.add (m_jButtonAdd);
    jPanelButtons.add (m_jButtonAddAll);
    jPanelButtons.add (componentRigidArea);
    jPanelButtons.add (m_jButtonRemove);
    jPanelButtons.add (m_jButtonRemoveAll);

    return jPanelButtons;
  }

  // Add the shuttle buttons in the same panel as the component.

  private Component addShuttleButtons (Component component) {
    JPanel pnlRight = new JPanel (new BorderLayout());
    pnlRight.add (getButtonPanel(), BorderLayout.WEST);
    pnlRight.add (component, BorderLayout.CENTER);
    return pnlRight;
  }

  // Add left and right component to a JSplitPane and then
  // add this to the Shuttle.

  private void addSplitPane (Component availableComp, Component selectedComp) {
    GridBagLayout gridBagLayout = new GridBagLayout();
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    this.setLayout (gridBagLayout);

    gridBagConstraints.fill = GridBagConstraints.BOTH;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.weighty = 1.0;
    gridBagLayout.setConstraints (availableComp, gridBagConstraints);

    // Add buttons to the component on the right side.
    Component rightSide = addShuttleButtons (selectedComp);

    // Create a JSplitPane to hold the available and selected sides
    m_jSplitPane = new JSplitPane (JSplitPane.HORIZONTAL_SPLIT, availableComp, rightSide);
    m_jSplitPane.addComponentListener (new ComponentAdapter() {

      public void componentResized (ComponentEvent componentEvent) {
        int intNewWidth = getWidth();
        if ((m_nWidth == -1) || 
            ((m_nWidth != -1) && (m_nWidth != intNewWidth))) {
          m_jSplitPane.setDividerLocation(.5);
        }
        
        m_nWidth = intNewWidth;
      }
    });

    m_jSplitPane.setBorder (BorderFactory.createEmptyBorder (0, 0, 0, 0));
    m_jSplitPane.setDoubleBuffered (true);
    gridBagLayout.setConstraints (m_jSplitPane, gridBagConstraints);
    m_jSplitPane.setContinuousLayout (true);
    add (m_jSplitPane);
  }

  /**
   * Lays out the shuttle components and Add/Remove buttons
   * 
   * @param componentAvailableSideToolbar A <code>Component</code> representing an 
   *        optional available side toolbar.
   * @param componentSelectedSideToolbar A <code>Component</code> representing an 
   *        optional selected side toolbar.
   *        
   * @status hidden       
   */
  private void layoutShuttleComponents (Component componentAvailableSideToolbar, 
                                        Component componentSelectedSideToolbar) {
    FocusAdapter focusAdapter = new FocusAdapter() {
      public void focusGained (FocusEvent focusEvent) {
        if (focusEvent != null) {
          Object objSource = focusEvent.getSource();
          Vector vShuttleComponents = 
            getShuttleComponents (Shuttle.this, null);
          
          if (vShuttleComponents != null) {
            Object objShuttleComponent;
            
            for (Enumeration enumeration = vShuttleComponents.elements(); enumeration.hasMoreElements(); ) {
              objShuttleComponent = enumeration.nextElement();
              
              if ((objShuttleComponent instanceof ShuttleComponent) && (objShuttleComponent != objSource)) {
                ((ShuttleComponent)objShuttleComponent).clearSelection();
              }
            }
          }
        }
      }

      public void focusLost (FocusEvent focusEvent) {
      }
    };

    if (m_componentAvailable instanceof ShuttleComponent) {
      m_holderPanelAvailable = 
        new HolderPanel ((Component)m_componentAvailable);
      
      m_componentAvailable.addFocusListener (focusAdapter);
      ((ShuttleComponent)m_componentAvailable).addShuttleListener (this);

      // Register keyboard actions
      // When Enter is pressed, move the selected items from the 
      // available side to the selected side    
      ActionListener enterAction = new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          // Insert the selected items from the available component
          // into all the shuttle components on the selected side
          addItems();
        }
      };

      // Make sure that Enter key will get handled by the components in the available panel
      m_holderPanelAvailable.registerKeyboardAction (enterAction, 
        KeyStroke.getKeyStroke (KeyEvent.VK_ENTER, KeyEvent.SHIFT_MASK), 
          JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }
    
    if (m_componentSelected instanceof ShuttleComponent) {
      m_holderPanelSelected = 
        new HolderPanel ((Component)m_componentSelected, 
          componentSelectedSideToolbar, componentAvailableSideToolbar);

      m_componentSelected.addFocusListener(focusAdapter);
      ((ShuttleComponent)m_componentSelected).addShuttleListener (this);

      // Register keyboard actions
      // When Del or Backspace key is pressed, 
      // remove the selected items from the selected side    
      ActionListener enterAction = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          // If the "Remove" button was pressed, remove the
          // selected nodes from the currently active component on the selected side
          removeItems();
        }
      };

      // Make sure that Delete and Backspace keys will get handled 
      // by the components in the selected panel
      m_holderPanelSelected.registerKeyboardAction (enterAction, 
        KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), 
          JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

      m_holderPanelSelected.registerKeyboardAction (enterAction, 
        KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0), 
          JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    if ((m_holderPanelAvailable != null) && (m_holderPanelSelected != null)) {
      // Add the left and right panels to a splitter.
      addSplitPane (m_holderPanelAvailable, m_holderPanelSelected);
    }
    else if (m_holderPanelAvailable != null) {
      // The right panel is null, so only add the left panel.
      this.setLayout (new BorderLayout());
      add (m_holderPanelAvailable, BorderLayout.CENTER);
    }
    else if (m_componentSelected != null) {
      // The left panel is null, so only add the right panel.
      this.setLayout (new BorderLayout());
      add (m_holderPanelSelected, BorderLayout.CENTER);
    }
  }

  // when settings change, make sure the visible buttons reflect the changes

  private void updateButtonVisibility() {
    if (m_jButtonAdd != null) {
      m_jButtonAdd.setVisible(((m_nButtonsShown & ADD_BUTTON) != 0));
    }
    
    if (m_jButtonAddAll != null) {
      m_jButtonAddAll.setVisible(((m_nButtonsShown & ADD_ALL_BUTTON) != 0));
    }
    
    if (m_jButtonRemove != null) {
      m_jButtonRemove.setVisible(((m_nButtonsShown & REMOVE_BUTTON) != 0));
    }
    
    if (m_jButtonRemoveAll != null) {
      m_jButtonRemoveAll.setVisible(((m_nButtonsShown & REMOVE_ALL_BUTTON) != 0));
    }
  }

  private Vector getShuttleComponents (Container container, Vector v) {
    if (container != null) {
      if (v == null) {
        v = new Vector();
      }
      
      if (container instanceof ShuttleComponent) {
        v.add ((ShuttleComponent)container);
      }
      
      Component[] components = container.getComponents();
      if (components != null) {
        for (int i = 0; i < components.length; i++) {
          if (components[i] instanceof Container) {
            getShuttleComponents ((Container)components[i], v);
          }
        }
      }
    }
    
    return v;
  }

  /**
   * Fires the specified <code>ShuttleEvent</code> to all registered listeners.
   *
   * @param shuttleEvent A <code>ShuttleEvent</code> representing the event
   *        to be fired.
   *
   * @status new
   */
  private void fireShuttleEvent (ShuttleEvent shuttleEvent) {
    ShuttleListener shuttleListener = null;

    // Get the listener class type / listener class instance
    // pairs.
    Object[] objListeners = m_shuttleListeners.getListenerList();

    // We step through the pairs from last to first. The first in
    // the pair is the class type, then is the class instance.
    // This is why we step through the list two at a time.
    for (int nIndex = objListeners.length - 2; nIndex >= 0; nIndex -= 2) {
      // Make sure this listener is the right type.
      if (objListeners[nIndex] == ShuttleListener.class) {
        shuttleListener = (ShuttleListener)objListeners[nIndex + 1];

        if (shuttleListener != null) {
          switch (shuttleEvent.getID()) {
            case ShuttleEvent.ADD:
            case ShuttleEvent.ADD_ALL:
            case ShuttleEvent.REMOVE:
            case ShuttleEvent.REMOVE_ALL:
              shuttleListener.shuttleItemsShuttled (shuttleEvent);
              break;
              
            case ShuttleEvent.DOUBLE_CLICK:
              shuttleListener.shuttleItemsDoubleClicked (shuttleEvent);
              break;          
                
            default:
              shuttleListener.shuttleItemsSelected (shuttleEvent);
              break;
          }
        }
      }
    }
  }

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Creates a panel wrapping the given panel, with the given title
   * 
   * @status hidden
   */
  private class HolderPanel extends JPanel {

    /////////////////////
    //
    // Members
    //
    /////////////////////

    private JLabel m_jLabelTitle = null;
    private JPanel m_jPanelTitle = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

   /**
    * <code>HolderPanel</code>
    * 
    * @param componentContents A <code>Component</code> representing the contents
    * @status hidden       
    */
    public HolderPanel (Component componentContents) {
      this (componentContents, null);
    }

   /**
    * <code>HolderPanel</code>
    * 
    * @param componentContents A <code>Component</code> representing the contents
    * @param componentToolbar A <code>Component</code> representing an 
    *        optional side toolbar.
    *        
    * @status hidden       
    */
    public HolderPanel (Component componentContents, Component componentToolbar) {
      this (componentContents, componentToolbar, null);
    }

   /**
    * <code>HolderPanel</code>
    * 
    * @param componentContents A <code>Component</code> representing the contents
    * @param componentToolbarOpposite A <code>Component</code> representing the 
    *        other panel.
    *                
    * @status hidden       
    */
    public HolderPanel (Component componentContents, 
        Component componentToolbar, Component componentToolbarOpposite) {
      super (new BorderLayout());
      setPreferredSize (new Dimension (300, 100));
      
      m_jPanelTitle = new JPanel (new BorderLayout());
      m_jPanelTitle.setBorder (BorderFactory.createEmptyBorder());
      
      // Create the title label and set mnemonic
      m_jLabelTitle = new JLabel();
      
      // Find the component to associate with the label,
      // which requests focus when the label's mnemonic is invoked
      Component labeledComp = getFocusableComponent (componentContents);
      
      m_jLabelTitle.setLabelFor (labeledComp);
      m_jLabelTitle.setVerticalAlignment (javax.swing.SwingConstants.CENTER);
      m_jPanelTitle.add (m_jLabelTitle, BorderLayout.CENTER);
      
      if (componentToolbar != null) {
        m_jPanelTitle.add (componentToolbar, BorderLayout.EAST);
      }
      else {
        if (componentToolbarOpposite != null) {
          int nHeight = (int) componentToolbarOpposite.getPreferredSize().getHeight();
          m_jPanelTitle.add (Box.createVerticalStrut (nHeight), BorderLayout.EAST);
        }
      }

      add (m_jPanelTitle, BorderLayout.NORTH);
      add (componentContents, BorderLayout.CENTER);
    }

    /////////////////////
    //
    // Public methods
    //
    /////////////////////

    public void setTitle (String strTitle) {
      if (m_jLabelTitle != null) {
        m_jLabelTitle.setText (StringUtils.stripMnemonic (strTitle));
        m_jLabelTitle.setDisplayedMnemonic (StringUtils.getMnemonicKeyCode (strTitle));
      }
    }

    public JPanel getTitlePanel() {
      return m_jPanelTitle;
    }
  }
}