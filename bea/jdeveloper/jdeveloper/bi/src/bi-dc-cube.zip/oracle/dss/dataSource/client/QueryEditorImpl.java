/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryEditorImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.dataSource.client;

import java.util.Enumeration;
import java.util.Vector;

import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.dataSource.common.QueryUtil2;

import oracle.dss.datautil.DataFilterChangedEvent;
import oracle.dss.datautil.ItemsChangedEvent;
import oracle.dss.datautil.QueryEditor;
import oracle.dss.datautil.QueryEditorException;
import oracle.dss.datautil.QueryEditorListener;

import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataSource;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.StatusInfo;


/**
 * @hidden
 * Class implementing QueryEditor
 */
public class QueryEditorImpl extends CommonQueryEditor implements QueryEditor
{    
    protected QueryLayoutAccess m_la = null;
    
    public QueryEditorImpl(Query query)
    {
        super(query);
        
        m_la = new QueryLayoutAccess(m_query, false);
        // Initialize
        m_la.getDataSource();
    }
    

    public void resetItems(String[] dataItems, String[] items) throws Exception
    {
        ItemsChangedEvent ice = new ItemsChangedEvent(this, dataItems, items, getDataItems(LayerMetadataMap.LAYER_METADATA_NAME), getItems(LayerMetadataMap.LAYER_METADATA_NAME));
        m_la.resetItems(dataItems, items);
        fireItemsChanged(ice);
    }
    
    public int getMeasureLayer()
    {
        return m_la.getMeasureLayer();
    }
    
    public int getMeasureEdge()    
    {
        return m_la.getMeasureEdge();
    }

    public void setMeasures(String[] measures)
    {
        m_la.setMeasures(measures);
    }
    
    public DataSource getDataSource()
    {
       return m_la.getDataSource();
    }
    
    public void setCursorEvaluation(boolean on)
    {
        m_la.setCursorEvaluation(on);
    }
    
    public String[] getMeasures(String type)
    {
        return m_la.getMeasures(type);
    }
    
    public boolean isSpecialDimension(int edge, int layer, String type) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {
        return m_la.isSpecialDimension(edge, layer, type);
    }
    
    public void setLayout(String[][] layout)
    {
        m_la.setLayout(layout);
    }

    public String[][] getLayout()
    {
        return m_la.getLayout();
    }
    
    // javadoc from interface
    public void addQueryEditorListener (QueryEditorListener queryEditorListener) {
      if (m_listeners.indexOf (queryEditorListener) == -1) {
        m_listeners.addElement (queryEditorListener);
  
        // gek 12/11/06 Add ability to listen to layout events  
        if (getLayoutQuery() != null) {
          getLayoutQuery().addQueryListener (queryEditorListener);
        }
      }
    }

    // javadoc from interface
    public void removeQueryEditorListener (QueryEditorListener queryEditorListener) {
      m_listeners.removeElement (queryEditorListener);
  
      // gek 12/11/06 Add ability to listen to layout events  
      if (getLayoutQuery() != null) {
        getLayoutQuery().removeQueryListener (queryEditorListener);
      }
    }

  // Fire item changed event
    protected void fireItemsChanged(ItemsChangedEvent ice)
    {
        Enumeration list = m_listeners.elements();
        QueryEditorListener listener = null;
        while (list.hasMoreElements()) 
        {
            listener = (QueryEditorListener)list.nextElement();
            listener.itemsChanged(ice);
        }
    }
    
    // javadoc from interface
    public BaseDataFilter[] getDataFilters(int instance)
    {
        //return m_la.getLayoutDataSource().getDataSource().getDataFilters();
        
        return m_selcursors.getDataFilters(instance);
    }
    
    // javadoc from interface
    public void addDataFilter(BaseDataFilter filter, int instance) throws QueryEditorException 
    {
        if (filter == null)
            return;
            
        // Copy current data filters to new array
        BaseDataFilter[] dfs = getDataFilters(instance);
        BaseDataFilter[] newdfs = dfs != null ? new BaseDataFilter[dfs.length+1] : new BaseDataFilter[1];
        if (dfs != null)
        {
            for (int i = 0; i < dfs.length; i++)
                newdfs[i] = dfs[i];
        }
        newdfs[newdfs.length-1] = filter;
        setDataFilters(newdfs, instance);
    }
        
    // javadoc from interface
    public void removeDataFilter(BaseDataFilter filter, int instance) throws QueryEditorException
    {
        if (filter == null)
            return;
            
        BaseDataFilter[] dfs = getDataFilters(instance);
        if (dfs == null || dfs.length == 0)
            return;
            
        int count = 0;
        BaseDataFilter[] newdfs = new BaseDataFilter[dfs.length-1];
        for (int i = 0; i < dfs.length; i++)
        {
            if (dfs[i] != null && dfs[i].equals(filter))
            {
                // Skip this one: this is the one to remove
            }
            else
            {
                if (count < newdfs.length)
                    newdfs[count++] = dfs[i];                
            }
        }
        if (newdfs.length == 0 || (newdfs.length == 1 && newdfs[0] == null))
            setDataFilters(null, instance);
        else
            setDataFilters(newdfs, instance);
    }
    
    private QueryUtil2.DAQuery _getDataForDataFilter(String item, BaseDataFilter[] dataFilters, MetadataMap map) throws Exception
    {
        QueryUtil2.DAQuery daq = QueryUtil2._getDataForDataFilters(createQuery(), item, dataFilters, map, this);
        // blm - Selection code moved to dvt-olap
        setCurrentOperation(daq.getQuery(), new ReturnValueProviderImpl(daq/*, null*/));
        return daq;
    }
    
    // javadoc from interface
    public DataAccess getDataAccess(String item, BaseDataFilter[] dataFilters)
    {
        try
        {
            // Check the cache
            //DataAccess da = getValueCache().getCursorValues(selection);
            // Must maintain a differentiation between regular data access & closeable, otherwise
            // caller could close a standard DA from the cache and screw things up using this API
            //if (da != null && da instanceof CloseableDataAccess)
                //return da;
                
            QueryUtil2.DAQuery daq = _getDataForDataFilter(item, dataFilters, m_metaTypes);
            if (!isAsynchronous())
                // blm - Selection code moved to dvt-olap
                return createCloseableDataAccess(daq/*, null*/);
            return null;
                
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    // javadoc from interface
    public boolean collapse(String item, int instance) throws QueryEditorException
    {
        return false;
    }
    
    // javadoc from interface
    public boolean expand(String item, int instance) throws QueryEditorException
    {
        return false;
    }
    
    // javadoc from interface
    public void setDataFilters(BaseDataFilter[] filters, int instance) throws QueryEditorException
    {
/*        try
        {*/
//            fireDataFilterChanged(dfce);
            //m_la.getLayoutDataSource().getDataSource().setDataFilters(filters);
            m_selcursors.setDataFilters(filters, instance);
/*        }
        catch (QueryException e)
        {
            throw new QueryEditorException(e.getMessage(), e);
        }*/
    }
    
    // javadoc from interface
    public DataDirector getDataDirector(String item, int instance) throws QueryEditorException
    {
        return null;
    }

    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String item) throws QueryEditorException
    {
        try
        {
            return m_query.getDefaultSelection(item);
        }
        catch (QueryException e)
        {
            throw new QueryEditorException(e.getMessage(), e);
        }
    }*/
    
    // javadoc from interface
    public Vector getValues(String item, int instance, String hierarchy, String[] type, int max) throws QueryEditorException
    {
        return null;
    }
    
    public String getMeasureItem(String type) throws QueryEditorException
    {
        return super.getMeasureDimension(type);
    }
    
   	public OlapQDR getQDR(String dataItem, String type, int instance) throws QueryEditorException
    {
        return super.getQDR(dataItem, null, type, instance);
    }

    public Object isValid(String validity, Object data) throws QueryEditorException
    {
        return null;
    }
    
    public Object isSupported(int capability, Object data) throws QueryEditorException
    {
        try
        {
            return m_query.isSupported(capability, data);
        }
        catch (QueryException e)
        {
            throw new QueryEditorException(e.getMessage(), e);
        }
    }
    
    protected DataFilterChangedEvent getDataFilterChanged(int instance, BaseDataFilter[] oldDF, BaseDataFilter[] newDF)
    {
        return new DataFilterChangedEvent(this, oldDF, newDF, instance);        
    }
    
    // blm - Selection code moved to dvt-olap
/*    protected oracle.dss.datautil.SelectionChangedEvent getSelectionChanged(Selection sel, int instance) throws CloneNotSupportedException
    {
        return new oracle.dss.datautil.SelectionChangedEvent(this, (Selection)sel.clone(),
                                    instance);
    }*/

    // javadoc from interface
    public int getMaxEdge()
    {
        return m_la.getMaxEdge();
    }

    // javadoc from interface
    public int getItemEdge(String item)
    {
        return m_la.getItemEdge(item);
    }
    

    // javadoc from interface
    public int getItemLayer(String item, int edge)
    {
        return m_la.getItemLayer(item, edge);
    }

    // javadoc from interface
    public void setItems(String dataItems[], String[] items) throws Exception
    {
        String[] oldItems = getItems(LayerMetadataMap.LAYER_METADATA_NAME);
        String[] oldDataItems = getDataItems(LayerMetadataMap.LAYER_METADATA_NAME);
        m_la.setItems(dataItems, items);
        ItemsChangedEvent ice = new ItemsChangedEvent(this, getDataItems(LayerMetadataMap.LAYER_METADATA_NAME), getItems(LayerMetadataMap.LAYER_METADATA_NAME), oldDataItems, oldItems);
        fireItemsChanged(ice);
    }
    
    // javadoc from interface
    public String[] getDataItems(String type)
    {
        return m_la.getDataItems(type);
    }
    
    // javadoc from interface
    public String[] getItems(String type)
    {
        return m_la.getItems(type);  
    }

    // javadoc from interface    
    public void hideItems(String[] items, boolean hide) throws QueryEditorException
    {
        if (items == null) {
            return;
        }
        
        m_la.getLayoutDA();
        if (m_la.m_layoutDD != null && m_la.m_layoutDA != null) {
            // Hide/unhide dimensions in the layout access' data source
            
            // Check each specified dimension for its current hidden state: if it's different, 
            // pivot it on the temporary layout data source and mark the difference
            //Selection sel = null;
            String dimName = null;
            
            int hiddenEdge = getMaxEdge()+1;
            for (int dim = 0; dim < items.length; dim++)
            {
            	
                dimName = items[dim];
                int currentEdge = getItemEdge(dimName);
                int currentLayer = getItemLayer(dimName, currentEdge);
                try
                {
                    int maxLayer = 0;
                    if (hiddenEdge < m_la.m_layoutDA.getEdgeCount()) {
                        maxLayer = m_la.m_layoutDA.getLayerCount(hiddenEdge)-1;
                    }
                    if (hide && hiddenEdge != currentEdge)
                    {        	
                        // Hide it on the extra edge if not already there
                        m_la.m_layoutDD.pivot(currentEdge, hiddenEdge, currentLayer, maxLayer, DataDirector.PIVOT_MOVE_AFTER);
                    }
                    else if (!hide && currentEdge == hiddenEdge)
                    {
                      //bug 3545372 : LayerOutOfRangeException when adding back a hidden dimension
                      //if layer count for page edge is 0. If layer count for page edge is 0, set the
                      //destination layer to 0.
                      // Put it back on the page edge to make it visible
                      m_la.m_layoutDD.pivot(currentEdge, DataDirector.PAGE_EDGE, currentLayer,
                      (m_la.m_layoutDA.getLayerCount(DataDirector.PAGE_EDGE) - 1) < 0 ? 0 :
                      (m_la.m_layoutDA.getLayerCount(DataDirector.PAGE_EDGE) - 1), DataDirector.PIVOT_MOVE_AFTER);
                    }
                }
                catch (Exception e)
                {
                    throw new QueryEditorException(e.getMessage(), e);
                }
            }
        }
    }
    
    protected boolean isAsynchronous()
    {
        try
        {
            // Check layout query to see about asynchronicity
            Boolean val = (Boolean)getProperty(DataDirector.PROP_ASYNCHRONOUS);
            if (val != null)
                return val.booleanValue();
        }
        catch (Exception e)
        {
        }
        return false;
    }
    
    protected boolean isAutoFireEvents()
    {
        try
        {
            // Check layout query to see about auto fire events
            Boolean val = (Boolean)getProperty(DataDirector.PROP_AUTO_FIRE_EVENTS);
            if (val != null)
                return val.booleanValue();
        }
        catch (Exception e)
        {
        }
        return false;
    }
        
    // javadoc from interface
    public StatusInfo fireEvents() throws QueryEditorException
    {        
        if (m_currOp != null)
        {
            try
            {
                m_currOp.getQuery().fireEvents();
                // Load the info with the return value
                StatusInfo info = new StatusInfo(StatusInfo.DATASOURCE_COMPLETE, m_currOp.getReturnValue());
                // This has to be the end
                clearCurrentOperation();
                return info;
                    
            }
            catch (Exception e)
            {
                throw new QueryEditorException(e.getMessage(), e);
            }
        }
        return null;
    }    
    
    // javadoc from interface
    public StatusInfo getStatus() throws QueryEditorException
    {
        if (m_currOp != null)
        {
            try
            {
                StatusInfo info = m_currOp.getQuery().getStatus();
                return processInfo(info);
            }
            catch (Exception e)
            {
                throw new QueryEditorException(e.getMessage(), e);
            }
        }
        return null;
    }
    
    // javadoc from interface
    public StatusInfo startExecution() throws QueryEditorException
    {
        if (m_currOp != null)
        {
            try
            {
                StatusInfo info = m_currOp.getQuery().startExecution();
                return processInfo(info);
            }
            catch (Exception e)
            {
                throw new QueryEditorException(e.getMessage(), e);
            }
        }
        return null;
    }
    
    protected StatusInfo processInfo(StatusInfo info) throws Exception
    {
        if (info.getStatus() == StatusInfo.DATASOURCE_CANCELED || info.getStatus() == StatusInfo.DATASOURCE_ERROR)
        {
            // Better clear this: nothing more to say: op is over
            clearCurrentOperation();
            return info;
        }
        if (info.getStatus() == StatusInfo.DATASOURCE_COMPLETE)
        {
            Object obj = m_currOp != null ? m_currOp.getReturnValue() : null;
            if (isAutoFireEvents())
            {
                // Clear the current operation if the events don't need firing
                clearCurrentOperation();
            }
            // Get the return value into the info
            return new StatusInfo(info.getStatus(), obj);
        }
        return info;
    }
    
    // javadoc from interface
    public void cancel() throws QueryEditorException
    {
        if (m_currOp != null)
        {
            m_currOp.getQuery().cancel();
        }
    }
    
    // javadoc from interface
    public Object getProperty(String name) throws QueryEditorException, oracle.dss.util.xml.NoSuchPropertyException
    {
        if (name == null)
            return null;
            
        if (name.equals(DataDirector.PROP_ASYNCHRONOUS))
            return ((Query)m_la.getDataSource()).getProperty(QueryConstants.PROPERTY_ASYNCHRONOUS);
        else if (name.equals(DataDirector.PROP_AUTO_FIRE_EVENTS))
            return ((Query)m_la.getDataSource()).getProperty(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS);
        
        return null;
    }

    // javadoc from interface
    public void setProperty(String name, Object value) throws QueryEditorException, oracle.dss.util.xml.NoSuchPropertyException
    {
        if (name == null)
            return;

        try
        {
            if (name.equals(DataDirector.PROP_ASYNCHRONOUS))
                ((Query)m_la.getDataSource()).setProperty(QueryConstants.PROPERTY_ASYNCHRONOUS, value);
            else if (name.equals(DataDirector.PROP_AUTO_FIRE_EVENTS))
                ((Query)m_la.getDataSource()).setProperty(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS, value);
        }
        catch (Exception e)
        {
            throw new QueryEditorException(e.getMessage(), e);
        }
    }

  /**
   * Retrieve the <code>Query</code> associated with the <code>QueryLayoutAccess</code>.
   * 
   * @return <code>Query</code> associated with the <code>QueryLayoutAccess</code>.
   */
  protected Query getLayoutQuery() {
    Query query = null;
    if (getQueryLayoutAccess() != null && getQueryLayoutAccess().isInitialized()) {
      query = (Query)getQueryLayoutAccess().getDataSource();
    } 

    return query;
  }

  /**
   * Retrieve the <code>QueryLayoutAccess</code>.
   * 
   * @return <code>QueryLayoutAccess</code>.
   */
  protected QueryLayoutAccess getQueryLayoutAccess() {
    return m_la;
  }
}
