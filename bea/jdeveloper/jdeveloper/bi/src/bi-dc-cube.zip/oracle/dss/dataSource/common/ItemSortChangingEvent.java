/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemSortChangingEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    jramanat    08/02/05 - jramanat_item_sort_common
    jramanat    08/02/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemSortChangingEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.dataSource.common;

import oracle.dss.selection.sortWrapper.ItemSortWrapper;

/**
 * Informs listeners when changes to one or more <code>ItemSortWrapper</code> objects
 * have been requested. A listener can call the <code>consume</code> method
 * of this event to veto the changes.
 *
 * @status New
 */
public class ItemSortChangingEvent extends ItemSortEvent implements Consumable {
  /**
   * Constructs the event.
   * 
   * @param source     The source of the event, that is, a reference to the
   *                   object that fired the event.
   * @param sorts A list of the <code>ItemSortWrapper</code> objects for which
   *                   changes were requested.
   *
   * @status New
   */
  public ItemSortChangingEvent(Object source, ItemSortWrapper[] sorts) {
      super(source, sorts, false);
  }    
  
 /**
   * Constructs the event.
   * 
   * @param source     The source of the event, that is, a reference to the
   *                   object that fired the event.
   * @param sorts A list of the <code>ItemSortWrapper</code> objects for which
   *                   changes were requested.
   * @param removed    Were these sorts removed?
   *
   * @status New
   */
  public ItemSortChangingEvent(Object source, ItemSortWrapper[] sorts, boolean removed) {
      super(source, sorts, removed);
  }    
      
  /**
   * Consumes this event.
   *
   * @status Documented
   */
  public void consume() {
      super.consume();
  }
  
  /**
   * Indicates whether this event has been consumed.
   *
   * @return <code>true</code> if the event was consumed;
   *         <code>false</code> if not.
   *
   * @status Documented
   */
  public boolean isConsumed() {
      return super.isConsumed();
  }        
}