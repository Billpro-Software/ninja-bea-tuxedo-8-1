/*
 * StandardDialog.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JComponent;
import javax.swing.JPanel;

import oracle.bali.ewt.dialog.JEWTDialog;
import oracle.bali.ewt.help.HelpProvider;
import oracle.bali.ewt.help.HelpUtils;

import oracle.dss.util.help.HelpContext;
import oracle.dss.datautil.Timer;

/**
 * Standard builder class.
 *
 * @status Documented
 */
public class StandardDialog extends JEWTDialog implements HelpContext {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   */
  public static final int SMALL_DIALOG = 0;
  
  /**
   * @hidden
   */
  public static final int LARGE_DIALOG = 1;
  
  /**
   * @hidden
   */
  public static final int ALERT_DIALOG = 2;

  // Standards set according to OLAF guidelines.
  
  /**
   * @hidden
   */
  public static final Dimension SMALL_SIZE = new Dimension(355, 344);
  
  /**
   * @hidden
   */
  public static final Dimension LARGE_SIZE = new Dimension(446, 420);
  
  /**
   * @hidden
   */
  public static final Dimension ALERT_SIZE = new Dimension(400, 200);    

  /**
   * The undefined return value.
   *
   * @status documented
   */
  public static final int UNDEFINED   = -1;
  
  /**
   * The OK return value.
   *
   * @status documented
   */
  public static final int OK             = 0;
  
   /**
   * The Cancel return value.
   *
   * @status documented
   */
  public static final int CANCEL        = 1;

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////
          
  /**
   * @hidden
   *
   * The HelpProvider.
   *
   * @status protected
   */
  protected HelpProvider m_helpProvider = null;
    
  /**
   * @hidden
   *
   */
  private int m_defaultButtonMask = 
    JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL | JEWTDialog.BUTTON_HELP;

  /**
   * @hidden
   *
   * Return code values (e.g. OK or CANCEL)
   */
  private int m_intReturnCode = UNDEFINED;

  /**
   * @hidden
   *
   */
  protected boolean m_bSuperCalled = false;
    
  /////////////////////
  //
  // Constructors
  //
  /////////////////////
    
  /**
   * Constructor that specifies the dialog that serves as the
   * parent for the <code>StandardDialog</code>.
   *
   * @param dlgParent The parent dialog.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
     * <code>false</code> if the dialog is not modal.
   * @param comp The component that is placed in the center of the dialog.
   *
   * @status documented
   */
  public StandardDialog(Dialog dlgParent, String strTitle,
                          boolean blnModal, Component comp) {
    super(dlgParent, strTitle);
    m_bSuperCalled = true;
    initDialog(m_defaultButtonMask, blnModal);
    setContent(comp);
  }
    
  /**
   * Constructor that specifies the frame that serves as the
   * parent for the <code>StandardDialog</code>.
   *
   * @param fraParent The parent frame.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
     * <code>false</code> if the dialog is not modal.
   * @param comp The component that is placed in the center of the dialog.
   *
   * @status documented
   */
  public StandardDialog(Frame fraParent, String strTitle,
                          boolean blnModal, Component comp) {
    super(fraParent, strTitle);
    m_bSuperCalled = true;
    initDialog(m_defaultButtonMask, blnModal);
    setContent(comp);
  }

  /**
   * A <code>StandardDialog</code> should be created using all the arguments
   * available for the constructor.
   *
   * @param fraParent The parent frame.
   * @param blnModal <code>true</code> if the dialog is modal,
     * <code>false</code> if the dialog is not modal.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by
   * {@link #StandardDialog(Frame, String, boolean, Component)}.
   */
  public StandardDialog(Frame fraParent, boolean blnModal) {
    super(fraParent);
    m_bSuperCalled = true;
    initDialog(m_defaultButtonMask, blnModal);
  }

  /**
   * A <code>StandardDialog</code> should be created using all the arguments
   * available for the constructor.
   *
   * @param fraParent The parent frame.
   * @param strTitle The title for the dialog.
   * @param blnModal <code>true</code> if the dialog is modal,
   * <code>false</code> if the dialog is not modal.
   *
   * @status documented
   * @deprecated As of 2.6.0.21, replaced by
   * {@link #StandardDialog(Frame, String, boolean, Component)}.
   */
  public StandardDialog(Frame fraParent, String title, boolean blnModal) {
    super(fraParent, title);
    m_bSuperCalled = true;
    initDialog(m_defaultButtonMask, blnModal);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
    
  /**
   * Sets the size of the dialog based upon the 
   * Oracle Look And Feel guidelines.
   *
   * @param intSize constant representing which size dialog to use.
   *
   * @status hidden
   * @hidden
   */
  public void setSize(int intSize) {
    if (intSize == SMALL_DIALOG) {
      setSize(SMALL_SIZE);
    }
    else if (intSize == LARGE_DIALOG) {
      setSize(LARGE_SIZE);
    }
    else if (intSize == ALERT_DIALOG) {
      setSize(ALERT_SIZE);
    }        
  }

  /**
   * @hidden
   */ 
  public void setSize(Dimension size) {
    super.setSize(size);
    setPreferredSize(size);
  }
  
  /**
   * Displays this dialog so that it is centered over the component that invokes 
   * it, which is often a button.
   *
   * @param centerOver The component over which to center the dialog.
   * If this parameter
   * is null, then the dialog is centered on the screen.
   *
   * @return A constant that represents the return code.
   *
   * @see #OK
   * @see #CANCEL
   *
   * @status documented
   */
  public int display(Component centerOver) {
		if ((Timer.ON) && (!Timer.getTimer().getStarted())) {
		 Timer.getTimer().start("Show dialog");
		}
      
	  setCenterOver(centerOver);
	  boolean blnOK = runDialog();
	  return blnOK ? OK : CANCEL;  
  }
    
  /**
   * Specifies the component that holds the content in this dialog.
   *
   * @param Component The component.
   *
   * @status documented
   */ 
  public void setContent(Component comp) {
    super.setContent(comp);
    if (m_helpProvider != null && comp instanceof JComponent) {
      HelpUtils.setHelpProvider((JComponent)comp, m_helpProvider);
    }
  }

  /**
   * Retrieves the current return code value.
   *
   * @return A constant that represents the return code.
   *
   * @see #UNDEFINED
   * @see #OK
   * @see #CANCEL
   *
   * @status documented
   */
  public int getReturnCode() {
    return m_intReturnCode;
  }

  /**
   * Retrieves the HelpProvider for this dialog.
   *
   * @return The HelpProvider for this dialog.
   *
   * @status Documented
   */
  public HelpProvider getHelpProvider () {
    return m_helpProvider;
  }
    
  /**
   * Specifies the HelpProvider.
   *
   * @param helpProvider The HelpProvider.
   *
   * @status Documented
   */
  public void setHelpProvider (HelpProvider helpProvider) {
    m_helpProvider = helpProvider;
    if (getContent() != null && getContent() instanceof JComponent) {
      HelpUtils.setHelpProvider((JComponent)getContent(), m_helpProvider);
    }
  }
    
  /**
   * Retrieves the Help context ID that is associated with this
   * dialog.
   *
   * This Help context ID is used to enable Help systems to map a particular
   * component to the proper help topic.
   *
   * @return A <code>string</code> that represents the Help context ID.
   *
   * @status documented
   */
  public String getHelpContextID() {
		return getClass().getName();
  }

  /**
   * Specifies the Help context ID that is associated with this dialog.
   *
   * <strong>Note:</strong> This method is not actually implemented in this class.
   * It is only here to satisfy the interface requirements.
   *
   * @param strHelpContextID A <code>string</code> value that represents the 
   *        Help context ID.
   *
   * @status documented
   */
  public void setHelpContextID (String strHelpContextID) {
  }

  /**
   * @hidden
   *
   * Hides the dialog.
   * @param cancelled true if the cancel button was pressed, false
   *             if the finish button was pressed.
   * @status protected
   */
  protected void dismissDialog(boolean cancelled) {
		      
    if (Timer.ON) {
    	Timer.getTimer().start("Close dialogue");
    }
      
    super.dismissDialog(cancelled);
    if (cancelled) {
      m_intReturnCode = CANCEL;
      doCancel();
    }
    else {
      m_intReturnCode = OK;
      doOK();
    }
    
    if (Timer.ON) {
    	Timer.getTimer().stop("Close dialogue");
		}
  }

  /**
   * @hidden
   * @status hidden
   */
  protected void doOK() {
  }
  
  /**
   * @hidden
   * @status hidden
   */
  protected void doCancel() {
  }

  /**
   * @hidden
   * @status hidden
   */
  protected void doApply() {
  }
  
  /**
   * @hidden
   *
   * Initialization method called by constructors.
   *
   * @status private
   */
  private void initDialog(int mask, boolean blnModal) {
    setButtonMask(mask);
    setModal(blnModal);
    setResizable(true);
    addActionListener(new ActionListener () {
      public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand() != null && e.getActionCommand().equals(JEWTDialog.ACTION_APPLY))
          doApply();
      }
    });
    
    if (Timer.ON) {
      addComponentListener(new ComponentAdapter() {
        public void componentShown(ComponentEvent e) {
          Timer.getTimer().stop("Show dialogue");
        }
      });
    }
  }
}