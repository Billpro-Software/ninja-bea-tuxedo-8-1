/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/ShuttleComponent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

/**
 * @hidden
 *
 * <pre>
 * The ShuttleComponent interface defines methods which need to be implemented 
 * by all the components used by the <code>Shuttle</code> class.
 * </pre>
 *
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 */
public interface ShuttleComponent {

  /**
   * @hidden
   * Gets the array of selected items from the shuttle component.
   *
   * @return array of selected items
   * @status hidden
   */
  public Object[] getSelectedItems();
  
  /**
   * @hidden
   * Get the array of all items from the shuttle component.
   *
   * @return array of all items
   * @status hidden
   */
  public Object[] getAllItems();

  /**
   * @hidden
   * Inserts an array of items into the shuttle component.
   *
   * @param array of items to be inserted
   * @status hidden
   */
  public void insertItems(Object[] newItems);

  /**
   * @hidden
   * Removes the selected items.
   * @status hidden
   */
  public void removeSelectedItems();
  
  /**
   * @hidden
   * Removes all the items.
   * @status hidden
   */
  public void removeAllItems();

  /**
   * @hidden
   * Add classes that want to be notified when a particular
   * component in the ShuttleComponent gains focus.
   * @status hidden
   *
   */
  // public void removeFocusListener(FocusListener listener);

  /**
   * @hidden
   * Remove classes that don't want to be notified when a particular
   * component in the ShuttleComponent gains focus.
   * @status hidden
   *
   */
  // public void addFocusListener(FocusListener listener);

   /**
   * @hidden
   * Add classes that want to be notified when a particular
   * component in the ShuttleComponent generates a mouse event.
   * @status hidden
   *
   */
  //public void addMouseListener(MouseListener listener);

  /**
   * @hidden
   * Remove classes that don't want to be notified when a particular
   * component in the ShuttleComponent generates a mouse event.
   * @status hidden
   *
   */
  //public void removeMouseListener(MouseListener listener);
   
  public void addShuttleListener(ShuttleListener listener);
   
  public void removeShuttleListener(ShuttleListener listener);

  /**
   * @hidden
   * Clears the selection.
   * @status hidden
   */
  public void clearSelection();
  
  /**
   * @hidden
   * Informs the shuttle if any items suitable for shuttling are present.
   *
   * @status hidden
   */
  public boolean isSelectableItemPresent();  
}