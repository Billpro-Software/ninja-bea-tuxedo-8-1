/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

import oracle.dss.selection.OlapQDR;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.util.QDR;

/**
 * Defines methods that perform various drill operations.
 * A drill operation is really a short-cut for applying one or more complicated
 * Steps to the specified dimension; this implies that a drill operation
 * represents a change to the underlying query.
 *
 * @status Documented
 */
public interface DrillManager extends BaseManager
{

    /**
     * Drills to a relative level of the specified hierarchy accepting a value's
     * parent for later optimization of drill steps.
     *
     * @param dimension   The dimension to drill.
     * @param value       The dimension value, also known as the
     *                    dimension member, to drill.
     * @param hierarchy   The target hierarchy for the drill.
     * @param delta       The relative number of levels to traverse within the
     *                    specified hierarchy. Positive numbers drill down;
     *                    negative numbers drill up.
     * @param valueParent Value's parent dimension value; used for optimizing
     *                    later potential drill up requests.
	   * @param queryParent The item from the original query members under which
     *                    this drill occurs.
     *
     * @throws QueryException          If there is a problem fetching data
     *                                 after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent) throws QueryException, MetadataManagerException;

    /**
     * Drills to a relative level of the specified hierarchy accepting
     * a value's parent for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param value        The dimension value, also known as the
     *                     dimension member, to drill.
     * @param hierarchy    The target hierarchy for the drill.
     * @param delta        The relative number of levels to traverse within the
     *                     specified hierarchy. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param valueParent  Value's parent dimension value; used for
     *                     optimizing later potential drill up requests.
     * @param queryParent  The item from the original query members under
     *                     which this drill occurs.
     * @param parentQDR    An optional OlapQDR specifying dimension/member pairs
     *                     limiting where this drill (down) should take place 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status documented
     */
    public void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent, OlapQDR parentQDR) throws QueryException, MetadataManagerException;

    /**
     * Drills to a relative level of the specified hierarchy accepting
     * a value's parent for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param value        The dimension value, also known as the
     *                     dimension member, to drill.
     * @param hierarchy    The target hierarchy for the drill.
     * @param delta        The relative number of levels to traverse within the
     *                     specified hierarchy. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param valueParent  Value's parent dimension value; used for
     *                     optimizing later potential drill up requests.
     * @param queryParent  The item from the original query members under
     *                     which this drill occurs.
     * @param levelDepth   Optional performance hint indicating the numeric 
     *                     level at which the drill target sits within its 
     *                     hierarchy.
     * @param parentQDR    An optional OlapQDR specifying dimension/member pairs
     *                     that limits where this drill (down) should occur 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent, int levelDepth, OlapQDR parentQDR) throws QueryException, MetadataManagerException;

    /**
     * Drills to relative levels of the specified hierarchies accepting
     * values' parents for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param target       The dimension drill targets, also known as the
     *                     dimension members, to drill.
     * @param hierarchy    The target hierarchies for the drill.
     * @param delta        The relative numbers of levels to traverse within the
     *                     specified hierarchies. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param above        If true, insert the targets' drill results above the targets rather
     *                     than below, which is the default.
     * @param valueParent  Values' parent dimension values; used for
     *                     optimizing later potential drill up requests.
     * @param queryAncestor The items from the original query members under
     *                     which these drills occur.
     * @param levelDepth   Optional performance hints indicating the numeric 
     *                     levels at which the drill targets sit within their 
     *                     hierarchies.
     * @param parentQDR    Optional OlapQDRs specifying dimension/member pairs
     *                     that limits where drills (down) should occur 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status New
     */
    public void drill(String dimension, String[] target, String[] hierarchy, int[] delta, boolean[] above, String[] valueParent, String[] queryAncestor, int[] levelDepth, OlapQDR[] parentQDR) throws QueryException;

    /**
     * Drills to specific levels of the specified hierarchies accepting
     * a values' parents for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param target       The dimension drill targets, also known as the
     *                     dimension members, to drill.
     * @param hierarchy    The target hierarchies for the drill.
     * @param level        The specific levels to drill to within the
     *                     specified hierarchies. 
     * @param above        If true, insert the targets' drill results above the targets rather
     *                     than below, which is the default.
     * @param valueParent  Values' parent dimension values; used for
     *                     optimizing later potential drill up requests.
     * @param queryAncestor The items from the original query members under
     *                     which these drills occur.
     * @param levelDepth   Optional performance hints indicating the numeric 
     *                     levels at which the drill targets sit within their 
     *                     hierarchies.
     * @param parentQDR    Optional OlapQDRs specifying dimension/member pairs
     *                     that limits where drills (down) should occur 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status New
     */
    public void drill(String dimension, String[] target, String[] hierarchy, String[] level, boolean[] above, String[] valueParent, String[] queryAncestor, int[] levelDepth, OlapQDR[] parentQDR) throws QueryException;

    /**
     * Drills to specified level of the specified hierarchy.
     *
     * @param dimension  The dimension to drill.
     * @param value      The dimension value, also known as the
     *                   dimension member, to drill.
     * @param hierarchy  The target hierarchy.
     * @param level      The target level to traverse to.
     * @param action     A constant (<code>Step.ADD</code>,
     *                   <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                   <code>Step.SELECT</code>) that represents the
     *                   selection step action.
     * @param flags      A list of optional flags. These flags are drill
     *                   constants that begin with the prefix
     *                   <code>DRILL_EXCLUDE_</code>.
     *
     * @throws QueryException          If there is a problem fetching data
     *                                 after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see  DrillConstants#DRILL_EXCLUDE_RANGE
     * @see  DrillConstants#DRILL_EXCLUDE_SELF
     * @see  DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see  oracle.dss.selection.step.Step#ADD
     * @see  oracle.dss.selection.step.Step#KEEP
     * @see  oracle.dss.selection.step.Step#REMOVE
     * @see  oracle.dss.selection.step.Step#SELECT
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #drill(String, String, String, String, String, int, BitSet, Object)}
     * 
     * @status Documented
     */
    public void drill(String dimension, String value, String hierarchy, String level, int action, BitSet flags) throws QueryException, MetadataManagerException;    
    
    /**
     * Drills to specified level of the specified hierarchy, or to the specified item (level).
     *
     * @param item The item to drill.
     * @param value     The item's value (also known as member) to drill.
     * @param valueLevel The item value's level.
     * @param hierarchy The name of the target hierarchy, if any.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @param data     Extra metadata/data
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * @status new
     */
    public void drill(String item, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException, MetadataManagerException;
    
   /**
     * Drills the specified members to the specified drill targets using the specified drill paths.
     *
     * @param item      The item to drill.
     * @param onEdge    Edge on which drill took place, if a layer (item) might exist on multiple edges
     * @param target    The members to drill.
     * @param drillPath The drill paths (e.g., hierarchies) to use.
     * @param drillTarget The drill targets (e.g., levels) to use.
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @status new
     */
    public void drill(String item, int onEdge, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException;
}
