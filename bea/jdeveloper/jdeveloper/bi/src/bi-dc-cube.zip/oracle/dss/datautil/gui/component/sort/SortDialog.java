/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortDialog.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.sort;

import java.awt.Dialog;
import java.awt.Frame;

import oracle.bali.ewt.help.HelpUtils;

import oracle.dss.datautil.gui.StandardDialog;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.sort.resource.SortBundle;

/**
 * @hidden
 *
 * <pre>
 * A Dialog that provides access to sort functionality.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   04/24/07 - Addition Sort Dialog updates.
 *
 */
public class SortDialog extends StandardDialog {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Help Context ID for <code>SortDialog</code>.
   * 
   * @status new
   */
  public static String SORT_DIALOG_HELP_CONTEXT_ID = "f1_dvt_bidc_sort_html";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private SortPanel m_sortPanel;
  
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that takes a parent Dialog.  Note that setModel and initialize
   * must be called on the contained SortPanel (obtained by calling getSortPanel)
   * before this Dialog is used.
   * 
   * @param dialogParent A <code>Dialog</code> which is the parent.
   * 
   * @status new
   */
  public SortDialog (Dialog dialogParent) {
    super (dialogParent, null, true, null);
    setSortPanel (new SortPanel());
    setTitle (getSortPanel().getResourceString (SortBundle.SORTDIALOG_TITLE));
    setContent (getSortPanel());
    setResizable (false);
  }

  /**
   * Constructor that takes a parent Frame.  Note that setModel and initialize
   * must be called on the contained SortPanel (obtained by calling getSortPanel)
   * before this Dialog is used.
   * 
   * @param frameParent A <code>Frame</code> which is the parent.
   * 
   * @status new
   */
  public SortDialog (Frame frameParent) {
    super (frameParent, null, true, null);
    setSortPanel (new SortPanel());
    setTitle (getSortPanel().getResourceString (SortBundle.SORTDIALOG_TITLE));
    setContent (getSortPanel());
    setResizable (false);
  }
  
  /**
   * Constructor that takes a parent Dialog and ComponentContext.
   * 
   * @param dialogParent A <code>Dialog</code> which is the parent.
   * @param componentContext A <code>ComponentContext</code>.
   * 
   * @status new
   */
  public SortDialog (Dialog dialogParent, ComponentContext componentContext) {
    super (dialogParent, null, true, null);
    setSortPanel (new SortPanel (componentContext));
    setTitle (getSortPanel().getResourceString (SortBundle.SORTDIALOG_TITLE));
    setContent (getSortPanel());
    setResizable (false);
  }

  /**
   * Constructor that takes a parent Frame and ComponentContext.
   * 
   * @param frameParent A <code>Frame</code> which is the parent.
   * @param componentContext A <code>ComponentContext</code>.
   * 
   * @status new
   */
  public SortDialog (Frame frameParent, ComponentContext componentContext) {
    super (frameParent, null, true, null);
    setSortPanel (new SortPanel (componentContext));
    setTitle (getSortPanel().getResourceString (SortBundle.SORTDIALOG_TITLE));
    setContent (getSortPanel());
    setResizable (false);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Retrieves the contained <code>SortPanel</code>
   * 
   * @return The <code>SortPanel</code>
   * 
   * @status new
   */
  public SortPanel getSortPanel() {
    return m_sortPanel;
  }

  /**
   * Retrieves the Help context ID that is associated with this dialog.
   *
   * This Help context ID is used to enable Help systems to map a particular
   * component to the proper help topic.
   *
   * @return A <code>string</code> that represents the Help context ID.
   *
   * @status documented
   */
  public String getHelpContextID() {
		return SORT_DIALOG_HELP_CONTEXT_ID;
  }

  /////////////////////
  //
  // Protected
  //
  /////////////////////

  /**
   * Specfies the <code>SortPanel</code>.
   * 
   * @param sortPanel A <code>SortPanel</code>.
   * 
   * @status new
   */
   public void setSortPanel (SortPanel sortPanel) {
     m_sortPanel = sortPanel;
     HelpUtils.setHelpID(m_sortPanel, SORT_DIALOG_HELP_CONTEXT_ID);     
   }

  /**
   * Determines how dialog was dismissed.
   * 
   * @param bCancelled A <code>boolean</code>
   * 
   * @status new
   */
  protected void dismissDialog (boolean bCancelled) {
    if (!bCancelled) {
      getSortPanel().apply();
    }

    super.dismissDialog (bCancelled);
  }    
}