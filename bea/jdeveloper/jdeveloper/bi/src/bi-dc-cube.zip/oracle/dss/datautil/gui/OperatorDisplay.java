/*
 * OperatorDisplay.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

/**
 * @hidden
 * This class just holds two strings. Depending on the value of
 * flag, toString() method returns one or the other string.
 * @status hidden
 */
public class OperatorDisplay {
    
    private String m_symbol;
    private String m_symbolAndDesc;
    private boolean m_blnDisplayJustSymbol = false;
    
    /**
     * @hidden
     * takes the short string and long string and sets them as member
     * variables.
     * @status hidden
     */
    public OperatorDisplay(String symbol, String symbolAndDesc)
    {
        m_symbol = symbol;
        m_symbolAndDesc = symbolAndDesc;
    }

    /**
     * @hidden
     * Sets the boolean value for determining which string to return in the
     * toString() method.
     *
     * @param blnDisplayJustSymbol if true, toString() returns short string; 
     * if false toString() returns long string.
     * @status hidden
     */
    public void setDisplayJustSymbol(boolean blnDisplayJustSymbol)
    {
        m_blnDisplayJustSymbol = blnDisplayJustSymbol;
    }
   
   /**
    * @hidden
    * returns either short or long string depending on the flag.
    *
    * @return either the short or long string.
    * @status hidden 
    */
    public String toString()
    {
        if (m_blnDisplayJustSymbol)
        {
            return m_symbol;
        }
        else
        {
            return m_symbolAndDesc;
        }
    }

    /**
     * @hidden
     * returns just the symbol without description.
     *
     * @return the symbol
     * @status hidden 
     */
    public String getSymbol()
    {
        return m_symbol;
    }

}