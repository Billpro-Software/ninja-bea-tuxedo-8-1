/*
 * ExceptionListenerDialog.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import java.awt.Component;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.gui.ExceptionListenerGui;

import oracle.dss.util.help.HelpContext;
import oracle.dss.util.Localizable;

/**
 * @hidden
 *
 * Interface for exception listener dialogs.
 *
 * Application developers should implement this interface to handle exceptions
 * from beans that need to have dialog boxes associated with them.
 *
 * Beans that call the exception listener dialog implement the
 * <code>ExceptionListenerDialogCallback</code> interface.
 * <P>
 *
 * By default, GUI (graphic user interface) based beans register a default GUI
 * exception listener that implements this interface.
 *
 * To replace the default exception listener with your implementation of this
 * interface, you call the <code>addExceptionListenerDialog</code> method of the bean.
 *
 * @see ExceptionListenerDialogCallback
 *
 * @status hidden
 */

public interface ExceptionListenerDialog extends ExceptionListener, Localizable, HelpContext {

  /**
   * @hidden
   * Retrieves the exception dialog's parent.
   *
   * @return <code>Component</code> which represents the alert dialog's parent.
   *
   * @status hidden
   */
  public Component getComponentParent();

  /**
   * @hidden
   * Specifies the alert dialog's parent.
   *
   * @param componentParent A <code>Component</code> value which represents the
   *                        alert dialog's parent.
   *
   * @status hidden
   */
  public void setComponentParent (Component componentParent);

  /**
   * @hidden
   * Retrieves the title associated with the alert dialog.
   *
   * @return <code>String</code> which represents the title associated with the
   *         alert dialog.
   *
   * @status hidden
   */
  public String getTitle();

  /**
   * @hidden
   * Specifies the title associated with the alert dialog.
   *
   * @param strTitle A <code>String</code> whicv represents the title associated
   *                 with the alert dialog.
   *
   * @status hidden
   */
  public void setTitle (String strTitle);

  /**
   * @hidden
   * Specifies whether a Help button in a dialog box that is displayed by
   * this panel, is displayed.
   * <P>For example, suppose that this panel had a font button and that
   * font button displayed a font dialog box. If that font dialog box had
   * a Help button, then this method would specify whether that Help button
   * is displayed.</P>
   *
   * @param  bValue  <code>true</code> to display the Help button,
   * <code>false</code> to hide it.
   *
   * @status hidden
   */
  public void setHelpEnabled (boolean bValue);

  /**
   * @hidden
   * Indicates whether a Help button in a dialog box that is displayed by
   * this panel, is displayed.
   * <P>For example, suppose that this panel had a font button and that
   * font button displayed a font dialog box. If that font dialog box had
   * a Help button, then this method would tell you whether that Help button
   * is displayed.</P>
   *
   * @return  <code>true</code> if the Help button is hidden,
   * <code>false</code> if it is displayed.
   *
   * @status hidden
   */
  public boolean isHelpEnabled();
}

