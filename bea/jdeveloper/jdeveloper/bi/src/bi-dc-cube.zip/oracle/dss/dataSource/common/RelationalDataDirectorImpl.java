/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/RelationalDataDirectorImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/10/05 - 
    bmoroze     04/29/05 - bmoroze_olap_refactoring
    bmoroze     04/27/05 - Creation
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.RelationalDataDirector;

/**
 * @hidden
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/RelationalDataDirectorImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
public class RelationalDataDirectorImpl extends DataDirectorImpl implements RelationalDataDirector
{    
    public RelationalDataDirectorImpl(Query query, Delegate delegate)
    {
        super(query, delegate);
    }

    public void setDelegate(Query delegateSource)
    {
        m_delegate = (Delegate)delegateSource.getRelationalDataDirectorFromImpl();
        if (m_delegate != null)
            m_delegate.setWrapper(this);        
    }    
}
