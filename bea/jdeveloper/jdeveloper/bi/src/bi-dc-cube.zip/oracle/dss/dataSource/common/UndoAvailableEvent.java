/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;


/**
 * Provides listeners with a <code>QueryEdit</code> object that they can use
 * to change the state of a <code>Query</code> object.
 * The <code>undo</code> and <code>redo</code> methods of the
 * <code>QueryEdit</code> object restore a <code>Query</code>
 * object to its state before or after a particular edit.
 *
 * @status Documented
 */
public class UndoAvailableEvent extends QueryEvent {
    /**
     * Constructs the event.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param undo         The undoable edit object that can be used
     *                     to reset the state of the <code>Query</code> object.
     *
     * @status Documented
     */
    public UndoAvailableEvent(Object source, QueryEdit undo) {
        super(source);
        
        _undo = undo;
    }    
    
    /**
     * Retrieves the undoable edit object from the event.
     *
     * @return The undoable edit object.
     *
     * @status Documented
     */
    public QueryEdit getEdit() {
        return _undo;
    }

    // Allow setting of the source to reflect client side
    void setSource(Query s) {
        super.setSource(s);
        // Make sure the undo we have is in synch
        _undo.setQuery(s);
    }
    
    /** 
     * @hidden
     * @serial Undoable edit field
     */
    protected QueryEdit _undo = null;
}