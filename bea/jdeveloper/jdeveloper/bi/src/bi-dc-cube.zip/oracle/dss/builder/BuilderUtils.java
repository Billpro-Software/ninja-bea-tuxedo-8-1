/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.builder;

import java.awt.*;
import javax.swing.*;

/*
 * @hidden
 */
public class BuilderUtils {

    /*
     * Public
     */
    
    /*
     * @hidden
     */
    public static void setCursor(Component parent, int predefCursor) {
        if (parent != null) { 
            Window parentWindow = SwingUtilities.windowForComponent (parent);
            if (parentWindow != null) {
                // Set the cursor on the parent Window
                parentWindow.setCursor(Cursor.getPredefinedCursor(predefCursor));
            }   
            else {
                // Set the cursor on the component
                parent.setCursor(Cursor.getPredefinedCursor(predefCursor));
            }
        } 
    }
}
