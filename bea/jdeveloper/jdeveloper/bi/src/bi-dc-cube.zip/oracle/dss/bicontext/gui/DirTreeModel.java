/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import javax.swing.tree.TreeModel;

import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;

import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;

/**
 * @hidden
 * A tree model that works with JNDI sources
 */
public interface DirTreeModel extends TreeModel, ErrorHandlerCallback
{
    /**
     * @hidden
     */
    public boolean orderInsert();
    
    /**
     * Retrieves the initial context used by the model
     *
     * @return A connection to the server
     * @status New
     */
    public DirContext getInitialContext();

    /**
     * Sets the initial context used by the model.
     *
     * @param con the initial context used by the model.
     * @status New
     */
    public void setInitialContext(DirContext con);

    /**
     * Gets the search filter used to populate the model
     *
     * @return the search filter used to populate the model
     * @status New
     */
    public Attributes getSearchFilters();

    /**
     * Sets the search filter used to populate the model
     *
     * @param props  The search filter used to populate the model
     * @status New
     */
    public void setSearchFilters(Attributes props);

    /**
     * Gets the <code>SearchControls</code> used to populate the model
     *
     * @return the search filter used to populate the model
     * @status New
     */
    public SearchControls getSearchControls();

    /**
     * Sets the <code>SearchControls</code> used to populate the model
     *
     * @param props  The search filter used to populate the model
     * @status New
     */
    public void setSearchControls(SearchControls controls);

    /**
     * Reports if the model is currently configured to show
     * leaf (as well as container) nodes.
     *
     * @return true if the model is currently configured to
     * show leaf (as well as container) nodes.
     * @status New
     */
    public boolean getAllowsLeafNodes();

    /**
     * Determines if the model is to show leaf (as well as
     * container) nodes.
     *
     * @param allow true if the model is to show leaf (as
     * well as container) nodes.
     * @status New
     */
    public void setAllowsLeafNodes(boolean allow);

    /**
     * Informs the tree that a particular node's structure
     * has changed and its view needs to be updated.
     *
     * @param node The node which has changed
     * @status New
     */
    public void fireTreeStructureChanged(DirTreeNode node);

    /**
     * Informs the tree that a particular node's structure
     * has changed and its view needs to be updated.
     *
     * @param node The node which has changed
     * @status New
     */
    public void fireTreeNodeChanged(DirTreeNode node);

    /**
     * Informs the tree that a new node is inserted and
     * its view needs to be updated.
     *
     * @param node The node which has changed
     * @status New
     */
    public void fireTreeNodeInserted(DirTreeNode node, int index);

    /**
     * Informs the tree that a new node is inserted and
     * its view needs to be updated.
     *
     * @param node The node which has changed
     * @param children The index of the children nodes removed
     * @status New
     */
    public void fireTreeNodesRemoved(DirTreeNode node, int[] children);

    /**
     * Retrieve the <code>ErrorHandler</code>
     */
    public ErrorHandler getErrorHandler();
}
