/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

/****************************************************
 * Imports
 ****************************************************/
import java.lang.Object;

/**
 * An object in the MetadataManager that does not represent a metadata object.
 * A <code>UserObject</code> normally stores a <code>Persistable</code>.
 * Then, the <code>UserObject</code> is stored in an <code>MDComponent</code>
 * object in the MetadataManager.
 *
 * @see oracle.dss.util.persistence.Persistable
 * @see oracle.dss.metadataManager.common.MDComponent
 * @see oracle.dss.metadataManager.common.MDObject
 */
/**
 * @hidden
 */
public class UserObject extends PropertyBag{
    /************************************************************************
    * Private members
    ************************************************************************/
    private Object m_UserObject = null;

    /**
     * Constructor.
     * The object will be cached both on the client tier and on the
     * middle tier.
     *
     * @param object    The <code>Object</code> to store in this
     *                  <code>UserObject</code>. The object should implement
     *                  the <code>Persistable</code> interface.
     * @param driverType  The type of driver that will store this
     *                     <code>UserObject</code>.Pass
     *                   <code>MDU.PERSISTENCE</code>.
     *
     * @see MDU#PERSISTENCE
     *
     * @status documented
     */
    public UserObject(Object object, String driverType) {
        setObject(object);
        setCacheSemantic(MDU.BOTH);
        setStrPropertyValue( MDU.DRIVER_TYPE, driverType, MDU.UI_ALL );
    }

    /**
     * @hidden
     * Constructor that specifies cache semantics.
     *
     * @param object    The <code>Object</code> to store in this
     *                  <code>UserObject</code>. The object should implement
     *                  the <code>Persistable</code> interface.
     * @param driverType  The type of driver that will store this
     *                     <code>UserObject</code>. Pass
     *                   <code>MDU.PERSISTENCE</code>.
     * @param cacheSemantic  A constant that identifies the caching behavior
     *                     for this object. The constants are listed in the
     *                     See Also section.
     *
     * @see MDU#PERSISTENCE
     * @see MDU#CLIENT_ONLY
     * @see MDU#SERVER_ONLY
     * @see MDU#BOTH
     * @see MDU#NONE
     *
     * @status documented
     */
    public UserObject(Object object, String driverType, int cacheSemantic) {
        setObject(object);
        setCacheSemantic(cacheSemantic);
        setStrPropertyValue( MDU.DRIVER_TYPE, driverType, MDU.UI_ALL );
    }

    /************************************************************************
    * Public Methods
    ************************************************************************/
    /**
     * Specifies an object to store in this <code>UserObject</code>.
     * The object must implement the Persistable interface.
     *
     * @param object  The object to store in this <code>UserObject</code>.
     *
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status documented
     */
    public void setObject ( Object object ){
        m_UserObject = object;
        return;
    }

    /**
     * Retrieves the object that this <code>UserObject</code> stores.
     *
     * @return  The object that this object stores.
     *
     * @status documented
     */
    public Object getObject() {
        return m_UserObject;
    }

    /**
     * @hidden
     * Retrieves the cache semantics for this <code>UserObject</code>.
     * This method returns a constant that indicates where the object is
     * cached, either on the client, on the middle tier, on both, or not
     * cached at all.
     *
     * @return  A constant that indicates the type of caching used for this
     *          object. Valid constants are listed in the See Also section.
     *
     * @see MDU#CLIENT_ONLY
     * @see MDU#SERVER_ONLY
     * @see MDU#BOTH
     * @see MDU#NONE
     *
     * @status documented
     */
    public int getCacheSemantic() {
        return getIntPropertyValue( MDU.CACHE_SEMANTIC );
    }

    /**
     * Retrieves the type of driver that stores this <code>UserObject</code>.
     *
     * @return  The type of driver for this <code>UserObject</code>. This
     *          method should return <code>MDU.PERSISTENCE</code>.
     *
     * @see MDU#PERSISTENCE
     *
     * @status documented
     */
    public String getDriverType() {
        return getStrPropertyValue( MDU.DRIVER_TYPE );
    }

    /**
     * @hidden
     * Specifies the cache semantics for this <code>UserObject</code>.
     *
     * @param cacheSemantic  A constant that represents the type of caching
     *                       used for this <code>UserObject</code>. Valid
     *                       constants are listed in the See Also section.
     *
     * @see MDU#CLIENT_ONLY
     * @see MDU#SERVER_ONLY
     * @see MDU#BOTH
     * @see MDU#NONE
     *
     * @status documented
     */
    public void setCacheSemantic( int cacheSemantic ) {
        setIntPropertyValue( MDU.CACHE_SEMANTIC, cacheSemantic );
    }
}
