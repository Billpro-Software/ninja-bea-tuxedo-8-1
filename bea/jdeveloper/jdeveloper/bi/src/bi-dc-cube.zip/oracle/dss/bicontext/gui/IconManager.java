/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.Hashtable;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;
import javax.swing.ImageIcon;

import oracle.bali.ewt.graphics.ImageUtils;

/**
 * @hidden
 * The IconManager maintains a list of icons which are associated with a lookup key.
 * The initial information is obtained from images.dat file, which contains a list
 * of filename of image and the associated key.
 */
public final class IconManager
{
    private static Hashtable s_packageImages = new Hashtable();
    private static Hashtable s_shortcutImages = new Hashtable();
    private static Properties s_props = new Properties();
    private static ImageIcon s_modifier = null;

    static
    {
    	InputStream _fis = IconManager.class.getResourceAsStream("images.dat");

    	if (_fis != null)
        {
            try
            {
        	    s_props.load(_fis);
            	_fis.close();
            }
            catch(IOException ioe)
            {
            	ioe.printStackTrace();
            }
        }

        s_modifier = new ImageIcon(ImageUtils.getImageResource(IconManager.class, "images/shortcut_overlay.gif"));
    }

    /**
     * Returns the icon associated with the specified key
     *
     * @param name - the name of the key associated with the icon
     * @return the icon associated with the key
     * @status New
     */
    public static ImageIcon getIcon(String name)
    {
        String _imageFileName = (String)s_props.get(name);
        ImageIcon _icon = (ImageIcon)s_packageImages.get(name);
        if (_icon == null)
        {
        	if (_imageFileName != null)
        	    _icon = new ImageIcon(ImageUtils.getImageResource(IconManager.class, "images/"+_imageFileName));
            else
        	    _icon = new ImageIcon(ImageUtils.getImageResource(IconManager.class, "images/genobject.gif"));

            if (_icon != null)
                s_packageImages.put(name, _icon);
        }

        return _icon;
    }

    /**
     * Returns the icon associated with the specified key
     *
     * @param name - the name of the key associated with the icon
     * @return the icon associated with the key
     * @status New
     */
    public static ImageIcon getShortcutIcon(String name)
    {
        ImageIcon _icon = (ImageIcon)s_shortcutImages.get(name);
        if (_icon == null)
        {
            _icon = new ShortcutIcon(getIcon(name), s_modifier);                
            if (_icon != null)
                s_shortcutImages.put(name, _icon);
        }

        return _icon;
    }

    /**
     * Register a new icon with the manager
     *
     * @param type - the key associated with the icon
     * @param icon - the icon
     * @status New
     */
    public static void registerIcon(String type, ImageIcon icon)
    {
        s_packageImages.put(type, icon);
    }

    /**
     * Unregister an icon from the manager
     *
     * @param type - the key of the icon to unregister
     * @status New
     */
    public static void unregisterIcon(String type)
    {
        s_packageImages.remove(type);
    }

    /**
     * Register a new shortcut icon with the manager
     *
     * @param type - the key associated with the icon
     * @param icon - the icon
     * @status New
     */
    public static void registerShortcutIcon(String type, ImageIcon icon)
    {
        s_shortcutImages.put(type, icon);
    }

    /**
     * Unregister an icon from the manager
     *
     * @param type - the key of the icon to unregister
     * @status New
     */
    public static void unregisterShortcutIcon(String type)
    {
        s_shortcutImages.remove(type);
    }    
}
