/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/BuilderException.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.builder;

import java.text.MessageFormat;

import oracle.dss.util.gui.ResourceHandler;

import oracle.dss.util.BIBaseException;

/**
 * <pre>
 * Provides non-runtime exceptions that are thrown specifically by the 
 * <code>Builder</code>.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.7
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   08/15/07 - 
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 *    gkellam   11/09/05 - Add support for ResourceHandler. 
 *    gkellam   09/09/05 - Move from CalcBuilder. 
 *
 */

public class BuilderException extends BIBaseException {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * The <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @status hidden
   */
  private transient Object[] m_objMergeArray = null;

  /**
   * Retrieves the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @return A <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @status hidden
   */
  private transient ResourceHandler m_resourceHandler = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>BuilderException</code> constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated
   *        error string in the resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be null).
   *
   * @status new
   */
  public BuilderException (String strErrorCode, Throwable throwable) {
    super (strErrorCode, throwable);
  }

  /**
   * <code>BuilderException</code> constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated
   *        error string in the resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be null).
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the error message.
   * 
   * @status new
   */
  public BuilderException (String strErrorCode, Throwable throwable, Object[] objMergeArray) {
    super (strErrorCode, throwable);
    setMergeArray (objMergeArray);
  }

  /**
   * <code>BuilderException</code> constructor.
   *
   * @param resourceHandler A <code>ResourceHandler</code> used for resource retrieval.
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated
   *        error string in the resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be null).
   *
   * @status new
   */
  public BuilderException (ResourceHandler resourceHandler, String strErrorCode, Throwable throwable) {
    super (strErrorCode, throwable);
    setResourceHandler (resourceHandler);
  }

  /**
   * <code>BuilderException</code> constructor.
   *
   * @param resourceHandler A <code>ResourceHandler</code> used for resource retrieval.
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated
   *        error string in the resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be null).
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the error message.
   * 
   * @status new
   */
  public BuilderException (ResourceHandler resourceHandler, String strErrorCode, 
                          Throwable throwable, Object[] objMergeArray) {
    super (strErrorCode, throwable);
    setMergeArray (objMergeArray);
    setResourceHandler (resourceHandler);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the error message.
   * If the error associated with the original error code is not found,
   * then this method retrieves the original error code.
   *
   * The message is formatted as follows:
   * ErrorCode <space> ErrorString
   *
   * For example: DVT-1500 MetadataManager not set
   *
   * @return <code>String</code> that represents the formatted error message.
   *
   * @status new
   */
  public String getMessage() {
    // Retrieve the initial Error code
    String strMessage = super.getMessage();

    if (strMessage != null) {
      // Retrieve our error string
      String strError = strMessage;
      if ((strMessage != null) && (getResourceHandler() != null)) {
        strError = getResourceHandler().getResourceString (strMessage);  
      }

      if (strError != null) {
        // Create our new error message
        //  ErrorCode <space> ErrorString
        //  DVT-1500 MetadataManager not set
        StringBuffer strBuffer = new StringBuffer (strMessage);
        strBuffer.append (" ");

        // Determine if any objects needs to be merged
        Object[] objMergeArray  = getMergeArray();
        if (objMergeArray != null) {
          strError = MessageFormat.format (strError, objMergeArray);
        }

        return strBuffer.append(strError).toString();
      }
    }

    return strMessage;
  }

  /**
   * Specifies the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @param resourceHandler A <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @status new 
   */
  public void setResourceHandler (ResourceHandler resourceHandler) { 
    m_resourceHandler = resourceHandler;
  }

  /**
   * Retrieves the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @return A <code>ResourceHandler</code> used for resource retrieval..
   * 
   * @status new 
   */
  public ResourceHandler getResourceHandler() { 
    return m_resourceHandler; 
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden 
   *
   * Specifies the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the exception's error message.
   *
   * @status protected
   */
  protected void setMergeArray (Object[] objMergeArray) {
    m_objMergeArray = objMergeArray;
  }

  /**
   * @hidden 
   *
   * Retrieves the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @return <code>Object[]</code> which is to be merged with the exception's
   *         error message.
   *         
   * @status protected   
   */

  protected Object[] getMergeArray() {
    return m_objMergeArray;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}