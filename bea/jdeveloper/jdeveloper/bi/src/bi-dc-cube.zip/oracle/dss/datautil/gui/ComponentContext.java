/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Component;

import java.util.Vector;

/**
 * Contains methods that common data-utility graphical user interface component  
 * objects require for instantiation, often in conjunction with <code>QueryBuilder</code> 
 * or <code>CalcBuilder</code>.
 *
 * @status documented
 */
public interface ComponentContext extends GuiContext
    {
    /**
     * Retrieves the type of display labels for this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @return   The display label type. Valid values are enumerations from
     *           the <code>LayerMetadataMap</code> such as long, short, or
     *           medium labels.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public String getDisplayLabelType ();

    /**
     * Specifies the type of display member labels for the measures that are
     * displayed in this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @param  strDisplayMemberLabelType The display label type. Valid values are
     *                                   enumerations from
     *                                   <code>util.MetadataMap</code> such as
     *                                   long, short, or medium labels.
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public void setDisplayMemberLabelType (String displayMemberLabelType);
    
    /**
     * Retrieves the type of display member labels for this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @return   The display member label type. Valid values are enumerations from
     *           the <code>LayerMetadataMap</code> such as long, short, or
     *           medium labels.
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public String getDisplayMemberLabelType ();

    /**
     * Specifies the type of display labels for the dimensions that are
     * displayed in this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @param  strDisplayLabelType The display label type. Valid values are
     *                             enumerations from
     *                             <code>util.LayerMetadataMap</code> such as
     *                             long, short, or medium labels.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public void setDisplayLabelType (String displayLabelType);

    /**
     * Retrieves the item count of all popup instances in this 
     * <code>Component</code>.
     *
     * @return The popup item count that is associated with this <code>Component</code>.
     *
     * @status documented
     */
    public int getPopupItemCount ();

    /**
     * Specifies the item count of all popup instances in this 
     * <code>Component</code>.
     *
     * @param nPopupItemCount The popup item count that is associated
     *                        with this <code>Component</code>.
     *
     * @status documented
     */
    public void setPopupItemCount (int nPopupItemCount);

    /**
     * Retrieves the list of measures that specify the initial context for this
     * <code>Component</code> instance.
     *
     * @return The list of measures that specify the initial context for this
     *         <code>Component</code> instance.
     *
     * @status documented
     */
    public Vector getMeasureContext ();

    /**
     * Specifies the list of measures that specify the initial context for this
     * <code>Component</code> instance.
     *
     * @param measures The list of measures that specify the initial context
     *                 for this <code>Component</code> instance.
     *
     * @status documented
     */
    public void setMeasureContext (Vector measures);

    /**
     * Retrieves the list of dimensions that specify the initial context for this
     * <code>Component</code> instance.
     *
     * @return The list of dimensions that specify the initial context for this
     *         <code>Component</code> instance.
     *
     * @status documented
     */
    public Vector getDimensionContext ();

    /**
     * Specifies the list of dimensions that specify the initial context for this
     * <code>Component</code> instance.
     *
     * @param dimensions The list of dimensions that specify the initial context
     *                 for this <code>Component</code> instance.
     *
     * @status documented
     */
    public void setDimensionContext (Vector dimensions);

    /**
     * Retrieves the parent of this <code>Component</code> instance.
     *
     * @return The parent of this <code>Component</code> instance.
     *
     * @status documented
     */
    public Component getParent ();

    /**
     * Specifies the parent of this <code>Component</code> instance.
     *
     * @param component The parent of this <code>Component</code> instance.
     *
     * @status documented
     */
    public void setParent (Component component);
    }

