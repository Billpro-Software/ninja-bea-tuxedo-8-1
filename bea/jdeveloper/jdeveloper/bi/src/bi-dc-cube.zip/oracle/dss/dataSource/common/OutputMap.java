/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.Hashtable;
import java.util.Enumeration;

/**
 * @hidden
 * Relate a map type to an array of cursor output positions.
 * Also provide a two-way lookup of source IDs to MM ids
 */
public class OutputMap extends Object implements java.io.Serializable, Cloneable
{
    protected Hashtable m_table = new Hashtable();
    protected Hashtable m_posTable = new Hashtable();
    protected Hashtable m_sourceIDToMM = new Hashtable();
    protected Hashtable m_MMToSourceID = new Hashtable();

    public void deleteMMID(String ID)
    {
        String sourceID = (String)m_MMToSourceID.get(ID);
        if (sourceID != null)
        {
            m_sourceIDToMM.remove(sourceID);
            m_MMToSourceID.remove(ID);
        }
    }

    public void storeSourceID(String sourceID, String MMID)
    {
        deleteMMID(MMID);
        m_sourceIDToMM.put(sourceID, MMID);
        m_MMToSourceID.put(MMID, sourceID);
    }

    public String getMMFromSourceID(String sourceID)
    {
        return (String)m_sourceIDToMM.get(sourceID);
    }


    public void clearDimension(String dimension)
    {
        Hashtable dimTable = _getTableForDimension(dimension);
        if (dimTable != null)
        {
            dimTable.clear();            
        }
        m_posTable.remove(dimension);
    }
    
    public void setType(String dimension, String type, int numPositions)
    {
        // Retrieve the table for the given dimension, or create one if not found
        Hashtable dimTable = _getTableForDimension(dimension);
        if (dimTable == null)
        {
            dimTable = new Hashtable();
            m_table.put(dimension, dimTable);
        }
        // Create an array containing the next numPositions positions
        // and store it relating to this type
        int currentPosition = _getCurrentPosition(dimension);        
        int[] posArray = new int[numPositions];
        for (int pos = 0; pos < numPositions; pos++)
        {
            posArray[pos] = currentPosition++;
        }
        dimTable.put(type, posArray);
        _setCurrentPosition(dimension, currentPosition);
    }
    
    public String getTypeForPosition(String dimension, int position)
    {
        Hashtable dimTable = _getTableForDimension(dimension);
        if (dimTable != null)
        {
            Enumeration keys = dimTable.keys();
            while (keys.hasMoreElements())
            {
                String key = (String)keys.nextElement();
                int[] positions = (int[])dimTable.get(key);
                if (positions != null)
                {
                    for (int i = 0; i < positions.length; i++)
                        if (position == positions[i])
                            return key;
                }
            }
        }
        return null;
    }
    
    public int[] getPositions(String dimension, String type)
    {
        Hashtable dimTable = _getTableForDimension(dimension);
        return (int[])dimTable.get(type);
    }

    public Object clone() throws CloneNotSupportedException
    {
        OutputMap newMap = new OutputMap();
        Enumeration keys = m_posTable.keys();
        Object key = null;
        while (keys.hasMoreElements())
        {
            key = keys.nextElement();
            Integer val = (Integer)m_posTable.get(key);
            newMap.m_posTable.put(key, new Integer(val.intValue()));            
        }
        keys = m_table.keys();
        while (keys.hasMoreElements())
        {
            key = keys.nextElement();
            Hashtable table = (Hashtable)m_table.get(key);
            Enumeration subKeys = table.keys();
            Object subkey = null;
            Hashtable newTable = new Hashtable();
            while (subKeys.hasMoreElements())
            {
                subkey = subKeys.nextElement();
                int[] val = (int[])table.get(subkey);
                int[] newVal = new int[val.length];
                for (int i = 0; i < val.length; i++)
                {
                    newVal[i] = val[i];
                }
                newTable.put(subkey, newVal);
            }
            newMap.m_table.put(key, newTable);
        }

        newMap.m_sourceIDToMM = (Hashtable)m_sourceIDToMM.clone();
        newMap.m_MMToSourceID = (Hashtable)m_MMToSourceID.clone();
        return newMap;
    }
    
    private void _setCurrentPosition(String dimension, int currentPosition)
    {
        m_posTable.remove(dimension);
        m_posTable.put(dimension, new Integer(currentPosition));
    }
    
    private int _getCurrentPosition(String dimension)
    {
        Integer currentPosition = (Integer)m_posTable.get(dimension);
        if (currentPosition == null)
        {
            // Must generate a new one
            currentPosition = new Integer(0);            
        }
        
        return currentPosition.intValue();
    }
    
    private Hashtable _getTableForDimension(String dimension)
    {
        return (Hashtable)m_table.get(dimension);
    }    
}