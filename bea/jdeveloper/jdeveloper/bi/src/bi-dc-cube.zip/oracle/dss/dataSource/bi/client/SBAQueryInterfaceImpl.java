/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAQueryInterfaceImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/28/06 - 
    jramanat    07/10/06 - 
    bmoroze     07/07/06 - 
    jramanat    06/14/06 - 
    bmoroze     05/12/06 - 
    jramanat    04/20/06 - SBA-style drilling 
    imohamma    04/13/06 - 
    bmoroze     04/11/06 - 
    jramanat    04/06/06 - Escape all SQL strings 
    imohamma    03/02/06 - 
    bmoroze     03/03/06 - 
    jramanat    03/02/06 - 
    bmoroze     02/27/06 - 
    jramanat    02/16/06 - Add SBA pluggable 
    jramanat    02/16/06 - Add SBA pluggable 
    jramanat    02/16/06 - Creation
 */

package oracle.dss.dataSource.bi.client;

import java.util.ArrayList;
import java.util.BitSet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import oracle.dss.connection.common.CB;
import oracle.dss.dataSource.client.CommonQueryInterfaceImpl;
import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.DataDirectorImpl;
import oracle.dss.dataSource.common.Delegate;
import oracle.dss.dataSource.common.DimTree;
import oracle.dss.dataSource.common.InvalidMetadataException;
import oracle.dss.dataSource.common.Node;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryUtil;
import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.drill.ItemDrill;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.Utility;
import oracle.dss.util.transform.BaseNode;
import oracle.dss.util.transform.BaseProjection;
import oracle.dss.util.transform.ResultTable;
import oracle.dss.util.transform.RowBasedCubicDataAccess;
import oracle.dss.util.transform.TabularDataAccess;
import oracle.dss.util.transform.TransformException;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAQueryInterfaceImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */
public abstract class SBAQueryInterfaceImpl extends CommonQueryInterfaceImpl {
  // Master result set + table
  protected ResultTable m_rt = null;
  protected List<DataAccess> m_da = new ArrayList<DataAccess>();
  //protected DrillSupport m_drillSupport = null;

  public SBAQueryInterfaceImpl(Query query) {
    super(query);
  }
  
  protected BitSet _setItems(String[] dataItems, String[] items, String[][] layout) throws QueryException
  {
      DimTree oldTree = m_query._getQueryState().getDimTree();
      
      // Must have a list of data items: put them in their own list
      // If items is set, assume everything's a data item
      // ID of data item
      Vector dataItemVecName = new Vector();
      // Default placement for data items
      Vector dataItemPlacement = new Vector();
      // ID for item
      Vector itemVecName = new Vector();
      // Default placement for item
      Vector itemPlacement = new Vector();
      boolean hasDataPoint = false;
      // Do we have a dimension tree?
      DimTree dt = m_query._getQueryState().getDimTree();
      boolean isTabular = isTabular();
      String measDim = m_query.getMeasureDim();
      if (dataItems != null)
      {
          for (int i = 0; i < dataItems.length; i++)
          {
              if (!isTabular)
                  hasDataPoint = true;            
              if (dataItems[i].equals(measDim))
                  continue;
            
              MDItem mdObj = null;
              try
              {
                  MDObject obj = m_query.getMDObject(MM.UNIQUE_ID, dataItems[i], MM.ITEM);
                  if (obj instanceof MDItem)
                      mdObj = (MDItem)obj;
              }
              catch (MetadataManagerException mme)
              {
                  throw new QueryException(mme.getMessage(), mme);
              }
              dataItemVecName.addElement(dataItems[i]);
              dataItemPlacement.addElement(new Object[] {dataItems[i], new Integer(DataDirector.COLUMN_EDGE)});
          }      
      }
        
      // Save this because we want to set this as the data Item state
      Vector origDataItemVecName = dataItemVecName != null ? (Vector)dataItemVecName.clone() : null;
        
      // Go through item loop--place meas dim in list if hasDataPoint
      Vector itemLocVecName = isTabular ? dataItemVecName : itemVecName;
      Vector itemLocPlacement = isTabular ? dataItemPlacement : itemPlacement;
      if (hasDataPoint && !isTabular)
      {
          itemLocVecName.addElement(measDim);
          itemLocPlacement.addElement(new Object[] {measDim, new Integer(DataDirector.COLUMN_EDGE)});
      }
      if (items != null)
      {
          for (int i = 0; i < items.length; i++)
          {
              if (items[i].equals(measDim))
                  continue;
            
              MDItem mdObj = null;
              try
              {
                  MDObject obj = m_query.getMDObject(MM.UNIQUE_ID, items[i], MM.ITEM);
                  if (obj instanceof MDItem)
                      mdObj = (MDItem)obj;
              }
              catch (MetadataManagerException mme)
              {
                  throw new QueryException(mme.getMessage(), mme);
              }
              // Check if we have it: skip if we're setting up a brand new layout--otherwise, keep 
              // it because we'll handle it later
              if (dt != null && mdObj != null && dt.getNode(mdObj.getUniqueID()) != null && layout == null)
                  continue;
            
              itemLocVecName.addElement(items[i]);
              itemLocPlacement.addElement(new Object[] {items[i], new Integer(mdObj == null ? DataDirector.PAGE_EDGE : i > 2 ? DataDirector.COLUMN_EDGE : DataDirector.ROW_EDGE)});
          }
      }
      
      dataItems = (String[])origDataItemVecName.toArray(new String[] {});    
    
      // Place items in "default" locations if items layout not specified
      if (layout == null)
      {
          // Do we have a dimtree?  If so, just add this stuff to the page
          if (isTabular)
          {
              if (dt != null)
              {
                  // Must explicitly add to page: can't go in row
                  dt.addNodes(_getNodes(dataItemVecName), dataItemPlacement, -1, true);
              }
              else
              {
                  dt = new DimTree(hasDataPoint ? measDim : null, _getNodes(dataItemVecName), dataItemPlacement, false);
              }
          }
          else
          {
              if (dt != null)
                  dt.addNodes(_getNodes(itemLocVecName), itemPlacement, -1, false);
              else
                  dt = new DimTree(hasDataPoint ? measDim : null, _getNodes(itemLocVecName), itemPlacement, false);
          }
          try
          {
              layout = Node.getStringArray(dt.getDimTree());
              m_query._getQueryState().setDimTree(dt);
          }
          catch (CloneNotSupportedException e)
          {
              throw new CloneException(e.getMessage(), e);
          }                
      }
      else
      {
          // Make sure the layout is completely in sync with the items and data items we have          
          dt = new DimTree(Node.getNodeArray(layout, null, null), null);
          // If we have data items, make sure we have a meas dim.  Conversely, make sure we
          // remove it if we don't
/*          BaseNode measNode = dt.getNode(measDim);
          if (dataItems == null && measNode != null)
          {
              // Remove meas dim if there
              dt.removeNode(measNode);
          }
          if (dataItems != null && measNode == null)
          {
              // Add meas dim if not there
              dt.addNode(new Node(measDim), DataDirector.COLUMN_EDGE);
          }*/
          // Now take care of the rest of the items, *except* the meas dim
          // First remove those that are not in the list
          dt.pruneExtraNodes(_getNodes(itemLocVecName));
          dt.addNodes(_getNodes(itemLocVecName), itemPlacement, -1, false);          
      }    
    
      // Make sure we retain this state
      m_query._getQueryState().setMeasures(dataItems);
      m_query._getQueryState().setDimTree(dt);
      evaluate(false);
      
      return getDimensionTree().getEdgeDifferences(oldTree);
  }

  protected abstract void evaluate(boolean refresh) throws QueryException;


  protected boolean isSAS() {
    return getConnection().getProperty(CB.SOAP) == null;    
  }

  protected oracle.dss.connection.client.Connection getConnection() {
    return ((MetadataManager)getMetadataManager()).getConnections()[0];
  }
  
  // Generate an evaluator context
  protected Hashtable getEvaluatorContext() {
    Hashtable context = new Hashtable();    
    return context;
  }

  private BaseNode[] _getNodes(Vector items) {
    BaseNode[] nodes = new BaseNode[items.size()];
    int count = 0;
    Enumeration itemEnum = items.elements();
    while (itemEnum.hasMoreElements()) {
      nodes[count++] = new Node((String)itemEnum.nextElement());
    }
    return nodes;
  }
  
  public BitSet addItems(String[] dataItems, String[] items) throws QueryException {
    // Save old tree for comparison
    DimTree oldTree = null;
    try {
      oldTree = (DimTree)m_query._getQueryState().getDimTree().clone();
    }
    catch (CloneNotSupportedException e) {
      throw new CloneException(e.getMessage(), e);
    }
    boolean startWithNone = false;
    String[] oldDataItems = m_query.getDataItems();
    if (oldDataItems == null || oldDataItems.length == 0) {
        startWithNone = true;
    }

    // Make sure we don't have duplicates
    Vector newDataItems = new Vector();
    int oldDataItemsLength = oldDataItems != null ? oldDataItems.length : 0;
    int dataItemsLength = dataItems != null ? dataItems.length : 0;
    for (int i = 0; i < oldDataItemsLength + dataItemsLength; i++) {
      Object item = i < oldDataItemsLength ? oldDataItems[i] : dataItems[i - oldDataItemsLength];
      if (newDataItems.indexOf(item) == -1)
        newDataItems.addElement(item);
    }

    String[] olditems = m_query.getItems();
    if (olditems == null)
        olditems = new String[0];
    // Make sure we don't have duplicates
    Vector newItems = new Vector();
    int olditemsLength = olditems != null ? olditems.length : 0;
    for (int i = 0; i < olditemsLength + (items == null ? 0 : items.length); i++)
    {
        Object item = i < olditemsLength ? olditems[i] : (items == null ? null : items[i-olditemsLength]);
        if (newItems.indexOf(item) == -1)
            newItems.addElement(item);
    }
    _setItems((String[])newDataItems.toArray(new String[]{}), (String[])newItems.toArray(new String[]{}), null);        

    BitSet edges = getDimensionTree().getEdgeDifferences(oldTree);
    QueryUtil.setDirtyEdgeBit(getDimensionTree(), edges, m_query.getMeasureDim(), false);    
    return startWithNone ? null : edges;
  }
  
  public void cancel() throws QueryException {
    
  }

  public Delegate createRelationalDataDirector() {
    SBADataDirector dd = new SBADataDirector(m_query);
    //setDataAccessInDataDirector(dd);
    return dd;
  }
    
  public Delegate createCubeDataDirector() {
    SBADataDirector dd = new SBADataDirector(m_query);
    //setDataAccessInDataDirector(dd);
    return dd;
  }

  /*protected void setDataAccessInDataDirector(SBADataDirector dd) {
    try {
      DataAccess[] da = generateDataAccess(new DataDirector[] {dd}, -1);
      if (da != null && da.length > 0)
        dd.setDataAccess((DataAccess)da[0]);
    }
    catch (QueryException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }        
  }
*/
  public DataDirector getDataDirector(DataAccess da) {
    return null;
  }

  public String[][] getDefaultLayout(String[] dataItems, String[] items) throws QueryException {
    return null;
  }

    private Hashtable<String, String>[] buildLayerNameLookup(String layerType) throws QueryException
    {
        if (layerType.equals(LayerMetadataMap.LAYER_METADATA_NAME))
            return new Hashtable[] {null, null};
        
        // Build a table of name->IDs
        Hashtable<String, String> layerNameLookup = new Hashtable<String,String>();
        Hashtable<String, String> idLookup = new Hashtable<String, String>();
        String[][] idLayout = m_query.getLayout();
        String[][] layerLayout = m_query.getLayout(layerType);
        for (int e = 0; e < idLayout.length; e++)
        {
            if (idLayout[e] != null)
            {
                for (int l = 0; l < idLayout[e].length; l++)
                {
                    layerNameLookup.put(layerLayout[e][l], idLayout[e][l]);
                    idLookup.put(idLayout[e][l], layerLayout[e][l]);
                }
            }
        }
        // Now put data items in there
        String[] dataItems = m_query.getDataItems();
        if (dataItems != null)
        {
            MDObject obj = null;
            String typeName = null;
            for (int i = 0; i < dataItems.length; i++)
            {
                // Get the appropriate type name
                try
                {
                    obj = m_query.getMDObject(MM.UNIQUE_ID, dataItems[i], MM.OBJECT);
                }
                catch (MetadataManagerException e)
                {
                    throw new InvalidMetadataException(e.getMessage(), dataItems[i], e);
                }
                typeName = QueryUtil.getLayerMetadata(layerType, obj);
                layerNameLookup.put(typeName, dataItems[i]);
                idLookup.put(dataItems[i], typeName);
            }
        }
        return new Hashtable[] {layerNameLookup, idLookup};
    }

    // javadoc from interface
    public BaseProjection getProjection(String layerMetadataType) throws QueryException
    {
        if (m_rt != null)                
        {
            Hashtable<String, String>[] lookups = buildLayerNameLookup(layerMetadataType);
            
            return new RowIteratorProjection(new DataTableIterator(m_rt.getDataTable(), lookups[0], lookups[1]), m_query, (SBADataTable)m_rt.getDataTable(), layerMetadataType, lookups[0]);
        }
        return null;
    }
    
    protected void releaseDAs()
    {
        for (DataAccess da : m_da)
        {
            da.release();
        }
        m_da.clear();
    }
    
  public DataAccess[] generateDataAccess(DataDirector[] dd, int changeType) throws QueryException {
    if (dd == null || m_rt == null)
        return null;

    TabularDataAccess[] da = new TabularDataAccess[dd.length];    
    for (int i = 0; i < da.length; i++)
    {
        try
        {
            if (isTabular())
            {
                da[i] = new TabularDataAccess((ResultTable)m_rt.clone());
            }
            else
            {
                // Don't need to clone?
                da[i] = new RowBasedCubicDataAccess(m_rt, false, true);/*, m_drillSupport.getDrills().getResultTableInserts());*/
            }
            m_da.add(da[i]);
            
            da[i].setDataDirector(dd[i]);
            if (dd[i] instanceof DataDirectorImpl)
            {
                DataDirectorImpl ddi = (DataDirectorImpl)dd[i];
                if (ddi.getDelegate() instanceof SBADataDirector)
                {
                    ((SBADataDirector)ddi.getDelegate()).setDataAccess(da[i]);
                }
            }
            //if (m_query.isSharePage())
            //{
                // Poke the query page in then
                da[i].setCurrentPosition(DataDirector.PAGE_EDGE, m_query.getPropertySupport().getCurrentPage());
            //}
        }
        catch (TransformException te) {
          if (te instanceof QueryException) {
            throw (QueryException)te;
          }
          else {
            throw new QueryException(te.getMessage(), te);
          }
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
    }
    
    return da;
  }

  public Object isSupported(int capability, Object data) throws QueryException {
    return null;
  }

  public void setProperty(String property, Object value) throws QueryException {
    
  }

  public BitSet layout(String[][] items) throws QueryException {
    DimTree newTree = new DimTree(Node.getNodeArray(items, null, null), null);
    DimTree oldTree = m_query._getQueryState().getDimTree();
    BitSet edges = oldTree.getEdgeDifferences(newTree);
    setDimensionTree(newTree);
    releaseDAs();
    return edges;
  }

  public boolean loadQuery() throws QueryException {
    evaluate(false);
    return true;
  }

  public BitSet pivot(String source, String target, int flags) throws QueryException {
    DimTree newTree = null;
    try {
      newTree = (DimTree)getDimensionTree().clone();
    }
    catch (CloneNotSupportedException e) {
      throw new CloneException(e.getMessage(), e);
    }
  
    boolean bSuccess = QueryUtil.doPivot(source, target, flags, newTree);
  
    if (!bSuccess) {
      return null;
    }
  
    BitSet edges = getDimensionTree().getEdgeDifferences(newTree);
    setDimensionTree(newTree);
    releaseDAs();
    return edges;
  }

  public int pivotCheck(String source, String target, int flags) throws QueryException {
    return DataDirector.PIVOT_CHECK_OK;
  }

  public int swapCheck(String source, String target) throws QueryException {
    return DataDirector.PIVOT_CHECK_OK;
  }

  public BitSet swap(String source, String target) throws QueryException {
    
    DimTree newTree = null;
    try {
      newTree = (DimTree)getDimensionTree().clone();
    }
    catch (CloneNotSupportedException e) {
      throw new CloneException(e.getMessage(), e);
    }
  
    boolean bSuccess = QueryUtil.doSwap(source, target, newTree);
  
    if (!bSuccess) {
      return null;
    }
  
    BitSet edges = getDimensionTree().getEdgeDifferences(newTree);
    setDimensionTree(newTree);
      releaseDAs();
    return edges;
  }

  public void refresh(int type) throws QueryException {
    release();
    // Refresh caches
    evaluate(type == QueryConstants.REFRESH_CURSORS);
  }

  public void release() throws QueryException {
    if (m_rt != null)
    {
        try
        {
            m_rt.close();
            //m_drillSupport.close();
        }
        catch (Exception e)
        {
            throw new QueryException(e.getMessage(), e);
        }
    }
            
    m_rt = null;
    releaseDAs();
  }

    public BitSet removeItems(String[] items) throws QueryException
    {
        return removeItems(items, -1);
    }
    
  private BitSet removeItems(String[] items, int onEdge) throws QueryException {
    DimTree oldTree = null;
    try {
      oldTree = (DimTree)getDimensionTree().clone();            
    }
    catch (CloneNotSupportedException e) {
      throw new CloneException(e.getMessage(), e);
    }
  
    String[] meas = m_query._getQueryState().getMeasures();
    Vector dataItems = Utility.copyArrayToVector(meas);
    // Remove the dataitems
    if (items != null) {
      for (int i = 0; i < items.length; i++) {
        if (dataItems != null) {
          dataItems.remove(items[i]);
        }
      }
    }

      if (dataItems != null) {
        meas = (String[])dataItems.toArray(new String[dataItems.size()]);
      }

    String measID = m_query.getMeasureDim();

    // remove the regular items
    if (items != null) {        
        BaseNode[] nodes = new BaseNode[items.length];
        for (int i = 0; i < items.length; i++) {
            // Do not remove the measure item if we still have measures...
            if (items[i].equals(measID) && (meas != null && meas.length > 0))
                continue;
            nodes[i] = new Node(items[i]);
        }
        oldTree.removeNodes(nodes, onEdge);
    }    
  
    // Make sure to remove meas dim if we have no measures left
    if (meas == null || meas.length == 0)
    {
        String measDim = m_query.getMeasureDim();
        oldTree.removeNodes(new Node[] {new Node(measDim)});        
    }
    getQuery()._getQueryState().setMeasures(meas);
  
    try {
      BitSet retval = layout(Node.getStringArray(oldTree.getDimTree()));
        evaluate(false);
        return retval;
    }
    catch (CloneNotSupportedException e) {
      throw new CloneException(e.getMessage(), e);
    }
  }

  public void setCurrentPage(long page, QDR qdrPage) throws QueryException
  {
  }

  public boolean isDataAvailable() {
    return m_rt != null;
  }

  // javadoc from interface
  public BitSet setColumnSorts(ColumnSortWrapper[] sorts) throws QueryException {    
    // Store info
    m_query._getQueryState().setColumnSorts(sorts);
    evaluate(false);
    BitSet edges = new BitSet(3);
    for (int i = 0; i < edges.size(); i++)
      edges.set(i);
    return edges;
  }
  
  public BitSet setDataFilters(BaseDataFilter[] filters) throws QueryException
  {    
    // Store info
    m_query._getQueryState().setDataFilters(filters);
    
    BitSet edges = new BitSet(3);
    int size = edges.size();
    for (int i = 0; i < size; i++)
        edges.set(i);
    
    evaluate(false);
    return edges;
  }
    
    // blm - Selection code moved to dvt-olap
/*  public BitSet applySelections(Selection[] selections) throws QueryException {
    SelectionList oldSels = (SelectionList)getQuery()._getQueryState().getSelections();
    boolean reevaluate = false;
    BitSet edges = new BitSet();        
    if (selections != null) {
      for (int i = 0; i < selections.length; i++) {
        if (!selections[i].equals(oldSels.find(selections[i].getDimension()))) {
          oldSels.remove(selections[i]);
          oldSels.add(selections[i]);
          QueryUtil.setDirtyEdgeBit(getQuery()._getQueryState().getDimTree(), edges, selections[i].getDim(), false);
          reevaluate = true;
        }
      }
    }
    if (reevaluate) {        
      evaluate();        
    }
    return edges;
  }*/

    private QDR _removeMeasDimPair(QDR val)
    {
        if (val == null)
            return null;
        
        QDR newQDR = (QDR)val.clone();
        newQDR.removeDimMemberPair(getQuery()._getQueryState().getMeasureDim());
        return newQDR;
    }
    
  // javadoc from interface
  public void drill(String item, int onEdge, QDR[] value, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException {    
    // Merge in this drill with the ItemDrill for the item
    ItemDrill[] itemDrills = m_query._getQueryState().getItemDrills();
    Vector vDrills = new Vector();
    if (itemDrills != null) {
      for (int i = 0; i < itemDrills.length; i++) {
        vDrills.add(itemDrills[i]);
      }
    }
    // Remove measure dim from value QDR
    QDR val = _removeMeasDimPair(value[0]);
    
    ItemDrill itemDrill = new ItemDrill(item, val, drillPath[0], drillTarget[0], (BitSet)flags.clone());
    ItemRemoveStruct<String> oldItem = null;
    if (flags.get(DataDirector.DRILL_REPLACE)) {
      vDrills.add(itemDrill);
    }
    else if (flags.get(DataDirector.DRILL_BACK)) {
        try
        {
            oldItem = _removeDrillFromList(vDrills, itemDrill);
        }
        catch (MetadataManagerException me) {
            throw new QueryException(me.getMessage(), me);
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
    }

    itemDrills = (ItemDrill[])vDrills.toArray(new ItemDrill[vDrills.size()]);
    // Save state
    m_query._getQueryState().setItemDrills(itemDrills);
    
    try {
      if (flags.get(DataDirector.DRILL_REPLACE)) {
        applyItemDrill(itemDrill, flags);
      }
      else if (flags.get(DataDirector.DRILL_BACK)) {
          if (oldItem != null && oldItem.isReplace())
          {
              // Then we need to substitute, not remove
              DimTree oldTree = (DimTree)getDimensionTree().clone();     
              oldTree.replaceNode(new BaseNode(item), new BaseNode(oldItem.get(0)));
              layout(Node.getStringArray(oldTree.getDimTree()));
              evaluate(false);
          }
          else if (oldItem != null)
          {
              removeItems((String[])oldItem.toArray(new String[] {}), onEdge);
          }
          else
            removeItems(new String[] {itemDrill.getDrillPath(0)}, onEdge);
      }
    }
    catch (Exception e) {
      throw new QueryException(e.getMessage(), e);
    }
  }

    // Remove regardless of flag settings
    private ItemRemoveStruct _removeDrillFromList(Vector drills, ItemDrill drill) throws CloneNotSupportedException, MetadataManagerException
    {
        if (drills == null || drill == null)
            return null;
        
        int size = drills.size();
        ItemDrill currDrill = null;
        ItemDrill drillToCheck = (ItemDrill)drill.clone();
        // Make this a flag neutral removal
        drillToCheck.setFlags(new BitSet());
        BitSet replaceBits = new BitSet();        
        replaceBits.set(DataDirector.DRILL_REPLACE);
        // Make this a QDR value neutral removal
        drillToCheck.setValue(null);
        Vector drillPaths = _getDrillPaths(drillToCheck);
        boolean replace = false;
        ItemRemoveStruct retStruct = null;
        for (int i = size-1; i >= 0; i--)
        {
            currDrill = (ItemDrill)drills.elementAt(i);
            if (currDrill != null) {
                currDrill = (ItemDrill)currDrill.clone();
                if (currDrill.getFlags(0).equals(replaceBits))
                {
                    // This is a pure replace, so the item we want to match will be the drill path of the
                    // item in this drill
                    if (currDrill.getDrillPath(0).equals(drillToCheck.getItem()))
                    {
                        // Good enough
                        drills.removeElementAt(i);
                        if (retStruct == null)
                            retStruct = new ItemRemoveStruct(true);
                        retStruct.add(currDrill.getItem());
                    }
                }
                else
                {
                    currDrill.setFlags(new BitSet());
                    currDrill.setValue(null);
                    if (_drillUpEqual(drillToCheck, currDrill, drillPaths))                     
                    {
                        drills.removeElementAt(i);
                        if (retStruct == null)
                            retStruct = new ItemRemoveStruct(false);
                        retStruct.add(currDrill.getDrillPath(0));
                    }
                }
            }
        }
        return retStruct;
    }
    
    private class ItemRemoveStruct<String> extends ArrayList<String>
    {
        private boolean m_replace = false;
        
        public ItemRemoveStruct(boolean replace)
        {
            super();
            m_replace = replace;
        }
        
        public boolean isReplace()
        {
            return m_replace;
        }
    }
    
    private boolean _drillUpEqual(ItemDrill drillUp, ItemDrill currDrill, Vector drillPaths) throws MetadataManagerException
    {
        // If they're straight up equal, then we're drilling up on an exact drill down
        if (drillUp.getItem().equals(currDrill.getItem()))
            return true;
        
        // But, we want to make sure to clean up any child drill downs that happened as a result
        // of this drill up...
        // That means, we want to eliminate any drills that are in the ultimate drill path of 
        // the drillUp drill
        Vector<String> paths = _getDrillPaths(drillUp);
        for (String path : paths)
        {
            if (currDrill.getItem().equals(path))
                return true;
        }
        return false;
    }

    private Vector<String> _getDrillPaths(ItemDrill drill) throws MetadataManagerException
    {
        MDObject obj = m_query.getMDObject(MM.UNIQUE_ID, drill.getItem(), MM.ITEM);
        Vector<String> ret = new Vector<String>();
        if (obj instanceof MDItem)            
            return _getDrillPathsRecursive((MDItem)obj, ret);
        return ret;
    }
    
    private Vector<String> _getDrillPathsRecursive(MDItem item, Vector<String> ret) throws MetadataManagerException
    {
        Vector<MDItem> ddPaths = item.getDrillDownPaths();
        if (ddPaths != null)
            for (MDItem ddItem : ddPaths)
            {
                if (ddItem != null)
                {
                    ret.addElement(ddItem.getUniqueID());
                    // Recursively check...
                    _getDrillPathsRecursive(ddItem, ret);
                }
            }
        return ret;
    }
    
    private String _getDrillNode(DimTree layout, int itemEdge, ItemDrill itemDrill) throws MetadataManagerException
    {
        Vector<String> drillPaths = _getDrillPaths(itemDrill);
        
        for (String path : drillPaths)
        {
            if (path != null)
            {
                // Check if it's in layout: if not, return it
                int layer = layout.getNode(itemEdge, new BaseNode(path));
                if (layer == -1)
                    return path;
            }
        }
        return null;
    }
    
  protected boolean applyItemDrill(ItemDrill itemDrill, BitSet flags) throws Exception {
    // Anchor item after which drill targets need to be placed
    QDR loc = null;
    if (itemDrill.getDrillCount() > 0)
        loc = itemDrill.getValue(0);
    
    DimTree layout = m_query._getQueryState().getDimTree();
    Node itemNode = new Node(itemDrill.getItem());
    // Find the target in the current layout
    int itemEdge = layout.getEdge(itemNode, loc);
    int itemLayer = layout.getNode(itemNode, loc);
    BaseNode[][] nodes = layout.getDimTree();
    String drillNodePath = _getDrillNode(layout, itemEdge, itemDrill);
    if (drillNodePath == null)
        return false;
    
    // Make sure we're storing the actual layer that was inserted
    itemDrill.setDrillPath(drillNodePath);
    BaseNode drillNode = new Node(drillNodePath);
    BaseNode[] newEdge = new BaseNode[nodes[itemEdge].length + 1];
    if (flags.get(DataDirector.DRILL_MEMBERS_ABOVE))
    {
        // Insert child layer outside target layer
        for (int i = 0; i <= itemLayer-1; i++)
            newEdge[i] = nodes[itemEdge][i];
        newEdge[itemLayer] = drillNode;
        for (int i = itemLayer; i < nodes[itemEdge].length; i++) {
            newEdge[i+1] = nodes[itemEdge][i];
        }
        nodes[itemEdge] = newEdge;
    }
    else if (flags.get(DataDirector.DRILL_MEMBERS_BELOW)) {
        // Insert child layer inside target layer
        for (int i = 0; i <= itemLayer; i++)
        {
            newEdge[i] = nodes[itemEdge][i];
        }
        newEdge[itemLayer + 1] = drillNode;
        for (int i = itemLayer + 1; i < nodes[itemEdge].length; i++) {
          newEdge[i + 1] = nodes[itemEdge][i];
        }
        nodes[itemEdge] = newEdge;
    }
    else {
        // Must be a pure replace
        nodes[itemEdge][itemLayer] = drillNode;
    }
    m_query._getQueryState().setDimTree(new DimTree(nodes, null));
    evaluate(false);
    return true;
  }

  public void drill(String dimension, String[] target, String[] hierarchy, Integer[] delta, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException {
    // Create a drill step
    // blm - Selection code moved to dvt-olap
/*    Selection sel = m_query.findSelection(dimension);
    if (sel == null)
    {
        sel = new Selection(dimension);
        sel.setHierarchy(hierarchy != null && hierarchy.length > 0 ? hierarchy[0] : null);
        m_query._getQueryState().getSelections().add(sel);
    }
    sel = drill(dimension, target, hierarchy, delta, valueParent, queryAncestor, levelDepth, parentQDR);
    m_query._getQueryState().getSelections().remove(sel);
    m_query._getQueryState().getSelections().add(sel);
    boolean aboveArg = false;
    if (above != null && above.length > 0 && above[0] != null)
        aboveArg = above[0].booleanValue();
    m_drillSupport.evaluate(aboveArg);*/
  }

}
