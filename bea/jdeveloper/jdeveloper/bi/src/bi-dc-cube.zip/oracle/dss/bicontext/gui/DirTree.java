/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;

import javax.accessibility.AccessibleContext;

import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.event.TreeExpansionListener;

import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.FocusUtility;

/**
 * The base class for <code>BIContextTree</code>.  Application developers
 * should not use this class.
 * 
 * @status New
 */
public class DirTree extends JTree
{
    private boolean m_blnFromMouseEvent = false;

    /**
     * @hidden
     */
    public DirTree()
    {
        super();
        setRootVisible(true);
        setEditable(false);
        setCellRenderer(new DirTreeCellRenderer());
    }

    /**
     * @hidden
     */
    public DirTree(TreeModel model)
    {
        super(model);
        setRootVisible(true);
        setEditable(false);
        setCellRenderer(new DirTreeCellRenderer());
    }


    /**
     * @hidden
     */
    public void enableToolTip()
    {
        ToolTipManager.sharedInstance().registerComponent(this);
    }

    /**
     * @hidden
     */
    public void disableToolTip()
    {
        ToolTipManager.sharedInstance().unregisterComponent(this);
    }

    /**
     * Processes focus events occurring on this component by dispatching them to
     * any registered FocusListener objects.
     *
     * This method is not called unless focus events are enabled for this
     * component. Focus events are enabled when one of the following occurs:
     *
     *  - A FocusListener object is registered via addFocusListener.
     *  - Focus events are enabled via enableEvents.
     *
     * Override processFocusEvent() so that we can change focus to
     * first selected row in JTree.
     *
     * @param  focusEvent a <code>FocusEvent</code> to process.
     * @status New
     */
    protected void processFocusEvent(FocusEvent focusEvent)
    {
        // Perform normal focus processing
        super.processFocusEvent(focusEvent);
          
        // Override the default behavior such that a focus on the DirTree actually
        // sets the focus on the selected row.
        if ( (!m_blnFromMouseEvent) && (focusEvent.getID() == FocusEvent.FOCUS_GAINED) ) {
            FocusUtility.setFocusToFirstSelectedRow(this, focusEvent);
        }
    }
    
    /**
     * Processes mouse events occurring on this component by dispatching them to any registered
     * MouseListener objects. 
     *
     * This method is not called unless mouse events are enabled for this component. Mouse events
     * are enabled when one of the following occurs: 
     *
     *  - A MouseListener object is registered via addMouseListener. 
     *  - Mouse events are enabled via enableEvents. 
     *
     * Override processMouseEvent() so that focus events generated via a mouse event
     * aren't modified.
     *
     * @param  mouseEvent a <code>MouseEvent</code> to process.
     * @status New
     */
    protected void processMouseEvent(MouseEvent mouseEvent) {
        // Ensure that a FocusEvent orginating from a MouseEvent isn't modified.
        // For example, clicking on the JTabbedPane (unlike hitting the accelerator key)
        // will result in the focus staying on the JTabbedPane.
        m_blnFromMouseEvent = true;
        super.processMouseEvent(mouseEvent);
        m_blnFromMouseEvent = false;
    }
}