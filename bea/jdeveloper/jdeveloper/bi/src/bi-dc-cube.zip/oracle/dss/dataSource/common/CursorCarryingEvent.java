package oracle.dss.dataSource.common;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

import oracle.dss.util.DataAccess;

/**
 * @hidden
 * Mark event as containing an OLAPI cursor.
 */
public interface CursorCarryingEvent
{
    /**
     * Return a reference to the new cursor.
     *
     * @return new cursor reference
     */
    public DataAccess getDataAccess();
    
    /**
     * Set the cursor into the event.
     * Restricted to use by data source.
     *
     * @param da new cursor
     */
    public void setDataAccess(DataAccess da);
}
