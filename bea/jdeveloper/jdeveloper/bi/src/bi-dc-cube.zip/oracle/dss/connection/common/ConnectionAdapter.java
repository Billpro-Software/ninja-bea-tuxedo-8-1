/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.connection.common;

/**
 * Listener for changes to the status in a connection.
 * You can extend this class to implement your own
 * <code>ConnectionListener</code>.
 *
 * @status Reviewed
 */
public class ConnectionAdapter implements ConnectionListener {

 /**
  * Constructor.
  * @status Reviewed
  */
  public ConnectionAdapter() {
  }

  /**
   * Responds to a request to connect.
   * This implementation does nothing.
   *
   * @param evt    Information about the connection request.
   *
   * @status Reviewed
   */
  public void connecting( ConnectionEvent evt ) {
  }

  /**
   * Responds to a connection.
   * This implementation does nothing.
   *
   * @param evt   Information about the connection.
   *
   * @status Reviewed
   */
  public void connected( ConnectionEvent evt ) {
  }

  /**
   * Responds to a request to disconnect.
   * This implementation does nothing.
   *
   * @param evt    Information about the request to disconnect.
   *
   * @status Reviewed
   */
  public void disconnecting( ConnectionEvent evt ) {
  }

  /**
   * Responds to a disconnection.
   * This implementation does nothing.
   *
   * @param evt   Information about the disconnection.
   *
   * @status Reviewed
   */
  public void disconnected( ConnectionEvent evt ) {
  }
}