/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;

import javax.swing.Icon;

/**
 * @hidden
 * The base interface for DirListNode and DirTreeNode
 */
public interface Node
{
    /**
     * Retrieves the name for this node.
     *
     * @return a string representing the name of the node.
     * @status New
     */
    public String getName();

    /**
     * Specifies the name for this node.
     *
     * @param a string representing the name of the node.
     * @status New
     */
    public void setName(String name);

    /**
     * Specifies an icon for this object, displayed in tree, left of name.
     * The recommended size for this icon is 16x16 pixels.
     *
     * @return an icon representing the object's icon
     * @status New
     */
    public Icon getIcon();

    /**
     * Retrieves the BIContext associated with this node if this node
     * is a folder, otherwise, return null
     *
     * @status New
     */
    public DirContext getDirContext();

    /**
     * TODO
     * @return 
     */
    public DirContext getParentDirContext();

    /**
     * Set the node disable for rendering
     *
     * @param disable <code>true</code> if node is disable
     *              <code>false</code> otherwise
     * @status New
     */
    public void setDisable(boolean disable);

    /**
     * Checks whether this node is disabled
     *
     * @return <code>true</code> if node is disable
     *              <code>false</code> otherwise
     * @status New
     */
    public boolean isDisable();

    /**
     * Retrieves the BISearchResult associated with this node
     *
     * @status New
     */
    public SearchResult getSearchResult();

    public String getFullPathName();
    
    public void setFullPathName(String fullPath);
}