/*
 * MDObjectDirTreeCellRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import java.awt.Component;

import javax.naming.directory.SearchResult;

import javax.swing.JTree;

import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.gui.DefaultDirTreeNode;
import oracle.dss.bicontext.gui.DirTreeCellRenderer;

import oracle.dss.datautil.gui.Utils;

import oracle.dss.metadataManager.common.MDObject;

 /**
  * @hidden
  * Specialized DirTreeCellRenderer for rendering MDObjects based upon
  * the given display member label type.
  * @status new
  */
public class MDObjectDirTreeCellRenderer extends DirTreeCellRenderer {
    // Holds the current display member label type.
    private String m_strDisplayMemberLabelType;
    
    /** 
     * Constructor that takes the desired display label type.
     * @param strDisplayMemberLabelType  A constant that identifies the type of label
     *                                   that you want.
     *                                   Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     *
     * @status new
     */
    public MDObjectDirTreeCellRenderer(String strDisplayMemberLabelType) {
        super();
        // Set the current display member label type.
        setDisplayLabelType(strDisplayMemberLabelType);
    }  
    
    /**
     * Default constructor
     * @status hidden
     */
    public MDObjectDirTreeCellRenderer() {
        this(null);            
    }
    
    /**
     * @hidden
     * Specifies the desired display member label type.
     * @param strDisplayMemberLabelType  A constant that identifies the type of label
     *                                   that you want.
     *                                   Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * 
     * @status new
     */
    public void setDisplayLabelType(String strDisplayMemberLabelType) {
        m_strDisplayMemberLabelType = strDisplayMemberLabelType;
    }
    
    /**
     * @hidden
     * Overrides the default implementation of this method from the superclass such that the text
     * is set based upon the appropriate display label type for the MDObject.
     *
     * @status hidden
     */
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        Component renderer = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        setText(Utils.toString(value, m_strDisplayMemberLabelType));
        return renderer;
    }
}