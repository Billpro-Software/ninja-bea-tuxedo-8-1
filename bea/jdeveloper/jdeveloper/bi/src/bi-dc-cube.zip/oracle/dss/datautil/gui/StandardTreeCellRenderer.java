/*
 * StandardTreeCellRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Component;

import javax.swing.JTree;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.UIManager;

import javax.swing.tree.DefaultTreeCellRenderer;

/**
 * @hidden
 * StandardTreeCellRenderer class is used to render the tree
 * so that the leaf icon is set to null and so the openIcon and
 * closedIcon are set to the Discoverer icons if they are null
 * (as they are for the OLAF).
 */
public class StandardTreeCellRenderer extends DefaultTreeCellRenderer
{
    //-----------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-----------------------------------------------------------------------
    
    // The images to be displayed in the tree
    private ImageIcon m_iconOpen    = null;
    private ImageIcon m_iconClosed  = null;
    private ImageIcon m_iconLeaf    = null;
    
    // The names of the images to be displayed in the tree
    private String      m_strIconOpen       = null;
    private String      m_strIconClosed     = null;
    private String      m_strIconLeaf       = null;
    
    private boolean     m_bInited           = false;
    
    private Component   m_parentComp        = null;  
    
    //-----------------------------------------------------------------------
    // PUBLIC METHODS
    //-----------------------------------------------------------------------

    public StandardTreeCellRenderer ( )
    {
        super ( );
        
        m_strIconOpen = new String ( "images/folder-o.gif" );
        m_strIconClosed = new String ( "images/folder-c.gif" );
        m_strIconLeaf = new String ( "" );
    }

    public StandardTreeCellRenderer ( Component parentComp, String strIconOpen, 
                                      String strIconClosed, String strIconLeaf )
    {
        super ( );
        
        m_parentComp = parentComp;
        
        if ( strIconOpen != null )
            m_strIconOpen = new String ( strIconOpen );
        if ( strIconClosed != null )            
            m_strIconClosed = new String ( strIconClosed );
        if ( strIconLeaf != null )            
            m_strIconLeaf = new String ( strIconLeaf );
    }
    
    // Overriding the getTreeCellRendererComponent call to set the right icons
    public Component getTreeCellRendererComponent ( JTree tree, Object value,
                                                    boolean isSelected, boolean isExpanded, 
                                                    boolean isLeaf, int row, boolean hasFocus )
    {
        Component   renderer    = null;
        
        if ( ! m_bInited )         
        {
            m_bInited = initContents ( );
        }
        
        if ( m_iconOpen != null )
    	{
    		setOpenIcon(m_iconOpen);
    	}
	    
        if ( m_iconClosed != null )
    	{
    		setClosedIcon ( m_iconClosed ); 
    	}

        if ( m_iconClosed != null )
    	{
    		setLeafIcon ( m_iconLeaf ); 
    	}
        
        renderer = super.getTreeCellRendererComponent ( tree, value,
                                                        isSelected, isExpanded, 
                                                        isLeaf, row, hasFocus );
        return renderer;
    }
    
    //-----------------------------------------------------------------------
    // NON PUBLIC METHODS
    //-----------------------------------------------------------------------

    private boolean initContents ( )
	{
	    Component   targetObject    = null;
	    
	    if ( m_bInited )
	        return true;

	    targetObject = this;
	    if ( m_parentComp != null )
	        targetObject = m_parentComp;
	    
	    try
	    {
	        if ( m_strIconOpen.length ( ) > 0 &&
	             null == ( Icon ) UIManager.get ( "Tree.openIcon" ) )
	    	{
	    		m_iconOpen = new ImageIcon ( Utils.getImageResource ( targetObject, m_strIconOpen ) );
	    	}
	    }
	   	catch ( Exception exception )
	    {
	    	exception.printStackTrace ( );
	    	return false;
	    }
	    
	    try
	    {
	        if ( m_strIconClosed.length ( ) > 0 && 
	             null == ( Icon ) UIManager.get ( "Tree.closedIcon" ) )
	    	{
	    		m_iconClosed = new ImageIcon ( Utils.getImageResource ( targetObject, m_strIconClosed ) );
	    	}
	    }
	   	catch ( Exception exception )
	    {
	    	exception.printStackTrace ( );
	    	return false;
	    }
	    
	    try
	    {
	        if ( m_strIconLeaf.length ( ) > 0 &&
	             null == ( Icon ) UIManager.get ( "Tree.leafIcon" ) )
	    	{
	    		m_iconLeaf = new ImageIcon ( Utils.getImageResource ( targetObject, m_strIconLeaf ) );
	    	}
	    }
	   	catch ( Exception exception )
	    {
	    	exception.printStackTrace ( );
	    	return false;
	    }
	    return true;
	}
}