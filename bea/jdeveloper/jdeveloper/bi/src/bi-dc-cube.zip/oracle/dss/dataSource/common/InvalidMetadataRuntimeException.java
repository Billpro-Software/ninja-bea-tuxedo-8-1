/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Superclass for exceptions that are thrown because of errors that occur while
 * retrieving metadata from the database.
 *
 * @status Documented
 */
public class InvalidMetadataRuntimeException extends QueryRuntimeException
{
    /**
     * @hidden
     * @serial Invalid object names
     */
    protected String[] m_objects = null;
    
    /**    
     * Constructor for a single error while getting metadata.
     *
     * @param s      Message to display.
     * @param object Name of invalid object.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMetadataRuntimeException(String s, String object, Throwable e)
    {
        super(s, e);
        m_objects = new String[] {object};
    }
    
    /**    
     * Constructor for multiple errors while getting metadata.
     *
     * @param s      Message to display.
     * @param object Names of invalid objects.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMetadataRuntimeException(String s, String[] object, Throwable e)
    {
        super(s, e);
        m_objects = object;
    }    
    
    /**
     * Retrieves the objects.
     *
     * @return  The list of objects.
     *
     * @status Documented
     */
    public String[] getObjects()
    {
        return m_objects;
    }
    
    /**
     * Indicates whether there are multiple invalid objects or a single invalid
     * object.
     *
     * @return <code>true</code> if one object; <code>false</code> if more than
     *         one invalid object.
     *
     * @status Documented
     */
    public boolean isMultipleObjects()
    {
        return m_objects != null && m_objects.length > 1;
    }        
}