/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;

/**
 * @hidden
 * Holds information concerning an OLAPI source ID, dimension, and step number
 */
public class SourceStepMap extends Object implements java.io.Serializable, Cloneable
{
    protected Hashtable m_dims = new Hashtable();
    
    public SourceStepMap()
    {
        super();
    }
    
    public void addDimStep(String dimension, int stepCount, String ID, boolean drillable)
    {
        // See if there is already a dimension table here
        Vector stepTable = getStepTable(dimension);
        if (stepTable == null)
        {
            // Define a new one
            stepTable = new Vector();
            m_dims.put(dimension, stepTable);
        }
        
        // Insert the given ID in the vector at the appropriate place
        int size = stepTable.size();
        StepData data = new StepData(ID, drillable);
        if (stepCount >= size)
        {
            stepTable.addElement(data);
        }
        else
        {
            stepTable.insertElementAt(data, stepCount);
        }
    }
    
    public void removeDimension(String dimension)
    {
        m_dims.remove(dimension);
    }
    
    protected StepData getStepData(String dimension, int stepCount)
    {
        Vector stepTable = getStepTable(dimension);
        if (stepTable == null || stepCount >= stepTable.size() || stepCount < 0)
        {
            return null;
        }
        return (StepData)stepTable.elementAt(stepCount);
    }
    
    public boolean isOneStep(String dimension)
    {
        Vector table = getStepTable(dimension);
        if (table == null)
        {
            return true;
        }
        return (table.size() <= 1);
    }
    
    public String getStepID(String dimension, int stepCount)
    {
        StepData data = getStepData(dimension, stepCount);
        if (data == null)
        {
            return null;
        }
        return data.getKey();
    }
    
    public int getGroupNumber(String dimension, String key)
    {
        Vector table = getStepTable(dimension);
        if (table != null)
        {
            // Search for this key
            boolean found = false;
            Enumeration steps = table.elements();
            StepData data = null;
            int count = 0;
            while (!found && steps.hasMoreElements())
            {
                data = (StepData)steps.nextElement();
                if (data != null)
                {
                    if (data.getKey().equals(key))
                    {
                        return count;
                    }
                }
                count++;
            }
        }
        return -1;
    }
    
    
    public boolean isDrillable(String dimension, String key)
    {
        Vector table = getStepTable(dimension);
        if (table != null)
        {
            // Search for this key
            boolean found = false;
            Enumeration steps = table.elements();
            StepData data = null;
            while (!found && steps.hasMoreElements())
            {
                data = (StepData)steps.nextElement();
                if (data != null)
                {
                    if (data.getKey().equals(key))
                    {
                        // Found it
                        found = true;
                    }
                }
            }
            if (found && data != null)
            {
                return data.isDrillable();
            }
        }
        return false;
    }
    
    public Vector getStepTable(String dimension)
    {
        return (Vector)m_dims.get(dimension);
    }
    
    public Object clone() throws CloneNotSupportedException
    {
        SourceStepMap newmap = new SourceStepMap();
        
        Enumeration dims = m_dims.keys();
        Vector stepTable = null;
        Enumeration steps = null;
        String dim = null;
        int stepCount = 0;
        StepData data = null;
        while (dims.hasMoreElements())
        {
            dim = (String)dims.nextElement();
            stepTable = (Vector)m_dims.get(dim);
            steps = stepTable.elements();
            stepCount = 0;            
            while (steps.hasMoreElements())
            {
                data = (StepData)steps.nextElement();
                newmap.addDimStep(dim, stepCount++, data.getKey(), data.isDrillable());
            }
        }
        return newmap;
    }
    
    private class StepData extends Object implements java.io.Serializable, Cloneable
    {
        private boolean m_drillable = false;
        private String m_key = null;
        
        public StepData(String key, boolean drillable)
        {
            m_key = key;
            m_drillable = drillable;
        }        
        
        public String getKey()
        {
            return m_key;
        }
        
        public boolean isDrillable()
        {
            return m_drillable;
        }
    }
}