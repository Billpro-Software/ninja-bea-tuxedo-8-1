/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if an operation is attempted that requires the
 * <code>QueryManager</code> property of the <code>Query</code> to be set but no
 * <code>QueryManager</code> is specified.
 *
 * @status Documented
 */
public class NoQueryManagerException extends QueryRuntimeException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public NoQueryManagerException(String s, Throwable e)
    {
        super(s, e);
    }
}