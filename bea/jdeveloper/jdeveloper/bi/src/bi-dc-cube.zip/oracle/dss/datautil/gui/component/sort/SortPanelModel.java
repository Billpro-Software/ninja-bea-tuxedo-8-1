/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    08/26/05 - 
    jramanat    08/25/05 - jramanat_sort_dialog
    jramanat    08/19/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil.gui.component.sort;

import java.util.Vector;

import oracle.dss.util.ColumnSortInfo;

public interface SortPanelModel {
  /**
   * Constant representing Crosstab mode
   */
  public static final String CROSSTAB_MODE = "CrosstabMode";

  /**
   * Constant representing Table mode
   */
  public static final String TABLE_MODE = "TableMode";

  /**
   * Indicates whether sorting should be done in Crosstab or Table mode
   * 
   * @return <code>CROSSTAB_MODE</code> for Crosstab, <code>TABLE_MODE</code>
   * for Table
   */
  public String getMode();  
}