/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/PollingRequiredEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     12/13/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/PollingRequiredEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.datautil;

/**
 * Event fired when a QueryEditor is asynchronous and the user must invoke the asynch
 * API (getStatus(), startExecution()) to complete the operation they've called.
 */
public class PollingRequiredEvent extends QueryEditorEvent
{
    /**
     * Constructor
     */
    public PollingRequiredEvent(QueryEditor qe)
    {
        super(qe);        
    }
}
