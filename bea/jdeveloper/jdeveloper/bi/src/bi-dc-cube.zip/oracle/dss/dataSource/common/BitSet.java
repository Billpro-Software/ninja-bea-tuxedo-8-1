/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.dataSource.common;

/**
 * @hidden
 * Track fixed size set of bits
 */
public class BitSet extends Object
{
    protected boolean[] m_array = null;
    protected int m_setCount = 0;
    protected int m_size = 0;
    
    public BitSet(int size)
    {
        super();
        m_size = size;
        clear();
    }
    
    public void clear()
    {
        m_array = new boolean[m_size];
    }
    
    public int cardinality()
    {
        return m_setCount;
    }
    
    public void set(int index)
    {
        if (!m_array[index])
        {
            m_setCount++;
            m_array[index] = true;
        }
    }
    
    public int nextClearBit(int start)
    {
        for (int i = start; i < m_array.length; i++)
            if (!m_array[i])
                return i;
                
        return -1;
    }
    
    public int nextSetBit(int start)
    {
        for (int i = start; i < m_array.length; i++)
            if (m_array[i])
                return i;
                
        return -1;
    }
}
