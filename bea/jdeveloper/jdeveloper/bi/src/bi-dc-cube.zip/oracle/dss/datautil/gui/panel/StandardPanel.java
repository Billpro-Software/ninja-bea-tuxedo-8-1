/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import java.awt.Image;
import java.awt.Component;

import javax.swing.ImageIcon;

import oracle.dss.datautil.client.DataUtilException;
import oracle.dss.datautil.gui.BuilderContext;
import oracle.dss.datautil.gui.panel.event.PanelEventListener;

import oracle.dss.util.help.HelpContext;

/**
 * Defines the methods to be implemented by a page
 * that must be embedded in a container.
 *
 * @status Documented
 */
public interface StandardPanel extends HelpContext
    {
    /**
     * Adds a listener for panel events.
     *
     * @param listener The listener for the panel events.
     *
     * @status Documented
     */
    public void addPanelEventListener ( PanelEventListener listener );

    /**
     * Cleans up any resources that were allocated by this panel.
     *
     * @status Documented
     */
    public void cleanup ( );

    /**
     * Retrieves the <code>BuilderContext</code> object that is associated with 
     * this panel.
     *
     * @return The <code>BuilderContext</code> object.
     *
     * @status Documented
     */
    public BuilderContext getBuilderContext ( );

    /**
     * Retrieves the component that is associated with this panel.
     *
     * @return The component for this panel.
     *
     * @status Documented
     */
    public Component getComponent ( );

    /**
     * Retrieves the container that is associated with this panel.
     *
     * @return The container that is associated with this panel.
     *
     * @status Documented
     */
    public Component getContainer ( );
    
    /**
     * Retrieves the identifier for this panel.
     *
     * @return The identifier for this panel.
     *
     * @status Documented
     */
    public String getId ( );
      
    /**
     * Retrieves the image for the panel. Typically this image is displayed
     * on the left side of a wizard.
     *
     * @return The image to be displayed for this panel.
     *
     * @status Documented
     */
    public Image getImage ( );

    /**
     * Retrieves the image icon for this panel.
     *
     * @return The icon that is to be displayed for this
     *         panel.
     *
     * @status Documented
     */
    public ImageIcon getImageIcon ( );

    /**
     * Retrieves the content of this panel.
     *
     * @return The panel content.
     *
     * @status Documented
     */
    public Object getPanelContent ( );

    /**
     * Retrieves the title of this panel.
     *
     * @return The panel title.
     *
     * @status Documented
     */
    public String getTitle ( );
    
    /**
     * Removes a listener for the panel events.
     *
     * @param listener The listener for the panel events.
     *
     * @status Documented
     */
    public void removePanelEventListener ( PanelEventListener listener );
    
    /**
     * Specifies whether the panel is to be active or inactive.
     *
     * @param bIsActive <code>true</code> if the panel
     *                  is to be active; <code>false</code> if the panel
     *                  is to be inactive.
     *
     * @return <code>true</code> if the operation was successful,
     *         <code>false</code> if the operation was not successful.
     *
     * @throws <code>DataUtilException</code> if the operation is unsuccessful.
     *
     * @status Documented
     */
    public boolean setActive ( boolean bIsActive ) throws DataUtilException;
    
    /**
     * Specifies the <code>BuilderContext</code> instance for this panel.
     *
     * @param The <code>BuilderContext</code> instance.
     *
     * @status documented
     */
    public void setBuilderContext ( BuilderContext builderContext );

    /**
     * Specifies the container that is associated with this panel.
     *
     * @param container The container.
     *
     * @status Documented
     */
    public void setContainer ( Component container );
    
    /**
     * Specifies the content for this panel.
     *
     * @param panelContent The panel content.
     *
     * @status Documented
     */
    public void setPanelContent ( Object panelContent );

    /**
     * Validates the contents of the panel.
     *
     * @param hintValidate A hint object to help in the validation process.
     *
     * @return <code>true</code> if the operation was successful,
     *         <code>false</code> if the operation was not successful.
     *
     * @status Documented
     */
    public boolean validateContents ( Object hintValidate );
    }