/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Interface indicating consumability of an event.
 * @status New
 */
public interface Consumable
{
    /**
     * Consume this event.
     * @status New
     */
    public void consume();
    
    /**
     * Has this event been consumed?
     *
     * @return <code>true</code> if consumed
     * @status New
     */
    public boolean isConsumed();
}

