/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class MDLookupCache
{
    private int m_cacheSize;
    private int m_currSize;
    private Hashtable m_cache;
    private Vector m_fifo;          // first-in-first-out
    
    public MDLookupCache(int size)
    {
        m_cacheSize = size;
        m_currSize = 0;
        size = (size < 2)? 2 : size*2;         // object is cached by UID and path
        m_fifo  = new Vector(size);
        m_cache = new Hashtable(size);
    }
    
    public void put(String uid, String path, Object object)
    {
        if(uid != null && path != null && object != null)
        {
            if(m_cache.containsKey(uid))        // already in cache
                removeByUniqueID(uid);
            else if(m_currSize >= m_cacheSize)  // cache is full, remove the oldest
                removeByUniqueID((String)m_fifo.elementAt(0));

            m_fifo.addElement(uid);
            m_fifo.addElement(path);
            
            m_cache.put(uid, object);
            m_cache.put(path, object);
            
            m_currSize++;                       // new entry
        }
    }
    
    public Object get(String uidOrPath)
    {
        return (uidOrPath != null)? m_cache.get(uidOrPath) : null;
    }
    
    /**
     * Expensive method.  Use with caution!
     * @return 
     */
    public Enumeration elements()
    {
        Vector _vec = new Vector(m_fifo.size()/2);  // m_fifo contains a object
                                                    // twice; by uid and path.
        for(int i=0; i<m_fifo.size()-1; i+=2)
        {
            String _uid = (String)m_fifo.elementAt(i);
            _vec.addElement(m_cache.get(_uid));
        }
        return _vec.elements();
    }
    
    public int size()
    {
        return m_currSize;
    }
    
    public void removeByUniqueID(String uid)
    {
        if(uid != null && m_cache.containsKey(uid))
        {
            int _index = m_fifo.indexOf(uid);
            String _path = null;
            if(_index != -1 && _index < (m_fifo.size()-1))
            {
                _path = (String)m_fifo.elementAt(_index + 1);
                m_fifo.remove(_index);    // remove the uid, vector slides up and next inline is path
                m_fifo.remove(_index);    // remove the path
            }
            
            if(_path != null)
                m_cache.remove(_path);
            
            m_cache.remove(uid);
            m_currSize--;  // decrement currSize
        }
    }

    public void removeByPath(String path)
    {
        if(path != null && m_cache.containsKey(path))
        {
            int _index = m_fifo.indexOf(path);
            String _uid = null;
            if(_index != -1 && _index < (m_fifo.size()))
            {
                _uid = (String)m_fifo.elementAt(_index - 1);
                m_fifo.remove(_index);    // remove the path
                m_fifo.remove(_index-1);  // remove the uid, vector slides up and next inline is path
            }

            if(_uid != null)
                m_cache.remove(_uid);

            m_cache.remove(path);
            m_currSize--;  // decrement currSize
        }
    }
    
    public boolean contains(String uidOrPath)
    {
        return m_cache.containsKey(uidOrPath);
    }
    
    public void clear()
    {
        m_fifo.clear();
        m_cache.clear();
        m_currSize = 0;
    }
}