/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

/**
 * Base class to distinguish layout sequence events.
 *
 * @status Documented
 */
public abstract class LayoutEvent extends QueryEvent
{
    /**
     * Constructor to use if the affected dimension names are available from
     * the original call that changed the layout.
     * Specifically, the constructor to use when the <code>layout</code> method
     * of the <code>Query</code> class is called.
     *
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param edges       A list of the dirty edges, if known. In this list,
     *                    to refer to edges, use the constants
     *                    <code>DataDirector.COLUMN_EDGE</code>,
     *                    <code>DataDirector.PAGE_EDGE</code>, or
     *                    <code>DataDirector.ROW_EDGE</code>.
     * @param dimensions  The names of the dimensions that were affected
     *                    by the call that changed the layout. This is the same
     *                    parameter that is used in the <code>layout</code>
     *                    method call in the <code>Query</code> class.
     *
     * @see  oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see  oracle.dss.util.DataDirector#PAGE_EDGE
     * @see  oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public LayoutEvent(Object source, BitSet edges, String[][] dimensions) {
        super(source);
        
        dims = dimensions;
        edgesChanged = edges;
    }    

    /**
     * Constructor to use to specify the kind of pivot.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param edges        A list of the dirty edges, if known. In this list,
     *                     to refer to edges, use the constants
     *                     <code>DataDirector.COLUMN_EDGE</code>,
     *                     <code>DataDirector.PAGE_EDGE</code>, or
     *                     <code>DataDirector.ROW_EDGE</code>.
     * @param sourcedim   The name of the source dimension for a pivot or swap.
     * @param targetdim   The name of the target dimension for a pivot or swap.
     * @param dimensions  The names of the dimensions that were affected
     *                    by the call that changed the layout. This is the same
     *                    parameter that is used in the <code>layout</code>
     *                    method call in the <code>Query</code> class.
     * @param flags       A constant that indicates the type of pivot. Use
     *                    either <code>PivotConstants.PIVOT_AFTER</code> or
     *                    <code>PivotConstants.PIVOT_BEFORE</code>.
     *
     * @see PivotConstants#PIVOT_AFTER
     * @see PivotConstants#PIVOT_BEFORE
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutEvent(Object source, BitSet edges, String sourcedim, String targetdim, String[][] dimensions, int flags) {
        this(source, edges, null);
        
        sd = sourcedim;
        td = targetdim;
        fl = flags;
        dims = dimensions;
    }    

    /**
     * Constructor to use for a swap or pivot of specific dimensions.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param edges        A list of the dirty edges, if known. In this list,
     *                     to refer to edges, use the constants
     *                     <code>DataDirector.COLUMN_EDGE</code>,
     *                     <code>DataDirector.PAGE_EDGE</code>, or
     *                     <code>DataDirector.ROW_EDGE</code>.
     * @param sourcedim   The name of the source dimension for a pivot or swap.
     * @param targetdim   The name of the target dimension for a pivot or swap.
     * @param dimensions  The names of the dimensions that were affected
     *                    by the call that changed the layout. This is the same
     *                    parameter that is used in the <code>layout</code>
     *                    method call in the <code>Query</code> class.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutEvent(Object source, BitSet edges, String sourcedim, String targetdim, String[][] dimensions) {
        this(source, edges, sourcedim, targetdim, dimensions, -1);
    }    

    /**
     * Constructor to use for an edge swap.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param sourceedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the source edge for an edge swap.
     * @param targetedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the target edge for an edge swap.
     * @param dimensions The names of the dimensions that were affected
     *                   by the call that changed the layout. This is the same
     *                   parameter that is used in the <code>layout</code>
     *                   method call in the <code>Query</code> class.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public LayoutEvent(Object source, int sourceedge, int targetedge, String[][] dimensions) {
        this(source, null, dimensions);
        BitSet edges = new BitSet(3);
        edges.set(sourceedge);
        edges.set(targetedge);
        edgesChanged = edges;
    }
    
    /**
     * Retrieves the layout of this event.
     *
     * @return The dimension layout.
     *
     * @status Documented
     */
    public String[][] getDimensions() {
        return dims;
    }
    
    /**
     * Determines whether an edge is dirty.
     *
     * @param edge   A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *               <code>DataDirector.PAGE_EDGE</code>, or
     *               <code>DataDirector.ROW_EDGE</code>) that represents
     *               the edge to check.
     *
     * @return <code>true</code> if the edge is dirty, false if not.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public boolean isEdgeDirty(int edge) {
        return (edgesChanged == null) ? false : edgesChanged.get(edge);
    }
    
    /**
     * Retrieves the name of the source dimension, if any.
     *
     * @return The name of the source dimension for a pivot or swap,
     *         or <code>null</code> if a direct layout.
     *
     * @status Documented
     */
    public String getSourceDimension() {
        return sd;
    }
    
    /**
     * Retrieves the name of the target dimension, if any.
     *
     * @return The name of the target dimension for a pivot or swap,
     *         or <code>null</code> if a direct layout.
     *
     * @status Documented
     */
    public String getTargetDimension() {
        return td;
    }

    /**
     * Retrieves flags that indicate the kind of layout change.
     *
     * @return A constant (<code>PivotConstants.PIVOT_AFTER</code> or
     *         <code>PivotConstants.PIVOT_BEFORE</code>) that represents the
     *         kind of pivot; -1 if not a pivot.
     *
     * @see PivotConstants#PIVOT_AFTER
     * @see PivotConstants#PIVOT_BEFORE
     *
     * @status Documented
     */
    public int getFlags() {
        return fl;
    }
    

    /**
     * @hidden
     * @serial layout of dimensions
     */
    protected String[][]    dims;

    /**
     * @hidden
     * @serial which edges may have changed
     */
    protected BitSet        edgesChanged;

    /**
     * @hidden
     * @serial special flags
     */
    protected int           fl = -1;

    /**
     * @hidden
     * @serial source dimension
     */
    protected String        sd;

    /**
     * @hidden
     * @serial target dimension
     */
    protected String        td;
}
