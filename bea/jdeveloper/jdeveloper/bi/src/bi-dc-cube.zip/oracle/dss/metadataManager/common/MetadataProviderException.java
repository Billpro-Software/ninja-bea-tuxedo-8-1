/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Locale;
import oracle.dss.util.BIBaseException;
//import oracle.dss.appmodule.common.BIJboCheckedException;

/**
 * @hidden
 */
public class MetadataProviderException extends BIBaseException //BIJboCheckedException
{
    private String m_driverType;

   /**
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    *
    * @status documented
    */
    public MetadataProviderException(Class resBundleClass, String errorCode, Object[] params, String driverType)
    {
        super(errorCode, null);
        m_driverType = driverType;
    }

   /**
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    *
    * @status documented
    */
    public MetadataProviderException(Class resBundleClass, String errorCode, Object[] params, String driverType, Throwable prevException)
    {
        super(errorCode, prevException);
        m_driverType = driverType;
    }

    /**
     * Constructor for an exception that cannot be localized and that passes
     * on an underlying exception.
     *
     * @param msg  The text of the error message.
     * @param prevException The exception that underlies this exception.
     *
     * @status documented
     */
    public MetadataProviderException(String msg, String driverType, Throwable prevException)
    {
        super(msg, prevException);
        m_driverType = driverType;
    }

    /**
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    *
    * @status documented
    */
    public MetadataProviderException(Class resBundleClass, String errorCode, Object[] params, Locale locale, Throwable prevException, String driverType)
    {
        super(errorCode, prevException);
        m_driverType = driverType;
    }

   /**
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    *
    * @status documented
    */
    public MetadataProviderException(Class resBundleClass, String errorCode, Object[] params, Throwable prevException, String driverType)
    {
        super(errorCode, prevException);
        m_driverType = driverType;
    }
}
