/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

// Imports
import java.util.Properties;
import java.io.Serializable;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.connection.common.CB;

/**
 * @hidden
 */
public class ConnectionObj extends PropertyBag implements Serializable {

 	public ConnectionObj() {
 		super();
 	}
	
	public boolean isConnected(){
		if ( getConnectionStatus() == CB.CONNECTED )
			return true;
		return false;
  }

  public boolean isConnectionFailed(){
    if ( getConnectionStatus() == CB.CONNECTION_FAILED )
      return true;
    return false;
  }
	public String[] getORBArgs(){
		return (String[]) getObjPropertyValue( CB.ORB_ARGS );
	}

	public void setORBArgs( String[] args ){
    if ( args != null )
		  setObjPropertyValue( CB.ORB_ARGS, (Object) args, CB.UI_NONE );
	}

	public Properties getORBProperties(){
		return (Properties) getObjPropertyValue( CB.ORB_PROPS );
	}

	public void setORBProperties( Properties props){
    if ( props != null )
		  setObjPropertyValue( CB.ORB_PROPS, (Object) props, CB.UI_NONE );
	}

	public boolean isORBInit(){
		if ( getIntPropertyValue ( CB.ORB_INI_STATUS ) == CB.TRUE )
			return true;
		return false;
	}

	public void setOrbInitStatus( boolean status){
		if ( status )
			setIntPropertyValue( CB.ORB_INI_STATUS, CB.TRUE, CB.UI_NONE );
		else
			setIntPropertyValue( CB.ORB_INI_STATUS, CB.FALSE, CB.UI_NONE );
	}

  public String getName() {
		return getStrPropertyValue( CB.OBJECT_NAME );
  }
  
  public void setName(String name) {
		setStrPropertyValue( CB.OBJECT_NAME, name, CB.UI_VISIBLE | CB.UI_WRITE );
  }

  public String getServerType() {
		return getStrPropertyValue( CB.SERVER_TYPE );
  }

  public void setServerType( String serverType ) {
		setStrPropertyValue( CB.SERVER_TYPE, serverType, CB.UI_VISIBLE | CB.UI_WRITE );
  }

  public String getDriverType() {
		return getStrPropertyValue( CB.DRIVER_TYPE );
  }

  public void setDriverType( String driverType) {
		setStrPropertyValue( CB.DRIVER_TYPE, driverType, CB.UI_VISIBLE | CB.UI_WRITE );
  }

  public int getConnectionStatus() {
		return getIntPropertyValue( CB.CONNECTION_STATUS );
  }

  public void setConnectionStatus( int status ) {
		setIntPropertyValue( CB.CONNECTION_STATUS, status, CB.UI_VISIBLE  );
  }

  public String getConnectionString() {
		return getStrPropertyValue( CB.CONNECTION_STRING );
  }
  
  public void setConnectionString(String connectionString) {
		setStrPropertyValue( CB.CONNECTION_STRING, connectionString, CB.UI_VISIBLE | CB.UI_WRITE );
  }

  public String getUsername() {
		return getStrPropertyValue( CB.USERNAME );
  }
  
  public void setUsername(String username) {
		setStrPropertyValue( CB.USERNAME, username, CB.UI_VISIBLE | CB.UI_WRITE );
  }
  
  public String getPassword() {
		return getStrPropertyValue( CB.PASSWORD );
  }
  
  public void setPassword(String service) {
		setStrPropertyValue( CB.PASSWORD, service, CB.UI_VISIBLE | CB.UI_WRITE | CB.UI_ENCRYPT );
  }

  public String getService() {
    //return getStrPropertyValue( CB.SERVICE );
    return null;
  }
  
  public void setService(String service) {
    //setStrPropertyValue( CB.SERVICE, service, CB.UI_VISIBLE | CB.UI_WRITE | CB.UI_ENCRYPT );
  }

  public String getSecurityCredentials() {
    //return getStrPropertyValue( CB.PASSWORD );
    return null;
  }
  
  public void setSecurityCredentials(String sc) {
    //setStrPropertyValue( CB.SECURITY_CREDENTIALS, sc, CB.UI_VISIBLE | CB.UI_WRITE | CB.UI_ENCRYPT );
  }
 	
  public String getSecurityPrincipal() {
    //return getStrPropertyValue( CB.SECURITY_PRINICIPAL );
    return null;
  }
  
  public void setSecurityPrincipal(String sp) {
    //setStrPropertyValue( CB.SECURITY_PRINICIPAL, sp, CB.UI_VISIBLE | CB.UI_WRITE | CB.UI_ENCRYPT );
  }
 
  public int free() {
		super.free();
		return CB.FAILURE;
  }

	/**************************************************
  * Static Methods
  ***************************************************/
}