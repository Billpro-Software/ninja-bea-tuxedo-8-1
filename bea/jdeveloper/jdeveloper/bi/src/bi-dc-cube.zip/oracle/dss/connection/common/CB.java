/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

// Imports
import oracle.dss.metadataUtil.MDU;
import oracle.dss.util.VersionInfo;

/**
 * Constants for Connection bean
 *
 * @status New
 */
public class CB extends MDU
{
    /**
     * The <code>Connection</code> is connected.
     *
     * @see oracle.dss.connection.client.Connection#connect
     * @see oracle.dss.connection.client.Connection#disconnect
     * @see oracle.dss.connection.client.Connection#getConnectionStatus
     *
     * @status Reviewed
     */
    public final static int CONNECTED = 1;

    /**
     * The <code>Connection</code> is not connected.
     *
     * @see oracle.dss.connection.client.Connection#connect
     * @see oracle.dss.connection.client.Connection#disconnect
     * @see oracle.dss.connection.client.Connection#getConnectionStatus
     *
     * @status Reviewed
     */
    public final static int NOT_CONNECTED = 2;
    /**
     * The <code>Connection</code> is being made.
     *
     * @see oracle.dss.connection.client.Connection#getConnectionStatus
     *
     * @status Reviewed
     */
    public final static int CONNECTING = 3;
    /**
     * The <code>Connection</code> attempt was a failure.
     *
     * @see oracle.dss.connection.client.Connection#getConnectionStatus
     *
     * @status New
     */
    public final static int CONNECTION_FAILED = 4;

    /**
     * The <code>org.omg.CORBA.ORB</code> instance to be used by the
     * connection.
     *
     * @see oracle.dss.connection.client.Connection#setProperty
     *
     * @status New
     */
    public final static String ORB = "Orb Reference";
    /**
     * @hidden
     */
	public final static String ORB_ARGS = "Orb Arguments";
    /**
     * The <code>java.util.Properties</code> containing arguments
     * needed to create the ORB.
     *
     * @see oracle.dss.connection.client.Connection#setProperty
     *
     * @status New
     */
	public final static String ORB_PROPS = "Orb Properties";
    /**
     * @hidden
     */
	public final static String ORB_INI_STATUS = "Orb Initialization Status";
	public final static String SERVER_TYPE = "Server Type";
	public final static String USERNAME = "user_name";
	public final static String PASSWORD = "password";
	public final static String SQL_DEBUG_FILE = "SQLDebugFile";

    /**
     * @hidden
     * Use this flag to specify the IOR for an already activated ServerInterface
     * remote object
     *
     * @status New
     */
    public final static String SERVER_IOR = "ior";

    /**
     * @hidden
     */
    public final static String REMOTE_CONNECTION = "remote";

    /**
     * @hidden
     */
    public final static String VERSION = "version";

    /**
     * @hidden
     */
    public final static int NOT_VALID = 1;

    /**
     * @hidden
     */
    public final static int VALID = 2;

    /**
     * Use this flag to specify the service for the connection
     * @status New
     */
    public final static String SERVICE = "service";

    /**
     * Use this flag to specify the host name for the connection
     * @status New
     */
    public final static String HOSTNAME = "hostname";

    /**
     * Use this flag to specify the port number for the connection
     * @status New
     */
    public final static String PORT = "port";

    /**
     * Use this flag to specify the SID for the connection
     * @status New
     */
    public final static String SID = "sid";

    /**
     * Use this flag to specify the jdbc URL for the connection
     * @status New
     */
    public final static String JDBC_URL = "jdbcurl";

    /**
     * Use this flag to specify the jdbc driver type for the connection
     * @status New
     */
    public final static String JDBC_TYPE = "jdbctype";

    /**
     * Use this flag to specify the name of the olap service for the connection
     * @status New
     */
    public final static String OLAP_SERVICE = "olapname";

    /**
     * Use this flag to retrieve the locale setting for the connection
     * @status New
     */
    public final static String LOCALE = "locale";

    /**
     * @hidden
     */
    public final static String ERROR_HANDLER = "errorhandler";

    /**
     * @hidden
     */
    public final static String BISESSION = "session";

    /**
     * The getVersionInfo() method returns a PropertyBag.  Use this key
     * to retrieve the database version from the PropertyBag.
     * @status New
     */
    public final static String DATABASE_VERSION = "database_version";

    /**
     * The getVersionInfo() method returns a PropertyBag.  Use this key
     * to retrieve the olap internal version from the PropertyBag.
     * @status New
     */
    public final static String OLAP_INTERNAL_VERSION = "olap_internal_version";

    /**
     * The getVersionInfo() method returns a PropertyBag.  Use this key
     * to retrieve the connection bean version from the PropertyBag.
     * @status New
     */
    public final static String CONNECTION_BEAN_VERSION = VersionInfo.BUILD_VERSION;

    /**
     * The getVersionInfo() method returns a PropertyBag.  Use this key
     * to retrieve the MDM driver version from the PropertyBag.  Following
     * are the possible values for this key.
     * @see oracle.dss.connection.common.CB#MDM_901_DRIVER
     * @see oracle.dss.connection.common.CB#MDM_92_DRIVER
     * @status New
     */
    public final static String MDM_DRIVER_VERSION = "mdm_driver_version";

    /**
     * The getVersionInfo() method returns a PropertyBag.  This is one of the
     * values for the MDM_DRIVER_VERSION key in the PropertyBag.
     * @see oracle.dss.connection.common.CB#MDM_DRIVER_VERSION
     * @status New
     */
    public final static String MDM_901_DRIVER = "901";

    /**
     * The getVersionInfo() method returns a PropertyBag.  This is one of the
     * values for the MDM_DRIVER_VERSION key in the PropertyBag.
     * @see oracle.dss.connection.common.CB#MDM_DRIVER_VERSION
     * @status New
     */
    public final static String MDM_92_DRIVER = "92";

    /**
     * The getVersionInfo() method returns a PropertyBag.  Use this key
     * to retrieve the JDBC driver version from the PropertyBag.
     * @status New
     */
    public final static String JDBC_DRIVER_VERSION = "jdbc_driver_version";

    /**
     * @hidden
     */
    public final static String DEPLOYMENT_PLATFORM = "deployment_platform";

    /**
     * @hidden
     */
    public final static String APPLET = "applet";

    /**
     * @hidden
     */
    public final static String CONNECTION = "connection";

    /**
     * A property to set the MetadataFetchPolicy on the ExpressDataProvider.  
     * Consult the OLAP API documentation to determine the values for this 
     * property.
     * @see oracle.express.olapi.data.full.ExpressDataProvider.
     */
    public final static String METADATA_FETCH_POLICY = "MetadataFetchPolicy";

    /**
     * @hidden
     * The value of this property can be set to Boolean.FALSE.  By doing so,
     * the MDObject representing AW logical metadata object will not be
     * enriched with AW specific metadata.
     */
    public final static String AW_ENABLED = "aw_enabled";

    public final static String CONNECTION_DRIVER = "connection_driver";

    /**
     * @hidden
     * Specifies a reference to connection driver manager
     */
    public static final String SECURITY_DRIVER_MANAGER = "securityDriverManager";

    /**
     * @hidden
     * encapsulates locale with resource bundle information and error handler
     */
    public static final String GLOBAL_ENVIRONMENT = "global_environment";

    /**
     * @hidden
     * encapsulates locale with resource bundle information and error handler
     */
    public static final String CONNECT_SETTINGS = "connection_settings";

    /**
     * @hidden
     * encapsulates locale with resource bundle information and error handler
     */
    public static final String CATALOG_EJBHOME = "catalog_ejbhome";

    /**
     * Application-specific connection parameters for query execution within the datasource
     */
    public static final String CONNECTION_PARAMETERS = "connection_parameters";

   /**
    * @hidden
    * The name of the application
    */
    public static final String APPLICATION_NAME = "app_name";
    
    public static final String SUPER_ROOT = "super_root";

    public static final String ROOT_NAME  = "root_name";
    
    public static final String SERVICE_CREDENTIALS = "service_credentials";
    
    public static final String SECURITY_SERVICE = "security_service";
    
    public static final String ADD_DATASOURCES = "add_ds";
    
    public static final String DATASOURCE_NAME = "datasource_name";
    
    public static final String SAW_URL = "saw_url";
    
    public static final String SOAP_SESSION = "?SoapImpl=nQSessionService";
    
    public static final String SOAP_METADATA = "?SoapImpl=metadataService";
    
    public static final String SOAP_XMLVIEW = "?SoapImpl=xmlViewService";

    public static final String SOAP_WEBCATALOG = "?SoapImpl=webCatalogService";
    
    public static final String SESSION_ID = "session_id";
    
//    public static final String SAS_JDBC = "sas_jdbc";
}
