/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataDirectorImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     11/01/06 - Move files back to oracle.dss.util
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     08/12/05 - 
    bmoroze     08/08/05 - 
    bmoroze     08/01/05 - 
    jramanat    07/15/05 - Add MemberSortInfo API to DataDirector3 
    jramanat    07/15/05 - 
    jramanat    07/13/05 - Add DimensionSortInfo API to DataDirector3 
    bmoroze     07/06/05 - 
    bmoroze     07/05/05 - 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/13/05 - 
    bmoroze     06/10/05 - 
    bmoroze     06/02/05 - 
    bmoroze     05/27/05 - 
    bmoroze     05/13/05 - 
    bmoroze     04/27/05 - Creation
 */
package oracle.dss.dataSource.common;

import java.lang.reflect.Method;

import java.util.Vector;


import oracle.dss.util.ColumnOutOfRangeException;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.InvalidDrillPathException;
import oracle.dss.util.InvalidDrillTargetException;
import oracle.dss.util.PollingRequiredEvent;
import oracle.dss.util.ColumnSortInfo;
import oracle.dss.util.DimensionSortInfo;
import oracle.dss.util.MemberSortInfo;
import oracle.dss.util.SortInfo;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataAvailableEvent;
import oracle.dss.util.DataDirectorException;
import oracle.dss.util.DataMap;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.RowOutOfRangeException;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.StatusInfo;

/**
 *  @hidden
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataDirectorImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
public abstract class DataDirectorImpl extends Object implements DataDirector
{    
    protected Query m_query = null;
    protected Delegate m_delegate = null;
    protected Vector m_listeners = new Vector();
    
    public DataDirectorImpl(Query query, Delegate delegate)
    {
        super();
        m_query = query;
        m_delegate = delegate;
    }

    public Query getQuery()
    {
        return m_query;
    }

    public void release()
    {
    }
    
    public abstract void setDelegate(Query delegateSource);
    
    public DataDirector getDelegate()
    {
        return m_delegate;
    }
    
    public int getListenerCount()
    {
        if (m_listeners != null)
            return m_listeners.size();
        
        return 0;
    }
    
    // javadoc from interface
    public boolean pivot(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.pivot(fromEdge, toEdge, fromLayer, toLayer, flags);
    }

    // javadoc from interface
    public int pivotCheck(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return DataDirector.PIVOT_CHECK_UNKNOWN;
            
        return m_delegate.pivotCheck(fromEdge, toEdge, fromLayer, toLayer, flags);
    }

    // javadoc from interface
    public boolean pivotOK(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
            
        return m_delegate.pivotOK(fromEdge, toEdge, fromLayer, toLayer, flags);
    }

    // javadoc from interface
    public boolean drill(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        
        return m_delegate.drill(edge, layer, slice, flags);
    }

    // javadoc from interface
    public boolean drillOK(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drillOK(edge, layer, slice, flags);
    }

    // javadoc from interface
    public boolean drill(int edge, int layer, int[] slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drill(edge, layer, slice, flags);
    }

    // javadoc from interface
    public boolean drillOK(int edge, int layer, int[] slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drillOK(edge, layer, slice, flags);
    }

    // javadoc from interface
    public boolean changeEdgeCurrentSlice(int edge, int slice) throws EdgeOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.changeEdgeCurrentSlice(edge, slice);
    }

    // javadoc from interface
    public boolean changeEdgeCurrentHPos(int edge, int[] hPos, int maxLayerSpecified) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
    
        return m_delegate.changeEdgeCurrentHPos(edge, hPos, maxLayerSpecified);
    }

    public DataAccess getDataAccess() throws DataDirectorException
    {
        if (m_delegate == null)
            return null;
            
        return m_delegate.getDataAccess(this);
    }
    
    // javadoc from interface
    public boolean reorder(int edge, int fromLayer, int toLayer, int flags) 
                           throws EdgeOutOfRangeException, LayerOutOfRangeException, 
                            DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.reorder(edge, fromLayer, toLayer, flags);
    }
            
    // javadoc from interface
    public boolean insertValueCalc(int row, int column, int flags, Object calc) throws RowOutOfRangeException, ColumnOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.insertValueCalc(row, column, flags, calc);
    }

    // javadoc from interface
    public boolean insertMemberCalc(int edge, int layer, int slice, int flags, Object calc) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        
        return m_delegate.insertMemberCalc(edge, layer, slice, flags, calc);
    }

    // javadoc from interface
    public boolean deleteValueCalc(int row, int column) throws RowOutOfRangeException, ColumnOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.deleteValueCalc(row, column);
    }

    // javadoc from interface
    public boolean deleteMemberCalc(int edge, int layer, int slice) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
    
        return m_delegate.deleteMemberCalc(edge, layer, slice);
    }

    ///// LISTENER NOTIFICATION
    // javadoc from interface
    public void addDataDirectorListener(DataDirectorListener l)
    {
 		if (m_listeners == null) 
        {
            m_listeners = new Vector();
        }

        if (m_listeners.indexOf(l) == -1)
        {
            m_listeners.addElement(l);
            // Make sure it's still in the query's list
            m_query.addDataDirector(this);
        }
        
        try
        {
            DataAccess da = m_query.generateDataAccess(this, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);        
            if (!m_query.firePollingRequired(null, l))
            {
                fireDataAvailable(l, new oracle.dss.dataSource.common.DataAvailableEvent(m_query, m_query.isDataAvailable(), da));
            }
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    protected void fireDataAvailable(oracle.dss.dataSource.common.DataAvailableEvent e) throws QueryException
    {
        if (m_listeners == null)
            return;
            
        for (int i = 0; i < m_listeners.size(); i++)
            fireDataAvailable((DataDirectorListener)m_listeners.elementAt(i), e);
    }
    
    protected void fireDataAvailable(DataDirectorListener l, oracle.dss.dataSource.common.DataAvailableEvent e) throws QueryException
    {
        // Notify DataDirectorListener that there is data available
        DataAccess da = e.getDataAccess();
        if (da == null)
            da = m_query.generateDataAccess(this, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);        
        DataAvailableEvent dataAvailableEvent = new DataAvailableEvent(m_query, e.isAvailable() ? DataAvailableEvent.DATA_AVAILABLE : DataAvailableEvent.DATA_UNAVAILABLE, e.isAvailable() ? da : null);
        l.viewDataAvailable(dataAvailableEvent);
   }
   
   protected void fireDataChanged(int changeType, boolean data, boolean row, boolean column, boolean page, DataAccess da) throws QueryException
   {
        if (m_listeners == null)
            return;
            
        DataDirector[] dd = new DataDirector[m_listeners.size()];
        for (int i = 0; i < dd.length; i++)
            dd[i] = this;
        DataAccess[] das = null;
        if (da == null)
            das = m_query.generateDataAccess(dd, changeType);
        else
        {
            // Clone these
            das = new DataAccess[dd.length];
            for (int i = 0; i < das.length; i++)
            {
                try
                {
                    Method m = das.getClass().getMethod("clone", null);
                    das[i] = (DataAccess)m.invoke(da, null);
                }
                catch (Exception e)
                {
                    // Just use the one we've got
                    das[i] = da;
                }
            }
        }
        if (das == null)
            return;
            
        for (int i = 0; i < das.length; i++)
        {
            ((DataDirectorListener)m_listeners.elementAt(i)).viewDataChanged(new oracle.dss.util.DataChangedEvent(m_query, das[i], changeType, data, row, column, page));
        }       
   }
   
   
   protected void firePollingRequired(PollingRequiredEvent event)
   {
        if (m_listeners == null)
            return;
        
        for (int i = 0; i < m_listeners.size(); i++)
        {
            if (m_listeners.elementAt(i) instanceof DataDirectorListener)
                ((DataDirectorListener)m_listeners.elementAt(i)).pollingRequired(event);
        }               
   }
   
    // javadoc from interface
    public void removeDataDirectorListener(DataDirectorListener l)
    {    
        if (m_listeners != null && m_listeners.indexOf(l) > -1)
            m_listeners.removeElement(l);
        
        // Now call query to remove the data director if this was the last listener on this DataDirector
        if (m_listeners.size() == 0)
            m_query.removeDataDirector(this);            
	}
    
    // javadoc from interface
    public boolean refresh() throws DataDirectorException
    {
        if (m_delegate == null)
            return false;
        
        return m_delegate.refresh();
    }

    // javadoc from interface
    public boolean revalidate() throws DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.revalidate();
    }

    // javadoc from interface
    public void setOutline(boolean outline) throws DataDirectorException
    {
        if (m_delegate != null)
            m_delegate.setOutline(outline);
    }

    // javadoc from interface
    public boolean isOutline()
    {
        if (m_delegate == null)
            return false;
        return m_delegate.isOutline();
    }

     // javadoc from interface
    public void setMetadataMap(int edge, int layer, MetadataMap map, int size) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate != null)
            m_delegate.setMetadataMap(edge, layer, map, size);
    }

    // javadoc from interface
    public void setDataMap(DataMap map, int sizeRow, int sizeColumn) throws DataDirectorException
    {
        if (m_delegate != null)
            m_delegate.setDataMap(map, sizeRow, sizeColumn);
    }

     // javadoc from interface
    public MetadataMap getMetadataMap(int edge, int layer) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getMetadataMap(edge, layer);
    }

    // javadoc from interface
    public DataMap getDataMap()
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getDataMap();
    }
        
    // javadoc from interface
    public boolean isCancelable()
    {
        if (m_delegate == null)
            return false;
        return m_delegate.isCancelable();
    }
    
    // javadoc from interface
    public boolean cancel() throws DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.cancel();
    }

    // javadoc from interface
    public void setManualUpdate()
    {
        if (m_delegate != null)
            m_delegate.setManualUpdate();
    }
    
    // javadoc from interface
    public void update() throws DataDirectorException
    {
        if (m_delegate != null)
            m_delegate.update();
    }    
    
    // javadoc from interface
    public MetadataMap getSupportedMetadataMap()
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getSupportedMetadataMap();
    }
    
    // javadoc from interface
    public LayerMetadataMap getSupportedLayerMetadataMap()
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getSupportedLayerMetadataMap();
    }

    // javadoc from interface
    public DataMap getSupportedDataMap()
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getSupportedDataMap();
    }

    // javadoc from interface
    public boolean drill(int edge, int layer, int slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drill(edge, layer, slice, pathID, targetID, flags);
    }    

    // javadoc from interface
    public boolean drillOK(int edge, int layer, int slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drillOK(edge, layer, slice, pathID, targetID, flags);
    }

    // javadoc from interface
    public boolean drill(int edge, int layer, int[] slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drill(edge, layer, slice, pathID, targetID, flags);
    }

    // javadoc from interface
    public boolean drillOK(int edge, int layer, int[] slice, String pathID, String targetID, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, InvalidDrillPathException, InvalidDrillTargetException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.drillOK(edge, layer, slice, pathID, targetID, flags);
    }

    // javadoc from interface
    public boolean setSorts(SortInfo[] sortInfo) throws LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)            
            return false;
        return m_delegate.setSorts(sortInfo);
    }


    // javadoc from interface
    public SortInfo[] getSorts() throws LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getSorts();
    }

    // javadoc from interface
    public boolean setColumnSorts(ColumnSortInfo[] sortInfo) throws LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return false;
        return m_delegate.setColumnSorts(sortInfo);
    }

    // javadoc from interface
    public ColumnSortInfo[] getColumnSorts() throws LayerOutOfRangeException, DataDirectorException
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getColumnSorts();
    }

    // javadoc from interface
    public void setProperty(String name, Object value) throws DataDirectorException
    {
        if (m_delegate != null)
            m_delegate.setProperty(name, value);
    }

    // javadoc from interface
    public Object getProperty(String name) throws DataDirectorException
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getProperty(name);
    }

    // javadoc from interface
    public Object[][] getCompatibleDataItemMetadata(String[] types, String[] idList) throws DataDirectorException
    {    
        if (m_delegate == null)
            return null;
        return m_delegate.getCompatibleDataItemMetadata(types, idList);
    }
    
    // javadoc from interface
    public String[] setExpressions(Object[] expressions) throws DataDirectorException
    {
        if (m_delegate == null)
            return null;
        return m_delegate.setExpressions(expressions);
    }
    
    // javadoc from interface
    public Object[] getExpressions()
    {
        if (m_delegate == null)
            return null;
        return m_delegate.getExpressions();
    }

    // javadoc from interface
    public boolean setDimensionSorts(DimensionSortInfo[] dimensionSortInfo) throws DataDirectorException {
      if (m_delegate == null) {
        return false;
      }
      return m_delegate.setDimensionSorts(dimensionSortInfo);
    }

    // javadoc from interface
    public DimensionSortInfo[] getDimensionSorts() throws DataDirectorException {
      if (m_delegate == null) {
        return null;
      }
      return m_delegate.getDimensionSorts();
    }    

    // javadoc from interface
    public boolean setMemberSorts(MemberSortInfo[] memberSortInfo) throws DataDirectorException {
      if (m_delegate == null) {
        return false;
      }
      return m_delegate.setMemberSorts(memberSortInfo);
    }

    // javadoc from interface
    public MemberSortInfo[] getMemberSorts() throws DataDirectorException {
      if (m_delegate == null) {
        return null;
      }
      return m_delegate.getMemberSorts();
    }    
    
    // javadoc from interface
    public void fireEvents() throws DataDirectorException
    {        
        if (m_delegate != null)
            m_delegate.fireEvents();
    }
    
    // javadoc from interface
    public StatusInfo startExecution() throws DataDirectorException
    {   
        if (m_delegate == null)
            return null;
            
        return m_delegate.startExecution();
    }    
    
    // javadoc from interface
    public StatusInfo getStatus() throws DataDirectorException
    {   
        if (m_delegate == null)
            return null;
            
        return m_delegate.getStatus();
    }    
    
    // javadoc from interface
    public void setLayerMetadata(int edge, int layer, String type, Object value) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {        
        if (m_delegate == null)
            return;
            
        m_delegate.setLayerMetadata(edge, layer, type, value);
    }    
    
}
