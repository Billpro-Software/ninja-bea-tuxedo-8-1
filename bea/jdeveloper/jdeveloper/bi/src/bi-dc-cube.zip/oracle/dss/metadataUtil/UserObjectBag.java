/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

/****************************************************
 * Imports
 ****************************************************/
import java.lang.Object;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.UserObject;

/**
 * @hidden
 * User object Bag contains a hashtable of UserObjects
 * and a String(Key) represents the relation or context.
 */
public class UserObjectBag implements Serializable {
  /************************************************************************
  * Private members
  ************************************************************************/
  //  String 			- Relation ( key )
  //  UserObject  - UserObject
  private  Hashtable m_UserObjectBag = null;
  private int initCapacity = 1;

	//Default Constructor
    public UserObjectBag() {
        m_UserObjectBag = new Hashtable( initCapacity );
    }

  /************************************************************************
  * Public Methods
  ************************************************************************/

	public int size(){
		return m_UserObjectBag.size();	
	}

	public UserObject[] getUserObjects(){
		if ( size() == 0 )
			return null;
		UserObject[] userObjects = new UserObject[size()];
		Enumeration enumer = m_UserObjectBag.elements();
		for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
				userObjects[i] = (UserObject) enumer.nextElement();
		}
		return userObjects ; 
	}

	public Object[] getObjects(){
		if ( size() == 0 )
			return null;
		Object[] objects = new Object[getObjectCount()];
		UserObject[] userObjects = getUserObjects();
		for ( int i = 0; ( ( userObjects != null ) && ( i < userObjects.length ) )  ; i++ ) {
			if ( ( userObjects[i] != null ) && ( ((Object) userObjects[i].getObject()) != null ) ) {
				objects[i] = (Object) userObjects[i].getObject();		
			}
		}
		return objects ; 
	}

	public UserObject getUserObject( String relation ){
		if ( size() == 0 )
			return null;
		return (UserObject) m_UserObjectBag.get((Object)relation );
	}

    public String getRelation( UserObject userObject ) {
        if( m_UserObjectBag != null && m_UserObjectBag.contains( userObject ) ) {
            Enumeration enumer = m_UserObjectBag.keys();
            while( enumer.hasMoreElements() ) {
                String relation = (String)enumer.nextElement();
                if( (m_UserObjectBag.get( relation )).equals( userObject ) ) {
                    return relation;
                }
            }
        }
        return null;
    }

	public Object getObject( String relation ){
		if ( size() == 0 )
			return null;
		return (Object) (getUserObject(relation)).getObject();  
	}

	public UserObject[] getUserObjects( Property property ){
		if ( size() == 0 )
			return null;
		int count = getUserObjectCount(property);
		UserObject[] userObjects = new UserObject[count];
		Enumeration enumer = m_UserObjectBag.elements();
		for ( int i = 0, j = 0; (( enumer.hasMoreElements()) && ( j < count )) ; i++ ) {
			UserObject userObject = (UserObject) enumer.nextElement();
			if ( (userObject.contains( property))){
				userObjects[j] = userObject;
				j++;	
			}
		}
		return userObjects;
	}

	public Object[] getObjects( Property property ){
		if ( size() == 0 )
			return null;
		UserObject[] userObjects = getUserObjects( property );
		int count = getObjectCount(property);
		Object[] objects = new Object[count];
		for ( int i = 0, j =0; ( ( i < userObjects.length) && ( j < count) ) ; i ++ ) {
			if (( userObjects[i] != null ) && ( userObjects[i].getObject() == null )) {
				objects[j] = (Object) userObjects[i].getObject();
			}	
		}
		return objects;
	}
	
	public void setUserObject( String relation, UserObject userObject ){
		m_UserObjectBag.put ( (Object) relation, (Object) userObject );
		return;
	}
/*
	public void setObject( String relation, Object object ){
		UserObject userObject = new UserObject();
		userObject.setObject ( object );
		m_UserObjectBag.put ( (Object) relation, (Object) userObject );
		return;
	}
*/
	public void removeUserObject( String relation ) {
		m_UserObjectBag.remove ( (Object) relation );
		return;
	}

	public void removeAll() {
		Enumeration enumer = m_UserObjectBag.keys();
		for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
			m_UserObjectBag.remove ( (Object) enumer.nextElement() );		
		}
		return;
	}

	public Hashtable getUserObjectBag(){
		return m_UserObjectBag;
	}

	public void setUserObjectBag( Hashtable userObjectBag ){
		m_UserObjectBag = userObjectBag;
		return;
	}
		
	public void free() {
		removeAll();
		m_UserObjectBag = null;
		return;
	}

  /************************************************************************
  * Private methods
  ************************************************************************/
	private int getUserObjectCount( Property property){
		int count = 0;
		UserObject userObject = null;
		Enumeration enumer = m_UserObjectBag.elements();
		for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
			userObject = (UserObject) enumer.nextElement();
			if ( (userObject.contains( property)) )
				count++;	
		}
		return count;
	}


	private int getObjectCount(){
		int count = 0;
		Enumeration enumer = m_UserObjectBag.elements();
		for ( int i = 0 ; enumer.hasMoreElements() ; i ++ ) {
			UserObject userobject = (UserObject) enumer.nextElement();
			if ( (userobject.getObject()) != null )
				count ++;
		}
		return count;
	}

	private int getObjectCount( Property property ){
		int count = 0;
		Enumeration enumer = m_UserObjectBag.elements();
		for ( int i = 0 ; enumer.hasMoreElements() ; i ++ ) {
			UserObject userobject = (UserObject) enumer.nextElement();
			if (( userobject.contains (property) ) && ( (userobject.getObject()) != null ) )
				count ++;
		}
		return count;
	}
}