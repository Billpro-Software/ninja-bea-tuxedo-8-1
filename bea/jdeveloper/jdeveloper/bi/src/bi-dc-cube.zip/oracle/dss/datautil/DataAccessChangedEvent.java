/*
 * DataAccessChangedEvent.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil;

import oracle.dss.util.DataAccess;

/**
 * Describes the event that provides <code>DataAccess</code> cursor information
 * to <code>QueryAccess</code> clients.
 *
 * @status Documented
 */
public class DataAccessChangedEvent extends QueryEditorInstanceEvent
{
    /**
     * @hidden
     * Constructs the event.
     *
     * @param qe        Source object.
     * @param dimension The name of the dimension whose cursor has changed.
     * @param da        The new <code>DataAccess</code> object.
     *
     * @status Documented
     * @hidden
     */
    public DataAccessChangedEvent(Object qe, String dimension, DataAccess da) {
        super(qe, 0);

        m_da = da;
        m_dim = dimension;
    }

    /**
     * Constructs the event.
     *
     * @param qe    The <code>QueryEditor</code> object that fired this
     *                  event.
     * @param dimension The name of the dimension whose cursor has changed.
     * @param da        The new <code>DataAccess</code> object.
     *
     * @status Documented
     * @hidden
     */
    public DataAccessChangedEvent(QueryEditor qe, String dimension, DataAccess da) {
        super(qe, 0);

        m_da = da;
        m_dim = dimension;
    }
    
    /**
     * Constructs the event.
     *
     * @param qe    The <code>QueryEditor</code> object that fired this
     *                  event.
     * @param dimension The name of the dimension whose cursor has changed.
     * @param da        The new <code>DataAccess</code> object.
     * @param instance The instance number that changed
     *
     * @status Documented
     * @hidden
     */
    public DataAccessChangedEvent(QueryEditor qe, String dimension, DataAccess da, int instance)
    {
        super(qe, instance);

        m_da = da;
        m_dim = dimension;
    }
    
    /**
     * Retrieves the name of the dimension that has been changed.
     *
     * @return The name of the dimension that was changed.
     *
     * @status Documented
     */
    public String getDimension()
    {
        return m_dim;
    }
     
    /**
     * Retrieves the changed <code>DataAccess</code> object.
     * 
     * @return The <code>DataAccess</code> object.
     *
     * @status Documented
     */
    public DataAccess getDataAccess() {
        return m_da;
    }
            
    /**
     * @hidden
     * 
     * @serial New DataAccess
     */
    protected DataAccess m_da = null;
    
    /**
     * @hidden
     * 
     * @serial Dim name
     */
    protected String m_dim = null;
}