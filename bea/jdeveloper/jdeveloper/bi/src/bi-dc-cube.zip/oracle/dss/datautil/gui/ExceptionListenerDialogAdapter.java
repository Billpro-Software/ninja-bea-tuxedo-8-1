/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/ExceptionListenerDialogAdapter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;

import java.util.Locale;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.gui.BIExceptionDialog;
import oracle.dss.util.gui.BIJOptionPane;
import oracle.dss.util.gui.ResourceHandler;

/**
 * Default exception listener dialog.
 *
 * This is the default implementation of the <code>ExceptionListenerDialog</code>
 * interface.
 *
 * This implementation simply displays a <code>BIExceptionDialog</code> in
 * response to exception method calls.
 *
 * @status new
 */
public class ExceptionListenerDialogAdapter implements ExceptionListenerDialog {

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * The <code>Component</code> which represents the exception dialog's parent.
   *
   * @status private
   */
  private transient Component m_componentParent = null;

  /**
   * The <code>String</code> representing the title of the exception dialog.
   *
   * @status private
   */
  private transient String m_strTitle = null;

  /**
   * The <code>Locale</code> used to properly translate messages.
   *
   * @status private
   */
  private transient Locale m_locale = null;

  /**
   * The Help context id.
   *
   * @status private
   */
  private transient String m_helpContextId = null;

  /**
   * Determines whether help button is displayed or not.
   *
   * @status private
   */
  private transient boolean m_bHelpEnabled = true;

  /**
	 * @hidden
   *
   * Error handler reference
   *
   * @status hidden
   */
  protected transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /**
   * Retrieves the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @return A <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @status hidden
   */
  private transient ResourceHandler m_resourceHandler = null;

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  //-------------------------------------------------------------------
  // Start Implementation of HelpContext interface
  //-------------------------------------------------------------------

  /**
   * Retrieves the Help context ID for this panel.
   * The default Help context ID is the full class path for this panel.
   * To set a different Help context ID, use the method
   * <code>setHelpContextID(String)</code>.
   *
   * The Help context ID that is used when listening for the user event
   * that requests the display of Help for this panel.
   *
   * @return The Help context ID for this panel
   *
   * @status new
   */
  public String getHelpContextID() {
    // If the Help context ID has been set by the application developer,
    // use that context ID, otherwise use the class name
    if (m_helpContextId != null) {
      return (m_helpContextId);
    }

    return this.getClass().getName();
  }

  /**
   * Specifies the Help context ID for this panel.
   * This Help context ID is used when listening for the user event
   * that requests the display of Help for this panel.
   *
   * @param helpContextId   The Help context ID for this panel.
   *
   * @status new
   */
  public void setHelpContextID (String helpContextId) {
    m_helpContextId = helpContextId;
  }

  //-------------------------------------------------------------------
  // End Implementation of HelpContext interface
  //-------------------------------------------------------------------

  //-----------------------------------------------------------------------
  // Begin - Implementation of the Localizable interface
  //-----------------------------------------------------------------------

  /**
   * Retrieves the locale associated with a object.
   *
   * @return <code>Locale</code> which represents the locale setting for this
   *         object, or the the system default locale, if not locale has been
   *         explicitly set.
   *
   * @status new
   */
  public Locale getLocale() {
    return m_locale;
  }

  /**
   * Specifies the locale used by this object.
   *
   * @param locale A <code>Locale</code> value that represents the locale to use
   *               for proper translation.
   *
   * @status new
   */
  public void setLocale (Locale locale) {
    m_locale = locale;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the Localizable interface
  //-----------------------------------------------------------------------

  //-----------------------------------------------------------------------
  // Begin - Implementation of the ExceptionListenerDialog interface
  //-----------------------------------------------------------------------

  /**
   * Retrieves the exception dialog's parent.
   *
   * @return <code>Component</code> which represents the exception dialog's parent.
   *
   * @status new
   */
  public Component getComponentParent() {
    return m_componentParent;
  }

  /**
   * Specifies the exception dialog's parent.
   *
   * @param componentParent A <code>Component</code> value which represents the
   *                        exception dialog's parent.
   *
   * @status new
   */
  public void setComponentParent (Component componentParent) {
    m_componentParent = componentParent;
  }

  /**
   * Retrieves the title associated with the exception dialog.
   *
   * @return <code>String</code> which represents the title associated with the
   *         exception dialog.
   *
   * @status new
   */
  public String getTitle() {
    return m_strTitle;
  }

  /**
   * Specifies the title associated with the exception dialog.
   *
   * @param strTitle A <code>String</code> whicv represents the title associated
   *                 with the exception dialog.
   *
   * @status new
   */
  public void setTitle (String strTitle) {
    m_strTitle = strTitle;
  }

  /**
   * Responds to trapped exceptions.
   *
   * <code>ExceptionListenerCallback</code> implementations call this method when
   * a response is required to an exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return <code>int</code> value which represents a positive response
   *         when zero and a negative response when non-zero.
   *
   * @see ExceptionListenerGui#OK_OPTION
   * @see ExceptionListenerGui#YES_OPTION
   * @see ExceptionListenerGui#NO_OPTION
   * @see ExceptionListenerGui#CANCEL_OPTION
   * @see ExceptionListenerGui#NONE_OPTION
   * @see ExceptionListenerGui#CLOSED_OPTION
   *
   * @status new
   */
  public int processException (Throwable throwable, String strClass, String strRoutine) {
    // Check for non-null exception
    if (throwable != null) {
      // Retrieve the dialog
      BIExceptionDialog biExceptionDialog =
        getDialog (throwable, strClass, strRoutine);

      // If we have create a dialog, display it
      if (biExceptionDialog != null) {
        biExceptionDialog.display();
      }
    }

    return ExceptionListenerGui.CANCEL_OPTION;
  }

  /**
   * Specifies whether a Help button in a dialog box that is displayed by
   * this panel, is displayed.
   * <P>For example, suppose that this panel had a font button and that
   * font button displayed a font dialog box. If that font dialog box had
   * a Help button, then this method would specify whether that Help button
   * is displayed.</P>
   *
   * @param  bValue  <code>true</code> to display the Help button,
   * <code>false</code> to hide it.
   *
   * @status new
   */
  public void setHelpEnabled (boolean bValue) {
    m_bHelpEnabled = bValue;
  }

  /**
   * Indicates whether a Help button in a dialog box that is displayed by
   * this panel, is displayed.
   * <P>For example, suppose that this panel had a font button and that
   * font button displayed a font dialog box. If that font dialog box had
   * a Help button, then this method would tell you whether that Help button
   * is displayed.</P>
   *
   * @return  <code>true</code> if the Help button is hidden,
   * <code>false</code> if it is displayed.
   *
   * @status new
   */
  public boolean isHelpEnabled() {
    return m_bHelpEnabled;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the ErrorHandlerDialog interface
  //-----------------------------------------------------------------------

	//-------------------------------------------------------------------
	// Start implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status New
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status New
   */
  public void removeErrorHandler() {
    addErrorHandler (new DefaultErrorHandler());
  }

	//-------------------------------------------------------------------
	// End implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> that represents the current
   *         error handler.
   *
   * @status New   
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /**
   * Specifies the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @param resourceHandler A <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @status new 
   */
  public void setResourceHandler (ResourceHandler resourceHandler) { 
    m_resourceHandler = resourceHandler;
  }

  /**
   * Retrieves the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @return A <code>ResourceHandler</code> used for resource retrieval..
   * 
   * @status new 
   */
  public ResourceHandler getResourceHandler() { 
    return m_resourceHandler; 
  }

  /**
   * @hidden
   * Retrieves the <code>BIExceptionDialogdialog</code> to display in response
   * to a <code>Throwable</code> exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ErrorHandlerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ErrorHandlerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return <code>BIExceptionDialog</code> which represents the dialog to display.
   *
   * @status hidden
   */
  public BIExceptionDialog getDialog (Throwable throwable, String strClass, String strRoutine) {

    // Determine the parent for the dialog
    Component componentParent = getComponentParent();

    // Initialize exception dialog
    BIExceptionDialog biExceptionDialog = null;

    // Check to see if the parent is a frame
    if (componentParent instanceof Frame) {
      biExceptionDialog =
        new BIExceptionDialog ((Frame)componentParent, throwable, getTitle(),
          throwable.getMessage(), getLocale());
    }
    // Check to see if the parent is a dialog
    else if (componentParent instanceof Dialog) {
      biExceptionDialog =
        new BIExceptionDialog ((Dialog)componentParent, throwable, getTitle(),
          throwable.getMessage(), getLocale());
    }
    else {
      // Default to no parent
      biExceptionDialog =
        new BIExceptionDialog ((Frame)null, throwable, getTitle(),
          throwable.getMessage(), getLocale());
    }

    // If we have create a dialog, display it
    if (biExceptionDialog != null) {
      biExceptionDialog.setHelpContextID (getHelpContextID());
      biExceptionDialog.setHelpEnabled (isHelpEnabled());
      biExceptionDialog.setModal (true);
    }

    return biExceptionDialog;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}

