/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.util.EventListener;
import java.util.Vector;

/**
 * @hidden
 * The interface allows grouping of sticky and non sticky items
 * in a list.
 *
 * @status hidden
 */

public interface CustomList
{
    //-------------------------------------------------------------------
    // PUBLIC CONSTANTS
    //-------------------------------------------------------------------

    /**
     * The sticky item type.
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_STICKYITEM = 1;
    
    /**
     * The non sticky item type.
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_NONSTICKYITEM = 2;

    /**
     * Includes both sticky and non sticky items
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_ALLITEMS = 3;

    /**
     * The item position type. 
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_ITEMPOS_NORTH = 1;
    
    /**
     * The item position type. 
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_ITEMPOS_SOUTH = 2;
    
    /**
     * The item position type. 
     *
     * @status hidden
     */
    public static final int CUSTOMLIST_ITEMPOS_DEFAULT = 3;
    
    //-------------------------------------------------------------------
    // PUBLIC METHODS
    //-------------------------------------------------------------------

    /**
     * @hidden
     * Adds an item of specified type to the list. Registers the listener 
     * with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param itemType The type of the item.
     * @param listener The listener for the item.
     *
     * @status hidden
     */
    public boolean addItem ( Object anObject, int itemType, EventListener listener );
    
    /**
     * @hidden
     * Adds an item of specified type to the list. Registers the listener 
     * with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param itemType The type of the item.
     * @param itemPosition The relative position of the item
     * @param listener The listener for the item.
     *
     * @status hidden
     */
    public boolean addItem ( Object anObject, int itemType, 
                             int itemPosition, EventListener listener );
    
    /**
     * @hidden
     * Gets the count of non sticky items in the list.
     *   
     * @return The count of non sticky items in the list.
     *
     * @status hidden
     */
    public int getNonStickyItemCount ( );
    
    /**
     * @hidden
     * Replaces one item in the non sticky group with the specified item. Registers
     * the listener with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param listener The listener for the item.
     *
     * @status hidden
     */
    public void replaceNonStickyItem ( Object anObject, EventListener listener );
    
    /**
     * @hidden
     * Specifies the count of non sticky items in the list.
     *   
     * @param itemCount The count of non sticky items in the list.
     *
     * @status hidden
     */
    public void setNonStickyItemCount ( int itemCount );
}
    