/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.ArrayList;
import java.util.Hashtable;

import javax.naming.directory.SearchResult;

import javax.swing.tree.TreeNode;

import oracle.dss.bicontext.BISearchResult;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 * Default factory class for tree nodes that represents container Persistable objects (for example, Workbooks).
 * Users can override and register their own TreeNodeFactory through the CatalogTreeModel class.
 */
public class PersistableTreeNodeFactory extends TreeNodeFactory
{
    static final String EXPANDABLE_TYPES = "types";

    private ArrayList m_types;

    /**
     * Constructor
     */
    public PersistableTreeNodeFactory()
    {
        m_types = new ArrayList(10);
        
        // these are the default supported Persistable object types
        m_types.add(PersistableConstants.WORKBOOK);
        m_types.add("oracle.bi.app.builder.document.WorkbookModel");
        m_types.add("oracle.bi.app.builder.document.WorksheetModel");
        m_types.add("oracle.bi.app.builder.document.FrameModel");
        m_types.add("oracle.bi.app.builder.document.PresentationModel");
    }
    
    /**
     * Add an object type as one of the supported types.  Non-supported types
     * are not displayed in the tree.
     * @param type
     */
    public void addObjectType(String type)
    {
        if (type != null)
            m_types.add(type);
    }
    
    /**
     * Override to create specialized tree node for Persistable objects
     * @return a tree node that represents the Persistable object.  
     * @param result
     * @param env
     */
    public TreeNode createTreeNode(Hashtable env, SearchResult result)
    {
        String _type = ((BISearchResult)result).getObjectType();
        if (_type != null && m_types.contains(_type))
            return createPersistableTreeNode(env, result);
        else
            return super.createTreeNode(env, result);
    }
    
    /**
     * Creates a PersistableTreeNode based on Persistable object
     * @param env
     * @param persistable
     * @return a tree node that represents the Persistable object.  
     *         null if the object type is not supported
     */
    public TreeNode createTreeNode(Hashtable env, Persistable persistable)
    {
        String _type = persistable.getPersistableAttributes(null).getObjectType();
        if (_type != null && m_types.contains(_type))
        {   
            // special case for WorkbookBuilder.  Hide TextArea objects even though
            // they are one of the supported type
            String _compSubType1 = PersistableTreeNode.mapType(persistable.getPersistableAttributes(null).getCompSubType1());
            if ("oracle.bi.app.builder.document.PresentationModel".equals(_type) && _compSubType1 != null)
                if (PersistableConstants.GRAPH.equals(_compSubType1) || PersistableConstants.CROSSTAB.equals(_compSubType1)
                || PersistableConstants.TABLE.equals(_compSubType1))
                    return createPersistableTreeNode(env, persistable);
                else
                    return null;
            else
                return createPersistableTreeNode(env, persistable);
        }
        else
            return null;
    }

    /**
     * User would only need to override this method if the user simply subclass PersistableTreeNode (for sub-objects)
     * @param env
     * @param persistable
     * @return
     */
    protected PersistableTreeNode createPersistableTreeNode(Hashtable env, Persistable persistable)
    {
        return new PersistableTreeNode(env, persistable);
    }

    /**
     * User would only need to override this method if the user simply subclass PersistableTreeNode
     * (for top-level Persistable object)
     * @param env
     * @param result
     * @return
     */
    protected PersistableTreeNode createPersistableTreeNode(Hashtable env, SearchResult result)
    {
        return new PersistableTreeNode(env, result);
    }
}