/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui.panel.event;

import java.util.EventObject;

/**
 * Describes the panel state that is related to a particular panel.
 *
 * @status documented
 */

public class PanelStateEvent extends EventObject
{
    /////////////////////////////////////////////////////////////////////
    // PUBLIC CONSTANTS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * The panel state is valid.
     *
     * @status documented
     */
    public static final String PANELSTATE_VALID = "valid";
    
    /**
     * The panel state is invalid.
     *
     * @status documented
     */
    public static final String PANELSTATE_INVALID = "invalid";
    
    /////////////////////////////////////////////////////////////////////
    // NON PUBLIC MEMBERS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * @hidden
     *
     * The panel state type. Valid values are PANELSTATE_VALID and 
     * PANELSTATE_INVALID.
     *
     * @status protected
     */
    protected String m_type = null;
    
    /**
     * @hidden
     *
     * The panel state info.
     *
     * @status protected
     */
    protected String m_stateInfo = null;
    
    /**
     * @hidden
     *
     * A placeholder for user state information.
     *
     * @status protected
     */
    protected Object m_userStateInfo = null;
    
    /////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Constructor that specifies all arguments, except the one for user-defined
     * state information.
     *
     * @param source The source of the event. This is the reference to the 
     * <code>StandardPanel</code> from which the event originated.
     * @param nType The type of the event.
     * @param nStateInfo The information about the panel state.
     *
     * @status documented
     */
    public PanelStateEvent ( Object source, String type, String stateInfo ) 
    {
        super ( source );
        m_type = type;
        m_stateInfo = stateInfo;
    }        
    
    /**
     * Constructor that specifies all arguments.
     *
     * @param source The source of the event. This is the reference to the 
     * <code>StandardPanel</code> from which the event originated.
     * @param nType The type of the event.
     * @param nStateInfo The information about the panel state.
     * @param userStateInfo The state information that is user-defined. This is 
     * interpreted based on the nStateInfo argument.
     *
     * @status documented
     */
    public PanelStateEvent ( Object source, String type, 
                             String stateInfo, Object userStateInfo ) 
    {
        super ( source );
        m_type = type;
        m_stateInfo = stateInfo;
        m_userStateInfo = userStateInfo;
    }        
    
    /////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Retrieves the information about the state of the panel.
     *
     * @return The information about the state.
     *
     * @status documented
     */
    public String getStateInfo ( )
    {
        return m_stateInfo;
    }
    
    /**
     * Retrieves the type of the panel state event.
     *
     * @return The type of the event.
     *
     * @status documented
     */
    public String getType ( )
    {
        return m_type;
    }        
    
    /**
     * Retrieves the user-defined information about the state of the panel.
     *
     * @return The user-defined information.
     *
     * @status documented
     */
    public Object getUserStateInfo ( )
    {
        return m_userStateInfo;
    }
    
    /**
     * Specifies the information about the state of the panel.
     *
     * @param stateInfo The information about the state.
     *
     * @status documented
     */
    public void setStateInfo ( String stateInfo )
    {
        m_stateInfo = stateInfo;
    }
    
    /**
     * Specifies the type of the panel state event.
     *
     * @param type The event type.
     *
     * @status documented
     */
    public void setType ( String type )
    {
        m_type = type;
    }        
    
    /**
     * Specifies the user-defined information about the state of the panel.
     *
     * @param userStateInfo The user-defined information.
     *
     * @status documented
     */
    public void setUserStateInfo ( Object userStateInfo )
    {
        m_userStateInfo = userStateInfo;
    }
}

    
