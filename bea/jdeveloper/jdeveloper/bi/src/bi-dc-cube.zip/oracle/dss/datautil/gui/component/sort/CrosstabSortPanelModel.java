/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/CrosstabSortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    01/17/06 - Creation
 */

package oracle.dss.datautil.gui.component.sort;

import java.util.Vector;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/CrosstabSortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public interface CrosstabSortPanelModel extends SortPanelModel {
  /**
   * Retrieves a list of items that can be sorted
   * 
   * @return The list of items;
   */
  public Vector getSortItems();
  
  /**
   * Retrieves the item currently being sorted
   * 
   * @return The sort item
   */
  public String getSortItem();
  
  /**
   * Specifies the item currently being sorted
   * 
   * @param item The sort item
   */
  public void setSortItem(String item);
  
  /**
   * Retrieves the criteria by which the sort item can be sorted
   * 
   * @return The sort criteria
   */
  public Vector getSortCriteria();
  
  /**
   * Indicates whether the specified sort item is a dimension or an item
   * 
   * @return <code>true</code> if the sort item is a dimension, 
   *         <code>false</code> otherwise
   */
  public boolean isDimension();
  
  /**
   * Retrieves the sorts for the sort item
   * 
   * @return a <code>DimensionSortInfo</code> if the item is a dimension, or a
   *         <code>QDRSortInfo</code> if it is not
   */
  public Object getSorts();
  
  /**
   * Specifies the sorts for the sort item
   * 
   * @param sorts a <code>DimensionSortInfo</code> if the item is a dimension, 
   *              or a <code>QDRSortInfo</code> if it is not
   */
  public void setSorts(Object sorts);
  
  /**
   * Applies the sorts for all sort items
   */
  public void applySorts();
  
  /**
   * Retrieves a list of sort directions
   * 
   * @param sortItem The criteria for which to retrieve sort directions
   *  
   * @return The sort directions
   */
  public Vector getDirections(Object criteria);
  
  /**
   * Retrieves the sort hierarchy for the sort item if it is a dimension
   * 
   * @return the hierarchy
   */
  public String getHierarchy();
}