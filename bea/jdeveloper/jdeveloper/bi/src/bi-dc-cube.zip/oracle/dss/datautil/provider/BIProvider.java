/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/provider/BIProvider.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.provider;

import oracle.dss.datautil.provider.DataProvider;
import oracle.dss.datautil.provider.MetadataProvider;
import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.QueryEditor;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.util.DataDirector;
import oracle.dss.util.gui.context.PropertyHashtable;

/**
 * <pre>
 * BIProvider used to retrieve data and metadata.
 * </pre>
 * 
 * @author gkellam 
 * @since  11.0.0.0.5
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   04/08/08 - 
 *    gkellam   09/14/05 - 
 *    jramanat  09/12/05 - Let setProperty(key, null) clear the property 
 *    jramanat  09/01/05 - 
 *    gkellam   08/24/05 - Add BIProvider.java removed by ADE from 
 *                         transaction. 
 */

public class BIProvider extends PropertyHashtable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////
  
  /**
   * <code>MetadataManager</code> property.
   * 
   * @status new
   */
  public static String METADATA_MANAGER = "MetadataManager";

  /**
   * <code>QueryContext</code> property.
   * 
   * @status new
   */
  public static String QUERY_CONTEXT = "QueryContext";

  /**
   * <code>QueryEditor</code> property.
   * 
   * @status new
   */
  public static String QUERY_EDITOR = "QueryEditor";

  /**
   * <code>DataDirector</code> property.
   * 
   * @status new
   */
  public static String DATA_DIRECTOR = "DataDirector";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  /**
   * Default constructor.
   *
   * @status new
   */
  public BIProvider () {
  }

  /**
   * Constructor based on a <code>QueryContext</code>.
   *
   * @param queryContext A <code>QueryContext</code> used for data retrieval.
   * 
   * @status new
   */
  public BIProvider (QueryContext queryContext) {
    setQueryContext (queryContext);

    if (queryContext != null) {
        setMetadataManager ((MetadataManager)queryContext.getMetadataManager());
    }
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
 
  /**
   * Specifies a property.
   * 
   * A key can be removed by specifying a null value.
   *
   * @param objKey A <code>Object</code> key, which cannot be null.
   * @param objValue A <code>Object</code> value.
   * 
   * @status new
   */
  public void setProperty (Object objKey, Object objValue) {
    if (objKey != null) {
      if (objValue != null) {
        put (objKey, objValue);
      }
      else {
        remove (objKey);
      }
    }
  }
  
  /**
   * Specifies the <code>MetadataManager</code>.
   * 
   * @param metadataManager A <code>MetadataManager</code> used to retrieve metadata.
   * 
   * @status new 
   */
  public void setMetadataManager (MetadataManager metadataManager) { 
    setProperty (METADATA_MANAGER, metadataManager);
  }

  /**
   * Retrieves the <code>MetadataManager</code>.
   * 
   * @return A <code>MetadataManager</code> used to retrieve metadata.
   * 
   * @status new 
   */
  public MetadataManager getMetadataManager() { 
    return (MetadataManager) getProperty (METADATA_MANAGER) ; 
  }

  /**
   * Specfies the <code>QueryContext</code>.
   * 
   * @param queryContext A <code>QueryContext</code> used to evaluate queries.
   * 
   * @status new 
   */
  public void setQueryContext (QueryContext queryContext) { 
    setProperty (QUERY_CONTEXT, queryContext);
  }

  /**
   * Retrieves the <code>QueryContext</code>.
   * 
   * @return A <code>QueryContext</code> used to evaluate queries.
   * 
   * @status new 
   */
  public QueryContext getQueryContext() { 
    return (QueryContext) getProperty (QUERY_CONTEXT) ; 
  }

  /**
   * Specifies the <code>QueryContext</code>.
   * 
   * @param queryEditor A <code>QueryContext</code> used to process queries.
   * 
   * @status new 
   */
  public void setQueryEditor (QueryEditor queryEditor) { 
    setProperty (QUERY_EDITOR, queryEditor);
  }

  /**
   * Retrieves the <code>QueryEditor</code>.
   * 
   * @return A <code>QueryEditor</code> used to process queries.
   * 
   * @status new 
   */
  public QueryEditor getQueryEditor() { 
    return (QueryEditor) getProperty (QUERY_EDITOR) ; 
  }

  /**
   * Creates a default <code>DataProvider</code>.
   * 
   * @return A <code>DataProvider</code> used to retrieve data.
   * 
   * @status new 
   */
  public DataProvider makeDataProvider() {
    return new BIDataProvider (this);
  }
            
  /**
   * Creates a default <code>MetadataProvider</code>.
   * 
   * @return A <code>MetadataProvider</code> used to retreive metadata.
   * 
   * @status new
   */
  public MetadataProvider makeMetadataProvider() {
    return new BIMetadataProvider (this);
  }

  /**
   * Specifies the DataDirector
   * 
   * @param dataDirector The DataDirector
   */
  public void setDataDirector(DataDirector dataDirector) {
    setProperty(DATA_DIRECTOR, dataDirector);
  }

  /**
   * Retrieves the DataDirector
   * 
   * @return The DataDirector
   */
  public DataDirector getDataDirector() {
    return (DataDirector) getProperty(DATA_DIRECTOR);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
  
}
