/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.dataSource.common.resource;

import java.util.ListResourceBundle;

/**
 * @hidden
 * Resources for data source client bean.
 * @status reviewed
 */
public class QueryCommonBundle extends ListResourceBundle
{
    static final Object[][] resourceArray =
    {
        {"Query", "Query"},
        {"QueryManager", "QueryManager"},
        {"AutoUpdate", "AutoUpdate"},
        {"Database", "Database"},
        {"queryManager", "queryManager"},
        {"SuppressColumns", "SuppressColumns"},
        {"SuppressRows", "SuppressRows"},
        {"SuppressPages", "SuppressPages"},
        {"Grand Total", "Grand Total"},
        {"Subtotal", "{0} Subtotal"},

        {"No Suppression", "No Suppression"},
        {"Suppress NA Only", "Suppress NA Only"},
        {"Suppress Zero Only", "Suppress Zero Only"},
        {"Suppress NA and Zero", "Suppress NA and Zero"},
        {"UndoCount", "UndoCount"},

        /**
         * @error DVT-9006 cannot copy event: {0}
         * @cause An error occurred while trying to copy the specified event.
         * @action Invoke the <code>printStackTrace</code> method on the exception object to display the
         *         full error stack and to identify the root cause of the problem.
         * @status reviewed
         */
        {"Could not copy event: ", "DVT-9006 cannot copy event: {0}"},

        /**
         * @error DVT-9007 Measure argument must not be null in <code>initCubeQuery</code>.
         * @cause A null measure list was passed to the <code>initCubeQuery</code> method.
         * @action Pass in a valid list of measures to the <code>initCubeQuery</code> method.
         * @status reviewed
         */
        {"measure argument must not be null in initCubeQuery", "DVT-9007 Measure argument must not be null in initCubeQuery."},

        /**
         * @error DVT-9008 Dimensions and measure arguments must not both be null in <code>initQuery</code>.
         * @cause Arguments for dimensions and a measure list were both null when passed to the <code>initQuery</code> method.
         * @action Pass in a valid value for either one or both of these arguments when calling the <code>initQuery</code> method.
         * @status reviewed
         */
        {"dimensions and measures arguments must not both be null in initQuery", "DVT-9008 Dimensions and measures arguments must not both be null in initQuery."},

        /**
         * @error DVT-9011 Dimension is out of range in metadata cursor for edge and dimension.
         * @cause The specified dimension was out of range in the method that was called for the specified edge and dimension arguments.
         * @action Ensure that the dimension is valid when calling the method.
         * @status reviewed
         */
        {"Dimension out of range in metadata cursor for edge, dimension: ", "DVT-9011 Dimension is out of range in metadata cursor for edge and dimension: {0} and {1}."},

        {"Measures", "Measures"},
        {"DefaultColumnCount", "DefaultColumnCount"},
        {"DefaultRowCount", "DefaultRowCount"},

        /**
         * @error DVT-9013 cannot create new instance of <code>QueryManager</code> or subclass when cloning
         * @cause Application code could not call the constructor that takes a <code>QueryManagerObject</code> parameter when trying to
         *        clone an instance of <code>QueryManager</code> or a subclass of <code>QueryManager</code>.
         * @action If the actual object is a subclass of <code>QueryManager</code>, then examine the subclass constructors
         *  for failure in the code that extends <code>QueryManager</code>.
         * @status reviewed
         */
        {"Could not create new instance of DataSource or subclass when cloning", "DVT-9013 cannot create new instance of QueryManager or subclass when cloning"},

        /**
         * @error DVT-9016 cannot find property
         * @cause The persistent XML file was not compatible with this object.
         * @action Re-create the object.
         * @status reviewed
         */
        {"Could not find property", "DVT-9016 cannot find property"},

        /**
         * @error DVT-9017 cannot redo
         * @cause There were no more operations on the stack to redo.
         * @action No action is necessary.
         * @status reviewed
         */
        {"Could not redo", "DVT-9017 cannot redo"},

        /**
         * @error DVT-9032 The specified measure is invalid.
         * @cause A measure name was specified that cannot be found in the database.
         * @action Ensure that all named measures exist in the database.
         * @status reviewed
         */
        {"Invalid measure specified", "DVT-9032 The specified measure {0} is invalid."},

        /**
         * @error DVT-9036 cannot undo
         * @cause There were no more operations on the stack to undo.
         * @action No action is necessary.
         * @status reviewed
         */
        {"Could not undo", "DVT-9036 cannot undo"},

        /**
         * @error DVT-9042 MetadataManager cannot return the measure dimension.
         * @cause Invalid or corrupt metadata was found in the database.
         * @action Repair problems with or rebuild the database schema.
         * @status documented
         */
        {"Metadata Manager cannot return the measure dimension", "DVT-9042 MetadataManager cannot return the measure dimension."},

        /**
         * @error DVT-9044 illegal DataDirector type request
         * @cause A relational DataDirector was requested for a nontabular query.
         * @action Either call createCubeDataDirector, or set the QueryConstants.PROPERTY_TABULAR_QUERY property to true before requesting a relational data director.
         * @status New
         */
        {"Illegal DataDirector type requested.", "DVT-9044 illegal DataDirector type request"},
        
        /**
         * @error DVT-9511 illegal pivot operation
         * @cause Dimensions or locations were provided that would not result in a legal pivot operation.
         * @action Check the given arguments and reconcile them with the layout of the current query.
         * @status Documented
         */
        {"Illegal pivot operation", "DVT-9511 illegal pivot operation"},

        /**
         * @error DVT-9512 illegal swap operation
         * @cause Dimensions or locations were provided that would not result in a legal swap operation.
         * @action Check the given arguments and reconcile them with the layout of the current query.
         * @status Documented
         */
        {"Illegal swap operation", "DVT-9512 illegal swap operation"},

        /**
         * @error DVT-9513 illegal swap edges operation
         * @cause Edges were provided that would not result in a legal swap operation.
         * @action Check the given edges and reconcile them with the layout of the current query.
         * @status Documented
         */
        {"Illegal swapEdges operation", "DVT-9513 illegal swap edges operation"},

        /**
         * @error DVT-9515 No query is defined.
         * @cause A method was called that requires an existing query.
         * @action Create a query before calling the method.
         * @status Documented
         */
        {"No query defined", "DVT-9515 No query is defined."},
                
        /**
         * @error DVT-9532 The specified dimension or item is invalid: {0}.
         * @cause A dimension or item name was specified that cannot be found in the current database.
         * @action Ensure that all named dimensions or items are in the current database.
         * @status documented
         */        
        {"Invalid dimension specified", "DVT-9532 The specified dimension or item is invalid: {0}."},

    };

    /**
     * Retrieves the string resource table.
     *
     * @return the string resource table for the data source package.
     * @status protected
     */
    protected Object[][] getContents()
    {
        return resourceArray;
    }
}
