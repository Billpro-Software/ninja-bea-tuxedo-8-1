/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;
import javax.naming.NamingEnumeration;
import javax.naming.directory.SearchResult;

/**
 * Describes the impact of a cascade delete.  
 *
 * @status New
 */
public interface ImpactReport
{
    /**
     * Return the name of the initial object deleted.  
     * @return null if no inital object.  This can occur with 
     * a rebind operation where there is no object bound at the 
     * given name.  
     */
    SearchResult getInitialDeleted();
    
    /**
     * Return names of the objects deleted as a result of deleting the 
     * initial object.  The initial object is not included, thus if 
     * there are no cascade deletes the returned enumeration will be 
     * empty.  
     * @return NamingEnumeration<SearchResult>
     */
    NamingEnumeration getCascadeDeleted();
    
    
}