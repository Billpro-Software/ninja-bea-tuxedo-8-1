/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners that a cell submission event has occurred.
 * This event indicates that the QDR overrides in the writeback collection
 * have been submitted for update to the database.
 * If auto submission is set for cell editing, then each
 * <code>QDRoverride</code> is submitted to the database immediately after the
 * cell is edited.
 * If auto submission is not set for cell editing, then the
 * <code>QDRoverride</code> objects accumulate in the writeback collection until
 * changes are submitted explicitly to the database.
 *
 * @see  oracle.dss.util.DataAccess#isAutoSubmit
 * @see  oracle.dss.util.DataAccess#setAutoSubmit
 * @see  oracle.dss.util.DataAccess#submitChanges
 *
 * @status Documented
 */
public class CellsSubmittedEvent extends CellsSubmitEvent
{

/**
 * Constructor.
 *
 * @param source                The source of the event, that is, the object
 *                              that fired the event.
 * @param qdrOverrideCollection A writeback collection that contains a QDR
 *                              override for each cell that was edited.
 *
 * @status Documented
 */
    public CellsSubmittedEvent(Object source, java.util.List qdrOverrideCollection ) {
        super(source, qdrOverrideCollection);

    }

    protected void setSubmitSuccess(boolean success)
    {
      m_submitSuccess = success;
    }

    public boolean isSubmitSuccess()
    {
        return m_submitSuccess;
    }

    private boolean m_submitSuccess = true;
}