/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Component;

import java.util.Vector;

import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;


/**
 * Contains methods that common data-utility graphical user interface component  
 * objects require for instantiation, often in conjunction with <code>QueryBuilder</code> 
 * or <code>CalcBuilder</code>.
 *
 * @status documented
 */
public class DefaultComponentContext extends DefaultGuiContext  implements ComponentContext
    {
    /////////////////////
    //
    // Constants
    //
    /////////////////////

    /**
     * Default item count for popups
     *
     * @status private
     */
    static private final int CALCBUILDER_POPUPITEMDEFCOUNT = 10;

    /**
     * Default display label type
     *
     * @status private
     */
    static private final String DEFAULT_DISPLAY_LABEL_TYPE = LayerMetadataMap.LAYER_METADATA_LONGLABEL;
    
    /**
     * Default display member label type
     *
     * @status private
     */
    static private final String DEFAULT_DISPLAY_MEMBER_LABEL_TYPE = MetadataMap.METADATA_LONGLABEL;

    /////////////////////
    //
    // Members
    //
    /////////////////////

    /**
     * @hidden
     *
     * Display label type
     *
     * @status protected
     */
    protected String m_strDisplayLabelType = DEFAULT_DISPLAY_LABEL_TYPE;
    
    /**
     * @hidden
     *
     * Display member label type
     *
     * @status protected
     */
    protected String m_strDisplayMemberLabelType = DEFAULT_DISPLAY_MEMBER_LABEL_TYPE;

    /**
     * @hidden
     *
     * Measures for the context of the component.
     *
     * @status protected
     */
    protected Vector m_vMeasureContext = null;

    /**
     * @hidden
     *
     * Dimensions for the context of the component.
     *
     * @status protected
     */
    protected Vector m_vDimensionContext = null;

    /**
     * @hidden
     *
     * Count of items to be displayed in popup's in this CalcBuilder instance.
     *
     * @status protected
     */
    protected int m_nPopupItemCount = CALCBUILDER_POPUPITEMDEFCOUNT;

    /**
     * @hidden
     *
     * Component's parent.
     *
     * @status protected
     */
    protected Component m_componentParent = null;

    /////////////////////
    //
    // Constructor
    //
    /////////////////////

    /**
     * Constructor.
     *
     * @status Documented
     */
    public DefaultComponentContext ( )
        {
        }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    //-----------------------------------------------------------------------
    // Begin - Implementation of PanelContext interface.
    //-----------------------------------------------------------------------

    /**
     * Retrieves the type of display labels for this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @return   The display label type. Valid values are enumerations from
     *           the <code>LayerMetadataMap</code> such as long, short, or
     *           medium labels.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public String getDisplayLabelType ()
        {
        return m_strDisplayLabelType;
        }

   /**
     * Specifies the type of display labels for the dimensions that are
     * displayed in this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @param  strDisplayLabelType The display label type. Valid values are
     *                             enumerations from
     *                             <code>util.LayerMetadataMap</code> such as
     *                             long, short, or medium labels.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public void setDisplayLabelType (String strDisplayLabelType)
        {
        if ( (strDisplayLabelType == null) ||
             ( (!strDisplayLabelType.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL)) &&
               (!strDisplayLabelType.equals(LayerMetadataMap.LAYER_METADATA_NAME)) &&
               (!strDisplayLabelType.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL)) &&
               (!strDisplayLabelType.equals(LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL)) ) )
            {
            m_strDisplayLabelType = DEFAULT_DISPLAY_LABEL_TYPE;
            }
        else
            {
            m_strDisplayLabelType = strDisplayLabelType;
            } 
        }
        
   /**
     * Retrieves the type of display member labels for this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @return   The display member label type. Valid values are enumerations from
     *           the <code>LayerMetadataMap</code> such as long, short, or
     *           medium labels.
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public String getDisplayMemberLabelType ()
        {    
        return m_strDisplayMemberLabelType;
        }

    /**
     * Specifies the type of display member labels for the measures that are
     * displayed in this <code>CalcBuilder</code>
     * or <code>QueryBuilder</code> object.
     *
     * @param  strDisplayMemberLabelType The display label type. Valid values are
     *                                   enumerations from
     *                                   <code>util.MetadataMap</code> such as
     *                                   long, short, or medium labels.
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public void setDisplayMemberLabelType (String strDisplayMemberLabelType)
        {
        if ( (strDisplayMemberLabelType == null) ||
             ( (!strDisplayMemberLabelType.equals(MetadataMap.METADATA_LONGLABEL)) &&
               (!strDisplayMemberLabelType.equals(MetadataMap.METADATA_VALUE)) &&
               (!strDisplayMemberLabelType.equals(MetadataMap.METADATA_SHORTLABEL)) &&
               (!strDisplayMemberLabelType.equals(MetadataMap.METADATA_MEDIUMLABEL)) ) )
            {
            m_strDisplayMemberLabelType = DEFAULT_DISPLAY_MEMBER_LABEL_TYPE;
            }
        else
            {
            m_strDisplayMemberLabelType = strDisplayMemberLabelType;
            }
        }

    /**
     * Retrieves the list of measures that specify the context for
     * this <code>CalcBuilder</code> or <code>QueryBuilder</code> object.
     *
     * @return The list of measures that act as context for this
     *         <code>CalcBuilder</code> or <code>QueryBuilder</code> object.
     *
     * @status Documented
     */
    public Vector getMeasureContext ()
        {
        return m_vMeasureContext;
        }

    /**
     * Specifies the list of measures that act as the context
     * for this <code>CalcBuilder</code> or <code>QueryBuilder</code> object.
     *
     * @param vMeasureContext The list of measures that act as the context
     *       for this <code>CalcBuilder</code> or <code>QueryBuilder</code> object.
     *
     * @status Documented
     */
    public void setMeasureContext (Vector vMeasureContext)
        {
        m_vMeasureContext = vMeasureContext;
        }

    /**
     * Retrieves the item count of all popup instances in this
     * <code>CalcBuilder</code> or <code>QueryBuilder</code> object. 
     * For example, counts for CustomPane popup menus or Combo popup menus.
     *
     * @return The count of items in the popups.
     *
     * @status Documented
     */
    public int getPopupItemCount ()
        {
        return m_nPopupItemCount;
        }

    /**
     * Specifies the item count of all popup instances in this
     * <code>CalcBuilder</code> or <code>QueryBuilder</code> object. 
     * For example, counts for CustomPane popup menus or Combo popup menus.
     *
     * @param nCount The count of items in the popups.
     *
     * @status Documented
     */
    public void setPopupItemCount (int nCount)
        {
        if (nCount <= 0)
            {
            m_nPopupItemCount = CALCBUILDER_POPUPITEMDEFCOUNT;
            return;
            }

        m_nPopupItemCount = nCount;
        }

    /**
     * Retrieves the list of dimensions that specify the context for
     * this <code>Component</code> object.
     *
     * @return The list of dimensions that specify the context for this
     *         <code>Component</code> object.
     *
     * @status Documented
     */
    public Vector getDimensionContext ()
        {
        return m_vDimensionContext;
        }

    /**
     * Specifies the list of dimensions that specify the context
     * for this <code>Component</code> object.
     *
     * @param vMeasureContext The list of dimensions that specify the context
     *                           for this <code>Component</code> object.
     *
     * @status Documented
     */
    public void setDimensionContext (Vector vDimensionContext)
        {
        m_vDimensionContext = vDimensionContext;
        }

    /**
     * Retrieves the parent of this <code>Component</code> instance.
     *
     * @return The parent of this <code>Component</code> instance.
     *
     * @status documented
     */
    public Component getParent ()
        {
        return m_componentParent;
        }

    /**
     * Specifies the parent of this <code>Component</code> instance.
     *
     * @param component The parent of this <code>Component</code> instance.
     *
     * @status documented
     */
    public void setParent (Component component)
        {
        m_componentParent = component;
        }

    //-----------------------------------------------------------------------
    // End - Implentation of ComponentContext interface.
    //-----------------------------------------------------------------------

    }