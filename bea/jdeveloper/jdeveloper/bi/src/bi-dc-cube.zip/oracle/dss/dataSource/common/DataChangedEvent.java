/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

import oracle.dss.util.DataDirector;
import oracle.dss.util.DataAccess;

/**
 * Informs listeners when data, metadata, or both have changed (that is, when
 * one or more pending operations have been flushed from the queue and have
 * returned successfully).
 *
 * @status Documented
 */
public class DataChangedEvent extends DataChangeEvent implements CursorCarryingEvent
{
    /**
     * @hidden
     */
    protected DataDirectorImpl m_dd = null;
    
    /**
     * Constructor to use when the extent of the changes may be unknown and the
     * listener should assume that the entire cube has changed.
     *
     * @param source      The object that fired the event.
     * @param  changeType   A constant that indicates the type of operation that
     *                    changed the data. Valid constants are listed in the
     *                    See Also section.
     * @param cur         Reference to the new cursor object.
     *
     * @see oracle.dss.util.DataChangedEvent#DRILL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PAGE_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PIVOT_CHANGE
     * @see oracle.dss.util.DataChangedEvent#SEL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#UNKNOWN_CHANGE
     *
     * @status documented
     */
    public DataChangedEvent(Object source, int changeType, DataAccess cur) {
        super(source, true, changeType);
        
        edges = new BitSet(3);
        edges.set(DataDirector.ROW_EDGE);
        edges.set(DataDirector.COLUMN_EDGE);
        edges.set(DataDirector.PAGE_EDGE);
        dataAccess = cur;
    }
    
    /**
     * Constructor to use when the <code>Query</code> object knows something
     * about what changed.
     * 
     * @param source          The source of the event, that is, a reference to
     *                        the object that fired the event.
     * @param dataChanged     <code>true</code> if data has changed,
     *                        <code>false</code> if not.
     * @param metadataChanged Variable that lists the changed edge or edges of
     *                        the cursor. To create this variable, you can use
     *                        the constants <code>ROW_EDGE, COLUMN_EDGE,</code>
     *                        or <code>PAGE_EDGE</code>
     *                        in <code>oracle.dss.util.DataDirector</code>.
     * @param  changeType   A constant that indicates the type of operation that
     *                    changed the data. Valid constants are listed in the
     *                    See Also section.
     * @param  cur            Reference to the new cursor object.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataChangedEvent#DRILL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PAGE_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PIVOT_CHANGE
     * @see oracle.dss.util.DataChangedEvent#SEL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#UNKNOWN_CHANGE
     *
     * @status documented
     */
    public DataChangedEvent(Object source, boolean dataChanged, BitSet metadataChanged, int changeType, DataAccess cur) {
        super(source, dataChanged, changeType);
        
        edges = metadataChanged;
        dataAccess = cur;
    }    
    
    /**
     * @hidden
     * @param source
     * @param dataChanged
     * @param metadataChanged
     * @param changeType
     * @param cur
     */
    public DataChangedEvent(Object source, boolean dataChanged, BitSet metadataChanged, int changeType, DataAccess cur, DataDirectorImpl dd)
    {
        this(source, dataChanged, metadataChanged, changeType, cur);
        m_dd = dd;
    }
    
    /**
     * @hidden
     * @return
     */
    protected DataDirectorImpl getDataDirector()
    {
        return m_dd;
    }
    
    /**
     * Retrieves a set of flags that indicate which, if any, metadata cursors
     * (edges) changed.
     *
     * @return Set of flags that indicate the edges that changed.
     *
     * @status Documented
     */
    public BitSet getMetadataChanged() {
        return edges;
    }

    /**
     * @hidden
     * Set the cursor into the event.
     *
     * @param cur new cursor
     */
    public void setDataAccess(DataAccess cur) {
        dataAccess = cur;
    }
    
    /**
     * Retrieves a reference to the new <code>DataAccess</code> cursor.
     *
     * @return Reference to the new <code>DataAccess</code> cursor.
     *
     * @status Documented
     */
    public DataAccess getDataAccess() {
        return dataAccess;
    }

    /**
     * @hidden
     * Merge another event into this one.
     *
     * @param event change event to merge
     */
    public void merge(MergeEvent event) {
        DataChangedEvent dce = (DataChangedEvent)event;
        super.merge(dce);
        
        // Merge metadata flags
        edges.or(dce.edges);
    }
    
    /**
     * @hidden
     * @serial list of edges and whether they've changed
     */
    protected BitSet                edges;
    /**
     * @hidden
     * @serial cursor containing changed data
     */
    protected DataAccess  dataAccess;
}
