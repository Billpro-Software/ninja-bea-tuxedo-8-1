/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFilterPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.util.Vector;

import oracle.dss.connection.client.Connection;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.util.gui.component.list.JListMutable;


/**
 * <pre>
 * <code>DataFilterPanelModel</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   05/27/08 - 
 *    gkellam   08/21/07 - Fix Bug 6059474 - Add Data Filter doesn't pick up
 *                         the selected item in the list.
 *    gkellam   03/12/07 - Fix Bug 5766378 - QUERYBUILDER: ITEM DROP DOWN IN
 *                         NEW/EDIT DATA FILTER NOT WORKING.
 * 
 */
public class DataFilterPanelModel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @internal
   * 
   * <code>Connection</code> property.
   * 
   */
  public static String CONNECTION = "Connection";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext = null;
  private BaseDataFilter m_dataFilter = null;

  /////////////////////
  //
  // Construstors
  //
  /////////////////////

  public DataFilterPanelModel (ComponentContext context) {
    setContext (context);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public void setContext (ComponentContext context) {
    m_componentContext = context;
  }

  public ComponentContext getContext() {
    return m_componentContext;
  }

  /**
   * @internal
   * 
   * Associates the <code>Connection</code> used for retrieving data with the
   * current <code>ComponentContext</code>.
   * 
   * @see #getContext()
   * 
   */
  public void setConnection (Connection connection) {
    if (getContext() != null) {
      getContext().setProperty (CONNECTION, connection);
    }
  }

  /**
   * @internal
   * 
   * Retrieves the <code>Connection</code> used for retrieving data from the
   * current <code>ComponentContext</code>.
   * 
   * @see #getContext()
   * 
   */
  public Connection getConnection() {
    return getContext() != null ? (Connection) getContext().getProperty (CONNECTION) : null;
  }

  public Vector getItems() {
    return QBUtils.getSelectedMDItems (m_componentContext);
  }

  public void setDataFilter (BaseDataFilter dataFilter) {
    m_dataFilter = dataFilter;
  }

  public BaseDataFilter getDataFilter() {
    return m_dataFilter;
  }

  /**
   * Make a <code>BaseDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   * 
   * @return <code>BaseDataFilter</code>
   * 
   */
  public BaseDataFilter makeBaseDataFilter (String strItemID, int nCmpOperator) throws Exception {

    BaseDataFilter baseDataFilter = null;

    switch (nCmpOperator) {
      case TopBottomDataFilter.OP_BOTTOM:
      case TopBottomDataFilter.OP_TOP:
        baseDataFilter = makeTopBottomDataFilter (strItemID, nCmpOperator);
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        baseDataFilter = makeRangeDataFilter (strItemID, nCmpOperator);
        break;
      
      default:
        baseDataFilter = makeDataFilter (strItemID, nCmpOperator);
        break;
    }

    return baseDataFilter;
  }

  public BaseDataFilter makeBaseDataFilter (String strItemID) throws Exception {
    return makeBaseDataFilter (strItemID, DataFilter.OP_EQUAL);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Make a <code>TopBottomDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   */
  protected BaseDataFilter makeTopBottomDataFilter (String strItemID, int nCmpOperator) {

    TopBottomDataFilter topBottomDataFilter = new TopBottomDataFilter();
    topBottomDataFilter.setItem (strItemID);
    topBottomDataFilter.setOperator (nCmpOperator);

    return topBottomDataFilter;
  }

  /**
   * Make a <code>RangeDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   */
  protected BaseDataFilter makeRangeDataFilter (String strItemID, int nCmpOperator) {

    RangeDataFilter rangeDataFilter = new RangeDataFilter();
    rangeDataFilter.setItem (strItemID);
    rangeDataFilter.setOperator (nCmpOperator);

    return rangeDataFilter;
  }

  /**
   * Make a <code>DataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * @throws <code>Exception</code>
   * 
   */
  protected BaseDataFilter makeDataFilter (String strItemID, int nCmpOperator) throws Exception {

    DataFilter dataFilter = new DataFilter();
    dataFilter.setItem(strItemID);
    dataFilter.setCmpOperator (nCmpOperator);

    return dataFilter;
  }
}