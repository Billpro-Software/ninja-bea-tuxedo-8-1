/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValuePanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    gkellam     08/02/07 - Improve data error handling.
    bmoroze     02/13/07 - 
    jhyman      01/24/06 - remove checktreecombo dependency 
    jramanat    11/29/05 - Creation
 */

package oracle.dss.datautil.gui.component.parameter;

import java.awt.Color;
import java.awt.Component;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.ArrayList;
import java.util.Hashtable;

import java.util.Vector;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;

import javax.swing.tree.DefaultTreeModel;

import javax.swing.tree.TreeModel;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.util.parameters.Parameter;

import oracle.bali.ewt.graphics.ImageUtils;

import oracle.bali.ewt.text.MultiLineLabel;

import oracle.dss.queryBuilder.ItemItemsTreeNode;
import oracle.dss.selection.parameter.ItemValueParameter;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.comboBox.TreeListCombo;
import oracle.dss.util.gui.component.comboBox.TreeListComboModel;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValuePanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */
public class ParameterValuePanel extends JPanel {
  private static final String RESOURCE_BUNDLE = "oracle.dss.datautil.gui.component.parameter.resource.ParameterBundle";
  private ComponentContext m_context = null;
  private ParameterValuePanelModel m_model = null;
  private ParameterValueContainer m_shared = null;
  private ParameterValueContainer[] m_private = null;
  private DescriptionPanel m_description = null;
  private JPanel m_mainPanel = null;

  /**
   * Empty Constructor
   */
  public ParameterValuePanel() {    
  }
  
  /**
   * Constructor that takes a ComponentContext
   * 
   * @param context The ComponentContext
   */
  public ParameterValuePanel(ComponentContext context) {
    setComponentContext(context);
  }
  
  /**
   * Specifies the ComponentContext for this panel
   * 
   * @param context The ComponentContext
   */
  public void setComponentContext(ComponentContext context) {
    m_context = context;
  }
  
  /**
   * Retrieves the ComponentContext for this panel
   * 
   * @return The ComponentContext
   */
  public ComponentContext getComponentContext() {
    return m_context;
  }
  
  /**
   * Specifies the model for this panel
   * 
   * @param model The ParameterValuePanelModel
   */
  public void setModel(ParameterValuePanelModel model) {
    m_model = model;
  }
  
  /**
   * Retrieves the model for this panel
   * 
   * @return The ParameterValuePanelModel
   */
  public ParameterValuePanelModel getModel() {
    return m_model;
  }
  
  /**
   * Initializes the GUI based on the specified model
   */
  public void initialize() {
    GridBagLayout gbl = new GridBagLayout();
    setLayout(gbl);
    addComponent(this, new JLabel(getResourceString("ParameterPanel")), gbl, getLeftGridBagConstraints(true));
    addComponent(this, new JButton("Defaults"), gbl, getRightGridBagConstraints(false, false));

    Parameter[] shared = m_model.getSharedParameters();
    if (shared != null && shared.length > 0) {
      m_shared = new ParameterValueContainer(shared, m_model.getSharedLabel(), true, -1);
    }
    m_private = new ParameterValueContainer[m_model.getPrivateCount()];
    for (int i = 0; i < m_private.length; i++) {
      Parameter[] params = m_model.getPrivateParameters(i) ;
      if (params != null && params.length > 0) {
        m_private[i] = new ParameterValueContainer(params, m_model.getPrivateLabel(i), false, i);
      }
    }
    m_mainPanel = new JPanel(new GridBagLayout());
    m_mainPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
    if (m_shared != null) {
      m_shared.addUI();
    }
    for (int i = 0; i < m_private.length; i++) {
      if (m_private[i] != null) {
        m_private[i].addUI();
      }
    }
    addComponent(m_mainPanel, new JLabel(), (GridBagLayout)m_mainPanel.getLayout(), getSpacerGridBagConstraints());
    JScrollPane scroll = new JScrollPane(m_mainPanel);
    scroll.setPreferredSize(new Dimension(400, 150));
    addComponent(this, scroll, gbl, getRowGridBagConstraints());
    addComponent(this, new JLabel(getResourceString("DescriptionPanel")), gbl, getRowGridBagConstraints());
    m_description = new DescriptionPanel();
    addComponent(this, m_description, gbl, getRowGridBagConstraints());
  }

  private void addSectionHeader(String header) {
    JLabel label = new JLabel(header);
    label.setOpaque(true);
    label.setBackground(Color.LIGHT_GRAY);
    addComponent(m_mainPanel, label, (GridBagLayout)m_mainPanel.getLayout(), getRowGridBagConstraints());
  }

  private void addPrompt(String prompt) {
    addComponent(m_mainPanel, new JLabel(prompt), (GridBagLayout)m_mainPanel.getLayout(), getLeftGridBagConstraints(false));
  }

  private void addEditor(Component component, Parameter parameter) {
    addComponent(m_mainPanel, component, (GridBagLayout)m_mainPanel.getLayout(), getRightGridBagConstraints(true, true));
    if (component instanceof TreeListCombo) {
      TreeListCombo combo = (TreeListCombo)component;
      combo.getEditor().getEditorComponent().addMouseListener(new EditorListener(parameter));
    }
  }

  private static GridBagConstraints getLeftGridBagConstraints(boolean anchorWest) {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.ipadx = 10;
    gbc.weightx = 0.0;
    gbc.gridwidth = 1;
    gbc.fill = GridBagConstraints.NONE;
    gbc.anchor = anchorWest ? GridBagConstraints.WEST : GridBagConstraints.EAST;
    return gbc;
  }

  private static GridBagConstraints getRightGridBagConstraints(boolean anchorWest, boolean fill) {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.ipadx = 10;
    gbc.weightx = fill ? 1.0 : 0.0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.fill = fill ? GridBagConstraints.HORIZONTAL : GridBagConstraints.NONE;
    gbc.anchor = anchorWest ? GridBagConstraints.WEST : GridBagConstraints.EAST;
    return gbc;
  }

  private static GridBagConstraints getRowGridBagConstraints() {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.ipadx = 10;
    gbc.weightx = 1.0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.WEST;
    return gbc;
  }
  
  private static GridBagConstraints getSpacerGridBagConstraints() {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.gridheight = GridBagConstraints.REMAINDER;
    gbc.weightx = 1;
    gbc.weighty = 1;
    gbc.fill = GridBagConstraints.BOTH;
    return gbc;
  }

  /**
   * Adds a component to a Panel using GridBagLayout
   */
  private static void addComponent(JPanel panel, Component component, GridBagLayout gbl, GridBagConstraints gbc) {
    gbl.setConstraints(component, gbc);
    panel.add(component);
  }


  /**
   * Applies all specified values to the underlying model
   * 
   * @param refresh Indicates whether the model's apply() method should be
   * called to refresh any dependent objects.
   */
  public void apply(boolean refresh) {
    if (m_shared != null) {
      Parameter[] params = m_shared.getParameters();
      for (int i = 0; i < params.length; i++) {
        Object o = m_shared.getValue(i);
        getModel().setSharedValue(params[i], o);
      }
    }
    for (int i = 0; i < m_private.length; i++) {
      if (m_private[i] != null) {
        Parameter[] params = m_private[i].getParameters();
        for (int j = 0; j < params.length; j++) {
          Object o = m_private[i].getValue(j);
          getModel().setPrivateValue(i, params[j], o);
        }
      }
    }
    if (refresh) {
      getModel().apply();
    }
  }

  private class ParameterValueContainer {
    private Parameter[] m_parameters = null;
    private boolean m_bShared = false;
    private int m_index = -1;
    private String m_title = null;
    private Hashtable m_editors = null;

    public ParameterValueContainer(Parameter[] parameters, String title, boolean shared, int index) {
      m_parameters = parameters;      
      m_bShared = shared;
      m_index = index;
      m_title = title;
      m_editors = new Hashtable();
    }

    public void addUI() {
      addSectionHeader(m_title);
      for (int i = 0; i < m_parameters.length; i++) {
        String prompt = m_parameters[i].getPrompt();
        if (m_parameters[i].getProperty(Parameter.REQUIRED)) {
          prompt = "*" + prompt;
        }
        addPrompt(prompt);
        if (m_parameters[i] instanceof ItemValueParameter) {
          ItemValueParameter ivp = (ItemValueParameter)m_parameters[i];
          ComponentNode item = new ComponentNode(ivp.getItem(), ivp.getItem());
          TreeListCombo combo = new TreeListCombo();
          ItemItemsTreeNode root = new ItemItemsTreeNode(combo.getTree(), item, getComponentContext());
          root.setPageSize(500);
          final DefaultTreeModel treeModel = new DefaultTreeModel(root);
          TreeListComboModel model = new TreeListComboModel() {
            public TreeModel getTreeModel() {
              return treeModel;
            }
            
            public ListModel[] getListModels() {
              return null;
            }
            
            public boolean isMultiSelect() {
                return true;
            }
            
            public ArrayList getSelectFilters() {
                return null;
            }
            
          };
          combo.setModel(model);
          combo.getTree().setRootVisible(false);
          combo.setEditable(true);
          Vector values = m_bShared ? (Vector)m_model.getSharedValue(ivp) : (Vector)m_model.getPrivateValue(m_index, ivp);
          combo.setSelectedItem(DataUtils.formatMembers(values, null, /*ivp.getValueType(),*/ (String)ivp.getValidationContext(), getComponentContext().getLocale(), getComponentContext().getErrorHandler()));
          m_editors.put(ivp, combo);
          addEditor(combo, m_parameters[i]);
        }
      }
    }
    
    public Parameter[] getParameters() {
      return m_parameters;
    }
    
    public Object getValue(int index) {
      Vector vMembers = null;
      
      String members = null;
      Component component = (Component)m_editors.get(m_parameters[index]);
      
      if (component instanceof TreeListCombo) {
        TreeListCombo combo = (TreeListCombo)component;
        members = ((String)combo.getSelectedItem()).trim();        
      }
      
      if (members.equals ("")) {
        members = null;
      }
      
      try {
        vMembers = 
          DataUtils.parseMembersString (members, null, 
            (String)m_parameters[index].getValidationContext(), 
              m_context.getLocale(), m_context.getErrorHandler());
      }
      
      catch (Exception exception) {
        Logger.getLogger ("oracle.dss.datautil.gui.component.parameter.ParameterValuePanel").log (Level.INFO, 
          "getValue(int) failed", exception);
      }
    
      return vMembers;
    }
  }
  
  String getResourceString(String key) {
    if (m_context != null && m_context.getResourceHandler() != null) {
      return m_context.getResourceHandler().getResourceString(RESOURCE_BUNDLE, key);
    }
    return key;
  }
  
  private class DescriptionPanel extends JPanel {
    MultiLineLabel m_label = null;
    
    public DescriptionPanel() {
      FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
      setLayout(layout);
      setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
      m_label = new MultiLineLabel();
      m_label.setPreferredRows(4);
      add(m_label);
    }
    
    public void setDescription(String text) {
      m_label.setText(text);
    }    
  }
  
  private class EditorListener extends MouseAdapter {
    Parameter m_parameter = null;
    public EditorListener(Parameter parameter) {
      m_parameter = parameter;
    }
    
    public void mouseClicked(MouseEvent me) {
      m_description.setDescription(m_parameter.getDescription());
    }
  }
}