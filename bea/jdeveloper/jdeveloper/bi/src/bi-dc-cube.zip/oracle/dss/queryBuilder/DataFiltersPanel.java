/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFiltersPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractCellEditor;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JTree;
import javax.swing.border.Border;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeCellRenderer;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;

/**
 * <pre>
 * <code>DataFiltersPanel</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   05/11/07 - Tweaks for TopBottomDataFilter.
 * 
 */
public class DataFiltersPanel extends QueryBuilderPanel {

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private JTree m_jTreeDataFilters = null;
  private DataFiltersPanelModel m_dataFiltersPanelModel = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public DataFiltersPanel (ComponentContext componentContext) {
    super (componentContext);
    setLayout (new BorderLayout());
    add (makeDataFiltersPanel(), BorderLayout.CENTER);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public void setModel (DataFiltersPanelModel dataFiltersPanelModel) {
    m_dataFiltersPanelModel = dataFiltersPanelModel;
  }

  public DataFiltersPanelModel getModel() {
    return m_dataFiltersPanelModel;
  }

  public void refresh() {
    m_jTreeDataFilters.stopEditing();
    
    if (m_dataFiltersPanelModel != null) {
      m_dataFiltersPanelModel.refresh();
    }
  }

  /**
   * @hidden
   */
  public static void main (String[] strArguments) {
    QBUtils.makeFrame (new DataFiltersPanel (null));
  }

  private Component makeDataFiltersPanel() {
    m_jTreeDataFilters = new JTree();
    m_jTreeDataFilters.setRootVisible(false);
    
    m_dataFiltersPanelModel = new DataFiltersPanelModel(getContext());
    m_jTreeDataFilters.setModel (m_dataFiltersPanelModel);
    m_jTreeDataFilters.setCellRenderer (new DataFiltersRenderer());
    m_jTreeDataFilters.setCellEditor (new DataFiltersEditor());
    m_jTreeDataFilters.setEditable (true);
    m_jTreeDataFilters.setBorder (BorderFactory.createLineBorder(Color.GRAY));
    return m_jTreeDataFilters;
    
    //SelectionHeader sh = new SelectionHeader("Data Filters", m_jTreeDataFilters);
    //return sh;
  }

  /////////////////////
  //
  // Inner Classess
  //
  /////////////////////

  private class DataFiltersRenderer extends JCheckBox implements TreeCellRenderer {
    private final Border m_border = 
      BorderFactory.createLineBorder(Color.BLACK, 5);
    private final JList m_jList = new JList();
    private Object m_objValue = null;

    public Component getTreeCellRendererComponent (JTree tree, Object value, 
      boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
      m_objValue = value;
      BaseDataFilter dataFilter = getDataFilter();
      
      if (dataFilter != null) {
        if (dataFilter instanceof DataFilter) {
          setText (((DataFilter)dataFilter).getName());
        }
        setSelected (m_dataFiltersPanelModel.isSelected (dataFilter));
      }
      
      if (selected) {
        setBackground (m_jList.getSelectionBackground());
        setForeground (m_jList.getSelectionForeground());
      } 
      else {
        setBackground (m_jList.getBackground());
        setForeground (m_jList.getForeground());
      }
      
      setBorder(m_border);
      return this;
    }

    public Dimension getPreferredSize() {
      Dimension dimensionSize = super.getPreferredSize();
      Dimension dimensionTreeSize = m_jTreeDataFilters.getSize();
      if (dimensionTreeSize.width > 0) {
        return new Dimension (dimensionTreeSize.width, dimensionSize.height);
      }
      
      return dimensionSize;
    }

    public BaseDataFilter getDataFilter() {
      if (m_objValue != null) {
        if (m_objValue instanceof BaseDataFilter) {
          return (BaseDataFilter)m_objValue;
        } 
        else if (m_objValue instanceof DefaultMutableTreeNode) {
          return (BaseDataFilter)((DefaultMutableTreeNode)m_objValue).getUserObject();
        }
      }
      
      return null;
    }

    public Object getValue() {
      return m_objValue;
    }
  }

  private class DataFiltersEditor extends AbstractCellEditor implements TreeCellEditor {
    private DataFiltersRenderer m_renderer = null;

    public DataFiltersEditor() {
      m_renderer = new DataFiltersRenderer();
      m_renderer.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent ae) {
          m_dataFiltersPanelModel.setSelected (m_renderer.getDataFilter(), 
            m_renderer.isSelected());
        }
      });
    }

    public Component getTreeCellEditorComponent (JTree jTree, Object objValue, 
      boolean isSelected, boolean expanded, boolean bLeaf, int nRow) {
      return m_renderer.getTreeCellRendererComponent (jTree, objValue, true, false, 
        true, nRow, true);
    }

    public Object getCellEditorValue() {
      return m_renderer.getDataFilter();
    }
  }
}