/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/filter/MetadataFilter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.filter;

import java.io.Serializable;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.NamingException;

import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BICompositeFilter;
import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.BISearchResult;

// import oracle.dss.calculation.client.MDCalcAttributes;

import oracle.dss.dataSource.common.Query;

import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.HiddenFilter;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.MeasureDataTypeFilter;
import oracle.dss.datautil.query.SetUtils;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.provider.BIProvider;

import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDSearchControls;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.MetadataMap;

/**
 * <pre>
 * This base class allows metadata objects to be filtered from OLAP Business 
 * areas and BI Catalogs based on a wide range of filtering criteria. 
 * 
 * By default, its BIFilter evaluate method returns <code>true</code>.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/02/06 - Remove CalcBuilder and olap from JDEVADF.
 *    gkellam   01/16/06 - Tweak item handling. 
 *    gkellam   01/10/06 - Implement initial Custom Measure GUI round trip. 
 *    gkellam   12/15/05 - Add support for item joinability filter. 
 *    gkellam   11/20/05 - Implement item joinability. 
 *    gkellam   11/18/05 - Update FolderItemsTreeNode to use MetadataFilter. 
 */
public class MetadataFilter implements BIFilter, ErrorHandlerCallback, Serializable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * A <code>int</code> value used when the comparison between between the 
   * base and comparison dimensionality should be ignored.
   *
   * @status new
   */
  public final static int DIMENSIONALITY_IGNORE = SetUtils.COMPARE_IGNORE;

  /**
   * <pre>
   * A <code>int</code> value used when the relationship between the base and 
   * comparison dimensionality are disjoint.
   *
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison dimensionality are <strong>disjoint</strong>
   *   Base dimensionality         = {A, B}
   *   Comparison dimensionality   = {C, D}
   *   Intersecting dimensionality = {} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   *
   * @status new
   */
  public final static int DIMENSIONALITY_DISJOINT = SetUtils.COMPARE_DISJOINT;

  /**
   * <pre>
   * A <code>int</code> value used when the relationship between the base and 
   * comparison dimensionality represents an intersection.
   *
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison dimensionality represent an <strong>intersection</strong>
   *   Base dimensionality         = {A, B}
   *   Comparison dimensionality   = {B, C}
   *   Intersecting dimensionality = {B} 
   *
   * </pre>
   *
   * @status new
   */
  public final static int DIMENSIONALITY_INTERSECTION = SetUtils.COMPARE_INTERSECTION;

  /**
   * <pre>
   * A <code>int</code> value used when the base dimensionality is a subset of the 
   * comparison dimensionality.
   *
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base dimensionality is a <strong>subset</strong> of the Comparison dimensionality
   *   Base dimensionality         = {A, B}
   *   Comparison dimensionality   = {A, B, C}
   *   Intersecting dimensionality = {A, B} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int DIMENSIONALITY_SUBSET = SetUtils.COMPARE_SUBSET;

  /**
   * <pre>
   * A <code>int</code> value used when the Base and Comparison dimensionality are equal.
   *
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base dimensionality is a <strong>superset</strong> of the comparison dimensionality 
   *   Base dimensionality         = {A, B, C}
   *   Comparison dimensionality   = {A, B}
   *   Intersecting dimensionality = {A, B} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int DIMENSIONALITY_SUPERSET = SetUtils.COMPARE_SUPERSET;

  /**
   * <pre>
   * A <code>int</code> value used when the Base dimensionality is a superset of 
   * the Comparison dimensionality.
   *
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison dimensionality are <strong>equal</strong>
   *   Base dimensionality         = {A, B, C}
   *   Comparison dimensionality   = {A, B, C}
   *   Intersecting dimensionality = {A, B, C} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int DIMENSIONALITY_EQUAL = SetUtils.COMPARE_EQUAL;

  /**
   * A <code>int</code> value used when the comparison of the base and comparison 
   * dimensionality results in any type of intersection.
   *
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * 
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int DIMENSIONALITY_ANY_INTERSECTING = 
    DIMENSIONALITY_INTERSECTION | DIMENSIONALITY_EQUAL | 
      DIMENSIONALITY_SUBSET | DIMENSIONALITY_SUPERSET;

  /**
   * A <code>int</code> value used when the comparison of the base and comparison
   * dimensionality results in a set where the comparison filtering dimensionality 
   * is a subset or equal to the base dimensionality.
   *
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * 
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int DIMENSIONALITY_SUBSET_OR_EQUAL = 
    DIMENSIONALITY_SUBSET | DIMENSIONALITY_EQUAL;

  /**
   * @hidden
   * 
   * Property used to store the number of intersecting dimensions used to 
   * determine dimensional ranking.
   * 
   * This property can be specified as a <code>MDObject</code> IntPropertyValue
   * or as a <code>MetadataManagerSearchResultImpl Attribute</code>.
   * 
   * @status hidden
   */
  protected static String FILTER_DIMENSION_RANK = "FilterDimensionRank";

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * <code>ComponentContext</code> used to initialize the filter. 
   *
   * @status new
   */
  private ComponentContext m_componentContext = null;

  /**
   * @hidden
   * 
   * A list of base measures used to determine filtering dimensionality.
   *
   * @status hidden
   */
  private Vector m_vstrBaseMeasures = null;

  /**
   * @hidden
   * 
   * The dimension by which each <code>MDObject</code> must be dimensioned.
   * 
   * @status hidden
   */
  private String m_strDimension = null;

  /**
   * @hidden
   * 
   * A list of filtering dimensions.
   *
   * @status hidden
   */
  private Vector m_vstrDimensions = null;

  /**
   * @hidden
   * 
   * Determines whether hidden metadata is included.
   *
   * @status hidden
   */
  private boolean m_bHiddenFilter = true;

  /**
   * @hidden
   * 
   * Determines whether sort filter is used.
   *
   * @status hidden
   */
  private boolean m_bSortFilter = true;

  /**
   * @hidden
   * 
   * Determines whether short cuts are included.
   * 
   * @status hidden
   */
  private boolean m_bIncludeShortCuts = true;

  /**
   * @hidden
   * 
   * The intersection filter to use.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   *
   * @status hidden
   */
  private int m_nIntersectionFilter = DIMENSIONALITY_ANY_INTERSECTING;

  /**
   * @hidden
   * 
   * <code>MetadataManagerServices</code> used to retrieve metadata.
   * 
   * @status hidden
   */
  private MetadataManagerServices m_metadataManagerServices = null;
  
  /**
   * @hidden
   * 
   * The <code>ErrorHandler</code> used to process errors.
   *
   * @status hidden
   */
  private transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /**
   * @hidden
   * 
   * The <code>BasicAttributes</code> used to refine search based on the object 
   * types.
   *
   * @status hidden
   */
  private BasicAttributes m_basicAttributes = null;

  /**
   * @hidden
   * 
   * The <code>SearchControls</code> used to determine scope of search 
   * and what gets returned.
   *
   * @status hidden
   */
  private SearchControls m_searchControls = null;

  /**
   * @hidden
   * 
   * An array of folders whose contents should be included in dialogs such as 
   * the Measure List dialog.  
   * 
   * @see #getSearchPaths()
   * @see #setSearchPaths(String[])
   * 
   * @status hidden
   */
  private String[] m_strArraySearchPaths = null;

  /**
   * @hidden
   * 
   * An array of names used to rename folders that appear in dialogs such as the 
   * Measure List dialog. 
   * 
   * @see #getSearchPathNames()
   * @see #setSearchPathNames(String[])
   * 
   * @status hidden
   */
  private String[] m_strArraySearchPathNames = null;

  /**
   * @hidden
   * 
   * The maximum number of values to be returned as a result of the search.  
   * A -1 value indicates that there is no limits and all values will be returned.
   * 
   * @status hidden
   */ 
  private long m_lCountLimit = -1;

  /**
   * @hidden
   * 
   * The driver type to search.  A null signifies that all available driver 
   * types are searched.
   *
   * @see oracle.dss.metadataManager.common.MM#MDM
   * @see oracle.dss.metadataManager.common.MM#PERSISTENCE
   * @see #setDriverType(String)
   * 
   * @status hidden
   */
  private String m_strDriverType = null;

  /**
   * @hidden
   * 
   * An array of <code>MetadataManager</code> object types to include. 
   * 
   * @see oracle.dss.metadataManager.common.MM#DIMENSIONMEMBER_CALC
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC
   * @see oracle.dss.metadataManager.common.MM#MEASURE 
   * @see oracle.dss.metadataManager.common.MM#MEASURE_CALC 
   * 
   * @status hidden
   */
  private String[] m_strObjectTypes = null;

  /**
   * @hidden
   * 
   * Determines search scope. 
   * 
   * @see oracle.dss.bicontext.BISearchControls#SELECTIVE_ONELEVEL_SCOPE 
   * @see oracle.dss.bicontext.BISearchControls#ONELEVEL_SCOPE_WITH_FOLDERS 
   * @see oracle.dss.bicontext.BISearchControls#SUBTREE_SCOPE 
   * 
   * @status hidden
   */
  private int m_nSearchScope = BISearchControls.SUBTREE_SCOPE;

  /**
   * @hidden
   * 
   * Root folder where search should start. 
   * 
   * @status hidden
   */
  private BIContext m_biContextRoot = null;

  /**
   * @hidden
   * 
   * Query used to retrieve dimensions and items used to filter metadata by.
   * 
   * @status hidden
   */
  private Query m_query = null;

  /**
   * @hidden
   * 
   * The data types that should be used to determine to determine measure 
   * compatability.  If this value is null, all data types will be included.
   * 
   * @status hidden
   */ 
  private String[] m_strDataTypes = null;

  /**
   * @hidden
   * 
   * Determines whether folders are filtered out of search results.
   *
   * @status hidden
   */
  private boolean m_bFolderFilter = true;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>MetadataFilter</code> constructor.
   *
   * @param componentContext A <code>ComponentContext</code> value used to 
   *        initialize the filter.
   *
   * @status New
   */
  public MetadataFilter (ComponentContext componentContext) {
    setComponentContext (componentContext);
  }

  /**
   * <code>MetadataFilter</code> constructor.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   *
   * @status New
   */
  public MetadataFilter (MetadataManagerServices metadataManagerServices) {
    setMetadataManagerServices (metadataManagerServices);
  }

  /**
   * <code>MetadataFilter</code> constructor that specifies the dimension to 
   * use for filtering.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param strDimension A <code>String</code> value that is used to filter metadata by.
   *
   * @status New
   */
  public MetadataFilter (MetadataManagerServices metadataManagerServices, String strDimension) {
    setMetadataManagerServices (metadataManagerServices);
    setDimension (strDimension);
  }
  
  /**
   * <code>MetadataFilter</code> constructor that specifies the dimensions to 
   * use for filtering.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param vstrDimensions A <code>Vector</code> of <code>String</code> values
   *        that are used to filter metadata by.
   *
   * @status New
   */
  public MetadataFilter (MetadataManagerServices metadataManagerServices, Vector vstrDimensions) {
    setMetadataManagerServices (metadataManagerServices);
    setDimensions (vstrDimensions);
  }

  /**
   * <code>MetadataFilter</code> constructor that specifies the <code>Query</code> 
   * that will be used to determine the dimensions to use for filtering.  The 
   * dimensions are determined by combining the dimensionality of each base 
   * measure contained in the <code>Query</code> object.
   *
   * @param query A <code>Query</code> used to filter measures by.
   *
   * @status New
   */
  public MetadataFilter (Query query) {
    setQuery (query);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies a <code>ComponentContext</code> used to initialize the filter. 
   *
   * @param componentContext A <code>ComponentContext</code> value used to 
   *        initialize the filter.
   *
   * @status new
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;
  }

  /**
   * Retrieves a <code>ComponentContext</code> used to initialize the filter. 
   *
   * @return A <code>ComponentContext</code> value used to initialize the filter.
   *
   * @status new
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }
  
  /**
   * Specifies the measures that will be used to determine filtering dimensionality.
   *
   * @param vstrBaseMeasures A <code>Vector</code> of <code>MetadataManager</code>
   *        measure runtime IDs.
   *
   * @status new
   */
  public void setBaseMeasures (Vector vstrBaseMeasures) {
    m_vstrBaseMeasures = vstrBaseMeasures;
  }

  /**
   * Retrieves the measures that will be used to determine filtering dimensionality.
   * 
   * This method first attempts to retrieve any measures which were previously
   * specified.  If none were found, it attempts to retreive the measures from 
   * the query.
   *
   * @return A <code>Vector</code> of <code>MetadataManager</code> measures 
   *         runtime IDs.
   *
   * @see #setQuery(Query)
   * @see #setBaseMeasures(Vector)
   *
   * @status new
   */
  public Vector getBaseMeasures() {
    Vector vstrMeasures = null;
    
    // Check to see if the user has already chosen specific dimensions
    if (m_vstrBaseMeasures != null) {
      vstrMeasures = m_vstrBaseMeasures;     
    }
    else {
      // Attempt to retrieve the dimensions from the query
      if (getQuery() != null) {
        vstrMeasures = DataUtils.getMeasures (getQuery());
      }
    }
  
    return vstrMeasures;
  }

  /**
   * Specifies the <code>BasicAttributess</code> used to refine search based 
   * on the object types.
   *
   * @param basicAttributes A <code>BasicAttributes</code> value used to refine 
   *        search based on the object type.
   *
   * @status new
   */
  public void setBasicAttributes (BasicAttributes basicAttributes) {
    m_basicAttributes = basicAttributes;
  }

  /**
   * Retrieves the <code>BasicAttributess</code> used to refine search based 
   * on the object types.
   *
   * @return A <code>BasicAttributes</code> values used to refine search based 
   *         on the object type.
   *
   * @status new
   */
  public BasicAttributes getBasicAttributes() {
    BasicAttributes basicAttributes = null;
    
    if (m_basicAttributes != null) {
      basicAttributes = m_basicAttributes;
    }
    else {
      basicAttributes = 
        getBasicAttributes (getObjectTypes(), isSortFilterUsed());
    }
 
    return basicAttributes;
  }

  /**
   * Retrieves the <code>BasicAttributes</code> used to refine search 
   * based on the object types.
   *
   * @param strObjectTypes A <code>String</code> array of object types to include.
   * @param bSort A <code>boolean </code> which is <code>true</code> when the 
   *        results should be sorted and <code>false</code> otherwise.
   *
   * @return <code>BasicAttributes</code> value which contains the values used 
   *         to refine search based on the object type.
   *          
   * @see oracle.dss.metadataManager.common.MM#COMPLEX_ITEMFOLDER 
   * @see oracle.dss.metadataManager.common.MM#DIMENSION 
   * @see oracle.dss.metadataManager.common.MM#DIMENSIONMEMBER_CALC 
   * @see oracle.dss.metadataManager.common.MM#ITEMFOLDER 
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC 
   * @see oracle.dss.metadataManager.common.MM#MEASURE 
   * @see oracle.dss.metadataManager.common.MM#MEASURE_CALC 
   * @see oracle.dss.metadataManager.common.MM#ITEMFOLDER 
   * @see oracle.dss.metadataManager.common.MM#SQL_ITEMFOLDER 
   * @see oracle.dss.metadataManager.common.MM#TABLE_ITEMFOLDER 
   * 
   * @status new
   */
  public static BasicAttributes getBasicAttributes (String[] strObjectTypes, boolean bSort) {
    // Determine object types to include
    BasicAttributes basicAttributes = null;
    BasicAttribute basicAttributeTypes = null;
    
    String strObjectType = null;
    
    if (strObjectTypes != null) {
      for (int nIndex = 0; nIndex < strObjectTypes.length; nIndex++) {
        strObjectType = strObjectTypes [nIndex];

        if (strObjectType != null) {
          if (nIndex == 0) {
            basicAttributes = new BasicAttributes();
            basicAttributeTypes = new BasicAttribute (MM.OBJECT_TYPE, strObjectType);
          }
          else {
            basicAttributeTypes.add (strObjectType);
          }
        }
      }

      if ((basicAttributes != null) && (basicAttributeTypes != null)) {
        basicAttributes.put (basicAttributeTypes);
      }

      // Determine sort criteria
      if ((basicAttributes != null) && bSort) {
        basicAttributes.put (MM.SORT, Boolean.valueOf (true));
      }
    }

    return basicAttributes;
  }

  /**
   * Specifies the <code>SearchControls</code> used to determine scope of search 
   * and what gets returned.
   *
   * @param searchControls A <code>SearchControls</code> value used to determine 
   *        scope of search and what gets returned.
   *
   * @status new
   */
  public void setSearchControls (SearchControls searchControls) {
    m_searchControls = searchControls;
  }

  /**
   * Retrieves the <code>SearchControls</code> used to determine scope of search 
   * and what gets returned.
   *
   * @return A <code>SearchControls</code> value used to determine scope of search 
   * and what gets returned.
   *
   * @status new
   */
  public SearchControls getSearchControls() {
    SearchControls searchControls = null;
    
    if (m_searchControls != null) {
      searchControls = m_searchControls;
    }
    else {
      searchControls = getSearchControls (getSearchScope(), 
        getDriverType(), getDataTypes(), isHiddenFilterUsed(), isIncludeShortCuts(), 
          getSearchPaths(), getSearchPathNames(), this, getCountLimit());
    }
    
    return searchControls;  
  }

  /**
   * Specifies an array of <code>MetadataManager</code> object types to include. 
   *
   * @param strObjectTypes A <code>String</code> array of object types to 
   *        include.
   *
   * @see oracle.dss.metadataManager.common.MM#DIMENSION 
   * @see oracle.dss.metadataManager.common.MM#DIMENSIONMEMBER_CALC 
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC 
   * @see oracle.dss.metadataManager.common.MM#MEASURE 
   * @see oracle.dss.metadataManager.common.MM#MEASURE_CALC 
   *
   * @status new
   */
  public void setObjectTypes (String[] strObjectTypes) {
    m_strObjectTypes = strObjectTypes;
  }

  /**
   * Retrieves an array of <code>MetadataManager</code> object types to include. 
   *
   * @return A <code>String</code> array of object types to include.
   *
   * @see oracle.dss.metadataManager.common.MM#DIMENSION 
   * @see oracle.dss.metadataManager.common.MM#DIMENSIONMEMBER_CALC 
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC 
   * @see oracle.dss.metadataManager.common.MM#MEASURE 
   * @see oracle.dss.metadataManager.common.MM#MEASURE_CALC 
   * 
   * @status new
   */
  public String[] getObjectTypes() {
    return m_strObjectTypes;
  }

  /**
   * <pre>
   * Specifies an array of folders whose contents should be included in  
   * dialogs such as the Measure List dialog.  
   * 
   * If this value is not specified, the contents of all default folders 
   * are included.
   * 
   * Note: By default, only the contents of the folder are displayed.  
   *       To display the folder itself, a name must be associated with it 
   *       using the <code>setItemSearchPathNames</code> method.
   * 
   * See the "Customizing the Display of Folders" topic in the Help system for 
   * more information and examples.
   * </pre>
   *
   * @param strArrayPaths A <code>String</code> array of folder names.
   *
   * @see #getSearchPaths()
   * @see #setSearchPathNames(String[])
   *
   * @status new
   */
  public void setSearchPaths (String[] strArrayPaths) {
    m_strArraySearchPaths = strArrayPaths;
  }

  /**
   * Retrieves an array of folders whose contents should be included in  
   * dialogs such as the Measure List dialog.  
   *
   * @return A string array of folder names.
   *
   * @see #setSearchPaths(String[])
   * 
   * @status new
   */
  public String[] getSearchPaths() {
    return m_strArraySearchPaths;
  }

  /**
   * <pre>
   * Specifies the array of names used to rename folders that appear in 
   * dialogs used by the CalcBuilder such as the Measure List dialog. 
   * 
   * If a name is not associated with the folder specified in the  
   * <code>setItemSearchPaths</code> method, the folder is not displayed. 
   *
   * See the "Customizing the Display of Folders in CalcBuilder" topic in the
   * Help system for more information and examples.     
   * </pre>
   *
   * @param strArrayPathNames A <code>string</code> array of folder names.
   * 
   * @see #getSearchPathNames()
   * @see #setSearchPaths(String[])
   *
   * @status new
   */
  public void setSearchPathNames (String[] strArrayPathNames) {
    m_strArraySearchPathNames = strArrayPathNames;
  }

  /**
   * Retrieves the array of names used to rename folders that appear in 
   * dialogs such as the Measure List dialog used by the CalcBuilder.
   *
   * @return A string array of folder names.
   *
   * @status new
   */
  public String[] getSearchPathNames() {
    return m_strArraySearchPathNames;
  }

  /**
   * Specifies the maximum number of values to be returned as a result of the search.  
   * A -1 value indicates that there is no limits and all values will be returned.
   * 
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned.
   * 
   * @see #getCountLimit
   * 
   * @status new
   */
  public void setCountLimit (long lCountLimit) {
    m_lCountLimit = lCountLimit;  
  }

  /**
   * Retrieves the maximum number of values to be returned as a result of the search.  
   * A -1 value indicates that there is no limits and all values will be returned.
   * 
   * @return <code>long</code> which specifies the maximum number of 
   *        values that will be returned.
   * 
   * @see #setCountLimit(long)
   * 
   * @status new
   */
  public long getCountLimit () {
    return m_lCountLimit;  
  }

  /**
   * Specifies the search scope.
   * 
   * @param nSearchScope A <code>int</code> which specifies the search scope.
   * 
   * @see oracle.dss.bicontext.BISearchControls#SELECTIVE_ONELEVEL_SCOPE 
   * @see oracle.dss.bicontext.BISearchControls#ONELEVEL_SCOPE_WITH_FOLDERS 
   * @see oracle.dss.bicontext.BISearchControls#SUBTREE_SCOPE
   * 
   * @status new
   */
  public void setSearchScope (int nSearchScope) {
    m_nSearchScope = nSearchScope;  
  }

  /**
   * Retrieves the search scope.
   * 
   * @return <code>int</code> which represents the search scope.
   * 
   * @see oracle.dss.bicontext.BISearchControls#SELECTIVE_ONELEVEL_SCOPE 
   * @see oracle.dss.bicontext.BISearchControls#ONELEVEL_SCOPE_WITH_FOLDERS 
   * 
   * @status new
   */
  public int getSearchScope() {
    return m_nSearchScope;  
  }

  /**
   * Specifies the <code>Query</code> used to filter <code>MDObject</code> 
   * and <code>SearchResult</code> values by.
   *
   * Generally speaking, a object will only be included if its 
   * dimensionality intersects that of the measures specified in the Query.
   *
   * @param query A <code>Query</code> used to filter <code>MDObject</code> 
   *        values by.
   *
   * @see #setBaseMeasures(Vector)
   * 
   * @status new
   */
  public void setQuery (Query query) {
    m_query = query;
  }

  /**
   * Retrieves the <code>Query</code> used to filter <code>MDObject</code> 
   * and <code>SearchResult</code> values by.
   *
   * @return A <code>Query</code> used to filter measures by.
   *
   * @status new
   */
  public Query getQuery() {
    return m_query;
  }

  /**
   * Specifies the dimension by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be dimensioned by.
   *
   * @param strDimension A <code>String</code> which represents the 
   *        <code>MetadataManager</code> dimension runtime ID.
   *
   * @status new
   */
  public void setDimension (String strDimension) {
    m_strDimension = strDimension;
  }

  /**
   * Retrieves the dimension by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be dimensioned by.
   *
   * @return A <code>String</code> which represents the <code>MetadataManager</code> d
   *         dimension runtime ID.
   *
   * @status new
   */
  public String getDimension() {
    return m_strDimension;
  }

  /**
   * Specifies the filtering dimensions to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   *
   * @param vstrDimensions A <code>Vector</code> of <code>MetadataManager</code>
   *        dimension runtime IDs.
   *
   * @status new
   */
  public void setDimensions (Vector vstrDimensions) {
    m_vstrDimensions = vstrDimensions;
  }

  /**
   * Retrieves the filtering dimensions to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   * 
   * This method first attempts to retrieve any dimensions which were previously
   * specified.  If none were found, it attempts to retreive the dimensions
   * from measures specified in the query.
   *
   * @return A <code>Vector</code> of <code>MetadataManager</code> dimension 
   *         runtime IDs.
   *
   * @status new
   */
  public Vector getDimensions() {
    Vector vstrDimensions = null;
    
    // Check to see if the user has already chosen specific dimensions
    if (m_vstrDimensions != null) {
      vstrDimensions = m_vstrDimensions;     
    }
    else {
      // Attempt to retrieve the dimensions from the query
      if (getQuery() != null) {
        vstrDimensions = DataUtils.getDimensions (getQuery());
      }
    }

    return vstrDimensions;
  }

  /**
   * Specifies the <code>MetadataManagerServices</code> object used to retrieve
   * metadata.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object.
   *
   * @status new
   */
  public void setMetadataManagerServices (MetadataManagerServices metadataManagerServices) {
    m_metadataManagerServices = metadataManagerServices;
  }

  /**
   * Retrieves the <code>MetadataManagerServices</code> object used to retrieve
   * metadata.
   *
   * This method first attempts to retrieve any <code>MetadataManagerServices</code>
   * value that was previously specified.  If none were found, it attempts to 
   * retreive the value from the query.
   *
   * @return The <code>MetadataManagerServices</code> object.
   *
   * @status new
   */
  public MetadataManagerServices getMetadataManagerServices() {
    MetadataManagerServices metadataManagerServices = null;
    
    // Check to see if a MetadataManager has been directly specified
    if (m_metadataManagerServices != null) {
      metadataManagerServices = m_metadataManagerServices;     
    }
    else {
      // Attempt to retrieve the MetadataManager from the query
      if (getQuery() != null) {
        metadataManagerServices = getQuery().getMetadataManager();
      }
      else {
        metadataManagerServices = 
          getMetadataManagerServices (getComponentContext());        
      }
    }
  
    return metadataManagerServices;
  }

  /**
   * Specifies the driver type to search.  
   *
   * @param strDriverType A <code>String</code> which represents the driver 
   *        type to search.  A null signifies that all available driver types
   *        are searched.
   *
   * @see oracle.dss.metadataManager.common.MM#MDM
   * @see oracle.dss.metadataManager.common.MM#PERSISTENCE
   * @see #getDriverType()
   * 
   * @status new
   */
  public void setDriverType (String strDriverType) {
    m_strDriverType = strDriverType;
  }

  /**
   * Retrieves the driver type to search.  
   *
   * @return A <code>String</code> which represents the driver type.
   *
   * @see #setDriverType(String)
   * 
   * @status new
   */
  public String getDriverType() {
    return m_strDriverType;
  }

  /**
   * Specifies whether the hidden metadata should be included in the search
   * result.
   *
   * @param bHiddenFilter A <code>boolean</code> value that is <code>true</code>
   *        when hidden metadata should be not be included and <code>false</code>
   *        otherwise.
   *
   * @status New
   */
  public void setHiddenFilter (boolean bHiddenFilter) {
    m_bHiddenFilter = bHiddenFilter;
  }

  /**
   * Determines whether the hidden metadata should be included in the search
   * result.
   *
   * @return <code>boolean</code> which is <code>true</code> when hidden metadata 
   *         should be not be included and <code>false</code> otherwise.
   *
   * @status New
   */
  public boolean isHiddenFilterUsed() {
    return m_bHiddenFilter;
  }

  /**
   * Specifies whether the search results should be sorted.
   *
   * @param bSortFilter A <code>boolean</code> value that is <code>true</code>
   *        when the search results should be sorted and <code>false</code>
   *        otherwise.
   *
   * @status New
   */
  public void setSortFilter (boolean bSortFilter) {
    m_bSortFilter = bSortFilter;
  }

  /**
   * Determines whether the search results should be sorted.
   *
   * @return <code>boolean</code> value that is <code>true</code>
   *        when the search results should be sorted and <code>false</code>
   *        otherwise.
   *
   * @status New
   */
  public boolean isSortFilterUsed() {
    return m_bSortFilter;
  }

  /**
   * Specifies whether folders are excluded from the search results.
   *
   * @param bFolderFilter A <code>boolean</code> value that is <code>true</code>
   *        when the folders are excluded from the search results and 
   *        <code>false</code> otherwise.
   *
   * @status New
   */
  public void setFolderFilter (boolean bFolderFilter) {
    m_bFolderFilter = bFolderFilter;
  }

  /**
   * Determins whether folders are excluded from the search results.
   *
   * @return <code>boolean</code> value that is <code>true</code>
   *        when the folders are excluded from the search results and 
   *        <code>false</code> otherwise.
   *
   * @status New
   */
  public boolean isFolderFilterUsed() {
    return m_bFolderFilter;
  }

  /**
   * Specifies whether the search results should include shortcuts.
   *
   * @param bIncludeShortCuts A <code>boolean</code> value that is <code>true</code>
   *        when the results should include shortcuts and <code>false</code> otherwise.
   *
   * @status New
   */
  public void setIncludeShortCuts (boolean bIncludeShortCuts) {
    m_bIncludeShortCuts = bIncludeShortCuts;
  }

  /**
   * Determines whether the search results should include shortcuts.
   *
   * @return <code>boolean</code> value that is <code>true</code>
   *         when the results should include shortcuts and <code>false</code> 
   *         otherwise.
   *
   * @status New
   */
  public boolean isIncludeShortCuts() {
    return m_bIncludeShortCuts;
  }

  /**
   * Specifies the intersection filter used when comparing dimensionality.
   *
   * <pre>
   * The <code>DIMENSIONALITY_DISJOINT</code>, <code>DIMENSIONALITY_INTERSECTION</code>,
   * <code>DIMENSIONALITY_EQUAL</code>, <code>DIMENSIONALITY_SUBSET</code> and
   * <code>DIMENSIONALITY_SUPERSET</code> values represent bitmask values that
   * may be combined together to apply multiple intersection filters at one time.
   * 
   * Example:
   *   setIntersectionFilter (DIMENSIONALITY_SUBSET | DIMENSIONALITY_EQUAL);
   * 
   * </pre>
   *
   * @param nIntersectionFilter A <code>int</code> value that specifies the
   *        type of intersection that the search should use.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   *
   * @status New
   */
  public void setIntersectionFilter (int nIntersectionFilter) {
    m_nIntersectionFilter = nIntersectionFilter;
  }

  /**
   * Determines the intersection filter used when comparing dimensionality.
   *
   * @return <code>int</code> value that represents the intersection filter used.
   *
   * @see #DIMENSIONALITY_IGNORE
   * @see #DIMENSIONALITY_DISJOINT
   * @see #DIMENSIONALITY_INTERSECTION 
   * @see #DIMENSIONALITY_EQUAL
   * @see #DIMENSIONALITY_SUBSET
   * @see #DIMENSIONALITY_SUPERSET
   * @see #DIMENSIONALITY_ANY_INTERSECTING
   * @see #DIMENSIONALITY_SUBSET_OR_EQUAL
   * 
   * @status New
   */
  public int getIntersectionFilter() {
    return m_nIntersectionFilter;
  }

  /**
   * Specifies the <code>MDFolder</code> root folder path where search should start. 
   *
   * @param strFolderRootPath A <code>String</code> which represents the 
   *        root folder where search should start.
   *
   * @throws NamingException If the folder cannot be found.
   * 
   * @status new
   */
  public void setFolderRootPath (String strFolderRootPath) throws NamingException {
    setFolderRoot (getMDFolder (strFolderRootPath));
  }

  /**
   * Retrieves the root folder path where search should start.
   *
   * @return <code>String</code> which represents the root folder path where 
   *         search should start or null if the root is not a <code>MDFolder</code>.
   *
   * @status new
   */
  public String getFolderRootPath() {
    String strFolderRootPath = null;
    
    BIContext biContextRoot = getFolderRoot();
    
    if ((biContextRoot != null) && (biContextRoot instanceof MDFolder)) {
      strFolderRootPath = ((MDFolder)biContextRoot).getPath();
    }
  
    return strFolderRootPath;
  }

  /**
   * Specifies the root folder where search should start.  
   * For example, a <code>MDFolder</code>. 
   *
   * @param biContextRoot A <code>BIContext</code> which represents the 
   *        root folder where search should start.
   *
   * @status new
   */
  public void setFolderRoot (BIContext biContextRoot) {
    m_biContextRoot = biContextRoot;
  }

  /**
   * Retrieves the root folder where search should start. 
   * For example, a <code>MDFolder</code>. 
   * 
   * @return <code>BIContext</code> which represents the root folder where search 
   *         should start.
   *
   * @status new
   */
  public BIContext getFolderRoot() {
    BIContext biContextRoot = null;
    
    if (m_biContextRoot != null) {
      biContextRoot = m_biContextRoot;   
    }
    else {
      // Attempt to retrieve the default root from MetadataMananager
      if (getMetadataManagerServices() != null) {
        biContextRoot = getMetadataManagerServices().getMDRoot();
      }
    }
    
    return biContextRoot;
  }

  /**
   * Specifies the data types that should be used to determine to determine 
   * measure compatability.  If this value is null, all data types will be 
   * included.
   *
   * @param strDataTypes A <code>String[]</code> value used to specify the data 
   *        types that should be used to determine measure compatability.
   *
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#STRING
   * 
   * @status new
   */
  public void setDataTypes (String[] strDataTypes) {
    m_strDataTypes = strDataTypes;
  }

  /**
   * Retrieves the data type thats should be used to determine to determine 
   * measure compatability.  If this value is null, all data types will be 
   * included.
   *
   * @param <code>String[]</code> value used to specify the data types 
   *        that should be used to determine measure compatability.
   *
   * @status new
   */
  public String[] getDataTypes() {
    return m_strDataTypes;
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome.
   *
   * @param strID A <code>String</code> which represents the ID of the object 
   *        to process to determine if it should be included in the result.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the object
   *         should be included and <code>false</code> otherwise.
   *         
   * @status New
   */
  public BISearchResult getSearchResult (String strID) {
    BISearchResult biSearchResult = null;
    
    if (strID != null) {
      try {
        // Retrieve the MDObject associated with the ID
        MDObject mdObject = 
          (MDObject) getMetadataManagerServices().getMDObjectByUniqueID (strID);
    
        biSearchResult = getSearchResult (mdObject);
      }
      
      catch (MetadataManagerException metadataManagerException) {
        if (getErrorHandler() != null) {
          getErrorHandler().log (metadataManagerException.toString(), 
            getClass().getName(), "getSearchResult(String)");
        }   
      }
    }
    
    return biSearchResult;
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome.
   *
   * @param strID A <code>String</code> which represents the ID of the object 
   *        to process to determine if it should be included in the result.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the object
   *         should be included and <code>false</code> otherwise.
   *         
   * @status New
   */
  public boolean evaluate (String strID) {
    boolean bInclude = true;
    
    if (strID != null) {
      try {
        // Retrieve the MDObject associated with the ID
        MDObject mdObject = 
          (MDObject) getMetadataManagerServices().getMDObjectByUniqueID (strID);
    
        bInclude = evaluate (getSearchResult (mdObject));
      }
      
      catch (MetadataManagerException metadataManagerException) {
        if (getErrorHandler() != null) {
          getErrorHandler().log (metadataManagerException.toString(), 
            getClass().getName(), "evaluate(String)");
        }   
      }
    }
    
    return bInclude;
  }

  /**
   * <pre>
   * Determines whether the particular search result should be included in the
   * final search outcome.
   *
   * Note: This default implementation includes all objects.
   * </pre>
   * 
   * @param biSearchResult A <code>BISearchResult</code> to process to determine
   *        if it should be included in the result.
   *                       
   * @return <code>boolean</code> which is <code>true</code> if the search result
   *         should be included and <code>false</code> otherwise.
   *         
   * @status New
   */
  public boolean evaluate (BISearchResult biSearchResult) {

    boolean bInclude = true;

    // Check for null search results
    if (biSearchResult == null)
      return false;

    return bInclude;
  }

  /**
   * Retrieves a list of <code>SearchResult</code> values based on the chosen 
   * <code>MetadataFilter</code> filtering options and specified list of
   * <code>MetadataManager</code> unique IDs.
   *
   * @param vstrUniqueIDs A <code>Vector</code> of <code>String</code> values
   *        that represents the <code>MetadataManager</code> unique IDs.
   *
   * @return <code>Vector</code> representing the list of associated
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>SearchResult</code> values cannot be retrieved.
   * 
   * @status new
   */
  
  public Vector getSearchResults (Vector vstrUniqueIDs) throws MetadataManagerException, NamingException {
  
    Vector vSearchResults = new Vector();

    getSearchResults ("", getMetadataManagerServices(), getBasicAttributes(), 
      getSearchControls(), vstrUniqueIDs, vSearchResults);

    return vSearchResults;
  }

  /**
   * Retrieves a list of <code>SearchResult</code> values based on the chosen 
   * <code>MetadataFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>SearchResult</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getSearchResults() throws MetadataManagerException, NamingException {
    // Retrieve the list of search results
    Vector vSearchResults = new Vector();
    vSearchResults = getSearchResults (getFolderRoot(), getBasicAttributes(), 
      getSearchControls(), vSearchResults, getCountLimit(), isFolderFilterUsed());

    return vSearchResults;
  }

  /**
   * Retrieves a list of <code>Object</code> values objects from the 
   * underlying <code>SearchResult</code> objects based on the 
   * current <code>MetadataFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getObjects() throws MetadataManagerException, NamingException {
    return getObjects (getSearchResults());
  }

  /**
   * Retrieves the label based on the specified label type.
   *
   * Currently only supports <code>MM.MEASURE_CALC</code> object types. 
   * 
   * @param attributes A <code>Attributes</code> value that contains the 
   *        labels to retrieve.
   * @param strLabelType A <code>String</code> representing the desired label
   *        type.
   *
   * @return <code>String</code> which represents the label.
   *
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME  
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * 
   * @status new
   */
  public static String getLabel (Attributes attributes, String strLabelType) {
    String strLabel = null;
    /* gek 11/02/06    
    if (attributes != null) {
      if (MetadataMap.METADATA_LONGLABEL.equals (strLabelType)) {
        strLabel = MDCalcAttributes.getLongLabel (attributes, null);
      }
      else if (MetadataMap.METADATA_SHORTLABEL.equals (strLabelType)) {
        strLabel = MDCalcAttributes.getShortLabel (attributes, null);
      }
      else if (MetadataMap.METADATA_MEDIUMLABEL.equals (strLabelType)) {
        strLabel = MDCalcAttributes.getMediumLabel (attributes, null);
      }
      else if (MetadataMap.METADATA_DISPLAYNAME.equals (strLabelType)) {
        strLabel = MDCalcAttributes.getName (attributes, null);
      }
      else if (MetadataMap.METADATA_VALUE.equals (strLabelType)) {
        strLabel = MDCalcAttributes.getUniqueID (attributes, null);
      }     
    }
    */
  
    return strLabel;
  }
  
  /**
   * Retrieves the label based on the specified label type.
   *
   * @param mdObject A <code>MDObject</code> value that contains the 
   *        labels to retrieve.
   * @param strLabelType A <code>String</code> representing the desired label
   *        type.
   *
   * @return <code>String</code> which represents the label.
   *
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME  
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * 
   * @status new
   */
  public static String getLabel (MDObject mdObject, String strLabelType) {
    String strLabel = null;
    
    if (mdObject != null) {
      if (MetadataMap.METADATA_LONGLABEL.equals (strLabelType)) {
        strLabel = mdObject.getLongLabel();
      }
      else if (MetadataMap.METADATA_SHORTLABEL.equals (strLabelType)) {
        strLabel = mdObject.getShortLabel();
      }
      else if (MetadataMap.METADATA_MEDIUMLABEL.equals (strLabelType)) {
        strLabel = mdObject.getShortLabel();
      }
      else if (MetadataMap.METADATA_DISPLAYNAME.equals (strLabelType)) {
        strLabel = mdObject.getName();
      }
      else if (MetadataMap.METADATA_VALUE.equals (strLabelType)) {
        strLabel = mdObject.getUniqueID();
      }     
    }
  
    return strLabel;
  }

  /**
   * Retrieves the appropriate display label based on the <code>SearchResult</code>
   * and <code>MetadataMap</code> label type.
   * 
   * @param mmSearchResult A <code>MetadataManagerSearchResultImpl</code> to
   *        retrieve the label for.
   * @param strLabelType A <code>String</code> that contains the 
   *        <code>MetadataMap</code> label type to return.       
   *        
   * @return <code>String</code> representing the label associated with the 
   *         chosen display label type. 
   *         
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME  
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * 
   * @status new
   */
  public static String getLabel (MetadataManagerSearchResultImpl mmSearchResult, 
                                 String strLabelType) {
     
    String strLabel = null;
    
    if ((mmSearchResult != null) && (strLabelType != null)) {
      String strObjectType = mmSearchResult.getObjectType();
      
      if (MM.MEASURE_CALC.equals (strObjectType)) {
        strLabel = getLabel (mmSearchResult, strLabelType);  
      }
      else {
        MDObject mdObject = (MDObject)mmSearchResult.getObject();
        strLabel = getLabel (mdObject, strLabelType);
      }
    }      

    return strLabel;
  }
  
  /**
   * @hidden
   * 
   * Retrieve a <code>Vector</code> of <code>DimensionMember</code> 
   * objects based on the specified <code>MetadataManagerSearchResultImpl</code> 
   * objects. 
   * 
   * The <code>DimensionMember</code> will be generated using the 
   * <code>MetadataManager</code> unique ID as the dimension member ID and
   * the chosen label type as the display name.
   *
   * @param vSearchResults A <code>Vector</code> of 
   *        <code>MetadataManagerSearchResultImpl</code> objects to retrieve 
   *        <code>DimensionMember</code> objects from.
   * @param strLabelType A <code>String</code> which represents the 
   *        <code>MetadataMap</code> label type to add to the 
   *        <code>DimensionMember</code>.
   * 
   * @return <code>List</code> containing the retrieved <code>DimensionMember</code>
   *         objects.
   * 
   * @throws <code>MetadataManagerException</code> or 
   *         <code>NamingException</code> if measures cannot be retrieved.
   * 
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME  
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * 
   * @status hidden
   */
  public static Vector getDimensionMembers (Vector vSearchResults, String strLabelType) {

    Attributes attributes;
    MetadataManagerSearchResultImpl mmSearchResult;
    String strLabel;
    String strObjectType;
    String strUniqueID = null; 
    Vector vDimensionMembers = new Vector();
    
    if ((vSearchResults != null) && (!vSearchResults.isEmpty())) {
      for (int nIndex = 0; nIndex < vSearchResults.size(); nIndex++) {
        mmSearchResult = 
          (MetadataManagerSearchResultImpl)vSearchResults.get (nIndex);
  
        strObjectType = mmSearchResult.getObjectType();

        /* gek 11/2/06
        // Determine if we are processing a calculation
        if (MM.MEASURE_CALC.equals (strObjectType)) {
          attributes = mmSearchResult.getAttributes();
        
          // Retrieve the dimensionality performantly 
          strUniqueID = 
            MDCalcAttributes.getUniqueID (attributes, null);
       
          strLabel = getLabel (attributes, strLabelType);   
        } 
        else {
          MDObject mdObject = mmSearchResult.getMDObject();
          
          if (mdObject != null) {
            strUniqueID = mdObject.getUniqueID();
          }
        
          strLabel = getLabel (mdObject, strLabelType);
        }
        */
      
        MDObject mdObject = mmSearchResult.getMDObject();
        
        if (mdObject != null) {
          strUniqueID = mdObject.getUniqueID();
        }
      
        strLabel = getLabel (mdObject, strLabelType);

        vDimensionMembers.add (new DimensionMember (strUniqueID, strLabel));
      }
    }

    return vDimensionMembers;
  }

  /**
   * Retrieves a <code>Vector</code> of <code>Object</code> values from the
   * specified <code>SearchResults</code>.
   *
   * @param vSearchResults A <code>Vector</code> of SearchResults to retrieve
   *       <code>Object</code> values for.
   *
   * @return <code>Vector</code> representing the list of <code>Object</code> 
   *         values, if any
   *         
   * @see oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl#getObject()
   * @see javax.naming.directory.SearchResult#getObject()
   * 
   * @status new
   */
  static public Vector getObjects (Vector vSearchResults) { 
    Vector vObjects = null;
 
     // Iterate over the search results to retrieve the underlying MDObjects
    if (vSearchResults != null && !vSearchResults.isEmpty()) {
      vObjects = new Vector();
      
      SearchResult searchResult;
      for (int nIndex = 0; nIndex < vSearchResults.size(); nIndex++) {
        searchResult = (SearchResult) vSearchResults.get (nIndex);
        
        if (searchResult != null) {
          vObjects.add (searchResult.getObject());
        }
      }
    }

    return vObjects;
  }

	//-------------------------------------------------------------------
	// Start implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.

   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status new 
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status new
   */
  public void removeErrorHandler() {
    addErrorHandler (new DefaultErrorHandler());
  }

	//-------------------------------------------------------------------
	// End implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> value which represents the current error
   *          handler.
   *          
   * @status new
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /**
   * Convert a <code>Vector</code> of <code>String</code> objects into a 
   * <code>String</code> array.
   *
   * @param vstrValues A <code>Vector</code> of <code>String</code> values to 
   *        convert.
   * 
   * @return <code>String</code> array of <code>String</code> values.
   * 
   * @status new
   */
  public static String[] toArray (Vector vstrValues) {
    String[] strValues = null;
    
    if ((vstrValues != null) && (!vstrValues.isEmpty())) {
      strValues = new String [vstrValues.size()];
      vstrValues.toArray (strValues);
    }

    return strValues;    
  }

  /**
   * @hidden
   * 
   * <pre>
   * Retrieves a <code>BICompositeFilter</code> based on the specified criteria
   * and simplifies access to the underlying <code>HiddenFilter</code> and 
   * <code>MeasureDataTypeFilter</code>.
   *
   * For a <code>SearchResult</code> to be included, it must meet all search
   * criteria.
   *
   * The following example creates a <code>BICompositeFilter</code> that 
   * only includes measures which have the integer or short datatype, share 
   * intersecting dimensionality with the measures specified in the query filter, 
   * and are not hidden.
   * 
   * BIFilter biFilter =
   *   MeasureFilter.getBICompositeFilter (new String[] {MM.INTEGER, MM.SHORT}, 
   *     true, new MeasureFilter (query);
   * 
   * </pre>
   * 
   * @param strDataTypes A <code>String[]</code> that represents the compatible
   *        data types to use.  If null, all data types will be included.
   * @param bUseHiddenFilter A <code>boolean</code> which is <code>true</code>
   *        when the hidden filter should be used, and <code>false</code>
   *        otherwise.
   * @param biFilter A optional application defined <code>BIFilter</code> used 
   *        to filter results, which may be null.
   * 
   * @return <code>BICompositeFilter</code> value based on the specified criteria.
   *  
   * @status hidden
   */
  public static BICompositeFilter getBICompositeFilter (String[] strDataTypes, 
    boolean bUseHiddenFilter, BIFilter biFilter) {
    
    BICompositeFilter biCompositeFilter = null;

    // Set up the BIFilters
    int nFilters = -1;

    // Set up the passed in filter
    if (biFilter != null) {
      nFilters++;
    }
    
    // Set up the Hidden Filter
    BIFilter biFilterHidden = null;
    if (bUseHiddenFilter) {
      biFilterHidden = new HiddenFilter();  
      nFilters++;
    }
   
    // Set up the DataType Filter
    BIFilter biFilterDataType = null; 
    if (strDataTypes != null) {
      biFilterDataType = new MeasureDataTypeFilter (strDataTypes);
      nFilters++;
    }

    if (nFilters != -1) {
      BIFilter[] biFilters = new BIFilter [++nFilters];
      
      int nIndex = 0;
      
      if (biFilter != null) {
        biFilters [nIndex++] = biFilter;   
      }
      
      if (biFilterHidden != null) {
        biFilters [nIndex++] = biFilterHidden;   
      }
      
      if (biFilterDataType != null) {
        biFilters [nIndex++] = biFilterDataType;   
      }

      // Set up the composite filter will all of our constituent ones
      biCompositeFilter = new BICompositeFilter (biFilters);
    }

    return biCompositeFilter;
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>MDFolder</code> object that is associated with the
   * specified path.
   *
   * @param strPath A <code>String</code> value which represents the path
   *        to the <code>MDObject</code> to load.  If a null value is 
   *        specified, the root is assumed.
   *
   * @return The <code>MDFolder</code> object that represents the folder
   *         object, or null.
   *
   * @throws NamingException If the folder cannot be found.
   *
   * @status protected
   */
  public MDFolder getMDFolder (String strPath) throws NamingException {

    // The retrieved folder
    MDFolder mdFolder = null;

    // Retrieve the root folder
    MDFolder mdRoot = getMetadataManagerServices().getMDRoot();

    // Determine the proper MDFolder associated with the calculations
    // folder name
    if (strPath == null || strPath.equals ("") || strPath.equals ("/")) {
      mdFolder = mdRoot;
    }
    else {
      // Determine the proper MDFolder associated with the calculation's
      // folder name
      mdFolder = (MDFolder)mdRoot.lookup (strPath);
    }

    return mdFolder;
  }

  /**
   * Generates a fully qualified <code>MDFolder</code> path based on the 
   * specified path and name.
   *
   * @param strPath A <code>String</code> value which represents the path
   *        to the <code>CalcStep</code> to load.
   * @param strName A <code>String</code> value which represents the name
   *        of the <code>CalcStep</code> to load.
   *
   * @return <code>String</code> representing the fully qualified path.
   *
   * @throws <code>NamingException</code> if path could not be generated.
   *
   * @status New
   */
  public String getPath (String strPath, String strName) throws NamingException {
    String strFullPath = null;
    
    // Find the folder
    MDFolder mdFolder = getMDFolder (strPath);
    if (mdFolder != null) {
      // Determine the fully qualified path
      strFullPath = MMUtilities.composePath (mdFolder, strName);
    }

    return strFullPath;
  }

  /**
   * Generate a <code>MetadataManagerSearchResultImpl</code> from a 
   * <code>MDObject</code>. 
   *
   * @param mdObject A <code>MDObject</code> to retrieve the used to retrieve 
   *        a <code>MetadataManagerSearchResultImpl</code>.
   * 
   * @return <code>MetadataManagerSearchResultImpl</code> associated with
   *         the specified <code>MDObject</code>. 
   *          
   * @status new
   */
  public static MetadataManagerSearchResultImpl getSearchResult (MDObject mdObject) {
 
    MetadataManagerSearchResultImpl metadataManagerSearchResultImpl = null;
    
    if (mdObject != null) {

      // Retrieve all the MDObject attributes
      Attributes attributes = 
        MMUtilities.propertyBagToAttributes (mdObject);
        
      // Add the unique ID in case MDObject needs to be retrieved by
      // MeasureFilter
      attributes.put (MM.UNIQUE_ID, mdObject.getUniqueID());

      // Generate a SearchResult based on the MDMeasure
      metadataManagerSearchResultImpl = 
        new MetadataManagerSearchResultImpl (mdObject.toString(), 
          mdObject.getClassName(), mdObject.getUniqueID(), 
            attributes, mdObject.getObjectType(), mdObject.getMetadataManagerServices());
   
      // Update Driver Type
      metadataManagerSearchResultImpl.setDriverType (mdObject.getDriverType());
    }
  
    return metadataManagerSearchResultImpl;
  }
 
  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Retrieves a <code>MetadataManagerServices</code> from a 
   * <code>ComponentContext</code>. 
   *
   * @param componentContext A <code>ComponentContext</code> used to retrieve 
   *        <code>MetadataManagerServices</code> from.
   * 
   * @return <code>MetadataManagerServices</code> retrieved from a 
   *         from a <code>ComponentContext</code>. 
   *          
   * @status hidden
   */
  protected static MetadataManagerServices getMetadataManagerServices (ComponentContext componentContext) {
    MetadataManagerServices metadataManagerServices = null;
    
    if (componentContext != null) {
      BIProvider biProvider = componentContext.getBIProvider();
      if (biProvider != null) {
        metadataManagerServices = biProvider.getMetadataManager();  
      }
    }
    
    return metadataManagerServices;
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>MetadataManager</code> unique IDs associated with
   * each <code>MDObject</code>. 
   *
   * @param mdObjectsArray A <code>MDObject[]</code> of <code>MDObject</code> 
   *        values to retrieve unique IDs for.
   * 
   * @return <code>Vector</code> of <code>MetadataManager</code> unique ID values.
   *          
   * @status hidden
   */
  protected static Vector getUniqueIDs (MDObject[] mdObjectsArray) {
   
    Vector vstrUniqueIDs = null;
    
    MDObject mdObject;
    String strUniqueID;
    
    if ((mdObjectsArray != null) && (mdObjectsArray.length != 0)) {
      vstrUniqueIDs = new Vector();
      
      for (int nIndex = 0; nIndex < mdObjectsArray.length; nIndex++) {
        // Retrieve the MDObject
        mdObject = (MDObject) mdObjectsArray [nIndex];
        
        // Retrieve the unique ID for the MDObject
        strUniqueID = (mdObject != null) ? mdObject.getUniqueID() : null;
  
        // Add the unique ID
        vstrUniqueIDs.add (strUniqueID);
      }
    }
  
    // Return the unique IDs
    return vstrUniqueIDs; 
  }
  
  /**
   * @hidden
   * 
   * Orders the specified list in descending order based on number of 
   * intersecting dimensions which is stored in the <code>SearchResult</code>
   * FILTER_DIMENSION_RANK <code>Attribute</code>value.
   *
   * @param vSearchResults A <code>Vector</code> of <code>SearchResult</code> 
   *        values to order.
   * 
   * @return <code>Vector</code> of <code>SearchResult</code> values in 
   *         descending order based on number of intersecting dimensions. 
   * 
   * @status hidden
   */
  protected static Vector orderByRank (Vector vSearchResults) {
    Vector vSearchResultsRanked = null;
    
    if ((vSearchResults != null) && !vSearchResults.isEmpty()) {
      
      int nDimensionRank = 0;

      // Ordered SearchResult bucket
      Vector vSearchResultsOrdered = new Vector(5); 
      Vector vSearchResultsCurrent;
      SearchResult searchResult;

      Iterator iterator = vSearchResults.iterator();
      while (iterator.hasNext()) {
        searchResult = (SearchResult) iterator.next();        

        try {
          // Attempt to find the dimension rank
          nDimensionRank = getDimensionRank (searchResult); 
    
          // Attempt to retrieve the vector at the current position
          vSearchResultsCurrent = (Vector) vSearchResultsOrdered.get (nDimensionRank);       
          
          // Since we already have a vector at this position, simply add our 
          // new SearchResult
          vSearchResultsCurrent.add (searchResult);
        }
        
        catch (Exception exception) {
          // Since we don't have a vector at this position, create one
          vSearchResultsCurrent = new Vector();
          vSearchResultsCurrent.add (searchResult);

          // Increase the size of the vector if needed          
          if (nDimensionRank >= vSearchResultsOrdered.size()) {
            vSearchResultsOrdered.setSize (nDimensionRank + 1);  
          }

          // Order the vector based on dimension rank
          vSearchResultsOrdered.add (nDimensionRank, vSearchResultsCurrent);
          
          // Continue processing other SearchResults
          continue;
        }
      }

      if ((vSearchResultsOrdered != null) && (!vSearchResultsOrdered.isEmpty())) {
        vSearchResultsRanked = new Vector(); 

        // Create a new list based on the dimension ranking by moving backwards
        // through the ordered list
        for (int nIndex = vSearchResultsOrdered.size() - 1; nIndex >= 0; nIndex--) {
          // Retreive the vector at the current position
          vSearchResultsCurrent = (Vector) vSearchResultsOrdered.get (nIndex);
          
          // Add SearchResults that are currently at the end of the ordered list  
          if (vSearchResultsCurrent != null) {
            for (int nIndex1 = 0; nIndex1 < vSearchResultsCurrent.size(); nIndex1++) {
              vSearchResultsRanked.add (vSearchResultsCurrent.get (nIndex1));
            }
          }
        }
      }
    }
    else {
      // Simply return original list
      vSearchResultsRanked = vSearchResults;
    }
    
    return vSearchResultsRanked;
  }

  /**
   * @hidden
   * 
   * Makes sure that the specified list of <code>SearchResult</code>
   * objects are ordered with the <code>SearchResult</code> values
   * associated with the base <code>MDObject</code> unique ID values on top.
   *
   * If necessary duplicate <code>SearchResult</code> values are removed
   * from generated result.
   * 
   * @param metadataManagerServices A <code>MetadataManagerServices</code> object
   *        used to retrieve metadata.
   * @param vSearchResults A <code>Vector</code> of <code>SearchResults</code> to order.
   * @param vstrBaseIDs A <code>Vector</code> of <code>MDObject</code> unique IDs 
   *        that should be added to the top of the search result.
   * @param errorHandler A <code>ErrorHandler</code> used to process errors.       
   * @param basicAttributes A <code>BasicAttributes</code> used to refine 
   *        search based on the object types.
   * @param searchControls A <code>SearchControls</code> used to determine scope 
   *        of search and what gets returned.
   * 
   * @return <code>Vector</code> of <code>SearchResult</code> objects with 
   *         chosen base objects on top. 
   * 
   * @status hidden
   */
  protected static Vector orderByID (MetadataManagerServices metadataManagerServices, 
    Vector vSearchResults, Vector vstrBaseIDs, ErrorHandler errorHandler, 
      BasicAttributes basicAttributes, SearchControls searchControls) {
    
    if ((vSearchResults != null) && (vstrBaseIDs != null) && 
        (metadataManagerServices != null)) {
      
      SearchResult searchResult = null;
      String strID = null;
      String strBaseID;

      Vector vstrIDs = new Vector();
      Vector vSearchResultsIDs = new Vector();
      
      // Move backwards in list so that resulting SearchResult is properly ordered
      for (int nIndex = vstrBaseIDs.size() - 1; nIndex >= 0; nIndex--) {
        // Retrieve the ID of the current base object
        strBaseID = (String)vstrBaseIDs.get (nIndex);

        if (strBaseID != null) {
          // Determine if object already exists in the SearchResult list  
          for (int nIndex1 = 0; nIndex1 < vSearchResults.size(); nIndex1++) {
            searchResult = (SearchResult) vSearchResults.get (nIndex1);
            
            /* gek 11/02/06
            strID = MDCalcAttributes.getUniqueID (searchResult.getAttributes(), null);
            */
            
            // Determine if we have found the ID in our list already
            if (strBaseID.equals (strID)) {
              break;              
            }
            else {
              strID = null;
            }
          }  
          
          // If we have found the SearchResult in the list, make sure it appears 
          // on top  
          if (strID != null) {   
            vSearchResults.remove (searchResult);
            vSearchResultsIDs.add (searchResult);
            strID = null;
          }
          else {
            // Since we haven't found the ID in our SearchResult list, we will
            // need to verify that it meets the search criteria
            vstrIDs.add (strBaseID);  
          }
        }    
      } 

      // Determine if there are any IDs that need to be checked
      if ((vstrIDs != null) && (!vstrIDs.isEmpty())) {
        
        // gek 3/17/04 Fix Bug 3462018: Edit step dialog in QB takes minutes
        //             to open.
        //
        // Note: This is currently a fairly major *HACK* since 'Bug 3476659: 
        // Search not working properly with calculation MetadataManager Unique IDs'
        // is not going to be fixed for BI Beans 3.2.  Once this base bug is fixed,
        // the previous code can be restored.

        BIFilter biFilter = null;
        
        // Determine if a BIFilter has been specified
        if ((searchControls != null) && (searchControls instanceof MDSearchControls)) {
          biFilter = ((MDSearchControls)searchControls).getResultFilter();
        }

        MDMeasure mdMeasure; 
        MetadataManagerSearchResultImpl mmSearchResult;
        boolean bInclude;
        
        // Iterate over all the Base IDs to determine if any of them should be
        // added to the SearchResults
        for (int nIndex = 0; nIndex < vstrIDs.size(); nIndex++) {
          try {
            // Retrieve the MDMeasure which should hopefully still be loaded
            mdMeasure = 
              metadataManagerServices.getMeasureByUniqueID ((String)vstrIDs.get (nIndex));     
          
            if (mdMeasure != null) {
        
              // Retrieve all the MDMeasure attributes
              Attributes attributes = 
                MMUtilities.propertyBagToAttributes (mdMeasure);
                
              // Add the unique ID in case MDMeasure needs to be retrieved by
              // MeasureFilter
              attributes.put (MM.UNIQUE_ID, mdMeasure.getUniqueID());
              
              // Generate a SearchResult based on the MDMeasure
              mmSearchResult = 
                new MetadataManagerSearchResultImpl (mdMeasure.toString(), 
                  mdMeasure.getClassName(), mdMeasure.getUniqueID(), 
                    attributes, mdMeasure.getObjectType(), metadataManagerServices);
              
              // Specify the underlying SearchResult object
              mmSearchResult.setObject (mdMeasure);

              // Run the search result through each of the BIFilters
              bInclude = true;
              
              if (biFilter != null) {
                bInclude = biFilter.evaluate (mmSearchResult);
              }
            
              // If the SearchResults meets our criteria, add it
              if (bInclude) {
                vSearchResultsIDs.add (mmSearchResult);  
              }
            }
          }
          
          catch (MetadataManagerException metadataManagerException) {
            // Ignore exceptions and keep iterating over the rest of the list
            continue;
          }
        }   
      }            

      // Make sure SearchResult appears on top
      if ((vSearchResultsIDs != null) && (!vSearchResultsIDs.isEmpty())) {
        vSearchResults.addAll (0, vSearchResultsIDs);
      }
    }
        
    return vSearchResults;
  }

  /**
   * @hidden
   * 
   * Retrieves the default <code>SearchControls</code> used to determine scope 
   * of search and what gets returned.
   *
   * @param nSearchScope A <code>int</code> that represents the search scope.
   * @param strDriverType A <code>String</code> that represents the driver type.
   * @param strDataTypes A <code>String[]</code> that represents the compatible
   *        data types to use.  If null, all data types will be included.
   * @param bUseHiddenFilter A <code>boolean</code> which is <code>true</code>
   *        when the hidden filter should be used, and <code>false</code>
   *        otherwise.
   * @param bIncludeShortCuts A <code>boolean</code> which is <code>true</code>
   *        when shortcuts should be included, and <code>false</code>
   *        otherwise.
   * @param strArrayPaths A <code>String</code> array of folder names.
   * @param strArrayPathNames A <code>string</code> array of folder names.
   * @param biFilter A <code>BIFilter</code> used to filter results.
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   * 
   * @return <code>SearchControls</code> value which used to determine scope 
   *         of search and what gets returned.
   * 
   * @status hidden
   */
  protected static SearchControls getSearchControls (int nSearchScope, 
    String strDriverType, String[] strDataTypes, boolean bUseHiddenFilter, 
    boolean bIncludeShortCuts, String[] strArrayPaths, 
    String[] strArrayPathNames, BIFilter biFilter, long lCountLimit) {
    
    // Determine search criteria    
    MDSearchControls mdSearchControls = new MDSearchControls();

    // Limit the search to ONLY include the specified driver type
    // For example MM.MDM or MM.PERSISTENCE
    if (strDriverType != null) {
      mdSearchControls.setDriverType (strDriverType);
    }
    
    // Determine search depth
    mdSearchControls.setSearchScope (nSearchScope);

    // Set up the BIFilters
    BICompositeFilter biCompositeFilter = 
      getBICompositeFilter (strDataTypes, bUseHiddenFilter, biFilter);
    mdSearchControls.setResultFilter (biCompositeFilter);
  
    // Include ShortCuts
    if (bIncludeShortCuts) {
      DataUtils.includeShortCuts (mdSearchControls);
    }   
      
    // Update path and path names
    mdSearchControls.setSearchPaths (strArrayPaths);
    mdSearchControls.setSearchPathNames (strArrayPathNames);

    // Determine count limit
    // Note: SearchControls consider 0 to imply no limit as opposed to -1
    mdSearchControls.setCountLimit (lCountLimit == -1 ? 0 : lCountLimit);

    return mdSearchControls;
  }

  /**
   * @hidden
   * 
   * Retrieves the default <code>SearchControls</code> used to determine scope 
   * of search and what gets returned.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> object
   *        used to retrieve metadata.
   * @param strDataTypes A <code>String[]</code> that represents the compatible
   *        data types to use.  If null, all data types will be included.
   * @param biFilterBase A <code>BIFilter</code> to use.  If null, default filter
   *        is used.
   * @param lCountLimit A <code>long</code> which specifies the maximum number of 
   *        entries that will be returned. A -1 value indicates that there is no 
   *        limits and all values will be returned.
   * 
   * @return <code>SearchControls</code> value which used to determine scope 
   *         of search and what gets returned.
   * 
   * @throws <code>MetadataManagerException</code> if dimensionality cannot be
   *         retrieved.
   * 
   * @status hidden
   */
  protected static SearchControls getSearchControls
    (MetadataManagerServices metadataManagerServices, String[] strDataTypes, 
      BIFilter biFilterBase, long lCountLimit) throws MetadataManagerException {
    
    // Determine search criteria    
    MDSearchControls mdSearchControls = new MDSearchControls();

    // Determine search depth
    mdSearchControls.setSearchScope (BISearchControls.SUBTREE_SCOPE);
    
    // Set up the BIFilters
    BICompositeFilter biCompositeFilter = 
      getBICompositeFilter (strDataTypes, true, biFilterBase);
    mdSearchControls.setResultFilter (biCompositeFilter);
  
    // Include ShortCuts
    DataUtils.includeShortCuts (mdSearchControls);

    // Determine count limit
    // Note: SearchControls consider 0 to imply no limit as opposed to -1
    mdSearchControls.setCountLimit (lCountLimit == -1 ? 0 : lCountLimit);
      
    return mdSearchControls;
  }

  /**
   * @hidden
   * 
   * Retrieves a the default data types from the specified measures.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param strMeasureIDs A <code>String</code> array of <code>MetadataManager</code>
   *        unique IDs to retrieve data type for.
   * 
   * @return <code>String[]</code> value which represents the default data types.
   * 
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#STRING
   * 
   * @status hidden
   */
  protected static String[] getDataTypes (
    MetadataManagerServices metadataManagerServices, String[] strMeasureIDs) 
                                              throws MetadataManagerException {
    
    String[] strDataTypes = null;
    
    if ((metadataManagerServices != null) && (strMeasureIDs != null)) {
      MDMeasure mdMeasure;

      // Determine the number of measures in the query
      int nMeasures = strMeasureIDs.length;
      
      if (nMeasures != 0) {
        strDataTypes = new String [nMeasures];
  
        // Retrieve the data type associated with each measure
        for (int nIndex = 0; nIndex < nMeasures; nIndex++) {
          mdMeasure = 
            metadataManagerServices.getMeasureByUniqueID (strMeasureIDs[nIndex]);     
        
          if (mdMeasure != null) {
            strDataTypes [nIndex] = mdMeasure.getDataType();
          }
        }
      }
    }

    return strDataTypes;
  }

  /**
   * @hidden
   * 
   * Retrieves the measure dimension unique ID.
   *
   * @return <code>String</code> which represents the Measure dimension unique ID. 
   * 
   * @status hidden
   */
  protected String getMeasureDimensionID() {
    String strMeasureDimensionID = null;  
    
    try {
      strMeasureDimensionID = (getMetadataManagerServices() != null) ? 
        getMetadataManagerServices().getMeasureDimension (null).getUniqueID() : null; 
    }
    
    catch (MetadataManagerException metadataManagerException) {
      if (getErrorHandler() != null) {
        getErrorHandler().log (metadataManagerException.toString(), 
          getClass().getName(), "getMeasureDimensionID()");
      }   
    }
  
    return strMeasureDimensionID;
  }

  /**
   * @hidden
   *
   * Retrieves a <code>Vector</code> of <code>SearchResult</code> values meeting
   * the specified search criteria.
   *
   * @param biContext A <code>BIContext</code> where the search begins.  For
   *        example, a <code>MDFolder</code>.
   * @param basicAttributes A <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls A <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param vSearchResults A <code>Vector</code> of <code>SearchResult</code> 
   *        values to be recursively updated.
   * @param lCount A <code>long</code> representing the maximum number of objects
   *        to retrieve.  A value of 0 implies all measures.
   * @param bFolderFilter A <code>boolean</code> value that is <code>true</code>
   *        when the folders are excluded from the search results and 
   *        <code>false</code> otherwise.
   *
   * @return <code>Vector</code> representing the list of available  
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * @status hidden
   */
  static protected Vector getSearchResults (BIContext biContext, 
    BasicAttributes basicAttributes, SearchControls searchControls, 
      Vector vSearchResults, long lCount, boolean bFolderFilter) 
        throws MetadataManagerException, NamingException {
    
    // Invoke the search
    Enumeration enumeration = biContext.search ("", basicAttributes, searchControls);

    // Iterate over the search results
    if (enumeration != null) {
      MetadataManagerSearchResultImpl mmSearchResult = null;
      long lItems = (vSearchResults != null) ? vSearchResults.size() : 0;

      // Determine if a BIFilter has been specified
      BIFilter biFilter = null;
      if ((searchControls != null) && (searchControls instanceof MDSearchControls)) {
        biFilter = ((MDSearchControls)searchControls).getResultFilter();
      }
      
      boolean bInclude = true;
      
      while (enumeration.hasMoreElements() && 
            (lCount <= 0 || (lItems < lCount))) {

        // Retrieve the next search result
        mmSearchResult = (MetadataManagerSearchResultImpl) enumeration.nextElement();
         
        if (mmSearchResult != null) {

          // Check to determine if we are removing folders before adding
          // search result
          if (!bFolderFilter || 
             (bFolderFilter && (!MM.FOLDER.equals (mmSearchResult.getObjectType())))) {

            // If we have found a search result, add it to the list
            if (vSearchResults != null) {
              // Run the search result through each of the BIFilters
              bInclude = true;
              
              if (biFilter != null) {
                bInclude = biFilter.evaluate (mmSearchResult);
              }
            
              // If the SearchResults meets our criteria, add it
              if (bInclude) {
                vSearchResults.add (mmSearchResult);  
              }
            }
          }

          // Update the number of items
          if (vSearchResults != null) {
            lItems = vSearchResults.size();
          }
        }
      }
    }
    
    // Return the search results
    return vSearchResults;
  }

  /**
   * @hidden
   *
   * Retrieves a <code>Vector</code> of <code>SearchResult</code> values meeting
   * the specified search criteria.
   *
   * @param biContext A <code>BIContext</code> where the search begins.  For
   *        example, a <code>MDFolder</code>.
   * @param basicAttributes A <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls A <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param vSearchResults A <code>Vector</code> of <code>SearchResult</code> 
   *        values to be recursively updated.
   * @param lCount A <code>long</code> representing the maximum number of objects
   *        to retrieve.  A value of 0 implies all measures.
   *
   * @return <code>Vector</code> representing the list of available  
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * @status hidden
   */
  static protected Vector getSearchResults (BIContext biContext, 
    BasicAttributes basicAttributes, SearchControls searchControls, 
      Vector vSearchResults, long lCount) throws MetadataManagerException, NamingException {
    
    return getSearchResults (biContext, basicAttributes, searchControls, 
      vSearchResults, lCount, true);    
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>FILTER_DIMENSION_RANK</code> from the 
   * specified <code>SearchResults</code> which contains the number of 
   * intersecting dimensions used to determine dimension ranking.
   *
   * @param searchResult A <code>SearchResult</code> to retrieve dimension rank
   *        from.
   *        
   * @return <code>int</code> which represents the number of intersecting 
   *         dimensions used to retreive dimension ranking. A value of 0 is 
   *         returned if this value cannot be retrieved.
   * 
   * @throws <code>NamingException</code> if dimension rank cannot be retrieved.
   * 
   * @see #FILTER_DIMENSION_RANK
   * 
   * @status hidden
   */
  static protected int getDimensionRank (SearchResult searchResult) throws NamingException {
    int nDimensionRank = 0;
  
    Object objAttribute = 
      getAttribute (searchResult, FILTER_DIMENSION_RANK);
    
    if (objAttribute != null) {
      nDimensionRank = ((Integer) objAttribute).intValue();
    }
  
    return nDimensionRank;
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>Attribute</code> from the <code>SearchResults</code>.
   *
   * @param searchResult A <code>SearchResult</code> to retrieve <code>Attribute</code>.
   * @param strAttribute A <code>String</code> that represents the 
   *        <code>Atttribute</code> to retrieve.
   *        
   * @return <code>Object</code> which represents the chosen attribute or null.
   * 
   * @throws <code>NamingException</code> if <code>Attribute</code> cannot be retrieved.
   * 
   * @status hidden
   */
  static protected Object getAttribute (SearchResult searchResult, 
                                   String strAttribute) throws NamingException {
    
    Object objAttribute = null;
    
    if ((searchResult != null) && (strAttribute != null)) {
      Attributes attributes = searchResult.getAttributes();  
      
      if (attributes != null) {
        Attribute attribute = attributes.get (strAttribute);
        if (attribute != null) {
          objAttribute = attribute.get();
        }
      }
    }
  
    return objAttribute;
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>SearchResult</code> based on the specified 
   * <code>MetadataManager</code> unique ID.
   *
   * @param strFolder A <code>String</code> representing the name of the folder
   *        to search.
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param basicAttributes A <code>BasicAttributes</code> used to refine 
   *        search based on the object types.
   * @param searchControls A <code>SearchControls</code> used to determine scope 
   *        of search and what gets returned.
   * @param strUniqueID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID.
   *        
   * @return <code>SearchResult</code> which represents the found object or null.
   * 
   * @throws <code>NamingException</code> if search fails.
   * 
   * @status hidden
   */
  static protected SearchResult getSearchResult (String strFolder, 
    MetadataManagerServices metadataManagerServices, BasicAttributes basicAttributes, 
      SearchControls searchControls, String strUniqueID) throws NamingException {
    
    SearchResult searchResult = null;
    
    if ((metadataManagerServices != null) && (strUniqueID != null)) {
      if (basicAttributes != null) {
        basicAttributes.put (new BasicAttribute (MM.UNIQUE_ID, strUniqueID));
      }

      if (searchControls != null) {
        searchControls.setSearchScope (BISearchControls.SUBTREE_SCOPE);
        searchControls.setCountLimit (1);
      }

      Enumeration enumeration = 
        metadataManagerServices.getMDRoot().search (strFolder, basicAttributes, searchControls);
      
      // Retrieve the first value which represents the SearchResult associated
      // with the unique ID
      if (enumeration != null) {
        MetadataManagerSearchResultImpl mmResult = null;
        while (enumeration.hasMoreElements() && (searchResult == null)) {
 
          // Retrieve the next search result
          mmResult = (MetadataManagerSearchResultImpl) enumeration.nextElement();
  
          if (mmResult != null) {
            // If we found a folder, skip it
            if (!MM.FOLDER.equals (mmResult.getObjectType())) {
              // We found the object we were looking for
              searchResult = mmResult;
            }
          }
        }
      }
    }
  
    return searchResult;
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>Vector</code> of <code>SearchResult</code> values
   * based on the specified <code>MetadataManager</code> unique IDs.
   *
   * @param strFolder A <code>String</code> representing the name of the folder
   *        to search.
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param basicAttributes A <code>BasicAttributes</code> used to refine 
   *        search based on the object types.
   * @param searchControls A <code>SearchControls</code> used to determine scope 
   *        of search and what gets returned.
   * @param vstrUniqueIDs A <code>Vector</code> of <code>String</code> values
   *        that represents the <code>MetadataManager</code> unique IDs.
   * @param vSearchResults A <code>Vector</code> of <code>SearchResult</code> 
   *        values that will be padded with new ones that meet the search criteria.
   *        
   * @throws <code>NamingException</code> if search fails.
   * 
   * @status hidden
   */
  static protected void getSearchResults (String strFolder, 
    MetadataManagerServices metadataManagerServices, BasicAttributes basicAttributes, 
      SearchControls searchControls, Vector vstrUniqueIDs, Vector vSearchResults) 
                                                        throws NamingException {
    
    if ((metadataManagerServices != null) && (vstrUniqueIDs != null)) {
      
      // Add our unique IDs to the BasicAttributes
      if (basicAttributes != null) {
        BasicAttribute basicAttribute = null;
        String strUniqueID = null;
        
        for (int nIndex = 0; nIndex < vstrUniqueIDs.size(); nIndex++) {
          // Retrieve the unique ID
          strUniqueID = (String)vstrUniqueIDs.get (nIndex);

          // Make sure that the unique ID is not null
          if (strUniqueID != null) {
            // Check to see if we need to create our first BasicAttribute
            if (basicAttribute == null) {
              basicAttribute = new BasicAttribute (MM.UNIQUE_ID, strUniqueID);            
            }
            else {
              // Add new unique ID
              basicAttribute.add (strUniqueID);
            }
          }        
        }

        if (basicAttribute != null) {          
          basicAttributes.put (basicAttribute);
        }
      }

      if (searchControls != null) {
        searchControls.setSearchScope (BISearchControls.SUBTREE_SCOPE);
      }

      // Attempt to retrieve matching SearchResults
      Enumeration enumeration = 
        metadataManagerServices.getMDRoot().search (strFolder, basicAttributes, searchControls);
      
      // Retrieve the first value which represents the SearchResult associated
      // with the unique ID
      if (enumeration != null) {
        MetadataManagerSearchResultImpl mmResult = null;
        while (enumeration.hasMoreElements()) {
 
          // Retrieve the next search result
          mmResult = (MetadataManagerSearchResultImpl) enumeration.nextElement();
  
          if (mmResult != null) {
            // If we found a folder, skip it
            if (!MM.FOLDER.equals (mmResult.getObjectType())) {
              // We found an object that we were looking for, so add it to our
              // running list
              if (vSearchResults != null) {
                vSearchResults.add (mmResult);
              }
            }
          }
        }
      }
    }
  }

  /**
   * @hidden
   *
   * Determines whether the specified intersection criteria has been met so 
   * that a given object should be include in a <code>SearchResult</code>.
   *
   * @param vstrSet1 A <code>Vector</code> of <code>String</code> values 
   *        representing the first set to compare.
   * @param vstrSet2 A <code>Vector</code> of <code>String</code> values 
   *        representing the second set to compare.
   * @param vstrIntersection A <code>Vector</code> that will be filled with 
   *        <code>String</code> values that represent the intersection between
   *        Set1 and Set2.  If this value is null, no values will be generated.
   * @param nIntersectionFilter A <code>int</code> value that determines the 
   *        desired intersection.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         intersection criteria has been met, and <code>false</code> 
   *         otherwise.
   *         
   * @see #getIntersectionFilter()
   * 
   * @status hidden
   */
  static protected boolean isIncluded (Vector vstrValue1, Vector vstrValue2, 
    Vector vstrIntersectionFilter, int nIntersectionFilter) { 
 
    // Determine the relationship between the lists of values
    int nCompare = 
      SetUtils.compareSets (vstrValue1, vstrValue2, vstrIntersectionFilter);

    return ((nCompare & nIntersectionFilter) != 0);
  }
 
  /**
   * Return <code>MDObject</code> associated with the specified 
   * <code>MetadataManager</code> name and type.
   * 
   * @param strName A <code>String</code> which represents the name of the 
   *        <code>MDObject</code> to find.
   * @param strType A <code>String</code> which represents the 
   *        <code>MetadataManager</code> type        
   *        
   * @see oracle.dss.metadataManager.common.MM#DIMENSION
   * @see oracle.dss.metadataManager.common.MM#DIMENSIONMEMBER_CALC
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC
   * @see oracle.dss.metadataManager.common.MM#MEASURE
   * @see oracle.dss.metadataManager.common.MM#MEASURE_CALC
   * 
   * @return <code>MDObject</code> associated with the specified name and type.
   */
  protected MDObject lookupMetadata (String strName, String strType) {
    MDObject mdObject = null;

    try {
      MetadataManagerServices metadataManagerServices = getMetadataManagerServices();

      if (metadataManagerServices != null) {
        mdObject = metadataManagerServices.getMDObject (MM.OBJECT_NAME, strName, strType);
      }
    }

    // Ignore exceptions        
    catch (MetadataManagerException metadataManagerException) {
      if (getErrorHandler() != null) {
        getErrorHandler().log (metadataManagerException.toString(), 
          getClass().getName(), "getMeasureDimensionID()");
      }   
    }

    return mdObject;
  }

  /**
   * @hidden
   * 
   * Hides the specified <code>MDMeasure</code> values.
   * 
   * @param strNames A <code>String[]</code> of <code>MetadataManager</code>
   *        names associated with the <code>MDMeasure</code> values to hide.
   * 
   * @status hidden
   */
  protected void hideMeasures (String[] strNames) {
    if (strNames != null) {
      
      MDObject mdMeasure;
      
      for (int nIndex = 0; nIndex < strNames.length; nIndex++) {
        mdMeasure = lookupMetadata (strNames [nIndex], MM.MEASURE);
      
        if (mdMeasure != null) {
          mdMeasure.setStrPropertyValue (MM.HIDDEN, MM.HIDE_ALWAYS);
        }
      }
    }
  }

  /**
   * @hidden
   * 
   * Retrieves a consolidated driver type based on the specified list of base
   * IDs.
   * 
   * @param vstrBaseIDs A <code>Vector</code> of <code>MDObject</code> unique IDs 
   *        that should be processed.
   * 
   * @return <code>String</code> which represents the consolidated driver type. 
   * 
   * @status hidden
   */
  protected static String getDriverType (Vector vstrBaseIDs) {
    String strDriverType = null;
    String strDriverTypeBase;
    
    String strID = null;
    
    if ((vstrBaseIDs != null) && (!vstrBaseIDs.isEmpty())) {
      for (int nIndex = 0; nIndex < vstrBaseIDs.size(); nIndex++) {
        strID = (String) vstrBaseIDs.get (nIndex);
        if (strID != null) {
          strDriverTypeBase = MMUtilities._getDriverType(strID);
          
          if (strDriverType != null) {
            if (!strDriverType.equals (strDriverTypeBase)) {
               // There are currently two driver types, MM.MDM and MM.PERSISTENCE.
               // If we have found driver types that don't match, specify null
               // so that both are included in the result.
              strDriverType = null;
              break;
            }
          }
          else {
            strDriverType = strDriverTypeBase;
          }
        }
      }      
    }
    
    return strDriverType;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}