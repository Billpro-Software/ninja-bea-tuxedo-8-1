/*
 * StandardButton.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Insets;

import javax.swing.Icon;
import javax.swing.JButton;

/**
 * @hidden
 */
public class StandardButton extends JButton
{
    //-----------------------------------------------------------------------
    // NON PUBLIC CONSTANTS
    //-----------------------------------------------------------------------
    
    private static final int STANDARDBUTTON_LEFTMARGIN      = 7;
    private static final int STANDARDBUTTON_RIGHTMARGIN     = 7;
    
    //-----------------------------------------------------------------------
    // CONSTRUCTOR
    //-----------------------------------------------------------------------

    /**
     * Creates a button with no set text or icon.
     */
    public StandardButton ( ) 
    {
        super ( );
        applyDefaultMargin ( );
    }
    
    /**
     * Creates a button with an icon.
     *
     * @param icon  the Icon image to display on the button
     */
    public StandardButton ( Icon icon ) 
    {
        super ( icon );
        applyDefaultMargin ( );
    }
    
    /**
     * Creates a button with text.
     *
     * @param text  the text of the button
     */
    public StandardButton ( String text )
    {
        super ( text );
        applyDefaultMargin ( );
    }
    
    /**
     * Creates a button with initial text and an icon.
     *
     * @param text  the text of the button.
     * @param icon  the Icon image to display on the button
     */
    public StandardButton ( String text, Icon icon )
    {
        super ( text, icon );
        applyDefaultMargin ( );
    }

    /**
     * @hidden
     * Creates a button with given insets.
     * 
     * @status hidden
     */
	public StandardButton ( Insets btnInsets )
	{
		super ( );
		setMargin ( new Insets ( btnInsets.top, btnInsets.left, 
		                         btnInsets.bottom, btnInsets.right ) );
	}
	
    //-----------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-----------------------------------------------------------------------

    /**
     * @hidden
     * @status hidden
     */
    protected void applyDefaultMargin ( )	
    {
        Insets  newInsets   = null, oldInsets = null;
        
        oldInsets = getMargin ( );
        newInsets = new Insets ( oldInsets.top, STANDARDBUTTON_LEFTMARGIN, 
                                 oldInsets.bottom, STANDARDBUTTON_RIGHTMARGIN );
        setMargin ( newInsets );                                 
    }        
}