/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui.component.models;

import java.util.ArrayList;

import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;

import javax.swing.JTree;

import oracle.dss.datautil.filter.MetadataFilter;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDSearchControls;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.queryBuilder.FolderItemsTreeNode;
import oracle.dss.util.gui.component.tree.ComponentTreeNode;


/**
 * This class will take in a component context and some parameters and return a tree of measures based
 * on ComponentNodes.  We should have a TreeListComboModel implementation that can wrap these component
 * nodes by Swing tree nodes to feed to the TreeListCombo.
 */

public class MeasureSelectModel implements SelectModel {
    protected ComponentContext m_context;
    protected ComponentTreeNode m_rootNode;
    
    public MeasureSelectModel(ComponentContext componentContext) {
        m_context = componentContext;
    }
    
    
    /**
     * Creates a default <code>MetadataFilter</code> that can be used to filter a wide 
     * range of metadata, using a variety of criteria. 
     *
     * @param componentContext A <code>ComponentContext</code> value used to 
     *        initialize the filter.
     * @return <code>MetadataFilter</code> used to filter a wide range of metadata, 
     *         based on  a variety of criteria. 
     *
     * @status new
     */
    public MetadataFilter createMetadataFilter (ComponentContext componentContext) {
      MetadataFilter metadataFilter = null;
      
      if (componentContext != null) {
        metadataFilter = new MetadataFilter (componentContext);
        metadataFilter.setBasicAttributes (createBasicAttributes());
        metadataFilter.setSearchControls (createSearchControls());    
      }
              
      // Do not filter folders out of the search result
      metadataFilter.setFolderFilter (false);
      
      return metadataFilter;
    }
    
    /**
     * Creates a default <code>SearchControls</code> that can be used to filter a wide 
     * range of metadata, using a variety of criteria. 
     *
     * @return <code>SearchControls</code> used to filter a wide range of metadata, 
     *         based on a variety of criteria. 
     *
     * @status new
     */
    public SearchControls createSearchControls() {
      MDSearchControls mdSearchControls = new MDSearchControls();
      mdSearchControls.setIgnoreMatchingAttributes (true);
      mdSearchControls.setSearchScope (MDSearchControls.SELECTIVE_ONELEVEL_SCOPE);
      
      return mdSearchControls;
    }    
    
    /**
     * Creates a default <code>BasicAttributes</code> that can be used to filter a wide 
     * range of metadata, using a variety of criteria. 
     *
     * @return <code>BasicAttributes</code> used to filter a wide range of metadata, 
     *         based on a variety of criteria. 
     *
     * @status new
     */
    public BasicAttributes createBasicAttributes() {
      BasicAttributes basicAttributes = new BasicAttributes();
      BasicAttribute basicAttribute = new BasicAttribute (MM.OBJECT_TYPE, MM.CALCULATION);
      basicAttribute.add (MM.MEASURE);
      basicAttributes.put (basicAttribute);
      basicAttributes.put (MM.SORT, Boolean.valueOf (true));   
      return basicAttributes;
    }

    public ComponentTreeNode getTreeRoot() {
        MDFolder rootFolder = m_context.getMetadataProvider().getCurrentDatasourceRootFolder();
        
        MetadataFilter filter = createMetadataFilter(m_context);
        
        FolderItemsTreeNode rootNode = new FolderItemsTreeNode(new JTree(), rootFolder, m_context);
        rootNode.setMetadataFilter(filter);
        
        return rootNode;
    }
    
    public ArrayList getSelectFilters() {
        ArrayList filters = new ArrayList(1);
        filters.add(FolderItemsTreeNode.class);
        return filters;
    }
    
    public boolean isMultiSelect() {
        return false;
    }
        
}
