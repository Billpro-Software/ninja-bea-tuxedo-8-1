/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

/**
 * @hidden
 * This interface is implemented by all model that can be sorted by a Sorter
 */
public interface SortableModel
{
   /**
    * Returns the index used for sorting of the children of the specified object
    *
    * @param obj the object in which the index is retrieved
    * @return the index of the children of the specified object
    *
    * @status New
    */
    public abstract int[] getIndexes(Object obj);

   /**
    * Sort the children of the specified object in the specified order
    *
    * @param obj the object in which the children are sorted
    * @param isAscent <code>true</code> if sort in ascending order.  <code>false</code>
    * if otherwise
    * @status New
    */
    public abstract void sort(Object obj, boolean isAscent);
}