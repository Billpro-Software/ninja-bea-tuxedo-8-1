/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/DataCell.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     06/05/06 - 
    jramanat    05/03/06 - 
    bmoroze     02/27/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/DataCell.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.client;

import oracle.dss.util.transform.DataCellInterface;
import oracle.dss.util.transform.DataType;
import oracle.dss.util.transform.TransformException;

/**
 * @hidden
 *
 */
public class DataCell extends Object implements DataCellInterface
{
    protected Object m_data = null;
    
    public DataCell(Object data)
    {
        super();
        m_data = data;
    }
    
    public Object getData(String type)
    {
        if (type == null)
            return null;
            
        if (type.equals(DataType.FORMATTED) || type.equals(DataType.VALUE))
            return m_data;
        return null;
    }    

    public boolean setData(Object value, String type) throws TransformException
    {
        return false;
    }        

}