/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.query;

import java.io.Serializable;

import java.util.Vector;

import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;

//import oracle.dss.calculation.client.MDCalcAttributes;

import oracle.dss.datautil.gui.Utils;

import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;

//import oracle.dss.selection.calcStep.CalcStep;

/**
 * @hidden
 */
public class MeasureDimensionedByFilter implements BIFilter, Serializable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  // The dimension by which each measure must be dimensioned.
  private String m_strDimension = null;

  // A superset of dimensions by which each measure must be dimensioned.
  private Vector m_vstrDimensions = null;

  // Determines whether a measure should be dimensioned by a Time dimension.
  private boolean m_bTimeFilter = false;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Specifies the dimension that each measure must be dimensioned by.
   *
   * As a result, a measure will only be included if is dimensioned by the
   * dimension.
   *
   * @param strDimension a <code>String</code> value that is used to filter measures by.
   *
   * @status New
   */
  public MeasureDimensionedByFilter (String strDimension) {
    m_strDimension = strDimension;
  }
  
  /**
   * Specifies the list of dimensions that is a superset of all available dimensions.
   *
   * As a result, a measure will only be included if all of the dimensions that
   * it is dimensioned by are available in the specified list.
   *
   * @param vstrDimensions a <code>Vector</code> of <code>String</code> values
   *        that are used to filter measures by.
   *
   * @status New
   */
  public MeasureDimensionedByFilter (Vector vstrDimensions) {
    m_vstrDimensions = vstrDimensions;
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies whether the measure should be dimensioned by Time.
   *
   * @param bTimeFilter a <code>boolean</code> value that is <code>true</code>
   *        when the measure should be dimensioned by Time.
   *
   * @status New
   */
  public void setTimeFilter (boolean bTimeFilter) {
    m_bTimeFilter = bTimeFilter;
  }

  /**
   * Determines whether the measure should be dimensioned by Time.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measure
   *         should be dimensioned by Time and <code>false</code> otherwise
   *
   * @status New
   */
  public boolean isTimeFilterUsed() {
    return m_bTimeFilter;
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome
   *
   * @return <code>boolean</code> which is <code>true</code> if the search result
   *         should be included and <code>false</code> otherwise
   * @status New
   */
  public boolean evaluate (BISearchResult searchResult) {

    boolean bInclude = true;
    MDObject mdObject = null;

    // Check for null search results
    if (searchResult == null)
      return false;

    if (searchResult instanceof MetadataManagerSearchResultImpl) {
      MetadataManagerSearchResultImpl mmResult = (MetadataManagerSearchResultImpl)searchResult;

      if (MM.CALCULATION.equals(searchResult.getObjectType())) {
        /** gek 11/03/06
        // gek 07/21/03 Fix Bug 2616374: Expensive operation to load each measure
        //              to check if they have a time dimension.
        //
        //              Do the "quick and dirty" search, if we are only
        //              concerned about Time
        if (isTimeFilterUsed() && (m_strDimension == null) && (m_vstrDimensions == null)) {

          // Determine if calculation is dimensioned by time
          String strDimensionedByTime = 
            MDCalcAttributes.getDimensionedByTime (mmResult.getAttributes(), null);

          // If calculation is definitively dimensioned by Time, return. 
          if (CalcStep.ATTRIBUTE_VALUE_YES.equals (strDimensionedByTime)) {
            return true;  
          }
        }

        MDDimension[] dims = 
          MDCalcAttributes.getDimensions (mmResult.getMetadataManagerServices(), 
            mmResult.getAttributes(), null);

        if (dims == null)
          return false;

        // Specifies the dimension that each measure must be dimensioned by.
        if (m_strDimension != null) {
          boolean include = false;
          for (int i = 0; i < dims.length; i++) {
            if (m_strDimension.equals(dims[i].getUniqueID())) {
              include = true;
              break;
            }
          }
          bInclude = include;
        }
        else if (m_vstrDimensions != null) {
          // Specifies the list of dimensions that is a superset of all available dimensions.
          boolean include = true;
          for (int i = 0; i < dims.length; i++) {
            if (!m_vstrDimensions.contains(dims[i].getUniqueID())) {
              include = false;
              break;
            }
          }
          bInclude = include;
        }
        
        if (m_vstrDimensions != null) {
          // Specifies the list of dimensions that is a superset of all available dimensions.
          boolean include = true;
          for (int i = 0; i < dims.length; i++) {
            if (!m_vstrDimensions.contains(dims[i].getUniqueID())) {
              include = false;
              break;
            }
          }
          bInclude = include;
        }
        
        // Check to see if we need to check for time dimension
        if (bInclude && isTimeFilterUsed()) {
          boolean include = false;
          for (int i = 0; i < dims.length; i++) {
            if (dims[i].isTimeDimension()) {
              include = true;
              break;
            }
          }
          bInclude = include;
        }
        */
      }
      else {
        // Need to load the measure so that its dimensions will be loaded when 
        // checking if it has any time dimensions. 
        Object objResult = searchResult.getObject();

        if ((objResult != null) && (objResult instanceof MDObject)) {

          mdObject = (MDObject)objResult;

          if (mdObject instanceof MDMeasure) {
            try {
              // Specifies the dimension that each measure must be dimensioned by.
              if (m_strDimension != null) {
                if (!DataUtils.isDimensionedBy (mdObject.getMetadataManagerServices(),
                  mdObject.getUniqueID(), m_strDimension)) {
                  bInclude = false;
                }
              }
              else {
                // Specifies the list of dimensions that is a superset of all available dimensions.
                if (m_vstrDimensions != null) {
                  if (!DataUtils.isDimensionedBy (mdObject.getMetadataManagerServices(),
                    mdObject.getUniqueID(), m_vstrDimensions)) {
                    bInclude = false;
                  }
                }
              }

              // Check to see if we need to check for time dimension
              if (bInclude && isTimeFilterUsed()) {
                // Determine if this measure has any time dimensions
                Vector vstrTimeDimensions =
                  Utils.getTimeDimensions (mdObject.getMetadataManagerServices(), 
                    mdObject.getUniqueID());

                // If we don't have any time dimensions, remove measure
                if ((vstrTimeDimensions == null) || (vstrTimeDimensions.size() == 0))
                  bInclude = false;
              }
            }

            catch (MetadataManagerException mme) {
              return false;
            }
          }
        }
      }
    }

    return bInclude;
  }
}