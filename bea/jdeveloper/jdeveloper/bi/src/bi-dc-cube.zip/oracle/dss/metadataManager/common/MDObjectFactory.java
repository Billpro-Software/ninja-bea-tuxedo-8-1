/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDComponent;
import oracle.dss.metadataManager.common.MDSelection;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataUtil.UserObject;

/**
 * @hidden
 */
public class MDObjectFactory {

    /**
     * @hidden
     */
    public static MDObject makeMDObject(String objType, 
                                        MDObject parent, 
                                        String driverType, 
                                        String objName, 
                                        MetadataManagerServices mdServices, 
                                        UserObject usrObj, 
                                        String usrObjRelationship)
    {
        MDObject _mdObj = null;

        if (objType.equals(MM.SELECTION))
            _mdObj = new MDSelection();
        else if (objType.equals(MM.MEASURE))
            _mdObj = new MDMeasure();
        else
            _mdObj = new MDComponent();

        return setCommonProperties(_mdObj, objType, parent, driverType, objName, mdServices, usrObj, usrObjRelationship);
    }
    
    /**
     * @hidden
     */
    public static MDObject setCommonProperties(MDObject mdObj,
                                               String objType,
                                               MDObject parent, 
                                               String driverType, 
                                               String objName, 
                                               MetadataManagerServices mdServices, 
                                               UserObject usrObj, 
                                               String usrObjRelationship)
    {
        if ( mdObj != null ) 
        {
            mdObj.setObjectType(objType);
            mdObj.setParent(parent); 
            mdObj.setDriverType(driverType);
            mdObj.setName(objName);
            mdObj.setMetadataManagerServices(mdServices);
            mdObj.addUserObject(usrObjRelationship, usrObj); 
        }
    	return mdObj;
    }    
}
