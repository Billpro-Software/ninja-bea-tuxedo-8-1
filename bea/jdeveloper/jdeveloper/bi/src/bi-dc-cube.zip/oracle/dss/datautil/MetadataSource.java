/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil;

/**
 * @hidden
 */
public interface MetadataSource
{
    public Object getMetadataObject(String id, int providerId);
    public void setMetadataObject(String name, Object metadataObj, String pathName, String id, int objectType, int providerId);
}
