/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/ItemsChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     07/28/05 - bmoroze_bicommon050726
    bmoroze     07/26/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/ItemsChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil;


/**
 * Describes the event that carries cursor access and item information
 * to <code>QueryEditor</code> clients.
 *
 * @status Documented
 */
public class ItemsChangedEvent extends QueryEditorEvent
{
    /**
     * Constructs the event.
     *
     * @param qe The QueryEditor that fired this event. (Note: This object can be
     *               the same <code>QueryEditor</code> object that is referenced
     *               by the parameter <code>qa</code>. It is also possible that
     *               this <code>source</code> parameter could be a higher level
     *               object and the parameter
     *               <code>qa</code> could be a <code>QueryEditor</code> object
     *               that was contained within the higher level object.)
     * @param dataItems The changed (new) dataItems.
     * @param items  The changed (new) items.
     * @param oldDataItems The old data items, if any.
     * @param oldItems The old items, if any.
     *
     * @status New
     * @hidden
     */
     public ItemsChangedEvent(QueryEditor qe, String[] dataItems, String[] items, String[] oldDataItems, String[] oldItems) {
        super(qe);
        
        m_items = items;
        m_oldItems = oldItems;
        m_dataItems = dataItems;
        m_oldDataItems = oldDataItems;
    }
        
    /**
     * Retrieves the changed data items.
     * 
     * @return The changed data items.
     */
    public String[] getDataItems()
    {
        return m_dataItems;
    }    
        
    /**
     * Retrieves the changed items.
     * 
     * @return The changed items.
     */
    public String[] getItems() {
        return m_items;
    }    

    /**
     * Retrieves the list of data items before the change
     * 
     * @return List of data items before the change.
     */
    public String[] getPreviousDataItems()
    {
        return m_oldDataItems;
    }
        
    /**
     * Retrieves the list of items before the change
     * 
     * @return List of items before the change.
     */
    public String[] getPreviousItems()
    {
        return m_oldItems;
    }

    /**
     * @hidden
     *
     * @serial data items that changed (new)
     */
    protected String[] m_dataItems = null;
        
    /**
     * @hidden
     *
     * @serial items that changed (new)
     */
    protected String[] m_items = null;

    /**
     * @hidden
     * Previous data items
     */
    protected String[] m_oldDataItems = null;    

    /**
     * @hidden
     * Previous items
     */
    protected String[] m_oldItems = null;    
}