/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/comboBox/TreeListComboBoxModelMembers.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.comboBox;

import java.awt.Component;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.resource.DataUtilGUIBundle;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.queryBuilder.DataFilterUtils;
import oracle.dss.queryBuilder.ItemItemsTreeNode;
import oracle.dss.queryBuilder.QBUtils;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.util.gui.ResourceHandler;
import oracle.dss.util.gui.component.ComponentNode;
// import oracle.dss.util.gui.component.comboBox.TreeListCombo;
import oracle.dss.util.gui.component.comboBox.TreeListComboBoxModel;
import oracle.dss.util.gui.component.tree.CheckTree;
import oracle.dss.util.gui.component.tree.Checkable;


/**
 * <pre>
 * Member specific implementation of the <code>TreeListComboBoxModel</code>.
 * </pre>
 * 
 * @author gkellam
 * @since  11.1.1.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   07/18/07 - Remove TreeListCombo from compound datafilter.
 *    gkellam   07/15/07 - Put strings in resource files.
 *    gkellam   05/08/07 - Fix Bug 6039525 - QueryBuilder: Clicking 'Select
 *                         Item...' from 'Add Data Filter' nothing happens.
 *    gkellam   05/02/07 - Fix various TreeListCombo issues.
 *    gkellam   04/20/07 - Modify TreeListComboMembers handling.
 *    gkellam   04/18/07 - Tweak numeric item handling.
 *    gkellam   04/16/07 - Modify numeric item handling.
 *    gkellam   04/10/07 - Modify how numeric items are processed.
 *    gkellam   03/17/07 - Continue TreeListComboMembers consolidation.
 */
public class TreeListComboBoxModelMembers extends TreeListComboBoxModel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * <code>JList[]</code> index for item values, for example Products.
   */
  public static int JLIST_ITEMS = 0;

  /**
   * <code>JList[]</code> index for option values, for example More....
   */
  public static int JLIST_OPTIONS = 1;

  /**
   * The default resource bundle class used by the <code>ItemsPanel</code>.
   *
   * @status New
   */
  public static final String DEFAULT_RESOURCE_BUNDLE_CLASS = 
    "oracle.dss.datautil.gui.resource.DataUtilGUIBundle";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private JComboBox m_treeListComboMembers = null;

  private ComponentContext m_componentContext = null;

  private CheckTree m_checkTree = null;

  private ItemItemsTreeNode m_itemItemsTreeNodeRoot = null;

  /**
   * @hidden
   * 
   * The resource bundle class used by the <code>TreeListComboBoxModelMembers</code> 
   * to retrieve resources.
   *
   * @status hidden
   */ 
  protected String m_strBundleClass = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public TreeListComboBoxModelMembers (ComponentContext componentContext) {
    setComponentContext (componentContext);
    initResources();
  }

  public TreeListComboBoxModelMembers (JTree jTree, JList[] jLists) {
    super (jTree, jLists);
    initResources();
  }

  public TreeListComboBoxModelMembers (JTree jTree, JList[] jLists, ArrayList arrayListFilters) {
    super (jTree, jLists, arrayListFilters);
    initResources();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public void setComponentContext (ComponentContext componentContext) {
   m_componentContext = componentContext;
  }
  
  public ComponentContext getComponentContext() {
   return m_componentContext;
  }

  public void setItem (MDItem mdItem) {
    setClass (DataFilterUtils.getClass (mdItem), mdItem);
    /*
    setClass (DataFilterUtils.getClass (mdItem), mdItem, m_treeListComboMembers, 
      m_componentContext, m_dataFilterPanelModel);
    */
  }

  /**
   * Refresh the model.
   * 
   * @status new
   */
  public void refresh() {
    /*      
    DataFilterUtils.setCurrentMembers (m_treeListComboMembers, 
      getCurrentMembers (m_dataFilterPanelModel, true, !hasParameter()));
  
    QBUtils.updateDataFilterMembers (getComponentContext());
    */
  }

  /**
   * Retrieve the members <code>TreeListCombo</code>.
   * 
   * @status new
   */
  public void setTreeListComboMembers (JComboBox treeListComboMembers) {
    m_treeListComboMembers = treeListComboMembers;
  }

  /**
   * Retrieve the members <code>TreeListCombo</code>.
   * 
   * @status new
   */
  public JComboBox getTreeListComboMembers() {
    return m_treeListComboMembers;
  }

  /**
   * Retrieve the <code>CheckTree</code>.
   * 
   * @status new
   */
  public CheckTree getCheckTree() {
    return m_checkTree;
  }

  /**
   * Retrieve the <code>ItemItemsTreeNode</code> root.
   * 
   * @status new
   */
  public ItemItemsTreeNode getItemItemsTreeNodeRoot() {
    return m_itemItemsTreeNodeRoot;
  }

  /**
   * Retrieves the <code>String</code> resource associated with the specified
   * key.  If the specified key cannot be found, the key itself is returned.
   *
   * @return <code>String</code> representing the <code>String</code> resource 
   *         associated with the specified key.
   *
   * @status new
   */ 
  public String getResourceString (String strKey) {
    ResourceHandler resourceHandler = 
      (getComponentContext() != null) ? getComponentContext().getResourceHandler() : null;
   
    return (resourceHandler != null) ? 
      resourceHandler.getResourceString (getResourceBundleClass(), strKey) : strKey;
  }

  /**
   * Specifies the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @param strBundleClass A <code>String</code> representing the resource
   *        bundle class.
   *
   * @status new
   */ 
  public void setResourceBundleClass (String strBundleClass) {
    m_strBundleClass = strBundleClass;
  }

  /**
   * Retrieves the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @return <code>String</code> representing the resource bundle class.
   *
   * @status new
   */ 
  public String getResourceBundleClass () {
    return m_strBundleClass;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Initialize the panel resources.
   * 
   * @status hidden
   */
  protected void initResources() {
    
    // Set up the resource handler
    ResourceHandler resourceHandler = 
      (getComponentContext() != null) ? getComponentContext().getResourceHandler() : null;

    if (resourceHandler == null) {
      if (getComponentContext() != null) {
        getComponentContext().setResourceHandler (
          new ResourceHandler (DEFAULT_RESOURCE_BUNDLE_CLASS, getComponentContext().getLocale()));
      }
    }
    
    setResourceBundleClass (DEFAULT_RESOURCE_BUNDLE_CLASS);
  }

  /**
   * Specify the <code>CheckTree</code>.
   * 
   * @param checkTree A <code>CheckTree</code>.
   * 
   * @status new
   */
  protected void setCheckTree (CheckTree checkTree) {
    m_checkTree = checkTree;
  }

  /**
   * Specifiy the <code>ItemItemsTreeNode</code> root.
   * 
   * @param itemItemsTreeNodeRoot A <code>ItemItemsTreeNode</code>
   * 
   * @status new
   */
  protected void setItemItemsTreeNodeRoot ( ItemItemsTreeNode itemItemsTreeNodeRoot) {
    m_itemItemsTreeNodeRoot = itemItemsTreeNodeRoot;
  }

  protected void setClass (Class classType, MDItem mdItem) {

    if (Number.class == classType) {
      Object[] objArrayOptions = { new SelectItems (getTreeListComboMembers()) };
      addMDItemNumeric (mdItem, objArrayOptions); 
    }
    else if (String.class == classType) {
      Object[] objArrayOptions = 
        {getResourceString (DataUtilGUIBundle.TREELISTCOMBOBOXMODELMEMBERS_PARAMETER_OPTION)};
      addMDItemString (mdItem, objArrayOptions);
    }      
  }

  protected void addMDItemNumeric (MDItem mdItem, Object[] objArrayOptions) {
    
    Vector vMDItems = new Vector();
    Vector vItems = new Vector();

    /**
     * TODO:
     *   1) Retrieve current numeric DataFilter member, if any and add it to vector
     *   2) Add selected numeric DataFilter member if it isn't already in vector
     */
    if ((vMDItems != null) && (mdItem != null) && 
        (!vMDItems.contains (mdItem))) {
      vMDItems.add (mdItem);
      vItems.addElement (new JList (vMDItems));
    }

    vItems.addElement (new JList (objArrayOptions));
    
    JList[] jLists = new JList [vItems.size()];
    vItems.copyInto (jLists);
    // getTreeListComboMembers().setLists (jLists);

    ((TreeListComboBoxModel)getTreeListComboMembers().getModel()).setLists (jLists);

    getTreeListComboMembers().setModel (
       new TreeListComboBoxModel (null, jLists));

    getTreeListComboMembers().addPopupMenuListener (new PopupMenuListener() {
      public void popupMenuWillBecomeVisible (PopupMenuEvent popupMenuEvent) {
      }

      public void popupMenuWillBecomeInvisible (PopupMenuEvent popupMenuEvent) {
        // Hack for Numeric Items
        if (popupMenuEvent != null) {
          Object objSource = popupMenuEvent.getSource();
        
          if (objSource instanceof JComboBox) {

            // Set the index of the combobox based on the JList              
            updateTreeListComboMembers();    
          }
        }
      }

      public void popupMenuCanceled (PopupMenuEvent popupMenuEvent) {
      }
    });
  }

  protected void updateTreeListComboMembers() {

    // Retrieve the JLists  
    //// JList[] jLists = getTreeListComboMembers().getLists();

    JList[] jLists = 
      ((TreeListComboBoxModel)getTreeListComboMembers().getModel()).getLists();

    // Retrieve the MDItem JList
    JList jList = jLists [TreeListComboBoxModel.JLIST_ITEMS]; 

    if (jList != null) {
      Object objSelected = jList.getSelectedValue();
      
      if (objSelected != null) {
        updateTreeListComboMembers (getTreeListComboMembers(), objSelected.toString());
      }
    }
  }

  protected void addMDItemString (MDItem mdItem, Object[] objArrayOptions) {
       
    JComboBox treeListComboMembers = getTreeListComboMembers();
      
    if ((mdItem != null) && (objArrayOptions != null) && (treeListComboMembers != null)) {
      JList[] jLists = new JList[1];
      jLists[0] = new JList (objArrayOptions);

      setCheckTree (new CheckTree());
      getCheckTree().setRootVisible (false);
          
      setItemItemsTreeNodeRoot (
        new ItemItemsTreeNode (getCheckTree(), mdItem, getComponentContext()));
  
      // gek 02/28/07 Retrieve the current DataFilter, if any
      /*     
      BaseDataFilter dataFilter = dataFilterPanelModel.getDataFilter();
        if (dataFilter != null) {
          itemItemsTreeNodeRoot.addDataFilter (dataFilter);
      }
      */
     
      getCheckTree().setModel (new DefaultTreeModel (getItemItemsTreeNodeRoot()));
        
      // getTreeListComboMembers().setTree (getCheckTree());
     
      getTreeListComboMembers().addPopupMenuListener (new PopupMenuListener() {
        public void popupMenuWillBecomeVisible (PopupMenuEvent popupMenuEvent) {
        }
  
        public void popupMenuWillBecomeInvisible (PopupMenuEvent popupMenuEvent) {
          Vector vSelectedItems = getSelectedItems (getCheckTree());
          String strSelectedItems = QBUtils.getDelimitedString (vSelectedItems, ",");
           
          updateTreeListComboMembers (getTreeListComboMembers(), strSelectedItems);
        }
  
        public void popupMenuCanceled (PopupMenuEvent popupMenuEvent) {
        }
      });
  
      // treeListComboMembers.setLists (jLists);
      ((TreeListComboBoxModel)treeListComboMembers.getModel()).setLists (jLists);

      
      treeListComboMembers.setModel (
         new TreeListComboBoxModel (null, jLists));

      /*    
      treeListComboMembers.setModel (
         new TreeListComboBoxModel (getTreeListComboMembers().getTree(), jLists));
      */
      
      /*         
       if (dataFilter != null) {
         treeListComboMembers.setSelectedItem (dataFilter);
       }
     */
    }
  }

  /**
   * Update the members <code>TreeListCombo</code> using the specified text.
   * 
   * @param strText A <code>String</code> to update the <code>TreeListCombo</code> with.
   * 
   * @status new
   */
  protected static void updateTreeListComboMembers (JComboBox treeListComboMembers, String strText) {
    if (treeListComboMembers != null) {
      //// treeListComboMembers.setText (strText);
      treeListComboMembers.setSelectedItem (strText);
     
      if ((strText != null) && (strText.length() > 0)) {
        Component editorComponent = 
          treeListComboMembers.getEditor().getEditorComponent();
       
        if (editorComponent instanceof JTextField) {
          ((JTextField)editorComponent).setText (strText);
        }
      }
    }
  }

  private static Vector getSelectedItems (JTree jTree) {
    Vector vobjSelectedItems = new Vector();
     
    if (jTree != null) {
      TreeModel treeModel = jTree.getModel();
  
      if (treeModel instanceof DefaultTreeModel) {
        Object object = ((DefaultTreeModel)treeModel).getRoot();
         
        if (object instanceof DefaultMutableTreeNode) {
          for (Enumeration enumeration = 
              ((DefaultMutableTreeNode)object).preorderEnumeration(); enumeration.hasMoreElements(); ) {
            object = enumeration.nextElement();
             
            if ((object instanceof Checkable) && ((Checkable)object).isChecked()) {
              object = ((DefaultMutableTreeNode)object).getUserObject();
               
              if (object instanceof ComponentNode) {
                vobjSelectedItems.addElement(((ComponentNode)object).getValue());
              }
            }
          }
        }
      }
    }
  
    return vobjSelectedItems;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  public class SelectItems extends Object {
    JComboBox m_treeListCombo = null;
  
    public SelectItems (JComboBox treeListCombo) {
      setTreeListCombo (treeListCombo);      
    }
  
    public String toString() {
      return getResourceString (DataUtilGUIBundle.TREELISTCOMBOBOXMODELMEMBERS_SELECT_ITEM_OPTION);
    }

    public JComboBox getTreeListCombo() {
      return m_treeListCombo;
    }

    public void setTreeListCombo (JComboBox treeListCombo) {
      m_treeListCombo = treeListCombo;
    }
  }
}
