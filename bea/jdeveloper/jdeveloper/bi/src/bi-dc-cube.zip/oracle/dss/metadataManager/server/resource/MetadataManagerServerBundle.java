/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.server.resource;

// Imports
import java.util.ListResourceBundle;

/**
 * @hidden
 * @status documented
 */
public class MetadataManagerServerBundle extends ListResourceBundle
{
    // MetadataManager Server messages have been assigned a range from
    // DVT-10500 to DVT-10599.
    // MetadataManager messages start at DVT-10100
    public static final String EXC_INSTANTIATION            = "10500";
    public static final String EXC_ILLEAGAL_ACCESS          = "10501";
    public static final String EXC_DRIVER_NOT_FOUND         = "10502";
    public static final String EXC_ILLEGAL_PROPERTY         = "10503";
    public static final String EXC_NO_JDBC_CONNECTION       = "10504";
    
    static final Object[][] ServerResources =  {
        /**
         * @error DVT-10500 <code>MetadataManager</code> driver cannot be instantiated.
         * @cause A failure occurred while creating an instance of the <code>MetadataManager</code> driver.
         *  The failure can happen only if the <code>MetadataManager</code> drivers are interfaces or are abstract classes.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_INSTANTIATION, "MetadataManager driver cannot be instantiated." },
        /**
         * @error DVT-10501 illegal attempt to access the MetadataManager driver
         * @cause A failure occurred while creating an instance of the <code>MetadataManager</code> driver.
         *   The failure can happen only if the <code>MetadataManager</code> drivers are not public or are not in the <code>MetadataManager</code> package.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_ILLEAGAL_ACCESS, "illegal attempt to access the MetadataManager driver" },
        /**
         * @error DVT-10502 <code>MetadataManager</code> driver is not found.
         * @cause A failure occurred while creating an instance of the <code>MetadataManager</code> driver.
         *  The failure can happen only if the necessary jar files are not referenced in the CLASSPATH setting.
         * @action Ensure that all necessary classes are included in the CLASSPATH setting.
         * @status documented
         */
        { EXC_DRIVER_NOT_FOUND, "MetadataManager driver is not found." },
        /**
         * @error DVT-10503 User cannot set the specified property.
         * @cause An attempt was made to set a property other than <code>Label</code> on the
         *        <code>MeasureDimension MDObject</code>.
         * @action Ensure that only the <code>Label</code> property is set on the <code>MeasureDimension MDObject</code>.
         * @status documented
         */
        { EXC_ILLEGAL_PROPERTY, "User cannot set the specified property: {0}." },
        /**
         * @error DVT-10504 <code>MetadataManager</code> cannot retrieve the OracleConnection.
         * @cause The <code>MetadataManager</code> could not retrieve the OracleConnection.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_NO_JDBC_CONNECTION, "MetadataManager cannot retrieve the OracleConnection." }
   	};

   /**
    * Return the string resource table.
    *
    * @status protected
    */
    protected Object[][] getContents()
    {
  	    return ServerResources;
    }
}