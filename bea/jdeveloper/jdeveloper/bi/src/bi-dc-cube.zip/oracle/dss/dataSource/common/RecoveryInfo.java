/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */
package oracle.dss.dataSource.common;

/**
 * Encapsulates information about load failures found by the call
 * to the <code>recover</code> method.
 *
 * @status New
 */
public class RecoveryInfo extends Object 
{
    /**
     * No issues were found: the query loaded successfully
     * 
     * @status New
     */
    public static final int NOERROR                 = -1;

    /**
     * One or more non-calculation measures were invalid.
     * 
     * @status New
     */
    public static final int BADMEASURE              = 0;

    /**
     * One or more calculations could not be loaded or were
     * invalid.
     * 
     * @status New
     */
    public static final int BADCALC                 = 1;

    /**
     * One or more dimensions were invalid.
     * 
     * @status New
     */
    public static final int BADDIMENSION            = 2;

    /**
     * One or more hierarchies were invalid.
     * 
     * @status New
     */
    public static final int BADHIERARCHY            = 3;

    /**
     * One or more levels were invalid.
     * 
     * @status New
     */
    public static final int BADLEVEL                = 4;

    /**
     * One or more attributes were invalid.
     * 
     * @status New
     */
    public static final int BADATTRIBUTE            = 5;

    /**
     * One or more indeterminate metadata IDs were invalid.
     * 
     * @status New
     */
    public static final int BADMETADATA             = 6;

    /**
     * A saved selection was invalid.  If <code>
     * fix</code> was requested, then the query was
     * updated by removing the bad saved selection
     * step from the overall dimension selection.
     * 
     * @status New
     */
    public static final int BADSAVEDSEL             = 7;

   /**
    * A saved selection was invalid.  If <code>
    * fix</code> was requested, then the query was
    * updated by rerunning with a default selection
    * for the dimension in question.
    * 
    * @status New
    */
    public static final int BADSAVEDSELDEF          = 8;


    /**
     * Unknown error code
     * 
     * @status New
     */
    public static final int UNKNOWN                 = 9;
    
    // Instance variables
    
    /**
     * @hidden
     * Error code
     */
    protected int m_code = -1;
    
    /**
     * @hidden
     * IDs causing failure.
     */
    protected String[] m_ids = null;
    
    /**
     * @hidden
     * Labels that go with the IDs causing failure, if known
     */
    protected String[] m_labels = null;
    
    /**
     * @hidden
     * Dimension IDs causing null status, if requested and if any
     */
    protected String[] m_nullIds = null;
    
    /**
     * @hidden
     * Labels that go with the IDs causing null status
     */
    protected String[] m_nullLabels = null;
    
    /**
     * @hidden
     * Was the problem fixed if so requested?
     */
    protected boolean m_fixed = false;

    /**
     * @hidden
     * Construct a RecoveryInfo object.
     * 
     * @param code  Error code found.
     * @param ids   List of IDs found to cause the failure, if any.
     * @param labels List of labels that go with the ids found to cause the failure, if available
     * @param nullIds List of dimension IDs found to have no data in status, if any, and if the check was requested.
     * @param nullLabels List of labels corresponding to the nullIds, if any
     * @param fixed Was the query fixed, if requested and if possible?
     */
    public RecoveryInfo(int code, String[] ids, String[] labels, String[] nullIds, String[] nullLabels, boolean fixed)
    {
        super();
        m_code = code;
        m_ids = ids;
        m_labels = labels;
        m_fixed = fixed;
        m_nullIds = nullIds;
        m_nullLabels = nullLabels;
    }

    /**
     * @hidden
     * Construct a RecoveryInfo object.
     * 
     * @param code  Error code found.
     */
    public RecoveryInfo(int code)
    {
        this(code, null, null, null, null, true);
    }

    /**
     * @hidden
     * Construct a RecoveryInfo object.
     * 
     * @param code  Error code found.
     * @param ids   List of IDs found to cause the failure, if any.
     * @param labels List of labels that go with the ids found to cause the failure, if available
     */
    public RecoveryInfo(int code, String[] ids, String[] labels)
    {
        this(code, ids, labels, null, null, true);
    }
    
    /**
     * Retrieves the metadata IDs found to cause the load failure,
     * if any.
     *
     * @return  The list of IDs.
     */
    public String[] getIDs()
    {
        return m_ids;
    }

    /**
     * Retrieves the metadata labels that go with the IDs found to cause the load failure,
     * if available.
     *
     * @return  The list of labels.
     */
    public String[] getLabels()
    {
        return m_labels;
    }

    /**
     * Retrieves the dimension IDs found to cause null status, if requested and if any.
     *
     * @return  The list of IDs.
     */
    public String[] getNullIDs()
    {
        return m_nullIds;
    }

    /**
     * Retrieves the dimension labels that go with the IDs found to cause null status,
     * if available and if requested.
     *
     * @return  The list of labels.
     */
    public String[] getNullLabels()
    {
        return m_nullLabels;
    }

    /**
     * Retrieves one of the error codes defined by
     * <code>RecoverInformation</code>.  If no error
     * occurred, <code>NOERROR</code> is returned.
     *
     * @return error code
     */
    public int getErrorCode()
    {
        return m_code;
    }

    /**
     * If <code>fix</code> was <code>true</code>,
     * was the Query modification successful?
     *
     * @return <code>true</code> if the Query believes the
     *         requested modification to be successful.
     *         If no fix was requested and there was an error,
     *         <code>false</code> is returned.
     *         <code>true</code> is also returned if there was
     *         no error to fix.  Returns <code>true</code>
     *         if only null status was found.
     */
    public boolean isFixed()
    {
        return m_fixed;
    }
}
