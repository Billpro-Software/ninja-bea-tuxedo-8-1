/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports

import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.MDU;

import oracle.dss.util.ErrorHandler;
import oracle.dss.util.Utility;

import java.util.Hashtable;
import java.util.Vector;

/**
 * A client-side representation of a dimension in an analytic workspace.
 * An <code>MDDimension</code> provides, to a java client, information about
 * a dimension in the workspace.
 * <P>
 * An OLAP dimension is a structure that categorizes data.
 * For example, in analyzing Sales data, typical dimensions would be
 * Product, Time, and Geography.
 * <P>
 * As an <code>MDFolder</code>, an <code>MDDimension</code> can contain
 * other <code>MDObjects</code>.
 * An <code>MDDimension</code> can contain <code>MDAttribute</code> objects
 * and <code>MDHierarchy</code> objects.
 *
 * @see MDAttribute
 * @see MDHierarchy
 *
 * @status Reviewed
 */
public class MDDimension extends MDFolder {

    /**
     * @hidden
     * Constructor.
     * Application developers should never construct an <code>MDDimension</code>.
     * The dimensions are actually defined in the analytic workspace on the
     * server.
     * You cannot use the MetadataManager to create dimensions in the
     * workspace.
     * <P>
     * To find the <code>MDDimension</code> that you want, call the
     * <code>getDimension</code> or <code>getDimensions</code> method of another
     * object.
     * For example, to retrieve the dimension for which a <code>Selection</code>
     * defines selected members, call the <code>Selection.getDimension</code>
     * method.
     * To find the dimensions of a measure, call
     * <code>MDMeasure.getDimensions</code>.
     *
     * @see MDMeasure#getDimensions
     * @see oracle.dss.selection.Selection#getDimension
     *
     * @status hidden
     */
    public MDDimension(){
        setObjectType(MM.DIMENSION);
    }

     /**
     *
     * @hidden
     *
     */
    public MDDimension( MetadataManagerServices mmServices,
                        String                  dimensionName,
                        MDObject                parent,
                        Hashtable               env,
                        ErrorHandler            handler )
    {
        super( mmServices, dimensionName, parent, env, handler );
        setObjectType(MM.DIMENSION);
    }

  	/**
     * Retrieves the folder that contains this <code>MDDimension</code>.
     *
     * @return The folder that contains this <code>MDDimension</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDFolder getFolder() throws MetadataManagerException {
  		MDObject parent = getParent();
  		if ( (parent != null) && (parent instanceof MDFolder) ) {
  			return (MDFolder)parent;
  		}
  		return null;
  	}
    
  	/**
     * Retrieves the <code>MDFolder</code> objects that this
     * this <code>MDDimension</code> uses.
     *
     * @return The folders that this dimension uses.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDFolder[] getFolders() throws MetadataManagerException {
  		Vector folders = new Vector();
  		MDFolder parent = getFolder();
  		if (parent != null) {
  			folders.addElement(parent);
  		}
  		MDFolder[] relatives = MDFolder.getFolderArray(getRelatives(MM.FOLDER));
  		if (relatives != null) {
  			for (int i=0; i<relatives.length; i++) {
  				folders.addElement(relatives[i]);
  			}
  		}
  		return (MDFolder[])Utility.copyVectorToArray(folders);
  	}

     /**
     *
     * @hidden
     *
     */
  	public int setFolder(MDFolder folder) throws MetadataManagerException {
  		if (getParent() == null) {
  			return setParent(folder);
  		}
  		else {
  			return setRelative(folder, MM.FOLDER);
  		}
  	}

	/**
     * Retrieves the <code>MDMeasure</code> objects that are dimensioned by
     * this <code>MDDimension</code>.
     *
     * @return The measures that are dimensioned by this dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDMeasure[] getMeasures() throws MetadataManagerException {
		  return MDMeasure.getMeasureArray(getRelatives(MM.MEASURE));
  	}

     /**
     *
     * @hidden
     *
     */
  	public int setMeasures(MDMeasure[] measures) {
  		if ( (measures == null) || (measures.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<measures.length; i++) {
  			setRelative(measures[i], MM.MEASURE);
  		}
  		return MDU.SUCCESS;
  	}

  	/**
     * Retrieves the <code>MDAttribute</code> objects that have been defined for
     * this <code>MDDimension</code>.
     *
     * @return The attributes for this dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDAttribute[] getAttributes() throws MetadataManagerException {
  		PropertyBag propertyBag = new PropertyBag();
  		propertyBag.setStrPropertyValue(MM.ATTRIBUTE_TYPE, MM.DIMENSIONAL_ATTRIBUTE, MDU.UI_NONE);
		return MDAttribute.getAttributeArray(getChildren(MM.ATTRIBUTE, propertyBag));
  	}
  
     /**
     *
     * @hidden
     *
     */
  	public int setAttributes(MDAttribute[] attributes) {
  		if ( (attributes == null) || (attributes.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<attributes.length; i++) {
  			setChild(attributes[i], MM.ATTRIBUTE);
  		}
  		return MDU.SUCCESS;
  	}

	/**
     * Retrieves the <code>MDHierarchy</code> objects that have been defined for
     * this <code>MDDimension</code>.
     *
     * @return The hierarchies that are defined for this dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDHierarchy[] getHierarchies() throws MetadataManagerException {
		  return MDHierarchy.getHierarchyArray(getChildren(MM.HIERARCHY));
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setHierarchies(MDHierarchy[] hierarchies) {
  		if ( (hierarchies == null) || (hierarchies.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<hierarchies.length; i++) {
  			setChild(hierarchies[i], MM.HIERARCHY);
  		}
  		return MDU.SUCCESS;
  	}

     /**
     *
     * @hidden
     *
     */
    public int setHierarchy(MDHierarchy hierarchy) {
      if (hierarchy == null)
        return MM.FAILURE;
      return setChild( hierarchy, MM.HIERARCHY);
    }

    /**
     * Retrieves the default hierarchy for this <code>MDDimension</code> object.
     *
     * @return The <code>MDHierarchy</code> that represents default hierarchy
     *          for this dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDHierarchy getDefaultHierarchy() throws MetadataManagerException {
		  return (MDHierarchy)getFirstRelative(MM.DEFAULT_HIERARCHY);
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setDefaultHierarchy(MDHierarchy defaultHierarchy) {
  		if (defaultHierarchy == null) {
  			return (MDU.FAILURE);
  		}
  		return setRelative( defaultHierarchy, MM.DEFAULT_HIERARCHY );
  	}
  	
	/**
     * Retrieves the short labels of the members
     * of this <code>MDDimension</code> object.
     *
     * @return The metadata that contains the short labels of the members.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDMemberMetadata getMemberShortLabelMetadata() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.MEMBER_SHORT_LABEL_METADATA);
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setMemberShortLabelMetadata(MDMemberMetadata memberShortLabelMetadata) {
  		if (memberShortLabelMetadata == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(memberShortLabelMetadata, MM.MEMBER_SHORT_LABEL_METADATA);
  	}

	/**
     * Retrieves the long labels of the members
     * of this <code>MDDimension</code> object.
     *
     * @return The metadata that contains the long labels of the members.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Documented
     */
  	public MDMemberMetadata getMemberLongLabelMetadata() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.MEMBER_LONG_LABEL_METADATA);
  	}

     /**
     *
     * @hidden
     *
     */
  	public int setMemberLongLabelMetadata(MDMemberMetadata memberLongLabelMetadata) {
  		if (memberLongLabelMetadata == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(memberLongLabelMetadata, MM.MEMBER_LONG_LABEL_METADATA);
  	}
  
  	/**
     * Retrieves the short plural label for this <code>MDDimension</code>.
     *
     * @return The short plural label, such as "Products".
     *
     * @status Reviewed
     */
    public String getShortPluralLabel() {
        String _str = getStrPropertyValue(MM.SHORT_PLURAL_LABEL);
        if(_str == null || _str.equals(""))
            _str = getStrPropertyValue(MM.LONG_PLURAL_LABEL);
        return _str;
    }
  
    /**
     *
     * @hidden
     *
     */
  	public int setShortPluralLabel(String shortPluralLabel) {
  		if (shortPluralLabel == null) {
  			return MDU.FAILURE;
  		}
  		setStrPropertyValue(MM.SHORT_PLURAL_LABEL, shortPluralLabel, MDU.UI_ALL);
  		return MDU.SUCCESS;
  	}

   	/**
     * Retrieves the long plural label for this <code>MDDimension</code>.
     *
     * @return The long plural label, such as "Products in Inventory".
     *
     * @status Reviewed
     */
    public String getLongPluralLabel() {
        String _str = getStrPropertyValue(MM.LONG_PLURAL_LABEL);
        if(_str == null || _str.equals(""))
            _str = getStrPropertyValue(MM.SHORT_PLURAL_LABEL);
        return _str;
    }

    /**
     *
     * @hidden
     *
     */
  	public int setLongPluralLabel(String longPluralLabel) {
  		if (longPluralLabel == null) {
  			return MDU.FAILURE;
  		}
  		setStrPropertyValue(MM.LONG_PLURAL_LABEL, longPluralLabel, MDU.UI_ALL);
  		return MDU.SUCCESS;
  	}
  
  	/**
     * @hidden
     * Retrieves the value format for this <code>MDDimension</code>.
     *
     * @return The format string for this dimension.
     *
     * @status hidden
     */
  	public String getValueFormat() {
		return getStrPropertyValue(MM.FORMAT);
  	}
  
     /**
     *
     * @hidden
     *
     */
  	public int setValueFormat(String valueFormat) {
  		if (valueFormat == null) {
  			return MDU.FAILURE;
  		}
  		setStrPropertyValue(MM.FORMAT, valueFormat, MDU.UI_ALL);
  		return MDU.SUCCESS;
  	}

    /**
     * Retrieves the data type for this <code>MDDimension</code>.
     *
     * @return A constant that represents the data type.
     * The valid constants are listed in the See Also section.
     *
     * @see MM#BOOLEAN
     * @see MM#SHORT
     * @see MM#INTEGER
     * @see MM#LONG
     * @see MM#FLOAT
     * @see MM#DOUBLE
     * @see MM#STRING
     *
     * @status Reviewed
     */
  	public String getDataType() {
		return getStrPropertyValue(MM.DATA_TYPE);
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setDataType(String dataType) {
	    if ((dataType != MM.BOOLEAN) && (dataType != MM.SHORT) &&
	        (dataType != MM.INTEGER) && (dataType != MM.LONG) &&
	        (dataType != MM.FLOAT) && (dataType != MM.DOUBLE) &&
	        (dataType != MM.STRING)) {
	    	return MDU.FAILURE;
		}
  		setStrPropertyValue(MM.DATA_TYPE, dataType, MDU.UI_ALL);
		return MDU.SUCCESS;
  	}
  
    /**
     * @hidden
     * Retrieves the type for this <code>MDDimension</code> object.
     *
     * @return A String that represents the type.
     *
     * @see oracle.dss.metadataManager.common.MM#TIME_DIMENSION
     * @see oracle.dss.metadataManager.common.MM#SPATIAL_DIMENSION
     * @see oracle.dss.metadataManager.common.MM#LINE_DIMENSION
     *
     * @status hidden
     */
    public String getDimensionType() {
        return getStrPropertyValue(MM.DIMENSION_TYPE);
    }
	
    /**
     *
     * @hidden
     *
     */
	public int setDimensionType(String strDimensionType) {
  		if (strDimensionType == null) {
  			return MDU.FAILURE;
  		}
  		setStrPropertyValue(MM.DIMENSION_TYPE, strDimensionType, MDU.UI_ALL);
  		return MDU.SUCCESS;
	}
	
    /**
     * Determine whether a dimension is a Time dimension.
     *
     * @return true if the dimension is a Time dimension, false otherwise.
     *
     * @status Documented
     */
	public boolean isTimeDimension() {
		String strType = getDimensionType();
		if (strType != null) {
			return strType.equals(MM.TIME_DIMENSION);
		}
		return false;
	}

    /**
     * Retrieves the endDate attribute for this <code>MDDimension</code> object.
     *
     * @return endDate attribute of a time dimension.  Null is returned
     * if this <code>MDDimension</code> object is not a time dimension.
     *
     * @status Documented
     */
    public MDAttribute getEndDate() throws MetadataManagerException
    {
        if(isTimeDimension())
        {
            Property prop = new Property();
            prop.setStrValue(MM.TIME_DIM_ATTR_TYPE, MM.END_DATE, MDU.UI_NONE);
            return (MDAttribute)getChildrenBag().getContentItem(MM.ATTRIBUTE, prop);
        }
        return null;
    }

    /**
     * Retrieves the timeSpan attribute for this <code>MDDimension</code> object.
     *
     * @return timeSpan attribute of a time dimension.  Null is returned
     * if this <code>MDDimension</code> is not a time dimension.
     *
     * @status Documented
     */
    public MDAttribute getTimeSpan() throws MetadataManagerException
    {
        if(isTimeDimension())
        {
            Property prop = new Property();
            prop.setStrValue(MM.TIME_DIM_ATTR_TYPE, MM.TIME_SPAN, MDU.UI_NONE);
            return (MDAttribute)getChildrenBag().getContentItem(MM.ATTRIBUTE, prop);
        }
        return null;
    }

    /**
     *
     * @hidden
     *
     */
  	public static MDDimension[] getDimensionArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDDimension[] dimensions = new MDDimension[objects.length];
		for (int i=0; i<objects.length ; i++) {
			dimensions[i] = (MDDimension)objects[i];
		}
		return dimensions;		
	}
 
    /**
     *
     * @hidden
     *
     */
  	public static MDDimension[] getDimensionArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDDimension[] dimensions = new MDDimension[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			dimensions[i] = (MDDimension)propertyBag[i];
		}
		return dimensions;		
  	}

    /**
     * @hidden
     */
    public MDDimensionCalc getDimensionCalcByID(String memberID) throws MetadataManagerException
    {
        if(memberID != null)
            return (MDDimensionCalc)getReferencedObject("MDC_"+memberID);
        else
            return null;
    }

    /**
     * @hidden
     */
    public void setDimensionCalcByID(String memberID, MDDimensionCalc memberCalc) throws MetadataManagerException
    {
        if(memberID != null && memberCalc != null)
            setReferencedObject("MDC_"+memberID, memberCalc);
    }
}