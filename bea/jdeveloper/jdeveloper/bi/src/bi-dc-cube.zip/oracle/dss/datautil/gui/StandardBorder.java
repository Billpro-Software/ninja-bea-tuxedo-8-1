/*
 * StandardBorder.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import javax.swing.border.EmptyBorder;

/**
 * @hidden
 */
public class StandardBorder extends EmptyBorder
{
	// The extra room around the component.
  	static private final int TOP 		= 10;
  	static private final int LEFT 		= 10;
  	static private final int BOTTOM 	= 10;
  	static private final int RIGHT 		= 10;

    /**
     * Constructor which creates a new StandardBorder.
     * 
     * @status hidden
     */
	public StandardBorder ( )
	{
		super ( TOP, LEFT, BOTTOM, RIGHT ); 
	}
}