/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/ComponentContext.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component;

import java.lang.Object;

import java.util.BitSet;
import java.util.Locale;
import java.util.Vector;

import oracle.bali.ewt.help.HelpProvider;

import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.gui.component.Size;
import oracle.dss.datautil.provider.BIProvider;
import oracle.dss.datautil.provider.DataProvider;
import oracle.dss.datautil.provider.MetadataProvider;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;

import oracle.dss.util.gui.ResourceHandler;
import oracle.dss.util.gui.context.PropertyHashtable;

import oracle.javatools.ui.search.SearchMatcher;

/**
 * <pre>
 * Defines a <code>ComponentContext</code> which contains common properties and
 * methods used by components. 
 * </pre>
 *
 * @author jramanat 
 * @since  11.0.0.0.5
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *  gkellam     08/09/07 - Add ability exclude member values.
 *  gkellam     08/08/07 - Implement Item filtering.
 *  gkellam     01/11/06 - Update component context to remove awt references. 
 *  gkellam     10/17/05 - Move some BuilderContext methods down into 
 *                         ComponentContext. 
 *  gkellam     09/29/05 - Create ResourceHandler dynamically as needed. 
 *  gkellam     09/13/05 - 
 *  jramanat    09/02/05 - Move BIProvider from BuilderContext and add 
 *                         DefaultErrorHandler 
 *  jramanat    09/01/05 - 
 *  gkellam     08/22/05 - 
 *  jramanat    08/17/05 - jramanat_component_context
 *  jramanat    08/17/05 - Creation
 */

public class ComponentContext extends PropertyHashtable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   * 
   * <code>BIProvider</code> property.
   * 
   * @status new
   */
  public static String BIPROVIDER = "BIProvider";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String DATA_PROVIDER = "DataProvider";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String DISPLAY_LABEL_TYPE = "DisplayLabelType";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String DISPLAY_MEMBER_LABEL_TYPE = "DisplayMemberLabelType";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String ERROR_HANDLER = "ErrorHandler";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String HELP_PROVIDER = "HelpProvider";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String LOCALE = "Locale";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String MAXIMUM_DROPDOWN_COUNT = "MaximumDropdownCount";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String METADATA_PROVIDER = "MetadataProvider";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String MINIMUM_SIZE = "MinimumSize";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String PARENT = "Parent";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String POSITION = "Position";

  /**
   * @hidden
   * 
   * <code>ResourceHandler</code> property.
   * 
   * @status new
   */
  public static String RESOURCE_HANDLER = "ResourceHandler";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String SIZE = "Size";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String TITLE = "Title";
  
  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String LAYOUT = "Layout";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String DEPENDENT_IDS = "DependentIDs";

  /**
   * @hidden
   * 
   * A <code>SearchMatcher</code> that can be used to filter a wide 
   * range of metadata, based on label. 
   * 
   * @status hidden
   */
  public static String SEARCH_MATCHER = "SearchMatcher";

  /**
   * @hidden
   * 
   * @status hidden
   */
  public static String EXCLUDE_NODES = "ExcludeNodes";

  /**
   * Exclude member nodes.
   * 
   * @status new
   */
	public static final int EXCLUDE_NODES_MEMBER = 0;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default <code>CompomentContext</code> constructor.
   * 
   * @status new
   */
  public ComponentContext() {
    super();
  }
  
  /**
   * <code>CompomentContext</code> constructor.
   *
   * @param objParent A <code>Object</code> which represents the arent of the 
   *        <code>Component</code>.  This is normally a <code>Dialog</code> or 
   *        <code>Window</code>, but can be null if there is no parent.
   * @param queryContext A <code>QueryContext</code> which is used to generate
   *        the underlying <code>BIProvider</code>, <code>DataProvider</code>
   *        and <code>MetadataProvider</code>.
   * @param locale The <code>Locale</code> for the resource values to retrieve.
   * 
   * @throws <code>Exception</code> if <code>BuilderContext</code> cannot be
   *         created.
   *         
   * @status new
   */
  public ComponentContext (Object objParent, QueryContext queryContext, 
                           Locale locale) throws Exception {
    super();
    initBIProvider (queryContext);
    setParent (objParent);
    setLocale (locale);
  }

  /**
   * <code>CompomentContext</code> constructor.
   *
   * @param objParent A <code>Object</code> which represents the
   *        parent of the <code>Component</code>.  This is normally a
   *        <code>Dialog</code> or <code>Window</code>, but can be null if there
   *        is no parent.
   * @param dataProvider A <code>DataProvider</code> which is used retrieve data.
   * @param metadataProvider A <code>MetadataProvider</code> which is used to retrieve
   *        metadata.
   * @param locale The <code>Locale</code> for the resource values to retrieve.
   *        
   * @status new
   */
  public ComponentContext (Object objParent, DataProvider dataProvider, 
    MetadataProvider metadataProvider, Locale locale) {
    setDataProvider (dataProvider);
    setParent (objParent);
    setMetadataProvider (metadataProvider);
    setLocale (locale);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Specifies the list of dependent IDs.
   *
   * @param vstrDependentIDs A <code>Vector</code> of <code>String</code> IDs
   *        representing a list of dependendent objects.
   *
   * @status new
   */
  public void setDependentIDs (Vector vstrDependentIDs) {
    setProperty (DEPENDENT_IDS, vstrDependentIDs);
  }
  
  /**
   * Retrieves the list of dependent IDs.
   *
   * @return <code>Vector</code> of <code>String</code> IDs representing a list 
   *         of dependendent objects.
   *
   * @status new
   */
  public Vector getDependentIDs() {
    return (Vector)getProperty (DEPENDENT_IDS);
  }

  /**
   * Specifies the type of label used when rendering metadata 
   * in the Component.
   *
   * @param  strDisplayLabelType The display label type. Valid values are
   *                             enumerations from
   *                             <code>util.LayerMetadataMap</code> such as
   *                             long, short, or medium labels.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
   *
   * @status new
   */
  public void setDisplayLabelType (String strDisplayLabelType) {
    setProperty(DISPLAY_LABEL_TYPE, strDisplayLabelType);
  }
    
  /**
   * Retrieves the type of label used when rendering metadata
   * in the Component.
   *
   * @return   The display label type. Valid values are enumerations from
   *           the <code>LayerMetadataMap</code> such as long, short, or
   *           medium labels.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
   *
   * @status new
   */
  public String getDisplayLabelType () {
    String s = (String)getProperty(DISPLAY_LABEL_TYPE);
    if (s != null) {
      s = LayerMetadataMap.LAYER_METADATA_LONGLABEL; 
      setDisplayLabelType(s);
    }
    return s;
  }
    
  /**
   * Specifies the type of label used when rendering data
   * in the Component.
   *
   * @param  strDisplayMemberLabelType The display label type. Valid values are
   *                                   enumerations from
   *                                   <code>util.MetadataMap</code> such as
   *                                   long, short, or medium labels.
   *
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
   *
   * @status Documented
   */
  public void setDisplayMemberLabelType(String strDisplayMemberLabelType) {
    setProperty(DISPLAY_MEMBER_LABEL_TYPE, strDisplayMemberLabelType);
  }
  
  /**
   * Retrieves the type of label used when rendering data
   * in the Component.
   *
   * @return   The display member label type. Valid values are enumerations from
   *           the <code>LayerMetadataMap</code> such as long, short, or
   *           medium labels.
   *
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
   *
   * @status Documented
   */
  public String getDisplayMemberLabelType() {
    String s = (String)getProperty(DISPLAY_MEMBER_LABEL_TYPE);
    if (s != null) {
      s = MetadataMap.METADATA_LONGLABEL; 
      setDisplayMemberLabelType(s);
    }
    return s;
  }

  /**
   * Specifies the <code>ErrorHandler</code> used by the Component.
   *
   * @param errorHandler The <code>ErrorHandler</code>.
   *
   * @status new
   */
  public void setErrorHandler(ErrorHandler errorHandler) {
    setProperty(ERROR_HANDLER, errorHandler);
  }
  
  /**
   * Retrieves the <code>ErrorHandler</code> used by the Component.
   *
   * @return the <code>ErrorHandler</code>.
   *
   * @status new
   */
  public ErrorHandler getErrorHandler() {
    ErrorHandler eh = (ErrorHandler)getProperty(ERROR_HANDLER);
    if (eh == null) {
      eh = new DefaultErrorHandler();
      setProperty(ERROR_HANDLER, eh);
    }
    return eh;
  }  

  /**
   * Specifies the <code>HelpProvider</code> used by the Component.
   *
   * @param helpProvider The <code>HelpProvider</code>.
   *
   * @status new
   */
  public void setHelpProvider (HelpProvider helpProvider) {
    setProperty(HELP_PROVIDER, helpProvider);
  }
  
  /**
   * Retrieves the <code>HelpProvider</code> used by the Component.
   *
   * @return the <code>HelpProvider</code>.
   *
   * @status new
   */
  public HelpProvider getHelpProvider() {
    return (HelpProvider)getProperty(HELP_PROVIDER);
  }

  /**
   * Specifies the <code>Locale</code> used by the Component.
   *
   * @param locale The <code>Locale</code>.
   *
   * @status new
   */
  public void setLocale(Locale locale) {
    setProperty (LOCALE, locale);
  }

  /**
   * Retrieves the <code>Locale</code> used by the Component.
   *
   * @return the <code>Locale</code>.
   *
   * @status new
   */
  public Locale getLocale() {
    Locale locale = (Locale)getProperty(LOCALE);
    if (locale == null) {
      locale = Locale.getDefault();
      setLocale(locale);
    }
    return locale;
  }
  
  /**
   * Specifies the maximum number of items displayed in dropdowns in the
   * Component.
   *
   * @param intMaximumDropdownCount The maximum dropdown count.
   *
   * @status new
   */
  public void setMaximumDropdownCount(int intMaximumDropdownCount) {
    setProperty(MAXIMUM_DROPDOWN_COUNT, new Integer(intMaximumDropdownCount));
  }
  
  /**
   * Retrieves the maximum number of items displayed in dropdowns in the
   * Component.
   *
   * @return the maximum dropdown count.
   *
   * @status new
   */
  public int getMaximumDropdownCount() {
    Integer intMaximumDropdownCount = (Integer)getProperty(MAXIMUM_DROPDOWN_COUNT);
    if (intMaximumDropdownCount != null) {
      return intMaximumDropdownCount.intValue();
    }
    return 10;
  }
                
  /**
   * Specifies the minimum size allowed by the Component.
   *
   * @param minimumSize The minimum size.
   *
   * @status new
   */
  public void setMinimumSize(Size minimumSize) {
    setProperty(MINIMUM_SIZE, minimumSize);
  }
  
  /**
   * Retrieves the minimum size allowed by the Component.
   *
   * @return the minimum size.
   *
   * @status new
   */
  public Size getMinimumSize() {
    return (Size)getProperty(MINIMUM_SIZE);
  }
    
  /**
   * Specifies the parent used by the <code>Component</code>. This is normally a
   * <code>Dialog</code> or <code>Window</code>, but can be null if there
   * is no parent.
   * 
   * @param objParent A <code>Object</code> representing the parent.
   *
   * @status new
   */
  public void setParent (Object objParent) {
    setProperty (PARENT, objParent);
  }
  
  /**
   * Retrieves the parent used by the <code>Component</code>.  This is normally a
   * <code>Dialog</code> or <code>Window</code>, but can be null if there
   * is no parent.
   *
   * @return <code>Object</code> representing the parent.
   *
   * @status new
   */
  public Object getParent() {
    return getProperty (PARENT);
  }
    
  /**
   * Specifies the position for this Component.  If no position is provided, the
   * Component will center relative to the specified parent.  If no parent is 
   * provided, the Component will center relative to the screen.
   *
   * @param position The position.
   *
   * @status new
   */
  public void setPosition(Size position) {
    setProperty(POSITION, position);
  }
  
  /**
   * Retrieves the position for this Component.  If no position is provided, the
   * Component will center relative to the specified parent.  If no parent is 
   * provided, the Component will center relative to the screen.
   *
   * @return the position.
   *
   * @status new
   */
  public Size getPosition() {
    return (Size)getProperty(POSITION);
  }

  /**
   * Specifies the size used by the Component.
   *
   * @param size The size.
   *
   * @status new
   */
  public void setSize(Size size) {
    setProperty(SIZE, size);
  }
  
  /**
   * Retrieves the size used by the Component.
   *
   * @return the size.
   *
   * @status new
   */
  public Size getSize() {
    Size size = (Size)getProperty (SIZE);
    
    if (size == null) {
      size = new Size (795, 530);
      setSize (size);
    }
    
    return size;
  }

  /**
   * Specifies the title used by the Component.
   *
   * @param strTitle The title.
   *
   * @status new
   */
  public void setTitle(String strTitle) {
    setProperty(TITLE, strTitle);
  }
  
  /**
   * Retrieves the title used by the Component.
   *
   * @return the title.
   *
   * @status new
   */
  public String getTitle() {
    return (String)getProperty(TITLE);
  }

  /**
   * Specifies the <code>DataProvider</code> used by the <code>BIProvider</code>. 
   * The <code>DataProvider</code> is an interface that defines all the methods used
   * by the <code>BIProvider</code to retrieve data (e.g. all the members for �Time�). 
   *
   * @param dataProvider A <code>DataProvider</code>.
   *
   * @status new
   */
  public void setDataProvider (DataProvider dataProvider) {
    setProperty (DATA_PROVIDER, dataProvider);
  }

  /**
   * <pre>
   * Retrieves the <code>DataProvider</code> used by the <code>BIProvider</code>. 
   *
   * The <code>DataProvider</code> is an interface that defines all the methods used
   * by the <code>BIProvider</code> to retrieve data (e.g. all the members for �Time�). 
   * Retrieves a <code>DataProvider</code> used to retrieve data.
   * 
   * By default, one is created if it does not yet exist.
   * </pre>
   * 
   * @return <code>DataProvider</code> used to retrieve data.
   * 
   * @status new
   */ 
  public DataProvider getDataProvider() {
    DataProvider dataProvider = (DataProvider)getProperty (DATA_PROVIDER);
    
    if (dataProvider == null) {
      dataProvider = (getBIProvider() != null) ? getBIProvider().makeDataProvider() : null;
      setDataProvider (dataProvider);
    }
    
    return dataProvider;
  }

  /**
   * Specifies the <code>MetadataProvider</code> used by the <code>BIProvider</code>.  
   * The <code>MetadataProvider</code> is an interface that defines all the methods
   * used by the <code>BIProvider</code to retrieve metadata (e.g. all the datasources). 
   *
   * @param metadataProvider A <code>MetadataProvider</code>.
   *
   * @status new
   */
  public void setMetadataProvider (MetadataProvider metadataProvider) {
    setProperty (METADATA_PROVIDER, metadataProvider);
  }
  
  /**
   * <pre>
   * Retrieves the <code>MetadataProvider</code> used by the <code>BIProvider</code>.  
   * 
   * The <code>MetadataProvider</code> is an interface that defines all the methods
   * used by the <code>BIProvider</code to retrieve metadata (e.g. all the datasources). 
   * Retrieves a <code>MetadataProvider</code> used to retrieve metadata.
   * 
   * By default, one is created if it does not yet exist.
   * </pre>
   * 
   * @return <code>MetadataProvider</code> used to retrieve metadata.
   * 
   * @status new
   */ 
  public MetadataProvider getMetadataProvider() {
    MetadataProvider metadataProvider = 
      (MetadataProvider)getProperty(METADATA_PROVIDER);
   
   if (metadataProvider == null) {
     metadataProvider = (getBIProvider() != null) ? getBIProvider().makeMetadataProvider() : null;
     setMetadataProvider (metadataProvider);
   }
  
   return metadataProvider;
  }
  
  /**
   * @hidden
   * 
   * Specifies the <code>BIProvider</code> used for retrieving data.
   * 
   * @status new
   */
  public void setBIProvider (BIProvider biProvider) {
    setProperty (BIPROVIDER, biProvider);
  }

  /**
   * @hidden
   * 
   * Retrieves the <code>BIProvider</code> used for retrieving data..
   * 
   * @status new
   */
  public BIProvider getBIProvider() {
    return (BIProvider) getProperty (BIPROVIDER);
  }

  /**
   * Specifies the <code>ResourceHandler</code> used by the Component.
   *
   * @param resourceHandler The <code>ResourceHandler</code> used for resource
   *        handling.
   *
   * @status new
   */
  public void setResourceHandler (ResourceHandler resourceHandler) {
    setProperty (RESOURCE_HANDLER, resourceHandler);
  }

  /**
   * Retrieves the <code>ResourceHandler</code> used by the Component.
   *
   * @return <code>ResourceHandler</code> used for resource handling.
   *
   * @status new
   */
  public ResourceHandler getResourceHandler() {
    ResourceHandler resourceHandler = 
      (ResourceHandler) getProperty (RESOURCE_HANDLER);
      
    if (resourceHandler == null) {
      resourceHandler = new ResourceHandler (getLocale());
      setResourceHandler (resourceHandler);
    }
    
    return resourceHandler;
  }

  /**
   * Allows specification of the current runtime DataSource by name.
   * 
   * @param strDataSourceName A <code>String</code> which represents the DataSource
   *        name.
   * 
   * @status new
   */
  public void setCurrentRuntimeDataSource (String strDataSourceName) {
    try {
      if (strDataSourceName != null) { 
        // gek 10/11/05: Work around bug 4616157 - Avoid OLAP attribute 
        //               searching by selecting Relational datasource.
        MetadataProvider metadataProvider = getMetadataProvider();
        if (metadataProvider != null) {
          // Attempt to specify a Relational connection root
          metadataProvider.setCurrentRuntimeDatasourceRootFolderByName (strDataSourceName);
        }
      }
    }
    
    catch (Exception exception) {
      exception.printStackTrace();  
    }
  }

  /**
   * Specifies a <code>SearchMatcher</code> that can be used to filter a wide 
   * range of metadata, based on label. 
   *
   * @param helpProvider The <code>HelpProvider</code>.
   *
   * @status new
   */
  public void setSearchMatcher (SearchMatcher searchMatcher) {
    setProperty (SEARCH_MATCHER, searchMatcher);
  }
  
  /**
   * Retrieves a <code>SearchMatcher</code> that can be used to filter a wide 
   * range of metadata, based on label. 
   *
   * @return the <code>HelpProvider</code>.
   *
   * @status new
   */
  public SearchMatcher getSearchMatcher() {
    return (SearchMatcher)getProperty (SEARCH_MATCHER);
  }

  /**
   * Specifies a <code>BitSet</code> that includes the list of node types that
   * should be excluded. 
   *
   * @param bitSetExcludeNodes A <code>BitSet</code> that includes the list of 
   *        node types that should be excluded.
   *
   * @see #EXCLUDE_NODES_MEMBER
   * 
   * @status new
   */
  public void setExcludeNodes (BitSet bitSetExcludeNodes) {
    setProperty (EXCLUDE_NODES, bitSetExcludeNodes);
  }
  
  /**
   * Retrieves a <code>BitSet</code> that includes the list of node types that
   * should be excluded. 
   *
   * @return <code>BitSet</code> that includes the list of node types that
   *         should be excluded.
   *
   * @see #EXCLUDE_NODES_MEMBER
   * 
   * @status new
   */
  public BitSet getExcludeNodes() {
    return (BitSet)getProperty (EXCLUDE_NODES);
  }

  /**
   * Retrieves whether the specified bit is set in the <code>EXCLUDE_NODES</code>
   * property. 
   *
   * @param nBitSetExcludeNodes A <code>int</code> that represents bit to check
   *        for.
   *
   * @return <code>boolean</code> that is <code>true</code> when the bit is set
   *         and <code>false</code> otherwise.
   *
   * @see #EXCLUDE_NODES_MEMBER
   * 
   * @status new
   */
  public boolean isExcludeNodes (int nBitSetExcludeNodes) {
    boolean bIsExcludeNodesSet = false;
    
    BitSet bitSetExcludeNodes = getExcludeNodes();
    if (bitSetExcludeNodes != null) {
      bIsExcludeNodesSet = bitSetExcludeNodes.get (nBitSetExcludeNodes);    
    }

    return bIsExcludeNodesSet;
  }

  /**
   * Sets the specified bit in the <code>EXCLUDE_NODES</code> property. 
   *
   * @param nBitSetExcludeNodes A <code>int</code> that represents bit to set.
   *
   * @see #EXCLUDE_NODES_MEMBER
   * 
   * @status new
   */
  public void setExcludeNodes (int nBitSetExcludeNodes) {
  
    if (getExcludeNodes() == null) {
      setExcludeNodes (new BitSet());
    }
    
    if (getExcludeNodes() != null) {
      getExcludeNodes().set (nBitSetExcludeNodes);
    }
  }

  /**
   * Initializes the <code>BIProvider</code> used for data and metadata 
   * retrieval based on a <code>QueryContext</code>.
   * 
   * @param queryContext A <code>QueryContext</code> used to create data and
   *        metadata providers.
   *        
   * @status new      
   */
  public void initBIProvider (QueryContext queryContext) {

    // Check for a non-null query
    if (queryContext != null) {
      BIProvider biProvider = 
        (getBIProvider() != null) ? getBIProvider() : new BIProvider(queryContext);

      biProvider.setQueryContext (queryContext);
      biProvider.setQueryEditor (queryContext.createQueryEditor());
      setBIProvider (biProvider);
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
