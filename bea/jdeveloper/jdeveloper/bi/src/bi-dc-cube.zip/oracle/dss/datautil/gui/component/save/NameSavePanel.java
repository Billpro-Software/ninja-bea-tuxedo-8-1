/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/save/NameSavePanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    hbroek      11/02/06 - Remove ExplorerTree reference
    gkellam     01/13/06 - Update component context to remove awt references. 
    jramanat    01/06/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/save/NameSavePanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil.gui.component.save;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.naming.NamingException;

import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import oracle.bali.ewt.dialog.JEWTDialog;

import oracle.dss.bicontext.BIContext;

import oracle.dss.datautil.gui.JTextAreaExtended;
import oracle.dss.datautil.gui.JTextFieldExtended;
import oracle.dss.datautil.gui.StandardBorder;
import oracle.dss.datautil.gui.accessible.AccessibleUtils;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.save.resource.SaveBundle;
import oracle.dss.datautil.query.DataUtils;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDRoot;

//HBR: Persistence removal
//import oracle.dss.persistence.gui.ExplorerTree;

public class NameSavePanel extends JPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Debug flag.
   * 
   * Note: Turn off for the final release build
   *
   * @status private
   */
  static private final boolean DEBUG = true;

  /**
   * The default resource bundle class used by the <code>NameSavePanel</code>.
   *
   * @status New
   */
  public static final String DEFAULT_RESOURCE_BUNDLE_CLASS = "oracle.dss.datautil.gui.component.save.resource.SaveBundle";

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * Root folder object.
   *
   * @status private
   */
  private String m_strRootFolder = null;

  /**
   * Object name label.
   *
   * @status hidden
   */
  private JLabel m_jLabelName = null;

  /**
   * Object description label.
   *
   * @status hidden
   */
  private JLabel m_jLabelDescription = null;

  /**
   * Object description scroll pane.
   *
   * @status hidden
   */
  private JScrollPane m_jScrollPanelDescription = null;

  /**
   * Object name text box.
   *
   * @status hidden
   */
  private JTextField m_jTextFieldName = null;

  /**
   * Object description text box.
   *
   * @status hidden
   */
  private JTextArea m_jTextAreaDescription = null;

  /**
   * @hidden
   *
   * The 'Save In Current Workbook' button.
   *
   * @status hidden
   */
  protected JRadioButton m_jRadioButtonSaveInCurrentWorkbook = null;

 /**
   * @hidden
   *
   * The 'Save In Folder' button.
   *
   * @status hidden
   */
  protected JRadioButton m_jRadioButtonSaveInFolder = null;

  /**
   * @hidden
   *
   * The label for the 'Save In' panel.
   *
   * @status hidden
   */
  protected JLabel m_jLabelSaveIn = null;

  /**
   * @hidden
   *
   * The listener for the 'Save In' radio buttons.
   * 
   * @status hidden
   */
  protected SaveInButtonListener m_saveInButtonListener = 
    new SaveInButtonListener();

  /**
   * @hidden
   *
   * The listener for the 'Select Folder...' radio buttons.
   * 
   * @status hidden
   */
  protected SelectFolderButtonListener m_selectFolderButtonListener = 
    new SelectFolderButtonListener();

  /**
   * @hidden
   * 
   * 'Save In' folder combo box.
   *
   * @status hidden
   */
  protected JComboBox m_jComboBoxSaveInFolder = null;

  /**
   * @hidden
   * 
   * Select Folder...' button
   *
   * @status hidden
   */
  protected JButton m_jButtonSelectFolder = null;

  /**
   * @hidden
   * Description of the object, which defaults to null.
   *
   * @status hidden
   */
  protected String m_strDescription = null;

  /**
   * @hidden
   * 
   * Autoname checkbox
   */
  protected JCheckBox m_jCheckBoxAutoName = null;

  /**
   * @hidden
   * 
   * ComponentContext
   */
  protected ComponentContext m_componentContext = null;

  /**
   * @hidden
   * 
   * ResourceBundle class
   */
  protected String m_strResourceBundleClass = DEFAULT_RESOURCE_BUNDLE_CLASS;


  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default <code>NameSavePanel</code> constructor.
   *
   * @status new
   */
  public NameSavePanel() {
    super();
  }
   
  /**
   * <code>NameSavePanel</code> constructor.
   * 
   * @param componentContext A <code>ComponentContext</code> which contains the basic
   *        building blocks required by the <code>NameSavePanel</code>.
   *
   * @status new
   */
  public NameSavePanel(ComponentContext componentContext) {
    setComponentContext(componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the ResourceBundle class for this panel
   * 
   * @param bundleClass The ResourceBundle class
   */
  public void setResourceBundleClass(String bundleClass) {
    m_strResourceBundleClass = bundleClass;
  }

  /**
   * Retrieves the ResourceBundle class for this panel
   * 
   * @return The ResourceBundle class
   */
  public String getResourceBundleClass() {
    return m_strResourceBundleClass;
  }

  /**
   * Specifies the <code>ComponentContext</code> for this panel
   * 
   * @param componentContext The <code>ComponentContext</code>
   */
  public void setComponentContext(ComponentContext componentContext) {
    m_componentContext = componentContext;
  }

  /**
   * Retrieves the <code>ComponentContext</code> for this panel
   * 
   * @return The <code>ComponentContext</code>
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }

  /**
   * Allow this instance to remove resources and any listeners it has added.
   *
   * @status new
   */
  public void cleanUp () { 
  }

  /**
  /**
   * Initializes the <code>NameSavePanel</code>.
   *
   * @status new
   */
  public void initialize() {
    setLayout(new BorderLayout());
    setBorder(new StandardBorder());

    // Add NameSavePanel
    add(getNameSavePanel(), BorderLayout.CENTER);
  }

  /**
   * Retrieves the 'Save In Folder' panel.
   *
   * @return A <code>JPanel</code> value that represents a 'Save In Folder' panel.
   *
   * @status new
   */
  public JPanel getSaveInFolderPanel() {
    JPanel jPanelSaveInFolderPanel = new JPanel(new BorderLayout());
    setSaveInFolderButton(new JRadioButton());
    getSaveInFolderButton().addActionListener(getSaveInButtonListener());
    setComboBoxSaveInFolder(new JComboBox());
    getComboBoxSaveInFolder().setEditable(true);

    jPanelSaveInFolderPanel.add(getSaveInFolderButton(), BorderLayout.WEST);
    jPanelSaveInFolderPanel.add(getComboBoxSaveInFolder(), BorderLayout.CENTER);
    return jPanelSaveInFolderPanel;
  }

  /**
   * Specifies the 'Save In Current Workbook' button.
   *
   * @param jRadioButtonSaveInCurrentWorkbook A <code>JRadioButton</code> value that 
   *        represents the 'Save In Current Workbook' button.
   *
   * @status new
   */ 
  public void setSaveInCurrentWorkbookButton (JRadioButton jRadioButtonSaveInCurrentWorkbook) {
    m_jRadioButtonSaveInCurrentWorkbook = jRadioButtonSaveInCurrentWorkbook;
  }

  /**
   * Retrieves the 'Save In Current Workbook' button.
   *
   * @return A <code>JRadioButton</code> value that represents 
   *         the 'Save In Current Workbook' button.
   *
   * @status new
   */ 
  public JRadioButton getSaveInCurrentWorkbookButton() {
    return m_jRadioButtonSaveInCurrentWorkbook;
  }
  
  /**
   * Specifies the 'Save In Folder' button.
   *
   * @param jRadioButtonSaveInFolder A <code>JRadioButton</code> value that represents 
   *         the 'Save In Folder' button.
   *
   * @status new
   */ 
  public void setSaveInFolderButton (JRadioButton jRadioButtonSaveInFolder) {
    m_jRadioButtonSaveInFolder = jRadioButtonSaveInFolder;
  }

  /**
   * Retrieves the 'Save In Folder' button.
   *
   * @return A <code>JRadioButton</code> value that represents 
   *         the 'Save In Folder' button.
   *
   * @status new
   */ 
  public JRadioButton getSaveInFolderButton() {
    return m_jRadioButtonSaveInFolder;
  }

  /**
   * Specifies the 'Save In' label.
   *
   * @param jLabelSaveIn A <code>JLabel</code> that specifies the 'Save In' 
   *        label.
   *
   * @status new
   */ 
  public void setSaveInLabel(JLabel jLabelSaveIn) {
    m_jLabelSaveIn = jLabelSaveIn;
  }

  /**
   * Retrieves the calculation type label.
   *
   * @return <code>JLabel</code> that represents the calculation type label.
   *
   * @status new
   */ 
  public JLabel getSaveInLabel() {
    return m_jLabelSaveIn;
  }

  /**
   * Specifies the 'Save In' folder.
   *
   * @param jComboBoxSaveInFolder A <code>JComboBox</code> that specifies 
   *        the 'Save In' folder.
   *
   * @status new
   */ 
  public void setComboBoxSaveInFolder(JComboBox jComboBoxSaveInFolder) {
    m_jComboBoxSaveInFolder = jComboBoxSaveInFolder;
  }
  
  /**
   * Retrieves the 'Save In' folder.
   *
   * @return <code>JComboBox</code> that represents tthat specifies 
   *        the 'Save In' folder.
   *        
   * @status new
   */ 
  public JComboBox getComboBoxSaveInFolder() {
    return m_jComboBoxSaveInFolder;
  }

  /**
   * Specifies the 'Select Folder...' button.
   *
   * @param jButtonSelectFolder A <code>JButton</code> that specifies 
   *        the 'Select Folder...' button.
   *
   * @status new
   */ 
  public void setSelectFolderButton(JButton jButtonSelectFolder) {
    m_jButtonSelectFolder = jButtonSelectFolder;
  }
  
  /**
   * Retrieves the 'Select Folder...' button.
   *
   * @return <code>JButton</code> that represents that represents 
   *        the 'Select Folder...' button.
   *        
   * @status new
   */ 
  public JButton getSelectFolderButton() {
    return m_jButtonSelectFolder;
  }

  /**
   * Specifies the 'Select Folder...' button listener.
   *
   * @param selectFolderButtonListener A <code>SelectFolderButtonListener</code> 
   *         that listens to button events.
   *
   * @status new
   */ 
  public void setSelectFolderButtonListener(SelectFolderButtonListener selectFolderButtonListener) {
    m_selectFolderButtonListener = selectFolderButtonListener;
  }

  /**
   * Retrieves the 'Select Folder...' button listener.
   *
   * @return <code>SaveInButtonListener</code> that listens to calculation type 
   *         button events.
   *
   * @status new
   */ 
  public SelectFolderButtonListener getSelectFolderButtonListener() {
    return m_selectFolderButtonListener;
  }

  /**
   * Specifies the 'Save In' button listener.
   *
   * @param saveInButtonListener A <code>SaveInButtonListener</code> 
   *         that listens to button events.
   *
   * @status new
   */ 
  public void setSaveInButtonListener(SaveInButtonListener saveInButtonListener) {
    m_saveInButtonListener = saveInButtonListener;
  }

  /**
   * Retrieves the 'Save In' button listener.
   *
   * @return <code>SaveInButtonListener</code> that listens to calculation type 
   *         button events.
   *
   * @status new
   */ 
  public SaveInButtonListener getSaveInButtonListener() {
    return m_saveInButtonListener;
  }

  /**
   * Retrieves the main panel.
   *
   * @return <code>JPanel</code> representing the save name and 
   *         description panel.
   *
   * @status new
   */
  public JPanel getNameSavePanel() {
    JPanel jPanelSaveInfo = null;

    GridBagLayout gbl = new GridBagLayout();
    jPanelSaveInfo = new JPanel();
    jPanelSaveInfo.setLayout(gbl);

    // Name Row
    setLabelName(DataUtils.getLabel(getResourceString (SaveBundle.NAME)));
    setNameTextBox(new JTextFieldExtended());
    // Associate label with combo box
    getLabelName().setLabelFor(getNameTextBox());
    addComponent(jPanelSaveInfo, getLabelName(), gbl, getLeftGridBagConstraints());
    addComponent(jPanelSaveInfo, getNameTextBox(), gbl, getCenterGridBagConstraints(false));
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getRightGridBagConstraints());

    // Autoname Row
    setAutoNameCheckBox(new JCheckBox(getResourceString(SaveBundle.AUTONAME)));
    getAutoNameCheckBox().setSelected(true);
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getLeftGridBagConstraints());
    addComponent(jPanelSaveInfo, getAutoNameCheckBox(), gbl, getCenterGridBagConstraints(false));
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getRightGridBagConstraints());

    // Description Row
    setDescriptionLabel(DataUtils.getLabel(getResourceString(SaveBundle.DESCRIPTION)));
    setDescriptionTextBox(new JTextAreaExtended());
    getDescriptionTextBox().setRows(4);
    getDescriptionTextBox().setLineWrap(true);
    getDescriptionTextBox().setFont(getNameTextBox().getFont());    
    // Associate label with calc description.
    getDescriptionLabel().setLabelFor(getDescriptionTextBox());
    m_jScrollPanelDescription = new JScrollPane(getDescriptionTextBox());
    addComponent(jPanelSaveInfo, getDescriptionLabel(), gbl, getLeftGridBagConstraints());
    addComponent(jPanelSaveInfo, m_jScrollPanelDescription, gbl, getCenterGridBagConstraints(true));
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getRightGridBagConstraints());

    ////////////////
    // Save In Rows
    ////////////////
    setSaveInLabel(DataUtils.getLabel(getResourceString(SaveBundle.SAVE_IN)));
    ButtonGroup buttonGroupSaveInOptions = new ButtonGroup();
    setSaveInCurrentWorkbookButton(DataUtils.getRadioButton(getResourceString(SaveBundle.SAVE_IN_CURRENT_WORKBOOK), LEFT_ALIGNMENT));    
    getSaveInCurrentWorkbookButton().addActionListener (getSaveInButtonListener());
    addComponent(jPanelSaveInfo, getSaveInLabel(), gbl, getLeftGridBagConstraints());
    addComponent(jPanelSaveInfo, getSaveInCurrentWorkbookButton(), gbl, getCenterGridBagConstraints(false));
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getRightGridBagConstraints());


    setSelectFolderButton(new JButton(getResourceString (SaveBundle.SELECT_FOLDER)));
    getSelectFolderButton().addActionListener (getSelectFolderButtonListener());
    addComponent(jPanelSaveInfo, new JLabel(), gbl, getLeftGridBagConstraints());
    addComponent(jPanelSaveInfo, getSaveInFolderPanel(), gbl, getCenterGridBagConstraints(false));
    addComponent(jPanelSaveInfo, getSelectFolderButton(), gbl, getRightGridBagConstraints());

    // Link together all the radio buttons.
    buttonGroupSaveInOptions.add(getSaveInCurrentWorkbookButton());
    buttonGroupSaveInOptions.add(getSaveInFolderButton());
    // Select the 'Save In Current Workbook' option by default
    getSaveInCurrentWorkbookButton().setSelected(true);
    // Associate 'Save In' label with the 'Save In Current Workbook' option
    AccessibleUtils.setLabelFor(getSaveInLabel(), getSaveInCurrentWorkbookButton(), false);
    
    return jPanelSaveInfo;
  }

  /**
   * Specifies the name label.
   *
   * @param jLabelName A <code>JLabel</code> that specifies the name label.
   *
   * @status new
   */ 
  public void setLabelName(JLabel jLabelName) {
    m_jLabelName = jLabelName;
  }
  
  /**
   * Retrieves the name label.
   *
   * @return <code>JLabel</code> that represents the name label.
   *        
   * @status new
   */ 
  public JLabel getLabelName() {
    return m_jLabelName;
  }

  /**
   * Specifies the name text box.
   *
   * @param jTextFieldName A <code>JTextFieldName</code> that specifies name text box.
   *
   * @status new
   */ 
  public void setNameTextBox(JTextField jTextFieldName) {
    m_jTextFieldName = jTextFieldName;
  }
  
  /**
   * Retrieves the name text box.
   *
   * @return <code>JTextField</code> that represents the name text box.
   *        
   * @status new
   */ 
  public JTextField getNameTextBox() {
    return m_jTextFieldName;
  }

  /**
   * Specifies the autoname checkbox.
   * 
   * @param autoName A <code>JCheckBox</code> that specifies whether or not to autoname
   */
  public void setAutoNameCheckBox(JCheckBox autoName) {
    m_jCheckBoxAutoName = autoName;
  }

  /**
   * Retrieves the autoname checkbox.
   * 
   * @return The <code>JCheckBox</code> that specifies whether or not to autoname
   */
  public JCheckBox getAutoNameCheckBox() {
    return m_jCheckBoxAutoName;
  }

  /**
   * Specifies the desription text box.
   *
   * @param jTextAreaDescription A <code>JTextArea</code> that specifies 
   *        description text box.
   *
   * @status new
   */ 
  public void setDescriptionTextBox (JTextArea jTextAreaDescription) {
    m_jTextAreaDescription = jTextAreaDescription;
  }
  
  /**
   * Retrieves the description text box.
   *
   * @return <code>JTextArea</code> that represents the description text box.
   *        
   * @status new
   */ 
  public JTextArea getDescriptionTextBox() {
    return m_jTextAreaDescription;
  }

  /**
   * Specifies the description label.
   *
   * @param jLabelDescription A <code>JLabel</code> that specifies the 
   *        description.
   *
   * @status new
   */ 
  public void setDescriptionLabel (JLabel jLabelDescription) {
    m_jLabelDescription = jLabelDescription;
  }
  
  /**
   * Retrieves the description label.
   *
   * @return A <code>JLabel</code> that specifies description label.
   *        
   * @status new
   */ 
  public JLabel getDescriptionLabel() {
    return m_jLabelDescription;
  }

  /**
   * Retrieves the saved location at the index.
   *
   * @return String object containing the saved location
   *  at the specified index.
   *
   * @status new
   */
  private String getSaveLocationAt (int nIndex) {
    String  strItem = null;

    /*
    if (nIndex > m_jComboBoxSaveFolder.getItemCount () - 1)
      return null;

    strItem = (String) m_jComboBoxSaveFolder.getItemAt (nIndex);
    if (null == strItem)
      return null;

    if (strItem.startsWith (m_strRootFolder)) {
      if (strItem.length () == m_strRootFolder.length ())
        strItem = "";
      else
        strItem = strItem.substring (m_strRootFolder.length ());
    }
    */

    return strItem;
  }

  /**
   * Validates the name of the object.
   *
   * @return <code>boolean</code> value which is <code>true</code> when the name
   *         is valid and <code>false</code> otherwise.
   * 
   * @status new
   */
  public boolean isNameValid (String strName) {
    boolean bIsNameValid = true;
    
    // Check to see if name is empty
    if (strName == null || strName.length() == 0) {
      bIsNameValid = false;
    }
  
    return bIsNameValid;
  }
  
  /////////////////////
  //
  // Public Inner Classes
  //
  /////////////////////
  
  /**
   * 'Save In' button listener class.
   * 
   * @status new
   */
  public class SaveInButtonListener implements ActionListener {
    
    /**
     * Process <code>SaveInButtonListener</code> events.
     * 
     * @param actionEvent An <code>ActionEvent</code> to process.
     * 
     * @status new
     */
    public void actionPerformed (ActionEvent actionEvent) {
      System.out.println ("SaveInButtonListener: " + actionEvent.toString());
    }
  }

  /**
   * 'Select Folder...' button listener class.
   * 
   * @status new
   */
  public class SelectFolderButtonListener implements ActionListener {
    
    /**
     * Process <code>SaveInButtonListener</code> events.
     * 
     * @param actionEvent An <code>ActionEvent</code> to process.
     * 
     * @status new
     */
    public void actionPerformed (ActionEvent actionEvent) {
      // Invoke the ExplorerTree
      MetadataManager metadataManager = 
        getComponentContext().getBIProvider().getMetadataManager();

      MDRoot mdRoot = metadataManager.getMDRoot();
      
      // displayExplorerTree (mdRoot, null, null, null);
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Provides the ability to retrieve a folder path from the <code>ExplorerTree</code>.
   *
   * @param biContext A <code>BIContext</code> object used to specify the root.
   * @param attributes A <code>Attributes</code> object used as an optional
   *        display filter.
   * @param searchControls A <code>SearchControls</code> object used as an
   *        optional search control.
   * @param strRootName A <code>String</code> representing the optional root name.       
   *
   * @return The <code>MDFolder</code> object that represents the folder
   *         object, or null.
   *
   * @throws NamingException If the folder cannot be found or created.
   *
   * @status new
   */
  protected void displayExplorerTree (BIContext biContext, Attributes attributes, 
                            SearchControls searchControls, String strRootName) {

    ComponentContext componentContext = getComponentContext();
    JEWTDialog jewtDialog = null;
    
    if (componentContext != null) {
      Component componentParent = (Component)componentContext.getParent();

      if (componentParent instanceof Dialog) {
        jewtDialog = new JEWTDialog ((Dialog)componentParent, "ExplorerTree");
      }
      else if (componentParent instanceof Frame) {
        jewtDialog = new JEWTDialog ((Frame)componentParent, "ExplorerTree");
      }
      else {
        jewtDialog = new JEWTDialog ((Frame)null, "ExplorerTree");
      }
    }
    

    //HBR: Persistence removal
    /*
    ExplorerTree explorerTree = 
      new ExplorerTree (biContext, attributes, searchControls, strRootName);
    
    JPanel jPanel = new JPanel();
    jPanel.setLayout (new BorderLayout());
    jPanel.add (new JScrollPane (explorerTree), BorderLayout.CENTER);
    
    jewtDialog.getContentPane().add (jPanel);
    */
    jewtDialog.setSize (640, 480);
    jewtDialog.setVisible (true);
  }

  /**
   * Retrieves the saved in folder at the specified index.
   * 
   * @param nIndex A <code>int</code> that represents index to retrieve the
   *        saved in folder from.
   * 
   * @return <code>String</code> that represents the saved in folder at the 
   *         specified index.
   *
   * @status hidden
   */
  protected String getSaveInFolderAt (int nIndex)	{
    String strFolder = null;

    if (getComboBoxSaveInFolder() != null) {

      if (nIndex > getComboBoxSaveInFolder().getItemCount () - 1) {
        return null;
      }   
  
      strFolder = (String) getComboBoxSaveInFolder().getItemAt (nIndex);
      if (null == strFolder) {
        return null;
      }
  
      if (strFolder.startsWith (m_strRootFolder)) {
        if (strFolder.length () == m_strRootFolder.length()) {
          strFolder = "";
        }
        else {
          strFolder = strFolder.substring (m_strRootFolder.length ());
        }
      }
    }

    return strFolder;
  }

  /**
   * @hidden
   */
  protected static GridBagConstraints getLeftGridBagConstraints() {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.anchor = GridBagConstraints.EAST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.weightx = 0;
    gbc.gridwidth = 1;
    gbc.ipadx = 10;
    return gbc;
  }

  /**
   * @hidden
   */
  protected static GridBagConstraints getCenterGridBagConstraints(boolean vertical) {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.anchor = GridBagConstraints.WEST;    
    gbc.fill = vertical ? GridBagConstraints.BOTH : GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1;
    gbc.weighty = vertical ? 1 : 0;
    gbc.gridwidth = 1;
    gbc.ipadx = 10;
    return gbc;    
  }

  /**
   * @hidden
   */
  protected static GridBagConstraints getRightGridBagConstraints() {
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.anchor = GridBagConstraints.WEST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.weightx = 0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.ipadx = 10;
    return gbc;    
  }

  String getResourceString(String strKey) {
    if (strKey != null && getResourceBundleClass() != null && getComponentContext() != null && getComponentContext().getResourceHandler() != null) {
      return getComponentContext().getResourceHandler().getResourceString(getResourceBundleClass(), strKey);
    }
    return strKey;
  }

  /**
   * Adds a component to a Panel using GridBagLayout
   */
  static void addComponent(JPanel panel, Component component, GridBagLayout gbl, GridBagConstraints gbc) {
    gbl.setConstraints(component, gbc);
    panel.add(component);
  }
  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
