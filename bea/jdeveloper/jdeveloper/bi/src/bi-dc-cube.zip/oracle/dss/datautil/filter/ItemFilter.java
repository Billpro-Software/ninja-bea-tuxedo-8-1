/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/filter/ItemFilter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.filter;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Vector;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.NamingException;

import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.BISearchResult;

// import oracle.dss.calculation.md.MDItemCalc;
import oracle.dss.dataSource.common.Query;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.SetUtils;

import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;

import oracle.dss.metadataUtil.PropertyBag;

import oracle.dss.persistence.PSRConstants;

import oracle.dss.util.ErrorHandler;

/**
 * <pre>
 * This class allows items to be filtered from DataSources and BI Catalogs 
 * based on a wide range of filtering criteria. 
 * 
 * Its primary feature is the ability to specify items and item folders that 
 * can be used to filter items based on their joinability.
 * 
 * This functionality for example, improves the usability of the BI Beans 
 * by limiting the available items based on the end user's current context.
 * 
 * Item filtering can be invoked by specifying a CalcBuilder/QueryBuilder
 * ItemFilter or directly through the ItemFilter methods (which can be used 
 * to directly retrieve items or indirectly when used as a BIFilter).
 *
 * <strong>Using ItemFilter to Retrieve Items</strong>
 * 
 *   // Static invocation example
 *   //
 *   // Retrieve the first 5 Items filtered by Query
 *   // Defaults to ALL_MDITEMS for the Object types
 *   Vector vMDItems = 
 *     ItemFilter.getMDObjects (metadataManagerServices, query, null, 5);
 *
 *   // Non-Static invocation example of previous static method call
 *   //
 *   // Retrieve the first 5 MDItems filtered by Query
 *   // Defaults to ALL_MDITEMS for the Object types
 *   ItemFilter itemFilter = new ItemFilter (query);
 *
 *   // The following call is optional if a MetadataManager has been associated 
 *   // with the Query
 *   itemFilter.setMetadataManagerServices (metadataManager);
 *   itemFilter.setCountLimit (5);
 *
 *   // Retrieve MDObjects (not recommended for large number of calculations)
 *   Vector vMDItems = itemFilter.getMDObjects();
 *
 *   // Retrieve SearchResults (recommended for large number of calculations)
 *   Vector vSearchResults = itemFilter.getSearchResults();
 *
 *   // Retrieve label from a SearchResult
 *   String strLabel = 
 *     itemFilter.getLabel ((MetadataManagerSearchResultImpl)vSearchResults.get(0),
 *       MetadataMap.METADATA_LONGLABEL);
 *     
 * <strong>Using ItemFilter as a BIFilter</strong>
 *   // Generate a default BI Filter based on the specified Query
 *   BIFilter biFilterMeasureQuery = new ItemFilter (query); 
 *     
 * <strong>Note:</strong> For performance, using SearchResults is preferable to 
 * MDObjects when processing large numbers of persisted objects such as calculations.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.16
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/02/06 - Remove CalcBuilder and olap from JDEVADF.
 *    gkellam   01/26/06 - Enhance performance. 
 *    gkellam   01/26/06 - Fix NamingException. 
 *    gkellam   01/25/06 - Work around MetadataManager/ET DataSource bug. 
 *    gkellam   01/17/06 - Check for scenario where no filtering items are 
 *                         specified. 
 *    gkellam   01/11/06 - Make sure that ResultFilter is specified. 
 *    gkellam   12/27/05 - QueryBuilder item filter integration. 
 *    gkellam   12/27/05 - Add support for item joinability filter. 
 *    gkellam   12/27/05 - Add support for item joinability filter. 
 *
 */
public class ItemFilter extends MetadataFilter {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * A <code>int</code> value used when the comparison between between the 
   * base and comparison items should be ignored.
   *
   * @status new
   */
  public final static int ITEMS_IGNORE = SetUtils.COMPARE_IGNORE;

  /**
   * <pre>
   * A <code>int</code> value used when the relationship between the base and 
   * comparison items are disjoint.
   *
   * The <code>ITEMS_DISJOINT</code>, <code>ITEMS_INTERSECTION</code>,
   * <code>ITEMS_EQUAL</code>, <code>ITEMS_SUBSET</code> and
   * <code>ITEMS_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison items are <strong>disjoint</strong>
   *   Base items         = {A, B}
   *   Comparison items   = {C, D}
   *   Intersecting items = {} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.ItemFilter#setIntersectionFilter(int)
   *
   * @status new
   */
  public final static int ITEMS_DISJOINT = SetUtils.COMPARE_DISJOINT;

  /**
   * <pre>
   * A <code>int</code> value used when the relationship between the base and 
   * comparison items represents an intersection.
   *
   * The <code>ITEMS_DISJOINT</code>, <code>ITEMS_INTERSECTION</code>,
   * <code>ITEMS_EQUAL</code>, <code>ITEMS_SUBSET</code> and
   * <code>ITEMS_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison items represent an <strong>intersection</strong>
   *   Base items         = {A, B}
   *   Comparison items   = {B, C}
   *   Intersecting items = {B} 
   *
   * </pre>
   *
   * @status new
   */
  public final static int ITEMS_INTERSECTION = SetUtils.COMPARE_INTERSECTION;

  /**
   * <pre>
   * A <code>int</code> value used when the base items is a subset of the 
   * comparison items.
   *
   * The <code>ITEMS_DISJOINT</code>, <code>ITEMS_INTERSECTION</code>,
   * <code>ITEMS_EQUAL</code>, <code>ITEMS_SUBSET</code> and
   * <code>ITEMS_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base items is a <strong>subset</strong> of the Comparison items
   *   Base items         = {A, B}
   *   Comparison items   = {A, B, C}
   *   Intersecting items = {A, B} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int ITEMS_SUBSET = SetUtils.COMPARE_SUBSET;

  /**
   * <pre>
   * A <code>int</code> value used when the Base and Comparison items are equal.
   *
   * The <code>ITEMS_DISJOINT</code>, <code>ITEMS_INTERSECTION</code>,
   * <code>ITEMS_EQUAL</code>, <code>ITEMS_SUBSET</code> and
   * <code>ITEMS_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base items is a <strong>superset</strong> of the comparison items 
   *   Base items         = {A, B, C}
   *   Comparison items   = {A, B}
   *   Intersecting items = {A, B} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int ITEMS_SUPERSET = SetUtils.COMPARE_SUPERSET;

  /**
   * <pre>
   * A <code>int</code> value used when the Base items is a superset of 
   * the Comparison items.
   *
   * The <code>ITEMS_DISJOINT</code>, <code>ITEMS_INTERSECTION</code>,
   * <code>ITEMS_EQUAL</code>, <code>ITEMS_SUBSET</code> and
   * <code>ITEMS_SUPERSET</code> values represent bitmask values that
   * may be combined together when specifying intersection filters.
   * 
   * Base and Comparison items are <strong>equal</strong>
   *   Base items         = {A, B, C}
   *   Comparison items   = {A, B, C}
   *   Intersecting items = {A, B, C} 
   *
   * </pre>
   *
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int ITEMS_EQUAL = SetUtils.COMPARE_EQUAL;

  /**
   * A <code>int</code> value used when the comparison of the base and comparison 
   * items results in any type of intersection.
   *
   * @see #ITEMS_INTERSECTION 
   * @see #ITEMS_EQUAL
   * @see #ITEMS_SUBSET
   * @see #ITEMS_SUPERSET
   * 
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int ITEMS_ANY_INTERSECTING = 
    ITEMS_INTERSECTION | ITEMS_EQUAL | 
      ITEMS_SUBSET | ITEMS_SUPERSET;

  /**
   * A <code>int</code> value used when the comparison of the base and comparison
   * items results in a set where the comparison filtering items 
   * is a subset or equal to the base items.
   *
   * @see #ITEMS_EQUAL
   * @see #ITEMS_SUBSET
   * 
   * @see oracle.dss.datautil.filter.MetadataFilter#setIntersectionFilter(int)
   * 
   * @status new
   */
  public final static int ITEMS_SUBSET_OR_EQUAL = 
    ITEMS_SUBSET | ITEMS_EQUAL;

  /**
   * A <code>String</code> array that contains all <code>MetadataManager</code>
   * item types.
   * 
   * @see oracle.dss.metadataManager.common.MM#ADMINCALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#CALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#COLUMN_ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC
   * 
   * @status new
   */
  public final static String[] MDITEMS = 
    new String[] {MM.ADMINCALCULATION_ITEM, MM.CALCULATION_ITEM, 
      MM.COLUMN_ITEM, MM.ITEM, MM.ITEM_CALC};

  /**
   * A <code>String</code> array that contains all <code>MetadataManager</code>
   * item folder object types.
   * 
   * @see oracle.dss.metadataManager.common.MM#COMPLEX_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#SQL_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#TABLE_ITEMFOLDER
   * 
   * @status new
   */
  public final static String[] MDITEM_FOLDERS = 
    new String[] {MM.ITEMFOLDER, MM.COMPLEX_ITEMFOLDER, MM.TABLE_ITEMFOLDER, 
      MM.SQL_ITEMFOLDER};

  /**
   * A <code>String</code> array that contains all <code>MetadataManager</code>
   * item and item folder object types.
   * 
   * @see oracle.dss.metadataManager.common.MM#COMPLEX_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#SQL_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#TABLE_ITEMFOLDER
   *
   * @see oracle.dss.metadataManager.common.MM#ADMINCALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#CALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#COLUMN_ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC
   * 
   * @status new
   */
  public final static String[] ALL_MDITEMS = 
    new String[] {MM.COMPLEX_ITEMFOLDER, MM.ITEMFOLDER, MM.SQL_ITEMFOLDER,
      MM.TABLE_ITEMFOLDER, MM.ADMINCALCULATION_ITEM, MM.CALCULATION_ITEM, 
        MM.COLUMN_ITEM, MM.ITEM, MM.ITEM_CALC};

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Determines whether items not meeting the search criteria are removed or
   * included but disabled.
   * 
   * For items not meeting the search criteria, if the disable filter is 
   * <code>true</code>, they are included, but marked disabled.  If 
   * <code>false</code> they are removed.
   *
   * @status hidden
   */
  private boolean m_bDisableFilter = true;

  /**
   * @hidden
   * 
   * Determines whether joinable filter is used.
   * 
   * The joinable filter only include object meeting the search criteria that
   * are joinable.
   *
   * @status hidden
   */
  private boolean m_bJoinableFilter = true;

  /**
   * @hidden
   * 
   * The item that each <code>MDObject</code> must be joinable, referenced
   * by <code>MetadataManager</code> <code>MDItem</code> ID.
   * 
   * @status hidden
   */
  private String m_strItem = null;

  /**
   * @hidden
   * 
   * A list of items that each <code>MDObject</code> must be joinable, referenced
   * by <code>MetadataManager</code> <code>MDItem</code> ID.
   *
   * @status hidden
   */
  private Vector m_vstrItems = null;

  /**
   * @hidden
   * 
   * The item folder that each <code>MDObject</code> must be joinable, referenced
   * by <code>MetadataManager</code> <code>MDItemFolder</code> ID.
   * 
   * @status hidden
   */
  private String m_strItemFolder = null;

  /**
   * @hidden
   * 
   * A list of item folders that each <code>MDObject</code> must be joinable, referenced
   * by <code>MetadataManager</code> <code>MDItemFolder</code> ID.
   *
   * @status hidden
   */
  private Vector m_vstrItemFolders = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>ItemFilter</code> constructor.
   *
   * @param componentContext A <code>ComponentContext</code> value used to 
   *        initialize the filter.
   *
   * @status New
   */
  public ItemFilter (ComponentContext componentContext) {
    super (componentContext);
  }

  /**
   * <code>ItemFilter</code> constructor.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   *
   * @status New
   */
  public ItemFilter (MetadataManagerServices metadataManagerServices) {
    super (metadataManagerServices);
    init();
  }

  /**
   * <code>ItemFilter</code> constructor.
   * 
   * Specifies the item that each item must be joinable to.
   *
   * As a result, a item will only be included if is joinable to the 
   * specified item.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param strItemID A <code>String</code> value that represents the 
   *        <code>MetadataManager</code> runtime ID of the <code>MDItem</code>
   *        which must be joinable.
   *
   * @status New
   */
  public ItemFilter (MetadataManagerServices metadataManagerServices, String strItemID) {
    super (metadataManagerServices);
    setItem (strItemID);
    init();
  }
  
  /**
   * <code>ItemFilter</code> constructor.
   *
   * Specifies the list of items that each item must be joinable to.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param vstrItemIDs A <code>Vector</code> of <code>String</code> values that 
   *        represent the <code>MetadataManager</code> runtime IDs of the 
   *        <code>MDItem</code>s which must be joinable.
   *
   * @status New
   */
  public ItemFilter (MetadataManagerServices metadataManagerServices, Vector vstrItemIDs) {
    super (metadataManagerServices);
    setItems (vstrItemIDs);
    init();
  }

  /**
   * <code>ItemFilter</code> constructor.
   *
   * Specifies the <code>Query</code> whose items are used to filter 
   * other items by joinability.
   *
   * Generally speaking, a item will only be included if it is joinable
   * to other items specified in the Query.
   *
   * The <code>ItemFilter</code> data types are automatically updated based
   * on the items in the query.
   * 
   * @param query A <code>Query</code> used to filter items by.
   *
   * @see #setDataTypes(String[])
   * 
   * @status New
   */
  public ItemFilter (Query query) {
    super (query);
    init();

    try {
      if (query != null) {
        setDataTypes (getDataTypes (getMetadataManagerServices(), query.getMeasures()));
      }
    }
    
    catch (MetadataManagerException metadataManagerException) {
      getErrorHandler().log (metadataManagerException.toString(), 
        getClass().getName(), "MetadataFilter (Query query)");
    }
  }

  /**
   * <code>ItemFilter</code> constructor. 
   * 
   * Specifies the <code>Query</code> whose items ae used is used to filter 
   * other items by joinability along with desired data types.
   *
   * Generally speaking, a item will only be included if it is joinable
   * to other items specified in the Query.
   *
   * @param query A <code>Query</code> used to filter items by.
   * @param strDataTypes A <code>String</code> array containing the object
   *        types to use.  
   *        
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#INDETERMINATE
   *
   * @see #setDataTypes(String[])
   * 
   * @status New
   */
  public ItemFilter (Query query, String[] strDataTypes) {
    super (query);
    init();
    setDataTypes (strDataTypes);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the item by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be joinable with.
   *
   * @param strItem A <code>String</code> which represents the 
   *        <code>MetadataManager</code> <code>MDItem</code> runtime ID.
   *
   * @status new
   */
  public void setItem (String strItem) {
    m_strItem = strItem;
  }

  /**
   * Retrieves the item by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be joinable with.
   *
   * @return A <code>String</code> which represents the <code>MetadataManager</code> 
   *         <code>MDItem</code> runtime ID.
   *
   * @status new
   */
  public String getItem() {
    return m_strItem;
  }

  /**
   * Specifies the filtering items to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   *
   * @param vstrItems A <code>Vector</code> of <code>MetadataManager</code>
   *        <code>MDItem</code> runtime IDs.
   *
   * @status new
   */
  public void setItems (Vector vstrItems) {
    m_vstrItems = vstrItems;
  }

  /**
   * Retrieves the filtering items to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   * 
   * This method first attempts to retrieve any items which were previously
   * specified.  If none were found, it attempts to retrieve the items
   * from those specified in the query.
   *
   * @return A <code>Vector</code> of <code>MetadataManager</code> 
   *         <code>MDItem</code> runtime IDs.
   *
   * @status new
   */
  public Vector getItems() {
    Vector vstrItems = null;
    
    // Check to see if the user has already chosen specific items
    if (m_vstrItems != null) {
      vstrItems = m_vstrItems;     
    }
    else {
      // Attempt to retrieve the items from the query
      if (getQuery() != null) {
        vstrItems = getItems (getQuery());
      }
    }

    return vstrItems;
  }

  /**
   * Specifies the item folder by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be joinable with.
   *
   * @param strItemFolder A <code>String</code> which represents the 
   *        <code>MetadataManager</code> <code>MDItem</code> runtime ID.
   *
   * @status new
   */
  public void setItemFolder (String strItemFolder) {
    m_strItemFolder = strItemFolder;
  }

  /**
   * Retrieves the item folder by which each <code>MDObject</code> or 
   * <code>SearchResult</code> must be joinable with.
   *
   * @return A <code>String</code> which represents the <code>MetadataManager</code> 
   *          <code>MDItemFolder</code> runtime ID.
   *
   * @status new
   */
  public String getItemFolder() {
    return m_strItemFolder;
  }

  /**
   * Specifies the filtering item folders to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   *
   * @param vstrItemFolders A <code>Vector</code> of <code>MetadataManager</code>
   *        <code>MDItemFolder</code> runtime IDs.
   *
   * @status new
   */
  public void setItemFolders (Vector vstrItemFolders) {
    m_vstrItemFolders = vstrItemFolders;
  }

  /**
   * Retrieves the filtering item folders to filter each <code>MDObject</code> or 
   * <code>SearchResult</code>.
   * 
   * This method first attempts to retrieve any items which were previously
   * specified.  If none were found, it attempts to retrieve the items
   * from those specified in the query.
   *
   * @return A <code>Vector</code> of <code>MetadataManager</code> item 
   *         runtime IDs.
   *
   * @status new
   */
  public Vector getItemFolders() {
    return m_vstrItemFolders;
  }

  /**
   * @hidden
   *
   * Retrieves the list of items defined by the query.
   *
   * @param query a <code>Query</code> value that contains the query used to
   *        define the list of available items.
   *
   * @return A <code>Vector</code> value that contains a list of available
   *         items.
   */
  public static Vector getItems (Query query) {

    Vector vstrItems = null;

    // Determine if a query has been specified
    if (query != null) {
      String[] strItems = query.getItems();

      // Create a list of measures to return
      if ((strItems != null) && (strItems.length > 0)){
        vstrItems = new Vector (strItems.length);
        
        for (int nIndex = 0; nIndex < strItems.length; nIndex++) {
          vstrItems.addElement (strItems[nIndex]);
        }
      }
    }

    return vstrItems;
  }

  /**
   * Specifies whether items not meeting the search criteria are removed or
   * included but disabled.
   * 
   * For items not meeting the search criteria, if the disable filter is 
   * <code>true</code>, they are included, but marked disabled.  If 
   * <code>false</code> they are removed.
   *
   * @param bDisableFilter A <code>boolean</code> value that is <code>true</code>
   *        when the results should be included but disabled and 
   *        <code>false</code> when they should be removed.
   *
   * @status New
   */
  public void setDisableFilter (boolean bDisableFilter) {
    m_bDisableFilter = bDisableFilter;
  }

  /**
   * Determines whether items not meeting the search criteria are removed or
   * included but disabled.
   * 
   * For items not meeting the search criteria, if the disable filter is 
   * <code>true</code>, they are included, but marked disabled.  If 
   * <code>false</code> they are removed.
   *
   * @param bDisableFilter A <code>boolean</code> value that is <code>true</code>
   *        when the results should be included but disabled and 
   *        <code>false</code> when they should be removed.
   *        
   * @return <code>boolean</code> value that is <code>true</code>
   *        when the results should be included but disabled and 
   *        <code>false</code> when they should be removed. 
   *        
   * @status new
   */
  public boolean isDisableFilterUsed() {
    return m_bDisableFilter;
  }

  /**
   * Specifies whether joinable filter is used.
   * 
   * The joinable filter only include object meeting the search criteria that
   * are joinable.  You can also specify the disable filter if you would prefer
   * to disable items that are not joinable instead of removing them.
   * 
   * @param bJoinableFilter A <code>boolean</code> value that is <code>true</code>
   *        when the joinable filter is used and <code>false</code> otherwise.
   *
   * @status New
   */
  public void setJoinableFilter (boolean bJoinableFilter) {
    m_bJoinableFilter = bJoinableFilter;
  }

  /**
   * Determines whether joinable filter is used.
   * 
   * The joinable filter only include object meeting the search criteria that
   * are joinable.  You can also specify the disable filter if you would prefer
   * to disable items that are not joinable instead of removing them.
   *
   * @return <code>boolean</code> value that is <code>true</code>
   *         when the joinable filter is used and <code>false</code> otherwise.
   *
   * @status New
   */
  public boolean isJoinableFilterUsed() {
    return m_bJoinableFilter;
  }

  /**
   * Determines whether the particular search result should be included in the
   * final search outcome.
   *
   * @param biSearchResult A <code>BISearchResult</code> to process to determine
   *        if it should be included in the result.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the search result
   *         should be included and <code>false</code> otherwise.
   *         
   * @status New
   */
  public boolean evaluate (BISearchResult biSearchResult) {

    boolean bInclude = true;
    MDObject mdObject = null;
    
    // Check for null search results
    if (biSearchResult == null) {
      return false;
    }

    // Items to filter joinable items by  
    Vector vstrItemIDsFilter;  
    
    // Determine items that each item must be joinable by.
    if (getItem() != null) {
      vstrItemIDsFilter = new Vector ();
      vstrItemIDsFilter.add (getItem());
    }
    else {
      vstrItemIDsFilter = getItems();
    }

    // Check to see if any item filters have been specified.
    // If not, simply return.
    if ((vstrItemIDsFilter == null) || (vstrItemIDsFilter.isEmpty())) {
      return bInclude;
    }
    
    if (biSearchResult instanceof MetadataManagerSearchResultImpl) {
      MetadataManagerSearchResultImpl mmResult = 
        (MetadataManagerSearchResultImpl) biSearchResult;

      // Retrieve the object type from the search result
      String strObjectType = mmResult.getObjectType();
   
      // Determine if we are processing a Item or Item Folder
      if (isItem (strObjectType) || isItemFolder (strObjectType)) {
        MDItem[] mdItems = null;

        try {
          // Retrieve the MDObject
          try {
            mdObject = (MDObject) mmResult.getObject();
          }
          
          catch (Exception exception) {
            // Work around MetadataManager/ET bug my retrieving MDObject by ID
            if (mdObject == null) {
              try {
                Attributes attributes = mmResult.getAttributes();
                // Attribute attribute = attributes.get (PSRConstants.Attributes.OBJECT_ID);
                Attribute attribute = attributes.get (MM.UNIQUE_ID);
                String strID = (String)attribute.get();
      
                mdObject = 
                  (MDObject) getMetadataManagerServices().getMDObjectByUniqueID (strID);
              }
              
              catch (NamingException namingException) {
                getErrorHandler().log (namingException.toString(), 
                  getClass().getName(), "evaluate (BISearchResult)");
              }
            } 
          }
          
          //// System.out.println (mdObject.toString() + " " + mdObject.getUniqueID());  
            
          // Determine if we are processing an ItemFolder
          if (isItemFolder (strObjectType)) {
            if (mdObject instanceof MDItemFolder) {
              mdItems = ((MDItemFolder)mdObject).getItems();
            }
          } 
          else {
            if (mdObject instanceof MDItem) {
              mdItems = new MDItem [1];
              mdItems[0] = (MDItem) mdObject;
            }
          }
          
          // If we can't retrieve any items, simply don't include it
          if (mdItems == null) {
            return false;
          }
          
          // Convert the MDItem objects to their associated unique IDs
          Vector vstrItemIDs = 
            new Vector (Arrays.asList (DataUtils.getUniqueIDs (mdItems)));
          
          // If a joinable filter is used, use MDItemFolders instead of 
          // MDItems for comparison
          if (isJoinableFilterUsed()) {
            // Retreive the joinable filters
            Vector vMDItemFolders = getJoinableFolders (vstrItemIDsFilter);
          
            // Convert the MDObjects to their associated unique IDs
            vstrItemIDsFilter = DataUtils.getUniqueIDs (vMDItemFolders);

            // If we are processing an item, override the default processing
            // so that we look for the item's joinable folders
            Vector vMDItems = getJoinableFolders (mdItems[0]);
            vstrItemIDs = DataUtils.getUniqueIDs (vMDItems);
          }
          
          // Determine whether this SearchResult should be included
          if (getIntersectionFilter() != ITEMS_IGNORE) {
            bInclude = isIncluded (vstrItemIDsFilter, vstrItemIDs, 
              null, getIntersectionFilter()); 
          }
        }
        
        catch (MetadataManagerException metadataManagerException) {
          getErrorHandler().log (metadataManagerException.toString(), 
            getClass().getName(), "evaluate (BISearchResult biSearchResult)");
          
          return false;
        }
      }
    }

    // Include the value, but disable it
     if (!bInclude && isDisableFilterUsed()) {
      bInclude = true;
      setEnabledProperty (biSearchResult, false);
      setEnabledProperty (mdObject, false);
    }
    
    return bInclude;
  }

  /**
   * Determines whether the specified object type represents a item.
   *
   * @param strObjectType A <code>String</code> which represents the object
   *        type to check.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the object
   *         type represents a item and <code>false</code> otherwise.
   *         
   * @status New
   */
  public boolean isItem (String strObjectType) {
    boolean bIsItem = false;

    if (MM.ITEM.equals (strObjectType)                  ||
        MM.ITEM_CALC.equals (strObjectType)             ||
        MM.CALCULATION_ITEM.equals (strObjectType)      ||
        MM.ADMINCALCULATION_ITEM.equals (strObjectType) ||
        MM.COLUMN_ITEM.equals (strObjectType)) {
      bIsItem = true;       
    }

    return bIsItem;
  }
  
  /**
   * Determines whether the specified object type represents an item folder.
   *
   * @param strObjectType A <code>String</code> which represents the object
   *        type to check.
   *                       
   * @return <code>boolean</code> value which is <code>true</code> if the object
   *         type represents an item folder and <code>false</code> otherwise.
   *         
   * @see oracle.dss.metadataManager.common.MM#COMPLEX_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#SQL_ITEMFOLDER
   * @see oracle.dss.metadataManager.common.MM#TABLE_ITEMFOLDER
   * 
   * @status New
   */
  public static boolean isItemFolder (String strObjectType) {
    boolean bIsItemFolder = false;
    
    if (MM.ITEMFOLDER.equals (strObjectType)        ||
        MM.COMPLEX_ITEMFOLDER.equals (strObjectType)||
        MM.TABLE_ITEMFOLDER.equals (strObjectType)  || 
        MM.SQL_ITEMFOLDER.equals (strObjectType)) {
      bIsItemFolder = true;       
    }
         
    return bIsItemFolder;
  }

  /**
   * Retrieves a <code>Vector</code> of <code>SearchResult</code> values based
   * on the chosen <code>ItemFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated item
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>SearchResult</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getSearchResults() throws MetadataManagerException, NamingException {
    
    long lCountLimit = getCountLimit();
    
    // Retrieve the list of search results
    Vector vSearchResults = new Vector();
    vSearchResults = getSearchResults (getFolderRoot(), getBasicAttributes(), 
      getSearchControls(), vSearchResults, lCountLimit, isFolderFilterUsed());

    // Perform post filtering processes
    vSearchResults = 
      getSearchResults (getMetadataManagerServices(), vSearchResults, 
        true, getErrorHandler());

    // Make sure that we don't return more SearchResults than the count limit
    if ((lCountLimit > -1) && (vSearchResults != null) && (vSearchResults.size() > lCountLimit)) {
      vSearchResults.setSize ((int)lCountLimit);  
    }

    return vSearchResults;
  }

  /**
   * Retrieves a <code>Vector</code> of <code>MDObject</code> values based
   * on the chosen <code>ItemFilter</code> filtering options.
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * @status new
   */
  public Vector getMDObjects() throws MetadataManagerException, NamingException {
    return getMDObjects (getSearchResults());
  }

  /**
   * Retrieves a <code>Vector</code> of <code>MDObject</code> values from the
   * underlying <code>MetadataManagerSearchResultImpl</code> 
   * <code>SearchResult</code> objects.
   *
   * @param vSearchResults A <code>Vector</code> of <code>MetadataManagerSearchResultImpl</code>
   *        SearchResults to retrieve MDObjects for.
   *
   * @return <code>Vector</code> representing the list of <code>MDObject</code> 
   *         values, if any
   *         
   * @see oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl#getMDObject()
   * 
   * @status new
   */
  static public Vector getMDObjects (Vector vSearchResults) throws NamingException { 
    Vector vMDObjects = null;
 
     // Iterate over the search results to retrieve the underlying MDObjects
    if (vSearchResults != null && !vSearchResults.isEmpty()) {
      vMDObjects = new Vector();
      
      SearchResult searchResult;
      MDObject mdObject;
      
      for (int nIndex = 0; nIndex < vSearchResults.size(); nIndex++) {
        searchResult = (SearchResult) vSearchResults.get (nIndex);
        
        if ((searchResult != null) && (searchResult instanceof MetadataManagerSearchResultImpl)) {
          mdObject = (MDObject)((MetadataManagerSearchResultImpl)searchResult).getObject();
               
          Attributes attributesSearch = searchResult.getAttributes();
          if (attributesSearch != null) {
            Attribute attribute  = attributesSearch.get (MM.ENABLED);      

            if (attribute != null) { 
              mdObject.setStrPropertyValue (attribute.getID(), (String)attribute.get().toString());
            }
          }
          
          vMDObjects.add (mdObject);
        }
      }
    }

    return vMDObjects;
  }

  /**
   * Determines whether the specified object type is being used by the filter. 
   *
   * @return A <code>boolean</code> which is <code>true</code> if the object
   *         type is being used and <code>false</code> otherwise.
   *
   * @see oracle.dss.metadataManager.common.MM#ADMINCALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#CALCULATION_ITEM
   * @see oracle.dss.metadataManager.common.MM#COLUMN_ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM
   * @see oracle.dss.metadataManager.common.MM#ITEM_CALC
   * 
   * @status new
   */
  public boolean isObjectTypeUsed (String strObjectType) {
    boolean bIsObjectTypeUsed = false;
 
    if (strObjectType != null) {   
      String[] strObjectTypes = getObjectTypes();
    
      // Iterate over all the object types looking for the one specified
      if ((strObjectTypes != null) && (strObjectTypes.length != 0)) {
        for (int nIndex = 0; nIndex < strObjectTypes.length; nIndex++) {
          if (strObjectType.equals (strObjectTypes [nIndex])) {
            bIsObjectTypeUsed = true;
            break;
          }
        }
      }
    }
  
    return bIsObjectTypeUsed;
  }

  /**
   * Determines the <code>MDItemFolder</code>s which are joinable to the 
   * specified items.
   *
   * @param vstrItemIDs A <code>Vector</code> of values that represents the 
   *        <code>MetadataManager</code> runtime IDs of the <code>MDItem</code>s
   *        which must be joinable.
   *
   * @return <code>Vector</code> of <code>MDItemFolder</code>s which are joinable. 
   * 
   * @status new
   */
  public Vector getJoinableFolders (Vector vstrItemIDs) throws MetadataManagerException {
    Vector vMDItemFolders = null;
    
    if ((vstrItemIDs != null) && (!vstrItemIDs.isEmpty())) {
      vMDItemFolders = new Vector();
      MDItemFolder[] mdItemFolders = null;
      
      Vector vMDItemFoldersCurrent;
      for (int nIndex = 0; nIndex < vstrItemIDs.size(); nIndex++) {
        vMDItemFoldersCurrent = getJoinableFolders ((String)vstrItemIDs.get (nIndex));
        
        if (vMDItemFoldersCurrent != null) {
          for (int nIndex1 = 0; nIndex1 < vMDItemFoldersCurrent.size(); nIndex1++) {
            vMDItemFolders.add (vMDItemFoldersCurrent.get (nIndex1));
          }  
        }
      }
    }
  
    return vMDItemFolders;
  }

  /**
   * Determines the <code>MDItemFolder</code>s which are joinable to the 
   * specified item.
   *
   * @param strItemID A <code>String</code> value that represents the 
   *        <code>MetadataManager</code> runtime ID of the <code>MDItem</code>
   *        which must be joinable.
   *
   * @return <code>Vector</code> of <code>MDItemFolder</code>s which are joinable. 
   * 
   * @status new
   */
  public Vector getJoinableFolders (String strItemID) throws MetadataManagerException {
    Vector vMDItemFolders = null;

    if (strItemID != null) {
      MDObject mdObject = 
        getMetadataManagerServices().getMDObjectByUniqueID (strItemID);
      
      vMDItemFolders = getJoinableFolders (mdObject); 
    }
  
    return vMDItemFolders;
  }

  /**
   * Determines the <code>MDItemFolder</code>s which are joinable to the 
   * specified item.
   *
   * @param mdObject A <code>MDObject</code> value that represents the 
   *        <code>MetadataManager</code> <code>MDItem</code>
   *        which must be joinable.
   *
   * @return <code>Vector</code> of <code>MDItemFolder</code>s which are joinable. 
   * 
   * @status new
   */
  public Vector getJoinableFolders (MDObject mdObject) throws MetadataManagerException {
    Vector vMDItemFolders = null;

    MDItemFolder[] mdItemFolders = null;
    if (mdObject instanceof MDItem) {
      
      // For MDItemCalc objects, determine joinable folders using the base
      // items.
      /* gek 11/02/06
      if (mdObject instanceof MDItemCalc) {
        Vector vMDItems = ((MDItemCalc)mdObject).getBaseItems();
        return getJoinableFolders (vMDItems);          
      }
      */

      vMDItemFolders = new Vector();
      MDObject mdObjectParent = mdObject.getParent();
      
      if (mdObjectParent instanceof MDItemFolder) {
        MDItemFolder mdItemFolder = (MDItemFolder) mdObjectParent ;
        // Add parent MDItemFolder
        vMDItemFolders.add (mdItemFolder);
      
        // Add joinable folders
        BIContext biContext = getFolderRoot();
        if (biContext instanceof MDFolder) {
          mdItemFolders = mdItemFolder.getJoinableItemFolders ((MDFolder)getFolderRoot(), true);
        }
      }
    }
    else {
      if (mdObject instanceof MDItemFolder) {
        // Add parent MDItemFolder
        vMDItemFolders.add (mdObject);

        // Add joinable Item folders
        mdItemFolders = 
          ((MDItemFolder) mdObject).getJoinableItemFolders ((MDFolder)getFolderRoot(), true);
      }
    }

    if (mdItemFolders != null) {
      // Add all other joinable MDItemFolder objects
      for (int nIndex = 0; nIndex < mdItemFolders.length; nIndex++) {
        vMDItemFolders.add (mdItemFolders[nIndex]);
      }
    }
  
    return vMDItemFolders;
  }

  /**
   * Retrieves the <code>SearchControls</code> used to determine scope of search 
   * and what gets returned.
   *
   * @return A <code>SearchControls</code> value used to determine scope of search 
   * and what gets returned.
   *
   * @status new
   */
  public SearchControls getSearchControls() {
    SearchControls searchControls = super.getSearchControls();
    
    // Add the ResultFilter if one is not already specified
    if (searchControls instanceof BISearchControls) {
      BISearchControls biSearchControls = (BISearchControls) searchControls;
  
      if (biSearchControls.getResultFilter() == null) {
        biSearchControls.setResultFilter (this);
      }
    }

    return searchControls;  
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Retrieves a <code>Vector</code> of <code>SearchResult</code> values meeting
   * the specified search criteria.
   *
   * @param biContext A <code>BIContext</code> where the search begins.  For
   *        example, a <code>MDFolder</code>.
   * @param basicAttributes A <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls A <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param vSearchResults A <code>Vector</code> of <code>SearchResult</code> 
   *        values to be recursively updated.
   * @param lCount A <code>long</code> representing the maximum number of objects
   *        to retrieve.  A value of 0 implies all values.
   *
   * @return <code>Vector</code> representing the list of available  
   *         <code>SearchResult</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * @status hidden
   */
  static protected Vector getSearchResults (BIContext biContext, 
    BasicAttributes basicAttributes, SearchControls searchControls, 
      Vector vSearchResults, long lCount) throws MetadataManagerException, NamingException {
    
    return getSearchResults (biContext, basicAttributes, searchControls, 
      vSearchResults, lCount, true);    
  }

  /**
   * Performs post search operations.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used
   *        to retrieve metadata.
   * @param vSearchResults A <code>Vector</code> of search results to process.
   * @param bAddItems A <code>boolean</code> value which is <code>true</code>
   *        when <code>MDItem</code>s meeting the search criteria should be 
   *        added to <code>MDItemFolder</code>s and <code>false</code> otherwise.
   * @param errorHandler A <code>ErrorHandler</code> used to process errors. 
   * 
   * @return <code>Vector</code> of ordered <code>MDMeasure</code> values. 
   * 
   * @status new
   */
  protected static Vector getSearchResults (MetadataManagerServices metadataManagerServices,
    Vector vSearchResults, boolean bAddItems, ErrorHandler errorHandler) throws MetadataManagerException {

    Vector vSearchResultsNew = vSearchResults;
    
    // Only update if we need to add items
    if (bAddItems) {
      if (vSearchResults != null) {
        // Determine if we need to add MDItems work around
        MetadataManagerSearchResultImpl mmResult = null;
        
        vSearchResultsNew = new Vector();
        
        Enumeration enumeration = vSearchResults.elements();
  
        while (enumeration.hasMoreElements()) {
          // Retrieve the next search result
          mmResult = (MetadataManagerSearchResultImpl) enumeration.nextElement();
          
          if (mmResult != null) {
            if (isItemFolder (mmResult.getObjectType())) {
              boolean bEnabled = getEnabledProperty (mmResult, errorHandler);
              
              // Add parent
              vSearchResultsNew.add (mmResult);
              
              // Add child items
              MDObject mdObject = (MDObject) mmResult.getObject();
              setEnabledProperty (mdObject, bEnabled);

              if (mdObject instanceof MDItemFolder) {
                MDItem[] mdItems = ((MDItemFolder)mdObject).getItems();
              
                /**
                 * Workaround for Bug 4753060: Search does not work for item object types
                 * 
                 * Iterate over each Item in the Item Folder to see if it should
                 * be included in the results.
                 */
                if ((mdItems != null) && (mdItems.length != 0)) {
                  SearchResult searchResult;
                  
                  for (int nIndex = 0; nIndex < mdItems.length; nIndex++) {

                    // Update the enabled status of each Item based on its
                    // parent ItemFolder                    
                    searchResult = getSearchResult (mdItems [nIndex]);
                    setEnabledProperty (searchResult, bEnabled);
                  }
                }
              }                
            }
            else {
              vSearchResultsNew.add (mmResult);
            }
          }
        }
      }
    }
  
    return vSearchResultsNew;
  }

  /**
   * Initializes the <code>ItemFilter</code>.
   * 
   * @status new
   */
  protected void init () {
    // Set default object types
    setObjectTypes (ALL_MDITEMS);
    
    // Set default data types
    setDataTypes (new String[] {MM.INTEGER, MM.SHORT, MM.FLOAT, MM.DOUBLE});
  }

  /**
   * Creates a <code>MetadataManagerSearchResultImpl</code> from a <code>MDObject</code>.
   * 
   * @param mdObject A <code>MDObject</code> to create 
   *        <code>MetadataManagerSearchResultImpl</code> for.
   * 
   * @return <code>MetadataManagerSearchResultImpl</code> associated with the
   *         <code>MDObject</code>.
   * 
   * @status new
   */
  protected static MetadataManagerSearchResultImpl getMetadataManagerSearchResult (MDObject mdObject) {
    MetadataManagerSearchResultImpl metadataManagerSearchResultImpl = null;
    
    if (mdObject != null) {

      Attributes attributes = null;
      PropertyBag propertyBag = mdObject.getPropertyBag();    
      if (propertyBag != null) {
        attributes = MMUtilities.propertyBagToAttributes (propertyBag);
        attributes.put (PSRConstants.Attributes.OBJECT_ID, mdObject.getUniqueID());
      }

      metadataManagerSearchResultImpl = 
        new MetadataManagerSearchResultImpl (mdObject.toString(), 
          mdObject.getClassName(), mdObject, attributes, mdObject.getObjectType(), 
            mdObject.getMetadataManagerServices());
    }
    
    return metadataManagerSearchResultImpl;
  }           

  /**
   * Specifies the enabled property value.
   * 
   * @param object A <code>Object</code> to set the enabled property on.
   * @param bEnabled A <code>boolean</code> which is <code>true</code> when
   *        the object is enabled and <code>false</code> otherwise.
   * 
   * @status new
   */
  protected static void setEnabledProperty (Object object, boolean bEnabled) {
    if (object instanceof SearchResult) {
      Attributes attributes = ((SearchResult)object).getAttributes();
      if (attributes != null) {
        attributes.put (MM.ENABLED, Boolean.valueOf (bEnabled));
      }
    }
    else {
      if (object instanceof MDObject) {
        ((MDObject)object).setStrPropertyValue (MM.ENABLED, 
          Boolean.valueOf (bEnabled).toString());
      }
    }
  } 

  /**
   * Retrieves the enabled property value.
   * 
   * @param object A <code>Object</code> to interrogate.
   * @parem errorHandler A <code>ErrorHandler</code> which is optional.
   * 
   * @return <code>boolean</code> which is <code>true</code> when
   *        the object is enabled and <code>false</code> otherwise.
   * 
   * @status new
   */
  protected static boolean getEnabledProperty (Object object, ErrorHandler errorHandler) {
    boolean bEnabled = true;

    if (object instanceof SearchResult) {
      Attributes attributesSearch = ((SearchResult)object).getAttributes();
      
      if (attributesSearch != null) {
        Attribute attribute  = attributesSearch.get (MM.ENABLED);      
        if (attribute != null) { 
          try {
            bEnabled = ((Boolean)attribute.get()).booleanValue();
          }
          
          // For now at least always enable
          catch (NamingException namingException) {
            if (errorHandler != null) {
              errorHandler.log (namingException.toString(), 
                "ItemFilter", "getEnabledProperty (Object)");
            }
          }
        }
      }
    }
    else {
      if (object instanceof MDObject) {
        MDObject mdObject = (MDObject)object;
        
        String strEnabled = 
          (mdObject.getStrPropertyValue (MM.ENABLED) != null) ?
            mdObject.getStrPropertyValue (MM.ENABLED) : Boolean.valueOf (true).toString(); 

        bEnabled = Boolean.valueOf (strEnabled).booleanValue();
      }
    }
  
    return bEnabled;
  } 

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}