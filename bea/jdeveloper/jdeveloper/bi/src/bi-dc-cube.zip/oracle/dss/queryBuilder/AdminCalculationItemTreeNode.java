/*
 * AdminCalculationItemTreeNode.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import javax.naming.directory.SearchResult;

import javax.swing.Icon;
import javax.swing.JTree;

import oracle.dss.datautil.gui.component.ComponentContext;

public class AdminCalculationItemTreeNode extends ItemsTreeNodeImpl {

    /*
     * Public
     */

    public AdminCalculationItemTreeNode(JTree tree, SearchResult sr, ComponentContext context) {
        //super(tree, sr, context);
        super(tree, QBUtils.makeComponentNode(sr, context), context);
    }
    
/*    public AdminCalculationItemTreeNode(JTree tree, MDAdminCalculationItem mdAdminCalculationItem, ComponentContext context) {
        //super(tree, mdAdminCalculationItem, context);
        super(tree, QBUtils.makeComponentNode(mdAdminCalculationItem, context), context);
    }*/
    
    public Icon getOpenIcon() {
        return m_icon;
    }
    
    public Icon getClosedIcon() {
        return getOpenIcon();
    }
        
    /*
     * Protected
     */
    
    /*
     * Private
     */
     
    private static Icon m_icon = QBUtils.getIcon(QBUtils.DATA_POINT_ICON);
}