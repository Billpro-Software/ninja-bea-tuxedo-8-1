/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.connection.common;

/**
 * Methods for listening for changes of status in a connection.
 * To listen for the status changes, implement this interface and
 * register the implementation with the connection.
 *
 * @see oracle.dss.connection.client.Connection#addListener
 *
 * @status Reviewed
 */
public interface ConnectionListener extends java.util.EventListener {

  /**
   * Responds to a request to connect.
   * This method is called before the request is processed.
   *
   * @param evt    Information about the connection request.
   *
   * @status Reviewed
   */
  public void connecting( ConnectionEvent evt );

  /**
   * Responds to a connection.
   * This method is called after the request to connect is processed.
   *
   * @param evt   Information about the connection.
   *
   * @status Reviewed
   */
  public void connected( ConnectionEvent evt );

  /**
   * Responds to a request to disconnect.
   * This method is called before a request to disconnect is processed.
   *
   * @param evt    Information about the request to disconnect.
   *
   * @status Reviewed
   */
  public void disconnecting( ConnectionEvent evt );

  /**
   * Responds to a disconnection.
   * This method is called after the request to disconnect is processed.
   *
   * @param evt   Information about the disconnection.
   *
   * @status Reviewed
   */
  public void disconnected( ConnectionEvent evt );
}