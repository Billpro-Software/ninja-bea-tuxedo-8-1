/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.client;

import java.lang.reflect.Method;
import java.util.List;
import java.util.BitSet;

import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.CB;
import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.DimTree;
import oracle.dss.dataSource.common.IllegalOperationException;
import oracle.dss.dataSource.common.InvalidMetadataException;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryState;
import oracle.dss.dataSource.common.QueryUtil2;
import oracle.dss.dataSource.common.RecoveryInfo;
import oracle.dss.datautil.QueryEditor;

import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MDObject;

import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;

import oracle.dss.util.BIBaseException;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.Operation;
import oracle.dss.util.Parameter;
import oracle.dss.util.QDR;
import oracle.dss.util.StatusInfo;
import oracle.dss.dataSource.common.QueryManagerInterface;
import oracle.dss.util.transform.BaseProjection;

/**
 * @hidden
 *
 * Common implementation of pluggable interface
 *
 * @status New
 */
public abstract class CommonQueryInterfaceImpl extends Object implements QueryInterface
{    
    protected Query m_query = null;
    
    public CommonQueryInterfaceImpl(Query query)
    {
        super();
        m_query = query;
    }
    
    public Query getQuery()
    {
        return m_query;
    }
    
    protected void apiOutput(String object, String routine)
    {
        QueryUtil2.apiOutput(m_query, "DATASERVICE", null, object, routine, null);
    }
    
    protected void apiOutput(String retVal, String object, String routine)
    {
        QueryUtil2.apiOutput(m_query, "DATASERVICE", retVal, object, routine, null);
    }

    protected void apiOutput(String retVal, String object, String routine, String[] args)
    {
        QueryUtil2.apiOutput(m_query, "DATASERVICE", retVal, object, routine, args);
    }
    
    protected void apiOutput(String object, String routine, String[] args)
    {
        QueryUtil2.apiOutput(m_query, "DATASERVICE", null, object, routine, args);
    }
    
    
    /**
     * @hidden
     * Output OLAPI trail information
     *
     */
    public static void olapiOutput(QueryState state, QueryManagerInterface qm, String msg)
    {
        if (state.getPropertySupport().getProperty(QueryConstants.PROPERTY_DEBUG_MODE).equals(new Boolean(true)))
        {
            qm.getErrorHandler().trace("OLAPI:: " + msg, "", "");
        }
    }        
    
    // javadoc from interface
    public void applyDataMap(DataMap map) throws QueryException
    {        
    }
    
    // javadoc from interface
    public Object getQueryObject()
    {
        return null;
    }
    
    // javadoc from interface
    public void applyMetadataMap(String item, MetadataMap map) throws QueryException
    {
    }

    // javadoc from interface
    public void applyMetadataMap(int edge, MetadataMap map) throws QueryException
    {
    }
    
    // javadoc from interface
    public boolean applyQueryEditor(QueryEditor qe, boolean update) throws BIBaseException
    {        
        return false;
    }

    // blm - Selection code moved to dvt-olap
/*    public BitSet applySelections(Selection[] selections) throws QueryException
    {        
        return null;    
    }
*/
    // javadoc from interface
    public Object clone() throws CloneNotSupportedException
    {        
        return null;
    }
        
    // javadoc from interface
    public void drill(String dimension, String[] target, String[] hierarchy, Integer[] delta, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {    
    }

    // javadoc from interface
    public void drill(String dimension, String[] target, String[] hierarchy, String[] level, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {    
    }
    
    // javadoc from interface
    public void drill(String item, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException
    {    
    }
    
    // javadoc from interface
    public void drill(String item, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException
    {    
    }
    
    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String dimension) throws QueryException
    {    
        return null;
    }
*/    
    // javadoc from interface
    public String getQuerySQL(int edge) throws QueryException    
    {    
        return null;
    }
    
    // javadoc from interface
    public void setCalcDefinitions(Object[] definitions) throws QueryException
    {    
    }

    // javadoc from interface
    public Object[] getCalcDefinitions()
    {    
        return null;
    }

    // javadoc from interface
    public Boolean isDependentOn(MDObject object)
    {    
        return new Boolean(false);
    }


    // javadoc from interface
    public RecoveryInfo recover(boolean fix, boolean nodata, Object specification) throws QueryException    
    {    
        return null;
    }
    

    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public BitSet removeSelection(Selection selection) throws QueryException
    {    
        return null;
    }
*/
    // javadoc from interface
    public boolean rollback() throws QueryException
    {    
        return false;
    }
    
    // javadoc from interface
    public BitSet setDataFilters(BaseDataFilter[] filters) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public BitSet setColumnSorts(ColumnSortWrapper[] sorts) throws QueryException
    {    
        return null;
    }
        
    // javadoc from interface
    public BitSet setItemSorts(ItemSortWrapper[] sorts) throws QueryException
    {    
        return null;
    }
        
    // javadoc from interface
    public void swapEdges(int source, int target) throws QueryException
    {
        // Swap the edges
        DimTree newTree = null;
        try
        {
            newTree = (DimTree)m_query._getQueryState().getDimTree().clone();
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }

        boolean bSuccess = newTree.swapEdge(source, target, true);
        String routine = "swapEdges";
        if (!bSuccess)
        {
            Parameter[] params = {new Parameter(new Integer(source), Integer.class),
                            new Parameter(new Integer(target), Integer.class)};
            throw new IllegalOperationException(m_query.getQueryManager().getResourceString("Illegal swapEdges operation"), new Operation(routine, params, true));
        }
        
        m_query._getQueryState().setDimTree(newTree);        
    }
    
    public boolean wantsData(boolean dataWanted)
    {
        return getDataItems() != null && getDataItems().length > 0 && dataWanted;
    }

    public QueryState getOldState() throws CloneException
    {
        return (QueryState)m_query._getQueryState().clone(m_query);
    }
    
    public DimTree getDimensionTree()
    {
        return m_query._getQueryState().getDimTree();
    }
    
    // blm - Selection code moved to dvt-olap
/*    public SelectionList getSelections()
    {
        return m_query._getQueryState().getSelections();
    }*/
    
    public void setDimensionTree(DimTree dimensions)
    {
        m_query._getQueryState().setDimTree(dimensions);
    }    
    
    // Return common list of current data items
    public String[] getDataItems()
    {
        return m_query.getDataItems();
    }
    
    // Determine if the query is supposed to be tabular or not
    protected boolean isTabular()
    {
        Object obj = m_query.getProperty(QueryConstants.PROPERTY_TABULAR_QUERY);
        if (obj instanceof Boolean)
            return ((Boolean)obj).booleanValue();
            
        return false;        
    }
        
    /**
     * @hidden
     */
    public String getMeasureDimension() throws InvalidMetadataException
    {
        return getQuery().getMeasureDim();
    }    
            
    // Datasource-specific code for setItems
    protected abstract BitSet _setItems(String[] dataItems, String[] items, String[][] layout) throws QueryException;
    
    // javadoc from interface
    public BitSet setItems(String[] dataItems, String items[], String[][] layout) throws QueryException
    {   
        if (layout != null && layout.length == 0)
        {
            layout = null;
        }
        if (dataItems != null && dataItems.length == 0)
        {
            dataItems = null;
        }
        
        return _setItems(dataItems, items, layout);                
    }
    
    protected DataDirector[] getDataDirectors()
    {
        return ((QueryClient)m_query).getDataDirectors();
    }
    
    // javadoc from interface
    public void setDataMap(DataMap map) throws QueryException
    {    
    }

    // javadoc from interface
    public void setMetadataMap(String dimension, MetadataMap map) throws QueryException
    {    
    }

    // javadoc from interface
    public boolean submit(List list) throws QueryException
    {    
        return false;
    }
    
    // javadoc from interface
    public void update() throws Exception    
    {    
    }
    
    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Object object) throws QueryException
    {    
        return null;
    }*/
   
    // javadoc from interface
    public StatusInfo getStatus(boolean startExecution) throws QueryException
    {    
        return null;
    }
    
    protected String getResourceString(String msg)
    {
        return m_query.getResourceString(msg);
    }
    
    protected MetadataManagerServices getMetadataManager()
    {
        return m_query.getMetadataManager();
    }    


    // Get the main "data source" connection
    protected Connection getConnection(MetadataManagerServices mm)
    {
        try
        {
            Method m = mm.getClass().getMethod("getConnections", null);
            Connection[] conn = (Connection[])m.invoke(mm, null);
            if (conn != null)
            {
                for (int i = 0; i < conn.length; i++)
                {
                    if (CB.PERSISTENCE.equals(conn[i].getDriverType()))
                        return conn[0];
                }
            }
        }
        catch (Exception e)
        {            
        }
        return null;
    }        
    
    /**
     * @hidden
     * Modifies a given Selection to effectively "drill" on the selection
     * similar to the way the relative drill() API call drills the entire
     * cube.
     * 
     * @param sel The dimension selection to drill.
     * @param value     The dimension value, also known as the
     *                  dimension member, to drill.
     * @param hierarchy The target hierarchy for the drill.
     * @param delta     The relative number of levels to traverse within the
     *                  specified hierarchy. Positive numbers drill down,
     *                  negative numbers drill up.
     * @param valueParent parent value of drilled-on dimension value
    * @param queryParent the item from the original query members under which this drill occurs
     * @param levelDepth   Optional performance hint indicating the numeric level at which the
     *                     drill target sits within its hierarchy
     * @param parentQDR    An optional OlapQDR specifying dimension/member pairs
     *                     limiting where this drill (down) should take place (parents
     *                     of the target)
     *
     * @return A <code>Selection</code> object that represents the given
     *         selection with added steps for drilling.
     *
     * @status private
     */
     // blm - Selection code moved to dvt-olap
/*    private Selection drillSelection(Selection sel, String[] value, String[] hierarchy, Integer[] delta, String[] valueParent, String[] queryParent, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException, MetadataManagerException
    {
        if (sel.isTupleSelection())
        {
            // Can't drill on a tuple
            return null;
        }

        // Create a "drill" step
        boolean[] hierDrill = new boolean[parentQDR.length];
        for (int i = 0; hierDrill.length < 0; i++)
            hierDrill[i] = _hierDrillOnSelForDrill(parentQDR[i], sel, getQuery()._getQueryState().getDimTree(), getQuery()._getQueryState(), getQuery().getQueryManager());
        int[] flags = new int[delta.length];
        for (int i = 0; i < delta.length; i++)
            flags[i] = (delta[i].intValue() > 0) ? DrillStep.DRILL_DOWN : DrillStep.DRILL_UP;
        if (levelDepth != null)
        {
            int[] intLevelDepth = new int[levelDepth.length];
            for (int i = 0; i < levelDepth.length; i++)
                if (levelDepth[i] != null)
                    intLevelDepth[i] = levelDepth[i].intValue();
            sel.drill(value, valueParent, flags, queryParent, intLevelDepth, parentQDR, hierDrill);
        }
        else
        {
            sel.drill(value, valueParent, flags, queryParent, null, parentQDR, hierDrill);
        }

        return sel;
    }    
    
    private boolean _hierDrillOnSelForDrill(OlapQDR parentQDR, Selection sel, DimTree dimensions, QueryState state, oracle.dss.dataSource.common.QueryManager qm) throws QueryException, MetadataManagerException
    {
        // Only call this a hierarchical drill if the selection is hierarchical, the flag is not set,
        // and this drill *itself* is not going to produce an asymmetric result
        return QueryUtil.hierDrillOnSel(sel, dimensions, state, qm) && (parentQDR == null || parentQDR.isEmpty());
    }        

    public Selection drill(String dimension, String[] target, String[] hierarchy, Integer[] delta, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {
        // Find this selection
        Selection sel = getQuery()._getQueryState().getSelections().find(dimension);

        // Add our "drill" step
        if (!getQuery()._getQueryState().getPropertySupport().isAsymmetricDrilling())
        {
            parentQDR = null;
        }
                
        try
        {
            sel = drillSelection(sel, target, hierarchy, delta, valueParent, queryAncestor, levelDepth, parentQDR);
        }
        catch (Exception e)
        {
            throw new QueryException(e.getMessage(), e);
        }
        
        return sel;
    }    
*/    
    // javadoc from interface
    public BaseProjection getProjection(String layerMetadataType) throws QueryException
    {
        return null;
    }
}
