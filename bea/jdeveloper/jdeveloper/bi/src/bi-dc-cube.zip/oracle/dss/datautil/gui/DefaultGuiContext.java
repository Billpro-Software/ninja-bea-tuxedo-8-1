/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Frame;

import oracle.dss.metadataManager.client.MetadataManager;

import oracle.dss.datautil.QueryContext;

//HBR: Persistence removal
//import oracle.dss.persistence.persistencemanager.common.PersistenceManager;
      
/**
 * Contains methods that common data-utility graphical user interface   
 * objects require for instantiation, often in conjunction with <code>QueryBuilder</code> 
 * or <code>CalcBuilder</code>.
 
 * @status Documented
 */
public class DefaultGuiContext implements GuiContext
{    
    //-----------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-----------------------------------------------------------------------

    /**
     * @hidden
     *
     * The metadataManager object associated with the Builder instance.
     * @status protected
     *
     */
    protected MetadataManager m_metadataManager = null;

    /**
     * @hidden
     *
     * The parent frame object associated with the Builder instance.
     * @status protected
     */
    protected Frame m_parentFrame = null;

    /**
     * @hidden
     *
     * The QueryContext object associated with the Builder instance.
     * @status protected
     *
     */
    protected QueryContext m_queryContext = null;
    
    //-----------------------------------------------------------------------
    // CONSTRUCTOR
    //-----------------------------------------------------------------------

    /**
     * Constructor.
     *
     * @status Documented
     */
    public DefaultGuiContext ( )
    {
    }

    //-----------------------------------------------------------------------
    // Begin - Implentation of GuiContext interface.
    //-----------------------------------------------------------------------

    /**
     * Retrieves the <code>MetadataManager</code> object.
     *
     * @return The <code>MetadataManager</code> object.
     *         
     * @status Documented
     */
    public MetadataManager getMetadataManager ( )
    {
        return m_metadataManager;
    }
    
    /**
     * Retrieves the parent <code>Frame</code> object.
     *
     * @return The parent <code>Frame</code> object.
     *
     * @status Documented
     */
    public Frame getParentFrame ( )
    {
        return m_parentFrame;
    }
    
    /**
     * Retrieves the <code>QueryContext</code> object.
     *
     * @return The <code>QueryContext</code> object.
     *
     * @status Documented
     */
    public QueryContext getQueryContext ( )
    {
        return m_queryContext;
    }
    
    /**
     * Specifies the <code>MetadataManager</code> object.
     *
     * @param metadataManager The <code>MetadataManager</code> object.
     *
     * @status Documented
     */
    public void setMetadataManager ( MetadataManager metadataManager )
    {
        m_metadataManager = metadataManager;
    }
    
    /**
     * Specifies the parent <code>Frame</code> object.
     *
     * @param  frameParent The parent <code>Frame</code> object.
     *
     * @status Documented
     */
    public void setParentFrame ( Frame parentFrame )
    {
        m_parentFrame = parentFrame;
    }
	
    /**
     * Specifies the <code>QueryContext</code> object.
     *
     * @param  queryContext The <code>QueryContext</code> object.
     *
     * @status Documented
     */
    public void setQueryContext ( QueryContext queryContext )
    {
        m_queryContext = queryContext;
    }
    
    //-----------------------------------------------------------------------
    // End - Implentation of GuiContext interface.
    //-----------------------------------------------------------------------
}