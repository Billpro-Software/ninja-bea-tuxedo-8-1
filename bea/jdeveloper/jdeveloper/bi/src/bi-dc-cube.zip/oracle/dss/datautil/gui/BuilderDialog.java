/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Component;

import oracle.dss.datautil.client.DataUtilException;

/**
 * Methods that are specific to container objects for QueryBuilder and
 * CalcBuilder.
 *
 * @status Documented
 */
public interface BuilderDialog
{    
    /**
     * Retrieves the <code>BuilderContext</code> object that is associated with
     * the <code>BuilderDialog</code>.
     *
     * @return A reference to the <code>BuilderContext</code> object.
     *
     * @status Documented
     */
    public BuilderContext getBuilderContext ( );
    
    /**
     * Retrieves the component that is associated with the
     * <code>BuilderDialog</code>.
     *
     * @return A reference to the associated component.
     *
     * @status Documented
     */
    public Component getComponent ( );
    
    /**
     * Initializes the contents of the <code>BuilderDialog</code> object.
     *
     * @return <code>true</code> if the operation is successful;
     *         <code>false</code> if the operation is not successful.
     *
     * @status Documented
     */
    public boolean initialize ( );

    /**
     * Refreshes the contents of the <code>BuilderDialog</code> object.
     *
     * @return <code>true</code> if the operation is successful;
     *         <code>false</code> if the operation is not successful.
     *
     * @status Documented
     */
    public boolean refresh ( );

    /**
     * Signals the <code>BuilderDialog</code> object to run the dialog.
     *
     * @return <code>true</code> if the dialog is dismissed with an OK command;
     *         <code>false</code> if the dialog is cancelled.
     * @throws <code>DataUtilException</code> if an error is encountered.    
     *
     * @status Documented
     */
    public boolean run ( ) throws DataUtilException;

    /**
     * Specifies whether the specified panel is to be shown or hidden.
     *
     * @param panelId    The identifier of the specified panel.
     * @param bVisible   <code>true</code> if the panel is to be marked visible,
     *                   <code>false</code> if the panel is to be hidden.
     *
     * @status Documented
     */
    public boolean setPanelVisible ( String panelId, boolean bVisible );
}
