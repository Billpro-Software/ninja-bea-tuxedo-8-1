/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/QueryEditorEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     12/05/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/QueryEditorEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.datautil;

/**
 * Base class for QueryEditor events
 */
public abstract class QueryEditorEvent extends java.util.EventObject implements java.io.Serializable
{

    /**
     * Constructor
     * @param qe
     * @param source
     */
    public QueryEditorEvent(QueryEditor qe)
    {
        super(qe);
    }
    
    /**
     * @hidden
     */
    public QueryEditorEvent(Object qe)
    {
        super(qe);
    }
    
    /**
     * Retrieves the QueryEditor instance involved in this event
     *
     * @return The <code>QueryEditor</code> object involved in this event
     *
     * @status New
     */
    public QueryEditor getQueryEditor()
    {
        return (QueryEditor)super.getSource();
    }
}