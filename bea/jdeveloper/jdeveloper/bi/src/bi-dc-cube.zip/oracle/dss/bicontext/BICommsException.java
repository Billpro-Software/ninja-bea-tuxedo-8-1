/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;

/**
 * Indicates a failure communicating to the BI server.  
 * <p>
 * To handle this exception in particular, catch it before you catch a
 * <code>NamingException</code>.
 * 
 * @status New
 */
public class BICommsException extends BINamingException
{
    
   /**
    * @hidden
    * Constructor for a formattable, localizable exception for a specific locale
    * that passes on a previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale The locale in which the message should be localized.
    * @param prevException  The exception that underlies this exception.
    */
    public BICommsException(Class resBundleClass, String errorCode, String[] params, Locale locale, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, locale, prevException);
    }
}
