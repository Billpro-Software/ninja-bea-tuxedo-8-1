/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners when a cell submission operation is requested.
 * A listener has the option to veto the cell submission operation by calling
 * the <code>consume</code> method.
 * If a listener vetoes the operation, then subsequent listeners are not
 * notified and the operation is cancelled (that is, not added to the pending
 * queue).
 *
 * @status Documented
 */
public class CellsSubmittingEvent extends CellsSubmitEvent implements Consumable
{

/**
 * Constructor.
 *
 * @param source                The source of the event, that is, the object
 *                              that fired the event.
 * @param qdrOverrideCollection A writeback collection that contains a QDR
 *                              override for each cell that was edited.
 *
 * @status Documented
 */
    public CellsSubmittingEvent(Object source, java.util.List qdrOverrideCollection )
    {
        super(source, qdrOverrideCollection);

    }


/**
 * Consumes this event.
 *
 * @status Documented
 */
    public void consume() {
        super.consume();
    }

/**
 * Indicates whether this event has been consumed.
 *
 * @status Documented
 */
    public boolean isConsumed() {
        return super.isConsumed();
    }
}