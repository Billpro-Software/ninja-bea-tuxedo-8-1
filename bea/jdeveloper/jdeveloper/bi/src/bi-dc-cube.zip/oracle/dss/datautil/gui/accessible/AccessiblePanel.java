/*
 * AccessiblePanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.accessible;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.accessibility.AccessibleContext;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

import oracle.bali.ewt.statusBar.StatusBar;
import oracle.bali.ewt.text.MultiLineLabel;

/**
 *  Provides the capability of accessibility to panels.
 *  This class allows you to control when text that is associated with the
 *  panel's AccessibleName and other embedded components is provided to
 *  accessibility applications such as JAWS.
 *  <p>Application developers should not use this class. It is for internal
 *  use only.</p>
 *
 *  @see oracle.dss.datautil.gui.accessible.AccessibleLabel
 *  @see oracle.dss.datautil.gui.accessible.AccessibleUtils 
 *  @status documented
 *
 */

 public class AccessiblePanel extends JPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * Debug flag.
   *  Note: Turn off for the final release build
   *
   * @status private
   */
  static private final boolean _DEBUG = false;

  /**
   * @hidden
   *
   * Hidden status label used to invoke accessibility
   *
   * @status protected
   */
  protected JLabel m_jLabelStatusBar = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor.
   *
   * @status documented
   */
  public AccessiblePanel() {

    // Create the label used by the status bar for accessibility
    setAccessibleLabel (new JLabel() {

      /**
       * Specifies the text for this label. This method overrides the
       * <code>setText</code> method of <code>JLabel</code> to support accessibility.
       *
       * This enables accessibility applications such as JAWS to read the text.
       *
       * If the old text is the same as the new text, then nothing is read.
       *
       * @param  strText A <code>string</code> that is associated with the label.
       *
       * @status documented
       */
      public void setText (String strText) {

        // gek 10/31/01 Check for null text
        if (strText == null) {
          strText = "";
        }

        // Retrieve the old text
        String strTextOld = getText();

        // Pass the new text to the JLabel
        super.setText(strText);

        // Retrieve the Accessible Context
        if (getAccessibleContext() != null) {
          // This will force jaws to read the text, if the new text is not the
          // same as the old text.
          if (!strTextOld.equals (strText)) {
            getAccessibleContext().firePropertyChange(
              AccessibleContext.ACCESSIBLE_NAME_PROPERTY, strTextOld, strText);
          }

          // Dump out new and old text strings
          if (_DEBUG) {
            System.out.println ("AccessiblePanel: AccessibleLabel setText");
            System.out.println ("[Old]: " + strTextOld );
            System.out.println ("[New]: " + strText);
          }
        }
      }});

    // Create a hidden status bar whose associated label will be used
    // invoke accessibility support.
    StatusBar statusBar = new StatusBar();
    statusBar.setAlignmentX(Component.LEFT_ALIGNMENT);
    statusBar.setPreferredSize(new Dimension(getToolkit().getScreenSize().width,0));
    statusBar.setMinimumSize(statusBar.getPreferredSize());
    statusBar.setMaximumSize(statusBar.getPreferredSize());

    // Add the accessible label
    statusBar.add(getAccessibleLabel());

    // Hide the status bar
    statusBar.setVisible(false);

    // Add the status bar to this panel
    this.add(statusBar);

    // Add a ComponentListener to make sure that when the panel is
    // resized the text is updated in the status bar.
    this.addComponentListener (new ComponentAdapter() {
      public void componentResized(ComponentEvent event) {
        super.componentResized (event);
        // updateLabel();

        if (_DEBUG)
          System.out.println (event.toString());
      }
    });

    // Add AncestorListener to make sure that when the container
    // of the panel is modified, the text is updated in the status bar.
    this.addAncestorListener(new AncestorListener() {

      // Update the status bar if a parent is moved
      public void ancestorMoved(AncestorEvent event) {
        // updateLabel();

        if (_DEBUG)
          System.out.println (event.toString());
      }

      // Update the status bar if a parent is added
      public void ancestorAdded(AncestorEvent event) {
        // updateLabel();

        if (_DEBUG)
          System.out.println (event.toString());
      }

      // Ignore
      public void ancestorRemoved(AncestorEvent event) {
        if (_DEBUG)
          System.out.println (event.toString());
      }
    });
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Resets the <code>JLabel</code> that is associated with the hidden status 
   * bar so that the user can determine when accessibility is updated.
   *
   * @status documented
   */
  public void resetAccessibleLabel () {
    getAccessibleLabel().setText ("");
  }

  /**
   * Retrieves the accessible <code>JLabel</code> that is associated with the hidden
   * status bar.
   *
   * @return The <code>JLabel</code> that represents the label that is associated 
   *         with the hidden status bar.
   * @status documented
   */
  public JLabel getAccessibleLabel () {
    return m_jLabelStatusBar;
  }

  /**
   * Retrieves the AccessibleName that is associated with this panel.
   *
   * @return A <code>string</code> that represents the AccessibleName.
   *
   * @status documented
   */
  public String getAccessibleName () {
    // Start with the accessible name associated with the panel
    AccessibleContext accessibleContext = getAccessibleContext();
    if (accessibleContext != null)
      return accessibleContext.getAccessibleName();
    else
      return ("");
  }

  /**
   * Retrieves the text that is associated with this panel.
   *
   * This text includes the panel's AccessibleName and all the text that is 
   * associated with any added components.
   *
   * The following components are currently supported:
   *  javax.swing.JLabel and oracle.bali.ewt.text.MultiLineLabel.
   *
   * @return A <code>string</code> that represents the concatenated text values.
   *
   * @status documented
   */
  public String getPanelText () {
    StringBuffer strBuffer = new StringBuffer();

    // Add the text for each component within the panel
    Component[] components = getComponents();
    if (components != null) {
      for (int nIndex = 0; nIndex < components.length; nIndex++) {
        String strText = null;
        Component component = components[nIndex];

        // Check for labels
        if (component instanceof JLabel) {
          strText = ((JLabel)component).getText();
        }

        // Check for multi-line labels
        if (component instanceof MultiLineLabel) {
          strText = ((MultiLineLabel)component).getText();
        }

        // Add new label text to running buffer
        if (strText != null)
          strBuffer.append (strText);
      }
    }

    // Return a string which contains all relevant label text
    return strBuffer.toString();
	}

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Updates the label based on the current AccessibleName and panel text.
   *
   * Note: The AccessibleName is added separately from the panel text due to
   *       JAWS inability to read long text strings properly (e.g. stops early
   *       or speaks '?').
   *
   * @status protected
   */
  protected void updateLabel() {

    // Retrieve the accessible name
    if (getAccessibleName() != null)
      getAccessibleLabel().setText(getAccessibleName());

    // Retrieve the text associated with panel components
    if (getPanelText() != null)
      getAccessibleLabel().setText(getPanelText());
  }

  /**
   * @hidden
   *
   * Specifies the <code>JLabel</code> associated with the hidden status bar.
   *
   * @param jLabel a <code>JLabel</code> associated with the hidden status bar.
   *
   * @status protected
   */
  protected void setAccessibleLabel (JLabel jLabel) {
    m_jLabelStatusBar = jLabel;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
