/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/resource/ParameterBundle.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.parameter.resource;

import java.util.ListResourceBundle;

/**
 * <pre>
 * <code>ParameterBundle</code>.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   06/13/07 - Fix Bug 6025518 - QueryBuilder: Parameter Dlg:
 *                         'Name' and 'Default Value' fields have no mnemonic.
 * 
 */
public class ParameterBundle extends ListResourceBundle {

  static final Object[][] m_resources = {
    // Parameter Creation panel
    {"CreateParameterDescription", "Create a parameter for an item."},
    {"Name", "Name"},
    {"GenerateName", "Autoname"},
    {"DefaultName", "{0} Parameter"},
    {"BasedOn", "Item"},
    {"Values", "Values"},
    {"ValueRequired", "Require users to enter a value"},
    {"MultipleValues", "Enable users to select multiple values"},
    {"IndexValue", "Enable users to select either indexes or values"},
    {"DefaultValues", "Default &Value"},
    {"Value", "Value"},
    {"UserPrompt", "&Name"},
    {"Description", "Description"},
    {"NewParameter", "New Parameter"},
    {"AllValues", "Show all available values"},
    {"FilterValues", "Limit available values based on filters"},
    {"Sharing", "Sharing"},
    {"SharingEachView", "Prompt separately for each view"},
    {"SharingAllViews", "Prompt once for all views"},
    {"Standard", "< Less"},
    {"Advanced", "More >"},
    {"ParameterTab", "Parameter"},
    {"NameSaveTab", "Name and Save"},
    
    // Parameter Values panel
    {"ParameterPanel", "Parameters:"},
    {"DescriptionPanel", "Description:"},
    
    // Parameter Values dialog
    {"EditParameterValues", "Parameter Values"},
    {"EditParameterValuesSubtitle", "Parameter Values: {0}"},
  };
  
  public Object[][] getContents() {
    return m_resources;
  }  
}
