/*
 * ResourceCache.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */   
package oracle.dss.datautil.gui;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;
import java.util.Hashtable;

/**
 * @hidden
 */
public class ResourceCache {
	// Default resource bundle.
	private static final String DEFAULT_RESOURCE_BUNDLE = "oracle.dss.datautil.gui.resource.DataUtilGUIBundle";

    // The current resource bundle.
    private ResourceBundle m_resourceBundle = null;
    // Location of the resource bundle.
    private String m_strResourceBundle = null;
    // The current locale.
    private Locale m_locale = null;

    /**
     * Constructor. It creates a default resource bundle using
     * the given default resource bundle file location and locale
     *
     * @param strResourceBundle The default resource bundle file location.
     *
     * @status hidden
     */
	public ResourceCache(String strResourceBundle, Locale locale) {
		// Set the default resource bundle.
		m_strResourceBundle = strResourceBundle;

    if (locale == null) {
      locale = Locale.getDefault();
    }
    setLocale(locale);
	}

    /**
     * Constructor. It creates a default resource bundle using
     * the given default resource bundle file location
     * 
     * @param strResourceBundle The default resource bundle file location.
     *
     * @status hidden
     */
	public ResourceCache(String strResourceBundle) {
		// Set the default resource bundle.
    this(strResourceBundle, null);
  }
    
    /**
     * Default constructor. It creates a default resource bundle using
     * the default resource bundle file location.
     *
     * @status hidden
     */
	public ResourceCache() {
		this(DEFAULT_RESOURCE_BUNDLE);
	}
		
	/**
   * @hidden
	 * Sets the current locale.
	 *
	 * @param locale The current locale.
	 *
	 * @status hidden
	 */
	public void setLocale(Locale locale) {
		m_resourceBundle = getResourceBundle(locale);
    m_locale = locale;
	}

  /**
   * @hidden
   * Gets the current locale
   *
   * @status hidden
   */
  public Locale getLocale() {
    return m_locale;
  }

    /**
     * @hidden
     * Retrieves the value element for the specified key element from the
     * <code>DataUtilBundle</code> object.
     * For example, for a key element "btnOK", it
     * might retrieve the value element "OK".
     *
     * @param strKey The key element whose value is to be retrieved.
     * @param resourceBundle The resource bundle containing the text.
     *
     * @return The value element of the specified key element.
     *
     * @status hidden
     */
    public String getIntlString (String strKey) {
        String strResource = null;
        
        if (m_resourceBundle == null) {
            return strKey;
        }
    
        try {
            strResource = m_resourceBundle.getString (strKey);
        }
        catch (MissingResourceException e) {
            return strKey;
        }
        return strResource;
    }
	
    /**
     * Return the ResourceBundle from the hashtable of ResourceBundles using
     * the given locale as the key.
     *
     * @param locale The locale used  as the key.
     *
     * @return The ResourceBundle.
     *
     * @status private
     */
	private ResourceBundle getResourceBundle (Locale locale) {
		if (locale != null) {
			m_resourceBundle = ResourceBundle.getBundle(m_strResourceBundle, locale);
		}
		return m_resourceBundle;
	}
}