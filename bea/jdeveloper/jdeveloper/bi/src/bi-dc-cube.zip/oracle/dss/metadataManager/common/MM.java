/*
** Copyright (c) 2008, 2009, Oracle and/or its affiliates.All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Vector;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;

import oracle.dss.util.DataAccess;
import oracle.dss.util.NumberFormatType;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * Constants that other MetadataManager classes use.
 *
 */
public class MM extends MDU {
  // Object Types
  /**
   * An object.
   * @see MDObject
   * 
   */
  public final static String OBJECT                     = "Object" ;
  /**
   * A folder.
   * @see MDFolder
   * 
   */
  public final static String FOLDER                     = PersistableConstants.FOLDER;
  /**
   * The root folder.
   * @see MDRoot
   * 
   */
  public final static String ROOT                       = "Root" ;
  /**
   * A measure.
   * @see MDMeasure
   * 
   */
  public final static String MEASURE                    = "Measure";
  /**
   * A dimension.
   * @see MDDimension
   * 
   */
  public final static String DIMENSION                  = "Dimension";
  /**
   * An attribute.
   * @see MDAttribute
   * 
   */
  public final static String ATTRIBUTE                  = "Attribute";
  /**
   * A hierarchy.
   * @see MDHierarchy
   * 
   */
  public final static String HIERARCHY                  = "Hierarchy";
  /**
   * A level in a hierarchy.
   * @see MDLevel
   * 
   */
  public final static String LEVEL                      = "Level";
  /**
   * A MDDimensionCalc.
   */
  public final static String DIMENSIONCALC              = "DimensionCalc";
  /**
   * A data-driven format.
   * 
   */
  public final static String FORMAT                     = "Format";
  /**
   * A component.
   * Components are generally stored in the repository.
   * 
   */
  public final static String COMPONENT                  = "Component";
  /**
   * A selection.
   * @see MDSelection
   * 
   */
  public final static String SELECTION                  = "Selection";
  /**
   * Metadata for the members of a dimension or attribute.
   * @see MDMemberMetadata
   * 
   */
  public final static String MEMBER_METADATA            = "Member Metadata";
  /**
   * A calculation.
   * 
   */
  public final static String CALCULATION                = "Calculation";
  /**
   * A crosstab.
   * @see oracle.dss.crosstab.Crosstab
   * 
   */
  public final static String CROSSTAB                   = "Crosstab";
  /**
   * A graph.
   * @see oracle.dss.graph.Graph
   * 
   */
  public final static String GRAPH                      = "Graph";
  /**
   * A table.
   * @see oracle.dss.table.Table
   * 
   */
  public final static String TABLE                      = "Table";

  // Relations of Objects   
  /**
   * @internal
   */
  public final static String DRIVER_ROOT                = "Driver Root" ;
  /**
   * The measure dimension.
   * The measure dimension specifies the available measures.
   * 
   */
  public final static String MEASURE_DIMENSION          = "Measure";
  /**
   * A range dimension.
   * The range dimension of an attribute specifies its valid values.
   * @see MDAttribute#getRangeDimension
   * 
   */
  public final static String RANGE_DIMENSION            = "Range Dimension";
  /**
   * A domain dimension.
   * The domain dimension of an attribute identifies the dimension that
   * the attribute describes.
   * @see MDAttribute#getDomainDimension
   * 
   */
  public final static String DOMAIN_DIMENSION           = "Domain Dimension";
  /**
   * A qualifying dimension.
   * A qualifying dimension of an attribute specifies a dimension whose values
   * determine the appropriate value of an attribute.
   * @see MDAttribute#getQualifyingDimensions
   * 
   */
  public final static String QUALIFYING_DIMENSION       = "Qualifying Dimension";
  /**
   * Short labels for members.
   * 
   */
  public final static String MEMBER_SHORT_LABEL_METADATA= "Member Short Label Metadata";
  /**
   * Long labels for members.
   * 
   */
  public final static String MEMBER_LONG_LABEL_METADATA = "Member Long Label Metadata";
  /**
   * The default hierarchy for a dimension.
   * 
   */
  public final static String DEFAULT_HIERARCHY          = "Default Hierarchy";
  /**
   * @internal
   */
  public final static String DEPENDENCY                 = "Dependency";


  // Driver Specific Object Type
  /**
   * @internal
   */
  public final static String OLAPI_SOURCE               = "Olapi Source";
  /**
   * @internal
   */
  public final static String OLAPI_MEMBER_SOURCE        = "Olapi Member Source";
  /**
   * @internal
   */
  public final static String DRIVER_TYPE                = "Driver Type";
  /**
   * @internal
   */
  public final static String OLAPI_MDM_OBJ              = "Olapi MDM Object";
  /**
   * @internal
   */
  public final static String OLAPI_ECM_OBJ              = "Olapi ECM Object";
  /**
   * An object that is stored in the repository.
   * 
   */
  public final static String PERSISTENCE_OBJECT         = "Persistence Object";
  /**
   * @internal
   */
  public final static String PERSISTENCE_RUNTIME_ID     = "Persistence Runtime ID";
  /**
   * @internal
   */
  public final static String STATEAGENT                 = "StateAgent";
  /**
   * @internal
   */
  public final static String REPOS_RUNTIME_ID           = "Repository Runtime ID";
  /**
   * @internal
   */
  public final static String DATABASE_STRING            = "Database String";
  /**
   * @internal
   */
  public final static String METADATA_MANAGER_SERVICES  = "MetadataManagerServices";

  // Properties
  /**
   * The data type of an object.
   * 
   */
  public final static String DATA_TYPE                  = "Data Type";
  /**
   * The short label of an object.
   * 
   */
  public final static String SHORT_LABEL                = "Short Label";
  /**
   * The medium label of an object.
   * 
   */
  public final static String MEDIUM_LABEL               = "Medium Label";
  /**
   * The long label of an object.
   * 
   */
  public final static String LONG_LABEL                 = "Long Label";
  /**
   * The short plural label of an object.
   * 
   */
  public final static String SHORT_PLURAL_LABEL         = "Short Plural Label";
  /**
   * The long plural label of an object.
   * 
   */
  public final static String LONG_PLURAL_LABEL          = "Long Plural Label";
  /**
   * The description of an object.
   * 
   */
  public final static String DESCRIPTION                = "Description";
  /**
   * @internal
   */
  public final static String STRING_TYPE                = "String Type";
  /**
   * @internal
   */
  public final static String STRING_TYPE_VALUE          =  LONG_LABEL;
  /**
   * @internal
   */
  public final static String RELATION                   = "Relation";
  /**
   * The base measures for a calculation.
   * 
   */
  public final static String BASE_MEASURES              = "Base Measures";
  /**
   * @internal
   */
  public final static String MEASURE_BASE_VARIABLE      = "Measures Base Variable";
  
  /**
   * @internal
   */
  public final static String SORT                       = "Sort";

  // run-time control properties
  /**
   * @internal
   */
  public final static String REQUEST_TYPE               = "Request Type";
  /**
   * @internal
   */
  public final static String CREATE_PERSISTENCE         = "Create Persistence";

  // Request type
  /**
   * @internal
   */
  public final static String REMOTE                     = "Remote";
  /**
   * @internal
   */
  public final static String NONREMOTE                  = "Non Remote";
  
  // Hierarchy properties
  /**
   * @internal
   */
  public final static String ANCESTORS_RELATION         = "Ancestors Relation";
  /**
   * @internal
   */
  public final static String LEVEL_RELATION             = "Level Relation";
  /**
   * @internal
   */
  public final static String PARENT_RELATION            = "Parent Relation";
  /**
   * @internal
   */
  public final static String VALUE_LEVEL_DEPTH          = "Value level depth";

    /**
     * @internal
     */
  public final static String ATTRIBUTE_MAP = "Attribute Map";
    
  // Data types
  /**
   * Boolean data type, as defined by the data store.
   * 
   */
  public final static String BOOLEAN                    = DataAccess.DATATYPE_BOOLEAN;
  /**
   * Short data type, as defined by the data store.
   * 
   */
  public final static String SHORT                      = DataAccess.DATATYPE_SHORT;
  /**
   * Integer data type, as defined by the data store.
   * 
   */
  public final static String INTEGER                    = DataAccess.DATATYPE_INTEGER;
  /**
   * Long data type, defined by the data store.
   * 
   */
  public final static String LONG                       = DataAccess.DATATYPE_LONG;
  /**
   * Float data type, as defined by the data store.
   * 
   */
  public final static String FLOAT                      = DataAccess.DATATYPE_FLOAT;
  /**
   * Double data type, as defined by the data store.
   * 
   */
  public final static String DOUBLE                     = DataAccess.DATATYPE_DOUBLE;
  /**
   * String data type, as defined by the data store.
   * 
   */
  public final static String STRING                     = DataAccess.DATATYPE_STRING;

  /**
   * Date data type, as defined by the data store.
   */
  public final static String DATE                       = DataAccess.DATATYPE_DATE;

  /**
   * @internal
   * Indeterminate data type.
   * This can occur when custom measures contain references to measures which
   * don't all contain the same data type or the data type can't be determined.
   *
   */
  public final static String INDETERMINATE              = "Indeterminate";

  // Search Flags
  /**
   * Search flags: Retrieve objects that relate to any of the specified
   * objects.
   * For example, retrieve dimensions that any of the specified measures are
   * dimensioned by.
   *
   * 
   */
  public final static String UNION                      = "Union";

  /**
   * Search flags: Retrieve only the objects that related to all of the
   * specified objects.
   * For example, retrieve only the dimensions that all of the specified
   * measures are dimensioned by.
   *
   * 
   */
  public final static String INTERSECTION               = "Intersection";
  /**
   * @internal
   */
  public final static String EXACT_MATCH                = "Exact Match";
  /**
   * @internal
   */
  public final static String CASE_SENSITIVE             = "Case Sensitive";

  // Attach Status
  /**
   * Status of the workspace or repository.
   * 
   */
  public final static String ATTACH_STATUS              = "Attach Status";
  /**
   * Analytic workspace status: Workspace attached.
   * <P>
   * For methods that indicate a particular workspace, this value means
   * that the specified workspace is attached (open).
   * For methods that do not indicate a particular workspace, this value
   * means that at least one analytic workspace is open.
   *
   * 
   */
  public final static int    ATTACHED                   = 1;

  /**
   * Analytic workspace status: Workspace not attached.
   * <P>
   * For methods that indicate a particular workspace, this value means
   * that the specified workspace is not attached (is closed).
   * For methods that do not indicate a particular workspace, this value
   * means that no analytic workspaces are open.
   *
   * 
   */
  public final static int    NOT_ATTACHED               = 2;

  /**
   * Analytic workspace status: The <code>MetadataManager</code> is in the
   * process of attaching the workspace.
   * <P>
   * For methods that indicate a particular workspace, this value means
   * that the specified workspace is being attached (being opened).
   * For methods that do not indicate a particular workspace, this value
   * means that at least one analytic workspace is being opened.
  *
   * 
   */
  public final static int    ATTACHING                  = 3;

  // Connection Status
  /**
   * Status of the connection.
   * 
   */
  public final static String CONNECTION_STATUS          = "Connection Status";

  /**
   * Connection status: The connection has not been set.
   *
   * 
   */
  public final static int    CONNECTIONS_NOT_SET        = 4;
  /**
   * Connection status: The connection has been set.
   *
   * 
   */
  public final static int    CONNECTIONS_SET            = 5;

  // Bound status
  /**
   * @internal
   */
  public final static String BOUND_STATUS               = "Bound Status";
  /**
   * Bound status: The object is bound.
   * 
   */
  public final static int    BOUND                      = 1;
  /**
   * Bound status: The object is not bound.
   * 
   */
  public final static int    NOT_BOUND                  = 2;

  // Evaluation Status
  /**
   * @internal
   */
  public final static String EVALUATION_STATUS          = "Evaluation Status";
  /**
   * @internal
   */
  public final static String EVALUATED                  = "Evaluated";
  /**
   * @internal
   */
  public final static String NOT_EVALUATED              = "Not Evaluated";

  // Dimension Type
  /**
   * @internal
   */
  public final static String DIMENSION_TYPE             = "Dimension Type";
  /**
   * @internal
   */
  public final static String TIME_DIMENSION             = "Time Dimension";
  /**
   * @internal
   */
  public final static String TIME_DIM_ATTR_TYPE         = "Time dim Attr Type";
  /**
   * @internal
   */
  public final static String END_DATE                   = "End Date";
  /**
   * @internal
   */
  public final static String TIME_SPAN                  = "Time Span";
  /**
   * @internal
   */
  public final static String SPATIAL_DIMENSION          = "Spatial Dimension";
  /**
   * @internal
   */
  public final static String LINE_DIMENSION             = "Line Dimension";

  // Attribute Type
  /**
   * @internal
   */
  public final static String ATTRIBUTE_TYPE             = "Attribute Type";
  /**
   * @internal
   */
  public final static String DIMENSIONAL_ATTRIBUTE      = "Dimensional Attribute";
  /**
   * @internal
   */
  public final static String PROPERTY_ATTRIBUTE         = "Property Attribute";

  // Relationship
  /**
   * @internal
   */
  public final static String CHILD                      = "child";
  /**
   * @internal
   */
  public final static String PARENT                     = "parent";

  // copy, move, security
  /**
   * @internal
   */
  public final static String COPY_OPTION                = "copy";
  /**
   * @internal
   */
  public final static String MOVE_OPTION                = "move";

  // Performance flags

  /**
   * @internal
   * Performance flag: Analytic workspace is small.
   * Do not defer loading.
   *
   */
  public final static int DEMO_DATABASE                 = -1;

  /**
   * @internal
   * Performance flag: Analytic workspace is medium-sized.
   * Do not defer loading.
   *
   */
  public final static int MEDIUM_DATABASE               = 3;

  /**
   * @internal
   * Performance flag: Analytic workspace is large.
   * Defer loading.
   *
   */
  public final static int LARGE_DATABASE                = 1;

  // flags for middle-tier deferred loading
  /**
   * @internal
   */
//  public final static String PERSISCHILDRENBAG_STATUS   = "Persis ChildrenBag Status";
  /**
   * @internal
   */
//  public final static String OLAPCHILDRENBAG_STATUS     = "Olap ChildrenBag Status";
  /**
   * @internal
   */
  public final static String RELATIVEBAG_STATUS         = "RelativeBag Status";

  /**
   * @internal
   */
  public final static int COMPLETE                      = 1;

  /**
   * @internal
   */
  public final static int NOT_COMPLETE                  = 2;

  /**
   * @internal
   */
  public final static int COMPLETING                    = 3;

  /**
   * @internal
   */
  public final static String CURRENT_MEMBER             = "Current Member";

  /**
   * @internal
   * Do not change the value of DATABASE_TYPE constant
   */
  public final static String DATABASE_TYPE              = "DatabaseType";

  /**
   * @internal
   *
   * Property that determines how a number should be formatted based on the
   * specified format mask value.
   */
  public final static String NUMBER_FORMAT_STRING       = "Number Format String";

  /**
   * @internal
   *
   * Property that determines the number format type associated with the number format string.
   * The default value is <code>NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS</code>.
   *
   * @see #NUMBER_FORMAT_STRING
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   *
   */
  public final static String NUMBER_FORMAT_TYPE         = "Number Format Type";

  /**
   * @internal
   */
  public final static String REFERENCE_BY_OBJ           = "Reference by Obj";

  /**
   * @internal
   */
  public final static String REFERENCE_OBJ              = "Reference obj";
  
  /**
   * @internal
   */
  public final static String REFERENCE_NAME             = "Reference name";

  /**
   * @internal 
   */
  public final static String IS_AW_OBJECT               = "Is AWObject";

  /**
   * @internal 
   */
  public final static String AW_OBJECT_NAME             = "AW Object Name";

  /**
   * @internal 
   */
  public final static String HIDDEN                     = "hidden";

  /**
   * @internal 
   */
  public final static String HIDE_ALWAYS                = "hide always";

  /**
   * @internal 
   */
  public final static String ENABLED                    = "enabled";

  /**
   * @internal 
   */
  public final static String INITIALIZER                = "initializer";

  /**
   * @internal 
   */
  public final static String BEFORE_CONNECT             = "before_connect";

  /**
   * @internal 
   */
  public final static String BEFORE_ATTACH              = "before_attach";

  /**
   * @internal 
   */
  public final static String AFTER_ATTACH               = "after_attach";

  /**
   * @internal 
   */
  public final static String BEFORE_METADATA_LOAD  = "before_olap_metadata_load";

  /**
   * @internal
   */
  public final static String OWNER                      = "owner";

  /**
   * @internal
   */
  public final static String METADATA_DRIVER            = "metadata_driver";

  /**
   * @internal
   */
  public final static String CHILDREN_STATUS            = "children_status";

  /**
   * @internal
   */
  public final static String PLSQL_FILTER               = "plsql_filter";

  /**
   * @internal
   */
  public final static String PLSQL_CALC_FILTER          = "begin bism_calc_filter.delete_nonviable_calc(?,?); end;";

  /**
   * @internal
   */
  public final static String IS_PLSQL_FILTER_ON         = "is_plsql_filter_on";

  /**
   * @internal
   */
  public final static String LOOKUP_CACHE_SIZE          = "lookup_cache_size";

   /**
    * @internal
    * The class name of the object
    */
    public static final String BISESSION                = "session";
    
    public static final String ITEMFOLDER               = "ItemFolder";
    public static final String SQL_ITEMFOLDER           = "SQL_ItemFolder";
    public static final String TABLE_ITEMFOLDER         = "Table_ItemFolder";
    public static final String COMPLEX_ITEMFOLDER       = "Complex_ItemFolder";
    public static final String ITEM                     = "Item";
    public static final String CALCULATION_ITEM         = "Calculation_Item";
    public static final String ADMINCALCULATION_ITEM    = "AdminCalculation_Item";
    public static final String COLUMN_ITEM              = "Column_Item";
    public static final String JOIN                     = "Join";
    public static final String FUNCTION                 = "Function";
    public static final String DEFAULT_AGG_FUNCTION     = "DEFAULT_AGG_FUNCTION";
    public static final String AGG_FUNCTION             = "AGG_FUNCTION";
    public static final String ALIGNMENT                = "Alignment";
    
    public static final String STATE_OBJECT             = "State_Object";
    public static final String DEFAULT_PLACEMENT        = "default_placement";
    public static final String AXIS                     = "axis";
    public static final String PAGE                     = "page";
    public static final String Y_AXIS                   = "y_axis";
    public static final String X_AXIS                   = "x_axis";

    public static final String IS_ADMIN_CALC            = "is_admin_calc";

    public static final String UNKNOWN                  = "none";
    public static final String COMPLEX                  = "complex";
    public static final String BFILE                    = "bfile";
    public static final String BINARY                   = "binary";
    public static final String NULL                     = "null";
    public static final String FORMAT_MASK              = "format_mask";
    public static final String ITEM_CALC                = "item_calc";
    public static final String MEASURE_CALC             = "measure_calc";
    public static final String DIMENSIONMEMBER_CALC     = "dimension_membercalc";
    public static final String DRILL_DOWN_PATHS         = "drill_down_paths";
    public static final String DRILL_UP_PATHS           = "drill_up_paths";
    public static final String EXPRESSION               = "expression";
    /**
     * @internal
     */
    public static final String ESCAPED_UID              = "escaped_uid";
    public static final String AGGR_RULE                = "aggr_rule";
}
