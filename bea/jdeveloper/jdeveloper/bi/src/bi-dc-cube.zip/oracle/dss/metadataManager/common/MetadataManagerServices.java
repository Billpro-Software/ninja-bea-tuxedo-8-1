/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Vector;
import java.util.Hashtable;

import javax.naming.Name;
import javax.naming.directory.Attributes;

import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.OrderedHashtable;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.bicontext.BINamingException;

/**
 * Methods required for the MetadataManager bean.
 * The MetadataManager consolidates access to metadata from multiple connections.
 * For example, you might have metadata stored in an analytic workspace and in
 * the repository.
 * The MetadataManager consolidates these sources of metadata to give you
 * unified access to the metadata.
 *
 * @status Reviewed
 */
/**
 * @hidden
 */
public interface MetadataManagerServices extends MetadataProvider {
   /************************************************************************
    * Attach and Detach Drivers
    ************************************************************************/
	// Attach a Metadata Driver
    /**
     * @hidden (why do we put this in the interface, if we don't implement it?)
     */
    public int attachDriver ( PropertyBag propertyBag ) throws MetadataManagerException;

	// Dech a Metadata Driver
    /**
     * @hidden (why do we put this in the interface, if we don't implement it?)
     */
	public int detachDriver (PropertyBag properties) throws MetadataManagerException;

	// Is the Driver Attached?
    /**
     * @hidden (why do we put this in the interface, if we don't implement it?)
     */
    public boolean isDriverAttached( PropertyBag properties );

   /************************************************************************
    * Get objects from any tier..
    ************************************************************************/

	// get an mdObject from the server side cache.
    /**
     * @hidden
     */
	public MDObject getMDObjectByID( long mdObjectID ) throws MetadataManagerException;

    // get mdObjects from the server side cache
    // Key is MDObject, value is relation
    /**
     * @hidden
     */
    public OrderedHashtable getChildrenTable ( MDObject mdObject, OrderedHashtable mdObjectIDs, int depth ) throws MetadataManagerException ;

    /**
     * @hidden
     */
    public OrderedHashtable getRelativeTable ( MDObject mdObject, OrderedHashtable mdObjectIDs ) throws MetadataManagerException ;

  /************************************************************************
  * Support for generating ID
  ************************************************************************/

  	/**
     * @hidden
     */
    public long generateMDObjectID();

  /************************************************************************
  * Support for User Objects ( for example XML object of Graph)
  * from the driver based on an MDObject.
  ************************************************************************/
    /**
     * @hidden (Hidden in client implementation)
     */
    public UserObject getUserObject( MDObject mdObject, String relation, String driverType ) throws MetadataManagerException;


    /**
     * Retrieves the <code>UserObject</code> for this object.
     * If the user object is not available locally, then this method
     * attempts to retrieve the user object from the underlying driver.
     *
     * @param mdObject
     * @param relation  The relationship between this object and its user object.
     * @param driverType  The type of driver that the user object uses.
     * @param args A hashtable that might contain objects that can help restore
     *             userObject on client side (reference resolver).
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @return  The <code>UserObject</code> for this object, or <code>null</code>
     *          if there is no <code>MetadataManagerServices</code> set for
     *          this object, or if <code>relation</code> or <code>driverType</code>
     *          is <code>null</code>.
     *
     * @status new
     */
    public UserObject getUserObject( MDObject mdObject, String relation, String driverType, Hashtable args) throws MetadataManagerException;

    /**
     * @hidden
     * Retrieves a <code>UserObject</code>.
     *
     * @param mdObject      mdObject that contains the userObject
     * @param persistable   Persistable object that will be passed 
     *                      to a handler when creating a new object
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     * @param args          hashtable that might contain objects that can help restore
     *                      userObject on client side.
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status hidden
     */
    public UserObject getUserObject( MDObject mdObject,
                                     Persistable persistable,
                                     String relation,
                                     String driverType,
                                     Hashtable args )
        throws MetadataManagerException;


    /**
     * @hidden
     * Returns the UserObject in the MDIndex without going throught the driver
     */
    public UserObject _getUserObject(MDObject mdObject, String relation);

    /**
     * @hidden
     */
    public void _addUserObject( MDObject mdObject, UserObject userObject, String relation );

    /**
     * @hidden
     */
    public void refreshUserObject( MDObject mdObject, String relation, String driverType ) throws MetadataManagerException;

    /**
     * Indicates whether this object is the client-side part of the
     * MetadataManager.
     *
     * @return  <code>true</code> if this is the client-side implementation,
     *          <code>false</code> if it is the middle-tier implementation.
     *
     * @status Reviewed
     */
    public boolean isBeanClass();

  /************************************************************************
  * Shortcut methods
  ************************************************************************/
 
 	  /**
     * Retrieves a metadata object that has the specified property values and
     * object type.
     *
     * @param  strPropertyName The property name to find.
     * @param  vstrPropertyValues A list of property values to find.
     * @param  objectType The type of object to retrieve.
     *
     * @return An object of <code>strObjectType</code> that has all of the
     *         specified property values, or <code>null</code> if the object
     *         could not be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented
     */
  	public MDObject getMDObject(String strPropertyName, Vector vstrPropertyValues, String objectType) throws MetadataManagerException;

  	/**
     * Retrieves a metadata object that has the specified property value and
     * object type.
     *
     * @param  strPropertyName The property name to find.
     * @param  strPropertyValue The property value to find.
     * @param  objectType The type of object to retrieve.
     *
     * @return An object of <code>strObjectType</code> that has the
     *         specified property value, or <code>null</code> if the object
     *         could not be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDObject getMDObject(String strPropertyName, String strPropertyValue, String objectType) throws MetadataManagerException;

  	/**
  	 * Retrieves the first <code>MDFolder</code> object that has a specified
     * property value.
     *
     * @param  strPropertyName a <code>String</code> value that
     *         represents the property name to find.
     * @param  strPropertyValue a String value that contains
     *         a property value to find.
     *
     * @return The first folder that has the <code>strPropertyValue</code> value
     *         for the <code>strPropertyName</code> property, or <code>null</code>
     *         if no folder can be found that has the property value.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDFolder getFolder(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * Retrieves the first selection that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first selection that has the specified property value, or
     *         <code>null</code> if no selection can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDSelection getSelection(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
	   * Retrieves the first <code>MDComponent</code> that has a specified
     * property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return <code>MDComponent</code> that has the specified property value,
     *         or <code>null</code> if no object can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status documented
     */
  	public MDComponent getComponent(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * Retrieves the first measure that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first measurethat has the specified property value, or
     *         <code>null</code> if no measure can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDMeasure getMeasure(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * Retrieves the first dimension that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first dimension that has the specified property value, or
     *         <code>null</code> if no dimension can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDDimension getDimension(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * Retrieves the first hierarchy that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first hierarchy that has the specified property value, or
     *         <code>null</code> if no hierarchy can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDHierarchy getHierarchy(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  	
  	/**
     * Retrieves the first attribute that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first attribute that has the specified property value, or
     *         <code>null</code> if no attribute can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDAttribute getAttribute(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
   
  	/**
     * Retrieves the first level that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first level that has the specified property value, or
     *         <code>null</code> if no level can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
  	public MDLevel getLevel(String strPropertyName, String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a folder from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the folder that
     *                 you want.
     *
     * @return The folder that has <code>strUniqueID</code>, or <code>null</code>
     *         if no folder can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDFolder getFolderByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a selection from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the selection that
     *                 you want.
     *
     * @return The selection that has <code>strUniqueID</code>, or <code>null</code>
     *         if no selection can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDSelection getSelectionByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a component from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the component that
     *                 you want.
     *
     * @return The component that has <code>strUniqueID</code>, or <code>null</code>
     *         if no component can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDComponent getComponentByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a measure from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the measure that
     *                 you want.
     *
     * @return The measure that has <code>strUniqueID</code>, or <code>null</code>
     *         if no measure can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDMeasure getMeasureByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a dimension from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the dimension that
     *                 you want.
     *
     * @return The dimension that has <code>strUniqueID</code>, or <code>null</code>
     *         if no dimension can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDDimension getDimensionByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a hierarchy from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the hierarchy that
     *                 you want.
     *
     * @return The hierarchy that has <code>strUniqueID</code>, or <code>null</code>
     *         if no hierarchy can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDHierarchy getHierarchyByUniqueID(String strPropertyValue) throws MetadataManagerException;
  	
  	/**
     * @hidden
     * Retrieves a attribute from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the attribute that
     *                 you want.
     *
     * @return The attribute that has <code>strUniqueID</code>, or <code>null</code>
     *         if no attribute can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDAttribute getAttributeByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * @hidden
     * Retrieves a level from a unique identifier.
     *
     * @param  strPropertyValue The unique ID that corresponds to the level that
     *                 you want.
     *
     * @return The level that has <code>strUniqueID</code>, or <code>null</code>
     *         if no level can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public MDLevel getLevelByUniqueID(String strPropertyValue) throws MetadataManagerException;
  
  	/**
     * Retrieves measures that have specified dimensions.
     * To retrieve measures that have any of the specified dimensions,
     * pass <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the measures that have all of the specified dimensions,
     * pass <code>MM.INTERSECTION</code>.
     *
     * @param dimensions The dimensions that the retrieved measures should have.
     * @param flag A constant that indicates whether to retrieve measures
     *              that have any of the <code>dimensions</code> or only the
     *              measures that have all of the <code>dimensions</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @see MM#UNION
     * @see MM#INTERSECTION
     *
     * @status documented
     */
  	public MDMeasure[] measuresOfDimensions(MDDimension[] dimensions, String flag) throws MetadataManagerException;

  	/**
     * Retrieves the dimensions that specified measures have.
     * To retrieve the dimensions that any of the measures has, pass
     * <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the dimensions that all of the measures have, pass
     * <code>MM.INTERSECTION</code>.
     *
     * @param measures The measures whose dimensions you want.
     * @param flag A constant that indicates whether to include the
     *              dimensions that any of the <code>measures</code> has or the
     *              dimensions that are common to all <code>measures</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status documented
     */
  	public MDDimension[] dimensionalityOfMeasures(MDMeasure[] measures, String flag) throws MetadataManagerException;

    /**
     * Retrieves the <code>MDFolder</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDFolder</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented, but is the <code>MDRoot</code> reference right, here?
     */
  	public MDFolder[] getFolders() throws MetadataManagerException;
  
    /**
     * Retrieves the <code>MDMeasure</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDMeasure</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented, but MDRoot?
     */
  	public MDMeasure[] getMeasures() throws MetadataManagerException;

  	/**
     * Retrieves the <code>MDDimension</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDDimension</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented, but MDRoot?
     */
  	public MDDimension[] getDimensions() throws MetadataManagerException;
  
  	/**
     * Retrieves the measure dimension for this <code>MetadataManager</code>.
     * The measure dimension is the dimension that lists available measures.
     *
     * @param dbString  The analytic workspace whose measure dimension you want.
     *
     * @return The measure dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     * 
     * @status NeedsChange Please add "Currently ignored" for dbString param
     */
  	public MDDimension getMeasureDimension(String dbString) throws MetadataManagerException;
  
  	//public MDHierarchy getHierarchyByName(String strDimension, String strHierarchy);
/*
  	public MDMeasure[] getAllMeasures();

  	public MDDimension[] getAllDimensions() throws MetadataManagerException;
*/
    /**
     * @hidden
     * Retrieves the <code>MDObject</code> at the specified path.
     * For objects in an analytic workspace, the path name should look
     * something like the following:
     * <P>
     * <code>machine_name:service_name!Root\folder\parent\child</code>
     * <P>
     * For objects in the repository, the path name should look something
     * like this:
     * <P>
     * <code>Root_folder/subfolder/object</code>
     * <P>
     * or
     * <p>
     * <code>subfolder/object</code>
     * <P>
     *
     * @param strPath The path of the <code>MDObject</code> that you want
     *                to retrieve.
     *
     * @return The <code>MDObject</code>.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method.
     *
     * @status hidden. If you unhide, please check my path information and
     * fix as necessary. THanks, Kris
     */
  	public MDObject getMDObjectByPath(String strPath) throws MetadataManagerException;

    /**
     * @hidden
     * Add mdObject to the cache.  This method will not call the driver and
     * save mdObject.
     *
     * @param mdObject MDObject that is to be added to cache.
     *
     * @status hidden
     */
    public void setMDObjectInCache( MDObject mdObject ) throws MetadataManagerException;

    /**
     * @hidden
     * Retrieve mdObject with specified properties from index.
     *
     * @param properties    properties that should exist in mdObject
     * @param fromIndex     <code>true</code>   return object from index only
     *                      <code>false</code>  return object from index. If
     *                                          not in index, go to driver.
     *
     * @return mdObject from index that has similar properties.  Null is
     *         returned if no mdObject found.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject getMDObject(PropertyBag properties, boolean fromIndex) throws MetadataManagerException;

    /**
     * @hidden
     */
    public MDObject[] getChildrenFromIndex(MDObject mdObject);
    
    /**
     * @hidden
     * Retrieve mdRoot set for this metadataManager
     *
     * @return  MDRoot set on metadataManager
     *
     * @status New
     */
    public MDRoot getMDRoot();

    /**
     * @hidden
     * Retrieve errorhandler from metadataManager
     *
     * @return  errorhandler
     *
     * @status New
     */
    public ErrorHandler getErrorHandler();

    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @return  an integer representing cachingSemantics of object of the specified type 
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status New
     */
    public int getCachingSemanticsByObjType(String objType);
    
    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @param   cachingSemantics caching semantics constant for the objType object type
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status New
     */
    public void setCachingSemanticsByObjType(String objType, int cachingSemantics);

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @param referenceResolver a hashtable that gets passed when getting a UserObject
     * @return  a Persistable object
     *
     * @status New
     */
    public Persistable getPersistableObject(MDObject mdObj, Hashtable referenceResolver) throws BINamingException;


    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @return  a Persistable object
     *
     * @status New
     */
    public Persistable getPersistableObject(MDObject mdObj) throws BINamingException;

    /**
     * @hidden
     */
    public int _setReferencedObject(PropertyBag props);

    /**
     * @hidden
     */
    public int _removeReferencedObject(PropertyBag propertyBag);

    /**
     * @hidden
     * Deprecated as of 3.0, please use the setMDObject with Attributes as argument
     * This method does not support extensible attributes.
     */
    public MDObject setMDObject(MDObject mdObject, PropertyBag properties) throws MetadataManagerException;

    /**
     * @hidden
     */
    public Hashtable getEnvironment();

    /**
     * Retrieve java.sql.Connection from the OLAP connection in the MetadataManager.
     * @return java.sql.Connection from the OLAP connection if an OLAP connection
     *         exist in the MetadataManager; null otherwise.
     * @status new
     */
    public java.sql.Connection getConnection() throws MetadataManagerException;

    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException;
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attrs, Attributes bindAttrs, Hashtable env) throws MetadataManagerException;    
    public Object lookup(MDFolder folder, Name name, Persistable persistable, Hashtable args, Attributes options) throws MetadataManagerException;
    
    public Object getObject(String id, String driverType) throws MetadataManagerException;
    
    /**
     * @hidden
     */
    public void addToLookupScopeCache(String oid, String path, Object sysAgg);
    /**
     * @hidden
     */
    public void clearLookupScopeCache();
    
    /**
     * @hidden
     */
    public void setMDObjectInCacheByOLAPIRunID(MDObject mdObject, Vector idVec);
    
    public MDObject getMDObjectByUniqueID(String uniqueID) throws MetadataManagerException;
    
    /**
     * @hidden
     */
    public void deferredObjectSetUp(MDObject obj);
    
    public void addMDObject(MDObject mdObject) throws MetadataManagerException;
}
