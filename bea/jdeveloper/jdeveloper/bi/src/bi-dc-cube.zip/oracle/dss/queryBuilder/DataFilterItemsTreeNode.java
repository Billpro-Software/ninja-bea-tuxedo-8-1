/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFilterItemsTreeNode.java /bibeans_root/22 2009/01/04 22:26:48 gkellam Exp $
 *
 * Copyright (c) 2005, 2008, Oracle and/or its affiliates.All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JTree;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.SavedDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.selection.dataFilter.VariableSettingDataFilter;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.selection.dataFilter.VariableSettingDataFilter;

/**
 * <pre>
 * <code>DataFilterItemsTreeNode</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/24/08 - Fix BUG 7667096 - CANNOT SPECIFY 'PARAMETER ACCEPTS
 *                         MULTIPLE VALUES' FOR COMPOUND DATA FILTERS.
 *    gkellam   12/03/08 - Continue variable work.
 *    gkellam   12/02/08 - Continue work on BUG 7586412 - BI_DATACONTROL: NEED
 *                         TO BE ABLE TO PASS SESSION VARIABLE VALUES TO RPD.
 *    gkellam   12/01/08 - Continue work on BUG 7586412 - BI_DATACONTROL: NEED
 *                         TO BE ABLE TO PASS SESSION VARIABLE VALUES TO RPD.
 *    gkellam   12/01/08 - Continue work on BUG 7586412 - BI_DATACONTROL: NEED
 *                         TO BE ABLE TO PASS SESSION VARIABLE VALUES TO RPD.
 *    bmoroze   05/27/08 - 
 *    gkellam   11/12/07 - Fix Bug 6623957 - INCORRECT 'TO' VALUE DISPLAYED FOR
 *                         'IN BETWEEN' DATA FILTER.
 *    gkellam   11/05/07 - Update TopBottomDataFilter parameter handling.
 *    gkellam   10/31/07 - Do not include null values in Data Filter labels.
 *    gkellam   08/29/07 - When processing members, if we find an MDItem,
 *                         return label instead of ID.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/15/07 - Put strings in resource files.
 *    gkellam   06/08/07 - Fix Bug 6067966 - QueryBuilder: Cannot parameterize
 *                         both operator and member.
 *    gkellam   05/10/07 - Fix Bug 5901482 - Missing Top/Bottom filters in the
 *                         QB add filter GUI.
 *    gkellam   04/27/07 - Fix Bug 5951398 - QueryBuilder: Creating a compound
 *                         'AND' Data Filter appears incorrect in shuttle.
 *    gkellam   03/09/07 - Modify parameter label format.
 *    gkellam   03/07/07 - Move common utility methods.
 *    gkellam   03/02/07 - Pass bUnformatted option to makeMembersLabel in
 *                         makeDataFilterLabel.
 *    gkellam   03/02/07 - Provide ability to retrieve unformatted labels.
 *    gkellam   02/28/07 - Tweak Parameter string generation.
 *    gkellam   02/26/07 - Add default parameter values.
 *    gkellam   02/26/07 - Continue makeParameter label work.
 * 
 */
public class DataFilterItemsTreeNode extends ItemsTreeNodeImpl {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  private static String EMPTY_STRING = "";

  /**
   * Used for <code>RangeDataFilter</code> parameter processing.
   */
  private final static int VALUE_FROM = 0;
  private final static int VALUE_TO = 1;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private static Icon m_iconDataFilter = QBUtils.getIcon (QBUtils.CONDITION_ICON);
  private static Icon m_iconVariableSettingDataFilter = QBUtils.getIcon (QBUtils.VALUE_ICON);

  private BaseDataFilter m_baseDataFilter = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public DataFilterItemsTreeNode (JTree jTree, ComponentNode componentNode, 
                                  ComponentContext componentContext) {
    super (jTree, componentNode, componentContext);
    setLeaf (true);
  }
   
  public DataFilterItemsTreeNode (ComponentContext componentContext) {
    super (null, null, componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public Icon getOpenIcon() {
    if (getDataFilter() instanceof VariableSettingDataFilter) {
      return m_iconVariableSettingDataFilter;  
    }
    else {
      return m_iconDataFilter;
    }
  }

  public Icon getClosedIcon() {
    return getOpenIcon();
  }

  public void setDataFilter (BaseDataFilter baseDataFilter) {
    m_baseDataFilter = baseDataFilter;
  }

  public BaseDataFilter getDataFilter() {
    if (m_baseDataFilter == null) {
      Object object = QBUtils.getObject(this, getContext());
      
      if (object instanceof DataFilter) {
        m_baseDataFilter = (DataFilter)object;
      }
    }

    return m_baseDataFilter;
  }

  public String getLabel (BaseDataFilter baseDataFilter, ComponentContext componentContext) {
    return getLabel (null, baseDataFilter, componentContext);
  }

  public String getLabel (BaseDataFilter baseDataFilter, ComponentContext componentContext, boolean bMembersOnly) {
    return getLabel (null, baseDataFilter, componentContext, bMembersOnly);
  }

  public String getLabel (BaseDataFilter baseDataFilter, ComponentContext componentContext, 
                                  boolean bMembersOnly, boolean bUnformatted) {
    return getLabel (null, baseDataFilter, componentContext, bMembersOnly, bUnformatted);
  }

  public static String makeMembersLabel (DataFilter dataFilter, ComponentContext componentContext) {
    String strLabel = EMPTY_STRING;
  
    if (dataFilter != null) {
      String strParameterLabel = makeParameterLabel (dataFilter);

      if (strParameterLabel != null) {
        strLabel += strParameterLabel;
        strLabel += DataUtils.makeMembersLabel (dataFilter.getCmpValues(), false);
      }
      else {
        strLabel += makeMembersLabel (dataFilter.getCmpValues());
      }
    }

    return strLabel;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected String getResourceString (String strID) {
    String strResourceString = strID;
    
    if ((getContext() != null) && (getContext().getResourceHandler() != null)) {
      strResourceString = 
        getContext().getResourceHandler().getResourceString (strID);
    }
    
    return strResourceString; 
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private static String makeParameterLabel (RangeDataFilter rangeDataFilter, int nValue) {

    String strParameterLabel = null; 
    String strParameterName = null; 

    if (rangeDataFilter != null) {
      switch (nValue) {
        case VALUE_FROM:
          strParameterName = 
            rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_START_VALUE);
          break;
          
        case VALUE_TO:
          strParameterName = 
            rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_END_VALUE);
          break;
          
        default:
          break;
      }
    }

    if (strParameterName != null) {
      strParameterLabel = ":" + strParameterName;
    }

    return strParameterLabel;
  }
  
  private static String makeParameterLabel (BaseDataFilter dataFilter) {
  
    String strParameterLabel = null; 
    String strParameterName = null; 

    if (dataFilter != null) {
    
      if (dataFilter instanceof TopBottomDataFilter) {
        strParameterName = 
          dataFilter.getAssociatedParameterName (TopBottomDataFilter.PARAMETER_COMPARISON_VALUE);
      }
      else {
        strParameterName = 
          dataFilter.getAssociatedParameterName (DataFilter.PARAMETER_COMPARISON_VALUES);
      }
     
      if (strParameterName != null) {
        if (DataUtils.canAcceptMultipleValues (dataFilter)) {
          strParameterLabel = 
            DataUtils.DATAFILTER_TOKEN_PARAMETER_ACCEPT_MULTIPLE_VALUES + strParameterName;
        }
        else {      
          strParameterLabel = DataUtils.DATAFILTER_TOKEN_PARAMETER + strParameterName;
        }
      }
             
      // Also check for existence of a ParameterMap entry
      /*
      if (strParameterName != null) {
        // Process the default parameter label
        ParameterUserHelper parameterUserHelper = dataFilter.getParameterUserHelper();

        if (parameterUserHelper != null) {
          String strParameterNames[] = 
            parameterUserHelper.getParameterNames ();
       
          // TODO: Support multiple parameter names
          if ((strParameterNames != null) && (strParameterNames.length != 0)) {
            strParameterName = strParameterNames[0];
          }
        }
      }         
      */
    }

    return strParameterLabel;
  }

  private String makeDataFilterLabel (DataFilter dataFilter, ComponentContext componentContext) {
    return makeDataFilterLabel (dataFilter, componentContext, false);
  }

  private String makeDataFilterLabel (DataFilter dataFilter, ComponentContext componentContext, 
                                             boolean bMemberOnly) {
    return makeDataFilterLabel (dataFilter, componentContext, bMemberOnly, false); 
  }

  private String makeDataFilterLabel (DataFilter dataFilter, ComponentContext componentContext, 
                                      boolean bMemberOnly, boolean bUnformatted) {
    String strLabel = EMPTY_STRING;
  
    if (dataFilter != null) {
    
      if (!bMemberOnly) {
        strLabel += makeItemLabel (dataFilter.getItem(), componentContext);
        strLabel += " ";
        strLabel += makeOperatorLabel (dataFilter.getCmpOperator());
        strLabel += " ";
      }
   
      String strParameterLabel = makeParameterLabel (dataFilter);

      if (strParameterLabel != null) {
        strLabel += strParameterLabel;
        strLabel += DataUtils.makeMembersLabel (componentContext, dataFilter.getCmpValues(), bUnformatted);
      }
      else {
        strLabel += DataUtils.makeMembersLabel (componentContext, dataFilter.getCmpValues(), bUnformatted);
      }
    }

    return strLabel;
  }

  private String makeDataFilterLabel (VariableSettingDataFilter variableSettingDataFilter, 
    ComponentContext componentContext, boolean bMemberOnly, boolean bUnformatted) {
    String strLabel = EMPTY_STRING;
  
    if (variableSettingDataFilter != null) {
    
      if (!bMemberOnly) {
        strLabel += makeItemLabel (variableSettingDataFilter.getItem(), componentContext);
        strLabel += " ";
        strLabel += makeOperatorLabel (variableSettingDataFilter.getCmpOperator());
        strLabel += " ";
      }
   
      String strParameterLabel = makeParameterLabel (variableSettingDataFilter);

      Vector vCmpValues = new Vector();
      
      String strCmpValue = variableSettingDataFilter.getCmpValue();
      if (strCmpValue != null) {
        vCmpValues.add (strCmpValue);
      }

      if (strParameterLabel != null) {
        strLabel += strParameterLabel;
        
        strLabel += DataUtils.makeMembersLabel (componentContext, 
          vCmpValues, bUnformatted);
      }
      else {
        strLabel += DataUtils.makeMembersLabel (componentContext, 
          vCmpValues, bUnformatted);
      }
    }

    return strLabel;
  }

  private String makeDataFilterLabel (TopBottomDataFilter topBottomDataFilter, ComponentContext componentContext, 
                                      boolean bMemberOnly, boolean bUnformatted) {
    String strLabel = EMPTY_STRING;
  
    if (topBottomDataFilter != null) {
    
      if (!bMemberOnly) {
        strLabel += makeItemLabel (topBottomDataFilter.getItem(), componentContext);
        strLabel += " ";
        strLabel += makeOperatorLabel (topBottomDataFilter.getOperator());
        strLabel += " ";
      }
   
      String strParameterLabel = makeParameterLabel (topBottomDataFilter);

      if (strParameterLabel != null) {
        strLabel += strParameterLabel;
        strLabel += DataUtils.makeMemberLabel (topBottomDataFilter.getValue(), bUnformatted);
      }
      else {
        strLabel += DataUtils.makeMemberLabel (topBottomDataFilter.getValue(), bUnformatted);
      }
    }

    return strLabel;
  }

  private String makeDataFilterLabel (RangeDataFilter rangeDataFilter, ComponentContext componentContext, 
                                      boolean bMemberOnly, boolean bUnformatted) {
    String strLabel = EMPTY_STRING;
  
    if (rangeDataFilter != null) {
    
      if (!bMemberOnly) {
        strLabel += makeItemLabel (rangeDataFilter.getItem(), componentContext);
        strLabel += " ";
        strLabel += makeOperatorLabel (rangeDataFilter.getOperator());
        strLabel += " ";
      }
      
      boolean bStartValueEmpty = false;
      boolean bEndValueEmpty = false;

      Vector vValues = new Vector();
      if (rangeDataFilter.getStartValue() != null) {
     
        String strParameterLabel = makeParameterLabel (rangeDataFilter, VALUE_FROM);
        if (strParameterLabel != null) {
          String strValue = 
            DataUtils.makeMemberLabel (rangeDataFilter.getStartValue(), bUnformatted);
  
          vValues.add (strParameterLabel + strValue);
        }
        else {    
          vValues.add (rangeDataFilter.getStartValue());
        }
      }
      else {
        vValues.add (EMPTY_STRING);
        bStartValueEmpty = true;
      }
      
      if (rangeDataFilter.getEndValue() != null) {
        String strParameterLabel = makeParameterLabel (rangeDataFilter, VALUE_TO);
        if (strParameterLabel != null) {
          String strValue = 
            DataUtils.makeMemberLabel (rangeDataFilter.getEndValue(), bUnformatted);
  
          vValues.add (strParameterLabel + strValue);
        }
        else {    
          vValues.add (rangeDataFilter.getEndValue());
        }
      }
      else {
        vValues.add (EMPTY_STRING);
        bEndValueEmpty = true;
      }
        
      if (!(bStartValueEmpty && bEndValueEmpty)) {
        strLabel += DataUtils.makeMembersLabel (vValues, bUnformatted);
      }    
    }

    return strLabel;
  }


  private static String makeMembersLabel (Vector vstrMembers) {
    return DataUtils.makeMembersLabel (vstrMembers, true);
  }

  private static String makeItemLabel (String strItemId, ComponentContext componentContext) {
    Object object = QBUtils.getObject(strItemId, componentContext);
    return (object != null) ? object.toString() : strItemId;
  }

  private String makeOperatorLabel (int nCmpOperator) {
    if (nCmpOperator == DataFilter.OP_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_EQUAL);
    }
    else if (nCmpOperator == DataFilter.OP_GREATER) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER);
    }
    else if (nCmpOperator == DataFilter.OP_GREATER_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER_EQUAL);
    }
    else if (nCmpOperator == DataFilter.OP_LESS) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS);
    }
    else if (nCmpOperator == DataFilter.OP_LESS_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS_EQUAL);
    }
    else if (nCmpOperator == DataFilter.OP_NOT_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_EQUAL);
    }
    else if (nCmpOperator == DataFilter.OP_CONTAINS_ALL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ALL);
    }
    else if (nCmpOperator == DataFilter.OP_BEGINS_WITH) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BEGINS_WITH);
    }
    else if (nCmpOperator == DataFilter.OP_ENDS_WITH) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_ENDS_WITH);
    }
    else if (nCmpOperator == DataFilter.OP_CONTAINS_ANY) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ANY);
    }
    else if (nCmpOperator == DataFilter.OP_DOES_NOT_CONTAIN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_DOES_NOT_CONTAIN);
    }
    else if (nCmpOperator == DataFilter.OP_LIKE) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LIKE);
    }
    else if (nCmpOperator == DataFilter.OP_NOT_LIKE) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_LIKE);
    }
    else if (nCmpOperator == TopBottomDataFilter.OP_TOP) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_TOP);
    }
    else if (nCmpOperator == TopBottomDataFilter.OP_BOTTOM) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BOTTOM);
    }
    else if (nCmpOperator == DataFilter.OP_IS_NULL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NULL);
    }
    else if (nCmpOperator == DataFilter.OP_IS_NOT_NULL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_NULL);
    }
    else if (nCmpOperator == RangeDataFilter.OP_BETWEEN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN);
    }
    else if (nCmpOperator == RangeDataFilter.OP_NOT_BETWEEN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN);
    }

    return null;
  }

  private String getLabel (String strLabel, BaseDataFilter baseDataFilter, 
                                  ComponentContext componentContext) {
    return getLabel (null, baseDataFilter, componentContext, false);
  }

  private String getLabel (String strLabel, BaseDataFilter baseDataFilter, 
                                  ComponentContext componentContext, boolean bMemberOnly) {
    return getLabel (strLabel, baseDataFilter, componentContext, bMemberOnly, false);
  }

  private String getLabel (String strLabel, BaseDataFilter baseDataFilter, 
      ComponentContext componentContext, boolean bMemberOnly, boolean bUnformatted) {
  
    if (strLabel == null) {
      strLabel = EMPTY_STRING;
    }

    if (baseDataFilter instanceof DataFilter) {
      strLabel += 
        makeDataFilterLabel ((DataFilter)baseDataFilter, componentContext, bMemberOnly, bUnformatted);
    }
    else if (baseDataFilter instanceof TopBottomDataFilter) {
      strLabel += 
        makeDataFilterLabel ((TopBottomDataFilter)baseDataFilter, componentContext, bMemberOnly, bUnformatted);
    }
    else if (baseDataFilter instanceof RangeDataFilter) {
      strLabel += 
        makeDataFilterLabel ((RangeDataFilter)baseDataFilter, componentContext, bMemberOnly, bUnformatted);
    }
    else if (baseDataFilter instanceof SavedDataFilter) {
      strLabel += QBUtils.getLabel(baseDataFilter, componentContext);
    }
    else if (baseDataFilter instanceof VariableSettingDataFilter) {
      strLabel += 
        makeDataFilterLabel ((VariableSettingDataFilter)baseDataFilter, componentContext, bMemberOnly, bUnformatted);
    }
    else if (baseDataFilter instanceof CompoundDataFilter) {
      
      CompoundDataFilter compoundDataFilter = (CompoundDataFilter)baseDataFilter;
      strLabel += "(";
      
      BaseDataFilter[] filters = compoundDataFilter.getDataFilters();
      
      if (filters != null) {
        for (int nIndex = 0; nIndex < filters.length; nIndex++) {
          // Add in each DataFilter
          strLabel += getLabel (strLabel, filters[nIndex], componentContext);
      
          if (nIndex < filters.length - 1) {
            strLabel += 
              compoundDataFilter.getOperator() == CompoundDataFilter.AND ? 
                " AND " : " OR ";
          }
        }
      }
      
      strLabel += ")";
    }
    
    return strLabel;
  }
}
