/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/query/MeasureDataTypeFilter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.query;

import java.io.Serializable;

import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MM;

// import oracle.dss.calculation.client.MDCalcAttributes;

/**
 * @hidden
 * 
 * Filter measures by available data types.
 * 
 */
public class MeasureDataTypeFilter implements BIFilter, Serializable {

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////
  
  /**
   * @hidden
   * 
   * A vector of valid data types for the measures.
   * 
   * @status hidden
   */
  private String[] m_strValidDataTypes = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor.
   * 
   * Filter measures by available data types.
   * 
   * @param strValidDataTypes A <code>String[]</code> of valid data types.
   * 
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   */
  public MeasureDataTypeFilter (String[] strValidDataTypes) {
    setValidDataTypes (strValidDataTypes);
  }

  /**
   * Determines whether to include a particular search result in the
   * final search outcome.
   *
   * @param biSearchResult A <code>BISearchResult</code> to evaluate.
   * 
   * @return <code>boolean</code> which is <code>true</code> if 
   *         <code>BISearchResult</code> should be included, <code>false</code> 
   *         otherwise.
   *         
   * @status New
   */
  public boolean evaluate (BISearchResult biSearchResult) {
    
    // Simply return false if we have a null BISearchResult
    if (biSearchResult == null)
      return false;

    // By default, include BISearchResult if it doesn't represent a MDMeasure or
    // MDMeasureCalc
    boolean bInclude = true;
    
    if (MM.MEASURE.equals (biSearchResult.getObjectType()) || 
       (MM.CALCULATION.equals (biSearchResult.getObjectType()) ||
       (MM.ITEM.equals (biSearchResult.getObjectType())))) {
    
      // Initialize the data type
      String strDataType = null;
      bInclude = false;
      
      // Attempt to retrieve Calculation data types performantly    
      /** gek 11/03/06  
      if (MM.CALCULATION.equals (biSearchResult.getObjectType())) {
        strDataType = 
          MDCalcAttributes.getDataType (biSearchResult.getAttributes(), null);      
      }
      */

      // If data type not found, attempt to get it from the underlying object
      if (strDataType == null) {
        Object objResult = biSearchResult.getObject();
      
        if (objResult != null) {
          if (objResult instanceof MDMeasure) {
            strDataType = ((MDMeasure)objResult).getDataType();
          }
          else if (objResult instanceof MDItem) {
            strDataType = ((MDItem)objResult).getDatatype();
          }
        }      
      }

      bInclude = isValidDataType (strDataType);
    }    
    
    return bInclude;
  }

  /**
   * @hidden
   * 
   * Determines if the data type is valid based on the specified array of data 
   * types.  A null data types value implies that all non-null data types are
   * valid.
   * 
   * @param strDataType A <code>String</code> which represents the data type to 
   *        check.
   *
   * @return <code>boolean</code> which is <code>true</code> if the data type 
   *         is valid, <code>false</code> otherwise.
   * 
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * 
   * @status hidden
   */ 
  private boolean isValidDataType (String strDataType) {
    String[] strValidDataTypes = getValidDataTypes();
    
    if (strValidDataTypes == null) {
      return true;
    }
    else if (strDataType != null) {
      for (int nIndex = 0; nIndex < strValidDataTypes.length; nIndex++) {
        if (strDataType.equals (strValidDataTypes[nIndex])) {
          return true;
        }
      }
    }
    
    return false;
  }

  /**
   * Specifies the valid data types.
   *
   * @param strValidDataTypes A <code>String[]</code> of valid data types.
   * 
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * 
   * @status New
   */
  public void setValidDataTypes (String[] strValidDataTypes) {
    m_strValidDataTypes = strValidDataTypes;
  }

  /**
   * Retrieves the valid data types.
   *
   * @return <code>String[]</code> of valid data types.
   * 
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * 
   * @status New
   */
  public String[] getValidDataTypes () {
    return m_strValidDataTypes;
  }
}