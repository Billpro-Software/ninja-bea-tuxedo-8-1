/*
 * DefaultBuilderDialog.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import javax.swing.JLabel;

import java.util.EventObject;
import java.util.Vector;
import java.util.Enumeration;

import java.text.MessageFormat;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import oracle.bali.ewt.event.Cancelable;

import oracle.bali.ewt.wizard.BaseWizard;
import oracle.bali.ewt.wizard.ImageWizardPage;
import oracle.bali.ewt.wizard.WelcomeWizardPage;
import oracle.bali.ewt.wizard.WizardDialog;
import oracle.bali.ewt.wizard.WizardEvent;
import oracle.bali.ewt.wizard.WizardListener;
import oracle.bali.ewt.wizard.WizardPage;
import oracle.bali.ewt.wizard.WizardValidateListener;
import oracle.bali.ewt.help.HelpUtils;

import oracle.dss.datautil.client.DataUtilException;
import oracle.dss.datautil.client.DataUtilRuntimeException;
import oracle.dss.datautil.client.resource.DataUtilClientBundle;
import oracle.dss.datautil.gui.CustomImageWizardPage;
import oracle.dss.datautil.gui.CustomReentrantWizard;
import oracle.dss.datautil.gui.CustomWelcomeWizardPage;
import oracle.dss.datautil.gui.CustomWizard;
import oracle.dss.datautil.gui.CustomWizardConst;
import oracle.dss.datautil.gui.CustomWizardPage;

import oracle.dss.datautil.gui.panel.StandardPanel;
import oracle.dss.datautil.gui.panel.WelcomePanel;

import oracle.dss.datautil.gui.panel.event.PanelEventListener;

import oracle.dss.util.ErrorHandler;

/**
 * Default implementation of a container for multiple panels.
 *
 * @status Documented
 */
public class DefaultBuilderDialog extends WizardDialog
                                  implements BuilderDialog
{                                                            
    //-----------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-----------------------------------------------------------------------

    /**
     * @hidden
     *
     * The BuilderContext object for the Builder Dialog instance.
     *
     * @status protected
     */
    protected BuilderContext m_builderContext = null;

    /**
     * @hidden
     *
     * Reference to the instance of the wizard used by the WizardDialog.
     *
     * @status protected
     */
    protected BaseWizard m_wizard = null;

    /**
     * @hidden
     *
     * The listener for panel events.
     *
     * @status protected
     */
    protected BuilderDialogPanelEventListener m_panelEventListener = null;

    /**
     * @hidden
     *
     * The Step title format of the builder dialog instance
     *
     * @status protected
     */
    protected MessageFormat m_strStepTitle = null;

    /**
     * @hidden
     *
     * The NonStep title format of the wizard.
     *
     * @status protected
     */
    protected MessageFormat m_strNonStepTitle = null;
    
    /**
     * @hidden
     *
     * Builder title
     *
     * @status protected
     */
    protected String m_strTitle = null;

    /**
     * @hidden
     *
     * Is the CalcBuilder being initialized?
     *
     * @status private
     */
    private boolean m_bInitializing = false;

    /**
     * @hidden
     *
     * Welcome panel page
     *
     * @status private
     */
    private WelcomeWizardPage m_wizardPageWelcome  = null;

    //-----------------------------------------------------------------------
    // CONSTRUCTOR
    //-----------------------------------------------------------------------

    /**
     * Constructor that specifies the dialog that serves as the
     * parent for the <code>DefaultBuilderDialog</code> object.
     *
     * @param builderContext  The <code>BuilderContext</code> object that is
     *                        associated with this Builder object.
     * @param parentDialog    The parent dialog of the builder.
     * @param strTitle        The title of the dialog.
     *
     * @status documented
     */
    public DefaultBuilderDialog ( BuilderContext builderContext, 
                                  Dialog parentDialog, String strTitle ) 
    {
        // We will set the wizard associated with this dialog later 
        super ( null, parentDialog, true );
        initDialog ( builderContext, parentDialog, strTitle );
    }
    
    /**
     * Constructor that specifies the frame that serves as the
     * parent for the  <code>DefaultBuilderDialog</code> object.
     *
     * @param builderContext  The <code>BuilderContext</code> object that is
     *                        associated with this Builder object.
     * @param parentFrame     The parent frame of the builder.
     * @param strTitle        The title of the dialog.
     *
     * @status documented
     */
    public DefaultBuilderDialog ( BuilderContext builderContext, 
                                  Frame parentFrame, String strTitle ) 
    {
        // We will set the wizard associated with this dialog later 
        super ( null, parentFrame, true );
        initDialog ( builderContext, parentFrame, strTitle );
    }

    //-----------------------------------------------------------------------
    // PUBLIC METHODS
    //-----------------------------------------------------------------------

    /**
     * Retrieves the default title for the <code>BuilderDialog</code>.
     *
     * @return The default title.
     *
     * @status documented
     */
    public String getDefaultTitle ( )
    {
        return null;
    }
    
    /**
     * Retrieves the panel for the specified index.
     *
     * @param nIndex The index of the specified panel.
     *
     * @status documented
     */
    public StandardPanel getPanel ( int nIndex )
    {
        Component   panel       = null;
        WizardPage  wizardPage  = null;
        
        if ( nIndex < 0 )
            return null;

        wizardPage = getWizardPage ( nIndex );
        if ( null == wizardPage )
            return null;
        
        panel = getInteractiveContent ( wizardPage );
        if ( ! ( panel instanceof StandardPanel ) )
            return null;
        
        return ( StandardPanel ) panel;
    }
    
    /**
     * Retrieves the panel with the specified identifier
     *
     * @param panelId The identifier of the specified panel.
     *
     * @status Documented
     */
    public StandardPanel getPanel ( String panelId )
    {
        Component   panel       = null;
        int         nIndex      = -1;
        WizardPage  wizardPage  = null;

        if ( null == panelId )
            return null;
        
        wizardPage = getWizardPage ( panelId );
        if ( null == wizardPage )
            return null;
        
        panel = getInteractiveContent ( wizardPage );
        if ( ! ( panel instanceof StandardPanel ) )
            return null;
        
        return ( StandardPanel ) panel;
    }
    
    /**
     * Retrieves the panel identifier at the specified index.
     *
     * @param nIndex   The index of the specified panel.
     *
     * @return   The identifier of the specified panel.
     *
     * @status Documented
     */
    public String getPanelId ( int nIndex )
    {
        Component   panel       = null;
        WizardPage  wizardPage  = null;
        
        wizardPage = getWizardPage ( nIndex );
        if ( null == wizardPage )
            return null;
            
        panel = getInteractiveContent ( wizardPage );
        if ( null == panel )
            return null;
                
        if ( panel instanceof StandardPanel )
            return ( ( StandardPanel ) panel ).getId ( );
            
        return null;
    }

    /**
     * Retrieves the index of the panel in the wizard.
     *
     * @param panelId  The identifier of the specified panel.
     *
     * @return The index of the panel with the specified panel identifier.
     *
     * @status Documented
     */
    public int getPanelIndex ( String panelId )
    {
        WizardPage  wizardPage  = null;

        wizardPage = getWizardPage ( panelId );
        if ( null == wizardPage )
            return -1;
            
        return wizardPage.getIndex ( );
    }

    /**
     * Retrieves the wizard page for the specified index.
     *
     * @param nIndex The index of the panel in the wizard.
     *
     * @return The <code>WizardPage</code> object for the specified index.
     *
     * @status Documented
     */
    public WizardPage getWizardPage ( int nIndex )
    {
      int intWizardPageCount = m_wizard.getPageCount ( );
        if ( nIndex < 0 || nIndex > intWizardPageCount || intWizardPageCount == 0 )
            return null;
        
        return m_wizard.getPageAt ( nIndex );
    }

    /**
     * Retrieves the wizard page for the specified panel identifier.
     *
     * @param panelId The panel identifier of the wizard page.
     * 
     * @return The <code>WizardPage</code> object for the specified panel identifier.
     *
     * @status Documented
     */
    public WizardPage getWizardPage ( String panelId )
    {
        Component   panel       = null;
        int         nIndex      = -1;
        WizardPage  wizardPage  = null;
        
        if ( null == panelId )
            return null;

        for ( nIndex = 0; nIndex < m_wizard.getPageCount ( ); nIndex++ )
        {
            wizardPage = m_wizard.getPageAt ( nIndex );
            if ( null == wizardPage )
                continue;
                
            panel = getInteractiveContent ( wizardPage );
            if ( null == panel )
                continue;
                
            if ( panel instanceof StandardPanel )
            {
                if ( panelId.equalsIgnoreCase ( ( ( StandardPanel ) panel ).getId ( ) ) )
                    return wizardPage;
            }                
        }

        return null;
    }

    //-----------------------------------------------------------------------
    // Begin - Implementation of the BuilderDialog interface
    //-----------------------------------------------------------------------

    /**
     * Retrieves the <code>BuilderContext</code> that is associated with the
     * this <code>BuilderDialog</code>.
     *
     * @return A reference to the <code>BuilderContext</code> interface.
     *
     * @status Documented
     */
    public BuilderContext getBuilderContext ( )
    {
        return m_builderContext;
    }
    
    /**
     * Retrieves the component that is associated with the
     * <code>BuilderDialog</code>.
     *
     * @return A reference to the component.
     *
     * @status Documented
     */
    public Component getComponent ( )
    {
        return this;
    }
    
    /**
     * Initializes the contents of the <code>BuilderDialog</code>.
     *
     * @return  <code>true</code> if the operation was successful;
     *          <code>false</code> if the operation was not successful.
     *
     * @status Documented
     */
    public boolean initialize ( )
    {
        boolean bRetVal     = false;
        String  builderMode = null;

        if ( ! doBasicValidation ( ) )
            return false;
        
        // Mark the start of the initialization process.
        m_bInitializing = true;

        // Retrieve the builder mode.
        builderMode = m_builderContext.getMode ( );
        if ( null == builderMode )
            return false;
        
    if ( builderMode.equalsIgnoreCase ( BuilderContext.WIZARD ) )
        {   // Create a linear wizard
            bRetVal = createWizard ( );
        }
        else if ( builderMode.equalsIgnoreCase ( BuilderContext.TABBED ) )
        {   // Create a reentrant wizard
          bRetVal = createReentrantWizard ( );
        }
        
        if ( ! bRetVal )
            return bRetVal;

        // Set the wizard that is contained by the dialog.
        setWizard ( m_wizard );

        // Set the size of the wizard.
        setWizardSize ( m_builderContext.getSize ( ) );
        
        // Set the help of the wizard.
        HelpUtils.setHelpProvider( m_wizard, m_builderContext.getHelpProvider ( ) );
        
        // Mark the end of the initialization process.
        m_bInitializing = false;
        
        return bRetVal;
    }
    
    /**
     * Refreshes the contents of the <code>BuilderDialog</code>.
     *
     * @return <code>true</code> if the operation was successful;
     *         <code>false</code> if the operation was nut successful.
     *
     * @status Documented
     */
    public boolean refresh ( )
    { 
      Vector currentPanels  = null;
      Vector newPanels    = null;
      Vector removePanels   = new Vector();
      Vector addPanels    = new Vector();

      // Get the current list of panels.
      currentPanels = getPanels ( );

        if ( null == currentPanels || 0 == currentPanels.size ( ) )
            return false;
    
      // Get the new list of panels.
        newPanels = m_builderContext.getPanelList ( );
        
        if ( null == newPanels || 0 == newPanels.size ( ) )
            return false;
            
      // Get the vector of panels to remove and to add.
        Utils.difference ( currentPanels, newPanels, removePanels, addPanels );
        
      removeWizardPages ( removePanels );
      addWizardPages ( addPanels, newPanels );
      
        return true;
    }

    /**
     * Signals the <code>BuilderDialog</code> to run the dialog.
     *
     * @return <code>true</code> if the dialog was dismissed with an OK command;
     *         <code>false</code> if the dialog was cancelled.
     * @throws <code>DataUtilException</code> if an error is encountered.   
     *
     * @status Documented
     */
    public boolean run() throws DataUtilException {
      return runDialog ( );
    }

    /**
     * @hidden
     *
     */
    public void addNotify() {
        super.addNotify();
        toFront();
    }

    public boolean runDialog() {
      try {
        boolean bRetVal = false;
        if (m_wizard == null || !doBasicValidation())
          return false;

        // Select the default page specified by the BuilderContext
        bRetVal = selectDefaultPanel ( );
        if (!bRetVal)
          return bRetVal;

        // Run the dialog. Yooo hooo
        bRetVal = super.runDialog();

        // gek 10/27/01 Fix Bug 2068677: Unchecking show this page next time
        //              doesn't work.
        //
        // gek 11/17/01 Fix Bug 2110037: Remember state of Welcome ShowNextTime
        //              even if user cancels.
        if (m_wizardPageWelcome != null) {
          if (getBuilderContext() instanceof DefaultBuilderContext) {
            ((DefaultBuilderContext)getBuilderContext()).setShowWelcomeNextTime (
              m_wizardPageWelcome.isShowNextTime());
          }

        m_wizardPageWelcome = null;
        }

        return bRetVal;
      }

      catch (Exception e) {
        // gek 11/20/01 Send exception to ErrorHandler if it exists
        if (getErrorHandler() != null) {
            getErrorHandler().error(e, "DefaultBuilderDialog", "runDialog");
          return false;
        }
        else {
          // Rethrow the wrapped exception
          throw new DataUtilRuntimeException (
            DataUtilClientBundle.EXC_UNEXPECTED_ERROR, e);
        }
      }
    }

    /**
     * Specifies whether the specified panel is to be shown or hidden.
     *
     * @param panelId    The identifier of the specified panel.
     * @param bVisible   <code>true</code> if the panel is to be marked visible,
     *                   <code>false</code> if the panel is to be hidden.
     *
     * @status Documented
     */
    public boolean setPanelVisible ( String panelId, boolean bVisible )
    {
        WizardPage wizardPage = null;

        if ( null == m_wizard  || null == panelId )
            return false;

        wizardPage = getWizardPage ( panelId );
        if ( null == wizardPage )
            return false;

        // Set the visible property of the wizard page.
        wizardPage.setVisible ( bVisible );

        return true;
    }

    //-----------------------------------------------------------------------
    // End - Implementation of the BuilderDialog interface
    //-----------------------------------------------------------------------

    //-----------------------------------------------------------------
    // NON PUBLIC METHODS
    //-----------------------------------------------------------------

    /**
     * @hidden
     *
     * Retrieves the <code>ErrorHandler</code> associated with the
     * <code>DefaultBuilderDialog</code>.
     *
     * @return <code>ErrorHandler</code> representing the error handler.
     * @status protected
     *
     */
    protected ErrorHandler getErrorHandler () {
      ErrorHandler errorHandler = null;

      BuilderContext builderContext = getBuilderContext();
      if ((builderContext != null) && (builderContext instanceof DefaultBuilderContext)) {
        errorHandler = ((DefaultBuilderContext) builderContext).getErrorHandler();
      }

      return errorHandler;
    }

    /**
     * @hidden
     *
     * Adds a panel to the Builder.
     *
     * @param panel The panel to be added to the Wizard instance.
     * @param panelId The Id of the panel that will come after the new panel.
     *
     * @status protected
     */
    protected boolean addWizardPage (StandardPanel panel, String panelId) {
      Component     interactivePanel  = null;
      String        builderMode       = null;
      WizardPage    wizardPage        = null;
      WizardPage    addedPage         = null;
      WizardPage    targetWizardPage  = null;

      // Basic validation.
      if (m_wizard == null || panel == null)
        return false;
          
      if (!validateWizardPage (panel))
        return false;

      // Get the target panel for the given wizard page.
      if (panelId != null) {
        targetWizardPage = getWizardPage (panelId);
        if (targetWizardPage == null)
          return false;
      }

      // Get the interactive panel for this wizard page.
      interactivePanel = panel.getComponent ( );
      if (interactivePanel == null)
        return false;

      builderMode = m_builderContext.getMode ( );
      if (builderMode == null)
        return false;

      if (builderMode.equalsIgnoreCase (BuilderContext.WIZARD)) {
        // Check if this is a wizard page panel
        if (interactivePanel instanceof WelcomePanel) {

          // Use Bali's new JEWT 4.2.x Wizard page to generate our welcome
          // panel.

          // We will use JEWT to generate a welcome panel based on our
          // StandardPanel's image, title and description.
          //
          // The wizard panel placed within the page is layed out as follows:
          //
          //  --------------------------------------------------
          // |Stretched| Title                                  |
          // |image    |                                        |
          // |         | Description (within multi-line label)  |
          // |         |                                        |
          // |         | x Show this page next time             |
          //  --------------------------------------------------
          //
          //
          // We will then wrap the newly generated welcome panel so that it
          // looks like a StandardPanel to the rest of the BIBeans wizard.

          wizardPage =
            new CustomWelcomeWizardPage (panel.getImage(), panel.getTitle(),
              ((WelcomePanel)panel).getDescription(), panel);

          // gek 10/27/01 Fix Bug 2068677: Unchecking show this page next time
          //              doesn't work.

          // Remember the Welcome page so we can determine whether it should be
          // shown next time or not
          m_wizardPageWelcome = (WelcomeWizardPage)wizardPage;

          boolean bShowWelcomeNextTime = true;
          if (getBuilderContext() instanceof DefaultBuilderContext) {
            bShowWelcomeNextTime =
              ((DefaultBuilderContext)getBuilderContext()).isShowWelcomeNextTime();
          }

          ((CustomWelcomeWizardPage)wizardPage).setShowNextTime(bShowWelcomeNextTime);

          // gek 11/17/01 Fix Bug 1837656: SetPanelVisible method does not work
          // Determine whether the panel is visible.
          boolean bIsVisible = getBuilderContext().isPanelVisible (panel.getId());

          // Determine if we should hide Welcome panel based on its current
          // visibility
          if (!bShowWelcomeNextTime && bIsVisible) {
            getBuilderContext().setPanelVisible (panel.getId(), false);
            bIsVisible = false;
          }

          // Determine whether the Welcome page is included or not based on its
          // visibility.
          setWelcomePageIncluded(bIsVisible);
        }
        else {
          wizardPage =
            new CustomImageWizardPage (interactivePanel,
              panel.getImage(), panel.getTitle());
        }
      }
      else if (builderMode.equalsIgnoreCase (BuilderContext.TABBED)) {
        wizardPage = new CustomWizardPage ( interactivePanel, panel.getTitle ( ) );
      }
      else {
        wizardPage = null;
      }

      if (wizardPage == null)
        return false;

      if (targetWizardPage == null)
        addedPage = m_wizard.addPage (wizardPage);
      else
        addedPage = m_wizard.addPage ( wizardPage, targetWizardPage );

      if (builderMode.equalsIgnoreCase(BuilderContext.TABBED)) {
        int componentCount = m_wizard.getComponentCount();
        for (int i = 0; i < componentCount; i++) {
          if (m_wizard.getComponent(i) instanceof JTabbedPane) {
            JTabbedPane tabPane = (JTabbedPane)m_wizard.getComponent(i);
            addedPage.setInitialFocus(tabPane);
            break;
          }
        }
      }

      if (addedPage != null) {   
        // Add the panel event listener
        panel.addPanelEventListener (m_panelEventListener);
      
        // Listen to the wizard events.
        addedPage.addWizardValidateListener (new BuilderWizardValidateAdapter ());
        return true;
      }
          
      return false;
    }
    
    /**
     * @hidden
     *
     * Adds a vector of panels to the wizard.
     *
     * @param addPanels Vector containing the panels to add to the wizard.
     * @param newPanels Vector containing an ordered list of all new panels.
     *
     * @status protected
     */
    protected boolean addWizardPages ( Vector addPanels, Vector newPanels )
    { 
      Object      element     = null;
      StandardPanel   panel     = null;
      int       nIndex      = -1;
      StandardPanel targetPanel   = null;
        
      if ( ( null == addPanels ) || ( null == newPanels ) )
        return false;
      
        for ( Enumeration e = addPanels.elements ( ); e.hasMoreElements ( ); )
      {
        panel = ( StandardPanel ) e.nextElement ( );
        targetPanel = getPanel ( panel, newPanels );

        if ( null == targetPanel )
          addWizardPage ( panel, null );
        else
          addWizardPage ( panel, targetPanel.getId ( ) );
      }
      
      return true;
    }
        
    /**
     * @hidden
     *
     * Retrieves the interactive working area of the wizard page.
     *
     * @param wizardPage The working area of the wizard page.
     *
     * @status protected
     */
    protected Component getInteractiveContent ( WizardPage wizardPage )
    {
        String builderMode  = null;
        
        builderMode = m_builderContext.getMode ( );
        if ( builderMode.equalsIgnoreCase ( BuilderContext.WIZARD ) )
        {
            if ( wizardPage instanceof ImageWizardPage )
                return ( ( ImageWizardPage ) wizardPage ).getInteractiveArea ( );
        }
        else if ( builderMode.equalsIgnoreCase ( BuilderContext.TABBED ) )
        {
            if ( wizardPage instanceof WizardPage )
                return ( ( WizardPage ) wizardPage ).getContent ( );
        }
        return null;
    }

    /**
     * @hidden
     *
     * Retrieves the target page index of the wizard. Attempts to 
     * query the current page for the target page id. If the current 
     * page does not know the target page the index of the next sequential 
     * page is returned.
     *
     * @param nCurPageIndex The current page index.
     * @param nWizardState  The state of the wizard. Valid values include
     * CustomWizardConst.CUSTOMWIZARD_PREVIOUS and CustomWizardConst.CUSTOMWIZARD_NEXT.
     *
     * @status protected
     */
    protected int getTargetPageIndex ( int nCurPageIndex, int nWizardState )
    {
        Component   panel           = null;
        String      targetPanelId   = null;
        WizardPage  targetPage      = null, curPage = null;
        
        if ( nCurPageIndex < 0 || 
             nCurPageIndex > m_wizard.getPageCount ( ) )
            return -1;             
            
        if ( CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE == nWizardState )
            return -1;
        
        curPage = m_wizard.getPageAt ( nCurPageIndex );
        if ( null == curPage ) 
            return -1;
        
        switch ( nWizardState )
        {
            case CustomWizardConst.CUSTOMWIZARD_NEXT:
            {
                targetPage = m_wizard.getNextPage ( curPage ); 
                break;
            }                
            case CustomWizardConst.CUSTOMWIZARD_PREVIOUS:
            {
                targetPage = m_wizard.getPreviousPage ( curPage );
                break;
            }
            default:
            {
                targetPage = null;
                break;
            }                
        }
        if ( null == targetPage )
            return -1;
        
        return targetPage.getIndex ( );
    }
    
    /**
     * @hidden
     *
     * Retrieves the hint object to be passed in to the panel during
     * the validation process.
     *
     * @param panelId The id of the specified panel.
     *
     * @return The hint object.
     *
     * @status protected
     */
    protected Object getValidateContentsHint ( String panelId )
    {
        return null;
    }
    
    /**
     * @hidden
     *
     * Returns the state of the wizard.
     *
     * @return The state of the wizard. Valid values include public members of the class
     * CustomWizardConst.
     *
     * @status protected
     */
    protected int getWizardState() {
      int    nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
      String builderMode  = null;

      builderMode = m_builderContext.getMode();
      if (builderMode.equalsIgnoreCase (BuilderContext.WIZARD)) {
        nWizardState = ( ( CustomWizard ) m_wizard ).getWizardState();
      }
      else if (builderMode.equalsIgnoreCase (BuilderContext.TABBED)) {
        nWizardState = ((CustomReentrantWizard) m_wizard).getWizardState();
      }
      else {
        nWizardState = CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE;
      }

      return nWizardState;
    }

    /**
     * @hidden
     *
     * Returns the current <code>BaseWizard</code> panel.
     *
     * @return <code>StandardPanel</code> representing the current active panel.
     * @status protected
     */
    protected StandardPanel getCurrentPanel() {
      StandardPanel panelCurrent      = null;
      int           nCurrentPageIndex = -1;
      String        strPanelID        = null;

      // Get the current wizard
      BaseWizard baseWizard = getWizard();
      if (baseWizard == null)
        return null;

      // Attempt to retrieve the current page
      nCurrentPageIndex = baseWizard.getCurrentPageIndex();
      if (nCurrentPageIndex < 0 || nCurrentPageIndex > baseWizard.getPageCount()) {
        return null;
      }

      // Attempt to retrieve the ID of the current page
      strPanelID = getPanelId (nCurrentPageIndex);
      if (strPanelID == null)
        return null;

      // Return the panel associated with the ID
      return getPanel (strPanelID);
    }

    /**
     * @hidden
     *
     * Process the Apply and Finish events.
     *
     * @status protected
     */
    protected boolean processApplyFinishEvents () {
      int           nWizardState      = -1;
      int           nCurrentPageIndex = -1;
      Object        panelContent      = null;
      StandardPanel panelCurrent      = null;

      // Attempt to retrieve the wizard
      BaseWizard baseWizard = getWizard();
      if (baseWizard == null)
        return false;

      // Retrieve the current wizard state
      nWizardState = getWizardState();
      if (nWizardState == CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE)
        return false;

      if (nWizardState != CustomWizardConst.CUSTOMWIZARD_APPLY &&
          nWizardState != CustomWizardConst.CUSTOMWIZARD_FINISH)
        return false;

      // Retrieve the current panel
      panelCurrent = getCurrentPanel();
      if (panelCurrent == null)
          return false;

      // Retrieve the panel's content
      panelContent = panelCurrent.getPanelContent();
      if (panelContent == null)
        return false;

      // Update the builder's context
      getBuilderContext().setBuilderContent (panelContent);

      // Success
      return true;
    }

    /**
     * @hidden
     *
     * Processes the panel events receieved from the child panels.
     *
     * @param event The event object describing the panel event.
     *
     * @return true if the event was processed successfully, false otherwise.
     *
     * @status protected
     */
    protected boolean processPanelEvent ( EventObject event )
    {        
        return true;
    }
    
    /**
     * @hidden
     *
     * Removes a panel from the Builder.
     *
     * @param panel The panel to be removed from the Wizard instance. 
     *
     * @status protected
     */
    protected boolean removeWizardPage ( String panelId )
    {
        WizardPage    targetWizardPage  = null;

        // Basic validation.
        if ( null == m_wizard || null == panelId )
            return false;
            
        // Get the target panel for the given wizard page.
      targetWizardPage = getWizardPage ( panelId );
      if ( null == targetWizardPage )
        return false;
        
      m_wizard.removePage ( targetWizardPage );

        return true;
    }
    
    /**
     * @hidden
     *
     * Selects the panel at with the specified id.
     *
     * @param panelId The id of the specified panel.
     * @param bDoValidate true if the target page needs to be validated, false otherwise.
     *
     * @return true if the panel was selected, false otherwise.
     *
     * @status protected
     */
  protected boolean selectPanel ( String panelId, boolean bDoValidate )
    {
        boolean     bRetVal     = false;
        Component   panel       = null;
        String      builderMode = null;
        WizardPage  wizardPage  = null;          
            
        if ( null == panelId || null == m_wizard )
            return false;
        
        wizardPage = getWizardPage ( panelId );
        if ( null == wizardPage )
            return false;
        
        panel = getInteractiveContent ( wizardPage );
        if ( ! ( panel instanceof StandardPanel ) )
            return false;
            
        builderMode = m_builderContext.getMode ( );
        if ( builderMode.equalsIgnoreCase ( BuilderContext.WIZARD ) )
        {
            ( ( CustomWizard ) m_wizard ).selectPage ( wizardPage, bDoValidate );
        }
        else if ( builderMode.equalsIgnoreCase ( BuilderContext.TABBED ) )
        {
            ( ( CustomReentrantWizard ) m_wizard ).selectPage ( wizardPage, bDoValidate );
        }
        else
        {
            return false;
        }            
        return true;
    }
    
    /**
     * @hidden
     *
     * Informs the specified panel of the wizard that it is active.
     *
     * @param panelId The id of the specified panel.
     * @param bIsActive true if the panel is active, false otherwise.
     *
     * @return true if the panel was activated, false otherwise.
     *
     * @status protected
     */
  protected boolean setActive (String panelId, boolean bIsActive) throws DataUtilException {
    boolean     bRetVal     = false;
    Object      panel       = null;
    WizardPage  wizardPage  = null;

    if (panelId == null)
      return false;

    wizardPage = getWizardPage (panelId);
    if (wizardPage == null)
      return false;

    panel = getInteractiveContent (wizardPage);
    if (panel == null)
      return false;

    if (!(panel instanceof StandardPanel))
      return false;

    // Set the wait cursor.
    setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));

    if (panel instanceof JPanel) {
      // gek 10/02/01 Update the wizard page based on the panel
      String strDescription =
        ((JPanel)panel).getAccessibleContext().getAccessibleDescription();

      if (strDescription != null)
        wizardPage.setAccessibleDescription (strDescription);
      else
        wizardPage.setAccessibleDescription ("");

      // gek 10/17/01 Update the wizard page label based on the panel
      wizardPage.setLabel(((StandardPanel)panel).getTitle());
    }

    bRetVal = ((StandardPanel)panel).setActive (bIsActive);

    // Set the default cursor.
    setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));

    // The seems to lose activation after a next or previous operation.
    
    // gek 05/13/04 Don't allow the DefaultBuilderDialog to request focus.  
    //              If it does, the focus is incorrect when the Back button is 
    //              pressed.  
    
    //  if (bIsActive)
    //    requestFocus ();

    return bRetVal;
  }

    /**
     * @hidden
     *
     * Sets the enable/disable state of the Finish button.
     *
     * @boolean true if the Finish button is to be enabled, false otherwise.
     *
     * @status protected
     */
    protected void setFinishButtonState ( boolean bEnable )
    {
        if ( null == m_wizard )
            return;
            
        if ( m_wizard instanceof CustomWizard )
            ( ( CustomWizard ) m_wizard ).setMustFinish ( ! bEnable );
        else if ( m_wizard instanceof CustomReentrantWizard )
            ( ( CustomReentrantWizard ) m_wizard ).setMustFinish ( ! bEnable );
    }
    
    /**
     * @hidden
     *
     * Sets the enable/disable state of the Finish button. Application
     * developers should override this method to set the state of the 
     * Finish button in the Builder Dialog.
     *
     * @panelId The id of the target panel based on which the state of 
     * the Finish button is specified.
     *
     * @status protected
     */
    protected void setFinishButtonState ( String panelId )
    {
    }
    
    /**
     * @hidden
     *
     * Sets the size of the wizard.
     *
     * @param size The size of the wizard.
     * 
     * @status protected
     */ 
  protected void setWizardSize ( Dimension size )
  {   
        String builderMode = null;
        
      if ( null == size || null == m_wizard )
          return;
        
        builderMode = m_builderContext.getMode ( );
        if ( null == builderMode )
            return;
            
    if ( builderMode.equalsIgnoreCase ( BuilderContext.WIZARD ) )
        {
            ( ( CustomWizard ) m_wizard ).setWizardSize ( size );
        }
        else if ( builderMode.equalsIgnoreCase ( BuilderContext.TABBED ) ) 
        {
            ( ( CustomReentrantWizard ) m_wizard ).setWizardSize ( size );
        }
    }
    
    /**
     * @hidden
     *
     * Updates the title of the Builder Dialog.
     *
     * @param panelId The id of the current panel.
     * 
     * @status protected
     */
/*  protected boolean updateTitle ( String panelId )
    {
        int             nPanelIndex     = -1, nPanelCount = -1;
        StandardPanel   panel           = null;
        String          builderMode     = null, strPanelTitle = null;
        String [ ]      strTitleArgs    = null;
        
        if ( null == panelId )
            return false;
        
        builderMode = getBuilderContext ( ).getMode ( );
        if ( null == builderMode )
            return false;
        
        // The title only needs to be updated for the wizard mode.
        if ( ! builderMode.equalsIgnoreCase ( BuilderContext.WIZARD ) )
            return false;

        panel = getPanel ( panelId );
        if ( null == panel )
            return false;

        strPanelTitle = panel.getTitle ( );
        // I am paranoid...
        if ( null == strPanelTitle || 0 == strPanelTitle.length ( ) )
            return false;

        // If the current pane is the default Welcome panel, use the 
        // non step format for displaying the dialog title.
        if ( panelId.equalsIgnoreCase ( WelcomePanel.WELCOME_PANEL_ID ) ) 
        {
            strTitleArgs = new String [ ] { m_strTitle, strPanelTitle };
            setTitle ( m_strNonStepTitle.format ( strTitleArgs ) );
            return true;
        }

        // Get the index of the current panel (not counting non visible panels
        // and the welcome panel)
        nPanelIndex = getPanelIndex ( panelId, true );
        
        // Get the total visible panel count.
        nPanelCount = getPanelCount ( true );

        strTitleArgs = new String [ ] { m_strTitle,
                                        Integer.toString ( nPanelIndex ),
                                        Integer.toString ( nPanelCount ),
                                        strPanelTitle };

        setTitle ( m_strStepTitle.format ( strTitleArgs ) );

        return true;
    }
*/

  /**
   * @hidden
   *
   * Validates the wizard state during the Apply or Finish event.
   *
   * @param event The WizardEvent object describing the event.
   *
   * @return true if the validation was successful, false otherwise.
   *
   * @status protected
   */
  protected boolean validateApplyFinishEvent (WizardEvent event) throws DataUtilException {
    boolean         bRetVal         = false;
    BuilderContext  builderContext  = null;
    int             nCurPageIndex   = -1;
    int             nIndex          = -1;
    int             nWizardState    = -1;
    Object          panelContent    = null;
    StandardPanel   curPanel        = null;
    StandardPanel   checkPanel      = null;
    String          curPanelId      = null;
    String          checkPanelId    = null;

    if (event == null || m_wizard == null)
      return false;

    builderContext = getBuilderContext();
    if (builderContext == null)
      return false;

    nWizardState = getWizardState ();
    if (nWizardState == CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE)
      return false;

    if (nWizardState != CustomWizardConst.CUSTOMWIZARD_APPLY &&
        nWizardState != CustomWizardConst.CUSTOMWIZARD_FINISH)
      return false;

    nCurPageIndex = m_wizard.getCurrentPageIndex ();
    if (nCurPageIndex < 0 || nCurPageIndex > m_wizard.getPageCount()) {
      ((Cancelable) event).cancel();
      return false;
    }

    // Retrieve the panel id of the current page
    curPanelId = getPanelId ( nCurPageIndex);

    // The current page is losing activation.
    bRetVal = setActive (curPanelId, false);
    if (!bRetVal) {
      ((Cancelable)event).cancel();
      return false;
    }

    // Retrieve the panel of the current panel
    curPanel = getPanel (curPanelId);
    if (curPanel == null) {
      ((Cancelable)event).cancel();
      return false;
    }

    // Retrieve the content of the current panel
    panelContent = curPanel.getPanelContent();
    if (panelContent == null) {
      // ((Cancelable) event).cancel ();
      // return false;

      // gek 08/23/00 In the case of QueryBuilder for instance, it is valid not
      // to have a panel content.
      return true;
    }

    // Ask all the panels to validate the panel content.
    for (nIndex = 0; nIndex < m_wizard.getPageCount(); nIndex++) {
      // Retrieve the ID of panel at the current position
      checkPanelId = getPanelId (nIndex);
      if (checkPanelId == null) {
        ((Cancelable)event).cancel();
        return false;
      }

      // If this panel is not enabled, do not validate the step
      // with this panel.
      if (!builderContext.isPanelVisible (checkPanelId))
        continue;

      // gek 11/29/01 Fix Bug 2130712: Pressing finish button on template panel
      //              does not save calculation.
      //
      //              Update each panel with the contents of the currently
      //              selected panel.

      // Set the target panel content. The panel content is used during
      // panel validation.
      StandardPanel targetPanel = getPanel (checkPanelId);
      if (targetPanel != null) {
        if (targetPanel.getPanelContent() == null) {
          targetPanel.setPanelContent (panelContent);
        }
      }

      // Attempt to validate the contents of the panel.
      if (!validateContents (checkPanelId)) {
        ((Cancelable) event).cancel();
        return false;
      }
    }

    return true;
  }

    /**
     * @hidden
     *
     * Informs the specified panel of the wizard to process the validate event.
     *
     * @param panelId The id of the specified panel.
     *
     * @return true if the validation was successful, false otherwise.
     *
     * @status protected
     */
  protected boolean validateContents ( String panelId )
    {
        boolean     bRetVal         = false;
        Component   panel           = null;
        int         nWizardState    = -1;
        WizardPage  wizardPage      = null;
        
        if ( null == panelId )
            return false;

        wizardPage = getWizardPage ( panelId );
        if ( null == wizardPage )
            return false;
        
        panel = getInteractiveContent ( wizardPage );
        if ( null == panel )
            return false;
            
        if ( ! ( panel instanceof StandardPanel ) )
            return false;
            
        // Set the wait cursor.
        setCursor ( Cursor.getPredefinedCursor ( Cursor.WAIT_CURSOR ) );

        bRetVal = ( ( StandardPanel ) panel ).validateContents (
                                              getValidateContentsHint ( panelId ) );

        // Set the default cursor.
        setCursor ( Cursor.getPredefinedCursor ( Cursor.DEFAULT_CURSOR ) );
        
        return bRetVal;
    }
    
    /**
     * @hidden
     *
     * Validates the next and previous events in the wizard. If the 
     * validation is successful, the target pages are initialized as well.
     *
     * @param wizardEvent The WizardEvent object describing the event.
     *
     * @return true if the validation was successful, false otherwise.
     *
     * @status protected
     */
    protected boolean validateNextPreviousEvent ( WizardEvent event ) throws DataUtilException
    {
        boolean         bRetVal         = false;
        int             nCurPageIndex   = -1, nTargetPageIndex = -1;
        int             nWizardState    = -1;
        Object          panelContent    = null;
        StandardPanel   curPanel        = null, targetPanel = null;
        String          curPanelId      = null, targetPanelId = null;

        if ( null == event || null == m_wizard )
            return false;
        
        nWizardState = getWizardState ( );
        if ( CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE == nWizardState )
            return false;

        if ( CustomWizardConst.CUSTOMWIZARD_NEXT != nWizardState &&
             CustomWizardConst.CUSTOMWIZARD_PREVIOUS != nWizardState )
            return false;

        nCurPageIndex = m_wizard.getCurrentPageIndex ( );
        if ( nCurPageIndex < 0 ||
             nCurPageIndex > m_wizard.getPageCount ( ) ) 
        {                 
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }
            
        curPanelId = getPanelId ( nCurPageIndex ); 
        // The current page is losing activation.
        bRetVal = setActive ( curPanelId, false );
        if ( ! bRetVal )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        // Allow validation to happen on the current page.
        bRetVal = validateContents ( curPanelId );
        if ( ! bRetVal )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        curPanel = getPanel ( curPanelId );
        if ( null == curPanel )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        panelContent = curPanel.getPanelContent ( );
            
        nTargetPageIndex = getTargetPageIndex ( nCurPageIndex, 
                                                getWizardState ( ) );
        if ( nTargetPageIndex < 0 || 
             nTargetPageIndex > m_wizard.getPageCount ( ) ) 
        {   
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        targetPanelId = getPanelId ( nTargetPageIndex );

        // Set the target panel content. The panel content is used during
        // panel initialization.
        targetPanel = getPanel ( targetPanelId );
        if ( targetPanel != null )
            targetPanel.setPanelContent ( panelContent );

        // The target page is getting activation
        bRetVal = setActive ( targetPanelId, true );
        if ( ! bRetVal )
        {   
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        // Set the state of the Finish button.
        setFinishButtonState ( targetPanelId );
        
        return bRetVal;
    }

    /**
     * @hidden
     *
     * Validates the page changing event in the wizard. If the 
     * validation is successful, the target pages are initialized as well.
     *
     * @param wizardEvent The WizardEvent object describing the event.
     *
     * @return true if the validation was successful, false otherwise.
     *
     * @status protected
     */
    protected boolean validatePageChangingEvent ( WizardEvent event ) throws DataUtilException
    {
        boolean         bRetVal         = false;
        int             nCurPageIndex   = -1, nTargetPageIndex = -1;
        int             nWizardState    = -1;
        Object          panelContent    = null;
        StandardPanel   curPanel        = null, targetPanel = null;
        String          curPanelId      = null, targetPanelId = null;
        WizardPage      targetPage      = null;

        if ( null == event || null == m_wizard )
            return false;
        
        nWizardState = getWizardState ( );
        if ( CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE == nWizardState )
            return false;

        if ( CustomWizardConst.CUSTOMWIZARD_PAGECHANGING != nWizardState )
            return false;
            
        nCurPageIndex = m_wizard.getCurrentPageIndex ( );
        if ( nCurPageIndex < 0 || 
             nCurPageIndex > m_wizard.getPageCount ( ) ) 
        {                 
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }
            
        curPanelId = getPanelId ( nCurPageIndex ); 
        // The current page is losing activation.
        bRetVal = setActive ( curPanelId, false );
        if ( ! bRetVal )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        // Allow validation to happen on the current page.
        bRetVal = validateContents ( curPanelId );
        if ( ! bRetVal )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }
            
        curPanel = getPanel ( curPanelId );
        if ( null == curPanel )
        {
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        panelContent = curPanel.getPanelContent ( );

        targetPage = event.getPage ( );
        if ( null == targetPage )
        {   
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }
        
        nTargetPageIndex = targetPage.getIndex ( );
        if ( nTargetPageIndex < 0 || 
             nTargetPageIndex > m_wizard.getPageCount ( ) ) 
        {   
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        targetPanelId = getPanelId ( nTargetPageIndex );

        // Set the target panel content. The panel content is used during
        // panel initialization.
        targetPanel = getPanel ( targetPanelId );
        if ( targetPanel != null )
            targetPanel.setPanelContent ( panelContent );
            
        // The target page is getting activation
        bRetVal = setActive ( targetPanelId, true );
        if ( ! bRetVal )
        {   
            ( ( Cancelable ) event ).cancel ( );
            return false;
        }

        return bRetVal;
    }
    
  /** 
   * @hidden
   *
   * Validates the panel object. Checks to see if the panel object
   * already exists in the wizard.
   *
   * @param panel The panel object to be validated.
   *
   * @return true if the panel object was validated, false if not.
   *
   * @status protected
   */
    protected boolean validateWizardPage ( StandardPanel panel )
    {        
      Vector existingPanels = new Vector ();
      
        for (int i=0; i<m_wizard.getPageCount(); i++)
        {
          existingPanels.addElement(getPanelId(i));
        }
        
        // Check to see if this ID already exists.
        return (!Utils.contains(existingPanels, panel.getId()));
    }
    
    /**
     * @hidden
     *
     * Creates and initialize a Reentrant wizard.
     *
     * @status protected
     */
    protected boolean createReentrantWizard() {
      // Create a reentrant wizard.
      if (m_wizard == null) {
        m_wizard = new CustomReentrantWizard();

        // Listen to the wizard events.
        m_wizard.addWizardListener (new BuilderWizardAdapter());
      }

      // Add panels to the reentrant wizard.
      return initWizardPages();
    }

    /**
     * @hidden
     *
     * Creates and initialize a linear wizard.
     *
     * @status protected
     */
    protected boolean createWizard() {
      // Create a reentrant wizard.
      if (m_wizard == null) {
        m_wizard = new CustomWizard();

        // Listen to the wizard events.
        m_wizard.addWizardListener (new BuilderWizardAdapter());
      }

      // Add panels to the linear wizard.
      return initWizardPages();
    }

    /**
     * @hidden
     *
     * Performs basic validation on this object.
     * NOTE: Do not check for existence of MetadataManager or QueryContext.
     * We assume that the BuilderContext object has validated itself. Change
     * requested by KC from the JDev team.
     *
     * @status private
     */
    private boolean doBasicValidation ( )
    {
        if ( null == m_builderContext )
            return false;

        return true;            
    }

    /**
     * @hidden
     *
     * Retrieves the first StandardPanel existing in the current WizardPage list
     * that follows the given StandardPanel.
     *
     * @param panel The source StandardPanel to look for.
     * @param newPanels The list of new panels from the BuilderContext.
     *
     * @status private
     */
    private StandardPanel getPanel( StandardPanel panel, Vector newPanels )
    {
      WizardPage    page      = null;
      int       nIndex      = -1;
      StandardPanel targetPanel   = null;
      
      if ( ( null == panel ) || ( null == newPanels ) )
        return null;
            
    for (nIndex = Utils.indexOf ( panel, newPanels ); ( nIndex + 1 ) < newPanels.size ( ); nIndex++ )
    {
      targetPanel = ( StandardPanel ) newPanels.elementAt ( nIndex + 1 );
      
      if ( null == targetPanel )
        return null;

      page = getWizardPage ( targetPanel.getId ( ) );
      
      if ( null != page )
        return targetPanel;
    }
      
      return null;
    }
    
    /**
     * @hidden
     *
     * Retrieves the count of panels in the Builder instance based on if 
     * they are visible or not visible.
     *
     * @param  bVisible The required panel state.
     *
     * @status private
     */
    private int getPanelCount ( boolean bVisible )
    {
        Component       component       = null;
        int             nIndex          = -1;
        int             nVisibleCount   = -1, nHiddenCount = -1;
        StandardPanel   curPanel        = null;
        String          curPanelId      = null;
        WizardPage      curWizardPage   = null;
        
        if ( null == m_wizard )
            return -1;
        
        nVisibleCount = 0;
        nHiddenCount = 0;
        for ( nIndex = 0; nIndex < m_wizard.getPageCount ( ); nIndex++ )
        {
            curWizardPage = getWizardPage ( nIndex );
            if ( null == curWizardPage )
                return -1;
            
            component = getInteractiveContent ( curWizardPage );
            if ( ! ( component instanceof StandardPanel ) )
                continue;
            
            curPanel = ( StandardPanel ) component;
            
            curPanelId = curPanel.getId ( );
            if ( null == curPanelId )
                continue;
                
            if ( curPanelId.equalsIgnoreCase ( WelcomePanel.WELCOME_PANEL_ID ) )
                continue;
                         
            if ( curWizardPage.isVisible ( ) )
            {
                nVisibleCount++;
            }                
            else
            {
                nHiddenCount++;
            }            
        }        
        
        return ( bVisible ? nVisibleCount : nHiddenCount );
    }
    
    /**
     * @hidden
     *
     * Retrieves the index of the panel in the Builder instance based on if 
     * the preceding panels are visible or not visible and excluding the 
     * Welcome panel.
     *
     * @param panelId The panel id whose index needs to be calculated
     * @param bVisible The required panel state.
     *
     * @status private
     */
    private int getPanelIndex ( String panelId, boolean bVisible )
    {
        Component       component       = null;
        int             nIndex          = -1, nVisibleIndex = -1;
        int             nHiddenIndex    = -1;
        StandardPanel   curPanel        = null;
        String          curPanelId      = null;
        WizardPage      curWizardPage   = null;
        
        if ( null == m_wizard || null == panelId )
            return -1;

        // Set the initial index to zero as we have a ONE based index
        // for the builder panels.
        nVisibleIndex = 0;
        nHiddenIndex = 0;
        for ( nIndex = 0; nIndex < m_wizard.getPageCount ( ); nIndex++ )
        {
            curWizardPage = getWizardPage ( nIndex );
            if ( null == curWizardPage )
                return -1;
            
            component = getInteractiveContent ( curWizardPage );
            if ( ! ( component instanceof StandardPanel ) )
                continue;
            
            curPanel = ( StandardPanel ) component;
            
            curPanelId = curPanel.getId ( );
            if ( null == curPanelId )
                continue;
                
            if ( curPanelId.equalsIgnoreCase ( WelcomePanel.WELCOME_PANEL_ID ) )
                continue;
                         
            if ( curWizardPage.isVisible ( ) )
            {
                nVisibleIndex++;
            }                
            else
            {
                nHiddenIndex++;
            }            
            
            if ( curPanelId.equalsIgnoreCase ( panelId ) )
                break;
        }
        
        return ( bVisible ? nVisibleIndex : nHiddenIndex );
    }

    /**
     * @hidden
     *
     * Retrieves the panels.
     *
     * @status private
     */
    private Vector getPanels ( )
    {
        StandardPanel   panel       = null;
        int       nIndex    = -1;
        Vector      panels    = null;
        
        if ( ( null == m_wizard ) || ( m_wizard.getPageCount() < 0 ) )
            return null;
        
        panels = new Vector ( );
        for ( nIndex = 0; nIndex < m_wizard.getPageCount ( ); nIndex++ )
        {
            panel = getPanel ( nIndex );
            if ( panel != null )
            {
              panels.addElement( panel );
            }
        }
        
      // Get the new list of panels.
        if ( null == panels || 0 == panels.size ( ) )
            return null;
        
        return ( panels );
    }
    
    /**
     * @hidden
     *
     * Initialization method called by constructors.
     *
     * @status private
     */
    private void initDialog ( BuilderContext builderContext, 
                                  Component parentComponent, String strTitle ) 
    {
        m_builderContext = builderContext;
        
        m_panelEventListener = new BuilderDialogPanelEventListener ( );

        // Use the passed-in title. If not specified, get the default builder title
        m_strTitle = strTitle;
        if ( null == m_strTitle || 0 == m_strTitle.length ( ) )
            m_strTitle = getDefaultTitle ( );
        
        // Set the title of the dialog.
        // Workaround for WizardDialog bug
        if (builderContext.getMode().equals(BuilderContext.WIZARD))
          setWizardTitle(m_strTitle);
        else if (builderContext.getMode().equals(BuilderContext.TABBED))
          setTitle(m_strTitle);
        
        // Init the builder title format's
        m_strStepTitle = new MessageFormat(
                             Utils.getIntlString("builderStepTitle", getLocale()));
        m_strNonStepTitle = new MessageFormat(
                                Utils.getIntlString("builderNonStepTitle", getLocale()));

        // Center the component over the parent component.
        setCenterOver ( parentComponent );
    }
    
    /**
     * @hidden
     *
     * Adds wizard pages to the wizard object.
     *
     * @return true if the wizard was initialized, false otherwise.
     *
     * @status private
     */
    protected boolean initWizardPages () {
      boolean         bVisible    = false;
      int             nIndex      = -1, nPanelCount = -1;
      Object          component   = null;
      StandardPanel   panel       = null;
      String          builderMode = null, panelId = null;
      Vector          listPanels  = null;

      if ( null == m_wizard )
        return false;

      listPanels = m_builderContext.getPanelList ( );
      if (listPanels == null || listPanels.size() == 0)
        return false;

      nPanelCount = listPanels.size ( );

      builderMode = m_builderContext.getMode ( );
      if (builderMode == null)
        return false;

      for (nIndex = 0; nIndex < nPanelCount; nIndex++) {
        component = listPanels.elementAt ( nIndex );
        if (component == null || !(component instanceof StandardPanel)) {
          continue;
        }

        panel = ( StandardPanel ) component;

        panelId = panel.getId ();
        if (panelId == null )
          continue;

        panel.setBuilderContext (getBuilderContext ());
        panel.setContainer (this);

        // Add the wizard page into the wizard.
        addWizardPage (panel, null);

        bVisible = m_builderContext.isPanelVisible (panelId);

        // Hide the panel if it's visibility is turned off.
        if (!bVisible)
          setPanelVisible (panelId, bVisible);
      }

      return true;
    }

    /**
     * @hidden
     *
     * Removes a vector of panels from the wizard.
     *
     * @status private
     */
    private boolean removeWizardPages ( Vector panels )
    {
      StandardPanel panel   = null;
      
      if ( ( null == panels ) || ( 0 == panels.size ( ) ) )
        return false;
      
        for ( Enumeration e = panels.elements ( ); e.hasMoreElements ( ); )
        {
          panel = ( StandardPanel ) e.nextElement ( );
          removeWizardPage ( panel.getId ( ) );
        }
        
        return true;
    }
    
    /**
     * @hidden
     *
     * Selects the default page of the wizard. If no default page has
     * been specified, selects the zeroth page.
     *
     * @return true if the default panel was selected, false otherwise.
     *
     * @status private
     */
  private boolean selectDefaultPanel ( ) throws DataUtilException
    {
        boolean         bRetVal         = false, bVisible = false;
        int             nCurPageIndex   = -1, nTargetPageIndex = -1;
        StandardPanel   targetPanel     = null;
        String          defPanelId      = null, targetPanelId = null;
        WizardPage      curWizardPage   = null, targetWizardPage = null;
        
        defPanelId = m_builderContext.getDefaultPanelId ( );
        if ( null == getWizardPage ( defPanelId ) )
        {   // If the page does not exist in the wizard, default to the zeroth page.
            defPanelId = getPanelId ( 0 );
        }            
        
        bVisible = m_builderContext.isPanelVisible ( defPanelId );
        // If the page is not visible attempt to determine the nearest
        // page visible to it. First search in the forward direction and
        // then in the backward direction.
        if ( bVisible )
        {
            targetPanelId = defPanelId;
        }            
        else 
        {
            curWizardPage = getWizardPage ( defPanelId );
            if ( curWizardPage != null )
                nCurPageIndex = curWizardPage.getIndex ( );
            nTargetPageIndex = getTargetPageIndex ( nCurPageIndex, 
                                                    CustomWizardConst.CUSTOMWIZARD_NEXT );
            if ( nTargetPageIndex < 0 )
                nTargetPageIndex = getTargetPageIndex ( nCurPageIndex, 
                                                        CustomWizardConst.CUSTOMWIZARD_PREVIOUS );
            if ( nTargetPageIndex < 0 )
                return false;
                             
            targetPanelId = getPanelId ( nTargetPageIndex );                                                        
            // Extreme paranoid case.
            if ( ! m_builderContext.isPanelVisible ( targetPanelId ) )
                targetPanelId = null;
        }
        
        if ( null == targetPanelId )
            return false;
        
        // Set the builder content into the target panel.
        targetPanel = getPanel ( targetPanelId );
        if ( targetPanel != null && getBuilderContext ( ) != null )
        {   // Set the builder content into the first selected panel.
            targetPanel.setPanelContent ( getBuilderContext ( ).getBuilderContent ( ) );
        }                
        
        // Tell the panel that it is being activated.
        bRetVal = setActive ( targetPanelId, true );
        if ( ! bRetVal ) 
            return bRetVal;

        // Select the desired page.
        bRetVal = selectPanel ( targetPanelId, false );
        if ( bRetVal )
        {   // Update the title of the dialog. This is only needed in wizard mode.
            //updateTitle ( targetPanelId );
        }        
        
        // Set the state of the Finish button.
        setFinishButtonState ( targetPanelId );
        
        return bRetVal;
    }

    //-----------------------------------------------------------------------
    // INNER CLASSES
    //-----------------------------------------------------------------------

    /**
     * @hidden
     *
     * The listener for wizard page selection changed events.
     */
    protected class BuilderWizardAdapter implements WizardListener
    {
        public BuilderWizardAdapter() {
        }
        
        public void wizardSelectionChanged ( WizardEvent event )
        {
            int         nIndex      = -1;
            String      panelId     = null;
            WizardPage  wizardPage  = null;
            
            // Do nothing if we are initializing
            if ( m_bInitializing ) 
                return;
    
            wizardPage = event.getPage ( );
            if ( null == wizardPage ) 
                return;
            
            nIndex = wizardPage.getIndex ( );
            if ( nIndex < 0 ||
                 nIndex > m_wizard.getPageCount ( ) )
                return;
            
            panelId = getPanelId ( nIndex );
            if ( null == panelId )
                return;

            //updateTitle ( panelId );
        }

        /**
         * @hidden
         */
        public void wizardApplyState (WizardEvent event) {
          try {
            processApplyFinishEvents ( );
            m_builderContext.doApply ( );
          }

          catch (Exception e) {
            // gek 11/20/01 Send exception to ErrorHandler if it exists
            if (getErrorHandler() != null) {
              getErrorHandler().error(e, "BuilderWizardAdapter", "wizardApplyState");

              // Cancel the current event
              ((Cancelable) event).cancel();
            }
            else  {
              // Rethrow the wrapped exception
              throw new DataUtilRuntimeException (
                DataUtilClientBundle.EXC_UNEXPECTED_ERROR, e);
            }
          }
        }

       /**
        * @hidden
        */
        public void wizardCanceled ( WizardEvent event )        
        {
            m_builderContext.doCancel ( );
        }

        /**
         * @hidden
         */
        public void wizardFinished (WizardEvent event) {
          try {
            processApplyFinishEvents ( );
            m_builderContext.doOK ( );
          }

          catch (Exception e) {
            // gek 11/20/01 Send exception to ErrorHandler if it exists
            if (getErrorHandler() != null) {
              getErrorHandler().error(e, "BuilderWizardAdapter", "wizardFinished");

              // Cancel the current event
              ((Cancelable) event).cancel();
            }
            else {
              // Rethrow the wrapped exception
              throw new DataUtilRuntimeException (
                DataUtilClientBundle.EXC_UNEXPECTED_ERROR, e);
            }
          }
        }
    }

    /**
     * @hidden
     *
     * The listener for wizard validate page events.
     *
     */
    private class BuilderWizardValidateAdapter implements WizardValidateListener {
      public void wizardValidatePage (WizardEvent event) {
        int nWizardState = -1;

        // Do nothing if we are initializing
        if (m_bInitializing)
          return;

        try {
          nWizardState = getWizardState ();
          if (CustomWizardConst.CUSTOMWIZARD_INVALIDSTATE == nWizardState)
              return;

          if (CustomWizardConst.CUSTOMWIZARD_APPLY == nWizardState ||
              CustomWizardConst.CUSTOMWIZARD_FINISH == nWizardState) {
            validateApplyFinishEvent (event);
            return;
          }

          if (CustomWizardConst.CUSTOMWIZARD_NEXT == nWizardState ||
              CustomWizardConst.CUSTOMWIZARD_PREVIOUS == nWizardState) {
            validateNextPreviousEvent (event);
            return;
          }

          if (CustomWizardConst.CUSTOMWIZARD_PAGECHANGING == nWizardState) {
            validatePageChangingEvent (event);
            return;
          }
        }

        catch (Exception e) {
          // gek 11/11/01 Make sure that we restore the default cursor before
          //              throwing exception.
          setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));

          // gek 11/20/01 Send exception to ErrorHandler if it exists
          if (getErrorHandler() != null) {
            getErrorHandler().error(e, "BuilderWizardValidateAdapter",
              "wizardValidatePage");

            // Cancel the current event
            ((Cancelable) event).cancel();
          }
          else {
            // Rethrow the wrapped exception
            throw new DataUtilRuntimeException (
              DataUtilClientBundle.EXC_UNEXPECTED_ERROR, e);
          }     
        }
      }
    }

    /**
     * @hidden
     *
     * The panel event listener.
     *
     */
    private class BuilderDialogPanelEventListener implements PanelEventListener
    {
        /**
         * Signals that a panel event ocurred.
         *
         * @param event The event object that describes the event.
         *
         * @status Documented
         */
        public void panelActionPerformed ( EventObject event )
        {
            processPanelEvent ( event );
        }
    } 
}    