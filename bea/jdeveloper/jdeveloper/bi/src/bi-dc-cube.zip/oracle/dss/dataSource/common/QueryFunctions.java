/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryFunctions.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/15/05 - 
    bmoroze     08/12/05 - bmoroze_bicommon050812
    bmoroze     08/12/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryFunctions.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import java.util.List;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.util.DataAccess;
import oracle.dss.util.QDR;

/**
 * @hidden
 * Interface to isolate query calls from cursor
 */
public interface QueryFunctions extends MetadataFunctions
{    
    public void setCurrentPage(long page, QDR qdr);
    
    public MetadataManagerServices getMetadataManager();
    
    public boolean fireCellOverriding(long row, long col, long page, Object data, QDR qdr);
    
    public void fireCellOverridden(long row, long col, long page, Object data, QDR qdr);
    
    public boolean fireCellsSubmitting(List qdrOverride);
    
    public void fireCellsSubmitted(List qdrOverride, boolean success);
    
    public void fireDataChanged(int edge, int type) throws Exception;
    
    public QueryManagerInterface getQueryManagerInterface();
    
    public void setAutoSubmit(boolean value);
    
    public QueryState _getQueryState();
    
    // blm - Selection code moved to dvt-olap
/*    public boolean setTotal(int edge, int layer, TotalStep totalStep) throws QueryException, MetadataManagerException;
    
    public String constructTotalMemberID(TotalStep ts, DataAccess da, int edge, int layer, int slice);
    
    public void replSel(String dimension, Selection sel) throws Exception;*/
    
    public MDMeasure[] getMMMeasures() throws InvalidMetadataException;    
}