/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui.hierLevel;

/**
 * @hidden
 */
public interface HyperLinkControl
{
   /**
    * Specifies the display mode for this control.
    *
    * @param isHyperLink boolean flag which if true will set 
    *             the display of the control to the hyperlink mode.
    * @status hidden
    */  
    public void setHyperLink(boolean isHyperLink);
    
  
   /**
    * Indicates whether the control is in hyperlink mode.
    *
    * @return true if the control is in the hyperlink mode.
    * @status hidden
    */    
    public boolean isHyperLink();
}
       