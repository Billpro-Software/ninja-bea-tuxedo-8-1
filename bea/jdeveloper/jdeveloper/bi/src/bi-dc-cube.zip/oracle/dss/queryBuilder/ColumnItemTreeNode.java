/*
 * ColumnItemTreeNode.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import javax.naming.directory.SearchResult;

import javax.swing.JTree;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.metadataManager.common.MDColumnItem;

public class ColumnItemTreeNode extends ItemsTreeNodeImpl {

    /*
     * Public
     */

    public ColumnItemTreeNode(JTree tree, SearchResult sr, ComponentContext context) {
        //super(tree, sr, context);
        super(tree, QBUtils.makeComponentNode(sr, context), context);
    }
    
    public ColumnItemTreeNode(JTree tree, MDColumnItem mdColumnItem, ComponentContext context) {
        //super(tree, mdColumnItem, context);
        super(tree, QBUtils.makeComponentNode(mdColumnItem, context), context);
    }
        
    /*
     * Protected
     */
    
    /*
     * Private
     */
}