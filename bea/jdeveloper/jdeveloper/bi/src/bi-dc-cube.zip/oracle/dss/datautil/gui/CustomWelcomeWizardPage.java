/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Image;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import oracle.bali.ewt.LWComponent;
import oracle.bali.ewt.wizard.WelcomeWizardPage;

import oracle.dss.datautil.gui.panel.DiscovererColorStrip;
import oracle.dss.datautil.gui.panel.StandardPanel;

/**
 * @hidden
 * Extends the Bali JEWT <code>WelcomeWizardPage</code> class for enhanced BIBeans
 * functionality, including support for Discoverer 3.1 based graphics.
 *
 * @status hidden
 */

 public class CustomWelcomeWizardPage extends WelcomeWizardPage {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructs a wizard welcome page with the given image, title, and
   * description.
   *
   * @param  image a <code>Image</code> value that represents the graphic to be
   *         displayed in this page.
   * @param  strTitle a <code>String</code> value that represents the
   * @param  strDescription a <code>String</code> value that represents the
   *         description for this page
   *
   * @status hidden
   */
  public CustomWelcomeWizardPage (Image image, String strTitle, String strDescription) {
    super (image, strTitle, strDescription);

    // Determine if this is a Discoverer graphic. If not, use default processing.
    if (DiscovererColorStrip.isDiscovererStyle(image)) {

      // Retrieve the current content
      LWComponent lwComponent = (LWComponent) getContent();
      if (lwComponent != null) {
        // Retrieve the components associated with the current content
        Component[] components = lwComponent.getComponents();

        if (components != null) {
          // Replace the previous ColorStrip with the Discoverer based one
          lwComponent.remove (components[0]);
          lwComponent.add(new DiscovererColorStrip(image), BorderLayout.WEST);
        }
      }
    }
  }


  /**
   * Constructs a wizard welcome page with the given image, title, and
   * description based on the specified <code>StandardPanel</code>.
   *
   * @param  image a <code>Image</code> value that represents the graphic to be
   *         displayed in this page.
   * @param  strTitle a <code>String</code> value that represents the
   * @param  strDescription a <code>String</code> value that represents the
   *         description for this page
   * @param  standardPanel a <code>StandardPanel</code> value that represents
   *         the panel to update and use within the Wizard page.
   *
   * @status hidden
   */
  public CustomWelcomeWizardPage (Image image, String strTitle,
            String strDescription, StandardPanel standardPanel) {
    super (image, strTitle, strDescription);

    // Determine if this is a Discoverer graphic. If not, use default processing.
    if (DiscovererColorStrip.isDiscovererStyle(image)) {

      // Retrieve the current content
      LWComponent lwComponent = (LWComponent) getContent();
      if (lwComponent != null) {
        // Retrieve the components associated with the current content
        Component[] components = lwComponent.getComponents();

        if (components != null) {
          // Replace the previous ColorStrip with the Discoverer based one
          lwComponent.remove (components[0]);
          lwComponent.add(new DiscovererColorStrip(image), BorderLayout.WEST);
        }
      }
    }

    // Update the Wizard Page's interactive area by wrapping the current panel
    // within a StandardPanel
    setInteractiveArea (standardPanel);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * Update the Wizard Page's interactive area by wrapping the current panel
   * within a StandardPanel.
   *
   * @param  standardPanel a <code>StandardPanel</code> value that represents
   *         the panel to update and use within the Wizard page.
   */
  public void setInteractiveArea (StandardPanel standardPanel) {
    // Verify that we have a valid panel
    if (standardPanel != null) {
      if (standardPanel instanceof JPanel) {
        JPanel jPanel = (JPanel)standardPanel;

        // Make sure that our panel is empty
        jPanel.removeAll();

        // Set to box layout
        jPanel.setLayout (new BoxLayout(jPanel, BoxLayout.X_AXIS));

        // Simply drop the original panel into our Standard Panel
        jPanel.add (getInteractiveArea());

        // Update the Welcome Wizard interactive area with the standard panel
        setInteractiveArea ((Component)standardPanel);
      }
    }
  }
}
