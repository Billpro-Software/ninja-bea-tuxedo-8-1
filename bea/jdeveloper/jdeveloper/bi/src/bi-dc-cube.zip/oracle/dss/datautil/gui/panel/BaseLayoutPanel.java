/*
 * BaseLayoutPanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.Border;

import oracle.bali.ewt.text.MultiLineLabel;
import oracle.bali.ewt.text.WordWrapper;

/**
 * A base layout panel. A superclass for <code>MeasureListPanel</code>.
 *
 * @status documented
 */   
public class BaseLayoutPanel extends JPanel {
  	private static final int CONTENT_BORDER_INSET_TOP       = 6;
  	private static final int CONTENT_BORDER_INSET_LEFT      = 6;
  	private static final int CONTENT_BORDER_INSET_BOTTOM    = 8;
  	private static final int CONTENT_BORDER_INSET_RIGHT     = 5;
	
  	private static final Border _sBorder = new EmptyBorder(
    	CONTENT_BORDER_INSET_TOP, CONTENT_BORDER_INSET_LEFT,
      	CONTENT_BORDER_INSET_BOTTOM, CONTENT_BORDER_INSET_RIGHT);

    /**
     * Constructor that specifies all arguments for 
     * the <code>BaseLayoutPanel</code>.
     *
     * @param component The component that holds the content in this panel.
     * @param strDescription The description for this panel.     
     *
     * @status documented
     */	
	public BaseLayoutPanel(Component component, String strDescription) {
		super(new BorderLayout());
		setBorder(_sBorder);
		setContent(component);
		setDescription(strDescription);
	}

    /**
     * Constructor that specifies only the component for 
     * the <code>BaseLayoutPanel</code>.
     *
     * @param component The component that holds the content in this panel.
     *
     * @status documented
     */		
	public BaseLayoutPanel(Component component) {
		this(component, null);
	}

    /**
     * Constructor.
     *
     * @status document
     */	
	public BaseLayoutPanel() {
		this(null, null);
	}

  /**
   * Specifies the component that holds the content in this panel.
   *
   * @param Component The component.
   *
   * @status documented
   */		
	public void setContent(Component component) {
		if (component != null) {
			add(component, BorderLayout.CENTER);
		}
	}

    /**
     * Specifies the description for this panel.
     *
     * @param strDescription The description.
     *
     * @status documented
     */
	public void setDescription(String strDescription) {
		if (strDescription != null) {
        	WordWrapper wordWrapper = (WordWrapper)WordWrapper.getTextWrapper();
        	MultiLineLabel lblDescription = new MultiLineLabel(wordWrapper, strDescription);
        	add(lblDescription, BorderLayout.NORTH);
		}
	}
}