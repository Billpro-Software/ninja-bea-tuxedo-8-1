/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

/**
 * The <code>ManagerFactory</code> creates and maintains an
 * <code>InitialPersistenceManager</code>,
 * as well as a pool of <code>QueryManager</code> and <code>MetadataManager</code>
 * objects for a particular user session.
 * You can get the <code>ManagerFactory</code> for your application by calling
 * the <code>getManagerFactory</code> of the <code>BISession</code> object.
 *
 * @status documented
 */
public interface ManagerFactory
{
    /**
     * Manager type: <code>InitialPersistenceManager</code>.
     * @status documented
     */
    public static final int PERSISTENCE_MANAGER = 0;

    /**
     * Manager type: <code>MetadataManager</code>
     * @status documented
     */
    public static final int METADATA_MANAGER = 1;

    /**
     * Manager type: <code>QueryManager</code>
     * @status documented
     */
    public static final int QUERY_MANAGER = 2;

    /**
     * Manager type: Unattached <code>MetadataManager</code>
     * If it is already attached, it would not detach it
     * @hidden
     */
    public static final int UNATTACHED_METADATA_MANAGER = 3;

   /**
    * Returns a named manager.
    * If you pass <code>true</code> as the <code>useSharedPool</code> parameter,
    * then this <code>ManagerFactory</code> first looks in the pool of managers
    * of the specified type for the named manager.
    * If it does not find the manager, then the <code>ManagerFactory</code>
    * instantiates the manager and adds it to the pool.
    * <p>
    * If you pass <code>false</code> as the <code>useSharedPool</code> parameter,
    * then this <code>ManagerFactory</code> does not look in the pool.
    * Instead, it creates a new instance, and it does not add the instance
    * to the pool.
    *
    * @param managerType    A constant that represents the type of manager that
    *                       you want. Valid values are listed in the See Also
    *                       section.
    * @param name           The name of the manager object.
    * @param useSharedPool  <code>true</code> to use an existing manager, if one
    *                       exists,
    *                       <code>false</code> to create a new instance, without
    *                       adding it to the pool of available managers.
    *
    * @return An instance of the specified type of manager, which is associated
    *         with the specified name.
    *
    * @throws Exception if an error occurred while loading the manager object.
    *
    * @see #PERSISTENCE_MANAGER
    * @see #METADATA_MANAGER
    * @see #QUERY_MANAGER
    *
    * @status documented
    */
    public Object lookupManager(int managerType, String name, boolean useSharedPool) throws Exception;

    /**
     * @hidden
     */
    public void cleanup() throws Exception;
}
