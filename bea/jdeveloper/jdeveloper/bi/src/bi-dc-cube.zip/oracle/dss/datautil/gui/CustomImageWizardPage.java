/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Image;

import oracle.dss.datautil.gui.panel.DiscovererColorStrip;

import oracle.bali.ewt.LWComponent;
import oracle.bali.ewt.wizard.ImageWizardPage;

/**
 * @hidden
 * Extends the Bali JEWT <code>ImageWizardPage</code> class for enhanced BIBeans
 * functionality, including support for Discoverer 3.1 based graphics.
 *
 * @status hidden
 */
public class CustomImageWizardPage extends ImageWizardPage {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructs a wizard welcome page the given image and label.
   *
   * @param  image a <code>Image</code> value that represents the graphic to be
   *         displayed in this page.
   * @param  strTitle a <code>String</code> value that represents the
   * @param  strDescription a <code>String</code> value that represents the
   *         description for this page
   *
   * @status hidden
   */
  public CustomImageWizardPage (Component interactive, Image image, String label) {
    super (interactive, image, label);

    // Determine if this is a Discoverer graphic. If not, use default processing.
    if (DiscovererColorStrip.isDiscovererStyle(image)) {

      // Retrieve the current content
      LWComponent lwComponent = (LWComponent)getContent();
      if (lwComponent != null) {
        // Retrieve the components associated with the content
        Component[] components = lwComponent.getComponents();

        // Replace the original ColorStrip with one based on Discoverer graphics
        lwComponent.remove (components[0]);
        lwComponent.add(new DiscovererColorStrip(image), BorderLayout.WEST);
      }

      // Update the contents
      setContent (lwComponent);
      }
    }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Fires a validate event and checks whether any listeners cancelled.
   *
   * @return  <code>true</code> if the validation succeeded;
   *          <code>false</code> if a listener cancelled.
   *
   * @status protected
   */
  protected boolean validatePage() {
    return super.validatePage ( );
  }
}
