/*
 * WelcomePanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import java.awt.Image;

import javax.swing.ImageIcon;

/**
 * Displays the Welcome panel for a builder.
 *
 * @status documented
 */

public abstract class WelcomePanel extends DefaultStandardPanel {

  //-----------------------------------------------------------------------
  // MEMBER VARIABLES
  //-----------------------------------------------------------------------

  /**
   * Welcome Panel ID.
   *
   * @status documented
   */
  static public final String WELCOME_PANEL_ID = "welcomePanel";

  /**
   * Welcome Description.
   *
   * @status private
   */
  private String m_strDescription = null;

  //-----------------------------------------------------------------------
  // CONSTRUCTORS
  //-----------------------------------------------------------------------

  /**
   * Constructor.
   *
   * @status documented
   */
  public WelcomePanel() {
    super ();
  }

  //-----------------------------------------------------------------------
  // PUBLIC METHODS
  //-----------------------------------------------------------------------

    /**
     * Retrieves the identifier for this panel.
     *
     * @return The identifier for this panel.
     *
     * @status Documented
     */
  public String getId () {
    return WELCOME_PANEL_ID;
  }

  /**
   * Retrieves the description for the Welcome panel.
   *
   * @return A <code>string</code> that represents the Welcome panel's description.
   *
   * @status Documented
   */
  public String getDescription () {
    return m_strDescription;
  }

  /**
   * Specifies the description for the Welcome panel.
   *
   * @param strDescription A <code>String</code> that represents the
   *        Welcome panel's description.
   * @status Documented
   */
  public void setDescription (String strDescription) {
    m_strDescription = strDescription;
  }

    /**
     * Retrieves the image icon for this panel.
     *
     * @return The icon to be displayed for this panel.
     *
     * @status Documented
     */
  public ImageIcon getImageIcon () {
    return null;
  }

    /**
     * Retrieves the image for the panel. Typically this image is displayed
     * on the left side of a wizard.
     *
     * @return The image to be displayed for this panel.
     *
     * @status Documented
     */
  public abstract Image getImage ();

    /**
     * Retrieves the title of this panel.
     *
     * @return The panel title.
     *
     * @status Documented
     */
  public abstract String getTitle ();

  /**
   * Retrieves the text description that appears at the top of the Welcome panel.
   *
   * @return The string that represents the description.
   *
   * @status Documented
   */
  public abstract String getWelcomeInformation ();
}
