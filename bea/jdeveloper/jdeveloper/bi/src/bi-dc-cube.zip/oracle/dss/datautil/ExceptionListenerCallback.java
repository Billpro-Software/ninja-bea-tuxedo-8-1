/*
 * ExceptionListenerCallback.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

/**
 * @hidden
 *
 * Interface for beans that send messages to an exception listener.
 *
 * @status New
 */
 
public interface ExceptionListenerCallback {
  /**
   * Adds a single exception listener to the bean.
   *
   * The bean then calls the exception listener with exception.
   *
   * @param exceptionListener a <code>ExceptionListener</code> used to process exceptions.
   *
   * @status New
   */
  public void addExceptionListener (ExceptionListener exceptionListener);

  /**
   * Retrieve the current exception listener.
   *
   * @return <code>ExceptionListener</code> which represents the current
   *         exception listener.
   *
   * @status New
   */
  public ExceptionListener getExceptionListener();

  /**
   * Removes the exception listener from the bean.
   *
   * @status New
   */
  public void removeExceptionListener();
}

