/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.sort;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

import oracle.bali.ewt.dialog.JEWTDialog;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.sort.resource.SortBundle;
import oracle.dss.util.ColumnSortInfo;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.swing.ComponentNodeComboBoxModel;

/**
 * <pre>
 * A JPanel that provides access to sort functionality.
 * </pre>
 * 
 * @author jramanat 
 * @since  11.0.0.0.8
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   10/24/07 - Fix Bug 6522478 - NULL POINTER EXCEPTION CAN BE
 *                         GENERATED WHEN ENTERING EMPTY SORT CRITERIA.
 *    gkellam   10/23/07 - Fix Bug 6522478 - NULL POINTER EXCEPTION CAN BE
 *                         GENERATED WHEN ENTERING EMPTY SORT CRITERIA.
 *    gkellam   04/24/07 - Addition Sort Dialog updates.
 *    gkellam   04/23/07 - Fix Bug 5941896 - UI changes to sort dialog popup in
 *                         BI Model Flat Editor.
 *    gkellam   10/16/06 - Add ability to configure SortPanel.
 *    jramanat  01/16/06 - 
 */
public class SortPanel extends JPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  private static final String RESOURCE_BUNDLE = "oracle.dss.datautil.gui.component.sort.resource.SortBundle";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext;
  private SortPanelModel m_sortPanelModel;
  private SortTable m_sortTable;
  
  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  /**
   * Constructor that takes no arguments.  setModel and initialize must be
   * called before this SortPanel is used.
   */
  public SortPanel() {
  }

  /**
   * Constructor that takes a <code>ComponentContext</code>
   * 
   * @param componentContext The <code>ComponentContext</code>
   */
  public SortPanel (ComponentContext componentContext) {
    setComponentContext (componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the <code>ComponentContext</code> to use.
   * 
   * @param componentContext The <code>ComponentContext</code>
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;
  }

  /**
   * Retrieves the <code>SortTable</code> used.
   * 
   * @return The <code>SortTable</code>
   */
  public SortTable getSortTable() {
    return m_sortTable;
  }

  /**
   * Retrieves the <code>ComponentContext</code> used.
   * 
   * @return The <code>ComponentContext</code>
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }

  /**
   * Specifies the model to use for tabular sorting
   * 
   * @param tableSortPanelModel The <code>TableSortPanelModel</code>
   */
  public void setModel (TableSortPanelModel tableSortPanelModel) {
    m_sortPanelModel = tableSortPanelModel;
  }
  
  /**
   * Specifies the model to use for crosstabular sorting
   * 
   * @param crosstabSortPanelModel The <code>CrosstabSortPanelModel</code>
   */
  public void setModel (CrosstabSortPanelModel crosstabSortPanelModel) {
    m_sortPanelModel = crosstabSortPanelModel;
  }
  
  /**
   * Retrieves the model to use
   * 
   * @return The <code>SortPanelModel</code>
   */
  public SortPanelModel getModel() {
    return m_sortPanelModel;
  }

  /**
   * Creates the UI based on the <code>SortPanelModel</code>
   */
  public void initialize() {
    String strMode = getModel().getMode();
    
    if (strMode.equals(SortPanelModel.TABLE_MODE)) {
      initializeTable();
    }
    else if (strMode.equals (SortPanelModel.CROSSTAB_MODE)) {
      initializeCrosstab();
    }
  }
  
  /**
   * @hidden
   */
  public static void main (String[] strArguments) throws Exception {
    UIManager.setLookAndFeel ("oracle.bali.ewt.olaf.OracleLookAndFeel");
    SortPanel sortPanel = new SortPanel (null);
    JEWTDialog jewtDialog = new JEWTDialog();
    jewtDialog.setResizable (false);
    jewtDialog.getContentPane().add (sortPanel);
    jewtDialog.pack();
    jewtDialog.setMinimumSize (jewtDialog.getSize());
    jewtDialog.setVisible (true);
  }
  
  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected String getResourceString (String strKey) {
   if (getComponentContext() != null && getComponentContext().getResourceHandler() != null) {
     return getComponentContext().getResourceHandler().getResourceString (RESOURCE_BUNDLE, strKey);
   }

   return strKey;
  }
   
  /**
   * Retrieves the <code>SortTable</code> used.
   * 
   * @return The <code>SortTable</code>
   */
  protected void setSortTable (SortTable sortTable) {
    m_sortTable = sortTable;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private TableSortPanelModel getTableModel() {    
    return (TableSortPanelModel)m_sortPanelModel;
  }

  private CrosstabSortPanelModel getCrosstabModel() {
    return (CrosstabSortPanelModel)m_sortPanelModel;
  }

  /**
   * Sets up UI in Table mode
   */
  private void initializeTable() {
    GridBagLayout gridBagLayout = new GridBagLayout();
    setLayout (gridBagLayout);
    
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.insets = new Insets (5, 5, 0, 0);
    gridBagConstraints.anchor = GridBagConstraints.NORTHWEST;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;    

    addComponent (this, 
      new JLabel (getResourceString (SortBundle.SORTPANEL_TABLE_DESCRIPTION)), gridBagLayout, gridBagConstraints);
    setSortTable (new SortTable (this));
    
    gridBagConstraints.weightx = 1;
    gridBagConstraints.fill = GridBagConstraints.BOTH;
    addComponent (this, getSortTable(), gridBagLayout, gridBagConstraints);
  }

  /**
   * Sets up UI in Crosstab mode
   */
  private void initializeCrosstab() {
    GridBagLayout gridBagLayout = new GridBagLayout();
    setLayout (gridBagLayout);

    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.insets = new Insets (5, 5, 0, 0);
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;

    // Label row
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (this, 
      new JLabel(getResourceString (
        SortBundle.SORTPANEL_CROSSTAB_DESCRIPTION)), gridBagLayout, gridBagConstraints);

    // Item picker
    ItemPanel itemPanel = new ItemPanel();
    addComponent (this, itemPanel, gridBagLayout, gridBagConstraints);
    
    gridBagConstraints.weightx = 1;
    
    setSortTable (new SortTable (this));
    addComponent (this, m_sortTable, gridBagLayout, gridBagConstraints);
  }

  /**
   * Adds a component to a Panel using GridBagLayout
   */
  private void addComponent (JPanel jPanel, JComponent jComponent, 
                             GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    gridBagLayout.setConstraints (jComponent, gridBagConstraints);
    jPanel.add (jComponent);
  }

  public void apply() {
    if (getModel().getMode().equals (SortPanelModel.TABLE_MODE)) {
      
      // Check for invalid sort criteria.
      ColumnSortInfo[] columnSortInfos = 
        validateSortCriteria ((ColumnSortInfo[])getSortTable().getData());
      
      // gek 10/23/07 Fix Bug 6522478 - NULL POINTER EXCEPTION CAN BE GENERATED 
      //              WHEN ENTERING EMPTY SORT CRITERIA.
      // 
      if (columnSortInfos == null) {
        // Avoid null pointer exception by only applying null ColumnSorts when
        // a previous one existed.
        if (getTableModel().getColumnSorts() != null) {
          getTableModel().setColumnSorts (columnSortInfos);
        }
      }
      else {
        getTableModel().setColumnSorts (columnSortInfos);
      }
    }
  }
  
  /**
   * Retrieves a valid list of <code>ColumnSortInfo</code> values from the 
   * specified list.
   * 
   * @param columnSortInfos A <code>ColumnSortInfo[]</code> of values to verify.
   * 
   * @return <code>ColumnSortInfo[]</code> of valid <code>ColumnSortInfo</code> values.
   * 
   * @status hidden
   */
  protected ColumnSortInfo[] validateSortCriteria (ColumnSortInfo[] columnSortInfos) {
    
    ColumnSortInfo[] columnSortInfosResult = null;
    
    if ((columnSortInfos != null) && (columnSortInfos.length > 0)) {
      ColumnSortInfo columnSortInfo = null;
      
      // Iterate over all the values, stripping out invalid ones
      Vector vColumnSortInfos = new Vector();
      for (int nIndex = 0; nIndex < columnSortInfos.length; nIndex++) {
        columnSortInfo = columnSortInfos [nIndex];
        
        // Check to see that Layer name and direction have been specified
        if (columnSortInfo != null) {
          if (columnSortInfo.getLayerName() != null) {
            if ((columnSortInfo.getDirection() != null) && (columnSortInfo.getDirection().length > 0)) {
              vColumnSortInfos.addElement (columnSortInfo);    
            }
          }
        }
      }
    
      // Create a ColumnSortInfo[] out of the valid values
      if ((vColumnSortInfos != null) && (!vColumnSortInfos.isEmpty())) {
        columnSortInfosResult = new ColumnSortInfo [vColumnSortInfos.size()];
        vColumnSortInfos.copyInto (columnSortInfosResult);
      }
    }
    
    return columnSortInfosResult;
  }

  private class ItemPanel extends JPanel {
    private JComboBox m_jComboBoxPicker = null;

    public ItemPanel() {
      m_jComboBoxPicker = 
        new JComboBox (new ComponentNodeComboBoxModel (getCrosstabModel().getSortItems()));
      
      if (getCrosstabModel().getSortItem() == null) {
        getCrosstabModel().setSortItem (((ComponentNode)m_jComboBoxPicker.getItemAt(0)).getID());
      }
      
      m_jComboBoxPicker.getModel().setSelectedItem (getCrosstabModel().getSortItem());
      
      m_jComboBoxPicker.addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          if (m_jComboBoxPicker.getSelectedItem() != null && getSortTable() != null) {
            getCrosstabModel().setSorts (getSortTable() .getData());
            getCrosstabModel().setSortItem (((ComponentNode)m_jComboBoxPicker.getSelectedItem()).getID());
            getSortTable() .update();
          }
        }
      });
      
      add (new JLabel (getResourceString ("CrosstabItem")));
      add (m_jComboBoxPicker);
    }

    public String getItem() {
      return ((ComponentNode)m_jComboBoxPicker.getSelectedItem()).getID();
    }
  }
}