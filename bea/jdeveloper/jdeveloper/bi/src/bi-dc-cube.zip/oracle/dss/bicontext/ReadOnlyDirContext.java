/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */

package oracle.dss.bicontext;

import java.util.Hashtable;

import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;

/**
 * The read only subset of the javax.naming.Context interface.
 */

public interface ReadOnlyDirContext {
  /**
     * @see javax.naming.Context#lookup(Name)
     */
    public Object lookup(Name name) throws NamingException;

    /**
     * @see javax.naming.Context#lookup(String)
     */
    public Object lookup(String name) throws NamingException;
   

   /**
     * @see javax.naming.Context#list(String)
     */
    public NamingEnumeration list(String name) throws NamingException;

    /**
     * @see javax.naming.Context#list(Name)
     */
    public NamingEnumeration list(Name name) throws NamingException;


     /**
     * @see javax.naming.Context#listBindings(Name)
     */
    public NamingEnumeration listBindings(Name name) throws NamingException;

   /**
     * @see javax.naming.Context#listBindings(String)
     */
    public NamingEnumeration listBindings(String name) throws NamingException;



    
    /**
     * @see javax.naming.Context#lookupLink(Name)
     */
    public Object lookupLink(Name name) throws NamingException;

    /**
     * @see javax.naming.Context#lookupLink(String)
     */
    public Object lookupLink(String name) throws NamingException;

    /**
     * @see javax.naming.Context#getNameParser(Name)
     */
    public NameParser getNameParser(Name name) throws NamingException;

    /**
     * @see javax.naming.Context#getNameParser(String)
     */
    public NameParser getNameParser(String name) throws NamingException;

   /**
     * @see javax.naming.Context#composeName(Name, Name)
     */
    public Name composeName(Name name, Name prefix) throws NamingException;

    /**
     * @see javax.naming.Context#composeName(String, String)
     */
    public String composeName(String name, String prefix)
	    throws NamingException;

    

   /**
     * @see javax.naming.Context#removeFromEnvironment(String)
     */
    public Object removeFromEnvironment(String propName)
	throws NamingException;

    /**
     * @see javax.naming.Context#getEnvironment()
     */
    public Hashtable getEnvironment() throws NamingException;

    

    /**
     * @see javax.naming.Context#getNameInNamespace()
     */
    public String getNameInNamespace() throws NamingException;


    /**
     * @see javax.naming.directory.DirContext#getAttributes(Name)
     */
    public Attributes getAttributes(Name name) throws NamingException;

     /**
     * @see javax.naming.directory.DirContext#getAttributes(String)
     */
    public Attributes getAttributes(String name) throws NamingException;
	
    /**
     * @see javax.naming.directory.DirContext#getAttributes(Name, String[])
     */
    public Attributes getAttributes(Name name, String[] attrIds)
	    throws NamingException;

     /**
     * @see javax.naming.directory.DirContext#getAttributes(String, String[])
     */
    public Attributes getAttributes(String name, String[] attrIds)
	    throws NamingException;

    

   

    


     /**
     * @see javax.naming.directory.DirContext#getSchema(Name)
     */
    public DirContext getSchema(Name name) throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#getSchema(String)
     */
    public DirContext getSchema(String name) throws NamingException;
    
    /**
     * @see javax.naming.directory.DirContext#getSchemaClassDefinition(Name)
     */
    public DirContext getSchemaClassDefinition(Name name)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#getSchemaClassDefinition(String)
     */
    public DirContext getSchemaClassDefinition(String name)
	    throws NamingException;



   /**
     * @see javax.naming.directory.DirContext#search(Name, Attributes, String[])
     */
    public NamingEnumeration search(Name name,
				    Attributes matchingAttributes,
				    String[] attributesToReturn)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(String, Attributes, String[])
     */
    public NamingEnumeration search(String name,
				    Attributes matchingAttributes,
				    String[] attributesToReturn)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(Name, Attributes)
     */
    public NamingEnumeration search(Name name,
				    Attributes matchingAttributes)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(String, Attributes)
     */
    public NamingEnumeration search(String name,
				    Attributes matchingAttributes)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(Name, String, SearchControls)
     */
    public NamingEnumeration search(Name name,
				    String filter,
				    SearchControls cons)
	    throws NamingException;

   /**
     * @see javax.naming.directory.DirContext#search(String, String, SearchControls)
     */
    public NamingEnumeration search(String name,
				    String filter,
				    SearchControls cons)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(Name, String, Object[], SearchControls)
     */
    public NamingEnumeration search(Name name,
				    String filterExpr,
				    Object[] filterArgs,
				    SearchControls cons)
	    throws NamingException;

    /**
     * @see javax.naming.directory.DirContext#search(String, String, Object[], SearchControls)
     */
    public NamingEnumeration search(String name,
				    String filterExpr,
				    Object[] filterArgs,
				    SearchControls cons)
	    throws NamingException;  
    

    /**
     * @see javax.naming.Context#addToEnvironment(String, Object)
     */
    public Object addToEnvironment(String propName, Object propVal)
	throws NamingException;  

    /**
     * @see javax.naming.Context#close()
     */
    public void close() throws NamingException;

    


};
