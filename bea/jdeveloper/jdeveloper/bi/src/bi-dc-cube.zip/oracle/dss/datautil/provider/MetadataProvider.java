/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/provider/MetadataProvider.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.provider;

import java.util.Vector;

import javax.naming.directory.DirContext;

import oracle.dss.bicontext.BIContext;

import oracle.dss.metadataManager.common.MDFolder;

/**
 * <pre>
 * Defines metadata provider interfaces used to retrieve metadata. 
 * </pre>
 *
 * @see oracle.dss.datautil.provider.DataProvider
 *
 * @author gkellam 
 * @since  11.0.0.0.3
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *  dbajpai     12/15/05 - basic infrastructure for function DnD and loading 
 *                         function metadata 
 *  rbalexan    10/28/05 - Remove setItems - moved to QB model.
 *  gkellam     10/11/05 - Work around bug 4616157: Avoid OLAP attribute 
 *                         searching by selecting Relational datasource. 
 *  dbajpai     09/26/05 - initial cut at adding split panes to the expression 
 *                         panel ui 
 *  dbajpai     09/26/05 - Change runtime datasource root to BIContext 
 *  dbajpai     09/21/05 - add methods to track current datasource, 
 *                         runtimedatasource and catalog root 
 *  dbajpai     09/21/05 - add methods to track current datasource, 
 *                         runtimedatasource 
 *  gkellam     08/22/05 - 
 *  rbalexan    08/12/05 - 
 *  rbalexan    07/12/05 - fill in interface methods 
 *  rbalexan    07/08/05 - 
 *  gkellam     06/23/05 - Initial R11 CalcBuilder framework. 
 *  gkellam     06/16/05 - Creation
 */
 
public interface MetadataProvider {

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Retrieves the available data sources.
   *
   * @return A <code>Vector</code> which represents the list of available data sources.
   *
   * @status hidden
   */
  public Vector getDatasources();
  
  /**
   * @hidden
   * 
   * @status hidden
   */
  public Object getObjectByUniqueId (String strUniqueId);
    
  /**
   * @hidden
   * 
   * @status hidden
   */
  public DirContext getRoot();
    
  /**
   * @hidden
   * 
   * @status hidden
   */
  public Object getDimensionByUniqueId (String strUniqueId);
    
  /**
   * Retrieves a list of item ids
   * 
   * @param data Indicates whether data items should be included
   * @param nondata Indicates whether non-data items should be included
   * 
   * @return The list of items ids
   */
  public Vector getItemIds(boolean data, boolean nondata);
    
  /**
   * Retrieves a list of item MDObjects
   * 
   * @param data Indicates whether data items should be included
   * @param nondata Indicates whether non-data items should be included
   * 
   * @return The list of item MDObjects
   */
  public Vector getItemObjects(boolean data, boolean nondata);

  /**
   * Retrieves the root folder of the current datasource.
   * 
   * @return a <code>MDFolder</code> instance
   */
  public MDFolder getCurrentDatasourceRootFolder();
  
  /**
   * Sets the root folder of the current datasource.
   * 
   * @param folder a <code>MDFolder</code> instance
   */
  public void setCurrentDatasourceRootFolder (MDFolder mdFolder);

  /**
   * Retrieves the root folder of the current runtime datasource.
   * 
   * @return a <code>BIContext</code> instance
   */
  public BIContext getCurrentRuntimeDatasourceRootFolder();

  /**
   * Sets the root folder of the current runtime datasource.
   * 
   * @param folder a <code>BIContext</code> instance
   */
  public void setCurrentRuntimeDatasourceRootFolder (BIContext folder);
  
  /**
   * Sets the root folder of the current runtime datasource based on its name.
   * 
   * @param strDataSourceName A <code>String</code> which represents the case 
   *        insensitive name of the DataSource.
   *        
   * @throws <code>Exception</code> if root folder cannot be set.       
   */
  public void setCurrentRuntimeDatasourceRootFolderByName (String strDataSourceName) throws Exception;

  /**
   * Retrieves the root folder of the BI Catalog.
   * 
   * @return a <code>MDFolder</code> instance
   */
  public MDFolder getBICatalogRootFolder();

  /**
   * Retrieves the root folder for the Functions metadata.
   * 
   * @return a <code>MDFolder</code> instance
   */
  public MDFolder getFunctionsRootFolder();

  /**
   * Sets the root folder of the Functions metadata.
   * 
   * @param folder the <code>MDFolder</code> instance 
   */
  public void setFunctionsRootFolder(MDFolder folder);
  
  /**
   * Retrieves the hierarchy for the specified dimension
   * 
   * @param dimension The dimension
   * @return The hierarchy
   */
  public String getHierarchy (String dimension);
}