/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Dimension;

import java.util.Locale;
import java.util.Vector;

import oracle.dss.datautil.client.DataUtilException;
import oracle.dss.datautil.gui.panel.StandardPanel;

import oracle.bali.ewt.help.HelpProvider;

/**
 * Methods and fields that are specific to <code>QueryBuilder</code> and
 * <code>CalcBuilder</code> objects. In this interface, the term "Builder" is
 * used to refer to both kinds of objects.
 *
 * @status Documented
 */
public interface BuilderContext extends ComponentContext
{    
    /////////////////////////////////////////////////////////////////////
    // PUBLIC CONSTANTS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * The tabbed mode of the Builder; provides dialog boxes that you can
     * access in any order.
     *
     * @status Documented
     */
    public static final String TABBED = "tabbed";
    
    /**
     * The wizard mode of the Builder; provides dialog boxes that you access
     * in sequential order.
     *
     * @status Documented
     */
    public static final String WIZARD = "wizard";
    
    /**
     * Indicates that measure filtering is used instead of evaluating the
     * measure dimension. The <code>MeasureList</code> is used.
     *
     * @status Documented
     */
 	public static final String APPLY_MEASURE_FILTER = "Apply measure filter";
    
    /**
     * Indicates that the <code>MeasureDimension</code> is evaluated in order to
     * obtain the list of dimensions. The <code>DimensionList</code> is used.
     *
     * @status Documented
     */
	public static final String EVALUATE_MEASURE_DIMENSION = "Evaluate measure dimension";

    /////////////////////////////////////////////////////////////////////
    // METHODS
    /////////////////////////////////////////////////////////////////////

	/**
 	 * Adds a panel to this Builder object after the other panels.
     *
	 * @param panel   The panel to add.
	 * @param panelId The identifier of the panel that will come after the new panel.
	 *
	 * @return   <code>true</code> if the panel is added successfully;
     *           <code>false</code> if the panel is not added successfully.
     *
	 * @status Documented
	 */
	public boolean addPanel ( StandardPanel panel, String panelId );
	
    /**
     * Signals the occurrence of the <code>Apply</code> event.
     *
     * @return <code>true</code> if the operation is successful;
     *         <code>false</code> if the operation is not successful.
     * @throws <code>DataUtilException</code> if an error is encountered.
     *
     * @status Documented
     */
    public boolean doApply () throws DataUtilException;
    
    /**
     * Signals the occurrence of the <code>Cancel</code> event.
     *
     * @return <code>true</code> if the operation is successful;
     *         <code>false</code> if the operation is not successful.
     *
     * @status Documented
     */
    public boolean doCancel ( );
    
    /**
     * Signals the occurrence of the <code>OK</code> event.
     *
     * @return <code>true</code> if the operation is successful;
     *         <code>false</code> if the operation is not successful.
     * @throws <code>DataUtilException</code> if an error is encountered.   
     *
     * @status Documented
     */
    public boolean doOK () throws DataUtilException;
    
    /**
     * Retrieves the content that is associated with the
     * <code>BuilderContext</code> object.
     *
     * @return The content that is associated with the
     *         <code>BuilderContext</code>.
     *
     * @status Documented
     */
    public Object getBuilderContent ( );

    /**
     * Retrieves the container that is associated with the
     * <code>BuilderContext</code> object.
     *
     * @return A reference to the <code>BuilderContext</code> object.
     *
     * @status Documented
     */
    public BuilderDialog getContainer ( );

    /**
     * Retrieves the identifier for the default panel in the Builder instance.
     *
     * @return The identifier for the default panel in the Builder instance.
     *
     * @status Documented
     */
    public String getDefaultPanelId ( );

    /**
     * Retrieves the HelpProvider for the Builder instance.
     *
     * @return The HelpProvider for the Builder instance.
     *
     * @status Documented
     */
    public HelpProvider getHelpProvider ( );
    
    /**
     * Retrieves the locale for this Builder object.
     *
     * @return The <code>Locale</code> object for this Builder object.
     *
     * @status Documented
     */
    public Locale getLocale ( );
    
    /**
     * Retrieves the mode for the Builder instance.
     *
     * @return The mode for the Builder instance. The mode is one of the
     *         following constants in this interface: TABBED or WIZARD.
     *
     * @see #TABBED
     * @see #WIZARD
     *
     * @status Documented
     */
    public String getMode ( );

    /**
     * Retrieves a panel with the specified identifier.
     *
     * @return The panel with the specified identifier.
     *
     * @status Documented
     */
    public StandardPanel getPanel ( String panelId );

    /**
     * Retrieves the list of panels for the Builder instance.
     *
     * @return The list of panels for the Builder instance.
     *
     * @status Documented
     */
    public Vector getPanelList ( );

    /**
     * Retrieves the size for the Builder instance.
     *
     * @return The size for the Builder instance.
     *
     * @status Documented
     */
    public Dimension getSize ( );

    /**
     * Retrieves the title for the Builder instance.
     *
     * @return The title for the Builder instance.
     *
     * @status Documented
     */
    public String getTitle ( );

    /**
     * Signals the Builder to create the graphical components.
     *
     * @return <code>true</code> if no problems were encountered;
     *         <code>false</code> a problem was encountered.
     *
     * @throws <code>Exception</code> if an error is encountered.
     * @status Documented
     */
    public boolean initialize ( );
    
    /**
     * Indicates whether the panel with the specified identifier is visible.
     *
     * @return <code>true</code> if the panel is visible;
     *         <code>false</code> if the panel is not visible.
     *
     * @status Documented
     */
    public boolean isPanelVisible ( String panelId );

    /**
     * Removes a panel from the list of panels in the panel context.
     *
     * @param panelId The identifier of the panel to be removed.
     *
     * @return   <code>true</code> if the remove operation was successful;
     *           <code>false</code> if the remove operation was not successful.
     *
     * @status Documented
     */
    public boolean removePanel ( String panelId );

    /**
     * Signals the Builder to run the dialog.
     *
     * @return <code>true</code> if the dialog is dismissed with an OK command;
     *         <code>false</code> if the dialog is cancelled.
     *
     * @throws <code>Exception</code> if an error is encountered.
     * @status Documented
     */
    public boolean run () throws Exception;

    /**
     * Specifies the content that is associated with the <code>BuilderContext</code>.
     *
     * @param builderContent The content that is associated with the
     *                       <code>BuilderContext</code>.
     *
     * @status Documented
     */
    public void setBuilderContent ( Object builderContent );
    
    /**
     * Specifies the container that is associated with the
     * <code>BuilderContext</code>.
     *
     * @param container A reference to the <code>BuilderDialog</code>.
     *
     * @status Documented
     */
    public void setContainer ( BuilderDialog container );

    /**
     * Specifies the identifier for the default panel in the Builder instance.
     *
     * @param defaultPanelId The identifier for the default panel in the Builder
     *                       instance.
     *
     * @status Documented
     */
    public void setDefaultPanelId ( String defaultPanelId );
    
    /**
     * Specifies the HelpProvider in the Builder instance.
     *
     * @param helpProvider The HelpProvider in the Builder instance.
     *
     * @status Documented
     */
    public void setHelpProvider ( HelpProvider helpProvider );

    /**
     * Specifies the locale for this Builder instance.
     *
     * @param locale The <code>Locale</code> object for this Builder instance.
     *
     * @status Documented
     */
    public void setLocale ( Locale locale );
    
    /**
     * Specifies the mode for the Builder instance.
     *
     * @param builderMode The mode for the Builder instance. Use one of the
     *                    following constants from this interface: TABBED or
     *                    WIZARD.
     *
     * @see #TABBED
     * @see #WIZARD
     *
     * @status Documented
     */
    public void setMode ( String builderMode );

    /**
     * Specifies whether the specified panel is to be shown or hidden.
     *
     * @param panelId    The identifier of the specified panel.
     * @param bVisible   <code>true</code> if the panel is to be marked visible,
     *                   <code>false</code> if the panel is to be hidden.
     *
     * @return <code>true</code> if the panel was marked visible,
     *         <code>false</code> if the operation failed.
     *
     * @status documented
     */
    public boolean setPanelVisible ( String panelId, boolean bVisible );
    
    /**
     * Specifies the size for the Builder instance.
     *
     * @param size The size for the Builder instance.
     *
     * @status Documented
     */
    public void setSize ( Dimension size );
    
    /**
     * Specifies the title for the Builder instance.
     *
     * @param title The title for the Builder instance.
     *
     * @status Documented
     */
    public void setTitle ( String title );
}