/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

/**
 * @hidden
 * The tokens for the calculation parser.
 * 
 * @status New
 */
 
public class CalcTokenConstants 
{
    //-------------------------------------------------------------------------
    // PUBLIC CONSTANTS
    //-------------------------------------------------------------------------

    /**
     * The token names.
     *
     * @status New
     */
    public static final String TOKEN_END = "end";
     
    public static final String TOKEN_FLOAT = "float";
    public static final String TOKEN_NUMBER = "number";
    public static final String TOKEN_HIERARCHY_KEYWORD = "hierarchyKeyword";
    public static final String TOKEN_PARENT = "parent";
    public static final String TOKEN_LIST_HIERARCHY = "listHierarchy";
    public static final String TOKEN_TOTAL = "total";
    public static final String TOKEN_ALL_LEVELS = "allLevels";
    public static final String TOKEN_DAY = "day";
    public static final String TOKEN_WEEK = "week";
    public static final String TOKEN_MONTH = "month";
    public static final String TOKEN_QUARTER = "quarter";
    public static final String TOKEN_YEAR = "year";
    public static final String TOKEN_PERIOD = "period";
    public static final String TOKEN_ASCENDING = "ascending";
    public static final String TOKEN_DESCENDING = "descending";
    public static final String TOKEN_LEVEL_KEYWORD = "levelKeyword";
    public static final String TOKEN_SELECTION_KEYWORD = "selectionKeyword";
    public static final String TOKEN_CURRENT = "current";
    public static final String TOKEN_DEFAULTSEL = "defaultSelection";
    
    public static final String TOKEN_ADD = "add";
    public static final String TOKEN_DIVIDE = "divide";
    public static final String TOKEN_MULTIPLY = "multiply";
    public static final String TOKEN_SUBTRACT = "subtract";
    public static final String TOKEN_LEFT_QUALIFIER = "leftQualifier";
    public static final String TOKEN_NAME_QUALIFIER = "nameQualifier";
    public static final String TOKEN_RIGHT_QUALIFIER = "rightQualifier";
    public static final String TOKEN_LPAREN = "leftParentheses";
    public static final String TOKEN_RPAREN = "rightParentheses";
    public static final String TOKEN_SEPARATOR = "separator";
    public static final String TOKEN_QDRSEPARATOR = "qdrSeparator";
     
    public static final String TOKEN_AGGREGATE = "aggregate";
    public static final String TOKEN_AVERAGE = "average";
    public static final String TOKEN_COUNT = "count";
    public static final String TOKEN_MAXIMUM = "maximum";
    public static final String TOKEN_MINIMUM = "minimum";
    public static final String TOKEN_PERCENTOFTOTAL = "percentOfTotal";
    public static final String TOKEN_SUM = "sum";

    public static final String TOKEN_DIFFERENCE = "difference";
    public static final String TOKEN_INDEX = "index";
    public static final String TOKEN_PERCENTDIFFERENCE = "percentDifference";
    public static final String TOKEN_PERCENTMARKUP = "percentMarkup";
    public static final String TOKEN_PERCENTVARIANCE = "percentVariance";
    public static final String TOKEN_RANK = "rank";
    public static final String TOKEN_RATIO = "ratio";
    public static final String TOKEN_SHARE = "share";
    public static final String TOKEN_VARIANCE = "variance";

    public static final String TOKEN_CALENDARTODATE = "calendarToDate";
    public static final String TOKEN_CALENDARTOGO = "calendarToGo";
    public static final String TOKEN_CUMULATIVETOTAL = "cumulativeTotal";
    public static final String TOKEN_FISCALTODATE = "fiscalToDate";
    public static final String TOKEN_FISCALTOGO = "fiscalToGo";
    public static final String TOKEN_LAG = "lag";
    public static final String TOKEN_LAGDIFFERENCE = "lagDifference";
    public static final String TOKEN_LAGPERCENT = "lagPercent";
    public static final String TOKEN_LEAD = "lead";
    public static final String TOKEN_MOVINGAVERAGE = "movingAverage";
    public static final String TOKEN_MOVINGMAXIMUM = "movingMaximum";
    public static final String TOKEN_MOVINGMINIMUM = "movingMinimum";
    public static final String TOKEN_MOVINGTOTAL = "movingTotal";
    
    public static final String TOKEN_DIMENSION = "dimension";
    public static final String TOKEN_MEMBER = "member";
    public static final String TOKEN_DIMENSIONMEMBER = "dimensionMember";
    public static final String TOKEN_FUNCTION = "function";
    public static final String TOKEN_FUNCTION_NAME = "functionName";
    public static final String TOKEN_HIERARCHY = "hierarchy";
    public static final String TOKEN_HIERARCHY_NAME = "hierarchyName";
    public static final String TOKEN_LEVEL = "level";
    public static final String TOKEN_LEVEL_NAME = "levelName";
    public static final String TOKEN_MEASURE = "measure";
    public static final String TOKEN_MEASURE_NAME = "measureName";
    public static final String TOKEN_QDR = "qdr";
    public static final String TOKEN_SELECTION = "selection";
    public static final String TOKEN_SELECTION_NAME = "selectionName";

    public static final String TOKEN_DOUBLE_QUOTES = "doubleQuotes";
    public static final String TOKEN_ESCAPE_CHAR = "escapeChar";
    public static final String TOKEN_EXPONENTIAL = "exponential";
    public static final String TOKEN_AND = "and";
    public static final String TOKEN_NOT = "not";
    public static final String TOKEN_OR = "or";
    public static final String TOKEN_WHITE_SPACE = "whiteSpace";
    
    /**
     * The token begin index attribute.
     *
     * @status New
     */
    public static final String TOKENATTRIB_BEGININDEX = "beginIndex";

    /**
     * The bold attribute.
     *
     * @status New
     */
    public static final String TOKENATTRIB_BOLD = "bold";

    /**
     * The token class attribute.
     *
     * @status New
     */
    public static final String TOKENATTRIB_CLASS = "class";

    /**
     * The dimension associated with the specified token
     *
     * @status New
     */
    public static final String TOKENATTRIB_DIMENSION = "attributeDimension";
    
    /**
     * The display syntax for the token
     *
     * @status New
     */
    public static final String TOKENATTRIB_DISPLAYSYNTAX = "displaySyntax";
    
    /**
     * The token end index attribute.
     *
     * @status New
     */
    public static final String TOKENATTRIB_ENDINDEX = "endIndex";

    /**
     * The font family attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_FONTFAMILY = "fontFamily";
    
    /**
     * The font size attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_FONTSIZE = "fontSize";
    
    /**
     * The foreground attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_FOREGRAOUND = "foreground";
    
    /**
     * The function type attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_FUNCTIONTYPE = "functionType";

    /**
     * The italic attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_ITALIC = "italic";
    
    /**
     * The parent token associated with the current token.
     *
     * @status New
     */
    public static final String TOKENATTRIB_PARENTTOKEN = "parentToken";

    /**
     * The begin index for the parent token associated with the current token.
     *
     * @status New
     */
    public static final String TOKENATTRIB_PARENTTOKEN_BEGININDEX = "parentTokenBeginIndex";

    /**
     * The end index for the parent token associated with the current token.
     *
     * @status New
     */
    public static final String TOKENATTRIB_PARENTTOKEN_ENDINDEX = "parentTokenEndIndex";

    /**
     * The qualify attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_QUALIFY = "qualify";

    /**
     * The syntax for the token
     *
     * @status New
     */
    public static final String TOKENATTRIB_SYNTAX = "syntax";

    /**
     * The underline attribute
     *
     * @status New
     */
    public static final String TOKENATTRIB_UNDERLINE = "underline";
    
    /**
     * The "CALCPARSER_TOKENCLASS" attribute value for a function.
     *
     * @status New
     */
    public static final String TOKENCLASS_FUNCTION_NAME = "functionClass";

    /**
     * The "CALCPARSER_TOKENCLASS" attribute value for keywords.
     *
     * @status New
     */
    public static final String TOKENCLASS_KEYWORD = "keywordClass";

    /**
     * The "CALCPARSER_TOKENCLASS" attribute value for a number
     *
     * @status New
     */
    public static final String TOKENCLASS_NUMERIC = "numericClass";

    /**
     * The "CALCPARSER_TOKENCLASS" attribute value for an operator.
     *
     * @status New
     */
    public static final String TOKENCLASS_OPERATOR = "operatorClass";
}