/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;
import java.util.Enumeration;
import javax.naming.NamingSecurityException;

/**
 * Indicates a security problem with a naming operation.
 * Subclasses of this class provide more detail.
 * To handle this exception in particular, catch it before you catch a
 * <code>NamingException</code>.
 * Then, you can try to solve the problem.
 *
 * @status documented
 */
public class BINamingSecurityException extends NamingSecurityException 
implements ExtendedBIException
{
    /**
     * @hidden
     * Never null
     * @serial Support code for JboExceptions
     */
    private final BIRemoteException m_jboEx;

    
    /**
     * @hidden
     * Constructor for an exception that cannot be localized and that passes
     * on an underlying exception.
     *
     * @param msg  The text of the error message.
     * @param prevException The exception that underlies this exception.
     */
    public BINamingSecurityException(String msg, Throwable prevException)
    {
        super(msg);
        // Link into base classes exception stack mechanisms.  
        setRootCause(prevException);
        m_jboEx = new BIRemoteException(msg, prevException);
    }

   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    */
    public BINamingSecurityException(Class resBundleClass, String errorCode, String[] params)
    {
        m_jboEx = new BIRemoteException(resBundleClass, errorCode, params, null);
    }

   /**
    * @hidden
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale    The locale in which this message is localized.
    * @param prevException  The exception that underlies this exception.
    */
    public BINamingSecurityException(Class resBundleClass, String errorCode, String[] params, Locale locale, Throwable prevException)
    {
        // Link into base classes exception stack mechanisms.  
        setRootCause(prevException);
        m_jboEx = new BIRemoteException(resBundleClass, errorCode, params, locale, prevException);
    }
        
    /**
     * Retrieves the underlying exception, if one exists.
     *
     * @return The previous exception. If there is no previous exception,
     *         then this method returns <code>null</code>.
     *
     * @status documented
     */
    public Throwable getPreviousException()
    {
        return m_jboEx.getPreviousException();
        
    }

    /**
     * Retrieves the exception stack.
     *
     * @return A concatenation of all messages from exceptions in the
     *         exception stack.
     *
     * @status documented
     */
    public String toString()
    {
        return m_jboEx.toString(this);
       
    }

   /**
    * Retrieves a message that is localized for the default locale.
    *
    * @return The localized message.
    *
    * @status documented
    */
    public String getMessage()
    {
        return m_jboEx.getMessage();
        
    }

   /**
    * Retrieves a message that is localized for the default locale
    * set in the exception
    *
    * @return The localized message.
    *
    * @status New
    */
    public String getLocalizedMessage()
    {
        return m_jboEx.getLocalizedMessage();
        
    }

   /**
    * @hidden
    * Retrieves a message that is localized for a specified <code>Locale</code>.
    *
    * @param l The locale whose translation to retrieve.
    *
    * @return The localized message.
    */
    public String getLocalizedMessage(Locale l)
    {
       return m_jboEx.getLocalizedMessage(l);
       
    }

   /**
    * @hidden
    * Retrieves the parameters for the error message.
    *
    * @return An array that contains an object for each token in the
    *         error message.
    */
    public Object[] getErrorParameters()
    {
        return m_jboEx.getErrorParameters();
        
    }

   /**
    * @hidden
    * Retrieves the error code for this exception.
    * The error code is the key into the resource bundle for the message.
    *
    * @return The error code for this exception.
    */
    public String getErrorCode()
    {
        return m_jboEx.getErrorCode();
        
    }

   /**
    * @hidden
    * Retrieves the product code for this exception.
    * Because this exception is caused by an exception from Java Business
    * Objects, the product code is the constant <code>JBO_PRODUCT_CODE</code>.
    *
    * @return The product code for this exception.
    */
    public String getProductCode()
    {
        return m_jboEx.getProductCode();
        
    }

   /**
    * @hidden
    * Indicates whether the message for this exception can be localized.
    *
    * @return <code>true</code> if the message can be localized,
    *         <code>false</code> if it cannot.
    */
    public boolean isLocalizable()
    {
        return m_jboEx.isLocalizable();
       
    }

    /**
     * Retrieves the root exception.
     *
     * @return the root exception.
     *
     * @status New
     */
    public Throwable getBIRootCause()
    {
        return m_jboEx.getBIRootCause(this);
        
    }

    /**
     * Retrieves the exception at the specified index.
     *
     * @return The exception at the specified index.
     *
     * @status New
     */
    public Throwable elementAt(int index)
    {
        return m_jboEx.elementAt(index, this);
        
    }

    /**
     * Retrieves An enumeration of exceptions in the exception chain.
     *
     * @return An enumeration containing the exceptions.
     *
     * @status New
     */
    public Enumeration elements()
    {
        return m_jboEx.elements(this);
        
    }

    /**
     * Retrieves the size of the exception chain.
     *
     * @return The size of the exception chain.
     *
     * @status New
     */
    public int size()
    {
        return m_jboEx.size();
        
    }
}
