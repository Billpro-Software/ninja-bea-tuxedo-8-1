/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.NamingException;

/**
 * An ObjectLoader allows objects to be accessed by id.  Combined references 
 * such as search results to be resolved.  
 * <p>
 * Except for shortcuts, the {@link #getObjectDefinition(String)} method 
 * returns the same object as {@link #getObject(String)}.
 * 
 * @hidden
 * 
 */
public interface ObjectLoader
{
    /**
     * Load the immediate object.  This may be a shortcut.  
     * @throws NamingException
     */
    public abstract Object getObject(String id) throws NamingException;
    
    /**
     * Load the underlying object, following shortcuts.  
     * @throws NamingException
     */
    public abstract Object getObjectDefinition(String id) throws NamingException;
}