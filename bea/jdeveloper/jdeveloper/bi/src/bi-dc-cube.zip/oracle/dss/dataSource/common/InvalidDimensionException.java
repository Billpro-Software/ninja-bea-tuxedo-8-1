/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if dimensions are invalid.
 *
 * @status Documented
 */
public class InvalidDimensionException extends InvalidMetadataException
{
    /**    
     * Constructor for a single invalid dimension.
     *
     * @param s      Message to display.
     * @param object Name of invalid dimension.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidDimensionException(String s, String object, Throwable e)
    {
        super(s, object, e);
    }
    
    /**    
     * Constructor for multiple invalid dimensions.
     *
     * @param s      Message to display.
     * @param object Names of invalid dimensions.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidDimensionException(String s, String[] object, Throwable e)
    {
        super(s, object, e);
    }        
    
    /**    
     * Constructor for a single invalid dimension.
     *
     * @param s      Message to display.
     * @param object Name of invalid dimension.
     * @param step   Optional Step containing invalid metadata
     * @param hierarchy Optional hierarchy ID associated with invalid dimension
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
    public InvalidDimensionException(String s, String object, /*Step step, */String hierarchy, Throwable e)
    {
        super(s, object, /*null, step, hierarchy, */e);
    }
    
}