/*
 * HyperLinkCombo.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import javax.swing.ListCellRenderer;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;

import oracle.dss.datautil.gui.Utils;

import oracle.dss.util.gui.LightWeightComboBox;

/**
 * @hidden
 */
public class HyperLinkCombo extends LightWeightComboBox implements HyperLinkControl {
    // Flag keeping track of the mode
    private boolean m_blnIsHyperLink;
    // Flag keeping track of whether the ItemEvents should be fired to the listeners
    private boolean m_blnSilent = false;
    private boolean m_blnNotifyListeners = true;
    // Create the hyperlink combo UI class
    private HyperLinkComboUI m_hyperLinkComboUI;
    // Create the mouse listener used to set the cursor to a hand when over the hyperlink
    private HyperCursorListener m_hyperCursorListener;    
    // The previous selected index;
    private int m_intPreviousSelectedIndex;
    // The vector of disabled items
    private Vector m_disabledItems = new Vector();
        
    /**
    * @hidden
    * Constructor which creates an empty HyperLinkCombo.
    */  
    public HyperLinkCombo() {
        super();
        initHyperLinkCombo();
    }
    
    /**
    * @hidden    
    * Constructor which creates a HyperLinkCombo that takes 
    * its items from an existing ComboBoxModel
    */  
    public HyperLinkCombo(ComboBoxModel aModel) {
        super(aModel);
        initHyperLinkCombo(); 
    }    
        
    /**
    * @hidden
    * Constructor which creates a HyperLinkCombo that contains 
    * the elements in the specified array.
    */  
    public HyperLinkCombo(Object[] items) {
        super(items);
        initHyperLinkCombo(); 
    }
 
    /**
    * @hidden
    * Constructor which creates a HyperLinkCombo that contains 
    * the elements in the specified Vector.
    */  
    public HyperLinkCombo(Vector items) {
        super(items);
        initHyperLinkCombo(); 
    }
    
    /**
     * @hidden
     * Disables the given item in the list.
     *
     * @param item The item to disable.
     */
    public void disableItem(Object item) {
        int intDisabledItemIndex = Utils.indexOf(this, item);
        if (intDisabledItemIndex != -1) {
            if (!m_disabledItems.contains(item)) {
                m_disabledItems.addElement(item);
            }
        }
    }
    
    /**
     * @hidden
     * Enables the given item in the list.
     *
     * @param item The item to enable.
     */
    public void enableItem(Object item) {
        int intDisabledItemIndex = Utils.indexOf(this, item);
        if (intDisabledItemIndex != -1) {
            m_disabledItems.removeElement(item);
        }  
    }
    
    /**
     * @hidden
     * Returns a vector of items in the combo box that are disabled.
     * @return Vector of disabled items.
     */
    public Vector getDisabledItems() {
        return m_disabledItems;
    }
    
    /**
    * @hidden
    * Sets the display mode for this control.
    * @param isHyperLink - boolean flag which if true will set 
    * the display of the combo box to the hyperlink mode
    */  
    public void setHyperLink(boolean isHyperLink) {
        if (m_blnIsHyperLink != isHyperLink) {
            if (isHyperLink) {
                // Set the UI class to be the HyperLinkComboUI
                setUI(m_hyperLinkComboUI);
                addMouseListener(m_hyperCursorListener);
            }
            else {
                // Set the default JComboBox UI
                updateUI();
                removeMouseListener(m_hyperCursorListener);
            }
            // Set the internal mode
            m_blnIsHyperLink = isHyperLink;
        }
    }
          
    /**
    * @hidden
    * Sets the display mode for this control.
    * @return true if the combo box is in the hyperlink mode
    */    
    public boolean isHyperLink() {
         return (m_blnIsHyperLink);   
    }

    /**
     *  @hidden
     */
    public void setModel(ComboBoxModel aModel) {
        super.setModel(aModel);
        updateModel();
    }

    /**
     *  @hidden
     */
    protected void updateModel() {
        ComboBoxModel model = getModel();
        updateEnabled();
        if (model != null) {
            model.addListDataListener(new ListDataListener() {
                public void intervalAdded(ListDataEvent e) {
                    updateEnabled();
                }
                public void intervalRemoved(ListDataEvent e) {
                    updateEnabled();
                }
                public void contentsChanged(ListDataEvent e) {
                    updateEnabled();
                }
            });
        }
    }
       
    /**
    * @hidden
    * Sets the items of the combo box from the given Vector
    *
    * @param vItems - Vector of items to be put in the combo box
    */     
    public void setItems(Vector vItems) {
        setSilent(true);
        super.setModel(new DefaultComboBoxModel(vItems));
        setSilent(false);
    }
    
    /**
    * @hidden
    * Sets the items of the combo box from the given array
    *
    * @param arrItems - array of items to be put in the combo box
    */     
    public void setItems(Object[] arrItems) {
        super.setModel(new DefaultComboBoxModel(arrItems));
    }

    /**
    * @hidden
    * Sets the selected item to the given index
    * without notifying the ItemListeners
    *
    * @param intIndex - index to be selected
    */  
    public void setSelectedIndexSilently(int intIndex) {
        // Set the internal flag to avoid the listener notification
        m_blnNotifyListeners = false;
        super.setSelectedIndex(intIndex);
        m_blnNotifyListeners = true;
    }
    
    /**
     * @hidden
     * Sets the combo box back to its previously stored index.
     */
    public void restore() {
    	setSelectedIndex(m_intPreviousSelectedIndex);
    }
    
    /**
     * @hidden
     * Sets the combo box back to its previously stored index.
     */
    public void restoreSilently() {
    	setSelectedIndexSilently(m_intPreviousSelectedIndex);
    }
    
    /*
     * @hidden
     * Deterines whether ItemEvents are fired to the listeners. 
     */
    public void setSilent(boolean blnSilent) {
        m_blnSilent = blnSilent;
    }
    
    /*
     * @hidden
     * Returns whether ItemEvents are currently being fired to the listeners.
     */
    public boolean isSilent() {
        return m_blnSilent;
    }
    
    /**
     * @hidden
     * Selects the item at index anIndex.
     */
 	public void setSelectedIndex(int anIndex) {
        if (!m_disabledItems.contains(getModel().getElementAt(anIndex))) {
            if (m_blnNotifyListeners) {
 			    m_intPreviousSelectedIndex = getSelectedIndex();
                selectedItemReminder = getModel().getSelectedItem();
 		    }
            super.setSelectedIndex(anIndex);
        }
 	}

	/**
     * @hidden
	 * Sets the selected item in the JComboBox by specifying the object in the list.
	 */
    public void setSelectedItem(Object anObject) {        
        if (m_blnNotifyListeners) {
    		m_intPreviousSelectedIndex = getSelectedIndex();
            selectedItemReminder = getModel().getSelectedItem();
    	}
    	super.setSelectedItem(anObject);
    }
                                   
    /**
    * @hidden
    * Sets the selected item to the given Object
    * without notifying the ItemListeners
    *
    * @param anObject - Object to be selected
    */ 
    public void setSelectedItemSilently(Object anObject) {
        // Set the internal flag to avoid the listener notification
        m_blnNotifyListeners = false;
        super.setSelectedItem(anObject);
        m_blnNotifyListeners = true;
    }

    // Overriding the method in the JComboBox to revalidate after the item has changed
    // to force the combo box to resize to fit the newly selected item
    // Added the ability to disable firing of the ItemEvents to the listeners
    // in case when we want to update the combo box but ignore the events
    protected void selectedItemChanged() {
        Object selectedItem = getSelectedItem();        
        if ((selectedItem != null) && selectedItem.equals(SEPARATOR)) {
            // Ignore the item state change, 
            // and revert back to the old item
            setSelectedItemSilently(selectedItemReminder);
        }
        else {
            revalidate();
            if (m_blnNotifyListeners) {
                // If not ignoring the ItemEvents, 
                // fire the ItemEvents to all the listeners        
                super.selectedItemChanged();   
            }
        }
    }
    
    // Set the features of the HyperLinkCombo
    private void initHyperLinkCombo() {
        // Set the renderer so that the selected item is displayed as a hyperlink
        setRenderer(new HyperComboRenderer(this));       
        // Create the hyperlink combo UI class
        m_hyperLinkComboUI = new HyperLinkComboUI();
        // Create the mouse listener used to set the cursor to a hand when over the hyperlink
        m_hyperCursorListener = new HyperCursorListener();
        // Set the default mode to hyperlink
        setHyperLink(true);
        addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent e) {
                if ("model".equals(e.getPropertyName())) {
                    updateModel();
                }
            }
        });
    }

    private void updateEnabled() {
        setEnabled(getModel().getSize() > 1);
    }
     
    //=================================
    // Begin HyperLinkComboUI
    //

    // Subclass of the BasicComboBoxUI
    // Several methods are overriden to provide special behavior
    // For specicif methods details, see below
    protected class HyperLinkComboUI extends BasicComboBoxUI {
        // The margins on the popup
        protected final int POPUP_PADDING = 15;
        // The preferred height of this control
        protected final int PREF_HEIGHT = 15;
        
        // Overriden to return our subclass of the BasicComboPopup
        // See HyperComboPopup
        protected ComboPopup createPopup() {
            BasicComboPopup popup = new HyperComboPopup(comboBox);
            popup.getAccessibleContext().setAccessibleParent(comboBox);
            String lafName = UIManager.getLookAndFeel().getClass().getName();
            // This is the only look-and-feel specific code
            // We are setting a special border for the popup under the 
            // Oracle Look and Feel
            if (lafName.equals("oracle.bali.ewt.olaf.OracleLookAndFeel")) {
                // Make sure the JPopupMenu is correct for the Oracle Look and Feel
                popup.setBorder(UIManager.getBorder("PopupMenu.border"));
            }
            return popup;
        }

        // Overriden to NOT create the arrow button and the editor
        // which the superclass method would create
        protected void installComponents() {
            comboBox.add(currentValuePane);
        }
        
        // Overriden to NOT create the arrow button
        protected JButton createArrowButton() {
            return (null);
        }

        //----- Begin Size methods ------ 
        
        // Overriden to return the new minimum size for this control
        protected Dimension getDefaultSize() {
            return new Dimension(0, 0);
        }
        
        // Uses the method getDisplaySize() in the BasicComboBoxUI 
        // to calculate the width for the ComboBox popup
        protected int getPopupWidth() {
            // Cached the size that the display needs to render the largest item
            Dimension cachedDisplaySize = new Dimension( 0, 0 );
            Dimension displaySize;

            int i,c;
            Dimension result = new Dimension();
            ListCellRenderer renderer = comboBox.getRenderer();
            ComboBoxModel model = comboBox.getModel();
            Component cpn;
            Dimension d;

            if ( renderer != null && model.getSize() > 0 ) {
                for ( i=0,c=model.getSize();i<c;i++ ) {
                    cpn = renderer.getListCellRendererComponent(listBox, model.getElementAt(i), i, false, false);
                    cpn.setFont(comboBox.getFont());
                    d = cpn.getPreferredSize();
                    result.width = Math.max(result.width,d.width);
                    result.height = Math.max(result.height,d.height);
                }
                cachedDisplaySize.setSize( result.width, result.height );
                displaySize = result;
            }
            else {
                displaySize = getDefaultSize();
            }
            // Add some "elbow room"
            int popupWidth = displaySize.width + POPUP_PADDING;
            return (popupWidth);
        }
        
        // Overriden from the superclass BasicComboBoxUI
        // to take into account only the size of the currently selected item,
        // instead of going through all the items and selecting the largest
        protected Dimension getDisplaySize() {
            ListCellRenderer renderer = comboBox.getRenderer();
            Dimension displaySize = getDefaultSize();
            if ((renderer != null) && (comboBox.isVisible())) {
                Component comp = renderer.getListCellRendererComponent(listBox, comboBox.getSelectedItem(), -1, false, false);
                currentValuePane.add(comp);
                comp.setFont(comboBox.getFont());
                displaySize = new Dimension(comp.getPreferredSize().width, PREF_HEIGHT);
                currentValuePane.remove(comp);
            }
            return displaySize; 
        }
           
        // Overriden from the superclass BasicComboBoxUI
        // to return the display size and ignore the button size
        public Dimension getMinimumSize(JComponent c) {
            return getDisplaySize();
        }
        
        // Overriden from the superclass BasicComboBoxUI
        // to return the display size and ignore the button size
        public Dimension getPreferredSize(JComponent c) {
            return getDisplaySize();
        }

        // Overriden from the superclass BasicComboBoxUI
        // to prevent the size of this component from becoming bigger than the preferred size
        public Dimension getMaximumSize(JComponent c) {
            return getDisplaySize();
        }

        // ----- End Size methods -----
        
        // ----- Begin painting methods -----
        
        // Overriden from the superclass BasicComboBoxUI
        // to ignore the button size when painting the current value
        protected Rectangle rectangleForCurrentValue() {
            int width = comboBox.getWidth();
            int height = comboBox.getHeight();
            return new Rectangle(0, 0, width, height);
        }
        
        // Overriden from the superclass BasicComboBoxUI 
        // to paint the current value foreground as a hyperlink
        public void paintCurrentValue(Graphics g,Rectangle bounds,boolean hasFocus) {
            // Get the HyperComboRenderer component
            ListCellRenderer renderer = comboBox.getRenderer();
            HyperComboRenderer hyperRenderer;
            // If no items are selected, do not paint
            if ( comboBox.getSelectedIndex() == -1 ) {
               return;
            }
            // If it has focus, and the popup is not visible, 
            // the current value should paint as selected
            boolean isSelected = hasFocus && !isPopupVisible(comboBox);
            // Get the renderer component
            hyperRenderer = (HyperComboRenderer)renderer.getListCellRendererComponent(listBox,
                                                      comboBox.getSelectedItem(),
                                                      -1,
                                                      isSelected,
                                                      false);
            // Set the Font to the combo box font
            hyperRenderer.setFont(comboBox.getFont());
            // Set the underlined property to true if the component is enabled
            hyperRenderer.setUnderlined(comboBox.isEnabled());
            // Remove the border
            hyperRenderer.setBorder(null);
            // Set the selection foreground and background colors
            if (isSelected) {
                hyperRenderer.setForeground(listBox.getSelectionForeground());
                hyperRenderer.setBackground(listBox.getSelectionBackground());
            }
            else {
                // Set the label background
                hyperRenderer.setBackground(UIManager.getColor("Label.background"));
                if (comboBox.isEnabled()) {
                    // Set the hyperlink foreground
                    hyperRenderer.setForeground(Color.blue);              
                }
                else {
                    // Set the usual label foreground
                    hyperRenderer.setForeground(UIManager.getColor("Label.foreground"));
                }
            }
            // Paint the component using the CellRendererPane (taken from the BasicComboBoxUI)
            currentValuePane.paintComponent(g,hyperRenderer,comboBox,bounds.x,bounds.y,
                                            bounds.width,bounds.height);
        }
        // ----- End painting methods -----

        // Overriden from the superclass BasicComboBoxUI
        // to avoid installing the combo box border
        protected void installDefaults() {
            LookAndFeel.installColorsAndFont(comboBox,
                                          "ComboBox.background",
                                          "ComboBox.foreground",
                                          "ComboBox.font" );
            //LookAndFeel.installBorder(comboBox, "ComboBox.border" );
        }
        
        // ----- Begin Keyboard Action Management -----
        //
        
        // Install the up and down arrow keys as selection changers
        protected void installKeyboardActions() {
            super.installKeyboardActions();
        
            final JComboBox cBox = comboBox;
            //final JButton button = arrowButton;
        
            // Action used for selecting the next value down
            AbstractAction downAction = new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    selectNextPossibleValue();
                }
                public boolean isEnabled() {
                    return (cBox.isEnabled() && cBox.isPopupVisible());
                }
            };

            // Register the down action with the combo box
            comboBox.registerKeyboardAction(downAction,
                                  KeyStroke.getKeyStroke(KeyEvent.VK_DOWN,0),
                                  JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

            // Action used for selecting the previous value in the combo popup
            AbstractAction upAction = new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    selectPreviousPossibleValue();
                }
            
                public boolean isEnabled() {
                    return (cBox.isEnabled() && cBox.isPopupVisible());
                }
            };

            // Register the up action with the combo box
            comboBox.registerKeyboardAction(upAction,
                                  KeyStroke.getKeyStroke(KeyEvent.VK_UP,0),
                                  JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }


        // Remove up and down arrows as selection changers
        protected void uninstallKeyboardActions() {
            super.uninstallKeyboardActions();
            comboBox.unregisterKeyboardAction(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN,0));
            comboBox.unregisterKeyboardAction(KeyStroke.getKeyStroke(KeyEvent.VK_UP,0));
        }
        // ----- End Keyboard Action Management -----
        //
    }
    
    //=================================
    // End HyperLinkComboUI
    //
    
    //=================================
    // Begin HyperComboPopup
    //

    // Subclass of the BasicComboPopup
    // The only change is that we override the method computePopupBounds()
    // to set the popup width to the width of the largest item in the popup 
    protected class HyperComboPopup extends BasicComboPopup {
        public HyperComboPopup(JComboBox combo) {
            super(combo);
        }
        
        // Overriden from the superclass BasicComboPopup
        // to get the preferred width of the popup from the Combo box UI class
        protected Rectangle computePopupBounds(int px,int py,int pw,int ph) {
            HyperLinkComboUI comboUI = (HyperLinkComboUI)comboBox.getUI();
            int popupWidth = comboUI.getPopupWidth();
            return (super.computePopupBounds(px, py, popupWidth, ph));
        }
        
        protected void syncWithComboBoxSelection() {
            int selectedIndex = comboBox.getSelectedIndex();

            if (selectedIndex == -1) {
                list.clearSelection();
            }
            else {
                list.setSelectedIndex(selectedIndex);
            }
        }
    }
    
    //=================================
    // End HyperComboPopup
    //
    
    // Listener for the mouse entered/exited events, which changes the cursor
    // to a hand pointer when over the HyperLinkCombo
    private class HyperCursorListener extends MouseAdapter {
         // When mouse enters the label, change the cursor to "hand", unless the label is not a hyperlink
        public void mouseEntered(MouseEvent e) {
            // Enable the reactions to the mouse press
            //setIgnoreMousePress(false);
            // Set the cursor to hand, if enabled
            if (isEnabled()) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            else {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        }
        // When the mouse exits the label, set the cursor back to default
        public void mouseExited(MouseEvent e) {
            // Set the cursor back to default
            setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        }
    }
}