/*
 * DataUtilExceptionListener.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

import oracle.dss.datautil.ExceptionListener;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;

/**
 * @hidden
 *
 * DataUtil Exception Listener.
 *
 * @status hidden
 */

public class DataUtilExceptionListener implements ExceptionListener {

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
	 * @hidden
   *
   * Error handler reference
   *
   * @status hidden
   */
  protected transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
  * @hidden
   * Default constructor.
   *
   * @status hidden
   *
   */
  public DataUtilExceptionListener () {
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Responds to trapped exception.
   *
   * <code>ExceptionListenerCallback</code> implementations call this method when
   * an exception is required in response to an exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return           <code>int</code> value which represents a positive response
   *                   when zero and a negative response when non-zero.
   *
   * @see #YES
   * @see #NO
   * @see #NONE
   *
   * @status New
   */
  public int processException (Throwable throwable, String strClass, String strRoutine) {
    return ExceptionListener.NONE;  
  }

	//-------------------------------------------------------------------
	// Start implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status New
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status New
   */
  public void removeErrorHandler() {
    addErrorHandler (new DefaultErrorHandler());
  }

	//-------------------------------------------------------------------
	// End implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> that represents the current
   *         error handler.
   *
   * @status New   
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}

