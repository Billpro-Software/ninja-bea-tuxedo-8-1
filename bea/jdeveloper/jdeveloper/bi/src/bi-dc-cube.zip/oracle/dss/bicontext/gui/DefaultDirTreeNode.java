/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.Hashtable;
import java.util.Vector;

import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;
import javax.swing.Icon;
import javax.swing.tree.DefaultMutableTreeNode;

import javax.naming.directory.Attributes;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import javax.swing.tree.TreeNode;

import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.BISearchControls;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.gui.component.tree.ComponentTreeNodeImpl;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 * This is the default implementation of the DirTreeNode interface.
 * Each instance represents a tree node in the Common Tree Model.
 *
 * Most of the work are taken care of by DefaultMutableTreeNode
 */
public class DefaultDirTreeNode extends ComponentTreeNodeImpl implements DirTreeNode
{
    // The directory model
    protected DirContext m_context;
    protected SearchResult m_entry;

    private String m_name;
    private String m_fullPathName;
    private boolean m_isRoot = false;
    private boolean m_disable = false;

    // Icon to show in tree
    private Icon m_icon = null;

    public static final String ATTRIBUTES = "attrs";
    public static final String SEARCHCONTROLS = "controls";
    public static final String ERRORHANDLER = "eh";
    public static final String NODEFACTORY = "factory";

    /**
     * @hiddeen
     */
    public DefaultDirTreeNode()
    {
        super(null, null, null);
    }

    /**
     * Constructor for root node
     * @param env the properties (filters, search controls etc.)
     * @param context the BIContext
     * @param rootName the name of the root
     *
     * @status New
     */
    public DefaultDirTreeNode(Hashtable env, DirContext context, String rootName)
    {
        super(null, null, env);
        
        if (env == null)
            setEnvironment(new Hashtable(10));

        setAllowsChildren(true);
        setName(rootName);

        m_context = context;
        // this is the root node, get entries
        m_isRoot = true;
        m_fullPathName = "";
    }

    /**
     * Constructor for non-root node.
     *
     * @param model the DirTreeModel
     * @param pathName the path name of the node in the tree
     * @param entry the SearchResult associated with this node
     */
    public DefaultDirTreeNode(Hashtable env, SearchResult entry)
    {
        super(null, null, env);

        if (env == null)
            setEnvironment(new Hashtable(10));

        m_entry = entry;
        setAllowsChildren(true);
        setUserObject(entry);
        initializeFromEntry(entry);
    }

    // Initialize the node from information in SearchResult
    private void initializeFromEntry(SearchResult entry)
    {
        if (entry instanceof BISearchResult)
            setName(((BISearchResult)entry).getLabel());
        Attribute _attr = entry.getAttributes().get("obj_fullpath_name");
        if (_attr != null)
        {
            try
            {
                m_fullPathName = (String)_attr.get();
            }
            catch (Exception ex){}
        }
    }

    // implementation of Node interface
    /**
     * Returns name that is displayed in tree view.
     *
     * @return name that is displayed in tree view.
     * @status New
     */
    public String getName()
    {
        return m_name;
    }

    /**
     * Sets name for this node.
     *
     * @param name name for this node.
     * @status New
     */
    public void setName(String name)
    {
        m_name = name;
    }

    public String getFullPathName()
    {
        return m_fullPathName;
    }
    
    public void setFullPathName(String fullPathName)
    {
        m_fullPathName = fullPathName;
    }

    /**
     * Returns 16x16 image that is displayed by this tree node.
     *
     * @return image that is displayed by this tree node
     */
    public Icon getIcon()
    {
        if (m_icon == null)
        	loadIcon();

        return m_icon;
    }

    public Icon getOpenIcon()
    {
        return getIcon();
    }

    public Icon getClosedIcon()
    {
        return getIcon();
    }

    /**
     * Sets 16x16 image that is displayed by this tree node.
     *
     * @param icon image that is displayed by this tree node
     */
    public void setIcon(Icon icon)
    {
        m_icon = icon;
    }

    private void loadIcon() 
    {
  	    setIcon(IconManager.getIcon(getObjectType()));
    }

    // implementation of DirTreeNode    
    /**
     * Retrieves the DirContext associated with this node if this node
     * is a folder, otherwise, return null
     *
     * @return the DirContext associated with this node 
     * @status New
     */
    public DirContext getDirContext()
    {
        if (m_context == null)
            m_context = (DirContext)m_entry.getObject();

    	return m_context;
    }

    public DirContext getParentDirContext()
    {
        if (getParent() != null && getParent() instanceof DirTreeNode)
            return ((DirTreeNode)getParent()).getDirContext();
        else
            return null;
    }

    /**
     * Retrieves the SearchResult associated with this node
     *
     * @return the <code>SearchResult</code> associated with this node
     * @status New
     */
    public SearchResult getSearchResult()
    {
        Object _obj = getUserObject();
        if (_obj instanceof SearchResult)
            return (SearchResult)getUserObject();
        else
            return null;
    }

    /**
     * Create a vector of all the one level depth sub nodes.
     * The nodes are also added as subnodes to this node.
     */
    protected Vector getChildren()
    {
        Vector _children = new Vector(50);            
        try
        {
            getDirContext();
            if (m_context == null)
                return _children;

            // Search for immediate children
            Attributes _attrs = (Attributes)getEnvironment().get(ATTRIBUTES);
            BISearchControls _controls = (BISearchControls)getEnvironment().get(SEARCHCONTROLS);
            if (_controls == null)
                _controls = new BISearchControls();
            _controls.setSortingOn(true);
            _controls.setReturningAttributes(addPriv(_controls));

            NamingEnumeration _results = ((BIContext)m_context).search("", _attrs, _controls);
            while (_results.hasMoreElements())
            {
                // Add each entry found to the tree
                BISearchResult _result = (BISearchResult)_results.next();
                
                // do not add the children if no privilege
                if (_result.getAttributes().get("privilege") != null)
                {
                    Attribute _attr = (Attribute)_result.getAttributes().get("privilege");
                    if (_attr.get() == null)
                        continue;
                }

                TreeNode _node = createDirTreeNode(_result);
                _children.add(_node);
            }
        }
        catch (NamingException ne)
        {
            getErrorHandler().error(ne, getClass().getName(), "getChildren");
        }
        
        return _children;
    }

    // subclass can override this method to allow creation of custom tree node
    protected TreeNode createDirTreeNode(SearchResult result)
    {
        if (getEnvironment().get(NODEFACTORY) != null)
        {
            TreeNodeFactory _factory = (TreeNodeFactory)getEnvironment().get(NODEFACTORY);
            TreeNode _node = _factory.createTreeNode(getEnvironment(), result);
            if (_node instanceof DefaultMutableTreeNode)
                ((DefaultMutableTreeNode)_node).setParent(this);
            return _node;
        }
        else
        {
            DefaultDirTreeNode _node = new DefaultDirTreeNode(getEnvironment(), result);
            _node.setParent(this);
            return _node;
        }
    }

    /**
     * Checks whether the node is a folder or not
     *
     * @return true if the node is a folder, false otherwise.
     */
    public boolean isFolder(SearchResult entry)
    {
        if (entry == null)
            return true;
        else
            return PersistableConstants.FOLDER.equals(((BISearchResult)entry).getObjectType());
    }

    /**
     * Checks whether the node is a leaf node or not. 
     *
     * @return <code>true</code> if the node is a leaf
     */
    public boolean isLeaf()
    {
        if (isFolder(m_entry) || m_isRoot)
            return false;
        else
            return true;
    }

    /**
     * Checks whether the node is the root node
     *
     * @return <code>true</code> if the node is the root node
     */
    public boolean isRoot()
    {
        return m_isRoot;
    }

    /**
     * Set the node disable for rendering
     *
     * @param disable <code>true</code> if node is disable
     *              <code>false</code> otherwise
     * @status New
     */
    public void setDisable(boolean disable)
    {
        m_disable = disable;
    }

    /**
     * Checks whether this node is disabled
     *
     * @return <code>true</code> if node is disable
     *              <code>false</code> otherwise
     * @status New
     */
    public boolean isDisable()
    {
        return m_disable;
    }

    /**
     * Insert a node as a child to this node in ascending order
     *
     * @param node the node to be inserted
     * @return the index of the newly inserted node
     */
    public int insert(DirTreeNode child)
    {
        String _myName = child.getName();

        int _count = getChildCount();        
        for (int i=0; i<_count; i++)
        {
            DirTreeNode _node = (DirTreeNode)getChildAt(i);
            // this modification is for order inserting while keeping folders grouped together
            if (PersistableConstants.FOLDER.equals(child.getObjectType()))
            {
                if (_myName.compareToIgnoreCase(_node.getName()) < 0 || !PersistableConstants.FOLDER.equals(_node.getObjectType()))
                {
                    insert(child, i);
                    child.setParent(this);
                    return i;                
                }
            }
            else
            {
                if (_myName.compareToIgnoreCase(_node.getName()) < 0 && !PersistableConstants.FOLDER.equals(_node.getObjectType()))
                {
                    insert(child, i);
                    child.setParent(this);
                    return i;
                }
            }
        }
        insert(child, _count);
        return _count;
    }

    /**
     * Retrieves the type of the object this tree node represents
     *
     * @return the object type of the underlying object
     */
    public String getObjectType()
    {
        if (m_entry != null || (m_entry instanceof BISearchResult))
            return ((BISearchResult)m_entry).getObjectType();
        else
            return PersistableConstants.FOLDER;
    }

    public boolean isDraggable()
    {
        return true;
    }

    public boolean isEditable()
    {
        return true;
    }

    public String getID()
    {
        return "CATALOG";
    }

    /**
     * Override the parent class to return a string representation of this node
     *
     * @return a string representation of this node
     */
    public String toString()
    {
        return m_name;
    }

    /**
     * @hidden 
     */
    public void cleanup()
    {
        m_entry = null;
        m_name = null;         
        m_context = null;
        m_icon = null;        
    }
    
    protected ErrorHandler getErrorHandler()
    {
        ErrorHandler _eh = (ErrorHandler)getEnvironment().get(ERRORHANDLER);
        if (_eh == null)
            _eh = new DefaultErrorHandler();
        
        return _eh;
    }
    
    private String[] addPriv(BISearchControls controls)
    {
        String[] _attrs = controls.getReturningAttributes();
        if (_attrs == null)
            return new String[]{"obj_fullpath_name", "privilege"};
        else if (_attrs.length == 0)
            return new String[]{"obj_fullpath_name", "privilege"};
        else
        {
            String[] _newAttrs = new String[_attrs.length+1];
            System.arraycopy(_attrs, 0, _newAttrs, 0, _attrs.length);
            _newAttrs[_attrs.length] = "privilege";
            
            return _newAttrs;
        }
    }
}