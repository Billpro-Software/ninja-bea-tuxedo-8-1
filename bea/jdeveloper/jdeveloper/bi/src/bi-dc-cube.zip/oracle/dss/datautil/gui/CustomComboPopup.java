/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Dimension;

import javax.swing.JComboBox;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicComboPopup;

/**
 * @hidden
 * The component allows uses to display a list as a popup menu. The user can 
 * also display a combo box using the component.
 *
 * @status hidden
 */

public class CustomComboPopup extends BasicComboPopup
{
    //-------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-------------------------------------------------------------------

    protected int m_nWidth  = -1;

    //-------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------

    /**
     * @hidden
     * Constructor that takes a JComboBox as argument.
     *
     * @param comboBox  The JComboBox whose contents are to be displayed in 
     *                  the popup.
     *
     * @status hidden
     */
    public CustomComboPopup ( JComboBox comboBox )
    {
        super ( comboBox );
    }            
        
    //-------------------------------------------------------------------
    // PUBLIC METHODS
    //-------------------------------------------------------------------

    /**
     * @hidden
     * Display the CustomComboPopup at the position x,y in the coordinate space 
     * of the component invoker.
     *   
     * nWidth   - The width of the popup component.
     *
     * @status hidden
     */
    public void setWidth ( int nWidth )
    {
        m_nWidth = nWidth;
    }
    
    /**
     * @hidden
     * Display the CustomComboPopup at the position x,y in the coordinate space 
     * of the component invoker.
     *   
     * invoker  - The component in whose space the popupmenu is to appear 
     * x        - The x coordinate in invoker's coordinate space at which 
     *            the popup menu is to be displayed. 
     * y        - The y coordinate in invoker's coordinate space at which 
     *            the popup menu is to be displayed.
     *
     * @status hidden
     */
    public void show ( Component invoker, int x, int y )
    {
        // Set the border to mimic the combo box border.
        setBorder( UIManager.getBorder ( "ComboBox.border" ) );
        
        // Make sure the popup is looking ship shape based on
        // default combo measurements.
        Dimension popupSize = comboBox.getSize ( );
        popupSize.setSize ( popupSize.width, 
                            getPopupHeightForRowCount ( comboBox.getMaximumRowCount ( ) ) );
                            
        if ( 0 == popupSize.width && m_nWidth > 0 )
            popupSize.width = m_nWidth;
        if ( 0 == popupSize.width )
            popupSize.width = popupSize.height;
            
        Rectangle popupBounds = computePopupBounds( 0, comboBox.getBounds ( ).height,
                                                    popupSize.width, popupSize.height );
        scroller.setMaximumSize ( popupBounds.getSize ( ) );
        scroller.setPreferredSize ( popupBounds.getSize ( ) );
        scroller.setMinimumSize ( popupBounds.getSize ( ) );
        list.invalidate ( );
        
        syncListSelection ( );
        list.ensureIndexIsVisible ( list.getSelectedIndex ( ) );

        setLightWeightPopupEnabled ( comboBox.isLightWeightPopupEnabled ( ) );

        // Off we go...            
        super.show ( invoker, x, y );
    }            
    
    //-------------------------------------------------------------------
    // NON PUBLIC METHODS
    //-------------------------------------------------------------------

    /**
     * Syncs the selection in the internal JList with the combobox.
     *   
     * @status protected
     */
    protected void syncListSelection ( )
    {
        int selectedIndex = comboBox.getSelectedIndex ( );
        if ( selectedIndex == -1 ) 
        {
            list.clearSelection ( );
        }
        else 
        {
            list.setSelectedIndex ( selectedIndex );
        }
    }
}
    