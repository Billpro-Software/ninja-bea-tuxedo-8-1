/*
 * MDObjectListCellRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */ 

 package oracle.dss.datautil.gui;
 
 import java.awt.Component;
 
 import javax.swing.DefaultListCellRenderer;
 import javax.swing.JList;
 
 import oracle.dss.metadataManager.common.MDObject;
 
 /**
  * @hidden
  * Specialized list cell renderer for rendering MDObjects based upon
  * the given display label type.
  */
 public class MDObjectListCellRenderer extends DefaultListCellRenderer {
     // Holds the current display label type.
    private String m_strDisplayLabelType;

    /** 
     * Constructor that takes the desired display label type.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     *
     * @status hidden
     */
    public MDObjectListCellRenderer(String strDisplayLabelType) {
        super();
        // Set the current display label type.
        setDisplayLabelType(strDisplayLabelType);
    }
    
    /**
     * Default constructor
     * @status hidden
     */
    public MDObjectListCellRenderer() {
        this(null);
    }
    
    /**
     * @hidden
     * Sets the desired display label type.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * 
     * @status hidden
     */
    public void setDisplayLabelType(String strDisplayLabelType) {
        m_strDisplayLabelType = strDisplayLabelType;
    }
    
    /**
     * @hidden
     * Overrides the default implementation of this method from the superclass such that the text
     * is set based upon the appropriate display label type for the MDObject.
     *
     * @status Hidden
     */
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if ( (m_strDisplayLabelType != null) && (value != null) && (value instanceof MDObject) ) {
            this.setText( ((MDObject)value).toString(m_strDisplayLabelType) );
        }
        return renderer;
    }
 }