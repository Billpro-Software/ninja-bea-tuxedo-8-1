/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */
package oracle.dss.dataSource.common;


import oracle.dss.connection.client.Connection;
import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.StatusInfo;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.util.ColumnOutOfRangeException;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.RowOutOfRangeException;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.transform.BaseProjection;

/**
 * Defines methods that shape the <code>Query</code> object at a query level.
 *
 * @status Documented
 */ 
public interface MainManager extends BaseManager
{
    /**
     * Adds one or more measures to an existing query in a <code>Query</code>
     * object. Creates a query if none exists.
     *
     * @param measures An array of the names of the measures to add to the query.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #addItems()}
     * 
     * @status Documented
     */
    public void addCubeMeasures(String[] measures) throws QueryException, MetadataManagerException;
    
    /**
     * Adds one or more items to an existing query in a <code>Query</code>
     * object. Creates a query if none exists.
     *
     * @param dataItems An array of the names of the data items to add to the query.
     * @param items An array of the names of non data items to add to the query.  This parameter is 
     *              ignored if dataItems are dimensional measures in the query.
     *
     * @throws QueryException           If there is a problem with this operation.
     *
     * @status New
     */
    public void addItems(String[] dataItems, String[] items) throws QueryException;
    
    /**
     * Adds the types in the specified data map to the DataMap for this
     * <code>Query</code> object.
     * These data map types will be included in subsequent data cursors for
     * the <code>Query</code> object.
     *
     * @param map   The <code>DataMap</code> that contains the desired types
     *              (such as formatted or unformatted data).
     *
     * @status Documented
     */
    public void applyDataMap(DataMap map);
    
    /**
     * Adds the types in the specified metadata map to the MetadataMap for
     * a specific item in this <code>Query</code> object.
     * These metadata types will be included in subsequent metadata
     * cursors for this <code>Query</code> object.
     *
     * @param item      The item to which this map should be applied.
     * @param map       The <code>MetadataMap</code> that contains the
     *                  desired types (such as short labels or long labels).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Needs change
     */
    public void applyMetadataMap(String item, MetadataMap map) throws QueryException, MetadataManagerException;

    /**
     * Adds the types in the specified metadata map to the MetadataMap of
     *  this <code>Query</code> object.
     * These metadata types will be included in subsequent metadata cursors
     * for the edges of this <code>Query</code> object.
     *
     * @param edge  The edge to which these metadata types apply.
     *              Use the <code>oracle.dss.util.DataDirector</code> constants
     *              with the suffix _EDGE to specify edges.
     * @param map   The <code>MetadataMap</code> that contains the desired
     *              types (such as short labels or long labels).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     *
     * @status Documented
     */
    public void applyMetadataMap(int edge, MetadataMap map) throws QueryException, MetadataManagerException;
        
    /**
     * Initializes a <code>Query</code> object based on one or more specified
     * data items. The <code>dimensions</code> parameter is optional when
     * initializing a cube (or multidimensional) query.
     *
     * @param dataItems   An array of data item names.
     * @param items An optional array of item layout arrays.
     *
     * @throws QueryException            If a cursor can not be created for
     *                                   this query.
     * @throws IllegalArgumentException  If one or more of the arguments is
     *                                   invalid.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void initCubeQuery(String[] dataItems, String[][] items) throws QueryException, IllegalArgumentException, MetadataManagerException;
    
    /**
     * Creates a default query based on the specified items; an optional
     * data item can also be specified.
     *
     * @param items  An array of item layout arrays.
     * @param measure     An optional data item. 
     *
     * @throws QueryException            If a cursor cannot be created for this
     *                                   query.
     * @throws IllegalArgumentException  If one or more of the arguments is
     *                                   invalid.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Needs change.
     */
    public void initQuery(String[][] items, String[] dataItems) throws QueryException, IllegalArgumentException, MetadataManagerException;
    
    /**
     * Creates a default query based on the specified items; an optional layout or set of
     * data items can also be specified.  This method is very similar to setItems with a user specified layout.
     *
     * @param layout  An optional array of item layout arrays.
     * @param items   Required array of non data item items.
     * @param dataItems     Optional data items
     *
     * @throws QueryException            If a cursor cannot be created for this
     *                                   query.
     * @throws IllegalArgumentException  If one or more of the arguments is
     *                                   invalid.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Needs change.
     */
    public void initQuery(String[][] layout, String[] dataItems, String[] items) throws QueryException, IllegalArgumentException, MetadataManagerException;
    
    /**
     * Retrieves a map that represents all data types requested by all
     * current clients of this <code>Query</code> object.
     *
     * @return A map that contains all the data types that were requested.
     *
     * @status Documented
     */
    public DataMap getDataMap();

    /**
     * Retrieves a map that represents all metadata types that were requested
     * by all current clients of this <code>Query</code> object for the
     * specified item.
     *
     * @param item The item for which metadata types have been
     *                  requested. <code>null</code> if default.
     *
     * @return A map that contains all the metadata types that were requested.
     *
     * @status Documented
     */
    public MetadataMap getMetadataMap(String item);        

    /**
     * Retrieves a map that represents all metadata types that were requested
     * by all current clients of this Query for the specified edge.
     *
     * @param edge The edge for which metadata types have been requested.
     *             To specify an edge, use one of the constants that end with
     *             _EDGE in <code>oracle.dss.util.DataDirector</code>.
     *
     * @return A map that contains all the metadata types for the specified
     *         edge for all current clients.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     *
     * @status Documented
     */
    public MetadataMap getMetadataMap(int edge);
    
    /**
     * Removes one or more measures from an existing query.  The dimensionality
     * of the query is updated as appropriate.
     *
     * @param measures An array of the names of the measures to be removed.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #removeItems()}
     * 
     * @status Documented
     */
    public void removeCubeMeasures(String[] measures) throws QueryException, MetadataManagerException;

    /**
     * Removes one or more items from an existing query.  
     *
     * @param measures An array of the names of the measures to be removed.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status new
     */
    public void removeItems(String[] items) throws QueryException;
    
    /**
     * Specifies a map that determines the contents of future data cursors
     * for this query for all clients of this <code>Query</code>.
     * (Resets cumulative <code>applyDataMap</code> operations; generally only
     * called on a clone of the <code>Query</code>.)
     *
     * @param map The map that contains the desired data types.
     *
     * @status Documented
     */
    public void setDataMap(DataMap map);

    /**
     * @hidden
     * Specifies a map that determines the allowable set of <code>DataMap</code>
     * values for this query for all clients of this <code>Query</code>.  The previous
     * (often default) map is replaced.
     *
     * @param map The map that contains the desired data types.
     *
     * @status New
     */
//    public void setSupportedDataMap(DataMap map);

    /**
     * @hidden
     * Returns the map that determines the allowable set of <code>DataMap</code>
     * values for this query for all clients of this <code>Query</code>.
     *
     * @return The current set of supported map values.
     *
     * @status New
     */
    public DataMap getSupportedDataMap();

    /**
     * Specifies a map that determines the contents of future metadata cursors
     * for all clients of this <code>Query</code> object.
     * (Resets cumulative <code>applyMetadataMap</code> operations; generally
     * only called on a clone of the <code>Query</code>.)
     *
     * @param dimension The name of the dimension for which the
     *                  <code>MetadataMap</code> is to be specified.
     * @param map       The <code>MetadataMap</code> that contains the desired
     *                  metadata types.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void setMetadataMap(String dimension, MetadataMap map) throws QueryException, MetadataManagerException;        
    
    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object.
     *
     * @param rebuild       if <code>true</code>, refreshes the structural elements
     *                      of the query such as calculations.  If false, <code>false</code>
     *                      a minimal refresh is performed.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #refresh(int)}
     * 
     * @status Needs change
     */
    public void refresh(boolean rebuild) throws QueryException, MetadataManagerException;

    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object, as with <code>refresh(true)</code>,
     * although this method also reloads saved selections.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *                                  
     * @deprecated As of 4.0.0.0, replaced by {@link #refresh(int)}
     *
     * @status New
     */
    public void refreshAll() throws QueryException, MetadataManagerException;

    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object.
     *
     * @param type      Enumerated QueryConstant:
     *                      REFRESH_ALL (reload saved selections, calculations, conditions, etc., rebuild structures
     *                                   and re-execute)
     *                      REFRESH_REBUILD (rebuild all structures and re-execute)
     *                      REFRESH_CURSORS (refresh cursors)
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status New
     */
    public void refresh(int type) throws QueryException;

    /**
     * Retrieves a list of the measure names that a
     * <code>Query</code> object is using.
     *
     * @return An array of measure names.
     *
     * @status Documented
     */
    public String[] getMeasures();

    /**
     * Checks a given MDObject (measures are the only
     * type of MDObject checked at this time) and determines
     * if the query makes use of the object in its selections
     * or measure list.
     *
     * @param object MDObject representing the object to check
     * @return <code>true</code> if the query uses the object,
     *         <code>false</code> otherwise
     *
     * @status New
     */
//    public Boolean isDependentOn(MDObject object);

    /**
     * Returns an Object indicating support or level of support for 
     * a given capability.  The capability parameter is a set of predefined constants covering capability
     * support that will change with data source type.  These constants will be defined as needed.  
     * Each capability constant will define its expected return value.
     *
     * @param capability A predefined capability constant about which to inquire.
     * @param data      Optional object to check against the capability property passed in
     *                  (for example, an inquiry may be made about a capability given a certain metadata ID).
     * 
     * @return Object defined by the capability constant representing the support level for the capability.
     *
     * @status New
     */
    public Object isSupported(int capability, Object data) throws QueryException;

    /**
     * Indicates whether any operations are pending, waiting to be sent to the enterprise tier.
     *
     * 
     * @return Object defined by the capability constant representing the support level for the capability.
     *
     * @status New
     */
    public boolean isUpdatePending();

    /**
     * Validates the entire <code>Query</code> object with the OLAP API.
     *
     * @param validationType OR-able constants that indicate the types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     *
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see ValidationObject
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType) throws MetadataManagerException, QueryException;*/

    /**
     * Validates an entire edge of a query with the OLAP API.
     *
     * @param validationType OR-able constants that indicate types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param edge           The edge to validate. To specify an edge, use one
     *                       of the constants that end with _EDGE in
     *                       <code>oracle.dss.util.DataDirector</code>.
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see ValidationObject
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, int edge) throws MetadataManagerException, QueryException;*/
    
    /**
     * Validates a <code>Selection</code> with the OLAP API.
     *
     * @param validationType OR-able constants that indicate the types of
     *                       validation to perform.
     * @param selection      Selection to validate.
     *
     * @return <code>ValidationObject</code> indicating results of validation
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see ValidationObject
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Selection selection) throws MetadataManagerException, QueryException;*/
    
    /**
     * Validates a specific <code>Step</code> with the OLAP API.
     *
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param step           The step to validate.
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see ValidationObject
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Step step) throws MetadataManagerException, QueryException;*/

    /**
     * If called after a Query fails to evaluate after a persistence
     * lookup, recover will return an object containing a code
     * and a list of names or IDs found to cause the failure.
     * recover will optionally attempt to modify and refresh the Query 
     * to avoid the failure.
     * recover will optionally return information about dimensions that
     * caused no data conditions.
     * 
     * @param fix if <code>true</code>, recover will attempt to 
     * 		modify and refresh the Query to avoid the failure
     * @param nodata if <code>true</code>, recover will 
     * 		determine which dimensions caused a no data 
     * 		condition and return this information
     * 
     * @return A <code>RecoverInformation</code> object, containing
     * 		an error code and possible metadata IDs found to have
     * 		caused a load failure.
     * 
     * @throws QueryException if an error occurs
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     * 
     * @status New
     */
    public RecoveryInfo recover(boolean fix, boolean nodata) throws QueryException, MetadataManagerException;

    /**
     * If called after a Query fails to evaluate after a persistence
     * lookup, recover will return an object containing a code
     * and a list of names or IDs found to cause the failure.
     * recover will optionally attempt to modify and refresh the Query 
     * to avoid the failure.
     * recover will optionally return information about dimensions that
     * caused no data conditions.
     * 
     * @param fix if <code>true</code>, recover will attempt to 
     * 		modify and refresh the Query to avoid the failure
     * @param nodata if <code>true</code>, recover will 
     * 		determine which dimensions caused a no data 
     * 		condition and return this information
     * @param If specified, a structure allowing an application to specify
     *        replacement metadata where a loaded query definition may be lacking
     *        or have invalid metadata IDs.
     * 
     * @return A <code>RecoverInformation</code> object, containing
     * 		an error code and possible metadata IDs found to have
     * 		caused a load failure.
     * 
     * @throws QueryException if an error occurs
     * 
     * @status New
     */
    public RecoveryInfo recover(boolean fix, boolean nodata, Object specification) throws QueryException;

    /**
     * @hidden
     * Migrate this query to unique value mode compliance.
     * 
     * @return <code>true</code> if successful
     * 
     * @throws QueryException if an error occurs
     */
     // blm - Selection code moved to dvt-olap
/*    public Boolean migrateToUnique() throws QueryException;*/

    /**
     * @hidden
     * Migrate this Selection to unique value mode compliance and return it.
     * 
     * @param sel   Selection to migrate to unique value mode
     * 
     * @return Updated Selection structure, if successful
     * 
     * @throws QueryException if an error occurs
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection migrateToUnique(Selection sel) throws QueryException;*/
    
    /**
     * @hidden
     * Migrate this Step to unique value mode compliance and return it.
     * 
     * @param step   Step to migrate to unique value mode
     * 
     * @return Updated Step structure, if successful
     * 
     * @throws QueryException if an error occurs
     */
     // blm - Selection code moved to dvt-olap
/*    public Step migrateToUnique(Step step) throws QueryException;*/
    
    
    /**
     * Return the SQL generated by the last query execution, if available.
     * 
     * @param edge  Edge for which to return last SQL, or -1 for all available SQL.
     * 
     * @return SQL for last executed query, if available.  null if not.
     * 
     * @throws QueryException if an error occurs.
     */
    //public String getQuerySQL(int edge) throws QueryException;    
    
    /**
     * Fire any pending events to all listeners.
     * 
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public void fireEvents() throws QueryException;
    
    
    /**
     * Returns an object that contains progress information (if supported) and contains 
     * an enumerated status constant, and a return value if the call has completed successfully
     * and the call returns a value.
     * 
     * @return StatusInfo containing status, progress information (if supported), and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo getStatus() throws QueryException;
    
    /**
     * Must be called to begin execution on an asynchronous query.  Returns an object that contains progress information (if supported) and contains 
     * an enumerated status constant, and a return value if the call has completed successfully
     * and the call returns a value.
     * 
     * @return StatusInfo containing status, progress information (if supported), and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo startExecution() throws QueryException;
    
    /**
     * Return the query's current data source type, as defined by MetadataManager constants
     * and by the metadata set on the query, if any.
     * 
     * @return MetadataManager data source type constant; null if query is not initialized.
     * 
     * @status New
     */
    public String getCurrentDataSourceType();    

    /**
     * Return the current MetadataManager data source 
     * 
     * @return current data source used to set up this query
     * 
     * @status New
     */
    public Connection getCurrentDataSource();

    /**
     * Specifies the full set of CalcDefinitions to be used by this Query.  If definitions
     * involves a change to the Query's CalcDefinitions, the Query will refresh.
     *
     * @param definitions all non item-based calculations to be used by the Query
     *
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public void setCalcDefinitions(Object[] definitions) throws QueryException;

    /**
     * Returns the full set of CalcDefinitions used by this Query. 
     *
     * @return all non item-based calculations used by the Query
     *
     * @status New
     */
    public Object[] getCalcDefinitions();

    /**
     * Specifies the set of column sorts on a table-style view.
     * Any settings made through this API are considered the
     * entire set of sort criteria: the given sort criteria 
     * replace previously set sort criteria.
     *
     * @param sortInfo An array of <code>ColumnSortWrapper</code> objects. Each
     *                 <code>ColumnSortWrapper</code> object may specify a
     *                 sort criterion by which to sort its corresponding
     *                 item.
     *
     * @return <code>true</code> if the sort operation is successful,
     *         <code>false</code> if the sort operation is not successful.
     *
     * @throws QueryException if an error occurs
     *
     * @status new
     */
    public void setColumnSorts(ColumnSortWrapper[] sortWrapper) throws QueryException;


    /**
     * Retrieves the set of column sorts on a table-style view.
     *
     * @return An array of <code>ColumnSortWrapper</code> objects.
     *
     * @status new
     */
    public ColumnSortWrapper[] getColumnSorts();
    
    /**
     * Specifies the set of item sorts on a crosstab-style view.
     * Any settings made through this API are considered the
     * entire set of sort criteria: the given sort criteria 
     * replace previously set sort criteria.
     *
     * @param sortInfo An array of <code>ItemSortWrapper</code> objects. Each
     *                 <code>ItemSortWrapper</code> object may specify a
     *                 sort criterion by which to sort its corresponding
     *                 item.
     *
     * @return <code>true</code> if the sort operation is successful,
     *         <code>false</code> if the sort operation is not successful.
     *
     * @throws QueryException if an error occurs
     *
     * @status new
     */
//    public void setItemSorts(ItemSortWrapper[] sortWrapper) throws QueryException;


    /**
     * Retrieves the set of item sorts on a crosstab-style view.
     *
     * @return An array of <code>ItemSortWrapper</code> objects.
     *
     * @status new
     */
    //public ItemSortWrapper[] getItemSorts();
    
    /**
     * Sets one or more preferred page items to be fetched before a DataAccess/DataDirector
     * is generated to improve fetching performance.  May not be implemented.
     *
     * @param pages pages to pre-fetch.
     *
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public void setCurrentPages(QDR[] pages) throws QueryException;

    /**
     * Returns the list of preferred page items set, if any.
     * 
     * @return list of preferred page items set, <code>null</code> if none.
     * 
     * @status New
     */
    public QDR[] getCurrentPages();
    
    /**
     * Sets items on the query.  Also see <code>addItems</code> and
     * <code>removeItems</code>.  The items' dimensions will be placed in a default layout, and/or
     * dimensions will be chosen based on the data items and placed in a default layout.
     *
     * @param dataItems a list of aggregable items or dimensional measures.
     * @param items the items to set (optional and ignored if the dataItems are dimensional).
     *
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public void setItems(String[] dataItems, String[] items) throws QueryException;

    /**
     * Returns the current list of items set on the Query, if any.
     * 
     * @return list of items set on the Query, <code>null</code> if none.
     * 
     * @status New
     */
    public String[] getDataItems();    
 

    /**
     * Returns the current list of items set on the Query, if any.  This does not include data Items.
     * 
     * @return list of items set on the Query, <code>null</code> if none.
     * 
     * @status New
     */
    public String[] getItems();        
    
    /**
     * Return an implementation-specific object representing the current "query"
     * 
     * @return implementation specific query object, or null if nothing has been defined
     * 
     * @status New
     */
    public Object getQueryObject();    
    
    /**
     * Return the current data set projection from this query, if any
     * 
     * @param layerMetadataType The type of metadata object ID to use in the returned projection.
     * 
     * @return BaseProjection object, if available and relevant
     *  
     * @throws QueryException thrown if an error occurs.
     */
    public BaseProjection getProjection(String layerMetadataType) throws QueryException;
}
