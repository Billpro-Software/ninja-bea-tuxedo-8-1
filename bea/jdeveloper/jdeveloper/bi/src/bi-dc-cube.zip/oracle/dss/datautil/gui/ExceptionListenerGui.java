/*
 * ExceptionListenerGui.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import javax.swing.JOptionPane;

import oracle.dss.datautil.ExceptionListener;

import oracle.dss.datautil.gui.ExceptionListenerDialogCallback;

/**
 * @hidden
 *
 * Interface for GUI (graphic user interface) based exception listeners.
 *
 * Application developers should implement this interface to handle exceptions
 * from beans that need to display messages within standardized dialog boxes.
 *
 * Beans that call the exception listener implement the
 * <code>ExceptionListenerDialogCallback</code> interface.
 * <P>
 * By default, the beans register a default exception listener that implements
 * this interface.
 *
 * To replace the default exception listener with your implementation of this
 * interface, you call the <code>addExceptionListenerDialog</code> method of the bean.
 *
 * @see ExceptionListenerDialogCallback
 *
 * @status hidden
 */

public interface ExceptionListenerGui extends ExceptionListener, ExceptionListenerDialogCallback {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Start of RESPONSE literals

  //
  // Return values patterned after JOptionPane.
  //

  /**
   * Return value from class method if YES is chosen.
   *
   * @status hidden
   */

  public static final int YES_OPTION = 0;

  /**
   *
   * Return value from class method if NO is chosen.
   *
   * @status hidden
   */

  public static final int NO_OPTION = 1;

  /**
   *
   * Return value from class method if CANCEL is chosen.
   *
   * @status hidden
   */
  public static final int CANCEL_OPTION = 2;

  /**
   *
   * Return value from class method if user closes window without selecting
   * anything, more than likely this should be treated as either a
   * CANCEL_OPTION or NO_OPTION.
   *
   * @status hidden
   */
  public static final int CLOSED_OPTION = 3;

  /**
   *
   * Return value form class method if OK is chosen.
   *
   * @status hidden
   */
  public static final int OK_OPTION = 4;

  /**
   *
   * Return value from class method if no dialog has been displayed.
   *
   * @status hidden
   */
  public static final int NONE_OPTION = 5;

  // End of RESPONSE literals
}

