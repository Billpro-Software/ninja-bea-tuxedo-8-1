/*
 * HyperLinkField.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.text.NumberFormat;
import java.text.ParseException;

import java.util.Locale;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.event.EventListenerList;

import oracle.bali.ewt.dateEditor.DateEditor;
import oracle.bali.ewt.text.NumberTextField;

import oracle.dss.datautil.gui.ResourceCache;

/**
 * @hidden
 * Label with the hyperlink
 */
public class HyperLinkField extends JPanel implements HyperLinkControl
{
    // The popup menu used for holding the text field
    protected JPopupMenu m_editMenu = null;

    // List of the focus listeners to which the notification is sent
    // when the field has lost focus, and the Escape was not pressed
    private EventListenerList m_focusListenerList = new EventListenerList();

    // The properties determining whether the label and the popup are enabled
    // If this property is true, label looks like a hyperlink
    // the mouse pointer over the label becomes a hand pointer, and the
    // popup is enabled
    private boolean m_blnIsEnabled = true;
    
    // The label used to display the text as a hyperlink
    private HyperLinkLabel m_hyperLabel;
    // The label used to display any post-field text
    private JLabel m_percentLbl;
    // The editor used for setting the new text of the label
    private Component m_editor;
    // The check box used for percent sign
    private JCheckBox m_percentChkBox;
    
    // Flag keeping track of whether the Escape key was pressed
    private boolean m_blnEscaped = false;
    // Flag keeping track of the mode
    private boolean m_blnIsHyperLink = true;
    // Flag keeping track whether the percent controls are displayed    
    private boolean m_blnPercentVisible = false;
    // NumberFormat used for formatting the number editor
    private NumberFormat m_numberFormat;
    
    // I18N strings
    private static String m_strPercent = "";

    private ResourceCache m_resourceCache = new ResourceCache("oracle.dss.datautil.gui.hierLevel.resource.HierLevelBundle");
    private boolean m_bSuperCalled = false;

    /**
    * "NEW"
    * Constructor which creates a hyper-link label which pops up a menu when clicked.
    * The menu contains a text field which is used to edit the text in the label.
    * @param txtField - text field to be displayed in the popup menu
    */
    public HyperLinkField(JTextField txtField)
    {
        super();
        m_bSuperCalled = true;
        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        setBorder(null);
        setEnabled(true);

        // Instantiate the NumberFormat.
        m_numberFormat = NumberFormat.getInstance();
        m_numberFormat.setGroupingUsed(false);
        m_numberFormat.setMaximumFractionDigits(Integer.MAX_VALUE);

        // Initialize the HyperLinkLabel
        m_hyperLabel = new HyperLinkLabel()
        {
            // Displays the edit menu and selects the currently displayed item
            protected void showEditMenu()
            {
                super.showEditMenu();
                // Reset the flag keeping track of whether 
                // the Escape key has been pressed
                m_blnEscaped = false;
                // Focus the text field and select the data in it
                m_editor.requestFocus();
                if (m_editor instanceof JTextField) {
                  ((JTextField)m_editor).selectAll();
                }
            }   
        };
        add(m_hyperLabel);
        
        // Initialize the label used for percent in hyperlink mode       
        m_percentLbl = new JLabel();

        // Create the percent checkbox
        m_percentChkBox = new JCheckBox();
        // Notify the listeners when the state changes
        m_percentChkBox.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent e)
            {
                // Update the percent label
                m_percentLbl.setText(m_percentChkBox.isSelected()? m_strPercent : "");
                fireFocusLostEvent();
            }
        });
        
        // Set the text field
        setEditor(txtField);
    }

    /**
    * "NEW"
    * Constructor which creates a hyper-link label which pops up a menu when clicked.
    * The menu contains a text field which is used to edit the text in the label.
    */
    public HyperLinkField()
    {
        this(new JTextField(5));
    }

    /** "NEW"
    * Sets the boolean property determining if the hyperlink field is enabled.
    * If yes, the label displays its text as blue and underlined, the popup menu
    * is displayed when the mouse is pressed on the label, and the mouse pointer changes
    * to a hand when the mouse is over the label.
    * Otherwise, the label displays its text as a regular JLabel, and
    * the popup menu does not display.
    *
    * @param isEnabled the boolean value of the enabled property
    */
    public void setEnabled(boolean isEnabled)
    {
        if (m_blnIsEnabled != isEnabled)
        {
            m_blnIsEnabled = isEnabled;
            
            // Update the enabling of the HyperLinkLabel and the text field
            m_hyperLabel.setEnabled(isEnabled);
            m_editor.setEnabled(isEnabled);
            m_percentChkBox.setEnabled(isEnabled);
        }
    }
    
    /**
    * "NEW"
    * Overriding the getPreferredSize() in parent class 
    * to return the preferred size of either the HyperLinkLabel, 
    * or the text field depending on the hyperlink mode.
    *
    * @return Dimension representing the preferred size
    */
    public Dimension getPreferredSize()
    {
        Dimension prefSize = null;
        
        // If the hyperlink mode is on, 
        // return the preferred size of the HyperLinkLabel
        if (isHyperLink())
        {
            prefSize = super.getPreferredSize();
        }
        else
        // If the hyperlink mode is off, 
        // return the preferred size of the text field
        {
            prefSize = m_editor.getPreferredSize();
        }
        
        return (prefSize);
    }


    /**
    * "NEW"
    * Sets the display mode for this control.
    * @param isHyperLink - boolean flag which if true will set 
    * the display of the combo box to the hyperlink mode
    */
    public void setHyperLink(boolean isHyperLink)
    {
        if (m_blnIsHyperLink != isHyperLink)
        {
            // Set the internal mode
            m_blnIsHyperLink = isHyperLink;

            this.removeAll();
            // If the hyperlink mode is on
            // add the hyperlink label to the panel
            if (isHyperLink)
            {
                this.add(m_hyperLabel);
                if (isPercentVisible())
                {
                    this.add(m_percentLbl);
                }
                m_hyperLabel.setContents(m_editor);
                m_hyperLabel.setText(getFieldText());
            }
            else
            // If the hyperlink mode is off
            // add the text field to the panel
            {
                this.add(m_editor);
                if (isPercentVisible())
                {
                    // Add the check box
                    this.add(m_percentChkBox);
                }
            }
            this.revalidate();  
        }
    }
          
    /**
    * "NEW"
    * Sets the display mode for this control.
    * @return true if the combo box is in the hyperlink mode
    */   
    public boolean isHyperLink()
    {
         return (m_blnIsHyperLink);   
    }   
    
    /**
     * Specifies whether this control shpould display a number as a percent
     *
     * @param true if the number is percentage, false otherwise
     *
     * @status hidden
     */
    public void setPercentVisible(boolean showPercent)
    {
        if (isPercentVisible() != showPercent)
        {
            m_blnPercentVisible = showPercent;
            
            // If the hyperlink mode is on, add/remove the percent label
            if (m_blnIsHyperLink)
            {
                if (showPercent)
                {
                    add(m_percentLbl);
                }
                else
                {
                    remove(m_percentLbl);    
                }
            }
            else
            {    
                if (showPercent)
                {
                    add(m_percentChkBox);
                }
                else
                {
                    remove(m_percentChkBox);    
                } 
            }

            this.revalidate();  
        }     
    }
    
    /**
     * Indicates whether this controls displays a number as a percent
     *
     * @return true if the number is percentage, false otherwise
     *
     * @status hidden
     */
    public boolean isPercentVisible()
    {
        return m_blnPercentVisible;
    }
    
    /**
     * Sets the state of the percent label/checkbox
     *
     * @param true if the checkbox should be checked and
     *     the label in the hyperlink mode should display % sign, false otherwise
     * @param rtl the flag indicating orientation of the percent label -
     *            <code>true</code>, if the orientation is right-to-left,
     *            <code>flase</code> otherwise.
     *
     * @status hidden
     */
    public void setPercent(boolean isPercent, boolean rtl)
    {
        // Fix for bug#2447379: If percent is visible and given rtl flag is
        // true, reorder the percent label with respect to the editor.
        if (rtl && isPercentVisible()) {
          reorderPercentLabel();
        }
        
        // In hyperlink mode, update the percent label
        m_percentLbl.setText(isPercent? m_strPercent : "");
        // Update the state of the checkbox
        m_percentChkBox.setSelected(isPercent); 
        revalidate();
    }
    
    // Fix for bug#2447379: Added the following private method to reorder the
    // percent label with respect to the editor.
    /**
     * Rearranges the percent label with respect to the editor.
     */
    private void reorderPercentLabel() {
      if (m_blnIsHyperLink) {
        remove(m_hyperLabel);
        add(m_percentLbl);
        add(m_hyperLabel);
        m_hyperLabel.setContents(m_editor);
        m_hyperLabel.setText(getFieldText());
      }
      else {    
        remove(m_editor);
        add(m_percentChkBox);
        add(m_editor);
      }
      this.revalidate();
    }
    
    /**
     * Indicates whether the percent is checked
     * @return true if the number is percentage, false otherwise
     *
     * @status hidden
     */
    public boolean isPercent()
    {
        return (m_percentChkBox.isSelected());    
    }

    
    /**
    * "NEW"
    * Sets the text on the HyperLinkLabel and text field.
    *
    * @param newText - String   
    */
    public void setText(String newText)
    {
        // Set the text on the field
        if (m_editor instanceof JTextField) {
            ((JTextField)m_editor).setText(newText);
        }
        else if (m_editor instanceof DateEditor) {
            try {
                ((DateEditor)m_editor).setDateString(newText);
            }
            catch (ParseException e) {
                e.printStackTrace();
            }
        }
        // Set the text on the hyperlink label
        m_hyperLabel.setText(newText);
    }
    
    /**
    * "NEW"
    * Gets the text from the text field.
    *
    * @return - the text in the text field   
    */
    public String getText()
    {
        return (getFieldText());
    }

    // Returns the text from the text field
    private String getFieldText() {
        String text = null;
        
        // If the field is a NumberTextField, display the number correctly
        if (m_editor != null) {
            if (m_editor instanceof NumberTextField) {
                Number num = ((NumberTextField)m_editor).getNumber();
                if (num != null) {
                    text = m_numberFormat.format(num.doubleValue()); 
                }
            }
            // Get the text from the field
            else if (m_editor instanceof JTextField) {
                text = ((JTextField)m_editor).getText();
            }
            else if (m_editor instanceof DateEditor) {
                text = ((DateEditor)m_editor).getDateString();
            }
        }

        return (text);        
    }

    /**
    * Gets the component used for editing this hyperlink.
    *
    * @status New
    * @return a Component used for editing the text
    */
    public Component getEditor() {
        return (m_editor);
    }
    
    /**
    * Sets the component used for editing this hyperlink.
    *
    * @status New
    * @param newComponent - Component used for editing the text
    */
    public void setEditor(Component newEditor) {
        m_editor = newEditor;
        m_editor.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                if (!m_blnEscaped) {
                    if (validateField()) {
                        // Set the text on the label to display what is in the field
                        m_hyperLabel.setText(getFieldText());
                        fireFocusLostEvent();
                    }
                }            
            }
        });
        m_editor.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (isHyperLink()) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        if (validateField()) {
                            m_hyperLabel.hideEditMenu();
                        }
                        e.consume();
                    }
                    else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                        // Hide the edit menu and cancel the changes
                        m_blnEscaped = true;
                        // Reset the text in the text field
                        if (m_editor instanceof JTextField) {
                            ((JTextField)m_editor).setText(m_hyperLabel.getText());
                        }
                        else if (m_editor instanceof DateEditor) {
                            try {
                                ((DateEditor)m_editor).setDateString(m_hyperLabel.getText());
                            }
                            catch (ParseException e2) {
                                e2.printStackTrace();
                            }
                        }
                        m_hyperLabel.hideEditMenu();
                        e.consume();
                    }
                }
            }
        });
        
        // If the hyperlink mode is on, add the field 
        // to the HyperLinkLabel's popup menu
        if (isHyperLink()) {
            m_hyperLabel.setContents(m_editor);
            m_hyperLabel.setText(getFieldText());
        }
        else { // Add the field directly to this panel
            this.removeAll();
            this.add(m_editor);
            this.revalidate();
        }
    }
    
    /**
    * "NEW"
    * Add classes that want to be notified when the field focus has changed
    */
    public void addFieldFocusListener(FocusListener listener)
    {
        m_focusListenerList.add(FocusListener.class,listener);
    }

    /**
     * "NEW"
     * Remove classes that don't want to be notified when a field focus has changed     
     */
    public void removeFieldFocusListener(FocusListener listener)
    {
        m_focusListenerList.remove(FocusListener.class,listener);
    }

    // Dispatch a focus lost FocusEvent from the text field to all the listeners.
    private void fireFocusLostEvent()
    {
        // Get the listener class type/ listener class instance pairs.
        Object[] listeners = m_focusListenerList.getListenerList();

        FocusEvent newEvent = new FocusEvent(m_editor, FocusEvent.FOCUS_LOST);
        // We step through the pairs from last to first. The first in
        // the pair is the class type, then is the class instance.
        // This is why we step through the list two at a time.
        for (int i=listeners.length-2; i>=0; i-=2)
        {
            // Make sure this listener is the right type.
            if (listeners[i] == FocusListener.class)
            {
                FocusListener fl = (FocusListener)listeners[i+1];
                fl.focusLost(newEvent);
            }
        }
    }

    public void addNotify()
    {
      super.addNotify();
      updateResources();
    }

    public void setLocale(Locale locale)
    {
      super.setLocale(locale);
      if (!m_bSuperCalled)
        return;
      m_resourceCache.setLocale(locale);
      updateResources();
    }

    private void updateResources()
    {
      m_strPercent = m_resourceCache.getIntlString("strPercent");
      m_percentLbl.setText(isPercent() ? m_strPercent : "");
      m_percentChkBox.setText(m_strPercent);
    }
    
    /**
     * Method used to validate the contents of the edit menu. If
     * the contents are not valid (i.e. blank, or out of range),
     * the edit menu will not be hidden.
     *
     * @status hidden
     * @hidden
     */
    protected boolean validateField() {
        return true;
    }
}