/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui.component.models;

import java.util.ArrayList;

import oracle.dss.util.gui.component.tree.ComponentTreeNode;

public interface SelectModel {

    public ComponentTreeNode getTreeRoot();
    
    public ArrayList getSelectFilters();
    
    public boolean isMultiSelect();
    
    
}
