/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.metadataUtil;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;
import java.util.Hashtable;
import java.text.MessageFormat;

import oracle.dss.metadataUtil.resource.MetadataUtilBundle;

/**
 * Describes changes that occur in the Connection and MetadataManager beans.
 * Subclasses provide more specific information.
 *
 * @status Reviewed
 */
public class BaseEvent extends java.util.EventObject {

  private boolean consumed;
  private boolean consumable;
  private String reason;
  private static Locale m_locale = null;
  private static Hashtable m_resTable = new Hashtable(5);

  /**
   * Constructor.
   *
   * @param source   The source of this event.
   * @param isConsumable <code>true</code> if this event can be consumed,
   *                     <code>false</code> if it cannot be consumed.
   *
   * @status Reviewed
  */
  public BaseEvent( Object source, boolean isConsumable ) {
    super( source );
    consumed = false;
    consumable = isConsumable;
    reason = null;
  }

  /**
   * Consumes this event.
   *
   * @throws     EventException If this event is not consumable.
   *
   * @status Reviewed
   */
  public void consume() throws EventException {
    if( consumable )
      consumed = true;
    else
      throw new EventException(getResourceString(MetadataUtilBundle.EXC_INCONSUMABLE_EVENT));
  }

  /**
   * Indicates whether this even has been consumed.
   *
   * @return      <code>true</code> if event has been consumed,
   *              <code>false</code> if it has not.
   *
   * @status Reviewed
   */
  public boolean isConsumed() {
    return consumed;
  }

  /**
   * Indicates whether this event can be consumed.
   *
   * @return      <code>true</code> if this event is consumable,
   *              <code>false</code> if it is not.
   *
   * @status Reviewed
   */
  public boolean isConsumable() {
    return consumable;
  }

  /**
   * @hidden
   * Specifies information about the generation of this event.
   * The object that instantiates this event can call this method to provide
   * information.
   *
   * @param reasonStr Information about this event.
   *
   * @status hidden
   */
  public void setReason( String reasonStr ) {
    reason = reasonStr;
  }

  /**
   * @hidden
   * Retrieves information about this event.
   *
   * @return The information that the source has provided, or <code>null</code>
   *         if no reason has been set.
   *
   * @see #setReason
   *
   * @status hidden
   */
  public String getReason() {
    return reason;
  }

  /**
   * @hidden
   * Load metadataUtil resources.
   *
   * @throws     MissingResourceException.
   *
   * @status private
   */
  private static ResourceBundle loadResourceBundle() {
    try {
      if(m_locale == null)
        m_locale = Locale.getDefault();

      String _key = m_locale.getLanguage() + m_locale.getCountry();
      ResourceBundle _res = (ResourceBundle)m_resTable.get(_key);
      if(_res == null)
      {
        _res = ResourceBundle.getBundle("oracle.dss.metadataUtil.resource.MetadataUtilBundle", m_locale);
        m_resTable.put(_key, _res);
      }

      return _res;
    }
    catch (MissingResourceException e) {
      e.printStackTrace();
    }
    return null;
  }

  public void setLocale(Locale locale) {
    m_locale = locale;
  }

  /**
   * @hidden
   * Local resource accessor to simplify other code
   *
   * @return String which represents the value associated with the specified key.
   *
   * @status private
   */
  private static String getResourceString(String key) {
    ResourceBundle _res = loadResourceBundle();
    if(_res != null)
      return MessageFormat.format("{0}-{1} {2}", new Object[]{"DVT", key, _res.getString(key)});
    else
      return null;
  }
}