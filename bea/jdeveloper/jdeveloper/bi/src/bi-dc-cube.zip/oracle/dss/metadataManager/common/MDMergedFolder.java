/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Properties;
import java.util.Vector;

import javax.naming.CompoundName;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.NameParser;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import oracle.dss.bicontext.ImpactReport;
import oracle.dss.bicontext.Acl;
import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BIComparator;
import oracle.dss.bicontext.BIInvalidNameException;
import oracle.dss.bicontext.BIOperationNotSupportedException;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.BISortUtils;
import oracle.dss.bicontext.Privilege;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * Represents a merged folder
 * @hidden
 */
public class MDMergedFolder implements BIContext
{
    private String m_name;
    private Vector m_folders;
    private Locale m_locale;
    private ErrorHandler m_handler;

    public MDMergedFolder(String name, Vector folders, Locale locale, ErrorHandler handler)
    {
        m_name = name;
        m_folders = folders;
        m_locale = locale;
        m_handler = handler;
    }

public ImpactReport rebindImpact(Name name, Object obj, Attributes attrs, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(Name name, Object obj, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(String name, Object obj, Attributes attrs, boolean dryRun)
    {
        return null;
    }
    public ImpactReport rebindImpact(String name, Object obj, boolean dryRun)
    {
        return null;
    }
    public ImpactReport unbindImpact(Name name, boolean dryRun)
    {
        return null;
    }
    public ImpactReport unbindImpact(String name, boolean dryRun)
    {
        return null;
    }
    public void endConsistentRead()
    {
        
    }
    public void startConsistentRead()
    {
        
    }
    
    public void close()
    {
        m_name = null;
        m_folders.removeAllElements();
        m_folders = null;
        m_locale = null;
        m_handler = null;
    }
    
    public NamingEnumeration search(String name, Attributes attrs) throws NamingException
    {
        return search(name, attrs, (String[])null);
    }

    public NamingEnumeration search(Name name, Attributes attrs) throws NamingException
    {
        return search(name, attrs, (String[])null);
    }

    public NamingEnumeration search(Name name, Attributes attrs, String[] attributesToReturn) throws NamingException
    {
        BISearchControls _controls = new BISearchControls();
        _controls.setSearchScope(BISearchControls.ONELEVEL_SCOPE);
        _controls.setReturningAttributes(attributesToReturn);
        return search(name, attrs, _controls);
    }

    public NamingEnumeration search(String name, Attributes attrs, String[] attributesToReturn) throws NamingException
    {
        BISearchControls _controls = new BISearchControls();
        _controls.setSearchScope(BISearchControls.ONELEVEL_SCOPE);
        _controls.setReturningAttributes(attributesToReturn);
        return search(name, attrs, _controls);
    }

    public NamingEnumeration search(Name name, Attributes attrs, SearchControls controls) throws NamingException
    {
        checkNullName(name);
        return search(name.toString(), attrs, controls);
    }

    public NamingEnumeration search(String name, Attributes attrs, SearchControls controls) throws NamingException
    {
        checkNullName(name);
        Vector _finalResults = search(m_folders, name, attrs, controls, m_locale, m_handler);

        // if sorting option is on, sort search results before returning.
        if (controls instanceof BISearchControls)
        {
            BISearchControls sc = (BISearchControls)controls;
            if (sc.isSortingOn())
            {
                BIComparator comp = sc.getSortingComparator();
                if (comp != null)
                {
                    if (comp.getErrorHandler() == null)
                        comp.setErrorHandler(m_handler);
                    // make sure that sorting is performed in the correct Locale
                    comp.setLocale(getLocale());
                }
                BISortUtils _sortUtils = new BISortUtils();
                _finalResults = _sortUtils.sortSearchResults(_finalResults, comp);
            }
        }

        return new NamingEnumerationImpl(_finalResults);
    }

    // returns multi-valued attributes for merged folders
    static Attributes getAttributes(Vector searchResults)
    {
        BasicAttributes _results = new BasicAttributes();
        for (int i=0; i<searchResults.size(); i++)
        {
            try
            {
                SearchResult _sr = (SearchResult)searchResults.elementAt(i);
                Attributes _attrs = _sr.getAttributes();
                if (_attrs != null)
                {
                    Enumeration _enum = _attrs.getIDs();
                    while (_enum.hasMoreElements())
                    {
                        String _key = (String)_enum.nextElement();
                        Object _val = _attrs.get(_key).get();
                        if (_results.get(_key) != null)
                            _results.get(_key).add(_val);
                        else
                            _results.put(_key, _val);
                    }
                }
            }
            catch (NamingException ne) {}
        }
        return _results;
    }

    // used by MDFolder search method also
    // this is the main method that takes care of all the merging/renaming etc.
    static Vector search(Vector folders, String name, Attributes attrs, SearchControls controls, Locale locale, ErrorHandler handler)
    {
        Hashtable _entries = new Hashtable(50, 50);
        // list of duplicate objects with key = name, value = # of duplicates
        Hashtable _objects = new Hashtable(10, 10);
        for (int i=0; i<folders.size(); i++)
        {
            try
            {
                int _scope = controls.getSearchScope();
                MDFolder _parent = (MDFolder)folders.elementAt(i);

                // if the setExcludeSubfolders flag is set on
                if (_parent.getStrPropertyValue("excludeSubfolders") != null && _parent.getStrPropertyValue("excludeSubfolders").equals("true"))
                {
                    controls.setSearchScope(BISearchControls.ONELEVEL_SCOPE);
                    _parent.removeProperty("excludeSubfolders");
                }

                NamingEnumeration _results = _parent.search(name, attrs, controls);

                // reset the scope back to normal
                controls.setSearchScope(_scope);
                while (_results.hasMoreElements())
                {
                    BISearchResult _result = (BISearchResult)_results.next();
                    String _name = getAtomicName(_result.getName());
                    String _type = _result.getObjectType();
                    Object _obj = _entries.get(_name);
                    if (_obj == null)
                        _entries.put(_name, _result);
                    else if (_obj instanceof Vector)
                    {
                        // add to the list of existing folders with the same name
                        if (_type.equals(MM.FOLDER))
                            ((Vector)_obj).addElement(_result);
                        else
                        {
                            // add the object with a different name
                            int _tag = 2;
                            if (_objects.get(_name) != null)
                            {
                                _tag = (((Integer)_objects.get(_name)).intValue());
                                _tag++;
                            }

                            _objects.put(_name, new Integer(_tag));
                            String _displayName = _name+" ("+_tag+")";
                            while(true)
                            {
                                if (_entries.get(_displayName) != null)
                                {
                                    _tag++;
                                    _displayName = _name+" ("+_tag+")";
                                }
                                else
                                    break;
                            }
                            _result.setLabel(_displayName);
                            _entries.put(_displayName, _result);
                        }
                    }
                    else if (_obj instanceof SearchResult)
                    {
                        if (_type.equals(MM.FOLDER))
                        {
                            // check existing object
                            if (((BISearchResult)_obj).getObjectType().equals(MM.FOLDER))
                            {
                                // existing folder with the same name
                                // merge them
                                Vector _searchResults = new Vector(5, 5);
                                _searchResults.addElement(_obj);
                                _searchResults.addElement(_result);
                                _entries.put(_name, _searchResults);
                            }
                            else
                            {
                                // existing object with the same name as this folder
                                // rename the existing object
                                int _tag = 2;
                                if (_objects.get(_name) != null)
                                {
                                    _tag = (((Integer)_objects.get(_name)).intValue());
                                    _tag++;
                                }
                                _objects.put(_name, new Integer(_tag));
                                String _displayName = _name+" ("+_tag+")";
                                while(true)
                                {
                                    if (_entries.get(_displayName) != null)
                                    {
                                        _tag++;
                                        _displayName = _name+" ("+_tag+")";
                                    }
                                    else
                                        break;
                                }
                                ((BISearchResult)_obj).setLabel(_displayName);
                                _entries.put(_displayName, _obj);

                                // put the new folder in place
                                _entries.put(_name, _result);
                            }
                        }
                        else
                        {
                            // just a new object to be added....
                            int _tag = 2;
                            if (_objects.get(_name) != null)
                            {
                                _tag = (((Integer)_objects.get(_name)).intValue());
                                _tag++;
                            }
                            _objects.put(_name, new Integer(_tag));
                            String _displayName = _name+" ("+_tag+")";
                            while(true)
                            {
                                if (_entries.get(_displayName) != null)
                                {
                                    _tag++;
                                    _displayName = _name+" ("+_tag+")";
                                }
                                else
                                    break;
                            }
                            _result.setLabel(_displayName);
                            _entries.put(_displayName, _result);
                        }
                    }
                }
            }
            catch (NamingException ne)
            {
                handler.error(ne, MDMergedFolder.class.getName(), "search");
            }
        }

        Vector _finalResults = new Vector(_entries.size());

        // entries contains all SearchResult(s)
        Enumeration _enum = _entries.elements();
        while (_enum.hasMoreElements())
        {
            Object _obj = _enum.nextElement();
            if (_obj instanceof BISearchResult)
            {
                BISearchResult _sr = (BISearchResult)_obj;
                _finalResults.addElement(_obj);
                String[] _retAttrs = controls.getReturningAttributes();
                if (_retAttrs == null)
                    _sr.getAttributes().put(MDU.OBJECT_LABEL, _sr.getLabel());
                else
                {
                    for (int j=0; j<_retAttrs.length; j++)
                    {
                        if (_retAttrs[j].equals(MDU.OBJECT_LABEL))
                        {
                            _sr.getAttributes().put(MDU.OBJECT_LABEL, _sr.getLabel());
                            break;
                        }
                    }
                }
            }
            else if (_obj instanceof Vector)
            {
                Vector _list = (Vector)_obj;
                Vector _folders = new Vector(_list.size());
                String _name = null;
                for (int j=0; j<_list.size(); j++)
                {
                    BISearchResult _sr = (BISearchResult)_list.elementAt(j);
                    _name = _sr.getName();

                    // safety check, should be folder
                    if (_sr.getObjectType().equals(MM.FOLDER))
                        _folders.addElement(_sr.getObject());
                }
                // attributes of a merged folder
                Attributes _attrs = getAttributes(_list);

                MDMergedFolder _mergedFolder = new MDMergedFolder(_name, _folders, locale, handler);
                MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(_name, _mergedFolder, _attrs, true, MM.FOLDER, null);
                _msr.setLabel(_name);
                _finalResults.addElement(_msr);
            }
        }

        return _finalResults;
    }

    static String getAtomicName(String name)
    {
        Properties s_env = new Properties();
        s_env.put("jndi.syntax.direction", "left_to_right");
        s_env.put("jndi.syntax.separator", "/");

        try
        {
            Name _name = new CompoundName(name, s_env);
            return _name.get(_name.size()-1);
        }
        catch (NamingException ne){}
        return name;
    }

    public Locale getLocale()
    {
        return m_locale;
    }

    public void setLocale(Locale locale)
    {
        if (locale != null)
            m_locale = locale;
    }

    public String getNameInNamespace()
    {
        return null;
    }

    // checks whether name is null
    private void checkNullName(Object name) throws NamingException
    {
        if (name == null)
          throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{"NULL"}, getLocale(), null);
    }

    public boolean getFeature(String feature)
    {
        return false;    
    }
    
    // did not implement these methods at the moment
    public void bind(String name, Object obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void bind(Name name, Object obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void bind(String name, Object obj, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void bind(String name, Object obj, Attributes attrs, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void bind(Name name, Object obj, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void bind(Name name, Object obj, Attributes attrs, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Name composeName(Name name, Name prefix) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public String composeName(String name, String prefix) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Context createSubcontext(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Context createSubcontext(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public DirContext createSubcontext(String name, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public DirContext createSubcontext(Name name, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void copy(String name, DirContext ctx, String target, int mode) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void copy(Name name, DirContext ctx, Name target, int mode) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void destroySubcontext(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void destroySubcontext(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Acl getAcl() throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean addEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean addEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean removeEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean removeEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean setEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public boolean setEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Vector entries(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Vector entries(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Vector getAllUsers() throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Privilege getPrivilege(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Privilege getPrivilege(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Attributes getAttributes(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Attributes getAttributes(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Attributes getAttributes(String name, String[] attrsToReturn) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Attributes getAttributes(Name name, String[] attrsToReturn) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public NameParser getNameParser(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NameParser getNameParser(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public DirContext getSchema(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public DirContext getSchema(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public DirContext getSchemaClassDefinition(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public DirContext getSchemaClassDefinition(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public NamingEnumeration list(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NamingEnumeration list(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public NamingEnumeration listBindings(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NamingEnumeration listBindings(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Object lookup(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookup(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookup(String name, Persistable obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookup(Name name, Persistable obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookup(String name, Persistable obj, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookup(Name name, Persistable obj, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Object lookupLink(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object lookupLink(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void move(String name, DirContext ctx) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void move(Name name, DirContext ctx) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void rebind(String name, Object obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rebind(Name name, Object obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rebind(String name, Object obj, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rebind(String name, Object obj, Attributes attrs, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rebind(Name name, Object obj, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rebind(Name name, Object obj, Attributes attrs, Hashtable env) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void refresh() throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public Object addToEnvironment(String id, Object obj) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Object removeFromEnvironment(String id) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public Hashtable getEnvironment() throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void rename(String oldName, String newName) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void rename(Name oldName, Name newName) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void modifyAttributes(String name, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void modifyAttributes(Name name, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void modifyAttributes(String name, int op, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void modifyAttributes(Name name, int op, Attributes attrs) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void modifyAttributes(String name, ModificationItem[] items) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void modifyAttributes(Name name, ModificationItem[] items) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public NamingEnumeration search(String name, String expr, SearchControls controls) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NamingEnumeration search(Name name, String expr, SearchControls controls) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NamingEnumeration search(String name, String expr, Object[] args, SearchControls controls) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public NamingEnumeration search(Name name, String expr, Object[] args, SearchControls controls) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    public void unbind(String name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }
    public void unbind(Name name) throws NamingException { throw new BIOperationNotSupportedException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_OP_NO_SUPPORT, null, getLocale(), null); }

    /**
     * @hidden
     */
    class NamingEnumerationImpl implements NamingEnumeration, java.io.Serializable
    {
      Enumeration m_enum;

      NamingEnumerationImpl(Vector v)
      {
          m_enum = v.elements();
      }

      public boolean hasMoreElements()
      {
          return m_enum.hasMoreElements();
      }

      public boolean hasMore() throws NamingException
      {
          return hasMoreElements();
      }

      public Object nextElement()
      {
          return m_enum.nextElement();
      }

      public Object next() throws NamingException
      {
            return nextElement();
      }

      public void close()
      {
      }
    }
}
