/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.QDR;

/**
 * Informs listeners when a cell override operation is requested.
 * A listener has the option to veto the cell override operation by calling the
 * <code>consume</code> method.
 * If a listener vetoes the operation, then subsequent listeners are not
 * notified and the operation is cancelled (that is, not added to the pending
 * queue).
 *
 * @status Documented
 */
public class CellOverridingEvent extends CellOverrideEvent implements Consumable
{

/**
 * Constructor for this event.
 *
 * @param source  The source of the event, that is, the object that fired the
 *                event.
 * @param row     The row of the cell that was edited.
 * @param col     The column of the cell that was edited.
 * @param page    The page of the cell that was edited.
 * @param data    The new data in the cell that was edited.
 * @param qdr     The QDR object that represents the cell that was edited.
 *
 *
 * @status Documented
 */
    public CellOverridingEvent(Object source, long row, long col, long page, Object data, QDR qdr)
    {
        super(source, row, col, page, data, qdr);
    }

/**
 * Consumes this event.
 *
 * @status Documented
 */
    public void consume() {
        super.consume();
    }

/**
 * Indicates whether this event has been consumed.
 *
 * @status Documented
 */
    public boolean isConsumed() {
        return super.isConsumed();
    }
}