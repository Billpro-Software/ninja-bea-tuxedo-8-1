/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.persistence;

import oracle.dss.bicontext.BIConstants;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * Constants for operations that have to do with persistence.
 * This interface contains two inner interfaces:
 * <P>
 * <ul>
 * <li> {@link Login} -- Environment properties for the default BI Beans
 *       implementation of the storage manager</li>
 * <li> {@link Attributes} -- Attributes that are used by the
 *      <code>StorageManager</code> interface. The attributes in
 *      <code>PSRConstants.Attributes</code> are some of the attributes that
 *      can be in the <code>Attributes</code> for a context.</li>
 * </ul>
 *
 * @see oracle.dss.persistence.persistencemanager.common.PersistenceManager
 * @see oracle.dss.persistence.persistencemanager.client.PersistenceManagerImpl
 * @see oracle.dss.persistence.persistencemanager.client.InitialPersistenceManager
 *
 * @status reviewed
 */
public interface PSRConstants extends PersistableConstants
{
   /**
     * Environment property: The limit of sql statements to be cached.
     * The value must be an <code>Integer</code> that specifies the
     * number of sql statements to cache.
     *
     * @status Documented
     */
    public static final String SEARCH_CACHE_LIMIT = "search_cache_limit";

    /**
     * Environment property: The error handler for the
     * <code>PersistenceManager</code>.
     * The value must be a <code>String</code> that identifies the
     * name of the class that implements the <code>ErrorHandler</code> interface.
     *
     * @deprecated as of 2.6.0.22. Use {@link oracle.dss.util.persistence.PersistableConstants#PERSISTENCE_ERRORHANDLER}.
     * @see oracle.dss.util.ErrorHandler
     *
     * @status reviewed
     */
    public static final String ERROR_HANDLER = "error_handler";

    /**
     * Copy mode: Do not copy referenced objects.
     * If you pass this constant as the <code>mode</code> argument to the
     * <code>copy</code> method, then only the object that you specify in the
     * <code>name</code> argument is copied.
     * Any named objects that that object references will not be copied.
     * <P>
     * For example, suppose you have a dimension list that references a named
     * selection.
     * If you use this copy mode, only the dimension list is copied.
     * The selection that the dimension list references is not copied.
     *
     * @see #DEEP_COPY
     * @see oracle.dss.bicontext.BIContext#copy
     *
     * @status reviewed
     */
    public static final int NORMAL_COPY = 0;

    /**
     * Copy mode: Copy referenced objects.
     * If you pass this constant as the <code>mode</code> argument to the
     * <code>copy</code> method, then objects that are referenced by the object
     * that you want to copy are also copied.
     * <P>
     * For example, suppose you have a dimension list that references a named
     * selection.
     * If you use this copy mode, both the dimension list and the selection
     * that it uses are copied.
     *
     * @see #NORMAL_COPY
     * @see oracle.dss.bicontext.BIContext#copy
     *
     * @status reviewed
     */
    public static final int DEEP_COPY = 1;

    /**
     * The implementation of a <code>StorageManager</code> that the
     * <code>PersistenceManager</code> should use.
     * The value must be a <code>String</code> that identifies the name of the
     * class that implements the <code>StorageManager</code> interface.
     * To use the default storage manager, use the value
     * "oracle.dss.persistence.storagemanager.bi.BIStorageManagerImpl".
     *
     * @status reviewed
     */
    public static final String STORAGEMANAGER_DRIVER = "sm_driver";

    /**
     * @hidden
     * encapsulates locale with resource bundle information and error handler
     */
    public static final String GLOBAL_ENVIRONMENT = "global_environment";

    /**
     * @hidden
     * global environment property: locale and resource bundle information
     *
     */
    public static final String PERSISTENCE_LOCALE_HELPER = "locale_helper";

    /**
     * @hidden
     * environment property: Timezone 
     *
     */
    public static final String TIMEZONE = "timezone";

    /**
     * Environment property:
     * Specifies the initial directory to use when the file based storagemanager
     * is used.  This property is required when the file based 
     * storagemanager is used.
     *
     * @status Documented
     */
    public static final String INITIAL_PATHNAME = "path";

    /**
     * Environment property:
     * Specifies the name of the zip file (full path name) when the zip file 
     * based storagemanager is used.  This property is required when the 
     * zip file based storagemanager is used.
     *
     * @status Documented
     */
   	public static final String ZIP_FILE = "zip";

    /**
     * Environment property:
     * Specifies the path of the root folder within the zip file when the 
     * zip file based storagemanager is used.  The default path is "".
     *
     * @status Documented
     */
    public static final String ZIP_ROOT_PATH = "path";

    /**
     * @hidden
     * Specifies an existing database connection
     */
    public static final String CONNECTION = "connection";

    /**
     * @hidden
     * Specifies a reference to connection driver manager
     */
    public static final String SECURITY_DRIVER_MANAGER = "securityDriverManager";

    /**
     * Environment property:
     * Specifies the user session that the PersistenceManager belongs to.
     *
     * @status Documented
     */
    public static final String BISESSION = "session";

    /**
     * @hidden
     */
    public static final String EXIST_CONNECTION = "existConnection";

    /**
     * @status hidden
     */
    public static final String PRESERVE_OBJECT_ID = "preserve_object_id";

    /**
     * This flag indicates whether PersistenceManager needs to keep track
     * of when objects get loaded in memory.
     *
     * The value is a <code>boolean</code>, which takes a value of 
     * <code>true</code> when tracking behavior is desired and 
     * <code>false</code> when no tracking should be performed.
     * @status new
     */
    public static final String TRACK_OBJ_ACCESS = "track_obj_last_accessed";

    /**
     * @hidden
     */
    public final static String FOLDER_UID_NAME = "folder.uid";

    /**
     * Environment properties for initializing the default implementation of the
     * <code>StorageManager</code>.
     * Use these constants when you create an
     * <code>InitialPersistenceManager</code>.
     *
     * @see oracle.dss.persistence.persistencemanager.client.InitialPersistenceManager
     *
     * @status reviewed
     */
    public interface Login
    {

        /**
         * The application user name to pass to the <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the
         * name of the user of the application.
         *
         * @status reviewed
         */
        public static final String USER_NAME = "user_name";


        /**
         * The application password to pass to the <code>StorageManager</code>.
         *
         * The value must be a <code>String</code> that contains the password
         * of the application.
         *
         * @status reviewed
         */
        public static final String PASSWORD  = "password";


        /**
         * The name of the Oracle RDBMS service, to pass to the
         * <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the
         * name of the Oracle server instance.
         * <P>
         * Note that you the <code>SERVICE</code> property replaces the
         * combination of the <code>HOSTNAME</code>, <code>PORT</code>, and
         * <code>SID</code> properties.
         *
         * @see #HOSTNAME
         * @see #PORT
         * @see #SID
         *
         * @status reviewed
         */
        public static final String SERVICE   = "service";


        /**
         * The host name of the Oracle RDBMS, to pass to the
         * <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the
         * host name of the Oracle server instance.
         * <P>
         * Note that you the <code>SERVICE</code> property replaces the
         * combination of the <code>HOSTNAME</code>, <code>PORT</code>, and
         * <code>SID</code> properties.
         *
         * @see #PORT
         * @see #SID
         * @see #SERVICE
         *
         * @status reviewed
         */
        public static final String HOSTNAME  = "hostname";


        /**
         * The port number of the Oracle RDBMS, to pass to the
         * <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the
         * port number of the Oracle server instance.
         * <P>
         * Note that you the <code>SERVICE</code> property replaces the
         * combination of the <code>HOSTNAME</code>, <code>PORT</code>, and
         * <code>SID</code> properties.
         *
         * @see #HOSTNAME
         * @see #SID
         * @see #SERVICE
         *
         * @status reviewed
         */
        public static final String PORT      = "port";


        /**
         * The ID of the Oracle Service Instance (SID) on a machine, to pass
         * to the <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the SID.
         * <P>
         * Note that you the <code>SERVICE</code> property replaces the
         * combination of the <code>HOSTNAME</code>, <code>PORT</code>, and
         * <code>SID</code> properties.
         *
         * @see #HOSTNAME
         * @see #PORT
         * @see #SERVICE
         *
         * @status reviewed
         */
        public static final String SID       = "sid";

        /**
         * The type of jdbc driver used, to pass to the 
         * <code>StorageManager</code>.
         * The value must be a <code>String</code> that contains the 
         * jdbc driver type.
         *
         * @status Documented
         */
        public static final String JDBC_DRIVERTYPE    = "drivertype";

        /**
         * The jdbc url to use
         * <code>StorageManager</code>.
         * See Oracle JDBC documentation for details.
         *
         * @status New
         */
        public static final String JDBC_URL    = "jdbcurl";
    }

    /**
     * Constants for the attributes that are used
     * by the <code>PersistenceManager</code> and <code>StorageManager</code>
     * interfaces.
     *
     * @status reviewed
     */
    public interface Attributes extends PersistableConstants.Attributes
    {
        /**
         * The name of the object.
         *
         * The value must be a <code>String</code> that contains the object
         * name.
         *
         * @status reviewed
         */
        public static final String OBJECT_NAME          = BIConstants.OBJECT_NAME;

        /**
         * The label of the object.
         *
         * The value must be a <code>String</code> that contains the object
         * name.
         *
         * @status Documented
         */
        public static final String OBJECT_LABEL         = BIConstants.OBJECT_LABEL;

        /**
         * The description of the object.
         *
         * The value must be a <code>String</code> that contains the
         * description of the object.
         *
         * @status reviewed
         */
        public static final String DESCRIPTION          = "description";


        /**
         * Keywords for the object.
         *
         * The value must be a <code>String</code> that contains the keywords
         * for the object.
         *
         * @status reviewed
         */
        public static final String KEYWORDS             = "keywords";


        /**
         * The application that owns the object.
         *
         * The value must be a <code>String</code> that contains the
         * name of the application.
         *
         * @status reviewed
         */
        public static final String APPLICATION          = "application";


        /**
         * The database that the object uses.
         *
         * The value must be a <code>String</code> that has the name of the
         * database.
         *
         * @status reviewed
         */
        public static final String DATABASE             = "database";


        /**
         * The part of the application that owns the object.
         * You can use this attribute to identify the module that
         * owns the object.
         *
         * The value must be a <code>String</code>.
         *
         * @status reviewed
         */
        public static final String APPSUBTYPE1	        = "application_subtype1";


        /**
         * @hidden
         * The ID of the object.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>String</code> that identifies the
         * object.
         *
         * @status reviewed
         */
         public static final String OBJECT_ID            = "object_id";


        /**
         * The time and date at which the object was created.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>java.util.Date</code> for the time and date
         * at the object was created.
         *
         * @status reviewed
         */
        public static final String TIME_DATE_CREATED    = "time_date_created";


        /**
         * The time and date at which the object was last modified.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>java.util.Date</code> for the time and date
         * at the object was last modified.
         *
         * @status reviewed
         */
        public static final String TIME_DATE_MODIFIED   = "time_date_modified";


        /**
         * The time and date at which the object was loaded for the last time.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>java.util.Date</code> for the time and date at 
         * which the object was loaded for last time.
         * @status new
         */
        public static final String TIME_DATE_LAST_ACCESSED = "time_date_last_accessed";
        
        /**
         * The ID of the user who created the object.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>String</code> that contains the ID of the
         * user who created the object.
         *
         * @status reviewed
         */
        public static final String CREATED_BY           = "created_by";


        /**
         * The ID of the user who last modified the object.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>String</code> that contains the ID of the
         * user who last modified the object.
         *
         * @status reviewed
         */
        public static final String MODIFIED_BY          = "modified_by";


        /**
         * Whether the object is visible to users.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>Boolean</code>: <code>true</code> if the
         * object is visible to users, <code>false</code> if it is not.
         *
         * @status reviewed
         */
        public static final String USER_VISIBLE         = "user_visible";


        /**
         * The full path name of the object.
         * The full path name is the name relative to the
         * <code>InitialPersistenceManager</code> (the initial context).
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is a <code>String</code> that contains the
         * full path name to the object.
         *
         * @status reviewed
         */
        public static final String OBJECT_FULLPATH_NAME = "obj_fullpath_name";

        /**
         * @hidden
         * The attribute that identifies the associate.
         * The attribute that identifies the association between the source and
         * the target object.
         * This attribute is set by the persistence manager.
         * It is read-only.
         *
         * The value is an <code>Attribute</code> that contains the
         * the key and the value of the association.
         *
         * @status hidden
         */
        public static final String ASSOCIATE_ID = "associate_id";

        /**
         * The net privilege that the caller has on the objects.
         *
         * Note that this attribute is an "operational attribute," 
         * which means that, unlike other attributes, it is not returned
         * as one of the returning attributes if a null value is specified.
         * The caller must explicitly specify this key in order to
         * retrieve the value.
         *
         * The value is of type <code>Privilege</code> and represents
         * the privilege that the caller has on the object.
         *
         * @status Documented
         */
        public static final String PRIVILEGE = "privilege";
        /**
         * Flag that indicates that the search result item represents a shortcut.
         *
         * Note that this attribute is an "operational attribute,"
         * which means that, unlike other attributes, it is not returned
         * as one of the returning attributes if a null value is specified.
         * The caller must explicitly specify this key in order to
         * retrieve the value.
         *
         * The value is of type <code>Boolean</code>. <code>True</code> means 
         * that the result
         * represents a shortcut, <code>false</code> means that the result does  
         * not represent a shortcut.
         *
         * @status Documented
         */
        public static final String IS_SHORTCUT = "is_shortcut";
    }

    /**
     * Constants for the extensible attributes that are used
     * by the <code>PersistenceManager</code> and <code>StorageManager</code>
     * interfaces.
     *
     * @status Documented
     */
    public interface ExtensibleAttributes
    {
        /**
         * Indicates all application
         * extensible attributes regardless of application name.
         *
         * The value is a <code>BasicAttributes</code> object that contains the
         * application extensible attributes of all applications.
         *
         * @status Documented
         */
        public static final String ALL_APPLICATIONS = "extensible_all_applications_attributes";

        /**
         * Indicates application 
         * extensible attributes for only the current application.
         *
         * The value is a <code>BasicAttributes</code> that contains the
         * application extensible attributes for only the current application.
         *
         * @status Documented
         */
        public static final String CURRENT_APPLICATION = "extensible_this_application_attributes";


        /**
         * Indicates component extensible attributes.
         *
         * The value is a <code>BasicAttributes</code> that contains the
         * component extensible attributes.
         *
         * @status Documented
         */
        public static final String COMPONENT = "extensible_component_attributes";

        /**
         * Indicates all extensible attributes of this object. This includes
         * both component and application extensible attributes.
         *
         * The value is a <code>BasicAttributes</code> that contains all the
         * extensible attributes of this object.
         *
         * @status Documented
         */
        public static final String ALL_ATTRIBUTES = "extensible_attributes";


    }
}
