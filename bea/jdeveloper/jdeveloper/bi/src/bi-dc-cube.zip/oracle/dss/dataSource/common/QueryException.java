/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.transform.TransformException;

/**
 * Non-runtime exceptions thrown specifically by the Query client.
 *
 * @status Documented
 */
public class QueryException extends TransformException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public QueryException(String s, Throwable e) {
        super(s, e);
    }    
}