/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.server.drivers.sba;

import oracle.bi.web.soap.internal.SAColumn;
import oracle.bi.web.soap.internal.SADataType;
import oracle.bi.web.soap.internal.SATable;

import java.sql.ResultSet;

import java.util.Hashtable;

import java.util.List;
import java.util.Vector;

import oracle.bi.presentation.soap.connection.BISoapConnection;

import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.CB;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.server.MetadataManagerImpl;
import oracle.dss.metadataUtil.PropertyBag;

import oracle.xml.parser.v2.XMLDocument;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MDObjectFactory
{
    private Hashtable m_ds;
    private MetadataManagerServices m_mms;
    private BISoapConnection m_connection;
    private String m_sessionID;
    private PropertyBag m_bag;
    private char[] m_escape;
    
    public MDObjectFactory(MetadataManagerServices mms) {
      m_ds = new Hashtable(7);
      m_escape = new char[] {' ', '/'};
      m_mms = mms;
    }

    public MDObjectFactory(MetadataManagerServices mms, BISoapConnection connection) {
        this(mms);
        m_connection = connection;
    }
    
    public MDObjectFactory(MetadataManagerServices mms, String sessionID) {
        this(mms);
        m_sessionID = sessionID;
    }

    public MDFolder makeDriverRoot(String name, String path) {
        MDFolder _root = new MDFolder();
        setCommonProperties(_root, "", name, path);
        return _root;
    }
    
    public void setCommonProperties(MDObject mdObject, String id, String name, String path) {
        if(mdObject != null) {
            mdObject.setName(name);
            mdObject.setLabel(name);
            mdObject.setPath(path);
            mdObject.setUniqueID(getDriverType(), id.replaceAll("\"", ""));
            //mdObject.setStrPropertyValue(MM.ESCAPED_UID, MMUtilities._escapeChar(id, m_escape));
            mdObject.setStrPropertyValue(MM.ESCAPED_UID, id);
            mdObject.setDriverType(getDriverType());
            mdObject.setObjectID(m_mms.generateMDObjectID());
            mdObject.setMetadataManagerServices(m_mms);
            
            String _dsName = id;
            if(id.indexOf('.') != -1)
                _dsName = id.substring(0, id.indexOf('.'));
            Connection _connection = (Connection)m_ds.get(_dsName);
            mdObject.setDatasource(_connection);

            try {
                m_mms.setMDObjectInCache(mdObject);
            }
            catch(Exception e) {} 
        }
    }
    
    private String getDriverType() {
        return MM.SBA;
    }
/*    
    public MDItemFolder createItemFolder(MDFolder parent, ResultSet rs) {
        MDItemFolder _itemFolder = null;
        try{
            String _name = rs.getString(3);
            String _id = parent.getName() + '.' + _name;
            String _path = parent.getName() + '/' + _name;
            
            String _itemName = rs.getString(4);
            String _itemID = parent.getName() + '.' + _name + '.' + _itemName;
            String _itemPath = parent.getName() + '/' + _name + '/' + _itemName;
            Object _dataType = rs.getString(5);
            
            _itemFolder = (MDItemFolder)m_mms.getMDObject(getBag(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), _id)), true);
            if(_itemFolder == null) {
                _itemFolder = new MDItemFolder();
                _itemFolder.setParent(parent);
                setCommonProperties(_itemFolder, _id, _name, _path);
            }
            
            MDItem _item = (MDItem)m_mms.getMDObject(getBag(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), _itemID)), true);
            if(_item == null) {
                _item = new MDItem();
                if("8".equals(_dataType))
                    _item.setStrPropertyValue(MM.DATA_TYPE, MM.INTEGER);
                else if("12".equals(_dataType))
                    _item.setStrPropertyValue(MM.DATA_TYPE, MM.STRING);
                setCommonProperties(_item, _itemID, _itemName, _itemPath);
                _item.setParent(_itemFolder);
                _itemFolder.setChild(_item, MM.ITEM);
            }
        }
        catch(Exception e) {
            // ignore
        }
        return _itemFolder;
    }
*/    
    public MDItemFolder createItemFolder(MDFolder parent, SATable table) {
        MDItemFolder _itemFolder = null;
        try{
            String _name = table.getDisplayName();
            String _id = parent.getName() + '.' + table.getName();
            String _path = parent.getName() + '/' + table.getName();
            _itemFolder = (MDItemFolder)m_mms.getMDObject(getBag(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), _id)), true);
            if(_itemFolder != null)
                return _itemFolder;
            else {
                _itemFolder = new MDItemFolder();
                _itemFolder.setParent(parent);
                setCommonProperties(_itemFolder, _id, _name, _path);
                List<SAColumn> columnArray = table.getColumns();
                for(SAColumn currentColumn : columnArray) {
                    String _itemName = currentColumn.getDisplayName();
                    String _dataType = currentColumn.getDataType();
                    String _itemID = _id + '.' + currentColumn.getName();
                    String _itemPath = _path + '/' + currentColumn.getName();
                    MDItem _item = (MDItem)m_mms.getMDObject(getBag(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), _itemID)), true);
                    if(_item == null) {
                        _item = new MDItem();
                        
                        if(SADataType.INTEGER.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.INTEGER);
                        else if(SADataType.VAR_CHAR.value().equalsIgnoreCase(_dataType) ||
                                SADataType.CHAR.value().equalsIgnoreCase(_dataType) ||
                                SADataType.LONG_VAR_CHAR.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.STRING);
                        else if(SADataType.DATE.value().equalsIgnoreCase(_dataType) ||
                                SADataType.TIME.value().equalsIgnoreCase(_dataType) ||
                                SADataType.TIME_STAMP.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.DATE);
                        else if(SADataType.DOUBLE.value().equalsIgnoreCase(_dataType) ||
                                SADataType.REAL.value().equalsIgnoreCase(_dataType) ||
                                SADataType.DECIMAL.value().equalsIgnoreCase(_dataType) ||
                                SADataType.NUMERIC.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.DOUBLE);
                        else if(SADataType.FLOAT.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.FLOAT);
                        else if(SADataType.BIG_INT.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.LONG);
                        else if(SADataType.TINY_INT.value().equalsIgnoreCase(_dataType) ||
                                SADataType.SMALL_INT.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.SHORT);
                        else if(SADataType.BINARY.value().equalsIgnoreCase(_dataType) ||
                                SADataType.LONG_VAR_BINARY.value().equalsIgnoreCase(_dataType) ||
                                SADataType.VAR_BINARY.value().equalsIgnoreCase(_dataType) ||
                                SADataType.BIT.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.BINARY);
                        else if(SADataType.UNKNOWN.value().equalsIgnoreCase(_dataType) ||
                                SADataType.INVALID.value().equalsIgnoreCase(_dataType))
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.UNKNOWN);
                        else
                            _item.setStrPropertyValue(MM.DATA_TYPE, MM.UNKNOWN);

                        _item.setStrPropertyValue(MM.AGGR_RULE, currentColumn.getAggrRule());
                        setCommonProperties(_item, _itemID, _itemName, _itemPath);
                        _item.setParent(_itemFolder);
                        _itemFolder.setChild(_item, MM.ITEM);
                    }
                }
            }
        }
        catch(Exception e) {
            // ignore
        }
        return _itemFolder;
    }

    private Connection createDatasource(String ds)
    {
        Connection _conn = new Connection();
        _conn.setProperty(CB.SUPER_ROOT, m_mms.getMDRoot());
        _conn.setProperty(CB.ROOT_NAME, ds);
        _conn.setConnectionKey(ds);
        _conn.setProperty(MM.DATASOURCE_TYPE, getDriverType());
        _conn.setProperty(MM.DATASOURCE, m_connection);
        
        MDFolder _dsRoot = new MDFolder();
        setCommonProperties(_dsRoot, ds, ds, ds);
        _dsRoot.setDatasource(_conn);
        _conn.setRoot(_dsRoot);
        return _conn;
    }
    
    public Connection getDatasource(String ds)
    {
        Connection _conn = null;
        if(m_ds.containsKey(ds))
            _conn = (Connection)m_ds.get(ds);
        else
        {
            _conn = createDatasource(ds);
            m_ds.put(ds, _conn);
        }
        return _conn;
    }
    
    private PropertyBag getBag(String propertyName, String propertyValue) {
        if(m_bag == null)
            m_bag = new PropertyBag();
            
        m_bag.setStrPropertyValue(propertyName, propertyValue);
        return m_bag;
    }

    public MDDimension createMeasureDimension() {
        MDDimension _measDim = new MDDimension();
        _measDim.setName(MM.MEASURE_DIMENSION);
        _measDim.setShortLabel(MM.MEASURE_DIMENSION);
        _measDim.setLongLabel(MM.MEASURE_DIMENSION);
        _measDim.setShortPluralLabel(MM.MEASURE_DIMENSION);
        _measDim.setLongPluralLabel(MM.MEASURE_DIMENSION);

        _measDim.setPath("");
        _measDim.setObjectID(m_mms.generateMDObjectID());
        _measDim.setDriverType(getDriverType());
        _measDim.setUniqueID(getDriverType(), MM.MEASURE_DIMENSION);
        return _measDim;
    }
/*
    public MDObject createOlapMetadata(MDItemFolder itemFld) {
      MDObject _olapObj;
      try {
        MDItem[] _items = itemFld.getItems();
        // determine measure folder
        boolean _isMeasureFld = true;
        for(int i=0; i < _items.length; i++) {
          Vector _drillUp = (Vector)_items[i].getObjPropertyValue(MM.DRILL_UP_PATHS);
          Vector _drillDown = (Vector)_items[i].getObjPropertyValue(MM.DRILL_DOWN_PATHS);
          if((_drillUp != null && _drillDown != null) || (MM.STRING.equals(_items[i].getDatatype()))) {
            _isMeasureFld = false;
            break;
          }
        }
        
        ((MetadataManagerImpl)m_mms).removeMDObjectFromCache(itemFld);
        if(_isMeasureFld) {
          _olapObj = new MDFolder();
          setCommonProperties(_olapObj, MMUtilities._extractID(itemFld.getUniqueID()), itemFld.getName(), itemFld.getPath());
          
          for(int i=0; i < _items.length; i++) {
            MDMeasure _meas = new MDMeasure();
            setCommonProperties(_meas, MMUtilities._extractID(_items[i].getUniqueID()), _items[i].getName(), _items[i].getPath());
            _meas.setDataType(MM.INTEGER);
            _olapObj.setChild(_meas, MM.MEASURE);
          }
        }
        else {
          _olapObj = new MDDimension();
          setCommonProperties(_olapObj, MMUtilities._extractID(itemFld.getUniqueID()), itemFld.getName(), itemFld.getPath());

          for(int i=0; i < _items.length; i++) {
          }
        }
      }
      catch(Exception e) {
      }
      return null;
    }
*/

    public MDFolder createMDFolder(MDFolder parent, Node node) {
      MDFolder _folder = null;
      String _name, _path, _id;
      _name = _path = _id = null;
      NodeList _nList = node.getChildNodes();
      for(int i=0; i < _nList.getLength(); i++) {
        Node _childNode = _nList.item(i);
        String _nodeName = _childNode.getNodeName();
        if("path".equals(_nodeName))
          _path = _childNode.getFirstChild().getNodeValue();
        else if("caption".equals(_nodeName))
          _name = _childNode.getFirstChild().getNodeValue();
          
        if(_path != null && _name != null)
          break;
      }

      if(_path != null && _name != null) {
        _id = _path.replace('/', '.');
        try {
          _folder = (MDFolder)m_mms.getMDObject(getBag(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), _id)), true);
          if(_folder == null) {
            _folder = new MDFolder();
            setCommonProperties(_folder, _id, _name, _path);
          }
        }
        catch(Exception e) {
          // ignore
        }
      }
      return _folder;
    }
}