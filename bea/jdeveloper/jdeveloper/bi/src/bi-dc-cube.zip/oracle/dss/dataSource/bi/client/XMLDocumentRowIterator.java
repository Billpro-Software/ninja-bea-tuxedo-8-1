/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/XMLDocumentRowIterator.java /bibeans_root/22 2009/08/20 08:29:23 srkalyan Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     02/26/07 - 
    imohamma    11/10/06 - 
    bmoroze     08/04/06 - 
    imohamma    07/20/06 - 
    bmoroze     07/07/06 - 
    jramanat    06/14/06 - Creation
 */

package oracle.dss.dataSource.bi.client;

import java.io.StringReader;


import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

import java.util.Iterator;
import java.util.List;

import java.util.Map;
import java.util.Set;
import java.util.Vector;

import oracle.dss.dataSource.client.DataCell;
import oracle.dss.dataSource.client.Member;
import oracle.dss.dataSource.client.QueryRowIterator;
import oracle.dss.dataSource.common.CouldNotEvaluateException;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataUtil.Property;
import oracle.dss.util.transform.DataCellInterface;
import oracle.dss.util.transform.DataType;
import oracle.dss.util.transform.MemberInterface;

import oracle.dss.util.transform.TransformException;

import oracle.xml.parser.v2.SAXParser;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/XMLDocumentRowIterator.java /bibeans_root/22 2009/08/20 08:29:23 srkalyan Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public class XMLDocumentRowIterator implements QueryRowIterator {
  protected Query m_query = null;
  protected Hashtable<String, ColumnInfo> m_columns = new Hashtable<String, ColumnInfo>();
  protected Hashtable<Integer, ColumnInfo> m_colNumbers = new Hashtable<Integer, ColumnInfo>();
  protected Hashtable<String, Integer> m_colTags = new Hashtable<String, Integer>();
  //protected NodeList m_rows = null;
  protected int m_rowIndex = -1;
  protected List<Object[]> m_rowList = new ArrayList<Object[]>();
  protected boolean m_isXML = false;
    private String m_xml = null;
  private boolean m_isInError = true;
  private Map<String, Map<String, String>> m_metadataMapCache = new HashMap<String, Map<String, String>>();

  public XMLDocumentRowIterator(String xml, Query q, boolean isXML) throws TransformException, CouldNotEvaluateException {
    m_query = q;
      m_xml = xml;
    initialize();
    m_isXML = isXML;
  }
  
    public Object clone()
    {
        try
        {
            return new XMLDocumentRowIterator(m_xml, m_query, m_isXML);
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    public String[] getColumns(String type)
    {
        return getColumns();
    }
    
  public String[] getColumns()
  {
      if (m_columns != null)
      {
          Vector<String> ids = new Vector<String>();
          Enumeration<String> keys = m_columns.keys();
          while (keys.hasMoreElements())
              ids.addElement(keys.nextElement());
          return (String[])ids.toArray(new String[]{});
      }
      return null;
  }
  
  public Object getValue(String column) throws TransformException
  {
    DataCellInterface dci = getCell(column);
    if (dci != null)
        return dci.getData(DataType.VALUE);
    MemberInterface mi = getMember(column);
    if (mi != null)
        return mi.getValue();
    return null;
  }
  
  private void initialize() throws TransformException, CouldNotEvaluateException {
    try {
        
        SAXParser parser = new SAXParser();        
        parser.setContentHandler(new ParseHandler());
        parser.setPreserveWhitespace(false);
        //parser.parse(new InputSource(new StringReader(SOAPUtility.getUnescapedString(m_xml))));
        StringReader sr = new StringReader(m_xml);
        InputSource is = new InputSource(sr);
        parser.parse(is);
        is = null;
        sr.close();
        sr = null;
        
/*      NodeList nl = m_document.getElementsByTagName("rowset");
      XMLDocument rowSet = SOAPUtility.parseXML(nl.item(0).getFirstChild().getNodeValue());
      NodeList columns = rowSet.getElementsByTagName("element");
      if (columns != null) {
        for (int i = 0; i < columns.getLength(); i++) {
          Node column = columns.item(i);
          String id = column.getAttributes().getNamedItem("saw-sql:displayFormula").getNodeValue();
          String tag = column.getAttributes().getNamedItem("name").getNodeValue();
          String type = column.getAttributes().getNamedItem("type").getNodeValue();
          m_columns.put(id, new ColumnInfo(i, tag, type));
        }
      }
      //m_rows = rowSet.getElementsByTagName("Row");*/
        parser = null;
      m_rowIndex = -1;
    }
    catch (Exception e) {
        if (m_isInError)
        {
          m_query.getErrorHandler().log("Error XML returned: " + m_xml, "XMLDocumentRowIterator", "initialize");
          throw new CouldNotEvaluateException("Error XML returned", 0, m_xml, m_query.getID(), e);
        }
      throw new TransformException(e.getMessage(), e);
    }
  }
  
  public boolean hasMoreRows() throws TransformException {
    return m_rowList != null && m_rowList.size() > 0 && (m_rowIndex + 1) < m_rowList.size();
  }

  public boolean nextRow() throws TransformException {
    if (hasMoreRows()) {
      m_rowIndex++;
      return true;
    }
    return false;
  }

  public void close() throws TransformException {
      if (m_columns != null)
            m_columns.clear();
      m_columns = null;
      m_query = null;
      if (m_colTags != null)
          m_colTags.clear();
      if (m_colNumbers != null)
          m_colNumbers.clear();
      m_colNumbers = null;
      if (m_rowList != null)
          m_rowList.clear();
      m_rowList = null;
      m_xml = null;    
      m_metadataMapCache = new HashMap<String, Map<String, String>>();
  }

    public Object getValue(Object columnKey) throws TransformException
    {
        return getValue(columnKey, -1);
    }
    
  public Object getValue(Object columnKey, int colCount) throws TransformException {
    if(m_isXML && columnKey instanceof String) {
      columnKey = ((String)columnKey).substring(((String)columnKey).indexOf('.')+1);
    }

    // NOTE THIS ORDER (ORDER OF COLS ASKED FOR BY DATATABLE) IS HIGHLY SENSITIVE TO THE ORDER IN WHICH QUERYSTATE WRITES OUT THE XML BEFORE TRANSFORMATION
    // IN ORDER TO SUPPORT UNMAPPABLE USER-DEFINED CALCS IN THE RETURNED XML CURSOR
    ColumnInfo colInfo = m_columns.get(columnKey);
    if (colInfo == null && colCount > -1)
    {
        // This may mean that we have a user-typed, ID, which case we have to find it by location--items first then dataitems
        // both in the cursor and in the input XML
        // bug 6445701 -- just use m_colNumbers table to look up
        colInfo = m_colNumbers.get(new Integer(colCount));
        if (colInfo == null)
        {
            Enumeration<ColumnInfo> cols = m_columns.elements();
            while (cols.hasMoreElements())
            {
                colInfo = cols.nextElement();
                if (colInfo.m_index == colCount)
                {
                    break;
                }
            }
        }
    }
    Object[] columns = m_rowList.get(m_rowIndex);
    return colInfo != null ? columns[colInfo.m_index] : null;
  }

    protected Object getObjectFromString(ColumnInfo colInfo, String strValue)
    {
        if (colInfo.m_type.equals("xsd:boolean")) {
          return new Boolean(strValue);
        }
        else if (colInfo.m_type.equals("xsd:byte")) {
          return new Byte(strValue);
        }
        else if (colInfo.m_type.equals("xsd:decimal")) {
          return new java.math.BigDecimal(strValue);
        }
        else if (colInfo.m_type.equals("xsd:double")) {
          return new Double(strValue);
        }
        else if (colInfo.m_type.equals("xsd:float")) {
          return new Float(strValue);
        }
        else if (colInfo.m_type.equals("xsd:int")) {
            return new Integer(strValue);
        }
        else if (colInfo.m_type.equals("xsd:integer")) {
          return new java.math.BigInteger(strValue);
        }
        else if (colInfo.m_type.equals("xsd:long")) {
          return new Long(strValue);
        }
        else if (colInfo.m_type.equals("xsd:short")) {
          return new Short(strValue);
        }
        else if (colInfo.m_type.equals("xsd:string")) {
          return strValue;
        }
        else {
          // xsd:base64Binary
          // xsd:dateTime
          // xsd:hexBinary
          // xsd:QName      
          return strValue;
        }        
    }
    protected class ParseHandler extends DefaultHandler
    {
        protected boolean m_inRowset = false;
        protected boolean m_inElement = false;
        protected boolean m_inRow = false;
        protected boolean m_inColumn = false;
        protected int m_elementCount = 0;
        protected int m_colPos = -1;
        
        public void startElement(java.lang.String namespaceURI,
                                 java.lang.String localName,
                                 java.lang.String qName,
                                 Attributes attrs)
                          throws SAXException
        {
            if (localName.equals("rowset"))
                m_inRowset = true;
            else if (localName.equals("element") && m_inRowset)
            {
                m_inElement = true;
                // Check attributes
                String id = attrs.getValue("saw-sql:displayFormula");                
                String tag = attrs.getValue("name");
                String type = attrs.getValue("type");
                m_elementCount++;
                ColumnInfo colInfo = new ColumnInfo(m_elementCount-1, tag, type);
                // De-quote the ID
                id = id.replaceAll("\"", "");
                m_columns.put(id, colInfo);
                m_colNumbers.put(new Integer(m_elementCount-1), colInfo);
                m_colTags.put(tag, m_elementCount-1);
            }
            else if (localName.equals("Row") && m_inRowset)
            {
                m_colPos = -1;
                m_inRow = true;
                m_rowList.add(new Object[m_elementCount]);
            }
            else if (localName.startsWith("Column") && m_inRow)
            {
                m_colPos = m_colTags.get(localName).intValue();
                m_inColumn = true;
            }
          else if (localName.equals("Error"))
               {
                 m_isInError = true;
               }
        }
        
        public void endElement(java.lang.String namespaceURI,
                               java.lang.String localName,
                               java.lang.String qName)
                        throws SAXException
        {
            if (localName.equals("rowset"))
                m_inRowset = false;
            else if (localName.equals("element"))
                m_inElement = false;
            else if (localName.equals("Row"))
                m_inRow = false;
            else if (localName.startsWith("Column"))
                m_inColumn = false;            
        }
        
        public void characters(char[] ch,
                               int start,
                               int length)
                        throws SAXException
        {
            if (m_inColumn)
            {
                // Store these
                m_rowList.get(m_rowList.size()-1)[m_colPos] = getObjectFromString(m_colNumbers.get(new Integer(m_colPos)), new String(ch, start, length));
            }
        }
                        
    }
    
    public MemberInterface getMember(String column) throws TransformException {
        return getMember(column, -1);
    }
    
    private String convertMemberToString(Object val)
    {
        // Convert the incoming member to a string value for the edge
        // member interface: if it's a number with a "0" decimal part, 
        // squelch it because of limitations on BI formatting and getting
        // true data types
        if (val instanceof Number)
        {
            Number num = (Number)val;
            if (num.intValue() == num.doubleValue())
            {
                // We can squelch
                Integer intVal = num.intValue();
                return intVal.toString();
            }
            return num.toString();
        }
        else
            if (val != null)
              return val.toString();
        return null;
    }
    
    private void updateMap(String column)
    {
        try
        {
          // Look it up in the MM
          MDObject obj = m_query.getMDObject(MM.UNIQUE_ID, column, MM.OBJECT);
            if (obj != null)
            {
                Property prop = obj.getProperty(MM.ATTRIBUTE_MAP);
                if (prop != null && prop.getObjValue() instanceof Map)
                {
                    // Has a map: store it
                    m_metadataMapCache.put(column, (Map<String, String>)prop.getObjValue());
                }
                else
                    m_metadataMapCache.put(column, null);
            }
        }
        catch (Exception e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        
    }
    
    private Map<String, Object> constructValueMap(Map<String, String> typeMap) throws TransformException
    {
        if (typeMap == null)
            return null;
        
        Set<String> keySet = typeMap.keySet();
        Iterator<String> iter = keySet.iterator();
        Map<String, Object> valMap = new HashMap<String, Object>();
        String id = null;
        String type = null;
        while (iter.hasNext())
        {
            id = iter.next();
            type = typeMap.get(id);
            valMap.put(type, getValue(id, -1));
        }
        return valMap;
    }
    
  public MemberInterface getMember(String column, int colCount) throws TransformException {
      // Check to see if this column has a MetadataMap type->other column map
      if (!m_metadataMapCache.containsKey(column))
      {
          updateMap(column);
      }
      
      Map<String, String> typeMap = m_metadataMapCache.get(column);
      Map<String, Object> valueMap = constructValueMap(typeMap);
      Object value = getValue(column, colCount);
      return new Member(value, column, column, valueMap, m_query);      
  }  

    public DataCellInterface getCell(String column) throws TransformException {
        return getCell(column, -1);
    }
  
  public DataCellInterface getCell(String column, int colCount) throws TransformException {
    Object data = getValue(column, colCount);
    if (data != null) {
      return new DataCell(data);
    }
    return null;
  }
  
  private class ColumnInfo
  {
    ColumnInfo(int index, String tag, String type) {
      m_index = index;
      m_tag = tag;
      m_type = type;
    }

    int m_index;
    String m_tag;
    String m_type;
  }
}
