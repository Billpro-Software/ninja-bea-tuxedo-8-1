/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/ExceptionListenerAdapter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

import java.io.Serializable;

import java.util.Date;

import oracle.dss.util.BIException;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.gui.ResourceHandler;

/**
 * <pre>
 * Default exception listener.
 *
 * This is the default implementation of the <code>ExceptionListener</code>
 * interface.
 *
 * This implementation simply dumps the alert messages.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 */
public class ExceptionListenerAdapter extends Object implements ExceptionListener, Serializable {

  /////////////////////
  //
  // Member variables
  //
  /////////////////////

  /**
   * Currently supported options.
   *
   * @status New
   */
  protected int m_nOptions = OPTION_ALL;

  /**
	 * @hidden
   *
   * Error handler reference
   *
   * @status hidden
   */
  protected transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /**
	 * @hidden
   *
   * <code>ResourceHandler</code> used for resource retrieval.
   *
   * @status hidden
   */
  protected transient ResourceHandler m_resourceHandler = null;

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the options for the exception listener.
   *
   * This method allows user specify multiple options through bitwise literals.
   *
   * @param nOption A <code>int</code> which contains the options associated
   *                with this <code>ExceptionListener</code>.
   *
   * @return <code>int</code> value which represents the current options.
   *
   * @see #OPTION_ALL
   * @see #OPTION_NONE
   * @see #OPTION_EXCEPTION
   *
   * @status New
   */
  public int setOptions (int nOptions) {
    if (((nOptions & OPTION_EXCEPTION) > 0) ||
        (nOptions == OPTION_NONE)           ||
        (nOptions == OPTION_ALL)) {
      m_nOptions = nOptions;
    }

    return m_nOptions;
  }

  /**
   * Retrieves the options specified for this <code>ExceptionListener</code>.
   *
   * @return <code>int</code> value which represents the current options.
   *
   * @status New
   */
  public int getOptions() {
    return m_nOptions;
  }

  /**
   * Reset the options of the <code>ExceptionListener</code> back to the default
   * settings.
   *
   * @status New
   */
  public void resetOptions() {
    m_nOptions = OPTION_ALL;
  }

  /**
   * Responds to trapped exception alerts.
   *
   * <code>ExceptionListenerCallback</code> implementations call this method when
   * an alert is required in response to an exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return <code>int</code> value which represents a positive response
   *         when zero and a negative response when non-zero.
   *
   * @see ExceptionListener#YES
   * @see ExceptionListener#NO
   * @see ExceptionListener#NONE
   *
   * @status New
   */
  public int processException (Throwable throwable, String strClass, String strRoutine) {
    if ((m_nOptions & OPTION_EXCEPTION) > 0 || m_nOptions == OPTION_ALL) {
      ErrorHandler errorHandler = getErrorHandler();

      if (errorHandler != null) {
        errorHandler.error (throwable, strClass, strRoutine);
      }
    }

    return YES;
  }

	//-------------------------------------------------------------------
	// Start implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status New
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status New
   */
  public void removeErrorHandler() {
    addErrorHandler (new DefaultErrorHandler());
  }

	//-------------------------------------------------------------------
	// End implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> that represents the current
   *         error handler.
   *
   * @status New   
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /**
   * Specifies the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @param resourceHandler A <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @status new 
   */
  public void setResourceHandler (ResourceHandler resourceHandler) { 
    m_resourceHandler = resourceHandler;
  }

  /**
   * Retrieves the <code>ResourceHandler</code> used for resource retrieval.
   * 
   * @return A <code>ResourceHandler</code> used for resource retrieval..
   * 
   * @status new 
   */
  public ResourceHandler getResourceHandler() { 
    return m_resourceHandler; 
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

}

