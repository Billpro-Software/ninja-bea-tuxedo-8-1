/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;

/**
 * Indicates a circular reference that prevents further operation.
 *
 * To handle this exception in particular, catch it before you catch a
 * <code>NamingException</code>.
 * 
 * @status New
 */
public class BICircularReferenceException extends BINamingException
{
    

    

    /**
     * @hidden
     * Constructor for an exception that cannot be localized and that passes
     * on an underlying exception.
     *
     * @param msg  The text of the error message.
     * @param prevException The exception that underlies this exception.
     */
    public BICircularReferenceException(String msg, Throwable prevException)
    {
        super(msg, prevException);
    }

   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    */
    public BICircularReferenceException(Class resBundleClass, String errorCode, String[] params)
    {
        super(resBundleClass, errorCode, params);
    }

   /**
    * @hidden
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    */
    public BICircularReferenceException(Class resBundleClass, String errorCode, String[] params, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, prevException);
    }

   /**
    * @hidden
    * Constructor for a formattable, localizable exception for a specific locale
    * that passes on a previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale The locale in which the message should be localized.
    * @param prevException  The exception that underlies this exception.
    */
    public BICircularReferenceException(Class resBundleClass, String errorCode, String[] params, Locale locale, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, locale, prevException);
    }
}
