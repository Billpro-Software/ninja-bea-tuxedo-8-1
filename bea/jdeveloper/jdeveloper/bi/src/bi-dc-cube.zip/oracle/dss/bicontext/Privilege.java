/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.io.Serializable;

/**
 * Represents the rights that a user has to manipulate a context and the
 * objects that a context contains.
 * You set the privilege for a user in an <code>ACLEntry</code>.
 * <P>
 * There are five valid privileges:
 * <P>
 * <ul><li>List -- The user can list the contents of the folder, but cannot do
 *         any other operations.</li>
 * <li>Read -- The user can list and read the contents of a folder, but cannot
 *         perform any other operations.</li>
 * <li>Add Folder -- The user can list and read the contents of a folder, and
 *         can create subfolders in the folder.
 *         The user cannot store (write) objects in the folder or change
 *         privileges.</li>
 * <li>Write -- The user can list and read the contents of a folder, and can
 *         create subfolders in the folder.
 *         The user can also write to the folder, saving objects in it.
 *         The only thing that the user cannot do is change the privileges
 *         for the folder.</li>
 * <li>Full Control -- The user can do everything to the folder and its contents.
 *         The user can list contents, read contents, write contents, create
 *         subfolders, and can change the privileges for the folder.</li>
 * </ul>
 * <P>
 * A <code>Privilege</code> must be one and only of these types.
 * Each privilege level in the list implies all of the prior privileges.
 * For example, if a user has Write privileges, then the user also has
 * List, Read, and Add Folder privileges.
 *
 * @status documented
 */
public class Privilege implements Serializable
{
    private int m_privilege;

    /**
     * Privilege: The user can list the contents of a folder.
     * The user cannot perform any other operations on the folder.
     *
     * @status documented
     */
    public static final Privilege LIST = new Privilege(10);

    /**
     * Privilege: The user can read the contents of a folder.
     * The user can also list the contents of the folder.
     * The user cannot write to a folder, create subfolders, or change
     * the privilege for the folder.
     *
     * @status documented
     */
    public static final Privilege READ = new Privilege(20);

    /**
     * Privilege: The user can add a subfolder to a folder.
     * The user can also list and read the contents of the folder.
     * The user cannot write to a folder or change
     * the privilege for the folder.
     *
     * @status documented
     */
    public static final Privilege ADD_FOLDER = new Privilege(30);

    /**
     * Privilege: The user can write objects to a folder.
     * This privilege also implies list, read, and add folder privileges.
     * The only operation that the user cannot do is change the privilege for
     * the folder.
     *
     * @status documented
     */
    public static final Privilege WRITE = new Privilege(40);

    /**
     * Privilege: The user has full control of the folder.
     * This privilege all other privileges.
     * In addition, the user can change the privilege for the folder.
     *
     * @status documented
     */
    public static final Privilege FULL_CONTROL = new Privilege(50);

    /**
     * @hidden
     */
    public static Privilege getPrivilege(String privilege)
    {
        if (privilege.equals("List"))
            return Privilege.LIST;
        else if (privilege.equals("Read"))
            return Privilege.READ;
        else if (privilege.equals("Add Folder"))
            return Privilege.ADD_FOLDER;
        else if (privilege.equals("Write"))
            return Privilege.WRITE;
        else if (privilege.equals("Full Control"))
            return Privilege.FULL_CONTROL;
        else
            return null;
    }

    /**
     * @hidden
     */
    public static Privilege getPrivilege(int privilege)
    {
        if (privilege == 10)
            return Privilege.LIST;
        else if (privilege == 20)
            return Privilege.READ;
        else if (privilege == 30)
            return Privilege.ADD_FOLDER;
        else if (privilege == 40)
            return Privilege.WRITE;
        else if (privilege == 50)
            return Privilege.FULL_CONTROL;
        else
            return null;
    }


    /**
     * @hidden
     */
    public Privilege(int privilege)
    {
        if ((privilege != 10) && (privilege != 20) &&
            (privilege != 30) && (privilege != 40) &&
            (privilege != 50))
        {
            throw new IllegalArgumentException("Invalid privilege value specified: " + privilege);
        }
        m_privilege = privilege;
    }


    /**
     * @hidden
     * Set the value of this privilege.
     *
     * @param privilege the privilege value to assign to this privilege.
     */
    public void setValue(int privilege)
    {
        if (getPrivilege(privilege) == null)
        {
            throw new IllegalArgumentException("Invalid privilege value specified: " + privilege);
        }
   	    m_privilege = privilege;
    }


    /**
     * @hidden
     */
    public int getValue()
    {
        return m_privilege;
    }

    /**
     * Indicates whether the specified object is equivalent to this
     * <code>Privilege</code>.
     *
     * @param obj  The object to compare with this <code>Privilege</code>.
     * @return <code>true</code> if <code>obj</code> is equivalent to this
     *             <code>Privilege</code>,
     *         <code>false</code> if not.
     *         This method also returns false if <code>obj</code> is not
     *         a privilege.
     *
     * @status documented
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Privilege)
        {
            int _privilege = ((Privilege)obj).getValue();
            return (m_privilege == _privilege);
        }
        else
        {
            return false;
        }
    }

    /**
     * @hidden
     * Returns a hash code value for the object
     *
     * @return int a hash code value for this object.
     */
    public int hashCode()
    {
        return m_privilege;
    }

    /**
     * Indicates whether this <code>Privilege</code> implies the specified
     * <code>Privilege</code>.
     * If this method returns <code>true</code>, then a user who has this
     * <code>Privilege</code> also has the specified <code>Privilege</code>.
     * For example, if this <code>Privilege</code> is "Read", and the specified
     * <code>Privilege</code> is "List," then this message returns
     * <code>true</code>.
     * A user who has this <code>Privilege</code> can read objects in a
     * context and, by implication, can list the objects in the context.
     *
     * @param privilege  The <code>Privilege</code> that might be implied by
     *             this <code>Privilege</code>.
     * @return <code>true</code> if this <code>Privilege</code> implies
     *             <code>privilege</code>,
     *         <code>false</code> if it does not.
     *
     * @status documented
     */
    public boolean implies(Privilege privilege)
    {
        int _privilege = privilege.getValue();
        return (m_privilege >= _privilege);
    }

    /**
     * Converts this <code>Privilege</code> to a <code>String</code>.
     * This method returns a <code>String</code> that identifies the
     * access rights of this <code>Privilege</code>, such as "List" or
     * "Write".
     *
     * @return The <code>String</code> representation of this
     *         <code>Privilege</code>.
     *
     * @status documented
     */
    public String toString()
    {
        if (m_privilege == 10)
            return "List";
        else if (m_privilege == 20)
            return "Read";
        else if (m_privilege == 30)
            return "Add Folder";
        else if (m_privilege == 40)
            return "Write";
        else if (m_privilege == 50)
            return "Full Control";
        else
            return null;
    }
}
