/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Provides a message when an undo operation cannot be performed.
 *
 * @status Documented
 */
public class UndoException extends QueryRuntimeException
{
    /**
     * Constructor for this class.
     *
     * @param  msg      The message that is provided with the exception.
     * @param exception The exception that was trapped to generate this
     *                  exception.
     *
     * @status Documented
     */
    public UndoException(String msg, Exception e) {
        super(msg, e);
    }
}
