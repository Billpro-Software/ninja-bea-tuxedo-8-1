/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBADataTable.java /bibeans_root/19 2009/04/16 20:10:18 bmoroze Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     10/31/06 - Move files back to oracle.dss.util
    bmoroze     08/24/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBADataTable.java /bibeans_root/19 2009/04/16 20:10:18 bmoroze Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.bi.client;

import java.util.Hashtable;
import java.util.Map;

import oracle.dss.util.transform.ColumnValues;
import oracle.dss.util.transform.DataCell;
import oracle.dss.util.transform.DataCellInterface;
import oracle.dss.util.transform.DataTable;
import oracle.dss.util.transform.LayerInterface;
import oracle.dss.util.transform.MemberCell;
import oracle.dss.util.transform.MemberInterface;
import oracle.dss.util.transform.QDRLite;
import oracle.dss.util.transform.RowProjection;
import oracle.dss.util.transform.Row;
import oracle.dss.util.transform.BaseRowIterator;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.total.AggSpec;

/**
 * @hidden
 * Adds a storage mechanism built in to the data table
 */
public class SBADataTable extends DataTable
{
    protected Hashtable<QDRLite, DataCellInterface> m_dataCache;
    
    protected SBADataTable()
    {
        super();
    }
    
    public SBADataTable(RowProjection projection) throws TransformException
    {
        this(projection, (AggSpec[][])null);
    }

    public SBADataTable(RowProjection projection, AggSpec[][] aggs) throws TransformException
    {
        super(projection, aggs);
    }
    
/*    public Object clone() throws CloneNotSupportedException
    {
      SBADataTable newdt = new SBADataTable();
      if (m_dataCache != null)
        newdt.m_dataCache = (Hashtable<QDR, DataCellInterface>)m_dataCache.clone();
      return _copy(newdt);
    }   */ 
    
    protected Row processCurrentRow(BaseRowIterator iter, ColumnValues extraMembers, long rowIndex) throws TransformException {
      Row row = super.processCurrentRow(iter, extraMembers, rowIndex);
      storeData(row);
      return row;
    }

    protected Hashtable<QDRLite, DataCellInterface> getDataCache()
    {
        if (m_dataCache == null)
            m_dataCache = new Hashtable<QDRLite, DataCellInterface>();
        return m_dataCache;
    }
    
    protected DataCellInterface getCell(BaseRowIterator iter, String col, int colCount) throws TransformException
    {
        return ((XMLDocumentRowIterator)iter).getCell(col, colCount);
    }
    
    protected MemberInterface getMember(BaseRowIterator iter, String col, int colCount) throws TransformException
    {
        return ((XMLDocumentRowIterator)iter).getMember(col, colCount);
    }
    
    
    protected void storeData(Row row) throws TransformException
    {
        DataCell[] cells = row.getCells();
        if (cells == null)
            return;

        // Make a qdr
        MemberCell[] members = row.getMembers();
        
        
        QDRLite qdr = new QDRLite();
        if (members != null)
        {
            for (int i = 0; i < members.length; i++)
            {
                if (members[i] != null && members[i].getMemberInterface() != null)
                    qdr.addDimMemberPair(members[i].getMemberColumnName(), members[i].getMemberInterface().getValue());
            }
        }
        QDRLite qdrStorage = null;
        for (int values = 0; values < cells.length; values++)
        {
            // Store each one 
            try
            {
                qdrStorage = (QDRLite)qdr.clone();
            }
            catch (CloneNotSupportedException e)
            {
                throw new TransformException(e.getMessage(), e);
            }
            if (cells[values] != null && cells[values].getDataCellInterface() != null)
            {
                LayerInterface li = m_projection.getDataLayer();
                qdrStorage.addDimMemberPair(li != null ? li.getValue() : null, cells[values].getDataCellColumnName());
                getDataCache().put(qdrStorage, cells[values].getDataCellInterface());
            }
        }
    }
    
    public DataCellInterface getData(Map<String,Object> qdr)
    {
        return getDataCache().get(qdr);
    }    
}
