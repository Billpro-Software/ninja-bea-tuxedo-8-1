/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/Layer.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/22/06 - 
    jramanat    05/08/06 - Creation
 */

package oracle.dss.dataSource.client;

import oracle.dss.dataSource.common.QueryState;
import oracle.dss.dataSource.common.QueryUtil;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.transform.LayerMetadata;
import oracle.dss.util.transform.LayerInterface;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.TransformUtils;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/Layer.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */
public class Layer implements LayerInterface {
  protected MDObject m_object = null;
  protected QueryState m_state = null;
  
  public Layer(MDObject object, QueryState qs) {
    m_object = object;
    m_state = qs;
  }

  
  public Object getMetadata(String type) throws TransformException {
      if (type == null)
          return null;
    
    Object data = QueryUtil.getLayerMetadata(TransformUtils.convertLayerMetadata(type), m_object);
    if (data != null)
        return data;
          
    if (type.equals(LayerMetadata.CANPIVOT))
    {
        return Boolean.valueOf(true);
    }
/*    else if (type.equals(LayerMetadataMap.LAYER_METADATA_HIERARCHICAL))
    {
        // blm - Selection code moved to dvt-olap
/*        if (m_state.getSelections() != null)
        {
            Selection sel = m_state.getSelections().find(m_object.getUniqueID());
            if (sel != null)
            {
                return Boolean.valueOf(sel.getHierarchy() != null && !sel.getHierarchy().equals(""));
            }
        }*/
       /* return Boolean.valueOf(false);
    }*/
    else if (type.equals(LayerMetadata.MEASURE))
    {
        return Boolean.valueOf(m_object.getUniqueID().equals(m_state.getMeasureDim()));
    }
    else if (type.equals(LayerMetadata.HIERARCHICAL))
    {
        // None right now
        return Boolean.valueOf(false);
    }
    return null;    
  }
  
  public String getValue() throws TransformException {
    return m_object.getUniqueID();
  }
}