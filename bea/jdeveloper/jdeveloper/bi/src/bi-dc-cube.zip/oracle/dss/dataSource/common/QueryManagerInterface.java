/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryManagerInterface.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - bmoroze_bicommon050815
    bmoroze     08/15/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryManagerInterface.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;
import java.util.Vector;
import oracle.dss.util.ErrorHandler;

/**
 * Interface representing some operations that are common to the client
 * and the middle tier but not necessarily promoted through the remote
 * interface
 */
public interface QueryManagerInterface
{
    /**
     * Closes a specified list of <code>Query</code> objects.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param queryList List of the query objects to close.
     *
     * @status Documented
     */
    public void closeQueries(java.util.List queryList);

    

    /**    
     * @hidden
     * Inform all queries of metadata manager database connection
     */
    public String informQueriesOfMetadataManager(boolean available) throws Exception;

    /**
     * @hidden
     * Get the current error handler.
     * 
     * @return current error handler
     */
    public ErrorHandler getErrorHandler();     

    
    /**
     * Cancel current processes on this connection, if possible
     *
     * @return <code>true</code> if the code was found to send an interrupt
     * @status New
     */
    public boolean cancel();    

    
    /**
     * @hidden
     */
    public String getResourceString(String key);

    /**
     * @hidden
     * Get the plugged in application class name for a given pluggable class or interface name, if any
     */
    public Class getPluggableClass(String pluggable);

    /**
     *  @hidden
     * Does this QueryManager require the MetadataManager to do certain 
     * storage operations?
     *
     * @return true if no, false if not (default)
     * 
     */
    public boolean isMetadataManagerNotAvailable();
    
    // NEW TEMPORARY CALLS
    /**
     * @hidden
     */
    //public QueryManagerObject.ReturnObject executeQuery(String queryID, QueryState state) throws Exception; 
    
    /**
     * @hidden
     * @throws java.lang.Exception
     * @return 
     * @param selsChanged
     * @param flags
     * @param target
     * @param source
     * @param state
     * @param queryID
     */
     // blm - Selection code moved to dvt-olap
/*    public QueryManagerObject.ReturnObject executePivot(String queryID, QueryState state, String source, String target, int flags, Selection[] selsChanged) throws Exception;*/

    /**
     * @hidden
     */
    //public QueryManagerObject.ReturnObject executeProperties(String queryID, QueryState state, Object data) throws Exception;

    /**
     * @hidden
     */
    //public QueryManagerObject.ReturnObject executeRefresh(String queryID, QueryState state, int type) throws Exception;

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public QueryManagerObject.ReturnObject executeApplySelections(String queryID, QueryState state, Selection[] selections, Selection oldSel) throws Exception;*/
    
    /**
     * @hidden
     * Return the version number we're connected to
     */
    public String getConnectionVersionInfo(String type);    
    
    /**
     * @hidden
     */
    public Vector getMemberLevel(String hierarchy);    
}
