/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemDrillRequestedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     01/17/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemDrillRequestedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;
import oracle.dss.util.QDR;

/**
 * Informs listeners that an item drill operation has occurred.
 *
 * @status Documented
 */
public class ItemDrillRequestedEvent extends DrillRequestedEvent
{
    /**
     * @hidden
     */
    protected QDR[] m_targets = null;
    
    // javadoc from superclass
    public ItemDrillRequestedEvent(Object source, String item, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags)
    {
        super(source, item, null, drillPath, null, null, drillTarget, null, null, null);
        fl = new BitSet[] {flags};
        m_targets = target;
    }
    
    /**
     * Return the item being drilled.
     * 
     * @return The item being drilled
     * 
     * @status New
     */
    public String getItem()
    {
        return super.getDimension();
    }

    /**
     * Return the Item's members on which to drill
     * 
     * @return drilled members
     * 
     * @status new
     */
    public QDR[] getTargets()
    {
        return m_targets;
    }
    
    /**
     * Return the drill paths for this drill
     * 
     * @return drill paths
     * 
     * @status New
     */
    public String[] getDrillPaths()
    {
        return hier;
    }
    
    /**
     * Return the drill targets for this drill
     * 
     * @return drill targets
     * 
     * @status New
     */
    public String[] getDrillTargets()
    {
        return m_valueParent;
    }
}


