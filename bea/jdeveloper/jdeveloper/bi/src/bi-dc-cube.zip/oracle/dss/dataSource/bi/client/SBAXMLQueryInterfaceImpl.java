/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAXMLQueryInterfaceImpl.java /bibeans_root/23 2009/03/24 11:20:29 mjakubia Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     03/09/07 - 
    imohamma    10/10/06 - 
    bmoroze     08/04/06 - 
    imohamma    07/19/06 - 
    jramanat    07/06/06 - Creation
 */

package oracle.dss.dataSource.bi.client;

import oracle.bi.web.soap.internal.QueryResults;
import oracle.bi.web.soap.internal.ReportRef;

import oracle.bi.web.soap.internal.XMLQueryExecutionOptions;
import oracle.bi.web.soap.internal.XMLQueryOutputFormat;
import oracle.bi.web.soap.internal.XmlViewServiceSoap;

import java.rmi.RemoteException;

import java.util.Vector;
import java.util.logging.Level;

import java.util.logging.Logger;

import oracle.bi.presentation.soap.connection.BISoapConnection;

import oracle.bi.presentation.soap.connection.BISoapException;

import oracle.dss.connection.common.CB;
import oracle.dss.dataSource.client.QueryRowIterator;
import oracle.dss.dataSource.common.DimTree;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.selection.XMLEvaluator;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.drill.ItemDrill;
import oracle.dss.util.persistence.ObjectScope;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.transform.TransformException;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAXMLQueryInterfaceImpl.java /bibeans_root/23 2009/03/24 11:20:29 mjakubia Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public class SBAXMLQueryInterfaceImpl extends SBAQueryInterfaceImpl implements XMLEvaluator
{
  private XMLQueryTransform m_transform;

    private static Logger m_logger = Logger.getLogger(SBAXMLQueryInterfaceImpl.class.getName());
    
  public SBAXMLQueryInterfaceImpl(Query query) {
    super(query);
    //m_drillSupport = new XMLDrillSupport(this);
    m_transform = new XMLQueryTransform();
  }
  
  public String generateXML(String[] replaceTheseColumns, String[] withTheseColumns) throws QueryException {
    DimTree dt = m_query._getQueryState().getDimTree();
    if(dt == null || dt.getNodeCount() == 0)
      return null;

    String queryXml = null;
    try {
        XMLContext context = new XMLContext();
        ObjectScope scope = new ObjectScope();
        scope.addObject(oracle.dss.selection.XMLEvaluator.class.getName(), this);
        context.setScope(scope);
      queryXml = m_query.getXMLAsString(context);
      m_logger.log(Level.FINE, queryXml);        
    }
    catch(Exception e) {
      throw new QueryException(e.getMessage(), e);
    }
    //return "<![CDATA[" + m_transform.queryToSaw(queryXml) + "]]>";
    return m_transform.queryToSaw(queryXml);
  }

  protected void evaluate(boolean refresh) throws QueryException {    
    try {
      if (m_rt != null)
        m_rt.close();
      m_rt = null;
        QueryRowIterator ri = null;
      if (m_query.isEvaluateCursor())
      {
        String xml = generateXML(null, null);
        if (xml != null) {
            m_logger.log(Level.FINE, xml);        
            ri = getQueryRowIterator(xml, refresh);
        }
        if (ri != null)
            m_rt = new SBAResultTable(new RowIteratorProjection(ri, m_query));        
      }
      else
      {
        m_rt = new SBAResultTable(new RowIteratorProjection(ri, m_query));
      }
      releaseDAs();
    }
    catch (Exception e) {
      throw new QueryException(e.getMessage(), e);
    }
  }
  
  // query is XML 
  private QueryRowIterator getQueryRowIterator(String xml, boolean refresh) throws QueryException {
      
      BISoapConnection biSoapConnection = (BISoapConnection)getConnection().getProperty(CB.CONNECTION).getObjValue();
      String sessionID = biSoapConnection.getLogonToken().getStringToken();
      XmlViewServiceSoap xmlService = null;
      try
      {
          xmlService = biSoapConnection.getXmlViewService();
      }
      catch (BISoapException e)
      {
          m_logger.logp(Level.SEVERE, getClass().getName(), "getQueryRowIterator", e.getCause() != null ? e.getCause().getMessage() : e.getMessage(), e.getCause() != null ? e.getCause() : e);
          throw new QueryException(e.getMessage(), e);
      }
      ReportRef report = new ReportRef();
      report.setReportXml(xml);      
      QueryResults qResult = null;

      XMLQueryExecutionOptions queryExecutionOptions = new XMLQueryExecutionOptions();
      //false, 100, refresh, false, "xml"
      
      queryExecutionOptions.setAsync(false);
      queryExecutionOptions.setMaxRowsPerPage(100);
      queryExecutionOptions.setRefresh(refresh);
      queryExecutionOptions.setPresentationInfo(false);
      queryExecutionOptions.setType("xml");
      
      qResult = xmlService.executeXMLQuery(report,
                                                    XMLQueryOutputFormat.SAW_ROWSET_SCHEMA_AND_DATA,
                                                    queryExecutionOptions,
                                                    null,
                                                    sessionID);
      String result = qResult.getRowset();
      try
      {
        return new XMLDocumentRowIterator(result, m_query, true);
      }
      catch (TransformException e)
      {
          m_logger.logp(Level.SEVERE, getClass().getName(), "getQueryRowIterator", e.getCause() != null ? e.getCause().getMessage() : e.getMessage(), e.getCause() != null ? e.getCause() : e);
          throw new QueryException(e.getMessage(), e);          
      }
      /*
      // Connected through SAW
      BISoapConnection biSoapConnection = (BISoapConnection)getConnection().getProperty(CB.CONNECTION).getObjValue();
      String sessionID = biSoapConnection.getLogonToken().getStringToken();
      String url = "http://imohamma-pc/analytics/saw.dll";
      String request = SOAPUtility.getRequestHeader("executeXMLQuery") +
                               SOAPUtility.getComplexParameter("report", new String[][] {{"reportXml", xml}}) +
                               SOAPUtility.getParameter("outputFormat", "SAWRowsetSchemaAndData") +
                               SOAPUtility.getComplexParameter("executionOptions", new String[][] {{"async", "false"},{"maxRowsPerPage", "100"},{"refresh", "false"},{"presentationInfo", "false"},{"type", "xml"}} ) +
                               SOAPUtility.getParameter("sessionID", sessionID) +
                               SOAPUtility.getRequestFooter("executeXMLQuery");
      String result = SOAPUtility.executeRequest(url + CB.SOAP_XMLVIEW, request);
      //XMLDocument doc = SOAPUtility.parseXML(result);
      return new XMLDocumentRowIterator(result, m_query, true);
      */
  }
  
    private boolean isFieldOK(String field)
    {
        return field.equals(DataFilter.ITEM_ID_PROPERTY) || field.equals(DataFilter.CMP_VALUE_PROPERTY);
    }
    
    private boolean isDataFilter(Object object)
    {
        return object instanceof DataFilter;
    }
    
    private boolean isItemDrill(Object object)
    {
        return object instanceof ItemDrill;
    }
    
    private boolean isItemDrillFieldOK(String field)
    {
        return field.equals(ItemDrill.ITEM_PROPERTY);
    }
    
    public String processXML(Object value, String field, Object object)
    {
        if (isDataFilter(object) && isFieldOK(field) && value != null)
        {
            // Process ID (escape it)
            BaseDataFilter df = (BaseDataFilter)object;
            // Remove prefix & subject area
            String uniqueId = value.toString();
            // Check data type
            int dotLoc = uniqueId.indexOf("."); 
            if (dotLoc == -1)
                return uniqueId;
            
            String id = uniqueId.substring(dotLoc+1);
            // Reconstruct with escaping
            dotLoc = id.indexOf(".");
            if (dotLoc == -1)
                return id;
            String escapedID = "\"" + id.substring(0, dotLoc) + "\".\"" + id.substring(dotLoc+1) + "\"";
            if (df.isIgnoreCase() && field.equals(DataFilter.ITEM_ID_PROPERTY))
            {
                // Check MDObject & type to make sure it's a string
                try
                {
                    MDItem item = (MDItem)m_query.getMDObject(MM.UNIQUE_ID, uniqueId, MM.ITEM);
                    if (item != null && item.getDatatype() != null && item.getDatatype().equals(MM.STRING))
                        return "Upper(" + escapedID + ")";
                }
                catch (MetadataManagerException e)
                {
                    m_logger.logp(Level.SEVERE, getClass().getName(), "processXML", e.getCause() != null ? e.getCause().getMessage() : e.getMessage(), e.getCause() != null ? e.getCause() : e);
                }
            }
            return escapedID;
        }
        if (isItemDrill(object) && isItemDrillFieldOK(field) && value != null)
        {
            // Determine if we have a data filter on the item (value).  If so, don't add a new
            // filter due to the drill, and indicate this by returning null
            BaseDataFilter[] filters = m_query._getQueryState().getDataFilters();
            if (_findMatchingDataFilter(filters, value))
                return null;
            return "true";     // this tells ItemDrill to give up its filter as designed (anything but null)
        }
        return value != null ? value.toString() : null;
    }
    
    private boolean _findMatchingDataFilter(BaseDataFilter[] filters, Object item)
    {
        if (item == null || filters == null)
            return false;
        
        // Check for a matching filter
        for (int f = 0; f < filters.length; f++)
        {
            if (filters[f] instanceof DataFilter)
            {
                DataFilter df = (DataFilter)filters[f];
                if (item.equals(df.getItem()))
                {
                    // Make sure the DF only has one comparison value--then the drill has to match the filter
                    Vector cmpVals = df.getCmpValues();
                    if (cmpVals != null && cmpVals.size() == 1)
                    {
                        // We already have a data filter based on this item--don't add one for drill
                        return true;
                    }
                }
            }
            else if (filters[f] instanceof CompoundDataFilter)
            {
                CompoundDataFilter cdf = (CompoundDataFilter)filters[f];
                BaseDataFilter[] moreFilters = cdf.getDataFilters();
                if (_findMatchingDataFilter(moreFilters, item))
                    return true;
            }
        }        
        return false;
    }
}