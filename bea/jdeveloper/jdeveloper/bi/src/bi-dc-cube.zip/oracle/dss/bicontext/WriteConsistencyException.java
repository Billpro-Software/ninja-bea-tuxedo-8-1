/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;

/**
 * Indicates an attempt to save an object which has already been 
 * saved by another session.  In order to avoid silently loosing another 
 * users changes, the second writer fails with a WriteConsistencyException. 
 * The client should reload the object, ask the user to confirm the 
 * reapplication of changes, and save again.  
 * <p>
 * To handle this exception in particular, catch it before you catch a
 * <code>NamingException</code>.
 * 
 * @status New
 */
public final class WriteConsistencyException extends BINamingException
{
    
   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    */
    public WriteConsistencyException(Class resBundleClass, String errorCode, String[] params, Locale locale)
    {
        super(resBundleClass, errorCode, params, locale, null);
    }

   

}
