/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataFilterChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/10/05 - bmoroze_datafilters_3
    bmoroze     06/09/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataFilterChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import oracle.dss.selection.dataFilter.BaseDataFilter;

/**
 * Informs listeners of changes to one or more <code>BaseDataFilter</code> objects.
 * This event is fired <I>before</I> the <code>DataChangedEvent</code>.
 * The <code>BaseDataFilter</code> cannot be consumed.
 *
 * @status New
*/
public class DataFilterChangedEvent extends DataFilterEvent
{
    /**
     * Constructs the event.
     * 
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param filters  A list of the <code>BaseDataFilter</code> objects that
     *                    changed.
     *
     * @status New
     */
    public DataFilterChangedEvent(Object source, BaseDataFilter[] filters) {
        super(source, filters, false);
    }    
    
    /**
     * Constructs the event.
     * 
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param filters  A list of the <code>BaseDataFilter</code> objects that
     *                    changed.
     * @param removed     Were these filters removed?
     *
     * @status New
     */
    public DataFilterChangedEvent(Object source, BaseDataFilter[] filters, boolean removed) {
        super(source, filters, removed);
    }        
}

