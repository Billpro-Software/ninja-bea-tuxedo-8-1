/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/metadataManager/common/MDItemCalc.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     06/15/07 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/metadataManager/common/MDItemCalc.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.metadataManager.common;


public class MDItemCalc extends MDItem
{
    public MDItemCalc()
    {
        setObjectType(MM.CALCULATION_ITEM);
    }    
    
    public void setRootFolder(String rootFolder)
    {
        super.setStrPropertyValue(MM.ROOT_FOLDER, rootFolder);        
    }
    
    public String getRootFolder()
    {
        return super.getStrPropertyValue(MM.ROOT_FOLDER);
    }
    
    public void setDatatype(String dataType)
    {
        super.setStrPropertyValue(MM.DATA_TYPE, dataType);
    }
    
    public void setExpression(String expression)
    {
        super.setStrPropertyValue(MM.EXPRESSION, expression);
    }
    
    public String getExpression()
    {
        return super.getStrPropertyValue(MM.EXPRESSION);
    }
    
    public void setUniqueID(String driverType, String id)
    {
        super.setDriverType(driverType);
        super.setUniqueID(driverType, id);
    }
    
}
