/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.dataSource.bi.client;

import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

import oracle.dss.dataSource.common.QueryException;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;

public class XMLQueryTransform {
  private String querytoSaw = "queryToSaw.xsl";
  private String sawToQuery = "sawToQuery.xsl";

  public String queryToSaw(String xml) throws QueryException {
    return transform(querytoSaw, xml);
  }
  
  public String sawToQuery(String xml) throws QueryException {
    return transform(sawToQuery, xml);
  }

  private String transform(String xsl, String xml) throws QueryException {
    try {
      DOMParser parser = new DOMParser();
      StringReader sr = new StringReader(xml);
      parser.parse(sr);
      XMLDocument xmlDoc = parser.getDocument();

      StringWriter strWriter = new StringWriter();
      PrintWriter writer = new PrintWriter(strWriter);
      XSLProcessor processor = new XSLProcessor();
      InputStream is = this.getClass().getResourceAsStream(xsl);
      XSLStylesheet styleSheet = processor.newXSLStylesheet(is);
      processor.processXSL(styleSheet, xmlDoc, writer);
        
      // Clean up
      writer.close();
      strWriter.close();
      xmlDoc.freeNode();
      is.close();
      parser.reset();
      sr.close();
      return strWriter.toString();
    }
    catch(Exception e) {
      throw new QueryException(e.getMessage(), e);
    }
  }
}