/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.server.drivers;

// Imports
import oracle.dss.metadataManager.common.MetadataProviderException;

/**
 * @hidden
 */
public class MetadataDriverException extends MetadataProviderException
{
   /**
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    *
    * @status documented
    */
    public MetadataDriverException(Class resBundleClass, String errorCode, Object[] params, String driverType)
    {
        super(resBundleClass, errorCode, params, driverType);
    }

   /**
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param prevException  The exception that underlies this exception.
    *
    * @status documented
    */
    public MetadataDriverException(Class resBundleClass, String errorCode, Object[] params, String driverType, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, driverType, prevException);
    }

    /**
     * Constructor for an exception that cannot be localized and that passes
     * on an underlying exception.
     *
     * @param msg  The text of the error message.
     * @param prevException The exception that underlies this exception.
     *
     * @status documented
     */
    public MetadataDriverException(String msg, String driverType, Throwable prevException)
    {
        super(msg, driverType, prevException);
    }
}