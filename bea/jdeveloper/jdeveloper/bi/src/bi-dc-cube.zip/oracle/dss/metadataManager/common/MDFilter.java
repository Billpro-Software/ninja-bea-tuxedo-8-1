/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import oracle.dss.bicontext.BIFilter;

/**
 * @hidden
 * A custom filter for filtering each of the search results AFTER the main search
 * is finished.
 */
public interface MDFilter extends BIFilter
{
    /**
     * Determines whether the particular search result should be included in the
     * final search outcome
     *
     * @return  <code>true</code> if the search result should be included
     *          <code>false</code> otherwise
     * @status New
     */
    public boolean evaluate(MDObject mdObj);
}