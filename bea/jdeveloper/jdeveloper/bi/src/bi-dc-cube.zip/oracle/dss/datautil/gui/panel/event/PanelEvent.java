/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui.panel.event;

import java.util.EventObject;

/**
 * Describes event types that are related to a particular panel.
 *
 * @status documented
 */

public class PanelEvent extends EventObject
{
    /////////////////////////////////////////////////////////////////////
    // PUBLIC CONSTANTS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * The PanelEvent type is enabled.
     *
     * @status documented
     */
    public static String PANELEVENT_ENABLE = "enable";
    
    /**
     * The PanelEvent type is disabled.
     *
     * @status documented
     */
    public static String PANELEVENT_DISABLE = "disable";
    
    /////////////////////////////////////////////////////////////////////
    // NON PUBLIC MEMBERS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * The Panel Event type.
     *
     * @status protected
     */
    protected String m_eventType = null;
    
    /**
     * The target panel info.
     *
     * @status protected
     */
    protected Object m_targetPanelInfo = null;
    
    /////////////////////////////////////////////////////////////////////
    // CONSTRUCTOR
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Constructor that specifies all arguments.
     *
     * @param source The source of the event. This is the reference to the 
     * <code>StandardPanel</code> from which the event originated.
     * @param nEventType The type of the event.
     * @param targetPanelInfo The information about the target panel.
     *
     * @status documented
     */
    public PanelEvent ( Object source, String eventType, Object targetPanelInfo ) 
    {
        super ( source );
        m_eventType = eventType;
        m_targetPanelInfo = targetPanelInfo;
    }        
    
    /////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Retrieves the identifier of the target panel if the event type is 
     * <code>PANELEVENT_ENABLE</code> or <code>PANELEVENT_DISABLE</code>.
     *
     * @return The target panel identifier.
     *
     * @status documented
     */
    public String getTargetPanelId ( )
    {
        if ( ! m_eventType.equalsIgnoreCase ( PANELEVENT_ENABLE ) &&
             ! m_eventType.equalsIgnoreCase ( PANELEVENT_DISABLE ) )            
            return null;

        if ( null == m_targetPanelInfo || 
             ! ( m_targetPanelInfo instanceof String ) )
             return null;
            
        return ( String ) m_targetPanelInfo;                
    }        

    /**
     * Retrieves the information about the target panel.
     *
     * @return The information about the target panel.
     *
     * @status documented
     */
    public Object getTargetPanelInfo ( )
    {
        return m_targetPanelInfo;
    }
    
    /**
     * Retrieves the type of the event.
     *
     * @return The type of the event.
     *
     * @status documented
     */
    public String getType ( )
    {
        return m_eventType;
    }        
}

    
