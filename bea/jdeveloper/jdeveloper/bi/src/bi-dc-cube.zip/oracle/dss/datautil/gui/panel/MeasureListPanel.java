/*
 * MeasureListPanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.event.MouseEvent;

import java.text.MessageFormat;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;

import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.QueryBuilderUtils;
import oracle.dss.datautil.gui.ResourceCache;
import oracle.dss.datautil.gui.Utils;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDSearchControls;

import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.gui.DefaultDirTreeModel;
import oracle.dss.bicontext.gui.DirTree;
import oracle.dss.bicontext.gui.DirTreeModel;
import oracle.dss.bicontext.gui.TreeSorter;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * Allows a user to select from a list of measures. Use this panel when you want
 * to have the list of measures tightly integrated in the application. For example,
 * you might include a <code>MeasureListPanel</code> on the main page of an
 * application so that if a user selects a different measure, then view updates 
 * to display that measure.
 *
 * @see oracle.dss.datautil.gui.dialog.MeasureListDialog 
 *
 * @status documented
 */
 
public class MeasureListPanel extends BaseLayoutPanel {
    /////////////////////
    //
    // Members
    //
    /////////////////////

  /**
	 * @hidden
   *
   * Determines whether shortcuts are accessible through the GUI.
   *
   * @status hidden
   */
  protected static boolean m_bShowShortCuts = true;

	// The MetadataManager instance.
    private MetadataManager m_metadataManager;

    // The tree component.
	private DirTree m_dirTree;

	// The filter
	private BIFilter m_filter;

    // The count label
    private JLabel m_lblCount;
    
    // The SearchControls used to filter which measures appear in the list.
    private MDSearchControls m_searchControls = new MDSearchControls();
    
    // Selections used in validating the measure selection.
    private Hashtable m_selections;

    /**
     *
     * @status private
     */
    private ResourceCache m_resourceCache = new ResourceCache("oracle.dss.datautil.gui.resource.DataUtilGUIBundle");

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    /**
     * Constructor that specifies all arguments for displaying the 
     * <code>MeasureListPanel</code>.
     *
     * @param metadataManager A <code>MetadataManager</code> object that is used
     * for populating the tree with folders and measures.
     * @param filter A <code>BIFilter</code> object that filters the tree model.
     *
     * @status documented
     */
	public MeasureListPanel (MetadataManager metadataManager, BIFilter filter) {
		super();
        m_metadataManager = metadataManager;
		setFilter(filter);
		m_dirTree = makeTree(metadataManager);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        JPanel content = new JPanel(new BorderLayout());
        content.add(getPanelDescription(), BorderLayout.NORTH);
        content.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        content.add(new JScrollPane(m_dirTree), BorderLayout.CENTER);
        add(content, BorderLayout.CENTER);
    }

    /**
     * Constructor that specifies only a <code>MetadataManager</code> object.
     *
     * @param metadataManager A <code>MetadataManager</code> object that is used
     * for populating the tree with folders and measures.
     *
     * @status documented
     */
	public MeasureListPanel(MetadataManager metadataManager) {
		this(metadataManager, null);
	}

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

  	/**
     * Retrieves the <code>DirTree</code> object that is used to display
     * the folders and measures.
   	 *
   	 * @return The <code>DirTree</code> object.
   	 *
   	 * @status documented
   	 */
	public DirTree getTree() {
		return m_dirTree;
	}

  	/**
     * Retrieves the <code>String</code> that represents a single measure.
     * If only one measure is selected, then it retrieves that measure.
     * If multiple measures are selected, then it retrieves the first selected
     * measure.  
   	 *
   	 * @return The selected measure.
   	 *
   	 * @status documented
   	 */
	public String getSelectedMeasure() {
        String[] measures = getSelectedMeasures();
        if (measures == null || measures.length == 0) {
            return null;
        }
        else {
            return measures[0];
        }
	}
    
    /**
     * @hidden
     * @param selections The Hashtable of selections used in validating the measures.
     * @status new
     */
    public void setValidationSelections(Hashtable selections) {
        m_selections = selections;
    }
    
    private boolean isValid(Object object) {        
    /** gek 11/03/06
        return QueryBuilderUtils.isValid(m_selections, QueryBuilderUtils.getCalcStep(Utils.getObject(object)), null, m_metadataManager);
    */
      return true;
    }

  	/**
     * Retrieves an array that contains a list of all the selected measures.  
     * If only one measure is selected, then it retrieves an array of size 1 
     * that contains the selected measure.  If multiple measures are selected,
     * then it retrieves an appropriately sized array that contains all the 
     * selected measures.
   	 *
   	 * @return The list of the selected measures.
  	 *
   	 * @status documented
   	 */
	public String[] getSelectedMeasures() {
        TreePath[] paths = m_dirTree.getSelectionPaths();
        if (paths == null || paths.length == 0) {
            return null;
        }
        Vector nodes = new Vector();
        String strUniqueID;
        String strObjectType;
        for (int i = 0; i < paths.length; i++) {
            if (paths[i] != null && paths[i].getLastPathComponent() != null) {
                strObjectType = Utils.getObjectType(paths[i].getLastPathComponent());
                if ( (MM.MEASURE.equals(strObjectType)) || (MM.CALCULATION.equals(strObjectType)) ) {
                    if (isValid(paths[i].getLastPathComponent())) {
                        strUniqueID = Utils.getUniqueID(paths[i].getLastPathComponent(), null);
                        if (strUniqueID != null) {
                            nodes.add(strUniqueID);
                        }
                    }
                }
            }
        }
        return (String[])nodes.toArray(new String[nodes.size()]);
    }

  	/**
     * Retrieves the <code>BIFilter</code> object that filters the tree model.
   	 *
   	 * @return The <code>BIFilter</code> object.
   	 *
   	 * @status documented
   	 */
	public BIFilter getFilter() {
		return m_filter;
	}

  	/**
     * Specifies the <code>BIFilter</code> object that filters the tree model.
   	 *
   	 * @param filter The <code>BIFilter</code> object.
   	 *
   	 * @status documented
   	 */
	public void setFilter(BIFilter filter) {
		m_filter = filter;
	}
        
   /**
     * Specifies the type of display labels for this 
     * <code>MeasureListPanel</code> object.
     *
     * @param  strDisplayMemberLabelType The display member label type. Valid values are
     *    enumerations from <code>oracle.dss.util.LayerMetadataMap</code> such as
     *    long, short, or medium labels.
     *
     * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_VALUE
     * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
     * @see oracle.dss.util.MetadataMap#METADATA_DISPLAYNAME
     *
     * @status documented
     */
    public void setDisplayLabelType(String strDisplayMemberLabelType) {
        if (m_dirTree != null) {
            TreeCellRenderer treeCellRenderer = m_dirTree.getCellRenderer();
            if ( (treeCellRenderer != null) && (treeCellRenderer instanceof MDObjectDirTreeCellRenderer) ) {
                ((MDObjectDirTreeCellRenderer)treeCellRenderer).setDisplayLabelType(strDisplayMemberLabelType);
            }
        }
    }
    
    /**
     * @hidden
     * Specifies an array of folders (that contain measures) 
     * whose names are displayed in the QueryBuilder.
     * Only those items within the folders 
     * whose names are specified in the array are displayed.
     * See the "Customizing the Display of Folders in QueryBuilder" topic in the
     * Help system for more information and examples.
     * 
     * The Select Measure dialog, which is controlled by the MeasureListPanel,
     * inherits the search paths from the Items panel.
     *
     * @param searchPaths A string array of folder names.
     *
     * @see #setSearchPathNames 
     *
     * @status hidden
     */
    public void setSearchPaths(String[] searchPaths) {
        m_searchControls.setSearchPaths(searchPaths);
    }
    
    /**
     * @hidden
     * Specifies an array of names to use for renaming folders (that contain 
     * measures) for display in the QueryBuilder.
     * Only those items within the folders 
     * whose names are specified in the array are displayed in the panel.
     * See the "Customizing the Display of Folders in QueryBuilder" topic in the
     * Help system for more information and examples.     
     *
     * The Select Measure dialog, which is controlled by the MeasureListPanel,
     * inherits the search path names from the Items panel.
     * 
     * @param searchPathNames A string array of folder names.
     *
     * @see #setSearchPaths
     *
     * @status hidden
     */
    public void setSearchPathNames(String[] searchPathNames) {
        m_searchControls.setSearchPathNames(searchPathNames);
    }

    /**
     * @hidden
     * 
     * Specifies whether shortcuts are accessible through the GUI.
     *
     * @param bEnableShortcuts A <code>boolean</code> which is <code>true</code> 
     *        if shortcuts are to be shown in the GUI and <code>false</code> 
     *        otherwise.
     *
     * @status hidden
     */
    public static void setShowShortcuts (boolean bShowShortcuts) {
        m_bShowShortCuts = bShowShortcuts;
    }
  
    /**
     * @hidden
     * 
     * Determines whether shortcuts are accessible through the GUI.
     *
     * @return <code>boolean</code> which is <code>true</code> if shortcuts are
     *         to be shown in the GUI and <code>false</code> otherwise.
     *
     * @status hidden
     */
    public static boolean isShowShortcuts() {
        return m_bShowShortCuts;
    }
        
    /*
     * @hidden
     */
    public void expandTree(String strMeasureID) { 
        Utils.expandPath(m_dirTree, Utils.getLowestCommonPath(m_metadataManager, strMeasureID, null));
        MDMeasure mdMeasure = QueryBuilderUtils.getMeasure(m_metadataManager, strMeasureID, null);
        if (mdMeasure != null) {
            DefaultMutableTreeNode node = Utils.getNode(m_dirTree, mdMeasure.getPath());
            if (node != null) {
                TreePath treePath = new TreePath(node.getPath());
                if (treePath != null) {
                    m_dirTree.setSelectionPath(treePath);
                }                
            }
        }
    }
 
    /////////////////////
    //
    // Protected Methods
    //
    /////////////////////

    /////////////////////
    //
    // Private Methods
    //
    /////////////////////

	private DirTree makeTree(MetadataManager metadataManager) {
		DirTree dirTree = new DirTree(makeModel(metadataManager));
		dirTree.addTreeSelectionListener(new TreeSelectionListener() {
	    	public void valueChanged(TreeSelectionEvent e) {
                updateCountLabel();
    		}
		});
        dirTree.addTreeExpansionListener(new TreeExpansionListener () {
            public void treeCollapsed(TreeExpansionEvent event) { 
                updateCountLabel();
            }
            public void treeExpanded(TreeExpansionEvent event)  {
                updateCountLabel();
            }
        });
        dirTree.getModel().addTreeModelListener(new TreeModelListener () {
            public void treeNodesChanged(TreeModelEvent e) { }
            public void treeNodesInserted(TreeModelEvent e)  { }
            public void treeNodesRemoved(TreeModelEvent e) { }
            public void treeStructureChanged(TreeModelEvent e) { 
                updateCountLabel();
            }
        });
        dirTree.setCellRenderer(new MDObjectDirTreeCellRenderer());
		dirTree.setRootVisible(false);
		dirTree.setShowsRootHandles(true);
		return dirTree;
    }
       
    private DefaultDirTreeModel makeModel(MetadataManager metadataManager) {
     	BasicAttributes attributes = new BasicAttributes();
        BasicAttribute attribute =
            new BasicAttribute(MM.OBJECT_TYPE, MM.MEASURE);
        attribute.add(MM.CALCULATION);

        attributes.put(attribute);
        attributes.put(MM.SORT, new Boolean(true));

        TreeSorter treeSorter = 
          new TreeSorter (new String[] {MM.FOLDER, MM.MEASURE, MM.CALCULATION});

        // SELECTIVE_ONELEVEL_SCOPE now works properly with MDM based measures
        m_searchControls.setSearchScope(MDSearchControls.SELECTIVE_ONELEVEL_SCOPE);
        // searchControls.setSearchScope (BISearchControls.ONELEVEL_SCOPE_WITH_FOLDERS);
        m_searchControls.setResultFilter(m_filter);

        // gek 10/10/03 Update SearchControls to include short cuts
        if (isShowShortcuts()) {
          DataUtils.includeShortCuts (m_searchControls);
        }

        return new DefaultDirTreeModel(metadataManager.getMDRoot(), attributes,
            m_searchControls, treeSorter, "Root Name", "rootIconKey");
    }
  
    private JPanel getPanelDescription() {
        JPanel pnlDescription = new JPanel(new BorderLayout());
        JLabel lblMeasures = new JLabel(StringUtils.stripMnemonic(m_resourceCache.getIntlString("measuresLabel")));
        lblMeasures.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(m_resourceCache.getIntlString("measuresLabel")));
        lblMeasures.setLabelFor(m_dirTree);
        lblMeasures.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        pnlDescription.add(lblMeasures, BorderLayout.CENTER);
        m_lblCount = new JLabel(m_resourceCache.getIntlString("defaultMeasuresCount"));
        m_lblCount.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        pnlDescription.add(m_lblCount, BorderLayout.EAST);
        return pnlDescription;
    }

    private void updateCountLabel() {
        String  s1 = Integer.toString(getSelectedCount(m_dirTree));
        String  s2 = Integer.toString(getTotalCount(m_dirTree));
        String[] args = new String[] {s1, s2};
        MessageFormat messageFormat = new MessageFormat(m_resourceCache.getIntlString("measuresCount"));
        m_lblCount.setText(messageFormat.format(args));
    }

    private int getSelectedCount(JTree tree) {
        int intSelectedCount = 0;
        if (tree != null) {
            TreePath[] paths = m_dirTree.getSelectionPaths();
            if ( (paths != null) && (paths.length > 0) ) {
                Vector nodes = new Vector();
                String strObjectType;
                for (int i = 0; i < paths.length; i++) {
                    if ( (paths[i] != null) && (paths[i].getLastPathComponent() != null) ) {
                        strObjectType = Utils.getObjectType(paths[i].getLastPathComponent());
                        if ( (MM.MEASURE.equals(strObjectType)) ||
                             (MM.CALCULATION.equals(strObjectType)) ) {
                            intSelectedCount++;
                        }
                    }
                }
            }
        }
        return intSelectedCount;
    }

    private int getTotalCount(JTree tree) {
        int intSize=0;
        if (tree != null) {
            Object root = tree.getModel().getRoot();
            if (root instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode)root;
                DefaultMutableTreeNode node;
                Object object;
                String strObjectType;
                for ( Enumeration e = rootNode.preorderEnumeration(); e.hasMoreElements(); ) {
                    object = e.nextElement();
                    if (object instanceof DefaultMutableTreeNode) {
                        node = (DefaultMutableTreeNode)object;
                        if (tree.isVisible(new TreePath(node.getPath()))) {
                            strObjectType = Utils.getObjectType(node);
                            if ( (MM.MEASURE.equals(strObjectType)) ||
                                 (MM.CALCULATION.equals(strObjectType)) ) {
                                intSize++;
                            }
                        }
                    }
                }
            }
        }
        return intSize;
    }
}