/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.builder;

import java.awt.BorderLayout;
import java.awt.Component;

import oracle.bali.ewt.wizard.WizardPage;

public class TrainWizardPage extends WizardPage {
    
    /*
     * Public
     */
     
    public TrainWizardPage(Component c, String s, WizardTrain wt) {
        super(c, s);
        m_c = c;
        BuilderPanel bp = new BuilderPanel(new BorderLayout()) {
            public void initialize() {
                if ( (m_c != null) && (m_c instanceof BuilderPanel) ) {
                    ((BuilderPanel)m_c).initialize();
                }
            }
            
            public void setContext(oracle.dss.builder.BuilderContext bc) {
                if ( (m_c != null) && (m_c instanceof BuilderPanel) ) {
                    ((BuilderPanel)m_c).setContext(bc);
                }
            }
        };
        bp.add(wt, BorderLayout.WEST);
        bp.add(c, BorderLayout.CENTER);
        setContent(bp);
    }
    
    /**
     * Retrieves the component used within the wizard page
     * @return
     */
    public Component getInteractiveArea()
    {
        return m_c;
    }

    /**
     * Sets the component within the wizard page
     * @param area
     */
    public void setInteractiveArea(Component area)
    {
        BuilderPanel _panel = (BuilderPanel)getContent();        
        if (_panel != null && area != null)
        {
            _panel.remove(m_c);
            _panel.add(area);
            
            _panel.validate();
            _panel.repaint();
        }
    }
    
    /*
     * Private
     */
     
    private Component m_c = null;
    private WizardTrain m_wt = null;
}