/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryCapabilities.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/11/05 - Fix item handling issues for relational; start 
                           isSupported API implementation 
    bmoroze     08/11/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryCapabilities.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.client;

import oracle.dss.datautil.QueryEditorCapabilities;

/**
 * Constants for isSupported Query API method
 * @status New
 */
public interface QueryCapabilities extends QueryEditorCapabilities
{
}
