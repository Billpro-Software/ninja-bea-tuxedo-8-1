/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.client;

import javax.swing.undo.UndoableEditSupport;
import javax.swing.event.UndoableEditListener;

import oracle.dss.dataSource.common.ListenerLists;
import oracle.dss.dataSource.common.UndoAvailableEvent;

/**
 * @hidden
 * Class designed to store and fire events to listeners on the client (contains Swing undo listener support).
 */
public class ClientListenerLists extends ListenerLists
{
    private transient UndoableEditSupport m_undoableSupport = new UndoableEditSupport();    
    
    /**
     * @hidden
     * Fire the undoAvailable event to all listeners.
     *
     * @param e event
     */
    public void fireUndoAvailableEvent(UndoAvailableEvent e) {
        super.fireUndoAvailableEvent(e);
        
        m_undoableSupport.postEdit(new QueryUndoableEdit(e.getEdit()));        
    }
    
    
    public void addUndoableEditListener(UndoableEditListener l)
    {
        m_undoableSupport.addUndoableEditListener(l);
    }
    
    public void removeUndoableEditListener(UndoableEditListener l)
    {
        m_undoableSupport.removeUndoableEditListener(l);
    }
    
    
}
