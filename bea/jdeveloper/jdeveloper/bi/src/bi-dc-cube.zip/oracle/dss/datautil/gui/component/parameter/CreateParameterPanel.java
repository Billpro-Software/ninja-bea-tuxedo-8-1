/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/CreateParameterPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.parameter;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.parameter.impl.CreateParameterPanelModelImpl;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.queryBuilder.DataFilterUtils;
import oracle.dss.queryBuilder.DataFiltersPanel;
import oracle.dss.queryBuilder.ItemItemsTreeNode;
import oracle.dss.queryBuilder.QBUtils;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.parameter.BaseParameter;
import oracle.dss.util.gui.component.ComponentNames;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.comboBox.TreeListCombo;
import oracle.dss.util.gui.component.comboBox.TreeListComboModel;
import oracle.dss.util.gui.component.tree.CheckTree;
import oracle.dss.util.gui.component.tree.Checkable;


/**
 * <pre>
 * <code>CreateParameterPanel</code>.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   08/02/07 - Improve data error handling.
 *    gkellam   06/14/07 - Fix Bug 6025518 - QueryBuilder: Parameter Dlg:
 *                         'Name' and 'Default Value' fields have no mnemonic.
 *    gkellam   04/21/07 - Remove JTabbedPanels.
 *    gkellam   03/08/07 - Fix parameter edit issues.
 *    gkellam   03/06/07 - Adjust panel size.
 *    gkellam   03/04/07 - Continue parameter GUI tweaks.
 * 
 */
public class CreateParameterPanel extends JPanel {
  private ComponentContext m_componentContext = null;
  private CreateParameterPanelModel m_createParameterPanelModel = null;
  private static final String RESOURCE_BUNDLE = 
    "oracle.dss.datautil.gui.component.parameter.resource.ParameterBundle";
  private JTextField m_jTextFieldUserPrompt = null;
  private DataFiltersPanel m_dataFiltersPanel = null;
  private boolean m_bStandard = true;
  private JLabel m_jLabelShare = null;
  private JRadioButton m_jRadioButtonEach = null;
  private JRadioButton m_jRadioButtonAll = null;
  private JCheckBox m_jCheckBoxIndexValue = null;
  private JCheckBox m_jCheckBoxLimitValues = null;
  private boolean m_bListening = true;
  private boolean m_bModified = false;
  private JPanel m_jPanelMain = null;
  private JComboBox m_jComboBoxValueType = null;
  private TreeListCombo m_treeListComboMembers = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Empty Constructor
   */
  public CreateParameterPanel() {    
  }
  
  /**
   * Constructor that takes a ComponentContext
   * 
   * @param context The ComponentContext
   */
  public CreateParameterPanel (ComponentContext context) {
    setComponentContext (context);
    setModel (new CreateParameterPanelModelImpl (context));
    initialize();    
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Specifies the ComponentContext for this panel
   * 
   * @param context The ComponentContext
   */
  public void setComponentContext (ComponentContext context) {
    m_componentContext = context;
  }
  
  /**
   * Retrieves the ComponentContext for this panel
   * 
   * @return The ComponentContext
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }
  
  /**
   * Specifies the model for this panel
   * 
   * @param model The CreateParameterPanelModel
   */
  public void setModel (CreateParameterPanelModel model) {
    m_createParameterPanelModel = model;
  }
  
  /**
   * Retrieves the model for this panel
   * 
   * @return The CreateParameterPanelModel
   */
  public CreateParameterPanelModel getModel() {
    return m_createParameterPanelModel;
  }

  /**
   * Creates the UI based on the specified CreateParameterPanelModel
   */
  public void initialize() {
    GridBagLayout gridBagLayout = new GridBagLayout();
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.ipadx = 10;
    
    m_jPanelMain = new JPanel (gridBagLayout);
    setLayout (new BorderLayout());
    
    gridBagConstraints.insets = new Insets (5, 0, 0, 0);
    addBasedOnRow (gridBagLayout, gridBagConstraints);
    addUserPromptRow (gridBagLayout, gridBagConstraints);
    addValuesRow (gridBagLayout, gridBagConstraints);
    addDefaultValuesRow (gridBagLayout, gridBagConstraints);
    addSharingRow (gridBagLayout, gridBagConstraints);
    setStandard (false);
    
    // m_jPanelMain.setPreferredSize (m_jPanelMain.getPreferredSize ());
    setStandard (true);

    add (new JLabel (getResourceString ("CreateParameterDescription")), BorderLayout.NORTH);
    add (m_jPanelMain, BorderLayout.CENTER);
  }

  public static void main (String[] args) {
    CreateParameterPanel createParameterPanel = new CreateParameterPanel();
    CreateParameterPanelModelImpl model = new CreateParameterPanelModelImpl (null);
    model.setBasedOn ("Foo item", true);
    model.setBasedOnFixed (true);
    createParameterPanel.setModel (model);
    createParameterPanel.initialize();
    
    JDialog jDialog = new JDialog();
    jDialog.getContentPane().add (createParameterPanel);
    jDialog.pack();
    jDialog.setVisible (true);
  }
  
  String getResourceString (String strKey) {
    if (m_componentContext != null && m_componentContext.getResourceHandler() != null) {
      return m_componentContext.getResourceHandler().getResourceString (RESOURCE_BUNDLE, strKey);
    }

    return strKey;
  }
  
  /**
   * Applies all UI field values to the underlying model
   */
  public void apply() {
    m_createParameterPanelModel.getParameter().setName (m_jTextFieldUserPrompt.getText());
    
    try {
      Vector vValues = 
        DataUtils.parseMembersString ((String)m_treeListComboMembers.getSelectedItem(), 
          m_createParameterPanelModel.getValueType(), 
            (String)m_createParameterPanelModel.getParameter().getValidationContext(), 
              m_componentContext.getLocale(), m_componentContext.getErrorHandler());
      
      m_createParameterPanelModel.getParameter().setDefaultValue (vValues);
      
      Vector vSelectedDataFilters  = m_dataFiltersPanel.getModel().getSelectedDataFilters();
      if (vSelectedDataFilters != null && vSelectedDataFilters.size() > 0) {
        m_createParameterPanelModel.setDataFilter (
          (BaseDataFilter[])vSelectedDataFilters.toArray (
            new BaseDataFilter[vSelectedDataFilters.size()]));
      }
    }
    
    catch (Exception exception) {
      Logger.getLogger ("oracle.dss.datautil.gui.component.parameter.CreateParameterPanel").log (Level.INFO, 
        "apply() failed.", exception);
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private JTextField getNameTextField() {
    JTextField jTextField = new JTextField();
    jTextField.setName (ComponentNames.PARAMETER_NAME_TEXTFIELD);
    String name = m_createParameterPanelModel.getParameter().getName();
    
    if (name == null) {
      jTextField.setText (m_createParameterPanelModel.getDefaultName());
      jTextField.setEditable (false);
    }
    else {
      jTextField.setText (name);
    }

    return jTextField;
  }

  private JButton getOptionsButton() {
    final JButton jButton = new JButton (getResourceString ("Advanced"));
    
    jButton.setName (ComponentNames.PARAMETER_OPTIONS_BUTTON);
    jButton.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        jButton.setText (getResourceString (m_bStandard ? "Standard" : "Advanced"));
        setStandard (!m_bStandard);
      }
    });

    return jButton;
  }

  private void setStandard (boolean bStandard) {
    m_bStandard = bStandard;
    m_jLabelShare.setVisible (!m_bStandard);
    m_jRadioButtonEach.setVisible (!m_bStandard);
    m_jRadioButtonAll.setVisible (!m_bStandard);
    /*
    m_jCheckBoxIndexValue.setVisible (!m_bStandard);
    m_jCheckBoxLimitValues.setVisible (!m_bStandard);
    */
    m_dataFiltersPanel.setVisible (!m_bStandard);

    m_jComboBoxValueType.setVisible (!m_bStandard);
  }

  private void addBasedOnRow (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    addComponent (m_jPanelMain, new JLabel (getResourceString ("BasedOn")), 
      gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    
    if (m_createParameterPanelModel.isBasedOnFixed()) {
      JLabel jLabel = new JLabel (m_createParameterPanelModel.getBasedOn().getName());
      jLabel.setFont (new Font (jLabel.getFont().getName(), Font.BOLD, jLabel.getFont().getSize()));
      addComponent (m_jPanelMain, jLabel, gridBagLayout, gridBagConstraints);
    }    
  }

  private void addUserPromptRow (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    
    JLabel jLabel = makeLabel (getResourceString ("UserPrompt"));    
    addComponent (m_jPanelMain, jLabel, gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    
    JTextField jTextField = getUserPromptTextField();  
    addComponent (m_jPanelMain, jTextField, gridBagLayout, gridBagConstraints);        

    // Set up mnemonic
    jLabel.setLabelFor (jTextField);

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  }

  private JTextField getUserPromptTextField() {
    m_jTextFieldUserPrompt = new JTextField();

    final DocumentListener documentListener = new DocumentListener() {
      public void changedUpdate (DocumentEvent documentEvent) {
        handle();
      }

      public void insertUpdate (DocumentEvent documentEvent) {
        handle();
      }

      public void removeUpdate (DocumentEvent documentEvent) {
        handle();
      }
      
      private void handle() {
        if (m_bListening) {
          m_bModified = true;
          m_jTextFieldUserPrompt.getDocument().removeDocumentListener (this);
        }
      }
    };

    m_jTextFieldUserPrompt.getDocument().addDocumentListener (documentListener);
    m_jTextFieldUserPrompt.setName (ComponentNames.PARAMETER_USER_PROMPT_TEXTFIELD);
    m_bListening = false;
    m_jTextFieldUserPrompt.setText (m_createParameterPanelModel.getParameter().getPrompt());
    m_bListening = true;

    return m_jTextFieldUserPrompt;
  }

  private void addValuesRow (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    /*
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    addComponent (m_jPanelMain, 
      new JLabel (getResourceString ("Values")), gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    addComponent (m_jPanelMain, getValueRequiredCheckBox(), gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);

    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    addComponent (m_jPanelMain, getMultipleValuesCheckBox(), gridBagLayout, gridBagConstraints);    

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);

    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    m_jCheckBoxIndexValue = getIndexValueCheckBox();
    addComponent (m_jPanelMain, m_jCheckBoxIndexValue, gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
    m_jCheckBoxLimitValues = getLimitValuesCheckBox();
    */

    m_dataFiltersPanel = getDataFiltersPanel();
    /*
    if (m_dataFiltersPanel.getModel().getFilterCount() > 0) {
      gridBagConstraints.gridwidth = 1;
      gridBagConstraints.weightx = 0;
      addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  
      gridBagConstraints.weightx = 0;
      gridBagConstraints.fill = GridBagConstraints.NONE;
      gridBagConstraints.anchor = GridBagConstraints.EAST;
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  
      gridBagConstraints.gridwidth = 1;
      gridBagConstraints.weightx = 0;
      addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  
      gridBagConstraints.weightx = 1;
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
      addComponent (m_jPanelMain, m_dataFiltersPanel, gridBagLayout, gridBagConstraints);

      gridBagConstraints.weightx = 0;
      gridBagConstraints.fill = GridBagConstraints.NONE;
      gridBagConstraints.anchor = GridBagConstraints.EAST;
      gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
      addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
    }

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
    */  
  }

  private JCheckBox getValueRequiredCheckBox() {
    final JCheckBox checkbox = new JCheckBox (getResourceString ("ValueRequired"));
    checkbox.setName (ComponentNames.PARAMETER_VALUE_REQUIRED_CHECKBOX);
    checkbox.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        m_createParameterPanelModel.getParameter().setProperty (BaseParameter.REQUIRED, checkbox.isSelected());
      }
    });

    checkbox.setSelected (m_createParameterPanelModel.getParameter().getProperty (BaseParameter.REQUIRED));
    return checkbox;
  }

  private JCheckBox getMultipleValuesCheckBox() {
    final JCheckBox jCheckBox = new JCheckBox (getResourceString ("MultipleValues"));
    jCheckBox.setName (ComponentNames.PARAMETER_MULTIPLE_VALUES_CHECKBOX);
    
    jCheckBox.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        m_createParameterPanelModel.getParameter().setProperty (BaseParameter.MULTIVALUED, jCheckBox.isSelected());
      }
    });

    jCheckBox.setSelected (m_createParameterPanelModel.getParameter().getProperty (BaseParameter.MULTIVALUED));
    return jCheckBox;
  }

  private JCheckBox getIndexValueCheckBox() {
    final JCheckBox checkbox = new JCheckBox (getResourceString ("IndexValue"));
    checkbox.setName (ComponentNames.PARAMETER_INDEX_VALUE_CHECKBOX);
    checkbox.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
      }
    });
    checkbox.setEnabled (false);
    return checkbox;
  }

  private JCheckBox getLimitValuesCheckBox() {
    final JCheckBox checkbox = new JCheckBox (getResourceString ("FilterValues"));
    checkbox.setName (ComponentNames.PARAMETER_LIMIT_VALUES_CHECKBOX);
    checkbox.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
      }
    });
    
    checkbox.setEnabled (false);
    return checkbox;
  }

  private void addDefaultValuesRow (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    // Default values row
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
 
    JLabel jLabel = makeLabel (getResourceString ("DefaultValues"));
    addComponent (m_jPanelMain, jLabel, gridBagLayout, gridBagConstraints);

    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    
    Vector vValues = new Vector();
    vValues.add (getResourceString ("Value"));
    m_jComboBoxValueType = new JComboBox (vValues);
    m_jComboBoxValueType.setName (ComponentNames.PARAMETER_INDEX_VALUE_COMBOBOX);
    m_jComboBoxValueType.setEnabled  (false);
    addComponent (m_jPanelMain, m_jComboBoxValueType, gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;

    m_treeListComboMembers = getDefaultValuesComboBox();

    DataUtils.setLabelFor (jLabel, m_treeListComboMembers);

    BaseParameter baseParameter = 
      getModel() != null ? getModel().getParameter() : null;
    
    if (baseParameter != null) {
      DataFilterUtils.setCurrentMembers (m_treeListComboMembers, 
        DataUtils.makeMembersLabel ((Vector)baseParameter.getDefaultValue(), true));
    }

    addComponent (m_jPanelMain, m_treeListComboMembers, gridBagLayout, gridBagConstraints);

    gridBagConstraints.weightx = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  }

  private TreeListCombo getDefaultValuesComboBox() {
    TreeListCombo treeListCombo = new TreeListCombo();
    
    ItemItemsTreeNode itemItemsTreeNodeRoot = 
      new ItemItemsTreeNode (treeListCombo.getTree(), getModel().getBasedOn(), getComponentContext());
    
    final DefaultTreeModel treeModel = 
      new DefaultTreeModel (itemItemsTreeNodeRoot);
    
    TreeListComboModel model = new TreeListComboModel () {
      public TreeModel getTreeModel () {
        return treeModel;
      }
      
      public ListModel[] getListModels() {
        return null;
      }
      
      public boolean isMultiSelect() {
          return true;
      }
      
      public ArrayList getSelectFilters() {
          return null;
      }
    };
    
    treeListCombo.setModel (model);
    treeListCombo.getTree().setRootVisible (false);
    treeListCombo.setEditable (true);
    treeListCombo.setName (ComponentNames.PARAMETER_DEFAULT_VALUES_COMBOBOX);

    final CheckTree checkTree = new CheckTree();
    checkTree.setRootVisible (false);
    checkTree.setModel (new DefaultTreeModel (itemItemsTreeNodeRoot));
    treeListCombo.setTree (checkTree);

    treeListCombo.addPopupMenuListener (new PopupMenuListener() {
      public void popupMenuWillBecomeVisible (PopupMenuEvent popupMenuEvent) {
      }
    
      public void popupMenuWillBecomeInvisible (PopupMenuEvent popupMenuEvent) {
        Vector vSelectedItems = getSelectedItems (checkTree);
        String strSelectedItems = QBUtils.getDelimitedString (vSelectedItems, ",");
        m_treeListComboMembers.setText (strSelectedItems);
         
        if ((strSelectedItems != null) && (strSelectedItems.length() > 0)) {
          Component editorComponent = 
            m_treeListComboMembers.getEditor().getEditorComponent();
           
          if (editorComponent instanceof JTextField) {
            ((JTextField)editorComponent).setText (strSelectedItems);
          }
        }
      }
    
      public void popupMenuCanceled (PopupMenuEvent popupMenuEvent) {
      }
    });
    
    return treeListCombo;
  }
  
  private DataFiltersPanel getDataFiltersPanel() {
    DataFiltersPanel dataFiltersPanel = new DataFiltersPanel (getComponentContext());
    dataFiltersPanel.setName (ComponentNames.PARAMETER_DATA_FILTERS_PANEL);
    dataFiltersPanel.refresh();
    return dataFiltersPanel;
  }
  
  private void addSharingRow (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    // Sharing rows (radio buttons)    
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    gridBagConstraints.weighty = 0;
    gridBagConstraints.fill = GridBagConstraints.NONE;
    gridBagConstraints.anchor = GridBagConstraints.EAST;
    m_jLabelShare = new JLabel (getResourceString ("Sharing"));
    addComponent (m_jPanelMain, m_jLabelShare, gridBagLayout, gridBagConstraints);
    
    ButtonGroup sharing = new ButtonGroup();
    m_jRadioButtonEach = getSharingEachViewRadioButton();
    m_jRadioButtonAll = getSharingAllViewsRadioButton();
    sharing.add (m_jRadioButtonEach);
    sharing.add (m_jRadioButtonAll);
    
    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;    
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    addComponent (m_jPanelMain, m_jRadioButtonEach, gridBagLayout, gridBagConstraints);
    
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    gridBagConstraints.weightx = 0;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
    
    gridBagConstraints.gridwidth = 1;
    gridBagConstraints.weightx = 0;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
    
    gridBagConstraints.weightx = 1;
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.anchor = GridBagConstraints.WEST;
    addComponent (m_jPanelMain, m_jRadioButtonAll, gridBagLayout, gridBagConstraints);  
    
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    gridBagConstraints.weightx = 0;
    addComponent (m_jPanelMain, new JLabel(), gridBagLayout, gridBagConstraints);
  }

  private JRadioButton getSharingEachViewRadioButton() {
    boolean shared = m_createParameterPanelModel.getParameter().getProperty (BaseParameter.SHARED);

    final JRadioButton jButton = new JRadioButton (getResourceString ("SharingEachView"), !shared);
    jButton.setName (ComponentNames.PARAMETER_EACH_VIEW_RADIOBUTTON);
    jButton.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        m_createParameterPanelModel.getParameter().setProperty (BaseParameter.SHARED, false);
      }
    });

    return jButton;
  }

  private JRadioButton getSharingAllViewsRadioButton() {
    boolean shared = m_createParameterPanelModel.getParameter().getProperty (BaseParameter.SHARED);

    final JRadioButton jButton = new JRadioButton (getResourceString ("SharingAllViews"), shared);
    jButton.setName (ComponentNames.PARAMETER_ALL_VIEWS_RADIOBUTTON);
    jButton.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        m_createParameterPanelModel.getParameter().setProperty (BaseParameter.SHARED, true);
      }
    });

    return jButton;
  }

  /**
   * Adds a component to a Panel using GridBagLayout
   */
  private static void addComponent (JPanel jPanel, Component component, GridBagLayout gridBagLayout, 
      GridBagConstraints gridBagConstraints) {
    gridBagLayout.setConstraints (component, gridBagConstraints);
    
    jPanel.add (component);
  }

  private Vector getSelectedItems (JTree jTree) {
    Vector vobjSelectedItems = new Vector();
     
    if (jTree != null) {
      TreeModel treeModel = jTree.getModel();

      if (treeModel instanceof DefaultTreeModel) {
        Object object = ((DefaultTreeModel)treeModel).getRoot();
         
        if (object instanceof DefaultMutableTreeNode) {
          for (Enumeration enumeration = 
              ((DefaultMutableTreeNode)object).preorderEnumeration(); enumeration.hasMoreElements(); ) {
            object = enumeration.nextElement();
             
            if ((object instanceof Checkable) && ((Checkable)object).isChecked()) {
              object = ((DefaultMutableTreeNode)object).getUserObject();
               
              if (object instanceof ComponentNode) {
                vobjSelectedItems.addElement(((ComponentNode)object).getValue());
              }
            }
          }
        }
      }
    }

    return vobjSelectedItems;
  }

  private JLabel makeLabel (String strLabel) {
    return (strLabel != null) ? 
      DataUtils.getLabel (strLabel, SwingConstants.LEADING) : null;
  }

}