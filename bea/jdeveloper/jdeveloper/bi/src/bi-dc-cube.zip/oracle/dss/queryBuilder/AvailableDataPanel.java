/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/AvailableDataPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Component;

import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import oracle.dss.bicontext.BIContext;
import oracle.dss.datautil.gui.component.ComponentContext;


public class AvailableDataPanel extends ShuttlePanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * DataSource <code>AvailableItemsTree</code>.
   *
   * @status new
   */
  public static final int AVAILABLEITEMSTREE_DATASOURCE = 0;

  /**
   * Catalog <code>AvailableItemsTree</code>.
   *
   * @status new
   */
  public static final int AVAILABLEITEMSTREE_CATALOG = 1;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private AvailableItemsTree m_availableItemsTreeDataSource = null;
  private AvailableItemsTree m_availableItemsTreeCatalog = null;
  
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public AvailableDataPanel (ComponentContext context) {
    super();
    add (makeViewTypePanel(), BorderLayout.NORTH);
    add (makeTabbedPane (context), BorderLayout.CENTER);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Clear the <code>AvailableDataPanel</code>.
   * 
   * @status hidden       
   */
  public void clear() {
    TreeModel treeModel = null;

    // DataSourceTree  
    AvailableItemsTree availableItemsTreeDataSource = getDatasourceTree();
    if (availableItemsTreeDataSource != null) {
      availableItemsTreeDataSource.setRoot (null);
        
      treeModel = availableItemsTreeDataSource.getModel();  
  
      if (treeModel != null) {
        ((DefaultTreeModel)treeModel).nodeStructureChanged (null);
      }
    }
    
    // CatalogTree  
    AvailableItemsTree availableItemsTreeCatalog = getCatalogTree();
    if (availableItemsTreeCatalog != null) {
      
      availableItemsTreeCatalog.setRoot (null);  
  
      treeModel = availableItemsTreeCatalog.getModel();  
  
      ((DefaultTreeModel)treeModel).nodeStructureChanged (null);
    }
  } 

  public AvailableItemsTree getDatasourceTree() {
    return m_availableItemsTreeDataSource;
  }

  public AvailableItemsTree getCatalogTree() {
    return m_availableItemsTreeCatalog;
  }

  /**
   * Retrieves the <code>FolderItemsTreeNode</code> associated with the 
   * the specified tree type.
   * 
   * @param nTreeType A <code>int</code> which represents the tree type to retrieve.
   * 
   * @return <code>FolderItemsTreeNode</code> associated with the specified tree type.
   * 
   * @see oracle.dss.queryBuilder.AvailableDataPanel#AVAILABLEITEMSTREE_DATASOURCE
   * @see oracle.dss.queryBuilder.AvailableDataPanel#AVAILABLEITEMSTREE_CATALOG
   * 
   * 
   * @status hidden
   */
  public FolderItemsTreeNode getFolderItemsTreeNode (int nTreeType) {
    AvailableItemsTree availableItemsTree = null;

    switch (nTreeType) {
      case AvailableDataPanel.AVAILABLEITEMSTREE_DATASOURCE:
        // availableItemsPanel.getAvailableItemsTree();
        availableItemsTree = getDatasourceTree();
        break;
      
      case AvailableDataPanel.AVAILABLEITEMSTREE_CATALOG:
        availableItemsTree = getCatalogTree();
        break;

      default:
        break;
    }
    
    return getFolderItemsTreeNode (availableItemsTree);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected void setDatasourceTree (AvailableItemsTree availableItemsTreeDataSource) {
    m_availableItemsTreeDataSource = availableItemsTreeDataSource;
  }

  protected void setCatalogTree (AvailableItemsTree availableItemsTreeCatalog) {
    m_availableItemsTreeCatalog = availableItemsTreeCatalog;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private AvailableItemsTree makeDataSourceTree (ComponentContext context) {
    m_availableItemsTreeDataSource = new AvailableItemsTree (context);
    return m_availableItemsTreeDataSource;
  }

  private AvailableItemsTree makeCatalogTree (ComponentContext context) {
    setCatalogTree (new AvailableItemsTree (context));
    
    BIContext biContextRoot = QBUtils.getRoot (context);
    if (biContextRoot != null) {
      getCatalogTree().setRoot (
        new FolderItemsTreeNode (getCatalogTree(), biContextRoot, context));
    }

    return getCatalogTree();
  }

  private JTabbedPane makeTabbedPane (ComponentContext context) {
    JTabbedPane jTabbedPane = new JTabbedPane();
    
    if (getShuttlePanel() == null) {  
      setShuttlePanel (this);
      setShuttleComponent (makeDataSourceTree (context));
      jTabbedPane.add ("Data Source", new JScrollPane ((Component)getShuttleComponent()));
      jTabbedPane.add ("BI Catalog", new JScrollPane (makeCatalogTree (context)));
    }
    else {
      jTabbedPane.add ("Select Values", new JScrollPane ((Component) getShuttleComponent()));
    }
    
    return jTabbedPane;
  }

  private JComboBox makeViewTypeComboBox() {
    Vector vItems = new Vector();
    vItems.addElement ("All");
    
    JComboBox jComboBox = new JComboBox (vItems);
    return jComboBox;
  }

  private JPanel makeViewTypePanel() {
    JPanel jPanel = new JPanel();
    jPanel.setLayout (new BoxLayout (jPanel, BoxLayout.X_AXIS));
    jPanel.add (new JLabel ("List"));
    
    JComboBox jComboBoxViewType = makeViewTypeComboBox();
    jPanel.add (jComboBoxViewType);
    return jPanel;
  }
}
