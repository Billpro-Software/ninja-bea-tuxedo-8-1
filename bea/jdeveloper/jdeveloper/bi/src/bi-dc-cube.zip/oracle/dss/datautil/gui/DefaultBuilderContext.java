/**
 * DefaultBuilderContext.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;

import javax.naming.directory.SearchControls;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

import oracle.bali.ewt.help.HelpProvider;

import oracle.dss.datautil.client.DataUtilException;
import oracle.dss.datautil.gui.panel.MeasureListPanel;
import oracle.dss.datautil.gui.panel.StandardPanel;
import oracle.dss.datautil.gui.panel.WelcomePanel;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.ExceptionListenerAdapter;
import oracle.dss.datautil.ExceptionListenerCallback;

import oracle.dss.util.BIException;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.DefaultErrorHandler;


/**
 * The default implementation of the <code>BuilderContext</code> interface.
 * 
 * @status Documented
 */
public class DefaultBuilderContext extends DefaultComponentContext
                                   implements BuilderContext, ExceptionListenerCallback, ErrorHandlerCallback {

  /**
   * @hidden
   * 
   * Specifies an invalid character array that only includes a space 
   * character.
   *
   * @status hidden
   */
  public static char[] INVALID_NAME_CHARS_BLANK = {' '}; 

  //-----------------------------------------------------------------------
  // NON PUBLIC MEMBERS
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * 
   * Specifies whether a beep is generated when the user attempts to enter
   * an invalid character.
   *
   * @status private
   */
  private boolean m_bInvalidCharsBeep = true; 

  /**
   * @hidden
   * 
   * Specifies the characters for a name that are considered invalid.
   *
   * @status private
   */
  private char[] m_charArrayInvalidName = null; 

  /**
   * @hidden
   * 
   * Determines whether time value-based hierarchies are allowed.
   * A value-based hierarchy is one which contains no levels.
   *
   * This is a <code>boolean</code> which is <code>true</code> time value-based 
   * hierarchies are allowed, and <code>false</code> otherwise.
   *
   * @status hidden
   */
  protected boolean m_bTimeValueHierarchiesAllowed = false;

  /**
	 * @hidden
   *
   * Specifies a custom filter that determines which steps should be made
   * available to the user when defining a new step in the CalcBuilder
   * or QueryBuilder.
   *
   * @status hidden
   */
   // blm - Selection code moved to dvt-olap
/*  protected StepFilter m_stepFilter = null;*/

  /**
	 * @hidden
   *
   * Determines whether shortcuts are accessible through the GUI.
   *
   * @status hidden
   */
  protected boolean m_bShowShortCuts = true;

  /**
	 * @hidden
   *
   * The container object associated with the Builder instance.
   *
   * @status protected
   */
  protected BuilderDialog m_container = null;

  /**
	 * @hidden
   *
   * The size associated with the Builder instance.
   *
   * @status protected
   */
  protected Dimension m_size = null;

  /**
	 * @hidden
   *
   * The Locale associated with this Builder instance.
   *
   * @status protected
   */
  protected Locale m_locale = null;

  /**
	 * @hidden
   *
   * The content object associated with the Builder instance.
   *
   * @status protected
   */
  protected Object m_builderContent = null;

  /**
	 * @hidden
   *
   * Builder resources
   *
   * @status protected
   */
  protected static transient ResourceBundle m_builderResources = null;

  /**
	 * @hidden
   *
   * The Builder Mode associated with the Builder instance.
   * Valid values include BuilderContext.TABBED and BuilderContext.WIZARD
   *
   * @status protected
   */
  protected String m_builderMode = null;

  /**
	 * @hidden
   *
   * The default panel id associated with the Builder instance.
   *
   * @status protected
   */
  protected String m_defaultPanelId = null;

  /**
	 * @hidden
   *
   * Look and feel
   *
   * @status protected
   */

  // gek 07/24/01 Fix Bug 1900094: CalcEditor changes the look and feel of JDeveloper
  //              Default look and feel to null so that it picks up system
  //              defaults instead of Oracle look and feel
  //              ("oracle.bali.ewt.olaf.OracleLookAndFeel").
  protected String m_strLookAndFeel = null;

  /**
	 * @hidden
   *
   * Title associated with the Builder instance.
   *
   * @status protected
   */
  protected String m_strTitle = null;

  /**
	 * @hidden
   *
   * The HelpProvider associated with the Builder instance.
   *
   * @status protected
   */
  protected HelpProvider m_helpProvider = null;

  /**
	 * @hidden
   *
   * Error handler reference
   *
   * @status protected
   */
  protected transient ErrorHandler m_errorHandler = new DefaultBuilderErrorHandler();

  /**
	 * @hidden
   *
   * Exception listener reference
   *
   * @status protected
   */
  protected transient ExceptionListener m_exceptionListener = new ExceptionListenerAdapter();

  /**
	 * @hidden
   *
   * Determines whether the Welcome panel be shown next time.
   *
   * @status protected
   */
  protected boolean m_bShowWelcomeNextTime = true;

  /** 
   * @hidden
   * 
   * Specifies the <code>SearchControls</code> object that is used by the 
   * Save dialog to filter the list of objects that is displayed.
   * 
   * @status hidden
   */    
  private SearchControls m_searchControls;

  /** 
   * @hidden
   * 
   * Specifies the path of the home directory associated with the 
   * components that use the <code>PersistenceObjectChooser</code> such 
   * as <code>CalcBuilder</code> to save objects.
   * 
   * @see #getHomeDirectoryPath()
   * @see #setHomeDirectoryPath(String)
   * 
   * @status hidden
   */    
  private String m_strHomeDirectoryPath;

  /** 
   * @hidden
   * 
   * Specifies the path of the starting directory to display forcomponents 
   * that use the <code>PersistenceObjectChooser</code> such 
   * as <code>CalcBuilder</code> to save objects.
   *
   * @see #getCurrentDirectoryPath()
   * @see #setCurrentDirectoryPath(String)
   *
   * @status hidden
   */    
  private String m_strCurrentDirectoryPath = null;

  //-----------------------------------------------------------------------
  // CONSTRUCTORS
  //-----------------------------------------------------------------------


    /**
     * A <code>DefaultBuilderContext</code> should have a parent dialog or frame associated with it to 
     * ensure proper focus handling.
     *
     * @status documented
     * @deprecated As of 2.6.0.21, replaced by {@link #DefaultBuilderContext(Dialog)}
     * or by {@link #DefaultBuilderContext(Frame)}.
     */
  public DefaultBuilderContext() {
      this ((Frame)null);
  }
  
    /**
     * Constructor that specifies the dialog that serves as the  
     * parent for the <code>DefaultBuilderContext</code>.
     *
     * @param owner The dialog to serve as the parent.
     *
     * @status documented
     */
  public DefaultBuilderContext(Dialog owner) {
      setParent(owner);
      updateBuilderResources ();
  }
  
    /**
     * Constructor that specifies the frame that serves as the  
     * parent for the <code>DefaultBuilderContext</code>.
     *
     * @param owner The frame to serve as the parent.
     *
     * @status documented
     */
  public DefaultBuilderContext(Frame owner) {
      setParent(owner);
      updateBuilderResources ();
  }

  //-----------------------------------------------------------------------
  // PUBLIC METHODS
  //-----------------------------------------------------------------------

  /**
   * @hidden
   *
   * Specifies whether a beep is generated when the user attempts to enter
   * an invalid character.
   * 
   * @param bInvalidCharsBeep A <code>boolean</code> which is <code>true</code>
   *        when a beep should be generated when the user attempts to enter an 
   *        invalid character, and <code>false</code> otherwise.
   *
   * @see #setInvalidCharsName(char[])
   *
   * @status hidden
   */
  public void setInvalidCharsBeep (boolean bInvalidCharsBeep) {
    m_bInvalidCharsBeep = bInvalidCharsBeep;
  }

  /**
   * @hidden
   *
   * Determines whether a beep is generated when the user attempts to enter
   * an invalid character.
   * 
   * @return <code>boolean</code> which is <code>true</code> when a beep 
   *         should be generated when the user attempts to enter an invalid 
   *         character, and <code>false</code> otherwise.
   *
   * @see #getInvalidCharsName() 
   *
   * @status hidden
   */
  public boolean isInvalidCharsBeep() {
    return m_bInvalidCharsBeep;
  }

  /**
   * @hidden
   *
   * Specifies the characters for a name that are considered invalid.  
   * 
   * @param m_charArrayInvalidName A <code>char[]</code> of values that are
   *        considered to be invalid.
   *
   * @see #setInvalidCharsBeep(boolean)
   *
   * @status hidden
   */
  public void setInvalidCharsName (char[] charArrayInvalidName) {
    m_charArrayInvalidName = charArrayInvalidName;
  }

  /**
   * @hidden
   *
   * Retrieves the characters for a name that are considered invalid.  
   * 
   * @return <code>char[]</code> of values that are considered to be invalid.
   *
   * @see #isInvalidCharsBeep()
   * 
   * @status hidden
   */
  public char[] getInvalidCharsName() {
    return m_charArrayInvalidName;
  }

  /**
   * Specifies a custom filter that determines which steps should be made
   * available to the user when defining a new step in the CalcBuilder
   * or QueryBuilder.
   *
   * @param stepFilter A <code>StepFilter</code> used to filter steps.
   *
   * @status new
   */
   // blm - Selection code moved to dvt-olap
/*  public void setStepFilter (StepFilter stepFilter) {
    m_stepFilter = stepFilter;
  }*/

  /**
   * Retrieves a custom filter that determines which steps should be made
   * available to the user when defining a new step in the CalcBuilder
   * or QueryBuilder.
   *
   * @return <code>StepFilter</code> representing the step filter to use.
   *
   * @status new
   */
   // blm - Selection code moved to dvt-olap
/*  public StepFilter getStepFilter() {
    return m_stepFilter;
  }*/

  /**
   * @hidden
   * Specifies the SearchControls object used by the save dialog
   * to filter the list of objects displayed.
   * <P>
   * For example:
   * <P>
   * <pre>
   * //Prevent users from saving into an OLAP catalog folder. 
   * MDSearchControls searchControls = new MDSearchControls();
   * searchControls.setDriverType(MM.PERSISTENCE);
   * </pre>
   *
   * @param searchControls The SearchControls.
   *
   * @status hidden
   */
  public void setSaveDialogSearchControls(SearchControls searchControls) {
      m_searchControls = searchControls;
  }
  
  /**
   * @hidden
   * Retrieves the SearchControls object used by the save dialog
   * to filter the list of objects displayed.
   *
   * @return The SearchControls.
   *
   * @status hidden
   */
  public SearchControls getSaveDialogSearchControls() {
      return m_searchControls;
  }

 /**
  * @hidden
  * 
  * Specifies the path of the home directory associated with the 
  * components that use the <code>PersistenceObjectChooser</code> such 
  * as <code>CalcBuilder</code> to save objects.
  * 
  * The path of the home directory is relative to the root folder that was 
  * specified by the user. Call this method before you display the dialog box.  
  * The default home directory is the root folder.
  * 
  * Note that current directory path takes precedence over the home directory 
  * path when the dialog is first displayed.
  *
  * @param strHomeDirectoryPath A <code>String</code> that specifies the name of 
  *        the path of the home directory.
  * 
  * @see #getHomeDirectoryPath()
  * 
  * @status hidden
  */
  public void setHomeDirectoryPath (String strHomeDirectoryPath) {
    m_strHomeDirectoryPath = strHomeDirectoryPath;
  }

 /**
  * @hidden
  * 
  * Retrieves the path of the home directory associated with the 
  * components that use the <code>PersistenceObjectChooser</code> such 
  * as <code>CalcBuilder</code> to save objects.
  * 
  * The path of the home directory is relative to the root folder that was 
  * specified by the user. Call this method before you display the dialog box.  
  * The default home directory is the root folder.
  * 
  * Note that current directory path takes precedence over the home directory 
  * path when the dialog is first displayed.
  *
  * @return <code>String</code>, which represents the name of the path of the 
  *         home directory.
  * 
  * @see #setHomeDirectoryPath(String)
  * 
  * @status hidden
  */
  public String getHomeDirectoryPath () {
    return m_strHomeDirectoryPath;
  }

 /**
  * @hidden
  * 
  * Specifies the path of the starting directory to display for components 
  * that use the <code>PersistenceObjectChooser</code> such 
  * as <code>CalcBuilder</code> to save objects.
  * 
  * The path of the starting directory is relative to the root folder that was 
  * specified by the user.  Call this method before the 
  * <code>PersistenceObjectChooser</code> is invoked.
  *
  * @param strCurrentDirectoryPath A <code>String</code> that specifies the name 
  *        of the path of the directory to be displayed when the 
  *        <code>PersistenceObjectChooser</code> is invoked.
  *
  * @see #getCurrentDirectoryPath() 
  * 
  * @status hidden
  */
  public void setCurrentDirectoryPath (String strCurrentDirectoryPath) {
    m_strCurrentDirectoryPath = strCurrentDirectoryPath;
  }

 /**
  * @hidden
  * 
  * Retrieves the path of the starting directory to display for components 
  * that use the <code>PersistenceObjectChooser</code> such 
  * as <code>CalcBuilder</code> to save objects.
  * 
  * The path of the starting directory is relative to the root folder that was 
  * specified by the user.  Call this method before the 
  * <code>PersistenceObjectChooser</code> is invoked.
  *
  * @return <code>String</code>, which represents the name of the path of the 
  *         directory to be displayed when the <code>PersistenceObjectChooser</code> 
  *         is invoked.
  *
  * @see #setCurrentDirectoryPath(String) 
  * 
  * @status hidden
  */
  public String getCurrentDirectoryPath () {
    return m_strCurrentDirectoryPath;
  }

  //-----------------------------------------------------------------------
  // Begin - Implentation of BuilderContext interface.
  //-----------------------------------------------------------------------

  /**
 	 * Adds a panel to this Builder object after the other panels.
   *
	 * @param panel   The panel to add.
	 * @param panelId The identifier of the panel that will come after the new panel.
   *
	 * @status Documented
	 */
  public boolean addPanel (StandardPanel panel, String panelId) {
	  return true;
	}

  /**
   * Signals the occurrence of the <code>Apply</code> event.
   *
   * @return <code>true</code> if the operation was successful;
   *         <code>false</code> if the operation was not successful.
   * @throws <code>DataUtilException</code> if an error is encountered.  
   *
   * @status Documented
   */
  public boolean doApply () throws DataUtilException {
    return true;
  }

  /**
   * Signals the occurrence of the <code>Cancel</code> event.
   *
   * @return  <code>true</code> if the operation was successful;
   *          <code>false</code> if the operation was not successful.
   *
   * @status Documented
   */
  public boolean doCancel() {
    return true;
  }

  /**
   * Signals the occurrence of the <code>OK</code> event.
   *
   * @return <code>true</code> if the operation was successful;
   *         <code>false</code> if the operation was not successful.
   * @throws <code>DataUtilException</code> if an error is encountered.   
   *
   * @status Documented
   */
  public boolean doOK () throws DataUtilException {
    return true;
  }

  /**
   * Retrieves the content that is associated with the
   * <code>BuilderContext</code>.
   *
   * @return The content that is associated with the
   *         <code>BuilderContext</code>.
   *
   * @status Documented
   */
  public Object getBuilderContent() {
    return m_builderContent;
  }

  /**
   * Retrieves the container that is associated with the
   * <code>BuilderContext</code> object.
   *
   * @return A reference to the <code>BuilderDialog</code> interface.
   *
   * @status Documented
   */
  public BuilderDialog getContainer() {
    return m_container;
  }

  /**
   * Retrieves the identifier for the default panel in the Builder instance.
   *
   * @return The identifier for the default panel in the Builder instance.
   *
   * @status Documented
   */
  public String getDefaultPanelId() {
    return m_defaultPanelId;
  }

  /**
   * Retrieves the HelpProvider for the Builder instance.
   *
   * @return The HelpProvider for the Builder instance.
   *
   * @status Documented
   */
  public HelpProvider getHelpProvider() {
    return m_helpProvider;
  }

  /**
   * Retrieves the locale for this Builder object. If no locale has been
   * specified, then it retrieves the default locale.
   *
   * @return The <code>Locale</code> object for this Builder object.
   *
   * @status Documented
   */
  public Locale getLocale() {
    if (null == m_locale)
      return Locale.getDefault ();

    return m_locale;
  }

  /**
   * Retrieves the name of the class that implements the look and feel of
   * this <code>BuilderContext</code> object.
   *
   * @return The name of the class that implements the look and feel.
   *
   * @status hidden
   * @hidden
   */
  public String getLookAndFeel() {
    return m_strLookAndFeel;
  }

  /**
   * Retrieves the mode for the Builder instance.
   *
   * @return The mode for the Builder instance. Valid values are
   *         <code>BuilderContext.TABBED</code> and
   *         <code>BuilderContext.WIZARD</code>.
   *
   * @see BuilderContext#TABBED
   * @see BuilderContext#WIZARD
   *
   * @status Documented
   */
  public String getMode() {
    return m_builderMode;
  }

  /**
   * Retrieves the panel with the specified identifier.
   *
   * @return The panel with the specified identifier.
   *
   * @status Documented
   */
  public StandardPanel getPanel (String panelId) {
    return null;
  }

  /**
   * Retrieves the list of panels for the Builder instance.
   *
   * @return The list of panels for the Builder instance.
   *
   * @status Documented
   */
  public Vector getPanelList() {
    return null;
  }

  /**
   * Retrieves the size for the Builder instance.
   *
   * @return The size for the Builder instance.
   *
   * @status Documented
   */
  public Dimension getSize() {
    return m_size;
  }

  /**
   * Retrieves the title for the Builder instance.
   *
   * @return The title for the Builder instance.
   *
   * @status Documented
   */
  public String getTitle() {
    return m_strTitle;
  }

  /**
   * Signals the Builder to create the graphical components.
   *
   * @return <code>true</code> if no problems were encountered;
   *         <code>false</code> a problem was encountered.
   *
   * @throws <code>Exception</code> if an error is encountered.
   * @status Documented
   */
  public boolean initialize () {
    return true;
  }

  /**
   * Indicates whether the panel with the specified identifier is visible.
   *
   * @return <code>true</code> if the panel is visible;
   *         <code>false</code> if the panel is not visible.
   *
   * @status Documented
   */
  public boolean isPanelVisible (String panelId) {
    return true;
  }

  /**
   * Removes the panel from the list of panels in the panel context.
   *
   * @param panelId    The identifier of the panel to be removed.
   *
   * @return  <code>true</code> if the remove operation is successful;
   *          <code>false</code> if the remove operation is not successful.
   *
   * @status Documented
   */
  public boolean removePanel (String panelId) {
    return true;
  }

  /**
   * Signals the Builder to run the dialog.
   *
   * @return   <code>true</code> if the dialog was dismissed with an OK
   *           command, <code>false</code> if the dialog was cancelled.
   *
   * @throws <code>Exception</code> if an error is encountered.
   * @status documented
   */
  public boolean run() throws Exception {
    return true;
  }

  /**
   * Specifies the content that is associated with the
   * <code>BuilderContext</code>.
   *
   * @param builderContent   The content that is associated with the
   *                         <code>BuilderContext</code>.
   *
   * @status Documented
   */
  public void setBuilderContent (Object builderContent) {
    m_builderContent = builderContent;
  }

  /**
   * Specifies the container that is associated with the
   * <code>BuilderContext</code>.
   *
   * @param builderDialog   A reference to the <code>BuilderDialog</code>.
   *
   * @status Documented
   */
  public void setContainer (BuilderDialog container) {
    m_container = container;
  }

  /**
   * Specifies the identifier for the default panel in the Builder instance.
   *
   * @param defaultPanelId   The identifier for the default panel in the
   *                         Builder instance.
   *
   * @status Documented
   */
  public void setDefaultPanelId (String defaultPanelId) {
    m_defaultPanelId = defaultPanelId;
  }

  /**
   * Specifies the HelpProvider in the Builder instance.
   *
   * @param helpProvider The HelpProvider in the Builder instance.
   *
   * @status Documented
   */
  public void setHelpProvider (HelpProvider helpProvider) {
    m_helpProvider = helpProvider;
  }

  /**
   * Specifies the locale for this Builder instance.
   *
   * @param locale The <code>Locale</code> object for this Builder instance.
   *
   * @status Documented
   */
  public void setLocale (Locale locale) {
    m_locale = locale;

    // Attempt to update the resources of the Builder object
    updateBuilderResources ();
  }

  /**
   * Specifies the name of the class that implements the look and feel of
   * this <code>BuilderContext</code> object.
   *
   * @param strLookAndFeel   The name of the class that implements the look
   *                         and feel.
   *
   * @status hidden
   * @hidden
   */
  public void setLookAndFeel (String strLookAndFeel) {
    m_strLookAndFeel = strLookAndFeel;
  }

  /**
   * Specifies the mode for the Builder instance.
   *
   * @param builderMode    The mode for the Builder instance.
   *
   * @status Documented
   */
  public void setMode (String builderMode) {
    m_builderMode = builderMode;
  }

  /**
   * Specifies whether a panel is to be shown or hidden.
   *
   * @param panelId   The identifier of the specified panel.
   * @param bVisible  <code>true</code> if the panel is to be marked visible;
   *                  <code>false</code> if the panel is to be hidden.
   *
   * @return <code>true</code> if the panel was marked visible,
   *         <code>false</code> if the operation failed.
   *
   * @status Documented
   */
  public boolean setPanelVisible (String panelId, boolean bVisible) {
    // gek 10/27/01 Fix Bug 2068677: Unchecking 'Show this page next time'
    //              doesn't work
    //
    //  Perform default processing for QueryBuilder
    if ((panelId != null) && (panelId.equals (WelcomePanel.WELCOME_PANEL_ID)))
     setShowWelcomeNextTime (bVisible);

    return true;
  }

  /**
   * Specifies the size for the Builder instance.
   *
   * @param size   The size for the Builder instance.
   *
   * @status Documented
   */
  public void setSize (Dimension size) {
    m_size = size;
  }

  /**
   * Specifies the title for the Builder instance.
   *
   * @param title The title for the Builder instance.
   *
   * @status Documented
   */
  public void setTitle (String title){
    m_strTitle = title;
  }


  //-----------------------------------------------------------------------
  // End - Implentation of BuilderContext interface.
  //-----------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status Documented
   */
  public void addErrorHandler(ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;

    // Let the ExceptionListener know about the ErrorHandler
    if (getExceptionListener() != null) {
      getExceptionListener().addErrorHandler (errorHandler);
    }
  }

  /**
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> that represents the current
   *         error handler.
   *
   * @status Documented   
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /**
   * Retrieves the value element for the specified key element from the
   * <code>ResourceBundle</code> specified for this Builder instance.
   *
   * @param strKey The key whose value is to be retrieved.
   *
   * @return The value of the specified key.
   *
   * @status hidden
   * @hidden
   * This method is currently being overridden in CalcBuilder
   * and QueryBuilder to avoid collisions in m_builderResources when
   * both CalcBuilder and QueryBuilder have been instantiated.
   */
  public static String getIntlString (String strKey) {
    String strResource = null;

    if (strKey == null || m_builderResources == null)
      return strKey;

    try {
      strResource = m_builderResources.getString (strKey);
    }

    catch (MissingResourceException e) {
      return strKey;
    }

    return strResource;
  }

  /**
   * Retrieves the string location of the resource bundle of the Builder
   * object that extends this default implementation of the BuilderContext.
   *
   * @return The string that specifies the location of the resource bundle.
   *
   * @status Documented
   */
  public String getResourcesLocation() {
    return null;
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status Documented
   */
  public void removeErrorHandler() {
    addErrorHandler(new DefaultErrorHandler());

    // Let the ExceptionListener know about the ErrorHandler
    if (getExceptionListener() != null) {
      getExceptionListener().removeErrorHandler();
    }
  }

  /**
   * Specifies whether the Welcome panel is displayed the next time that 
   * the wizard is displayed.
   *
   * @param bVisible  <code>true</code> if the panel is to be displayed;
   *                  <code>false</code> if the panel is not to be displayed.
   * @status Documented
   */
  public void setShowWelcomeNextTime (boolean bVisible) {
    m_bShowWelcomeNextTime = bVisible;
  }

  /**
   * Indicates whether the Welcome panel is displayed the next time that the
   * wizard is displayed.
   *
   * @return <code>true</code> if the panel is to be displayed;
   *         <code>false</code> if the panel is not to be displayed.
   *
   * @status Documented   
   */
  public boolean isShowWelcomeNextTime() {
    return m_bShowWelcomeNextTime;
  }

  //-------------------------------------------------------------------
  // Start Implementation of ExceptionListenerCallback interface
  //-------------------------------------------------------------------

 /**
  * @hidden
  *
  * Adds a single exception listener to the bean.
  *
  * The bean then calls the exception listener with error or alert messages.
  *
  * @param exceptionListener a <code>ExceptionListener</code> used to process exceptions.
  *
  * @status hidden
  */
  public void addExceptionListener (ExceptionListener exceptionListener) {
    m_exceptionListener = exceptionListener;
  }

  /**
   * @hidden
   *
   * Retrieve the current exception listener.
   *
   * @return <code>ExceptionListener</code> which represents the current
   *         exception listener.
   *
  * @status hidden   
   */
  public ExceptionListener getExceptionListener() {
    return m_exceptionListener;
  }

  /**
   * @hidden
   *
   * Removes the exception listener from the bean.
   *
  * @status hidden
   */
  public void removeExceptionListener() {
    addExceptionListener(new ExceptionListenerAdapter());
  }

  /**
   * @hidden
   * 
   * Specifies whether shortcuts are accessible through the GUI.
   *
   * @param bEnableShortcuts A <code>boolean</code> which is <code>true</code> 
   *        if shortcuts are to be shown in the GUI and <code>false</code> 
   *        otherwise.
   *
   * @status hidden
   */
  public void setShowShortcuts (boolean bShowShortcuts) {
    m_bShowShortCuts = bShowShortcuts;
    MeasureListPanel.setShowShortcuts (bShowShortcuts);
  }

  /**
   * @hidden
   * 
   * Determines whether shortcuts are accessible through the GUI.
   *
   * @return <code>boolean</code> which is <code>true</code> if shortcuts are
   *         to be shown in the GUI and <code>false</code> otherwise.
   *
   * @status hidden
   */
  public boolean isShowShortcuts() {
    return m_bShowShortCuts;
  }

  /**
   * @hidden
   * 
   * Specifies whether time value-based hierarchies are allowed.
   * A value-based hierarchy is one which contains no levels.
   *
   * @param bTimeValueHierarchiesAllowed A <code>boolean</code> which is 
   *        <code>true</code> time value-based hierarchies are allowed, and 
   *        <code>false</code> otherwise.
   *
   * @status hidden
   */
  public void setTimeValueHierarchiesAllowed (boolean bTimeValueHierarchiesAllowed) {
    m_bTimeValueHierarchiesAllowed = bTimeValueHierarchiesAllowed;  
  }

  /**
   * @hidden
   * 
   * Retrieves whether time value-based hierarchies are allowed.
   * A value-based hierarchy is one which contains no levels.
   *
   * @return <code>boolean</code> which is <code>true</code> if time 
   *         value-based hierarchies are allowed, and <code>false</code> otherwise.
   *
   * @status hidden
   */
  public boolean isTimeValueHierarchiesAllowed() {
    return m_bTimeValueHierarchiesAllowed;  
  }

  //-----------------------------------------------------------------------
  // NON PUBLIC METHODS
  //-----------------------------------------------------------------------

  /**
	 * @hidden
   *
   * Updates the resources of the Builder object with the currently specified
   * locale.
   *
   * @status protected
   * @hidden
   * This method is currently being overridden in CalcBuilder
   * and QueryBuilder to avoid collisions in m_builderResources when
   * both CalcBuilder and QueryBuilder have been instantiated.
   */
  protected boolean updateBuilderResources (){
    Locale  builderLocale = null;
    String  strResources  = null;

    strResources = getResourcesLocation ();
    if (strResources == null)
      return false;

    // Retrieve the locale of the builder object
    builderLocale = getLocale ();

    try {
      if (builderLocale == null) {
        m_builderResources = ResourceBundle.getBundle (strResources);
      }
      else {
        m_builderResources =
          ResourceBundle.getBundle (strResources, builderLocale);
      }
    }

    catch (MissingResourceException e) {
      if (getErrorHandler () != null) {
        getErrorHandler ().log("missing resource bundle "+ strResources,
          getClass().getName(), "updateBuilderResources ()");

        m_builderResources = null;
      }
    }

    if (m_builderResources == null)
      return false;

    return true;
  }
  
    private class DefaultBuilderErrorHandler extends DefaultErrorHandler {
        /**
         * Overrides the superclass method to print the stack trace of the top level
         * exception in addition to printing the stack trace of the root cause.
         */
        public void error(Throwable e, String _class, String routine) {
            if ((getDebugMode() & SHOW_ERROR) > 0 || getDebugMode() == SHOW_ALL) {
                System.err.println(getDate() + " In " + _class + "::" + routine);
                System.err.println(e.getMessage());
                if(e instanceof BIException) {
                    ((BIException)e).getBIRootCause().printStackTrace();
                }
                else {
                    e.printStackTrace();
                }
            }
        }
    }
}