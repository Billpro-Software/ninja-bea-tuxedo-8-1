/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Vector;
import javax.naming.NamingException;

/**
 * Methods required for an access control list for a
 * <code>BIContext</code>.
 * You use the methods in this interface to find information about the users of
 * the associated <code>BIContext</code> and information about the privileges
 * that those users have.
 * You also use the methods in this interface to add and remove users for
 * accessing the associated <code>BIContext</code> with a specific privilege.
 * <P>
 * To get access to the <code>Acl</code> for a <code>BIContext</code>,
 * call the <code>getAcl</code> method of the <code>BIContext</code>.
 *
 * @see User
 * @see Privilege
 *
 * @status reviewed
 */
public interface Acl
{
    /**
     * Adds a <code>Vector</code> of entries to this <code>Acl</code>.
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to add to this <code>Acl</code>.
     * @param cascade <code>true</code> to have this <code>Acl</code>
     *                  apply to all of the subfolders of folder from which
     *                  this <code>Acl</code> was obtained,
     *                <code>false</code> to have this <code>Acl</code>
     *                  apply only to the folder from which it was obtained.
     *
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to this <code>Acl</code>,
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add entries
     *            to this <code>Acl</code>.
     *
     * @status reviewed
     */
    boolean addEntries(Vector entries, boolean cascade) throws NamingException;

    /**
     * Removes a <code>Vector</code> of entries from this <code>Acl</code>.
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param entries The entries to remove to this <code>Acl</code>.
     * @param cascade <code>true</code> to have this <code>Acl</code>
     *                  apply to all of the subfolders of folder from which
     *                  this <code>Acl</code> was obtained,
     *                <code>false</code> to have this <code>Acl</code>
     *                  apply only to the folder from which it was obtained.
     *
     * @return <code>true</code> if <code>entries</code> are successfully removed
     *                           from this <code>Acl</code>,
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to remove entries
     *            from this <code>Acl</code>.
     *
     * @status reviewed
     */
    boolean removeEntries(Vector entries, boolean cascade) throws NamingException;

    /**
     * Retrieves the <code>Vector</code> of entries in this <code>Acl</code>.
     *
     * @return A <code>Vector</code> of entries in this <code>Acl</code>.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to list entries
     *            of this <code>Acl</code>.
     *
     * @status reviewed
     */
    Vector entries() throws NamingException;

    /**
     * @hidden -- this shouldn't be removed
     * (do you want to add this to the interface?
     * Retrieves the <code>User</code> object for each entry in this
     * <code>Acl</code>.
     *
     * @return A <code>Vector</code> of the <code>User</code> objects from
     *         the entries in this <code>Acl</code>.
     *
     * @throws NamingException If ????
     *
     * @status New
     */
    Vector getAllUsers() throws NamingException;

    /**
     * Retrieves the privilege that the caller has, either as a user or
     * as a member of a group.
     * For example, you might have only read access assigned
     * in your entry as an individual user.
     * But, as a member of a DBA group, you might have full control.
     * This method returns that you have full control.
     *
     * @return The highest privilege of the caller, either as a user or as a
     *         member of a group.
     *
     * @status documented
     */
    Privilege getPrivilege() throws NamingException;
}
