/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Hashtable;
import oracle.dss.bicontext.BISearchControls;

/**
 * Encapsulates factors that controls the behavior of a search.
 * This class allows you to specify:
 * <P>
 * <ul>
 * <li>The scope of the search</li>
 * <li>What the search returns in the search results</li>
 * <li>The maximum size of the search result set</li>
 * <li>The time limit for the search</li>
 * <li>Whether to include a subfolder as the returned result</li>
 * </ul>
 *
 * @status New
 */
public class MDSearchControls extends BISearchControls
{
    private String m_driver;
    private boolean m_ignore = false;
    private String[] m_paths;
    private String[] m_pathNames;
    private Hashtable m_excludeFolders;
    private String m_srClsName;
    
    /**
     * Specifies the search paths
     *
     * @status New
     */
    public void setSearchPaths(String[] paths)
    {
        m_paths = paths;
    }

    /**
     * Retrieves the search paths
     *
     * @status New
     */
    public String[] getSearchPaths()
    {
        return m_paths;
    }

    /**
     * Specifies the name for the root of the search paths
     *
     * @status New
     */
    public void setSearchPathNames(String[] pathNames)
    {
        m_pathNames = pathNames;
    }

    /**
     * Retrieves the name of the root for the search paths
     *
     * @status New
     */
    public String[] getSearchPathNames()
    {
        return m_pathNames;
    }

    /**
     * @hidden
     * Checks if the search on the search path should exclude
     * subfolders
     */
    public boolean isExcludeSubfolders(String searchPath)
    {
        if (m_excludeFolders == null)
            return false;
        else if (m_excludeFolders.get(searchPath) == null)
            return false;
        else
            return ((Boolean)m_excludeFolders.get(searchPath)).booleanValue();
    }

    /**
     * @hidden
     * Specifies whether to exclude subfolders when performing
     * search on the specific searchPath
     */
    public void setExcludeSubfolders(String searchPath, boolean excludeSubfolders)
    {
        if (searchPath == null)
            return;

        if (m_excludeFolders == null)
            m_excludeFolders = new Hashtable(5, 5);

        m_excludeFolders.put(searchPath, new Boolean(excludeSubfolders));
    }

    /**
     * @hidden
     */
    public void clear()
    {
        m_paths = null;
        m_pathNames = null;
    }

    /**
     * Specify the driverType of the connection on which the 
     * search is performed.  Following are valid driverTypes:
     * @see oracle.dss.metadataUtil#MDM
     * @see oracle.dss.metadataUtil#PERSISTENCE
     * 
     * @status New
     */
    public void setDriverType(String driver)
    {
        m_driver = driver;
    }

    /**
     * Retrieve the driverType set on the MDSearchControls.
     * 
     * @status New
     */
    public String getDriverType()
    {
        return m_driver;
    }

    /**
     * @hidden
     * specifies whether to ignore matching attributes when
     * performing a search on the MDM driver
     */
    public void setIgnoreMatchingAttributes(boolean ignore)
    {
        m_ignore = ignore;
    }

    /**
     * @hidden
     */
    public boolean isIgnoreMatchingAttributes()
    {
        return m_ignore;
    }
    
    public void setMDSearchResultImplClassName(String clsName)
    {
        m_srClsName = clsName;
    }
    
    public String getMDSearchResultImplClassName()
    {
        return m_srClsName;
    }
}
