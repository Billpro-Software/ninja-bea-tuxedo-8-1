/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

public class MetadataManagerAssociation extends MetadataManagerSearchResultImpl
{
    private Attribute m_associateID;
    
    /**
     * @hidden
     */
    public MetadataManagerAssociation (String name, Object obj, Attributes attrs, String type, MetadataManagerServices mms, Attribute associateID)
    {
        super(name, obj, attrs, type, mms);
        m_associateID = associateID;
    }

    /**
     * @hidden
     */
    public MetadataManagerAssociation (String name, Object obj, Attributes attrs, boolean isRelative, String type, MetadataManagerServices mms, Attribute associateID)
    {
        super(name, obj, attrs, isRelative, type, mms);
        m_associateID = associateID;
    }

    /**
     * @hidden
     */
    public MetadataManagerAssociation (String name, String className, Object obj, Attributes attrs, String type, MetadataManagerServices mms, Attribute associateID)
    {
        super(name, className, obj, attrs, type, mms);
        m_associateID = associateID;
    }

    /**
     * @hidden
     */
    public MetadataManagerAssociation (String name, String className, Object obj, Attributes attrs, boolean isRelative, String type, MetadataManagerServices mms, Attribute associateID)
    {
        super(name, className, obj, attrs, isRelative, type, mms);
        m_associateID = associateID;
    }
    
    public Attribute getAssociateID()
    {
        return m_associateID;
    }
}