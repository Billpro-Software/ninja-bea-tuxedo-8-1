/*
 * ExceptionListenerDialogCallback.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import oracle.dss.datautil.gui.ExceptionListenerDialog;

/**
 * @hidden
 *
 * Interface for beans that wish to display dialogs in response to exceptions.
 *
 * @see oracle.dss.datautil.gui.ExceptionListenerDialog
 *
 * @status hidden
 */

public interface ExceptionListenerDialogCallback {

  /**
   * @hidden
   * Adds a single <code>ExceptionListenerDialog</code> to the bean.
   *
   * The bean then calls the exception listener dialog with exception messages.
   *
   * @param exceptionListenerDialog A <code>ExceptionListenerDialog</code> to add.
   *
   * @status hidden
   */
  public void addExceptionListenerDialog (ExceptionListenerDialog exceptionListenerDialog);

  /**
   * @hidden
   * Retrieves the <code>ExceptionListenerDialog</code> used to display errors or
   * exceptions.
   *
   * @return <code>ExceptionListenerDialog</code> which is the dialog used to display
   *         errors or exceptions.
   *
   * @status hidden
   */
  public ExceptionListenerDialog getExceptionListenerDialog();

  /**
   * @hidden
   * Removes the <code>ExceptionListenerDialog</code> from the bean.
   *
   * @status hidden
   */
  public void removeExceptionListenerDialog();
}

