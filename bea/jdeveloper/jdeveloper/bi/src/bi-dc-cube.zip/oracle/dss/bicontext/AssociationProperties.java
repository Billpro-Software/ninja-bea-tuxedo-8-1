/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;


/**
 * Properties such as cascade delete of the association.  
 *
 * @status New
 */
public final class AssociationProperties 
{
    
    /**
     * If true, cascade deletes down the association.  
     */
    private boolean m_cascadeDelete = false;
    
    /**
     * Constructor.  Associations created by methods without an 
     * explicit association properties argument will be given 
     * this default association properties.  
     */
    public AssociationProperties()
    {
        
    }
    
    /**
     * Set cascade delete property.  If true, deletes cascade down 
     * the association.  
     */
    public void setCascadeDelete(boolean cascadeDelete)
    {
        m_cascadeDelete = cascadeDelete;
    }
    

    /**
     * Return true if deletion should cascade down the association.  
     */
    public boolean getCascadeDelete()
    {
        return m_cascadeDelete;
    }
    
    
}
