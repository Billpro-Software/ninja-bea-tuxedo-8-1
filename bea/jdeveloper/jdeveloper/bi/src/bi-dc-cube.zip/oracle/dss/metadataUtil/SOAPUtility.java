/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataUtil;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.io.StringReader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;

public class SOAPUtility {
  public static String executeRequest(String urlStr, String request) throws Exception{
    URL url = new URL(urlStr);
    URLConnection connection = url.openConnection();
    HttpURLConnection httpConn = (HttpURLConnection) connection;

    byte[] b = request.getBytes("UTF-8");
    
    // Set the appropriate HTTP parameters.
    //httpConn.setRequestProperty("User-Agent",""); 
    httpConn.setRequestProperty( "Content-Length",
                                String.valueOf( b.length ) );
    httpConn.setRequestProperty("Content-Type","text/xml; charset=utf-8");
    httpConn.setRequestMethod( "POST" );
    httpConn.setDoOutput(true);
    httpConn.setDoInput(true);
    
    // Everything's set up; send the XML that was read in to b.
    OutputStream out = httpConn.getOutputStream();
    out.write( b );    
    out.close();
    
    // Read the response.
    
    InputStreamReader isr =
       new InputStreamReader(httpConn.getInputStream());
    BufferedReader in = new BufferedReader(isr);
    
    String inputLine;
    StringBuffer buf = new StringBuffer();    
    while ((inputLine = in.readLine()) != null) {
       buf.append(inputLine);
    }

    in.close();
    httpConn.disconnect();
    return buf.toString();
  }
  
  public static String getRequestHeader(String action) {
    return "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
             "<soap:Body xmlns:ns1=\"com.siebel.analytics.web/soap/v4\">" +
               "<ns1:" + action + ">";
  }

  public static String getRequestFooter(String action) {
    return     "</ns1:" + action + ">" +
             "</soap:Body>" +
           "</soap:Envelope>";
  }

  public static String getParameter(String name, String value) {
    return      "<ns1:" + name + ">" + value + "</ns1:" + name + ">";
  }
  
  public static String getComplexParameter(String name, String[][] values) {
    StringBuffer buf = new StringBuffer();
    buf.append("<ns1:" + name + ">");
    for(int i=0; i<values.length; i++)
      buf.append("<ns1:" + values[i][0] + ">" + values[i][1] + "</ns1:" + values[i][0] + ">");
    buf.append("</ns1:" + name + ">");
    return buf.toString();
  }
  
  protected static DOMParser m_parser = null;
  public static XMLDocument parseXML(String xml) throws Exception {
  if (m_parser == null)
  {
      m_parser = new DOMParser();
      m_parser.setValidationMode(DOMParser.NONVALIDATING);
      m_parser.setPreserveWhitespace(false);
  }
    m_parser.parse(new StringReader(xml));
    return m_parser.getDocument();
  }
  
    public static String getUnescapedString(String str) {
      if (str == null) {
        return null;
      }
      str = str.replaceAll("&lt;", "<");
      str = str.replaceAll("&gt;", ">");
        str = str.replaceAll("&quot;", "\"");
      str = str.replaceAll("&amp;", "&");
      str = str.replaceAll("&apos;", "\'");
      return str;
    }
  
  public static String getEscapedString(String str) {
    if (str == null) {
      return null;
    }
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < str.length(); i++) {
      char c = str.charAt(i);
      if (c == '<') {
        sb.append("&lt;");
      }
      else if (c == '>') {
        sb.append("&gt;");
      }
      else if (c == '&') {
        sb.append("&amp;");
      }
      else if (c == '\'') {
        sb.append("&apos;");
      }
      else if (c == '"') {
        sb.append("&quot;");
      }
      else {
        sb.append(c);
      }
    }
    return sb.toString();
  }
  
  
}