/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/QueryEditorCapabilities.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     12/21/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/QueryEditorCapabilities.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.datautil;

/**
 * Contains constants defining capabilities of the QueryEditor implementation.
 */
public interface QueryEditorCapabilities
{
    /**
     * Does the query editor support measure dimension Selections?
     */
    public static final int MEASURE_DIMENSION_SELECTION = 1;
    
    /**
     * Does the query editor support outline mode?
     */
    public static final int OUTLINE_MODE = 2;    
}
