/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/Builder.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.builder;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;

import oracle.bali.ewt.help.HelpUtils;
import oracle.bali.ewt.wizard.BaseWizard;
import oracle.bali.ewt.wizard.ImageWizardPage;
import oracle.bali.ewt.wizard.Wizard;
import oracle.bali.ewt.wizard.WizardAdapter;
import oracle.bali.ewt.wizard.WizardDialog;
import oracle.bali.ewt.wizard.WizardEvent;
import oracle.bali.ewt.wizard.WizardPage;

import oracle.dss.builder.BuilderWizard;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.ExceptionListenerAdapter;
import oracle.dss.datautil.gui.Utils;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;

/**
 * <pre>
 * The base <code>Builder</code> wizard framework.
 * </pre>
 *
 * @author rbalexan 
 * @since  11.0.0.0.5
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    rbalexan  07/19/06 - 
 *    gkellam   01/12/06 - Update component context to remove awt references. 
 *    gkellam   11/30/05 - Add item calc support to QueryBuilder. 
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 *    gkellam   11/02/05 - Add ErrorHandlerCallback. 
 *    gkellam   09/19/05 - 
 */
public class Builder implements ErrorHandlerCallback {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  /**
   * @hidden
   * The <code>BuilderContext</code>.
   * @status hidden
   */
  private BuilderContext m_builderContext = null;
  
  /**
   * @hidden
   * The <code>BaseWizard</code>.
   * @status hidden
   */
  private BaseWizard m_baseWizard = null;

  /**
   * @hidden
   * Determines whether the <code>Builder</code> is finished.
   * @status hidden
   */
  private boolean m_bFinished = false;
   
  /**
   * @hidden
   *
   * Exception listener reference
   *
   * @status hidden
   */
  private transient ExceptionListener m_exceptionListener = 
    new ExceptionListenerAdapter();

  /**
   * @hidden
   * 
   * The <code>ErrorHandler</code> used to process errors.
   *
   * @status hidden
   */
  private transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default <code>Builder</code> constructor.
   * 
   * @status new
   */
  public Builder() {
    this (null);
  }
        
  /**
   * <code>Builder</code> constructor.
   * 
   * @param builderContext A <code>BuilderContext</code> containing properties
   *        used by the <code>Builder</code>.
   * 
   * @status new
   */
  public Builder (BuilderContext builderContext) {
    setContext (builderContext);
    //setWizard (makeWizard(builderContext.getMode()));    
    
    setWizard (makeWizard());
    initialize();

    if (getWizard() != null) {
      if (builderContext != null) {
        getWizard().setSize (Utils.getDimension(builderContext.getSize()));
        HelpUtils.setHelpProvider (getWizard(), builderContext.getHelpProvider());
      }
      else {
        getWizard().setSize (new Dimension(800,600));
      }
    }
    
    /*
    if ( (builderContext != null) && (getWizard() != null) ) {
      getWizard().setSize(builderContext.getSize());
      HelpUtils.setHelpProvider(getWizard(), builderContext.getHelpProvider());
    }
    */
  }
    
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * <code>Builder</code> constructor.
   *
   * @status new
   */
  public BaseWizard getWizard() {
    return m_baseWizard;
  }

  /**
   * Run the <code>Builder</code>.
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful and 
   *         <code>false</code> otherwise.
   * 
   * @status new
   */
  public boolean run() {
    setCursor (Cursor.WAIT_CURSOR);
    initialize (getWizard().getSelectedPage());

    getWizard().addWizardListener (new WizardAdapter() {
      public void wizardSelectionChanged (WizardEvent wizardEvent) {
        if (wizardEvent != null) {
          initialize (wizardEvent.getPage());
        }
      }
      
      /*
      public void wizardApplyState(WizardEvent wizardEvent) {
        m_builderContext.doApply();
      }
      */
      
      /**
       * Handle the Wizard canceled event.
       * 
       * @param wizardEvent A <code>WizardEvent</code> to process.
       * 
       * @status new
       */
      public void wizardCanceled (WizardEvent wizardEvent) {
        m_bFinished = false;
      }

      /**
       * Handle the Wizard finished event.
       * 
       * @param wizardEvent A <code>WizardEvent</code> to process.
       * 
       * @status new
       */
      public void wizardFinished (WizardEvent wizardEvent) {
        apply();
        m_bFinished = true;
      }
    });

    // WizardDialog wizardDialog = new WizardDialog(getWizard()) {
    WizardDialog wizardDialog = null;
    BuilderContext builderContext = getContext();
    
    if (builderContext != null) {
      Component parentComponent = (Component)builderContext.getParent();
      
      if (parentComponent != null) {
        if (parentComponent instanceof Dialog) {
          wizardDialog = new WizardDialog(getWizard(), (Dialog)parentComponent, true) {
            public Dimension getPreferredSize() {
              return getWizard().getSize();
            }

            public void addNotify() {
              Builder.this.setCursor(Cursor.DEFAULT_CURSOR);
              super.addNotify();
            }
          };
        }
        else if (parentComponent instanceof Frame) {
          wizardDialog = new WizardDialog(getWizard(), (Frame)parentComponent, true) {
            public Dimension getPreferredSize() {
              return getWizard().getSize();
            }

            public void addNotify() {
              Builder.this.setCursor(Cursor.DEFAULT_CURSOR);
              super.addNotify();
            }
          };
        }
      }
    }

    if (wizardDialog == null) {
      wizardDialog = new WizardDialog(getWizard(), (Frame)null, true) {
        public Dimension getPreferredSize() {
          return getWizard().getSize();
        }

        public void addNotify() {
          Builder.this.setCursor(Cursor.DEFAULT_CURSOR);
          super.addNotify();
        }
      };  
    }

    /*
    WizardDialog wizardDialog = new WizardDialog(getWizard(), getContext().getParent()) {
      public Dimension getPreferredSize() {
        return getWizard().getSize();
      }
      
      public void addNotify() {
        Builder.this.setCursor(Cursor.DEFAULT_CURSOR);
        super.addNotify();
      }
    };
    */

    if (builderContext != null) {
      wizardDialog.setWizardTitle (builderContext.getTitle());

      // Update the BuilderContext with the WizardDialog
      builderContext.setWizardDialog (wizardDialog);    
    }
    
    wizardDialog.runDialog();

    return isFinished();
  }
  
  public BuilderContext getContext() {
    return m_builderContext;
  }
    
  /**
   * Adds a single exception listener to the <code>Builder</code>.
   *
   * The <code>Builder</code> then calls the exception listener with error or 
   * alert messages.
   *
   * @param exceptionListener a <code>ExceptionListener</code> used to process exceptions.
   *
   * @status new
   */
  public void addExceptionListener (ExceptionListener exceptionListener) {
    if (getContext() != null) {
      getContext().setExceptionListener (exceptionListener);
    }
  }

  /**
   * Retrieve the current exception listener.
   *
   * @return <code>ExceptionListener</code> which represents the current
   *         exception listener.
   *
   * @status new   
   */
  public ExceptionListener getExceptionListener() {
    return (getContext() != null) ? getContext().getExceptionListener() : null;
  }

  /**
   * Removes the exception listener from the <code>Builder</code>.
   *
   * @status new
   */
  public void removeExceptionListener() {
    addExceptionListener (new ExceptionListenerAdapter());
  }

  //.........................................................
  // Start - Implementation of ErrorHandlerCallback interface
  //.........................................................

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler A <code>ErrorHandler</code> object.
   *
   * @status new
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;

    // Add the ErrorHandler to the ExceptionListener    
    if (getExceptionListener() != null) {
      getExceptionListener().addErrorHandler (errorHandler);
    }
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status new
   */
  public void removeErrorHandler() {
    m_errorHandler = null;

    // Remove the ErrorHandler from the ExceptionListener    
    if (getExceptionListener() != null) {
      getExceptionListener().removeErrorHandler();
    }
  }

	//.........................................................
	// End - Implementation of ErrorHandlerCallback interface
	//.........................................................

  /**
   * Allow this instance to remove resources and any listeners it has added.
   *
   * @status new
   */
  public void cleanUp () { 
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
     
  /**
   * @hidden
   * Determines whether the <code>Builder</code> has finished.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the builder
   *         is finished and <code>false</code> otherwise.
   * 
   * @status hidden
   */
  protected boolean isFinished() { 
    return m_bFinished;
  }

  /**
   * @hidden
   * @status hidden
   */
  protected void initialize() { 
  }
  
  /**
   * @hidden
   * @status hidden
   */
  protected void apply() { 
  }
  
  /**
   * @hidden
   * @status hidden
   */
  protected void setWizard (BaseWizard baseWizard) {
    m_baseWizard = baseWizard;
  }
  
  /**
   * @hidden
   * @status hidden
   */
  protected void setCursor (int nCursor) {
    BuilderContext builderContext = getContext();

    if (builderContext != null) {
      BuilderUtils.setCursor ((Component)builderContext.getParent(), nCursor);
    }
  }
  
    /**
     * @hidden
     * @status hidden
     */
    //private BaseWizard makeWizard(String strMode) {
    protected BaseWizard makeWizard() {
      //return new Wizard();
      
      // Use BuilderWizard instead of Wizard to provide BI Beans specific 
      // functionality not provided by Wizard
      Wizard wizard = new BuilderWizard();
      wizard.setMustFinish (false);
      return wizard;

      /*    
      BaseWizard wizard = null;
      if (BuilderContext.WIZARD.equals(strMode)) {
        wizard = new Wizard(); 
      }
      else if (BuilderContext.TABBED.equals(strMode)) {
        wizard = new ReentrantWizard();
      }
      
      return wizard;
      */
    }
          
  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
     
  /**
   * @hidden
   * @status hidden
   */
  private void setContext (BuilderContext builderContext) {
    m_builderContext = builderContext;
  }
            
  /**
   * @hidden
   * @status hidden
   */
  private void initialize (WizardPage wizardPage) {
    Component component = getInteractiveArea (wizardPage);
    
    if ((component != null) && (component instanceof BuilderPanel)) {
      BuilderPanel builderPanel = (BuilderPanel)component;
      if (builderPanel.isDirty()) {
        builderPanel.setDirty (false);
        builderPanel.setContext (getContext());
        builderPanel.initialize();
      }
    }
  }
  
  /**
   * @hidden
   * @status hidden
   */
  private Component getInteractiveArea (WizardPage wizardPage) {
    if (wizardPage != null) {
      if (wizardPage instanceof ImageWizardPage) {
        return ((ImageWizardPage)wizardPage).getInteractiveArea();
      }

      return wizardPage.getContent();

    }
    
    return null;
  }
}
