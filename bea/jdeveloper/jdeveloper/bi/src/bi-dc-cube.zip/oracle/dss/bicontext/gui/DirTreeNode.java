/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.Hashtable;

import javax.swing.tree.MutableTreeNode;

import oracle.dss.util.gui.component.tree.ComponentTreeNode;

/**
 * @hidden
 * Each tree node in the common tree model (in Explorer and QueryBuilder)
 * implements this interface
 */
public interface DirTreeNode extends MutableTreeNode, ComponentTreeNode, Node
{
    public String getObjectType();
    
    public int insert(DirTreeNode child);
    
    public Hashtable getEnvironment();
    
    public boolean isDraggable();
    
    public boolean isEditable();
    
    public String getID();
}





