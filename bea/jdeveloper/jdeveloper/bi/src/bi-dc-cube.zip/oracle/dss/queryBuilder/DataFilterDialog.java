/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DataFilterDialog.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.text.MessageFormat;
import java.text.ParseException;

import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import oracle.bali.ewt.help.HelpUtils;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.gui.StandardDialog;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.queryBuilder.AdvancedDataFilterPanel;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.util.gui.BIJOptionPane;

import oracle.ide.controls.JComboCardPanel;


/**
 * <pre>
 * <code>DataFilterDialog</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   05/27/08 - 
 *    gkellam   05/20/08 - Fix Bug 7017064 - Ignore parameterized filters at
 *                         runtime if parameter values are unspecified.
 *    gkellam   03/23/08 - Check for the maximum number of members allowed for
 *                         each datafilter.
 *    gkellam   03/21/08 - Add date error handling.
 *    gkellam   11/29/07 - Fix Bug 6656715 - SHOULD NOT ALLOW USER TO ENTER
 *                         EMPTY PARAMETER VALUE.
 *    gkellam   11/12/07 - Bug 6620692 - QueryBuilder: Click on 'Compound' in
 *                         'Edit Data Filter', removes 1 Data Filter.
 *    gkellam   09/14/07 - Modify RadioButton focus.
 *    gkellam   09/13/07 - Modify simple/compound radio button handling.
 *    gkellam   09/12/07 - Fix Bug 6409887 - QUERYBUILDER: SIMPLE DATA FILTER
 *                         OPERATOR/VALUES NOT CARRIED TO COMPOUND.
 *    gkellam   08/23/07 - When setting the AdvancedDataFilterPanel as the
 *                         current component, do not update GUI.
 *    gkellam   08/23/07 - Bug 6311941 cleanup.
 *    gkellam   08/17/07 - Update MDItem.
 *    gkellam   08/16/07 - Fix DataFilter bugs.
 *    gkellam   08/07/07 - Implement DataFilter search functionality.
 *    gkellam   08/02/07 - Improve data error handling.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/24/07 - More DataFilter updates.
 *    gkellam   07/15/07 - Put strings in resource files.
 *    gkellam   07/13/07 - Continue working in DataFilter plumbing....
 *    gkellam   07/09/07 - Implement new BI Model UI for DataFilters.
 *    gkellam   07/04/07 - Continue updating DataFilter GUI.
 *    gkellam   07/02/07 - Continue updating DataFilter GUI.
 *    gkellam   06/12/07 - Fix Bug 5990797 - QueryBuilder: Edit/Add data filter
 *                         dialogs have no mnemonics.
 *    gkellam   05/15/07 - Fix Bug 6048121 - Please add help context_ids to BI
 *                         Model dialog.
 *    gkellam   05/13/07 - Modify DialogFilterDialog handling.
 *    gkellam   05/13/07 - Add TopBottomDataFilter error checking.
 *    gkellam   05/11/07 - Tweaks for TopBottomDataFilter.
 *    gkellam   05/10/07 - Fix Bug 5901482 - Missing Top/Bottom filters in the
 *                         QB add filter GUI.
 *    gkellam   05/08/07 - Continue to fix Bug 6037092 - QueryBuilder: Add data
 *                         filter dialog should display warning message.
 *    gkellam   05/07/07 - Fix Bug 6037092 - QueryBuilder: Add data filter
 *                         dialog should display warning message.
 *    gkellam   04/04/07 - Change DataFilterModel access.
 */
public class DataFilterDialog extends StandardDialog {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Help Context ID for <code>DataFilterDialog</code>.
   * 
   */
  public static String DATA_FILTER_DIALOG_HELP_CONTEXT_ID = "f1_dvt_bidc_data_filter_html";

  protected static String TITLE_ADD_DATA_FILTER = "Add Data Filter";

  public static Dimension DATAFILTERDIALOG_PREFERRED_SIZE = new Dimension (800, 600);
  public static Dimension DATAFILTERDIALOG_MINIMUM_SIZE = new Dimension (600, 450);

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext = null;
  private DataFilterPanel m_dataFilterPanel = null;

  private AdvancedDataFilterPanel m_advancedDataFilterPanel = null;
  private DataFilterPanelModel m_dataFilterPanelModel = null;
  private JComponent m_jComponentCurrent = null;

  private JComboCardPanel m_jComboCardPanel = null;  

  private JRadioButton m_jRadioButtonSimple = null;  
  private JRadioButton m_jRadioButtonCompound = null;  

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public DataFilterDialog (Dialog dialog, ComponentContext componentContext) {
    this (dialog, componentContext, null);
  }

  public DataFilterDialog (Frame frame, ComponentContext componentContext) {
    this (frame, componentContext, null);
  }

  public DataFilterDialog (Dialog dialog, ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
    super (dialog, TITLE_ADD_DATA_FILTER, true, null);
    setDataFilterPanelModel (dataFilterPanelModel);  
    initDialog (componentContext);
  }

  public DataFilterDialog (Frame frame, ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
    super (frame, TITLE_ADD_DATA_FILTER, true, null);
    setDataFilterPanelModel (dataFilterPanelModel);  
    initDialog (componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the <code>ComponentContext</code>.
   * 
   * @param componentContext A <code>ComponentContext</code> containing 
   *        properties used to initialize the <code>DataFilterDialog</code>.
   *        
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;  
  }      

  /**
   * Retrieves the <code>ComponentContext</code>.
   * 
   * @return <code>ComponentContext</code> containing properties used to  
   *         initialize the <code>DataFilterDialog</code>.
   *        
   */
  public ComponentContext getComponentContext () {
    return m_componentContext;  
  }      
  
  public static DataFilterDialog createDataFilterDialog (ComponentContext componentContext) {
    return createDataFilterDialog (componentContext, null); 
  }

  public static DataFilterDialog createDataFilterDialog (ComponentContext componentContext, 
      DataFilterPanelModel dataFilterPanelModel) {
    DataFilterDialog dataFilterDialog = null;
    
    if (componentContext != null) {
      Component componentParent = 
        (Component)componentContext.getParent();
    
      if (componentParent != null) {
        if (componentParent instanceof Dialog) {
          dataFilterDialog = 
            new DataFilterDialog ((Dialog)componentParent, componentContext, dataFilterPanelModel);
        }
        else if (componentParent instanceof Frame) {
          dataFilterDialog = 
            new DataFilterDialog ((Frame)componentParent, componentContext, dataFilterPanelModel);
        }
      }
    }

    if (dataFilterDialog == null) {
      dataFilterDialog = new DataFilterDialog ((Frame)null, componentContext, dataFilterPanelModel);
    }

    return dataFilterDialog;
  }

  public void setModel (DataFilterPanelModel dataFilterPanelModel) {
    if (dataFilterPanelModel != null) {
      setComponentContext (dataFilterPanelModel.getContext());
      
      setDataFilterPanelModel (dataFilterPanelModel);
      getDataFilterPanel().setDataFilterPanelModel (getDataFilterPanelModel());
      getAdvancedDataFilterPanel().setDataFilterPanelModel (getDataFilterPanelModel());

      BaseDataFilter baseDataFilter = dataFilterPanelModel.getDataFilter();

      // Navigate to the correct DataFilter panel
      if (baseDataFilter instanceof CompoundDataFilter) {
        setCurrentComponent (getAdvancedDataFilterPanel());
      } 
      else {
        setCurrentComponent (getDataFilterPanel());
      }
    }
  }

  /**
   * @internal
   */
  public static void main (String[] args) {
    QBUtils.makeWindow (new DataFilterDialog((Frame)null, null));
  }

  /**
   * Retrieves the Help context ID that is associated with this dialog.
   *
   * This Help context ID is used to enable Help systems to map a particular
   * component to the proper help topic.
   *
   * @return A <code>string</code> that represents the Help context ID.
   *
   */
  public String getHelpContextID() {
		return DATA_FILTER_DIALOG_HELP_CONTEXT_ID;
  }

  /**
   * Retrieve the simple <code>JRadioButton</code>.
   * 
   * @return <code>JRadioButton</code>
   * 
   */
  public JRadioButton getRadioButtonSimple() {
    return m_jRadioButtonSimple;
  }

  /**
   * Retrieve the compound <code>JRadioButton</code>.
   * 
   * @return <code>JRadioButton</code>
   * 
   */
  public JRadioButton getRadioButtonCompound() {
    return m_jRadioButtonCompound;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Specifiy the simple <code>JRadioButton</code>.
   * 
   * @param jRadioButtonSimple A <code>JRadioButton</code>.
   */  
  protected void setRadioButtonSimple (JRadioButton jRadioButtonSimple) {
    m_jRadioButtonSimple = jRadioButtonSimple;
  }

  /**
   * Specifiy the compound <code>JRadioButton</code>.
   * 
   * @param jRadioButtonCompound A <code>JRadioButton</code>.
   */  
  protected void setRadioButtonCompound (JRadioButton jRadioButtonCompound) {
    m_jRadioButtonCompound = jRadioButtonCompound;
  }

  /**
   * @internal
   *
   * Hides the dialog.
   * 
   * @param bCancelled A <code>boolean</code> which is <code>true</code> if the 
   *        cancel button was pressed, false if the finish button was pressed.
   *        
   */
  protected void dismissDialog (boolean bCancelled) {
    
    if (!bCancelled) {       
  
      // Check for member
      BaseDataFilter baseDataFilter = null;
      Component componentCurrent = getCurrentComponent();
      if (componentCurrent != null) {
        try {
          if (componentCurrent instanceof BaseDataFilterPanel) {
            baseDataFilter = ((BaseDataFilterPanel)componentCurrent).makeBaseDataFilter();
          }
        }
        
        catch (Exception exception) {
          
          // DATAFILTERDIALOG_ERROR_VALUES
          
          String strError = 
            getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_INTEGER_VALUE_ONLY);
        
          String strTitle = 
            getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
        
          BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Check for DataFilter errors

        // gek 05/20/08 Fix Bug 7017064 - Ignore parameterized filters at runtime 
        //              if parameter values are unspecified.
        //
        // It is no longer necessary to specify any members when creating a DataFilter.
        // If no values are specified, the DataFilter is not evaluated (i.e. it is ignored).               
        
        /*
        if (isMemberMissing (baseDataFilter)) {
          return;
        }
        */

        // Check for DataFilter errors
        if (isParameterNameMissing (baseDataFilter)) {
          return;
        }

        // TODO: Check for invalid integer values  
        if (isNotValidInt (baseDataFilter)) {
          return;
        }

        if (isNotValidDate (baseDataFilter)) {
          return;
        }

        // TODO: Need to finish implementation
        /*
        if (isNotValidMemberCount (baseDataFilter)) {
          return;
        }
        */
      }
    }
    
    super.dismissDialog (bCancelled);
  }

  /**
   * @internal
   *
   * Displays an error dialog if a member is missing.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to check.
   *        
   */
  protected boolean isMemberMissing (BaseDataFilter baseDataFilter) {
    boolean bIsMemberMissing = false;

    if (baseDataFilter != null) {
      bIsMemberMissing =  baseDataFilter.isMemberMissing();
    
      if (bIsMemberMissing) {
        String strError = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_NO_MEMBER);
        
        String strTitle = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
        
        BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
      }
    }

    return bIsMemberMissing;
  }

  /**
   * @internal
   *
   * Displays an error dialog if a parameter name is missing.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to check.
   *        
   */
  protected boolean isParameterNameMissing (BaseDataFilter baseDataFilter) {
    boolean bIsParamNameMissing = false;

    if (baseDataFilter != null) {
      bIsParamNameMissing = baseDataFilter.isParameterNameMissing();
    
      if (bIsParamNameMissing) {
        String strError = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_NO_PARAM_NAME);
        
        String strTitle = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
        
        BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
      }
    }

    return bIsParamNameMissing;
  }

  /**
   * @internal
   *
   * Displays an error dialog if a <code>DataFilter</code> should only 
   * contain an <code>int</code> member value, but does not.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to check.
   *        
   */
  protected boolean isNotValidInt (BaseDataFilter baseDataFilter) {
    boolean bIsNotValidInt = false;

    if (baseDataFilter != null) {
      bIsNotValidInt = baseDataFilter.isNotValidInt();
    
      if (bIsNotValidInt) {
        String strError = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_INTEGER_VALUE_ONLY);
        
        String strTitle = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
        
        BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
      }
    }

    return bIsNotValidInt;
  }

  /**
   * @internal
   *
   * Displays an error dialog if a <code>DataFilter</code> should only 
   * contain an Date member value, but does not.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to check.
   *        
   */
  protected boolean isNotValidDate (BaseDataFilter baseDataFilter) {
    boolean bIsNotValidDate = false;

    if (baseDataFilter != null) {

      MetadataManager metadataManager = null;
      ComponentContext componentContext = getComponentContext();
      
      if (componentContext != null) {
        metadataManager = componentContext.getBIProvider().getMetadataManager();
      }

      bIsNotValidDate = baseDataFilter.isNotValidDate (metadataManager);
    
      if (bIsNotValidDate) {
        String strError = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_DATE_VALUE_ONLY);
        
        // TODO Pass in locale
        try {
          // Merge in current date/time 
          Object[] objMergeArray = new Object[2];

          objMergeArray [0] = DataUtils.makeFormattedDate (new Date(), DataUtils.DEFAULT_DATE_INPUT_DATE, Locale.getDefault());
          objMergeArray [1] = DataUtils.makeFormattedDate (new Date(), DataUtils.DEFAULT_DATE_INPUT_DATE_TIME, Locale.getDefault());
  
          if (objMergeArray != null) {
            strError = MessageFormat.format (strError, objMergeArray);
          }
        }
        
        catch (ParseException parseException) {
        }
        
        String strTitle = 
          getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
        
        BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
      }
    }

    return bIsNotValidDate;
  }

  /**
   * @internal
   * TODO: Not yet implemented
   *
   * Displays an error dialog if the number of <code>DataFilter</code> members
   * is incorrect.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to check.
   *        
   */
  protected boolean isNotValidMemberCount (BaseDataFilter baseDataFilter) {
    boolean bIsNotValidMemberCount = false;

    int nMaxMembers = -1;
    int nMembers = -1;
    
    if (baseDataFilter != null) {

      if (baseDataFilter instanceof DataFilter) {
        DataFilterPanel dataFilterPanel = getDataFilterPanel(); 
        if (dataFilterPanel != null) {
     
          nMaxMembers = dataFilterPanel.getMaxMembers (baseDataFilter.getCmpOperator());      
          
          Vector vCmpValues = ((DataFilter)baseDataFilter).getCmpValues();
          
          if (vCmpValues != null) {
            nMembers = vCmpValues.size();          
          }
        }
      }

      String strError = null;

      if (nMaxMembers != nMembers) {
       
        if (nMaxMembers == -1) {
          if (nMembers <= 0) {
            strError = 
              getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_NO_MEMBER);
          }
        }
        else {

          if (nMaxMembers == 1) {
            strError = 
              getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_NUM_VALUE);
          }
          else {
            strError = 
              getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_ERROR_NUM_VALUES);
  
            Object[] objMergeArray = new Object[1];
    
            objMergeArray [0] = nMaxMembers;
    
            if (objMergeArray != null) {
              strError = MessageFormat.format (strError, objMergeArray);
            }
          }
        }
        
        if (strError != null) {
          String strTitle = 
            getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE_ERROR);
          
          BIJOptionPane.showMessageDialog (this, strError, strTitle, JOptionPane.WARNING_MESSAGE);
          
          bIsNotValidMemberCount = true;
        }    
      }
    }

    return bIsNotValidMemberCount;
  }

  protected void doOK() {
    try {
      if (getCurrentComponent() instanceof DataFilterPanel) {
        ((DataFilterPanel)getCurrentComponent()).updateModel();
      }
      else if (getCurrentComponent() instanceof AdvancedDataFilterPanel) {
        ((AdvancedDataFilterPanel)getCurrentComponent()).updateModel();
      }
    }
    
    catch (Exception exception) {
      Logger.getLogger ("oracle.dss.queryBuilder.DataFilterDialog").log (Level.INFO, 
        "doOK() failed", exception);
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Retrieves the <code>DataFilterPanel</code>.
   * 
   * @return <code>DataFilterPanel</code>.
   *        
   */
  protected DataFilterPanel getDataFilterPanel() {
    return m_dataFilterPanel;  
  }      
  
  /**
   * Specifies the <code>DataFilterPanel</code>.
   * 
   * @param dataFilterPanel A <code>DataFilterPanel</code>.
   *        
   */
  protected void setDataFilterPanel (DataFilterPanel dataFilterPanel) {
    m_dataFilterPanel = dataFilterPanel;  
    
    // JDev watches for "HelpId" on JComponents
    m_dataFilterPanel.putClientProperty("HelpID", DATA_FILTER_DIALOG_HELP_CONTEXT_ID);
  }

  /**
   * Retrieves the <code>DataFilterPanelModel</code>.
   * 
   * @return <code>DataFilterPanelModel</code>.
   *        
   */
  protected DataFilterPanelModel getDataFilterPanelModel() {
    return m_dataFilterPanelModel;  
  }      
  
  /**
   * Specifies the <code>DataFilterPanelModel</code>.
   * 
   * @param dataFilterPanelModel A <code>DataFilterPanelModel</code>.
   *        
   */
  protected void setDataFilterPanelModel (DataFilterPanelModel dataFilterPanelModel) {
    m_dataFilterPanelModel = dataFilterPanelModel;  
  }      

  /**
   * Retrieves the <code>AdvancedDataFilterPanel</code>.
   * 
   * @return <code>AdvancedDataFilterPanel</code>.
   *        
   */
  protected AdvancedDataFilterPanel getAdvancedDataFilterPanel() {
    return m_advancedDataFilterPanel;  
  }      
  
  /**
   * Specifies the <code>AdvancedDataFilterPanel</code>.
   * 
   * @param advancedDataFilterPanel A <code>AdvancedDataFilterP</code>.
   *        
   */
  protected void setAdvancedDataFilterPanel (AdvancedDataFilterPanel advancedDataFilterPanel) {
    m_advancedDataFilterPanel = advancedDataFilterPanel;  
  }      

  /**
   * Specifies the <code>JComboCardPanel</code> content.
   * 
   * @param jComboCardPanel A <code>JPanel</code>.
   *        
   */
  protected void setJComboCardPanel (JComboCardPanel jComboCardPanel) {
    m_jComboCardPanel = jComboCardPanel;  
  }      

  /**
   * Specifies the <code>JComboCardPanel</code> content.
   * 
   * @return <code>JComboCardPanel</code>.
   *        
   */
  protected JComboCardPanel getJComboCardPanel() {
    return m_jComboCardPanel;  
  }      

  /**
   * Specifies the current <code>Component</code>.
   * 
   * @param jComponentCurrent A <code>Component</code>.
   *        
   */
  protected void setCurrentComponent (JComponent jComponentCurrent) {
    m_jComponentCurrent = jComponentCurrent;  

    if (getJComboCardPanel() != null) {
      if (jComponentCurrent instanceof AdvancedDataFilterPanel) {
        getRadioButtonCompound().setSelected (true);  
        getRadioButtonCompound().requestFocus();  
      }
      else {
        getRadioButtonSimple().setSelected (true);  
        getRadioButtonSimple().requestFocus();  
      }

      getJComboCardPanel().showSubPanel (jComponentCurrent);
    }
  }      

  /**
   * Retrieves the current <code>JComponent</code> displayed in the DataFilterDialog.
   * 
   * @return <code>JComponent</code>.
   *        
   */
  protected JComponent getCurrentComponent() {
    return m_jComponentCurrent;  
  }      

  protected String getResourceString (String strID) {
    String strResourceString = strID;
    
    if ((getComponentContext() != null) && (getComponentContext().getResourceHandler() != null)) {
      strResourceString = 
        getComponentContext().getResourceHandler().getResourceString (strID);
    }
    
    return strResourceString; 
  }

  protected String getOperatorLabel (int nOperator) {
    if (nOperator == DataFilter.OP_GREATER) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER);
    }
    else if (nOperator == DataFilter.OP_LESS) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS);
    }
    else if (nOperator == DataFilter.OP_GREATER_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER_EQUAL);
    }
    else if (nOperator == DataFilter.OP_LESS_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS_EQUAL);
    }
    else if (nOperator == DataFilter.OP_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_EQUAL);
    }
    else if (nOperator == DataFilter.OP_NOT_EQUAL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_EQUAL);
    }
    else if (nOperator == DataFilter.OP_CONTAINS_ALL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ALL);
    }
    else if (nOperator == DataFilter.OP_BEGINS_WITH) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BEGINS_WITH);
    }
    else if (nOperator == DataFilter.OP_ENDS_WITH) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_ENDS_WITH);
    }
    else if (nOperator == DataFilter.OP_CONTAINS_ANY) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ANY);
    }
    else if (nOperator == DataFilter.OP_DOES_NOT_CONTAIN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_DOES_NOT_CONTAIN);
    }
    else if (nOperator == DataFilter.OP_LIKE) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LIKE);
    }
    else if (nOperator == DataFilter.OP_NOT_LIKE) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_LIKE);
    }
    else if (nOperator == TopBottomDataFilter.OP_TOP) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_TOP);
    }
    else if (nOperator == TopBottomDataFilter.OP_BOTTOM) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BOTTOM);
    }
    else if (nOperator == RangeDataFilter.OP_BETWEEN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN);
    }
    else if (nOperator == RangeDataFilter.OP_NOT_BETWEEN) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN);
    }
    else if (nOperator == DataFilter.OP_IS_NULL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN);
    }
    else if (nOperator == DataFilter.OP_IS_NOT_NULL) {
      return getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN);
    }

    return null;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * @internal
   * 
   * Make Simple and Compound Radio Buttons panel.
   * 
   * @return <code>JPanel</code>.
   * 
   */
  private JPanel makeDefaultRadioButtonsPanel() {

    JPanel jPanel = new JPanel();

    setRadioButtonSimple ( 
      new JRadioButton (StringUtils.stripMnemonic (
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_RADIOBUTTON_SIMPLE))));
    
    setRadioButtonCompound (  
      new JRadioButton (StringUtils.stripMnemonic (
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_RADIOBUTTON_COMPOUND))));

    getRadioButtonSimple().setMnemonic (StringUtils.getMnemonicKeyCode (
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_RADIOBUTTON_SIMPLE)));
    
    getRadioButtonCompound().setMnemonic (StringUtils.getMnemonicKeyCode (
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_RADIOBUTTON_COMPOUND)));

    // Create a ButtonGroup that has both the buttons
    final ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add (getRadioButtonSimple());
    buttonGroup.add (getRadioButtonCompound());
    
    getRadioButtonSimple().setSelected (true);
    
    jPanel.add (getRadioButtonSimple());
    jPanel.add (getRadioButtonCompound());

    // Enable/disable controls as Radio Buttons are selected
    getRadioButtonSimple().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        try {
          getRadioButtonSimple().requestFocus();

          boolean bWasAdvancedDataFilterPanel = 
            (getCurrentComponent() != null) ? 
              getCurrentComponent() instanceof AdvancedDataFilterPanel : false;

          if (bWasAdvancedDataFilterPanel) {

            // Move from Compound to Simple
            getAdvancedDataFilterPanel().updateModel();
            
            BaseDataFilter baseDataFilter = 
              getAdvancedDataFilterPanel().getModel().getDataFilter();
            
            if (baseDataFilter instanceof CompoundDataFilter) {
  
              // Make sure the user wants to go from Compound to Simple 
              int nResponse = JOptionPane.showConfirmDialog (
                getAdvancedDataFilterPanel(),
                getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_REPLACE),
                getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_REPLACE_TITLE),
                JOptionPane.YES_NO_OPTION);
            
                // If the user has changed their mind, reselect Compound and return
                if (nResponse == JOptionPane.NO_OPTION) {
                  getRadioButtonCompound().setSelected (true);
                  getRadioButtonCompound().requestFocus();
                  return;  
                }
  
              // Update the DataFilter
              getDataFilterPanel().getDataFilterPanelModel().setDataFilter (getDataFilterPanel().makeBaseDataFilter());
            }
            
            getDataFilterPanel().refresh();
            setCurrentComponent (getDataFilterPanel());
          }
        }

        catch (Exception exception) {
        }
      }
    });

    // Enable/disable controls as Radio Buttons are selected
    getRadioButtonCompound().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        try {
          getRadioButtonCompound().requestFocus();

          boolean bWasSimpleDataFilterPanel = 
            (getCurrentComponent() != null) ? 
              getCurrentComponent() instanceof DataFilterPanel : false;
          
          // Only update if we previously were on the Simple DataFilterPanel
          if (bWasSimpleDataFilterPanel) {
            // Move from Simple to Compound
            getDataFilterPanel().updateModel();
    
            if (getAdvancedDataFilterPanel().getDataFilterConstraintBuilder() != null) {
              getAdvancedDataFilterPanel().getDataFilterConstraintBuilder().selectAll();
              getAdvancedDataFilterPanel().getDataFilterConstraintBuilder().deleteSelectedComponents();
            }
    
            getAdvancedDataFilterPanel().refresh();
            setCurrentComponent (getAdvancedDataFilterPanel());
          }
        }
        
        catch (Exception exception) {
        }
      }
    });

    return jPanel;
  }

  private void initDialog (ComponentContext componentContext) {
    setComponentContext (componentContext);

    setTitle (getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_TITLE));

    GridBagLayout gridBagLayout = new GridBagLayout();
    JPanel jPanelContent = new JPanel (gridBagLayout);

    // Set up GridBagConstraints for Header Label
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    
    // Add Header Label
    JLabel jLabel = 
      new JLabel (getResourceString (QueryBuilderBundle.DATAFILTERDIALOG_HEADER));
    
    jPanelContent.add (Box.createRigidArea (new Dimension (0,5)));
    jPanelContent.add (jLabel, gridBagConstraints);
    
    // Set up GridBagConstraints for JComboCardPanel and make it fill all
    // the available space in the DataFilterDialog panel
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.weighty = 1.0;
    gridBagConstraints.fill = GridBagConstraints.BOTH; 

    // Add JComboCardPanel
    setJComboCardPanel (new JComboCardPanel (null, makeDefaultRadioButtonsPanel()));
    jPanelContent.add (getJComboCardPanel(), gridBagConstraints);

    // Add Simple and Compound DataFilter Panels
    setDataFilterPanel (
      new DataFilterPanel (getComponentContext(), getDataFilterPanelModel()));
    
    setAdvancedDataFilterPanel (
      new AdvancedDataFilterPanel (getComponentContext(), getDataFilterPanelModel()));

    setContent (jPanelContent);
    HelpUtils.setHelpID(jPanelContent,DATA_FILTER_DIALOG_HELP_CONTEXT_ID );
    
    setPreferredSize (DATAFILTERDIALOG_PREFERRED_SIZE);
    setMinimumSize (DATAFILTERDIALOG_MINIMUM_SIZE);
  }

  private static String makeName (ComponentContext componentContext, BaseDataFilter dataFilter) {
    return null;
  }

  private String makeName (ComponentContext componentContext, DataFilter dataFilter) {
    String strName = "";

    if ((componentContext != null) && (dataFilter != null)) {
      try {
        Object object = 
          componentContext.getMetadataProvider().getObjectByUniqueId (dataFilter.getItem());
        
        if ((object != null) && (object instanceof MDObject)) {
          strName += ((MDObject)object).getLabel();
        }
      }

      catch (Exception exception) {
        exception.printStackTrace();
      }

      strName += " " + getOperatorLabel (dataFilter.getCmpOperator()) + " ";
      
      if (dataFilter.getAssociatedParameterName(DataFilter.PARAMETER_COMPARISON_VALUES) != null) {
        strName += 
          dataFilter.getAssociatedParameterName(DataFilter.PARAMETER_COMPARISON_VALUES);
      }
      else {
        strName += QBUtils.getDelimitedString(dataFilter.getCmpValues(), ",");
      }
    }

    return strName;
  }
}