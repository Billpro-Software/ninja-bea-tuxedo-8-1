/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.server;

// Imports
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.ModificationItem;

import oracle.dss.metadataManager.common.MDLookupCache;

import oracle.dss.bicontext.BIConstants;
import oracle.dss.bicontext.BINamingException;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.Privilege;
import oracle.dss.connection.common.CB;
import oracle.dss.connection.server.ConnectionImpl;

import oracle.dss.metadataManager.common.MDAttribute;
import oracle.dss.metadataManager.common.MDComponent;
import oracle.dss.metadataManager.common.MDContentBag;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDIndex;
import oracle.dss.metadataManager.common.MDInitializer;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDRoot;
import oracle.dss.metadataManager.common.MDSelection;
import oracle.dss.metadataManager.common.MDSearchControls;
import oracle.dss.metadataManager.common.MetadataManagerEvent;
import oracle.dss.metadataManager.common.MetadataManagerEventSupport;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.InvalidPropertyException;
import oracle.dss.metadataManager.common.MetadataManagerListener;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerObject;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MetadataModifiedEvent;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;
import oracle.dss.metadataManager.common.NameClashException;
import oracle.dss.metadataManager.common.NameNotBoundException;
import oracle.dss.metadataManager.common.PersistenceHelper;
import oracle.dss.metadataManager.common.UnsupportedOperationException;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

import oracle.dss.metadataManager.server.drivers.MetadataDriver;
import oracle.dss.metadataManager.server.resource.MetadataManagerServerBundle;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.OrderedHashtable;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.UserObjectBag;
import oracle.dss.metadataUtil.MDAggregateInfo;
import oracle.dss.metadataUtil.MDPersistable;

import oracle.dss.util.Comparison;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.PersistableConstants;


import oracle.dss.metadataManager.common.MDItem;

// Middle tier implementation of the Metadata Manager Bean
/**
 * Middle-tier implementation of the MetadataManager.
 * The client-side implementation calls this class.
 * Application developers do not normally do not need to call methods in this class.
 * Instead, call methods of the <code>MetadataManager</code>, and they will call
 * the methods of this class.
 * <P>
 * Only if you create middle-tier components might you want them to instantiate
 * and call methods on this class.
 *
 * @see oracle.dss.metadataManager.client.MetadataManager
 *
 * @status documented
 */

/**
 * @hidden
 */
public class MetadataManagerImpl implements MetadataManagerServices, Comparison, MetadataManagerObject, PersistenceHelper {
    /************************************************************************
    * Private members
    ************************************************************************/
    private static int m_InstanceID = 0;

    private boolean m_DEBUG = false;

    // Root
    private  MDRoot m_MDRoot = null;

    // Cache that contains only the client side cache
    private  MDIndex m_MDIndex = null;

    // All ConnectionImpls
    private  Vector m_ConnectionImpls = null;

    // All Drivers
    private  Vector  m_MetadataDrivers = null;

    // Event handling support
    private MetadataManagerEventSupport  m_EventSupport =  null;

    private MDContentBag m_MetadataModifiedEventCache = null;

    private boolean m_IsBatchEventMode = false;

    // a hashtable that stores object types and their caching semantics
    private Hashtable m_cachingSemantics;

    // Resources
    protected  static  ResourceBundle     m_Resources = null;

    // Unique ID
    private static long m_UniqueID = 0;

    private int m_Depth = MM.LARGE_DATABASE;

    private transient Locale m_Locale = Locale.getDefault();
    private transient ErrorHandler m_errHandler;
//    private transient CallbackObject m_callback;

    public static long m_OlapiTimeforSource = 0;
    public static long m_MMCachedSourceTime = 0;
    public static long m_MMTimeforSource = 0;

    public static long m_OlapiTimeforMemberSource = 0;
    public static long m_MMTimeforMemberSource = 0;
    public static boolean m_IsMMTimed = false;

    // key is the driverType and value is the driver class name
    private Hashtable m_driverImpl;

    private MDLookupCache m_lookupCache;
    
    private MetadataManagerServices m_clientMM;
    /************************************************************************
     * Public methods
     ************************************************************************/
    /**
     * Constructor.
     * Unless you are creating middle-tier components, you do not need to
     * construct a <code>MetadataManagerImpl</code>.
     * Instead, construct a <code>MetadataManager</code> and call its methods.
     *
     * @see oracle.dss.metadataManager.client.MetadataManager#MetadataManager
     *
     * @status documented
     */
    public MetadataManagerImpl() {
        super();
        m_MDRoot = new MDRoot();
        m_MDRoot.setObjectID( generateID() );
        m_MDIndex = new MDIndex();
        initMetadataManagerImpl();
        m_EventSupport = new MetadataManagerEventSupport( this );
        m_errHandler = new DefaultErrorHandler();
        return;
    }

    /**
     * @hidden
     * piggyback support
     */
    public boolean isRegWithPiggyMan()
    {
        return true;
    }

    /**
     * @hidden
     * For local mode talking directly to client object
     */
     /*
    public void setCallbackObject(CallbackObject client)
    {
        m_callback = client;
    }*/

    /**
     * Notify client of message through piggyback
     *
     * @status private
     */
    private void notifyClient(MetadataModifiedEvent evt)
    {
        // this is for piggybacking
        /*
        if (evt.isPiggybacked())
        {
            Vector _listeners = getCompListeners();
            if (_listeners.size() > 0)
            {
                m_errHandler.trace("Sending piggyback messages to client: "+evt, getClass().getName(), "notifyClient");
              	// in our case there will always be one piggyback listener per component
                ((ComponentObjectListener)_listeners.elementAt(0)).eventOccured(evt);
            }
        }
*/
        // this is for local mode callback
        // currently, process event immediately, but can change
        // it so that it buffers events until a certain threshold
        //if (m_callback != null)
        //    m_callback.processEventList(new EventObject[]{evt});
    }

    /************************************************************************
     * ConnectionImpl Support.
     ************************************************************************/

    /**
     * @hidden
     * Set a ConnectionImpl to this MetadataManagerImpl instance.
     *
     * @param connectionImpl    ConnectionImpl object that needs to be set
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>SUCCESS</code>
     *                  <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int setConnectionImpl( ConnectionImpl connectionImpl )
                                                throws MetadataManagerException
    {
        if ( m_ConnectionImpls == null )
            m_ConnectionImpls = new Vector();
        if (  connectionImpl.isConnectionFailed() )
          return MDU.FAILURE;
        m_ConnectionImpls.addElement ( (Object) connectionImpl ) ;
        m_MDRoot.setStrings( connectionImpl.getConnectionString(), "" );
        return MDU.SUCCESS;
    }

   	/**
      * Specifies the size of the schema to which this
     * <code>MetadataManagerImpl</code> provides access.
     * If the schema is very large, then this <code>MetadataManagerImpl</code>
     * loads less of the schema to the client, to improve performance.
     * Call this method, passing
     * <code>oracle.dss.metadataManager.common.MM.LARGE_DATABASE</code>,
     * if either the repository or the analytic workspace is very large.
     * You should also call the appropriate deferred-loading method.
     *
     * @param flag    A constant that represents the schema size. Valid
     *                values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @status documented
    */
    public void setPerformanceTuning( int flag ) {
        //m_Depth = flag;
    }

   	/**
     * Retrieves the size of the schema to which this
     * <code>MetadataManagerImpl</code> provides access.
     *
     * @return      A constant that represents the size of the schema.
     *              Possible values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @status documented
     */
    public int getPerformanceTuning() {
        return m_Depth;
    }

   	/**
     * @hidden
     * Set database string which is the name of olap database.
     *
     * @param databaseString    String representing database name.
     * @param connection        olap connection instance.
     *
     * @status hidden
     */
    public void setDatabaseString( String databaseString, ConnectionImpl connectionImpl ) {
        if ( connectionImpl == null )
            return;
        m_MDRoot.setStrings( connectionImpl.getConnectionString(), databaseString );
        return;
    }

    /**
     * @hidden
     * Retrieve all ConnectionImpls associated to this MetadataManagerImpl.
     *
     * @return Array containing ConnectionImpl instances set in MetadataManager
     *
     * @status hidden
     */
    public ConnectionImpl[] getConnectionImpls()
                                                throws MetadataManagerException
    {
        if  ( m_ConnectionImpls == null )
            return null;

        int count = m_ConnectionImpls.size();
        if ( count == 0 )
            return null;

        ConnectionImpl[] connectionImpls = new ConnectionImpl[count];
        for ( int i =0 ; i < count ; i++ ) {
            connectionImpls[i] = (ConnectionImpl) m_ConnectionImpls.elementAt(i);
        }
        return connectionImpls;
    }

   	/**
     * @hidden
     * Retrieve a particular ConnectionImpl
     *
     * @param connectionString    String representing ConnectionImpl instance.
     *
     * @return  ConnectionImpl instances set in MetadataManager corresponding to
     *          connectionString.
     *
     * @status hidden
     */
    public ConnectionImpl getConnectionImpl( String connectionString )
                                                throws MetadataManagerException
    {
        ConnectionImpl[] connectionImpls = getConnectionImpls();
        if (( connectionImpls == null ) || ( connectionImpls.length == 0))
            return null;
        for ( int i = 0; i < connectionImpls.length ; i ++ ) {
            String _str = connectionImpls[i].getConnectionString();
            if(_str == null)
                _str = connectionImpls[i].getOLAPServiceName();
            if(_str == null || _str.equals(""))
                _str = connectionImpls[i].getService();
            if(_str == null || _str.equals(""))
                _str = connectionImpls[i].getPropertyBag().getStrPropertyValue(CB.SID);
            if(_str != null && _str.equals(connectionString)){
                return connectionImpls[i];
            }
        }
        return null;
    }

   	/**
     * @hidden
     * Retrieve connection status for connection corresponding to connectionString
     * in the metadataManager.
     *
     * @param connectionString        String representing connection instance.
     *
     * @return  Constant representing connection status.  Possible values are:
     *          <code>CONNECTIONS_SET</code> if connection is set.
     *          <code>CONNECTIONS_NOT_SET</code> if connection is not set.
     *
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_SET
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_NOT_SET
     *
     * @status hidden
     */
    public int getConnectionStatus( String connectionString )
                                                throws MetadataManagerException
    {
        ConnectionImpl connectionImpl = null;
        connectionImpl = getConnectionImpl ( connectionString );
        if ( connectionImpl != null )
            return connectionImpl.getConnectionStatus();
        return MM.CONNECTIONS_NOT_SET;
    }

   	/**
     * @hidden
     * Retrieve connection strings for ConnectionImpls set in metadataManager.
     *
     * @return      Array containing connection strings for ConnectionImpls set
     *              in metadataManager.
     *
     * @status hidden
     */
    public String[] getConnectionImplStrings() throws MetadataManagerException {
        ConnectionImpl[] connectionImpls = getConnectionImpls();
        if (( connectionImpls == null ) || ( connectionImpls.length == 0) )
            return null;
        String[] connectionStrings = new String[connectionImpls.length];
        for ( int i = 0; i < connectionImpls.length ; i ++ ) {
            connectionStrings[i] = connectionImpls[i].getConnectionString();
            /*
            if(connectionStrings[i] == null)
            {
                connectionStrings[i] = connectionImpls[i].getServerUrl();
            }
            */
        }
        return connectionStrings;
    }

    /****************************************************************
     * MDRoot methods
     ****************************************************************/
    /**
     * @hidden
     * Retrieve connection string for connection with specified databaseString
     *
     * @param databaseString    String representing database instance.
     *
     * @return  Connection string
     *
     * @status hidden
     */
    public String getConnectionString ( String databaseString ) {
        return m_MDRoot.getConnectionString ( databaseString );
    }

    /**
     * @hidden
     * Retrieve database string for database with specified connectionString
     *
     * @param connectionString    String representing connection instance.
     *
     * @return  database string
     *
     * @status hidden
     */
    public String getDatabaseString( String connectionString ) {
        return m_MDRoot.getDatabaseString ( connectionString );
    }

    /**
     * @hidden
     * Retrieve database strings for ConnectionImpls with specified
     * connectionString
     *
     * @return  Array of database string
     *
     * @status hidden
     */
    public String[] getDatabaseStrings( String connectionString ) {
        return m_MDRoot.getDatabaseStrings ( connectionString );
    }

    /**
     * @hidden
     * Retrieve database strings for all ConnectionImpls.
     *
     * @return  Array of database string
     *
     * @status hidden
     */
    public String[] getDatabaseStrings() {
        return m_MDRoot.getDatabaseStrings();
    }

    /**
     * @hidden
     * Retrieve connection string for connections.
     *
     * @return  Connection string array
     *
     * @status hidden
     */
    public String[] getConnectionStrings() {
        return m_MDRoot.getConnectionStrings();
    }

   	/**
     * @hidden
     * Retrieve attach status for database specified by databaseString.
     *
     * @param databaseString        String corresponding to a database.
     *
     * @return  Constant representing attach status.  Possible values are:
     *          <code>ATTACHED</code> if connection is set.
     *          <code>NOT_ATTACHED</code> if connection is not set.
     *          <code>ATTACHING</code> if connection is not set.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public int getAttachStatus( String databaseString ){
        return m_MDRoot.getAttachStatus ( databaseString );
    }

   	/**
     * @hidden
     * Set attach status in the metadataManager.
     *
     * @param databaseString    String corresponding to a database.
     *
     * @param status            Integer constant representing attach status.
     *                          Possible values are:
     *                          <code>ATTACHED</code> if database is attached.
     *                          <code>NOT_ATTACHED</code> if database is not attached.
     *                          <code>ATTACHING</code> if database is attaching.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public void setAttachStatus( String databaseString, int status ){
        m_MDRoot.setAttachStatus ( databaseString, status );
        return;
    }

   	/**
     * @hidden
     * Retrieve databaseStrings for databases that corresponds to the status
     * specified.
     *
     * @param status            Integer constant representing attach status.
     *                          Possible values are:
     *                          <code>ATTACHED</code> if database is attached.
     *                          <code>NOT_ATTACHED</code> if database is not attached.
     *                          <code>ATTACHING</code> if database is attaching.
     *
     * @return                  Array of Database strings for specified status.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public String[] getDatabaseStrings( int status ) {
        return m_MDRoot.getDatabaseStrings( status );
    }

    /**
     * Adds a <code>MetadataManagerListener</code> to this
     * <code>MetadataManagerImpl</code>.
     *
     * @param listener The listener to add.
     *
     * @status documented
     */
    public void addListener( MetadataManagerListener listener ) {
        m_EventSupport.addMetadataManagerListener( listener );
    }

    /**
     * Removes a <code>MetadataManagerListener</code> from the list of
     * listeners for this <code>MetadataManagerImpl</code>.
     *
     * @param listener  The listener to remove.
     *
     * @status documented
     */
    public void removeListener( MetadataManagerListener listener ) {
        m_EventSupport.removeMetadataManagerListener( listener );
    }

    /**
     * @hidden
     * This method adds a propertyBag to the event cache so that if caching is
     * enabled, modified mdObject is saved in event-cache instead of firing
     * a metadataModified event.
     *
     * @param propertyBag   propertyBag that needs to be saved in event cache.
     * @param relation      String representing relation
     *
     *
     * @status private
     */
    private void cacheMetadataModified( PropertyBag propertyBag, String relation ) {
        if ( m_MetadataModifiedEventCache == null )
            m_MetadataModifiedEventCache = new MDContentBag();
        m_MetadataModifiedEventCache.setContentItem( propertyBag, relation );
        return;
    }

    /**
     * @hidden
     * This method fires MetadataModified Event that contains all the MDObject
     * that were modified.
     *
     * @status private
     */
    private void fireMetadataModifiedCachedEvent() {
        MetadataModifiedEvent event =
         new MetadataModifiedEvent( this, false, m_MetadataModifiedEventCache );
        m_EventSupport.fireMetadataModifiedEvent( event );
        return;
    }

    /**
     * @hidden
     * This method enables or disables event caching.
     *
     * @param isBatchEvent  This can be set to either true or false.
     *                      <code>true</code> enables metadataModified event caching
     *                      <code>false</code> disable metadataModified event caching
     *                                         if events were cached, fire a
     *                                         single event that contains all the
     *                                         modified mdObjects.
     *
     * @status hidden
     */
    public void setBatchEventMode( boolean isBatchEvent ) {
        m_IsBatchEventMode = isBatchEvent;
        if( (m_IsBatchEventMode == false) &&
            (m_MetadataModifiedEventCache != null ) &&
            (m_MetadataModifiedEventCache.size() != 0) )
        {
            fireMetadataModifiedCachedEvent();
        }
    }

    /**
     * @hidden
     * This method retrieves event caching flag.
     *
     * @return              Either true or false.
     *                      <code>true</code> if event caching is enabled
     *                      <code>false</code> if event caching is disabled
     *
     * @status hidden
     */
    public boolean getBatchEventMode() {
        return m_IsBatchEventMode;
    }

    /**
     * @hidden
     * This method retrieves children of mdObject.
     *
     * @param mdObject      mdObject whose children are to be retrieved.
     * @param mdObjectIDs   OrderedHashtable that contains IDs of children
     * @param depth         Constant representing the depth of tree under
     *                      mdObject.  Possible values are:
     *                      <code>DEMO_DATABASE</code>
     *                      <code>MEDIUM_DATABASE</code>
     *                      <code>LARGE_DATABASE</code>
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public OrderedHashtable getChildrenTable( MDObject mdObject,
                                              OrderedHashtable mdObjectIDs,
                                              int depth )
                                                throws MetadataManagerException
    {
        if(mdObject == null){
            return null;
        }
        MDObject obj = m_MDIndex.getMDObject(mdObject.getObjectID());
        if(obj != null) {
            mdObject = obj;
        }
        mdObject.setMetadataManagerServices(this);
        if(mdObject.getChildrenStatus() == MM.NOT_COMPLETE) {
            Vector driverTypes = mdObject.getDriverTypes();
            if(driverTypes != null)
            {
                int count = driverTypes.size();
                for(int i = 0; i < count; i++)
                {
                    String driverType = (String)driverTypes.elementAt(i);
                    MetadataDriver[] mmDrivers = getMetadataDrivers(driverType);
                    for(int j = 0; j < mmDrivers.length; j++)
                    {
                        if(mmDrivers[j].isAsynchronousLoad())
                        {
                            synchronized(this) {
                                while((mdObject.getChildrenStatus(driverType) == MM.NOT_COMPLETE)
                                       && !mmDrivers[j].isAsyncLoadComplete()) {
                                    try {
                                        notifyAll();
                                        wait();
                                    }
                                    catch(InterruptedException ie){
                                    }
                                }
                            }
                        }
                        else if(mmDrivers[j].isDeferredLoad() && (mdObject.getChildrenStatus(driverType) == MM.NOT_COMPLETE))
                        {
                            if(mdObject.getChildrenStatus(driverType) != MM.COMPLETING) {
                                mdObject = mmDrivers[j].addChildren( mdObject, false );
                            }
                        }
                    }
                }
                if(mdObject.getChildrenStatus() == MM.COMPLETE)
                    return mdObject.getChildrenBag().getContentTable();
                else
                    return null;
            }
        }
        if ( ( mdObjectIDs == null ) || ( (mdObjectIDs.size() == 0) && (mdObject.getChildrenStatus() == MM.COMPLETE) ) || ( mdObject == null ) )
            return null;
        OrderedHashtable onlyIDs = new OrderedHashtable();
        OrderedHashtable mdObjectTable = m_MDIndex.getMDObjects( mdObjectIDs, onlyIDs );
        m_MDIndex.setMDObjects( mdObjectTable, (MetadataManagerServices) this );

        OrderedHashtable childrenTable = new OrderedHashtable();
        Enumeration enumer = mdObjectIDs.keys();
        MDObject tempMDObject;
        while( enumer.hasMoreElements() ) {
            Long key = (Long)enumer.nextElement();
            tempMDObject = m_MDIndex.getMDObject( key.longValue() );
            childrenTable.put( tempMDObject, mdObjectIDs.get( key ) );
        }

        MDContentBag mdContentBag = new MDContentBag();
        mdContentBag.setContentTable( childrenTable );
        mdObject.setChildrenBag ( mdContentBag );
        MDObject mdParent = mdObject.getParent();
        if ( mdParent != null )
            mdParent.resetChild( mdObject );
        return childrenTable;
    }

    /**
     * @hidden
     * Retrieve relative from cache.  Fill relative bag and return an
     * OrderedHashtable containing relative.
     *
     * @param mdObject      mdObject whose relative bag needs to be filled.
     * @param mdObjectIDs   IDs of relative
     *
     * @throws              MetadataManagerException
     *
     * @return              OrderedHashtable containing relative.
     *
     * @status hidden
     */
    public OrderedHashtable getRelativeTable ( MDObject mdObject,
                                               OrderedHashtable mdObjectIDs )
                                               throws MetadataManagerException
    {
        if(mdObject == null){
            return null;
        }
        MDObject obj = m_MDIndex.getMDObject(mdObject.getObjectID());
        if(obj != null){
            mdObject = obj;
        }
        mdObject.setMetadataManagerServices(this);
        if(mdObject.getRelativeStatus() == MM.NOT_COMPLETE) {
            Vector driverTypes = mdObject.getDriverTypes();
            if(driverTypes != null)
            {
                int count = driverTypes.size();
                for(int i = 0; i < count; i++)
                {
                    String driverType = (String)driverTypes.elementAt(i);
                    MetadataDriver[] mmDrivers = getMetadataDrivers(driverType);
                    for(int j = 0; j < mmDrivers.length; j++)
                    {
                        if(mmDrivers[j].isAsynchronousLoad())
                        {
                            // Current thread will sleep for a time interval here.
                            synchronized(this) {
                                while((mdObject.getRelativeStatus() == MM.NOT_COMPLETE)
                                      && (!mmDrivers[j].isAsyncLoadComplete())) {
                                    try {
                                        notifyAll();
                                        wait();
                                    } catch(InterruptedException ie) {
                                    }
                                }
                            }
                        }
                        else if(mmDrivers[j].isDeferredLoad())
                        {
                            mdObject = mmDrivers[j].addRelatives( mdObject, false, false );
                        }
                    }
                }
                if(mdObject.getRelativeStatus() == MM.COMPLETE)
                    return mdObject.getRelativesBag().getContentTable();
                else
                    return null;
            }
        }

        if ( ( mdObjectIDs == null ) || ( mdObjectIDs.size() == 0 ) || ( mdObject == null ) )
            return null;
        OrderedHashtable onlyIDs = new OrderedHashtable();
        OrderedHashtable mdObjectTable = m_MDIndex.getMDObjects( mdObjectIDs, onlyIDs );
        m_MDIndex.setMDObjects( mdObjectTable, (MetadataManagerServices) this );

        OrderedHashtable relativesTable = new OrderedHashtable();
        Enumeration enumer = mdObjectIDs.keys();
        MDObject tempMDObject;
        while( enumer.hasMoreElements() ) {
            Long key = (Long)enumer.nextElement();
            tempMDObject = m_MDIndex.getMDObject( key.longValue() );
            relativesTable.put( tempMDObject, mdObjectIDs.get( key ) );
        }

        MDContentBag mdContentBag = new MDContentBag();
        mdContentBag.setContentTable( relativesTable );
        mdObject.setRelativesBag ( mdContentBag );
        MDObject mdParent = mdObject.getParent();
        if ( mdParent != null )
            mdParent.resetChild( mdObject );
        return relativesTable;
    }

  /************************************************************************
  * Attach Detach Support
  ************************************************************************/
    /**
     * @hidden
     * Is root attached to databases
     *
     * @return  <code>true</code> database is attached
     *          <code>false</code> database is not attached
     *
     * @status hidden
     */
    public boolean isAttached(){
        return m_MDRoot.isAttached();
    }

   	/**
     * Attaches (opens) all analytic workspaces to which this
     * <code>MetadataManagerImpl</code> has connections.
     *
     * @return A constant that represents attach status.
     *         Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the process of attaching
     *                   workspaces fails.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status documented
     */
    public int attach() throws MetadataManagerException{
        m_MDRoot = attach( m_MDRoot, (PropertyBag) null ) ;
        return getAttachStatus();
    }

   	/**
     * Detaches (closes) all open analytic workspaces.
     *
     * @return A constant that represents detach status.
     *         Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the process of closing the
     *                   workspaces fails.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status documented
     */
    public int detach() throws MetadataManagerException {
        m_MDRoot = detach ( (PropertyBag) null ) ;
        return getAttachStatus();
    }

   	/**
     * @hidden
     * Attach all. Not fully implemented
     *
     * @param mdRoot
     * @param attachParams  PropertyBag containing
     *
     * @return mdRoot
     *
     * @throws MetadataManagerException if attach process failed
     *
     * @status hidden
     */
    public MDRoot attach( MDRoot mdRoot, PropertyBag attachProperties )
                                                throws MetadataManagerException
    {
        if(attachProperties != null)
            m_clientMM = (MetadataManagerServices)attachProperties.getObjPropertyValue("metadatamanager");

        int _cacheSize = mdRoot.getIntPropertyValue(MM.LOOKUP_CACHE_SIZE);
        if(_cacheSize > 0)
            m_lookupCache = new MDLookupCache(_cacheSize);
        else
            m_lookupCache = new MDLookupCache(50);
            
        // Retrieve MDInitializer
        OrderedHashtable _initTable = (OrderedHashtable)mdRoot.getObjPropertyValue(MM.INITIALIZER);

        // attachProperties is not used at this time.
        MetadataManagerEvent event = new MetadataManagerEvent( this, false, attachProperties );
        m_EventSupport.fireAttachingEvent( event );

        // extract errorhandler
        ErrorHandler errorHandler = (ErrorHandler)mdRoot.getObjPropertyValue("ErrorHandler");
        if(errorHandler != null)
        {
            m_errHandler = errorHandler;
            mdRoot.removeProperty("ErrorHandler");
        }

        // extract the drivers
        if(mdRoot.getObjPropertyValue(MM.METADATA_DRIVER) != null)
            m_driverImpl = (Hashtable)mdRoot.getObjPropertyValue(MM.METADATA_DRIVER);

        Locale _locale = (Locale)mdRoot.getObjPropertyValue("locale");
        if (_locale != null)
        {
            m_Locale = _locale;
            mdRoot.removeProperty("locale");
        }

        MDRoot _obj = (MDRoot)m_MDIndex.getMDObject(mdRoot.getObjectID());
        if(_obj != null)
        {
            mdRoot = _obj;
        }

        m_MDRoot = mdRoot;

        if( m_MDRoot.getObjectID() == MM.ILLEGAL_LONG_VALUE )
            m_MDRoot.setObjectID( generateMDObjectID() );

        m_MDIndex.setMDObject( m_MDRoot );

        //if ( m_MetadataDrivers == null )
            m_MetadataDrivers = getMetadataDrivers();

        if(m_MetadataDrivers != null && errorHandler != null)
        {
            int size = m_MetadataDrivers.size();

            PropertyBag errBag = new PropertyBag();
            errBag.setStrPropertyValue("ErrorHandler", "ErrorHandler");

            for(int i=0; i < size; i++)
            {
                ((MetadataDriver)m_MetadataDrivers.elementAt(i)).setDriverSpecificObject(m_errHandler, errBag);
                ((MetadataDriver)m_MetadataDrivers.elementAt(i)).setLocale(m_Locale);
            }
        }

        // set performance flags on server-tier
        m_Depth = mdRoot.getPerformanceTuning();

        m_MDRoot.setMetadataManagerServices(this);

        m_MDIndex.setMDObject ( m_MDRoot );
        int count = (m_MetadataDrivers != null)? m_MetadataDrivers.size() : 0;
        if ( count == 0 ) {
          //System.out.println ( "-MetadataManagerBean-Server: No Drivers attached : Couldn't build the Object Model" ) ;
          m_errHandler.trace("-MetadataManagerBean-Server: No Drivers attached : Couldn't build the Object Model", getClass().getName(), "attach");
          return m_MDRoot;
        }
        //System.out.println ( "-MetadataManagerBean-Server : Building Object Model" ) ;
        m_errHandler.trace("-MetadataManagerBean-Server : Building Object Model", getClass().getName(), "attach");

        // Run Initializers with BEFORE_ATTACH flag
        if(_initTable != null)
        {
            Enumeration _enum = _initTable.keys();
            while(_enum.hasMoreElements())
            {
                MDInitializer _init = (MDInitializer)_enum.nextElement();
                String _flag = (String)_initTable.get(_init);
                if(_flag.equals(MM.BEFORE_ATTACH))
                {
                    getErrorHandler().trace("Execute BEFORE_ATTACH MDInitializer: " + _init.getClass().getName(), getClass().getName(), "attach");
                    long _bef = System.currentTimeMillis();
                    _init.run(this);
                    long _aft = System.currentTimeMillis();
                    getErrorHandler().trace(_init.getClass().getName() + " executed in " + (_aft-_bef) + "ms", getClass().getName(), "attach");
                }
            }
        }

        buildObjectModel();

        // Run Initializers with AFTER_ATTACH flag
        if(_initTable != null)
        {
            Enumeration _enum = _initTable.keys();
            while(_enum.hasMoreElements())
            {
                MDInitializer _init = (MDInitializer)_enum.nextElement();
                String _flag = (String)_initTable.get(_init);
                if(_flag.equals(MM.AFTER_ATTACH))
                {
                    getErrorHandler().trace("Execute AFTER_ATTACH MDInitializer: " + _init.getClass().getName(), getClass().getName(), "attach");
                    long _bef = System.currentTimeMillis();
                    _init.run(this);
                    long _aft = System.currentTimeMillis();
                    getErrorHandler().trace(_init.getClass().getName() + " executed in " + (_aft-_bef) + "ms", getClass().getName(), "attach");
                }
            }
        }
        
        if(m_DEBUG) {
            System.out.println("Printing From Server - start");
            //m_errHandler.trace("Printing From Server - start", getClass().getName(), "attach");
            m_MDRoot.print(0);
            printChildren ( m_MDRoot, 8, "" );
            m_MDIndex.print();
            System.out.println ( "Printing From Server - end" );
            //m_errHandler.trace("Printing From Server - end", getClass().getName(), "attach");
        }
        return m_MDRoot;
    }

    /**
     * @hidden
     * Print children till depth of the specified mdObject
     *
     * @param mdObject  MDObject whose children are to be printed
     * @param depth     Depth of tree under mdObject
     * @param str       Pre-pend the uniqueID of mdObject and it's children
     *                  with str
     *
     * @throws MetadataManagerException if error occured while retriving
     *                                  children.
     *
     * @status hidden
     */
    public void printChildren( MDObject mdObject, int depth, String str )
                                                throws MetadataManagerException
    {
        if ( depth == 0)
            return;
        if ( depth == 1 )
            System.out.println ( "Test...." );
            //m_errHandler.trace("Test....", getClass().getName(), "printChildren");

        str = str + "\\" + mdObject.getUniqueID();
        System.out.println( "-----------------------------------------------------------------" );
        //m_errHandler.trace("-----------------------------------------------------------------", getClass().getName(), "printChildren");
        System.out.println ( "-Depth<<" + depth + ">> Path=" + str );
        //m_errHandler.trace("-Depth<<" + depth + ">> Path=" + str, getClass().getName(), "printChildren");
        System.out.println ( "-----------------------------------------------------------------" );
        //m_errHandler.trace("-----------------------------------------------------------------", getClass().getName(), "printChildren");
        MDObject[] mdObjects = mdObject.getChildren();
        for (int i = 0 ; ((mdObjects != null) && ( i < mdObjects.length ) ); i++ ) {
            mdObjects[i].print ( 0 );
            if ( !mdObject.isAncestor( mdObjects[i].getUniqueID()) ) {
                // recursion
                printChildren ( mdObjects[i], depth - 1, str );
            }
        }
    }

   	/**
     * @hidden
     * Detach all.  Not fully implemented
     *
     * @param detachProperties  properties that MetadataManagerImpl needs to
     *                          detach
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return mdRoot
     *
     * @status hidden
     */
    public MDRoot detach ( PropertyBag detachProperties )
                                                throws MetadataManagerException
    {
        MetadataManagerEvent detachingEvent =
                       new MetadataManagerEvent( this, true, detachProperties );
        if(m_EventSupport.fireDetachingEvent( detachingEvent ) ) {
            //System.out.println("detaching event is consumed");
            m_errHandler.trace("detaching event is consumed", getClass().getName(), "detach");
            return null;
        }
        //System.out.println ( "-MetadataManagerBean-Server is going to detach" ) ;
        m_errHandler.trace("-MetadataManagerBean-Server is going to detach", getClass().getName(), "detach");
        int count = (m_MetadataDrivers != null)? m_MetadataDrivers.size() : 0;
        for ( int i =0 ; i < count; i++ ) {
            MetadataDriver mmDriver = (MetadataDriver) m_MetadataDrivers.elementAt(i);
            PropertyBag return_props = mmDriver.detach( getPropertyBag() );
            removeFromObjectModel ( mmDriver );
            setPropertyBag ( return_props, MDU.KEEP );
            if ( !mmDriver.isAttached() ) {
                setAttachStatus ( mmDriver.getDatabaseString(), MM.NOT_ATTACHED );
                MetadataManagerEvent detachedEvent = new MetadataManagerEvent( this, false, detachProperties );
                m_EventSupport.fireDetachedEvent( detachedEvent );
            }
        }
        m_MDRoot.removeProperty(MDU.DRIVER_TYPE);
        m_MDRoot.removeAllChildren();
        if(m_MetadataDrivers != null) m_MetadataDrivers.clear();
        setAttachStatus( MM.NOT_ATTACHED );
        m_MDIndex.clear();
        return m_MDRoot;
    }

   	/**
     * @hidden
     * Load Metadata from driver into mdRoot
     *
     * @param mmDrivers   MetadataDriver object from which Metadata is to
     *                    be read
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status private
     */
    private void buildObjectModel() throws MetadataManagerException
    {
        int count = (m_MetadataDrivers != null)? m_MetadataDrivers.size() : 0;
        for ( int i =0 ; i < count; i++ ) {
            MetadataDriver mmDriver = (MetadataDriver)m_MetadataDrivers.elementAt(i);
            PropertyBag send_props = getPropertyBag();
            mmDriver.setMetadataManagerServices( this );
            if(!mmDriver.isAttached())
            {
                PropertyBag return_props = mmDriver.attach( send_props );
                setPropertyBag(return_props,MDU.KEEP);

                // Run Initializers with BEFORE_METADATA_LOAD flag
                OrderedHashtable _initTable = (OrderedHashtable)m_MDRoot.getObjPropertyValue(MM.INITIALIZER);
                if(_initTable != null)
                {
                    Enumeration _enum = _initTable.keys();
                    while(_enum.hasMoreElements())
                    {
                        MDInitializer _init = (MDInitializer)_enum.nextElement();
                        String _flag = (String)_initTable.get(_init);
                        if(_flag.equals(MM.BEFORE_METADATA_LOAD))
                        {
                            getErrorHandler().trace("Execute BEFORE_METADATA_LOAD MDInitializer: " + _init.getClass().getName(), getClass().getName(), "buildObjectModel");
                            long _bef = System.currentTimeMillis();
                            _init.run(this);
                            long _aft = System.currentTimeMillis();
                            getErrorHandler().trace(_init.getClass().getName() + " executed in " + (_aft-_bef) + "ms", getClass().getName(), "buildObjectModel");
                        }
                    }
                }

                if(mmDriver.isAttached())
                {
                    setAttachStatus(mmDriver.getDatabaseString(), MM.ATTACHED);
                    setAttachStatus(MM.ATTACHED);
                    m_MDRoot = mmDriver.addToObjectModel(m_MDRoot);
                    m_MDIndex.setMDObject(m_MDRoot);
                }
            }
            else
            {
                Vector vDrivers = m_MDRoot.getDriverTypes();
                if(vDrivers == null || !vDrivers.contains(mmDriver.getDriverType()))
                {
                    setAttachStatus(mmDriver.getDatabaseString(), MM.ATTACHED);
                    setAttachStatus(MM.ATTACHED);
                    m_MDRoot = mmDriver.addToObjectModel(m_MDRoot);
                    m_MDIndex.setMDObject(m_MDRoot);
                }
            }
        }

        // For MDM deferred load, load the first level of children.
        MetadataDriver[] mmDrivers = getMetadataDrivers(MDU.MDM);
        for(int i = 0; mmDrivers  != null && i < mmDrivers.length; i++)
        {
            if(mmDrivers[i].isDeferredLoad())
            {
                m_MDRoot.getChildren();
                break;
            }
        }
        
        if(m_DEBUG)
        {
            PropertyBag b = new PropertyBag();
            b.setStrPropertyValue(MM.DRIVER_TYPE,MDU.MDM);
            b.setStrPropertyValue(MM.TIME_LAPSED, "init_time");
            m_errHandler.trace("\n\nTime lapsed="+getDriverSpecificObject(b, null), getClass().getName(), "buildObjectModel");
            b.removeProperty(MM.TIME_LAPSED);
            b.setStrPropertyValue(MM.TOTAL_CALLS, "init_calls");
            m_errHandler.trace("Total calls="+getDriverSpecificObject(b, null)+"\n\n", getClass().getName(), "buildObjectModel");
        }
    }

   	/**
     * @hidden
     * Merge Metadata in specified MDFolder into root
     *
     * @param mdFolder  Root folder which will be filled with Metadata from
     *                  olap datasource
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return  root folder with merged object tree under it.
     *
     * @status private
     */
    private MDRoot mergeDriverRoot( MDFolder mdFolder )
                                                throws MetadataManagerException
    {
        if ( mdFolder == null )
            return m_MDRoot;
        m_MDRoot.setChildrenBag( MDContentBag.mergeContentBags(
                                                    m_MDRoot.getChildrenBag(),
                                                    mdFolder.getChildrenBag()
                                                               )
                                );
        m_MDRoot.setRelativesBag( MDContentBag.mergeContentBags(
                                                    m_MDRoot.getRelativesBag(),
                                                    mdFolder.getRelativesBag()
                                                                )
                                );
        m_MDRoot.setPropertyBag( mdFolder.getPropertyBag(), MDU.KEEP  );
        return m_MDRoot;
    }

   	/**
     * @hidden
     * Remove mmDriver from root
     *
     * @param mmDriver     MetadataDriver whose objects are to be removed from
     *                     root
     *
     * @throws MetadataManagerException
     *
     * @return          Integer constant representing remove status.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @status private
     */
    private int removeFromObjectModel( MetadataDriver mmDriver )
                                                throws MetadataManagerException
    {
        if ( mmDriver == null )
            return MDU.FAILURE;

        MDFolder mdFolder = (MDFolder) mmDriver.getRoot();
        if ( mdFolder == null )
            return MDU.FAILURE;
        m_MDIndex.removeMDObject ( mdFolder.getObjectID() );
        m_MDRoot.removeChild ( mdFolder );
        mdFolder.free();
        mdFolder = null;
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieve a property on server side of metadataManager.
     *
     * @param propertyName  Name of property that need to be retrieved from
     *                      server side.
     *
     * @return  Property found on server side for the given propertyName
     *
     * @status hidden
     */
    public Property getServerProperty( String propertyName ) {
        return m_MDRoot.getProperty( propertyName );
    }

    /**
     * @hidden
     * Sets the property on server side of metadataManager
     *
     * @param property      Property that need to be set on server side.
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setServerProperty( Property property ) {
        m_MDRoot.setProperty( property );
        return MDU.SUCCESS;
    }

    public void deferredObjectSetUp(MDObject mdObject) {
        if (mdObject instanceof MDItem) {
            Vector driverTypes = mdObject.getDriverTypes();
            if(driverTypes != null)
            {
                int count = driverTypes.size();
                for(int i = 0; i < count; i++)
                {
                    String driverType = (String)driverTypes.elementAt(i);
                    try
                    {
                        MetadataDriver[] mmDrivers = getMetadataDrivers(driverType);
                        for(int j = 0; j < mmDrivers.length; j++)
                        {
                            mmDrivers[j].deferredObjectSetUp(mdObject);                                                        
                        }
                    }
                    catch (MetadataManagerException e)
                    {
                        getErrorHandler().log(e.getMessage(), "MetadataManagerImpl", "deferredObjectSetUp");
                    }
                }
            }
        }
    }
    
    /**
     * @hidden
     * Retrieve mdRoot set for this metadataManager
     *
     * @return  MDRoot set on metadataManager
     *
     * @status hidden
     */
    public MDRoot getMDRoot(){
        return m_MDRoot;
    }

    /**
     * @hidden
     * Set mdRoot on this metadataManager
     *
     * @param           MDRoot folder that needs to be set as root
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setMDRoot( MDRoot mdRoot){
        m_MDRoot = mdRoot;
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Get server side MDRoot instance.
     *
     * @return  MDRoot set on server side of metadataManager
     *
     * @status hidden
     */
    public MDRoot getServerMDRoot(){
        return getMDRoot();
    }

    /**
     * @hidden
     * Set MDRoot instance on server side.
     *
     * @param   MDRoot instance that needs to be set on server side
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setServerMDRoot( MDRoot mdRoot){
        mdRoot.setMetadataManagerServices(this);
        return setMDRoot( mdRoot );
    }


    /*********************************************************
     * Generic methods for property Setting from Property Bag
     ********************************************************/
    /**
     * @hidden
     * Retrieve properties set on root
     *
     * @return      Properties in MDRoot
     *
     * @status hidden
     */
    public Property[] getServerProperties(){
        return m_MDRoot.getProperties();
    }

    /**
     * @hidden
     * Sets the property on server side of metadataManager
     *
     * @param name      Property name
     * @param object    Object that is to be set in property
     * @param dataType  Constant representing object type.  Possible values are:
     *                  <code>STRING</code>
     *                  <code>LONG</code>
     *                  <code>INTEGER</code>
     *                  <code>OBJ</code>
     *                  <code>STRING_VECTOR</code>
     *                  <code>ALL_DATATYPES</code>
     * @flag            Constant representing visibility of property.
     *                  Possible values are:
     *                  <code>UI_VISIBLE</code>
     *                  <code>UI_WRITE</code>
     *                  <code>UI_DELETE</code>
     *                  <code>UI_ENCRYPT</code>
     *                  <code>UI_ALL</code>
     *                  <code>UI_NONE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#STRING
     * @see oracle.dss.metadataUtil.MDU#LONG
     * @see oracle.dss.metadataUtil.MDU#INTEGER
     * @see oracle.dss.metadataUtil.MDU#OBJ
     * @see oracle.dss.metadataUtil.MDU#STRING_VECTOR
     * @see oracle.dss.metadataUtil.MDU#ALL_DATATYPES
     * @see oracle.dss.metadataUtil.MDU#UI_VISIBLE
     * @see oracle.dss.metadataUtil.MDU#UI_WRITE
     * @see oracle.dss.metadataUtil.MDU#UI_DELETE
     * @see oracle.dss.metadataUtil.MDU#UI_ENCRYPT
     * @see oracle.dss.metadataUtil.MDU#UI_ALL
     * @see oracle.dss.metadataUtil.MDU#UI_NONE
     *
     * @status hidden
     */
    public void setServerProperty ( String name, Object object, int dataType, int flags){
        m_MDRoot.setProperty ( name, object, dataType, flags );
    }

    /**
     * @hidden
     * Remove the property on server side of metadataManager
     *
     * @param name      Property name
     *
     * @status hidden
     */
    public void removeServerProperty(String name) {
        m_MDRoot.removeProperty( name );
    }

    /**
     * @hidden
     * Retrieve property bag from root
     *
     * @return  PropertyBag of mdRoot.
     *
     * @status hidden
     */
    public PropertyBag getPropertyBag() {
        return m_MDRoot.getPropertyBag();
    }

    /**
     * @hidden
     * Set property bag of root
     *
     * @param propertyBag      propertyBag that needs to be set as propertybag
     *                         of root.
     * @param keepRemoveFlags  Constant representing whether propertyBag should
     *                         be added to the propertyBag of root or replace it
     *                         Possible values can be:
     *                         <code>KEEP</code>
     *                         <code>REMOVE</code>
     *
     * @return                 Integer constant representing success or failure.
     *                         Possible values are:
     *                         <code>FAILURE</code>
     *                         <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setPropertyBag( PropertyBag propertyBag , int keepRemoveFlags ) {
        return m_MDRoot.setPropertyBag ( propertyBag, keepRemoveFlags );
    }

    /****************************************************
     * Short cut methods for property setting
     ****************************************************/
    /**
     * Retrieves the name of the MetadataManager bean.
     *
     * @return The name of the MetadataManager.
     *
     * @status documented
     */
    public String getMetadataManagerName() {
        String name = m_MDRoot.getName();
        if ( ( name == null ) || ( name.equals ("") ) ) {
            name = "MetadataManager_" + Integer.toString(getInstanceID()).trim();
            m_MDRoot.setName( name );
        }
        return m_MDRoot.getName();
    }

    /**
     * Specifies the name of this MetadataManager bean.
     *
     * @param name  The name for the MetadataManager.
     *
     * @status documented
     */
    public void setMetadataManagerName(String name) {
        m_MDRoot.setName( name );
    }

   	/**
     * @hidden
     * Retrieve attach status.
     *
     * @return     Integer constant representing attach status.
     *             Possible values are:
     *             <code>ATTACHED</code> if more than one database is attached.
     *             <code>NOT_ATTACHED</code> if no database is attached.
     *             <code>ATTACHING</code> if database is attaching.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public int getAttachStatus() {
        return m_MDRoot.getAttachStatus();
    }

   	/**
     * @hidden
     * Set attach status.
     *
     * @param status    Integer constant representing attach status.
     *                  Possible values are:
     *                  <code>ATTACHED</code> if more than one database is attached.
     *                  <code>NOT_ATTACHED</code> if no database is attached.
     *                  <code>ATTACHING</code> if database is attaching.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public void setAttachStatus( int status ) {
        m_MDRoot.setAttachStatus( status );
    }

   	/**
     * @hidden
     * Retrieve connection status for connection corresponding to connectionString
     * in the metadataManager.
     *
     * @param connectionString        String representing connection instance.
     *
     * @return  Constant representing connection status.  Possible values are:
     *          <code>CONNECTIONS_SET</code> if connection is set.
     *          <code>CONNECTIONS_NOT_SET</code> if connection is not set.
     *
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_SET
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_NOT_SET
     *
     * @status hidden
     */
    public int getConnectionStatus() {
        return m_MDRoot.getConnectionStatus();
    }

   	/**
     * @hidden
     * Set connection status on root.
     *
     * @param status  Constant representing connection status.
     *                Possible values are:
     *                <code>CONNECTIONS_SET</code> if connection is set.
     *                <code>CONNECTIONS_NOT_SET</code> if connection is not set.
     *
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_SET
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_NOT_SET
     *
     * @status hidden
     */
    public void setConnectionStatus( int status ) {
        m_MDRoot.setConnectionStatus( status );
    }

    /**
     * @hidden
     * This method retrieves children of mdObject.
     *
     * @param mdObjectIDs   OrderedHashtable that contains IDs of mdObject
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public OrderedHashtable getMDObjectTable ( OrderedHashtable mdObjectIDs ) throws MetadataManagerException {
        return m_MDIndex.getMDObjects( mdObjectIDs );
    }

    /************************************************************************
     * MetadataProvider interface methods
     *************************************************************************
    /************************************************************************
     * Methods for populating the Cache
     ************************************************************************/
    /**
     * @hidden
     * Retrieve MDContentBag containing children for the specified mdObject
     *
     * @param mdObject   mdObject whose contentBag is required
     *
     * @return   MDContentBag containing children of mdObject
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDContentBag getChildren( MDObject mdObject )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        mdObject.setMetadataManagerServices(this);
        return mdObject.getChildrenBag();
        /*
        MDContentBag childrenBag = mdObject.getChildrenBag();
        if( childrenBag != null && childrenBag.size() == 0 ) {
            MetadataDriver mmDriver = getMetadataDriver( mdObject.getPropertyBag() );
            if( mmDriver != null ) {
                childrenBag = mmDriver.getChildren( mdObject );
                mdObject.setChildrenBag( childrenBag );
            }
        }
        return childrenBag;
        */
    }

    /**
     * @hidden
     * This method retrieves children of mdObject.
     *
     * @param mdObject      mdObject whose children are to be retrieved.
     * @param depth         Constant representing the depth of tree under
     *                      mdObject.  Possible values are:
     *                      <code>DEMO_DATABASE</code>
     *                      <code>MEDIUM_DATABASE</code>
     *                      <code>LARGE_DATABASE</code>
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public OrderedHashtable getChildrenTillDepth( MDObject mdObject, int depth ) throws MetadataManagerException {
        MDObject obj = m_MDIndex.getMDObject(mdObject.getObjectID());
        if(obj != null) {
            mdObject = obj;
        }
        mdObject.setMetadataManagerServices( (MetadataManagerServices)this );
        if( mdObject != null && mdObject.getChildrenStatus() == MM.NOT_COMPLETE ) {
            Vector driverTypes = mdObject.getDriverTypes();
            if(driverTypes != null)
            {
                int count = driverTypes.size();
                for(int i = 0; i < count; i++)
                {
                    String driverType = (String)driverTypes.elementAt(i);
                    MetadataDriver[] mmDrivers = getMetadataDrivers(driverType);
                    for(int j = 0; j < mmDrivers.length; j++)
                    {
                        if(mmDrivers[j].isAsynchronousLoad())
                        {
                            // Current thread will sleep for a time interval here.
                            synchronized(this) {
                                while((mdObject.getChildrenStatus(driverType) == MM.NOT_COMPLETE)
                                      && !mmDrivers[j].isAsyncLoadComplete()) {
                                    try {
                                        notifyAll();
                                        wait();
                                    } catch(InterruptedException ie) {
                                    }
                                }
                            }
                        }
                        else if(mmDrivers[j].isDeferredLoad() && (mdObject.getChildrenStatus(driverType) == MM.NOT_COMPLETE))
                        {
                            if(mdObject.getChildrenStatus(driverType) != MM.COMPLETING){
                                mdObject = mmDrivers[j].addChildren( mdObject, false );
                            }
                        }
                    }
                }
                if(mdObject.getChildrenStatus() == MM.COMPLETE)
                    return mdObject.getChildrenBag().getContentTable();
                else
                    return null;
            }
        }
        OrderedHashtable _table = m_MDIndex.getChildren( mdObject, depth );

        if(_table != null)
        {
            Enumeration _enum = _table.keys();
            while (_enum.hasMoreElements())
            {
                Object _key = _enum.nextElement();
                if (_key instanceof MDObject)
                {
                    MDObject _mdObj = (MDObject)_key;
                    Object _src = _mdObj.getObjPropertyValue(MM.OLAPI_SOURCE);
                    if (_src != null && !(_src instanceof java.io.Serializable) )
                        _mdObj.removeProperty(MM.OLAPI_SOURCE);
                }
            }
        }
        return _table;
    }

    /**
     * @hidden
     * Retrieve MDContentBag for specified mdObject
     *
     * @param mdObject   mdObject whose relatives are needed
     *
     * @return   MDContentBag containing relatives
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDContentBag getRelatives(MDObject mdObject)
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        MDObject obj = m_MDIndex.getMDObject(mdObject.getObjectID());
        obj.setMetadataManagerServices(this);
        MDContentBag bag = obj.getRelativesBag();
        return bag;
    }

    /************************************************************************
     * Methods to query the cache and driver.
     ************************************************************************/
	/**
     * @hidden
     * Retrieve mdObject with specified properties.
     *
     * @param properties    properties that should exist in mdObject
     *
     * @return mdObject     mdObject that has specified properties
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject getMDObject(PropertyBag properties)
                                                throws MetadataManagerException
    {
        // check sysAgg cache
        if(m_lookupCache.size() > 0)
        {
            Object _obj = null;
            String _str = properties.getStrPropertyValue(MM.UNIQUE_ID);
            if(_str == null)
                _str = properties.getStrPropertyValue(MM.PATH);
            if(_str != null)
                _obj = m_lookupCache.get(_str);
                
            if(_obj instanceof MDObject)
            {
                properties.setIntPropertyValue(PersistableConstants.SYSTEM_AGGREGATE, MM.TRUE);
                return (MDObject)_obj;
            }
                
            _str = properties.getStrPropertyValue(MM.OLAPI_RUNTIME_ID);
            if(_str != null)  // found olapi runtime id.
            {
                for(Enumeration _enum = m_lookupCache.elements(); _enum.hasMoreElements();)
                {
                    // this is the crazy logic where OLAPI_RUNTIME_ID has to
                    // be matched with OLAPI_RUNTIME_IDS
                    Object _tmp = _enum.nextElement();
                    if(_tmp instanceof MDObject && !(_tmp instanceof MDFolder))
                    {
                        MDObject _mdObj = (MDObject)_tmp;
                        Property _prop = new Property();
                        Vector _vec = new Vector(1);
                        _vec.addElement(_str);
                        _prop.setStringVectorValue(MM.OLAPI_RUNTIME_IDS, _vec, MM.UI_NONE);
                        if(_prop.equals(_mdObj.getProperty(MM.OLAPI_RUNTIME_IDS)))
                        {
                            properties.setIntPropertyValue(PersistableConstants.SYSTEM_AGGREGATE, MM.TRUE);
                            return _mdObj;
                        }
                    }
                }
            }
        }

        // start the Clock
        long before = System.currentTimeMillis();

        MDObject mdObject = m_MDIndex.getMDObject(properties);
        if(mdObject != null)
        {
          // Stop the clock
          if ( m_IsMMTimed ) {
            long after = System.currentTimeMillis();
            m_MMTimeforSource = m_MMTimeforSource + ( after - before );
          }
          return mdObject;
        }
        else {
            // Check for measures or dimensions
            String objectType = properties.getStrPropertyValue(MDU.OBJECT_TYPE);
            String driverType = properties.getStrPropertyValue(MDU.DRIVER_TYPE);
            MetadataDriver[] mmDrivers = null;
            if(driverType != null)
                mmDrivers = getMetadataDrivers(driverType);
            else if(m_MetadataDrivers != null) {
                MetadataDriver[] drivers = new MetadataDriver[m_MetadataDrivers.size()];
                m_MetadataDrivers.copyInto(drivers);
                mmDrivers = drivers;
            }

            for(int i = 0; mmDrivers != null && i < mmDrivers.length; i++)
            {
                if(mmDrivers[i].isAsynchronousLoad())
                {
                    if(objectType != null && objectType.equals(MM.DIMENSION))
                    {
                        synchronized(this) {
                            while(m_MDRoot.getChildrenStatus() != MM.COMPLETE
                                  && !mmDrivers[i].isAsyncLoadComplete()) {
                                try {
                                    notifyAll();
                                    wait();
                                } catch(InterruptedException ie) {}
                            }
                        }
                        mdObject = m_MDIndex.getMDObject(properties);
                        if(mdObject != null) {
                            // Stop the clock
                            if ( m_IsMMTimed ) {
                                long after = System.currentTimeMillis();
                                m_MMTimeforSource = m_MMTimeforSource + ( after - before );
                            }
                            return mdObject;
                        }
                    }
                    else
                    {
                        synchronized(this) {
                            while(mdObject == null && !mmDrivers[i].isAsyncLoadComplete())
                            {
                                try {
                                    notifyAll();
                                    wait();
                                } catch(InterruptedException ie) {
                                }
                                mdObject = m_MDIndex.getMDObject(properties);
                            }
                        }
                        if(mdObject != null) {
                            // Stop the clock
                            if ( m_IsMMTimed ) {
                                long after = System.currentTimeMillis();
                                m_MMTimeforSource = m_MMTimeforSource + ( after - before );
                            }
                            return mdObject;
                        }
                    }
                }
                else if(mmDrivers[i].isDeferredLoad())
                {
                    String uniqueID = properties.getStrPropertyValue(MM.UNIQUE_ID);
                    if(uniqueID != null) {
                        MDObject _obj = mmDrivers[i].getMDObject(uniqueID);
/*
                        if(_obj instanceof MDFolder)
                        {
                            String _uid = _obj.getStrPropertyValue(MM.UNIQUE_ID);
                            String _path = _obj.getStrPropertyValue(MM.PATH);
                            if(_uid != null &&  _path != null)
                                m_lookupCache.put(_uid, _path, _obj);
                        }
*/
                        // if _obj is null, then mmDrivers[i] is
                        // the persistence driver so go to next iteration
                        // by doing nothing.  This may change when persistence
                        // driver implements getMDObject(String uniqueID)
                        if(_obj != null)
                            return _obj;
                        //return mmDrivers[i].getMDObject(uniqueID);
                    }
                    else
                    {
                        String olapID = properties.getStrPropertyValue(MM.OLAPI_METADATA_ID);
                        if(olapID != null)
                            uniqueID = MMUtilities._makeUniqueID(MDU.MDM, olapID);
                        else {
                            String path = properties.getStrPropertyValue(MM.PATH);
                            if(path != null)
                            {
                                //uniqueID = MMUtilities._makeUniqueID(MDU.PERSISTENCE, path);
                                MDObject _mdObj = mmDrivers[i].getMDObjectUsingFullPath(path);
/*
                                if(_mdObj instanceof MDFolder)
                                {
                                    String _uid = _mdObj.getStrPropertyValue(MM.UNIQUE_ID);
                                    String _path = _mdObj.getStrPropertyValue(MM.PATH);
                                    if(_uid != null &&  _path != null)
                                        m_lookupCache.put(_uid, _path, _mdObj);
                                }
*/
                                if(_mdObj != null)
                                    return _mdObj;
                            }
                        }

                        if(uniqueID != null) {
                            MDObject _obj = mmDrivers[i].getMDObject(uniqueID);
                            // if _obj is null, then mmDrivers[i] is
                            // the persistence driver so go to next iteration
                            // by doing nothing.  This may change when persistence
                            // driver implements getMDObject(String uniqueID)
/*
                            if(_obj instanceof MDFolder)
                            {
                                String _uid = _obj.getStrPropertyValue(MM.UNIQUE_ID);
                                String _path = _obj.getStrPropertyValue(MM.PATH);
                                if(_uid != null &&  _path != null)
                                    m_lookupCache.put(_uid, _path, _obj);
                            }
*/
                            if(_obj != null)
                                return _obj;
                            //return mmDrivers[i].getMDObject(uniqueID);
                        }
                        MDObject _obj = mmDrivers[i].getMDObject(properties);
                        if(_obj != null)
                            return _obj;
                    }
                }
            }
            mdObject = m_MDIndex.getMDObject(properties);
            if(mdObject != null) {
                // Stop the clock
                if ( m_IsMMTimed ) {
                  long after = System.currentTimeMillis();
                  m_MMTimeforSource = m_MMTimeforSource + ( after - before );
                }
                return mdObject;
            }
        }
        // Stop the clock
        if ( m_IsMMTimed ) {
          long after = System.currentTimeMillis();
          m_MMTimeforSource = m_MMTimeforSource + ( after - before );
        }
        return null;
    }

	/**
     * @hidden
     * Retrieves the <code>MDObject</code> object for
     * the given path.
     *
     * @param strPath The path of the <code>MDObject</code> object.
     *
     * @return The <code>MDObject</code> object.
     *
     * @status hidden
     */
    public MDObject getMDObjectByPath(String strPath)
                                                throws MetadataManagerException
    {
        return m_MDRoot.getMDObjectByPath(strPath, this, getMDRoot());
    }

	/**
     * @hidden
     * Retrieve multiple mdObject with specified properties.
     *
     * @param properties    properties that should exist in mdObject
     *
     * @return mdObject     mdObject array that have specified properties
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject[] getMDObjects(PropertyBag properties)
                                                throws MetadataManagerException
    {
        String objectType = properties.getStrPropertyValue(MDU.OBJECT_TYPE);
        Vector driverVec = getMetadataDrivers();
        MetadataDriver[] mmDrivers = new MetadataDriver[driverVec.size()];
        driverVec.copyInto(mmDrivers);
        for(int i = 0; i < mmDrivers.length; i++)
        {
            if(mmDrivers[i].isAsynchronousLoad())
            {
                if(objectType != null && objectType.equals(MM.DIMENSION))
                {
                    synchronized(this) {
                        while(m_MDRoot.getChildrenStatus() != MM.COMPLETE
                              && !mmDrivers[i].isAsyncLoadComplete())
                        {
                            try {
                                notifyAll();
                                wait();
                            } catch(InterruptedException ie) {
                            }
                        }
                    }
                }
                else
                {
                    MDObject mdObjects[] = null;
                    synchronized(this) {
                        while(!mmDrivers[i].isAsyncLoadComplete() && mmDrivers[i].isAttached())
                        {
                            try {
                                notifyAll();
                                wait();
                            } catch(InterruptedException ie) {}
                        }
                    }
                }
            }
            else if(mmDrivers[i].isDeferredLoad())
            {
                String uniqueID = properties.getStrPropertyValue(MM.UNIQUE_ID);
                MDObject[] objs = new MDObject[1];
                if(uniqueID != null) {
                    objs[0] = mmDrivers[i].getMDObject(uniqueID);
                    return objs;
                }
                else
                {
                    String olapID = properties.getStrPropertyValue(MM.OLAPI_METADATA_ID);
                    if(olapID != null)
                        uniqueID = MMUtilities._makeUniqueID(MDU.MDM, olapID);
                    else {
                        String path = properties.getStrPropertyValue(MM.PATH);
                        if(path != null)
                            uniqueID = MMUtilities._makeUniqueID(MDU.PERSISTENCE, path);
                    }

                    if(uniqueID != null) {
                        objs[0] = mmDrivers[i].getMDObject(uniqueID);
                        return objs;
                    }
                }
            }
        }
        return m_MDIndex.getMDObjects(properties);
    }

    /**
     * @hidden
     * Retrieve mdObjects that matches the given properties. (for a specified level)
     * Normally, object will come from the cache. But it can be overriden by
     * some property setting.
     *
     * @param mdObject      mdObject whose children are needed
     * @param properties    properties that we are looking for in MDObject
     *
     * @return  Array of MDObject with properties that match specified properties.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject[] getChildren( MDObject mdObject, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getChildren( properties );
    }


    /**
     * @hidden
     * Retrieve children for a particular level.
     *
     * @param mdObject      mdObject whose children are needed
     * @param properties    properties that we are looking for in MDObject
     * @param depth         depth of tree under the mdObject
     *
     * @return  Array of MDObject with properties that match specified properties.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject[] getChildren( MDObject mdObject,
                                   PropertyBag properties,
                                   int depth )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getChildren( properties, depth );
    }

    /**
     * @hidden
     * Retrieve relatives with a particular relation
     *
     * @param mdObject   mdObject whose relatives are needed
     * @param relation   relation that relative has with mdObject
     *
     * @return  Array of MDObject with specified relation.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject[] getRelatives( MDObject mdObject, String relation )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getRelatives( relation );
    }

    /**
     * @hidden
     * Retrieve relative with a particular properties
     *
     * @param mdObject      mdObject whose relatives are needed
     * @param properties    properties that we are looking for in MDObject
     *
     * @return  Array of relatives with specified relation.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject[] getRelatives( MDObject mdObject, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getRelatives( properties );
    }

  /************************************************************************
   * Methods to update the cache and the drivers.
   ************************************************************************/
    /**
     * @hidden
     * deprecated as of 3.0, please use setMDObject(MDObject, Attributes) method instead
     */
    public synchronized MDObject setMDObject(MDObject mdObject, PropertyBag properties) throws MetadataManagerException
    {
        if (properties != null)
        {
            String _relation = properties.getStrPropertyValue(MM.RELATION);
            if (_relation != null)
                mdObject.setStrPropertyValue(MM.RELATION, _relation);
            properties.removeProperty(MM.RELATION);
        }
        return setMDObject(mdObject, MMUtilities.propertyBagToAttributes(properties));
    }

    /**
     * Saves an <code>MDObject</code> that wraps a <code>UserObject</code> in it.
     * Call this method to save an object through the MetadataManager.
     * This method saves the object in the repository.
     *
     * @param mdObject  The <code>MDObject</code> that wraps the
     *                  <code>UserObject</code> that you are saving.
     * @param properties Properties for <code>mdObject</code>.
     *
     * @return  An <code>MDObject</code> on which the driver has set properties.
     *          such as the unique ID and so on.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. For example, this exception is thrown
     *          if the caller does not have permission to write to the server.
     *
     * @status documented But we'll hide this when we have a good method for this.
     */
    public MDObject setMDObject (MDObject mdObject, Attributes attributes) throws MetadataManagerException
    {
        if (mdObject == null)
            return null;

        mdObject.setMetadataManagerServices(this);

        // if mdObject has no id, generate one.
        if (mdObject.getObjectID() == MDU.ILLEGAL_LONG_VALUE)
            mdObject.setObjectID (generateMDObjectID());

        String _relation = mdObject.getStrPropertyValue (MM.RELATION);
        mdObject.removeProperty(MM.RELATION);

        String _request = mdObject.getStrPropertyValue(MM.REQUEST_TYPE);
        if (_request != null)
        {
            mdObject.removeProperty(MM.REQUEST_TYPE);
            UserObject _usrObj = mdObject.getUserObject(MM.PERSISTENCE_OBJECT);
            String _objType = mdObject.getObjectType();
            int _cacheSem = getCachingSemanticsByObjType(_objType);
            if (_cacheSem == MDU.BOTH && _usrObj != null)
                m_MDIndex.setUserObject(mdObject, _usrObj, MM.PERSISTENCE_OBJECT);
        }
        mdObject.removeUserObject(MM.PERSISTENCE_OBJECT);

        UserObjectBag usrBagInMDObj = mdObject.getUserObjectBag();
        UserObjectBag usrBagInIndex = null;
        if (_request == null || _request.equals(MM.NONREMOTE))
            usrBagInIndex = m_MDIndex.getUserObjectBag( mdObject );

        UserObjectBag usrBag = null;
        if((usrBagInMDObj != null) && (usrBagInMDObj.size() > 0))
            usrBag = usrBagInMDObj;

        if((usrBagInIndex != null) && (usrBagInIndex.size() > 0))
        {
            if(usrBag == null)
                usrBag = usrBagInIndex;
            else
            {
                Hashtable usrTable = usrBagInIndex.getUserObjectBag();
                Enumeration enumer = usrTable.keys();
                while(enumer.hasMoreElements())
                {
                    Object obj = enumer.nextElement();
                    usrBag.setUserObject( (String)obj, (UserObject)usrTable.get( obj ) );
                }
            }
        }

        if (mdObject instanceof MDFolder)
        {
            boolean _success = false;
            UnsupportedOperationException _uoe = null;

            Vector _driverTypes = mdObject.getDriverTypes();
            for (int j=0; j<_driverTypes.size(); j++)
            {
                MetadataDriver[] mmDrivers = getMetadataDrivers( (String)_driverTypes.elementAt(j) );

                for (int i=0; i<mmDrivers.length; i++)
                {
                    MetadataDriver _driver = mmDrivers[i];
                    try
                    {
                        _driver.setMDObject(mdObject, attributes);
                        _success = true;
                    }
                    catch (UnsupportedOperationException uoe)
                    {
                        _uoe = uoe;
                    }
                }
            }

            if (!_success && _uoe != null)
                throw _uoe;
        }

        if(usrBag != null && usrBag.size() > 0)
        {
            UserObject[] userObjects = usrBag.getUserObjects();
            for( int i = 0; i < userObjects.length; i++ )
            {
                int cacheSemantic = userObjects[i].getCacheSemantic();
                if( cacheSemantic == MDU.SERVER_ONLY || cacheSemantic == MDU.BOTH )
                {
                    Object obj = userObjects[i].getObject();
                    if(obj != null)
                    {
                        String relation = usrBag.getRelation( userObjects[i] );
                        m_MDIndex.setUserObject( mdObject, userObjects[i], relation );
                    }
                }

                String driverType = userObjects[i].getDriverType();
                MetadataDriver[] mmDrivers = getMetadataDrivers( driverType );

                if (mmDrivers == null || mmDrivers.length == 0)
                    if (driverType.equals(MDU.PERSISTENCE) || driverType.equals(MDU.DISCOVERER))
            		    throw new UnsupportedOperationException(MDU.MDM, getLocale());

                for( int j = 0; (mmDrivers != null) && (j < mmDrivers.length); j++ )
                {
                    try
                    {
                        mdObject = mmDrivers[j].setMDObject( mdObject, attributes );
                    }
                    catch( MetadataManagerException e )
                    {
                        if( mdObject.getBoundStatus() == MM.NOT_BOUND )
                        {
                        // this causes DR.WATSON!?
//                            m_MDIndex.removeAllUserObject( mdObject );
//                            mdObject.free();
                        }
                        throw e;
                    }
                }
            }
        }

        // clear the UserObjectBag of mdObject
        if(mdObject.getUserObjectCount() > 0)
        {
            UserObjectBag newUsrBag = mdObject.getUserObjectBag();
            UserObject[] usrObjs = mdObject.getUserObjects();
            for( int i = 0; i < usrObjs.length; i++ )
            {
                int cacheSemantic = usrObjs[i].getCacheSemantic();
                String relation = newUsrBag.getRelation( usrObjs[i] );
                if( cacheSemantic == MDU.SERVER_ONLY || cacheSemantic == MDU.BOTH )
                    m_MDIndex.setUserObject( mdObject, usrObjs[i], relation );
                mdObject.removeUserObject( relation );
            }
        }

        m_MDIndex.setMDObject (mdObject.getObjectID(), mdObject);
        MDObject mdParent = m_MDIndex.getMDObject (mdObject.getParentID());
        if (mdParent != null)
        {
            MDObject _oldMDObject = getMDObjectByPath(mdObject.getPath());
            if (_oldMDObject != null && (_oldMDObject.getObjectID() != mdObject.getObjectID()))
            {
                // remove old MDObject first
                mdParent.removeChild(_oldMDObject);
                _oldMDObject.setParent(null);
                m_MDIndex.removeMDObject(_oldMDObject);
            }

            mdParent.setChild (mdObject, _relation);
            m_MDIndex.setMDObject (mdParent.getObjectID(), mdParent);
        }

        if (m_IsBatchEventMode)
            cacheMetadataModified (mdObject, _relation);
        else
        {
            MetadataModifiedEvent event = new MetadataModifiedEvent (this, false, mdObject);
            m_EventSupport.fireMetadataModifiedEvent( event );
        }

        // piggyback support
        MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.SET);
        if (_request == null || _request.equals(MM.NONREMOTE))
            // this is a server request, piggyback changes to client
            _evt.setPiggybacked(true);
        notifyClient(_evt);

        return mdObject;
    }

    /**
     * Indicates whether this object is the client-side part of the
     * MetadataManager.
     * Because this <code>MetadataManagerImpl</code> is the main middle-tier
     * component, this method always returns <code>false</code>.
     *
     * @return  <code>false</code>.
     *
     * @status documented
     */
    public boolean isBeanClass(){
        return false;
    }

    /**
     * @hidden
     * Adds a userObject to local cache of MetadataManager.
     *
     * @param mdObject      MDObject whose userObject is being added to local cache
     * @param userObject    UserObject that needs to be added to cache.
     * @param relation      relation between userObject and mdObject
     *
     * @status hidden
     */
    public void _addUserObject( MDObject mdObject, UserObject userObject, String relation ){
        // if mdObject has no id, generate one.
        if( mdObject.getObjectID() == MDU.ILLEGAL_LONG_VALUE ) {
            mdObject.setObjectID( generateMDObjectID() );
        }
        m_MDIndex.setUserObject( mdObject, userObject, relation );
    }

	/**
     * @hidden
     * Retrieves the source object for a measure-dimension object with
     * specified database string.
     *
     * @param dbString  Database string for which source object is needed
     *
     * @return The source object.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public Object getMeasureDimensionSource( String dbString ) throws MetadataManagerException{
        return getMeasureDimensionSource ( getMeasures(), dbString );
    }

	/**
     * @hidden
     * Retrieves the source object for a measure-dimension object with
     * specified database string.
     *
     * @param mdMeasures    MDMeasure array for which source is needed
     * @param dbString      Database string for which source object is needed
     *
     * @return The source object.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public Object getMeasureDimensionSource( MDMeasure[] mdMeasures,
                                             String dbString)
                                             throws MetadataManagerException
    {
        PropertyBag propBag = new PropertyBag();
        propBag.setStrPropertyValue ( MM.DRIVER_TYPE, MM.MDM );
        propBag.setStrPropertyValue ( MM.DATABASE_STRING, dbString );
        MetadataDriver mmDriver = getMetadataDriver ( propBag );
        if ( mmDriver == null )
            return null;

        propBag = null;
        propBag = new PropertyBag();
        propBag.setStrPropertyValue ( MM.OBJECT_NAME, "MeasureDimensionSource" );
        Object obj = mmDriver.getDriverSpecificObject ( propBag, (Object) mdMeasures );
        return obj;
    }

    /**
     * Removes an <code>MDObject</code>.
     * This method removes the object from the client-side cache, from the
     * server-side cache, and from the underlying driver.
     *
     * @param mdObject  Object to remove.
     *
     * @return A constant that indicates whether the object was successfully
     *         removed. Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented but when does the exception get thrown? What
     *         possible constants might be in "isSuccess"?
     */
	public int removeMDObject( MDObject mdObject ) throws MetadataManagerException
    {
        boolean _success = false;
        UnsupportedOperationException _uoe = null;

        Vector _types = mdObject.getDriverTypes();
        for (int j=0; j<_types.size(); j++)
        {
            MetadataDriver[] _drivers = getMetadataDrivers((String)_types.elementAt(j));
            for (int i=0; i<_drivers.length; i++)
            {
                MetadataDriver _driver = (MetadataDriver)_drivers[i];
                if(_driver.getConnectionDriver().getFeature(BIConstants.WRITE))
                {
                    try
                    {
                        int _flag = _driver.removeMDObject(mdObject);
                        if (_flag == MDU.SUCCESS)
                            _success = true;
                    }
                    catch (UnsupportedOperationException uoe)
                    {
                        _uoe = uoe;
                    }
                }
            }
        }

        if (!_success && _uoe != null)
            throw _uoe;

        MDObject _mdObj = m_MDIndex.getMDObject(mdObject.getObjectID());
        if (_mdObj != null)
        {
            // this is to handle the case where a MDM/Persistence hybrid
            // object is renamed, we only want to change the MDObject if
            // and only if it is not a MDM object
            if (!MMUtilities.isMDM(_mdObj))
            {
                m_MDIndex.removeMDObject(_mdObj);
                MDObject _parent = _mdObj.getParent();
                if (_parent != null)
                    _parent.removeChild(_mdObj);
            }
            else 
            {
                if (MMUtilities.isPersistence(_mdObj))
                    _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
                
                if (MMUtilities.isDiscoverer(_mdObj))
                    _mdObj.getDriverTypes().removeElement(MDU.DISCOVERER);
            }

            // piggyback support
            String _requestType = mdObject.getStrPropertyValue(MM.REQUEST_TYPE);
            MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.REMOVE);
            if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                // this is a server request, piggyback changes to client
                _evt.setPiggybacked(true);
            else
                mdObject.removeProperty(MM.REQUEST_TYPE);

            notifyClient(_evt);
        }
        return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Remove all children from the client, server side cache and the driver.
     *
     * @param mdObject      MDObject whose children need to be removed
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int removeAllChildren( MDObject mdObject ) throws MetadataManagerException
    {
        int isSuccess = mdObject.removeAllChildren();
        if( isSuccess == MDU.SUCCESS ) {
            String driverType = mdObject.getStrPropertyValue( MDU.DRIVER_TYPE );
            MetadataDriver[] mmDrivers = getMetadataDrivers( driverType );
            for( int i = 0; i < mmDrivers.length; i++ ) {
                try{
                    isSuccess = mmDrivers[i].removeAllChildren( mdObject );
                    if( isSuccess == MDU.SUCCESS )
                        return isSuccess;
                }
                catch( MetadataManagerException e ) {
                    continue;
                }
            }
        }

        // piggyback support
        String _requestType = mdObject.getStrPropertyValue(MM.REQUEST_TYPE);
        MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.REMOVEALL);
        if (_requestType == null || _requestType.equals(MM.NONREMOTE))
            // this is a server request, piggyback changes to client
            _evt.setPiggybacked(true);
        else
            mdObject.removeProperty(MM.REQUEST_TYPE);
        notifyClient(_evt);

        return MDU.FAILURE;
    }

	/**
     * @hidden
     * Set a relative of mdObject
     *
     * @param firstObject   MDObject whose relative needs to be set
     * @param secondObject  MDObject that needs to be set as relative
     * @param relation      relation between firstObject and secondObject
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int setRelatedMDObject( MDObject firstObject,
                                   MDObject secondObject,
                                   String relation )
                                   throws MetadataManagerException
    {
        firstObject.setMetadataManagerServices(this);
        secondObject.setMetadataManagerServices(this);
        int isSuccess = firstObject.setRelative( secondObject, relation );
        if( isSuccess == MDU.SUCCESS ) {
            String driverType = firstObject.getStrPropertyValue( MDU.DRIVER_TYPE );
            MetadataDriver[] mmDrivers = getMetadataDrivers( driverType );
            for( int i = 0; i < mmDrivers.length; i++ ) {
                try{
                    isSuccess = mmDrivers[i].setRelatedMDObject( firstObject, secondObject, relation );
                    if( isSuccess == MDU.SUCCESS )
                        return isSuccess;
                }
                catch( MetadataManagerException e ) {
                    continue;
                }
            }
        }
        return MDU.FAILURE;
    }

	/**
     * @hidden
     * Remove a relative of mdObject
     *
     * @param firstObject   MDObject whose relative needs to be removed
     * @param secondObject  MDObject that needs to be removed as relative
     * @param relation      relation between firstObject and secondObject
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int removeRelatedMDObject( MDObject firstObject,	MDObject secondObject, String relation ) throws MetadataManagerException {
        int isSuccess = firstObject.removeRelative( secondObject );
        if( isSuccess == MDU.SUCCESS ) {
            String driverType = firstObject.getStrPropertyValue( MDU.DRIVER_TYPE );
            MetadataDriver[] mmDrivers = getMetadataDrivers( driverType );
            for( int i = 0; i < mmDrivers.length; i++ ) {
                try{
                    isSuccess = mmDrivers[i].removeRelatedMDObject( firstObject, secondObject, relation );
                    if( isSuccess == MDU.SUCCESS )
                        return isSuccess;
                }
                catch( MetadataManagerException e ) {
                    continue;
                }
            }
        }
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Refreshes all the cached children on the server side.  This call
     * will synchronize all the objects with the source platform.
     * The existing cache will be replced by the refreshed items.
     *
     * @param mdObject  mdObject that needs to be refreshed
     * @param depth     depth of tree under mdObject that should be refreshed
     *
     * @return          mdObject that is being refreshed
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDObject refresh(MDObject mdObject, int depth)
                                                throws MetadataManagerException
    {
        mdObject.setMetadataManagerServices(this);
        MDObject _obj = m_MDIndex.getMDObject(mdObject.getUniqueID());
        if(_obj != null) {
            mdObject = _obj;
        }

        Vector vec = mdObject.getDriverTypes();
        if(vec != null)
        {
            for(int i = 0; i < vec.size(); i++)
            {
                String dStr = (String)vec.elementAt(i);
                // get persistence drivers only because MDM will not change
                if(dStr != null && (dStr.equals(MDU.PERSISTENCE) || dStr.equals(MDU.DISCOVERER)))
                {
                    MetadataDriver[] mmDrivers = getMetadataDrivers(dStr);
                    if(mmDrivers != null && mmDrivers.length > 0)
                    {
                        if(mdObject.getObjectType().equals(MM.FOLDER)
                           || mdObject.getObjectType().equals(MM.ROOT))
                        {
                            if (dStr.equals(MDU.PERSISTENCE))
                                cleanCache(mdObject, MDU.PERSISTENCE);
                            else if (dStr.equals(MDU.DISCOVERER))
                                cleanCache(mdObject, MDU.DISCOVERER);
                        }
                        else
                        {
                            m_MDIndex.removeUserObjects(mdObject);
                            mdObject.removeAllUserObjects();
                        }
                        mdObject.setChildrenStatus(dStr, MM.NOT_COMPLETE);
                        for(int j = 0; j < mmDrivers.length; j++)
                        {
                            mmDrivers[j].addChildren(mdObject, false);
                            if(dStr.equals(MDU.DISCOVERER))
                                mmDrivers[j].refresh(mdObject);
                        }
                    }
                }
            }
        }
        MetadataManagerEvent event = new MetadataManagerEvent(this, false, null);
        m_EventSupport.fireMetadataRefreshEvent( event );
        return mdObject;
    }

    /**
     * @hidden
     */
    private void cleanCache(MDObject mdObject, String driverType) throws MetadataManagerException
    {
        if(mdObject != null && driverType != null)
        {
            MDObject[] children = getChildrenFromIndex(mdObject);
            if(children != null)
            {
                for(int i = 0; i < children.length; i++)
                {
                    if ((driverType.equals(MDU.PERSISTENCE) && !MMUtilities.isMDM(children[i])) ||
                        (driverType.equals(MDU.MDM) && MMUtilities.isMDM(children[i])) ||
                        (driverType.equals(MDU.DISCOVERER) && !MMUtilities.isMDM(children[i])))
                    {
                        if(children[i].getObjectType().equals(MM.FOLDER))
                            cleanCache(children[i], driverType);
                        m_MDIndex.removeMDObjectOnly(children[i]);
                        mdObject.removeChild(children[i]);
                    }
                }
            }
        }
    }

    /**
     * @hidden
     * Refresh userObject
     *
     * @param mdObject  mdObject that the userObject is associated with
     * @param relation relation between mdObject and userObject
     * @param driverType driverType of userObject
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public void refreshUserObject( MDObject mdObject,
                                   String relation,
                                   String driverType )
                                   throws MetadataManagerException
    {
        if (mdObject == null || relation == null || driverType == null) {
            return;
        }
        if( mdObject.getMetadataManagerServices() == null ) {
            mdObject.setMetadataManagerServices( (MetadataManagerServices)this );
        }
        MetadataDriver[] drivers = getMetadataDrivers(driverType);
        if( drivers != null ) {
            for (int i = 0; i < drivers.length; i++)
            {
                UserObject userObject = drivers[i].getUserObject(mdObject, relation, null);
                if (userObject != null) {
                    int cacheSemantic = userObject.getCacheSemantic();
                    if( cacheSemantic == MDU.SERVER_ONLY || cacheSemantic == MDU.BOTH ) {
                        m_MDIndex.setUserObject( mdObject, userObject, relation );
                    }
                }
            }
        }
    }

    /**
     * @hidden
     */
	public MDObject copy ( MDObject objectToBeCopied, MDObject newParent, PropertyBag properties ) throws MetadataManagerException
    {
        objectToBeCopied.setMetadataManagerServices(this);
        newParent.setMetadataManagerServices(this);
        String driverType = objectToBeCopied.getDriverType();
        MetadataDriver[] drivers = getMetadataDrivers(driverType);
        int _flag = -1;
        MDObject _mdObj = null;
        if( drivers != null )
        {
            UnsupportedOperationException _uoe = null;
            for (int i = 0; i < drivers.length; i++)
            {
                try
                {
                    MDObject _ret = drivers[i].copy(objectToBeCopied, newParent, properties);
                    if (_ret != null)
                        _mdObj = _ret;
                }
                catch (UnsupportedOperationException uoe)
                {
                    _uoe = uoe;
                }
            }

            if (_mdObj == null && _uoe != null)
                throw _uoe;
        }

        if (_mdObj != null)
        {
            long _parentId = newParent.getObjectID();

            MDObject _newParent = m_MDIndex.getMDObject(_parentId);
            if (_newParent != null)
            {
                _newParent.setChild(_mdObj, _mdObj.getObjectType());
                String _path = MMUtilities.composePath(_newParent, _mdObj.getName());
                if (_path != null)
                    _mdObj.setPath(_path);
            }
            m_MDIndex.setMDObject(_mdObj);

            // piggyback support
            String _requestType = properties.getStrPropertyValue(MM.REQUEST_TYPE);
            MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.COPY);
            if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                // this is a server request, piggyback changes to client
                _evt.setPiggybacked(true);
            notifyClient(_evt);
        }

        return _mdObj;
    }

  /**
   * @hidden
   */
	public int move ( MDObject objectToBeMoved, MDObject newParent, PropertyBag properties ) throws MetadataManagerException
    {
        objectToBeMoved.setMetadataManagerServices(this);
        newParent.setMetadataManagerServices(this);
        String driverType = objectToBeMoved.getDriverType();
        MetadataDriver[] drivers = getMetadataDrivers(driverType);

        long _oldParentId = objectToBeMoved.getParentID();
        long _newParentId = newParent.getObjectID();
        long _childId = objectToBeMoved.getObjectID();

        MDObject _oldParent = m_MDIndex.getMDObject(_oldParentId);
        MDObject _newParent = m_MDIndex.getMDObject(_newParentId);
        MDObject _child = m_MDIndex.getMDObject(_childId);

        int _flag = -1;
        if( drivers != null )
        {
            UnsupportedOperationException _uoe = null;
            boolean _success = false;
            for (int i = 0; i < drivers.length; i++)
            {
                try
                {
                    _flag = drivers[i].move(objectToBeMoved, newParent, properties);
                    _success = true;
                }
                catch (UnsupportedOperationException uoe)
                {
                    _uoe = uoe;
                }
            }

            if (!_success && _uoe != null)
                throw _uoe;
        }

        if (_oldParent != null && _newParent != null && _child != null)
        {
            _newParent.setChild(_child, _child.getObjectType());
            _oldParent.removeChild(_child);

            String _path = MMUtilities.composePath(_newParent, _child.getName());
            if (_path != null)
                _child.setPath(_path);
        }

        // piggyback support
        String _requestType = properties.getStrPropertyValue(MM.REQUEST_TYPE);
        MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, objectToBeMoved, MetadataModifiedEvent.MOVE);
        if (_requestType == null || _requestType.equals(MM.NONREMOTE))
            // this is a server request, piggyback changes to client
            _evt.setPiggybacked(true);
        notifyClient(_evt);

        return _flag;
    }

  /**
   * @hidden
   */
	public Vector search ( MDObject mdObject, Attributes attributes, BISearchControls controls ) throws MetadataManagerException
    {
        // This is for VB mode, should work for local too
        MDObject _obj = m_MDIndex.getMDObject(mdObject.getObjectID());
        if(_obj != null)
            mdObject = _obj;

        mdObject.setMetadataManagerServices(this);
        Vector driverTypes = mdObject.getDriverTypes();

        String _showOnlyDriver = null;
        if (controls instanceof MDSearchControls)
            _showOnlyDriver = ((MDSearchControls)controls).getDriverType();

        MetadataManagerException _ex = null;
        boolean _success = false;

        // for now, this is okay, in the end we need to merge
        // results coming back from drivers
        Vector _result = new Vector(100, 100);
        for (int j=0; j<driverTypes.size(); j++)
        {
            String _driver = (String)driverTypes.elementAt(j);

            if (_showOnlyDriver == null || (_showOnlyDriver != null && _driver.equals(_showOnlyDriver)))
            {
                MetadataDriver[] drivers = getMetadataDrivers(_driver);
                if( drivers != null )
                {
                    for (int i = 0; i < drivers.length; i++)
                    {
                        try
                        {
                            Vector _temp = drivers[i].search(mdObject, attributes, controls);
                            // at least one driver succeed
                            _success = true;
                            if (_temp != null && _temp.size() > 0)
                            {
                                for (int k=0; k<_temp.size(); k++)
                                    _result.addElement(_temp.elementAt(k));
                            }
                        }
                        catch(InvalidPropertyException ipe)
                        {
                            m_errHandler.log(ipe.getLocalizedMessage(), getClass().getName(), "search");
                        }
                        catch (MetadataManagerException e)
                        {
                            _ex = e;
                        }
                    }
                }
            }
        }

        if(_result != null && _result.size() == 0 && _ex != null && !_success)
            throw _ex;

        return _result;
    }

    public Vector search(String uniqueID, Attributes attributes, BISearchControls controls ) throws MetadataManagerException
    {
        MDObject _folder = m_MDIndex.getMDObject(MM.UNIQUE_ID, uniqueID);
        if(_folder == null)
            _folder = m_MDRoot;

        Vector _results = new Vector();
        if(_folder != null)
        {
            Vector _driverTypes = null;
            if((controls instanceof MDSearchControls) && ((MDSearchControls)controls).getDriverType() != null)
            {
                _driverTypes = new Vector(1);
                _driverTypes.addElement(((MDSearchControls)controls).getDriverType());
            }
            else
                _driverTypes = _folder.getDriverTypes();
            
            for(int i=0; _driverTypes != null && i < _driverTypes.size(); i++)
            {
                String _driverType = (String)_driverTypes.elementAt(i);
                MetadataDriver _drivers[] = getMetadataDrivers(_driverType);
                for(int j=0; _drivers != null && j < _drivers.length; j++)
                {
                    String _uniqueID = _folder.getUniqueID(_driverType);
                    Vector _vec = _drivers[j].search(_uniqueID, attributes, controls);
                    for(int k=0; _vec != null && k < _vec.size(); k++)
                        _results.addElement(_vec.elementAt(k));
                }
            }
            
            // check for merged folders
            mergeFolderDrivertypes(_results);
        }
        return _results;
    }

    private void mergeFolderDrivertypes(Vector results)
    {
        Hashtable _flds = new Hashtable();  // key=path : value=MetadataManagerSearchResultImpl
        Vector _removeList = new Vector();
        for(Enumeration _enum = results.elements(); _enum.hasMoreElements();)
        {
            MetadataManagerSearchResultImpl _impl = (MetadataManagerSearchResultImpl)_enum.nextElement();
            if(MM.FOLDER.equals(_impl.getObjectType()))
            {
                String _path = _impl.getFullPathName();
                if(_path != null && _flds.containsKey(_path)) // folder already exists, merge!
                {
                    ((MetadataManagerSearchResultImpl)_flds.get(_path)).setDriverType(_impl.getDriverType());
                    _removeList.addElement(_impl);
                }
                else
                    _flds.put(_path, _impl);
            }
        }

        if(_removeList.size() > 0)
        {
            for(Enumeration _enum = _removeList.elements(); _enum.hasMoreElements();)
                results.remove(_enum.nextElement());
        }
    }

    /**
     * @hidden
     */
    public int renameMDObject(MDObject mdObject, Name newName) throws MetadataManagerException
    {
        mdObject.setMetadataManagerServices(this);
        if (newName != null)
        {
            int _flag = MDU.SUCCESS;
            Vector driverType = mdObject.getDriverTypes();

            UnsupportedOperationException _uoe = null;
            boolean _success = false;

            for (int j=0; j<driverType.size(); j++)
            {
                MetadataDriver[] drivers = getMetadataDrivers((String)driverType.elementAt(j));

                if( drivers != null )
                {
                    for (int i = 0; i < drivers.length; i++)
                    {
                        try
                        {
                            _flag = drivers[i].renameMDObject(mdObject, newName);
                            _success = true;
                        }
                        catch (UnsupportedOperationException uoe)
                        {
                            _uoe = uoe;
                        }
                    }
                }
            }

            if (!_success && _uoe != null)
                throw _uoe;

            MDObject _mdObj = m_MDIndex.getMDObject(mdObject.getObjectID());
            if (_mdObj != null)
            {
                // this is to handle the case where a MDM/Persistence hybrid
                // object is renamed, we only want to change the MDObject if
                // and only if it is not a MDM object
                if (!MMUtilities.isMDM(_mdObj))
                {
                    String _newName = newName.get(newName.size()-1);
                    _mdObj.setName(_newName);

                    MDObject _parent = _mdObj.getParent();
                    String _path = MMUtilities.composePath(_parent, _newName);
                    if (_path != null)
                        _mdObj.setPath(_path);
                }
                else
                {
                    if (MMUtilities.isPersistence(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
                    if (MMUtilities.isDiscoverer(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.DISCOVERER);
                }

                // piggyback support
                String _requestType = mdObject.getStrPropertyValue(MM.REQUEST_TYPE);
                mdObject.removeProperty(MM.REQUEST_TYPE);
                MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.RENAME);
                if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                    // this is a server request, piggyback changes to client
                    _evt.setPiggybacked(true);
                notifyClient(_evt);
            }

            return _flag;
        }
        else
            return MDU.SUCCESS;
    }
     
    /**
     * Modifies the properties of an <code>MDObject</code>.
     * This method changes the properties of the object in the repository.
     *
     * @param mdObject  The <code>MDObject</code> in which the properties
     *                  are updated.
     * @param properties Properties that have changed for <code>mdObject</code>.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem modifying
     *          the properties of the object on the server. For example, this
     *          exception is thrown if the caller does not have permission
     *          to write to the server.
     *
     * @status documented
     */
    public int modifyMDObject(MDObject mdObject, ModificationItem[] items) throws MetadataManagerException
    {
        mdObject.setMetadataManagerServices(this);
        if (items != null)
        {
            int _flag = MDU.SUCCESS;
            Vector driverType = mdObject.getDriverTypes();

            UnsupportedOperationException _uoe = null;
            boolean _success = false;

            for (int j=0; j<driverType.size(); j++)
            {
                MetadataDriver[] drivers = getMetadataDrivers((String)driverType.elementAt(j));
                if( drivers != null )
                {
                    for (int i = 0; i < drivers.length; i++)
                    {
                        try
                        {
                            _flag = drivers[i].modifyMDObject(mdObject, items);
                            _success = true;
                        }
                        catch (UnsupportedOperationException uoe)
                        {
                            _uoe = uoe;
                        }
                    }
                }
            }

            if (!_success && _uoe != null)
                throw _uoe;

            MDObject _mdObj = m_MDIndex.getMDObject(mdObject.getObjectID());
            if (_mdObj != null)
            {
                // this is to handle the case where a MDM/Persistence hybrid
                // object is renamed, we only want to change the MDObject if
                // and only if it is not a MDM object
                if (!MMUtilities.isMDM(_mdObj))
                {
                    // populate MDObject properties (todo)
                }
                else
                {
                    if (MMUtilities.isPersistence(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
                    if (MMUtilities.isDiscoverer(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.DISCOVERER);
                }

                // piggyback support
                String _requestType = mdObject.getStrPropertyValue(MM.REQUEST_TYPE);
                mdObject.removeProperty(MM.REQUEST_TYPE);
                MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.MODIFY);
                if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                    // this is a server request, piggyback changes to client
                    _evt.setPiggybacked(true);
                notifyClient(_evt);
            }

            return _flag;
        }
        else
            return MDU.SUCCESS;
    }

  /************************************************************************
  * Operations on the objects that only exist on the source platform.
  ************************************************************************/

    /**
     * @hidden
     * Retrieve the driver specific objects from the driver
     *
     * @param properties    properties that should match with the object we are
     *                      looking for
     * @param object        Object needed to get driver specific object
     *
     * @return              driver specific object
     *
     * @throws              MetadataManagerException
     *
     * @status hidden
     */
    public Object getDriverSpecificObject(PropertyBag properties,
                                          Object object)
                                          throws MetadataManagerException
    {
        String other = properties.getStrPropertyValue ( "DEBUG" );
        if (( other != null ) && ( other.equals( "PRINT_TIME_INFO" ))) {
            printTimeInfo();
            return null;
        }
        else if (( other != null ) && ( other.equals( "RESET_TIME_INFO" ))) {
            resetTimeInfo();
            return null;
        }

        String driverType = properties.getStrPropertyValue ( MDU.DRIVER_TYPE );

        MetadataDriver[] metadataDrivers = getMetadataDrivers ( driverType );
        if ( metadataDrivers == null )
            return null;

        for ( int i = 0; (i < metadataDrivers.length) ; i ++ ) {
            String dbStr = properties.getStrPropertyValue(MM.DATABASE_STRING);
            if(dbStr != null && !dbStr.equals("")) {
                if(metadataDrivers[i].getDatabaseString().equals(dbStr))
                    return (Object) metadataDrivers[i].getDriverSpecificObject ( properties, object );
            }
            else
                return metadataDrivers[i].getDriverSpecificObject(properties, object);
        }
        return null;
    }

    /**
     * @hidden
     * Set the driver specific objects on the driver
     *
     * @param object        driver specific object that needs to be set
     * @param properties    properties needed to set driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              MetadataManagerException
     *
     * @status hidden
     */
    public int setDriverSpecificObject( Object object, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if(properties != null) {
            String errorHandler = properties.getStrPropertyValue("ErrorHandler");
            if(errorHandler != null)
            {
                if(errorHandler.equals("add"))
                    m_errHandler = (ErrorHandler)object;
                else
                    m_errHandler = new DefaultErrorHandler();
                int success = MDU.FAILURE;
                for ( int i = 0; m_MetadataDrivers != null && i < m_MetadataDrivers.size(); i++ ) {
                    success = ((MetadataDriver)m_MetadataDrivers.elementAt(i)).setDriverSpecificObject(m_errHandler, properties);
                }
                return success;
            }
        }
        String driverType = properties.getStrPropertyValue(MDU.DRIVER_TYPE);
        MetadataDriver[] metadataDrivers = getMetadataDrivers ( driverType );
        if ( metadataDrivers == null )
            return MDU.FAILURE;
        for ( int i = 0; (i < metadataDrivers.length); i ++ ) {
            return metadataDrivers[i].setDriverSpecificObject ( object, properties );
        }
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Remove the driver specific objects at driver level
     *
     * @param properties    properties needed to remove driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int removeDriverSpecificObjects( PropertyBag properties )
                                                throws MetadataManagerException
    {
        String driverType = properties.getStrPropertyValue ( MDU.DRIVER_TYPE );
        MetadataDriver[] metadataDrivers = getMetadataDrivers ( driverType );
        if ( metadataDrivers == null )
            return MDU.FAILURE;
            for ( int i = 0; (i < metadataDrivers.length); i ++ ) {
                if ( metadataDrivers[i].getDatabaseString().equals ( properties.getStrPropertyValue ( MM.DATABASE_STRING ) ))
                    return metadataDrivers[i].removeDriverSpecificObjects ( properties );
        }
        return MDU.FAILURE;
    }

    /************************************************************************
     * Support for Security
     ************************************************************************/
    /**
     * @hidden
     */
    public boolean addEntries(MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        folder.setMetadataManagerServices(this);
        if (MMUtilities.isPersistence(folder))
        {
            MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

            boolean _flag = false;
            // should be only one persistence driver
            if( drivers != null )
            {
                for (int i = 0; i < drivers.length; i++)
                    _flag = drivers[i].addEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
            }
            return _flag;
        }
        else
            throw new UnsupportedOperationException(folder.getDriverType(), getLocale());
    }

    /**
     * @hidden
     */
    public boolean removeEntries(MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        folder.setMetadataManagerServices(this);
        if (MMUtilities.isPersistence(folder))
        {
            MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

            boolean _flag = false;
            // should be only one persistence driver
            if( drivers != null )
            {
                for (int i = 0; i < drivers.length; i++)
                    _flag = drivers[i].removeEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
            }
            return _flag;
        }
        else
            throw new UnsupportedOperationException(folder.getDriverType(), getLocale());
    }

    /**
     * @hidden
     */
    public boolean setEntries(MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        folder.setMetadataManagerServices(this);
        if (MMUtilities.isPersistence(folder))
        {
            MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

            boolean _flag = false;
            // should be only one persistence driver
            if( drivers != null )
            {
                for (int i = 0; i < drivers.length; i++)
                    _flag = drivers[i].setEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
            }
            return _flag;
        }
        else
            throw new UnsupportedOperationException(folder.getDriverType(), getLocale());
    }

    /**
     * @hidden
     */
    public Vector entries (MDFolder folder, Name name) throws MetadataManagerException
    {
        folder.setMetadataManagerServices(this);
        if (MMUtilities.isPersistence(folder))
        {
            MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

            Vector _entries = null;
            // should be only one persistence driver
            if( drivers != null )
            {
                for (int i = 0; i < drivers.length; i++)
                    _entries = drivers[i].entries(folder, name);
            }
            return _entries;
        }
        else
            throw new UnsupportedOperationException(folder.getDriverType(), getLocale());
    }


    /**
     * @hidden
     */
    public Vector getAllUsers() throws MetadataManagerException
    {
        MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

        Vector _users = null;
        // should be only one persistence driver
        if( drivers != null )
        {
            if (drivers.length > 0)
                _users = drivers[0].getAllUsers();
        }
        return _users;
    }

    /**
     * @hidden
     */
    public Privilege getPrivilege(MDFolder folder, Name name) throws MetadataManagerException
    {
        folder.setMetadataManagerServices(this);
        if (MMUtilities.isPersistence(folder))
        {
            MetadataDriver[] drivers = getMetadataDrivers(MDU.PERSISTENCE);

            Privilege _priv = null;
            // should be only one persistence driver
            if( drivers != null )
            {
                try
                {
                    for (int i = 0; i < drivers.length; i++)
                        _priv = drivers[i].getPrivilege(folder, name);
                }
                catch (NameNotBoundException nnbe)
                {
                    if (MMUtilities.isDiscoverer(folder) || MMUtilities.isMDM(folder))
                        throw new UnsupportedOperationException(folder.getDriverType(), getLocale());        
                    else
                        throw nnbe;
                }
            }
            return _priv;
        }
        else
            throw new UnsupportedOperationException(folder.getDriverType(), getLocale());
    }

  /************************************************************************
  * Other
  ************************************************************************/
    /**
     * @hidden
     * Free all the contents and the object itself
     *
     * @param mdObject  MDObject that needs to be freed
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int free( MDObject mdObject) throws MetadataManagerException {
        return m_MDIndex.removeMDObject( mdObject );
    }

    /**
     * Frees resources that the MetadataManager bean uses.
     * Call this method before you close your application.
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status Documented-PriorityReview  -- is it really necessary to call this?
     * When should they?
     */
    public int free() throws MetadataManagerException {
        if ( getAttachStatus() == MM.ATTACHED ) {
            if ( detach() == MM.ATTACHED );
                return MDU.FAILURE;
        }
        m_MDRoot.free();
        m_MDIndex.free();
        m_MDRoot = null;
        m_MDIndex = null;
        if(m_lookupCache != null) 
            m_lookupCache.clear();
        m_lookupCache = null;
        return MDU.SUCCESS;
    }

  /************************************************************************
  *											MetadataManagerService interface methods
  *************************************************************************

  /************************************************************************
  * Attach and Detach Drivers
  ************************************************************************/
    /**
     * @hidden
     * Attach a Metadata Driver
     * Not Implemented
     *
     * @status hidden
     */
    public int attachDriver( PropertyBag propertyBag )
                                                throws MetadataManagerException
    {
        return 0;
    }

    /**
     * @hidden
     * Detach a Metadata Driver
     * Not Implemented
     *
     * @status hidden
     */
    public int detachDriver(PropertyBag properties)
                                                throws MetadataManagerException
    {
        return 0;
    }

    /**
     * @hidden
     * Is the Driver Attached?
     * Not Implemented
     *
     * @status hidden
     */
    public boolean isDriverAttached(PropertyBag propertyBag)
    {
        if(propertyBag != null && propertyBag.size() > 0)
        {
            String _dType = propertyBag.getStrPropertyValue(MDU.DRIVER_TYPE);
            if(_dType != null)
            {
                MetadataDriver[] _drivers = null;
                try
                {
                    _drivers = getMetadataDrivers(_dType);
                }
                catch(MetadataManagerException e)
                {
                    getErrorHandler().error(e, getClass().getName(), "isDriverAttached");
                }
                if(_drivers != null && _drivers.length > 0)
                {
                    for(int i = 0; i < _drivers.length && _drivers[i].isAttached(); i++)
                    {
                        // if propertyBag contains only one property then it has
                        // to be driverType so return true.
                        if(propertyBag.size() == 1)
                            return true;

                        Property[] props = propertyBag.getProperties();
                        try
                        {
                            PropertyBag _bag = _drivers[i].getConnectionDriver().getConnectionPropertyBag();
                            // loop through all properties and when the loop end and j == props.length
                            // then connection driver contained all properties passed-in by user
                            int j;
                            for(j = 0; j < props.length && _bag.contains(props[j]); j++);
                            if(j == props.length)
                                return true;
                        }
                        catch(Exception e)
                        {
                            getErrorHandler().error(e, getClass().getName(), "isDriverAttached");
                        }
                    }
                }
            }
        }
        return false;
    }

  /************************************************************************
  * Get objects from any tier..
  ************************************************************************/

    /**
     * @hidden
     * Retrieve an mdObject from cache.
     *
     * @param mdObjectID    ID of the mdObject that need to be retrieved
     *
     * @return  MDObject with specified objectID
     *
     * @status hidden
     */
    public MDObject getMDObjectByID( long mdObjectID ) {
        return m_MDIndex.getMDObject ( mdObjectID );
    }

  /************************************************************************
  * Support for User Objects ( for example XML object of Graph)
  * from the driver based on an MDObject.
  ************************************************************************/
    /**
     * @hidden
     * Retrieve the userObject
     *
     * @param mdObject      mdObject that contains the userObject
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public UserObject getUserObject (MDObject mdObject,
                                     String relation,
                                     String driverType )
                                     throws MetadataManagerException
    {
        return getUserObject(mdObject, relation, driverType, null);
    }

    /**
     *  @hidden
     *  Updates the <code>MDObject</code> dependency associated with an
     *  <code>MDObject</code> on the client via piggyback.
     *
     *  @param  mdObject a <code>MDObject</code> value containing the
     *          <code>MDObject</code> objects to update.
     *
     *  @throws MetadataManagerException if the dependent objects can't be
     *          retrieved or updated
     *  @status hidden
     */
    protected void updateDependency (MDObject mdObject) throws MetadataManagerException {
      if (mdObject != null) {
        // Set up the dependent load client event
        MetadataModifiedEvent metadataModifiedEvent =
          new MetadataModifiedEvent (this, false, mdObject,
            MetadataModifiedEvent.DEPENDENT_LOAD);

        // Piggyback multiple events together
        metadataModifiedEvent.setPiggybacked(true);

        // gek 08/06/01 Fix Bug 1900268: Custom measures don't properly reconstruct
        //              dimensionality in VB mode
        //
        //              Make sure that we update the server's dependencies as
        //              well as the client's.
        m_MDIndex.setMDObject (mdObject);

        // Add this event to the piggy back list sent to client
        notifyClient(metadataModifiedEvent);
      }
    }

    /**
     *  @hidden
     *  Updates the <code>MDObject</code> dependencies associated with each
     *  <code>MDObject</code> on the client via piggyback.
     *
     *  This includes updating the entire MDObject dependency tree associated
     *  with each top level object passed in.
     *
     *  @param  mdObjects a <code>MDObject[]</code> value containing an array
     *          of <code>MDObject</code> objects to update.
     *
     *  @throws MetadataManagerException if the dependent objects can't be
     *          retrieved or updated
     *
     *  @status hidden
     */
    protected void updateDependencies (MDObject[] mdObjects)
                                        throws MetadataManagerException {
      // Make sure that we have a valid MDObject array
      if ((mdObjects != null) && (mdObjects.length > 0)) {

        // Iterate over each dependent MDObject
        for (int i = 0; i < mdObjects.length; i++) {

          // Recursively process dependent objects
          updateDependencies (mdObjects[i].getDependents());

          // Update the dependencies associated with this MDObject
          updateDependency (mdObjects[i]);
        }
      }
    }

    /**
     * @hidden
     * Retrieve the userObject
     *
     * @param mdObject      mdObject that contains the userObject
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     * @param args          hashtable that might contain objects that can help restore
     *                      userObject on client side.
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public UserObject getUserObject (MDObject mdObject, String relation,
                                     String driverType, Hashtable args )
                                     throws MetadataManagerException {
      mdObject.setMetadataManagerServices(this);
      if (mdObject == null || relation == null) {
        return null;
      }

      String _id  = mdObject.getUniqueID();
      if(_id != null)
      {
          Object _obj = m_lookupCache.get(_id);
          if(_obj != null)
          {
            if(args != null)
              args.put(PersistableConstants.SYSTEM_AGGREGATE, new Integer(MM.TRUE));
            return new UserObject(_obj, MM.PERSISTENCE);
          }
      }

      UserObject userObject = m_MDIndex.getUserObject (mdObject, relation);
      if (userObject != null )
        return userObject;

      MetadataDriver[] drivers = getMetadataDrivers(driverType);
      for (int i = 0; i < drivers.length; i++) {
        userObject = drivers[i].getUserObject(mdObject, relation, args);
        if (userObject != null)
          break;
      }

      // Store the object in cache if it's supposed to be there according to
      // its caching semantics
      int mdObjCachingSemantics =
        getCachingSemanticsByObjType (mdObject.getObjectType());

      if (mdObjCachingSemantics != MDU.NONE &&
          mdObjCachingSemantics != MDU.CLIENT)
        m_MDIndex.setUserObject (mdObject, userObject, relation);

      // Send the dependents back to client if there are any
      if (userObject != null) {
        // Fix Bug 1900268: Custom measures don't properly reconstruct dimensionality
        //                  in VB mode.

        // Recursively update MDObject
        MDObject[] mdObjects = new MDObject [1];
        mdObjects[0] = mdObject;
        updateDependencies (mdObjects);
      }

      return userObject;
    }

    /**
     * @hidden
     * Retrieves a <code>UserObject</code>.
     *
     * @param mdObject      mdObject that contains the userObject
     * @param persistable   Persistable object that will be passed
     *                      to a handler when creating a new object
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     * @param args          hashtable that might contain objects that can help restore
     *                      userObject on client side.
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status hidden
     */
    public UserObject getUserObject( MDObject mdObject,
                                     Persistable persistable,
                                     String relation,
                                     String driverType,
                                     Hashtable args )
                                     throws MetadataManagerException
    {
        return getUserObject(mdObject, relation, driverType, args);
    }

    /**
     * @hidden
     * return the UserObject in MDIndex, needed by the driver
     */
    public UserObject _getUserObject(MDObject mdObject, String relation)
    {
        if( mdObject == null || relation == null )
            return null;

        return m_MDIndex.getUserObject(mdObject, relation);
    }

  /************************************************************************
  * MetadataManagerObject interface methods
  *************************************************************************/

  /************************************************************************
  * Connection Support
  *************************************************************************/
    /**
     * @hidden
     * Set a Connection object to this MetadataManager instance
     *
     * @param connectionObject   A connection object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int setConnectionObject( Object connectionObject)
                                                throws MetadataManagerException
    {
        if ( connectionObject == null )
            return MDU.FAILURE;
        if ( m_ConnectionImpls == null )
            m_ConnectionImpls = new Vector();
        ConnectionImpl connectionImpl = (ConnectionImpl) connectionObject;
        m_ConnectionImpls.addElement((Object)connectionImpl);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Set Connection objects to this MetadataManager instance
     *
     * @param connections   Array of connection objects
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public int setConnectionObjects( Object[] connectionObjects)
                                                throws MetadataManagerException
    {
        if ( connectionObjects == null )
            return MDU.FAILURE;

        int count = connectionObjects.length;
        if (  count == 0)
            return MDU.FAILURE;

        for ( int i = 0; i < count ; i++ ) {
            setConnectionObject( connectionObjects[i] );
        }
        setConnectionStatus ( MM.CONNECTIONS_SET ) ;
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Get all the Connection Objects associated to this MetadataManager
     * Object.
     *
     * @return  Array of connection objects set on MetadataManager instance
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public Object[] getConnectionObjects()
                                                throws MetadataManagerException
    {
        return null;
    }


    /**
     * @hidden
     * Get a particular Connection Object
     *
     * @param connectionString  connection string that will be used to get
     *                          connection object
     *
     * @return  A connection objects set on MetadataManager instance
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public Object getConnectionObject( String connectionString )
                                                throws MetadataManagerException
    {
        return null;
    }

    /************************************************************************
     * Support for generating ID
     ************************************************************************/
    /**
     * @hidden
     * Support for generating ID
     *
     * @return   long value which can be used as a unique id for this JVM.
     *
     * @status hidden
     */
    public long generateMDObjectID() {
        return generateID();
    }

    /**
     * @hidden
     * Support for generating ID
     *
     * @return   long value which can be used as a unique id for this session.
     *
     * @status hidden
     */
    public static long generateID() {
        return m_UniqueID++;
    }


    /************************************************************************
     *                      MetadataManager Server Short cut methods
     *************************************************************************/
    /**
     * Retrieves the <code>MDFolder</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDFolder</code> objects.
     *
     * @status documented
     */
    public MDFolder[] getFolders() throws MetadataManagerException {
        return m_MDRoot.getFolders();
    }

    /**
     * Retrieves the <code>MDMeasure</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDMeasure</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     * 
     * @status documented
     */
    public MDMeasure[] getMeasures() throws MetadataManagerException {
        PropertyBag propBag = new PropertyBag();
        propBag.setStrPropertyValue( MDU.OBJECT_TYPE, MM.MEASURE );
        return MDMeasure.getMeasureArray(getMDObjects(propBag));
    }

    /**
     * Retrieves the <code>MDDimension</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDDimension</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status documented
     */
    public MDDimension[] getDimensions() throws MetadataManagerException {
      PropertyBag propBag = new PropertyBag();
      propBag.setStrPropertyValue( MDU.OBJECT_TYPE, MM.DIMENSION );
      return MDDimension.getDimensionArray(getMDObjects(propBag));
    }

    /**
     * Compare two unique ID level strings and determine if they are equivalent
     *
     * @param id1   first ID string to compare
     * @param id2   second ID string to compare
     * 
     * @return <code>true</code> if they are equivalent, <code>false</code> if not
     *
     * @status Documented
     */
    public boolean areLevelIDsEquivalent(String id1, String id2)
    {
        try
        {
            MDLevel level1 = (MDLevel)getMDObject(MM.UNIQUE_ID, id1, MM.LEVEL);
            if (level1 != null)
            {
                MDLevel level2 = (MDLevel)getMDObject(MM.UNIQUE_ID, id2, MM.LEVEL);
                if (level2 != null)
                {
                    return level1.nameEquals(level2);
                }
            }
        }
        catch (MetadataManagerException e)
        {
            m_errHandler.error(e, getClass().getName(), "areLevelIDsEquivalent");
        }
        
        return false;
    }

    /**
     * @hidden
     *  gek 12/04/00
     *
     *  Determines if the specified property values can be found in this
     *  object's string vector.  This routine will only return <code>true</code>
     *  if ALL values in the property vector can be found.
     *
     *  @param  strPropertyName a <code>String</code> value that
     *          represents the property name to find.
     *  @param  vstrPropertyValues a <code>vector</code> value that contains
     *          a list of property values to find.
     *  @param  strObjectType a <code>String</code> value that contains
     *          the object's type.
     *  @return <code>MDObject</code> which represents the retrieved object, or
     *          null
     *
     *  @throws MetadataManagerException
     *
     *  @status hidden
     */
  	public MDObject getMDObject(String strPropertyName,
                                Vector vstrPropertyValues,
                                String objectType)
                                throws MetadataManagerException {
    	PropertyBag propertyBag = new PropertyBag();
      	propertyBag.setStringVectorPropertyValue(strPropertyName,
                                                 vstrPropertyValues,
                                                 MDU.UI_NONE);
		return getMDObject(propertyBag);
  	}

    /**
     * @hidden
     *  Retrieve if the specified values can be found in this metadataManager
     *
     *  @param  strPropertyName a <code>String</code> value that
     *          represents the property name to find.
     *  @param  strPropertyValue a <code>String</code> value that
     *          represents the property value to find.
     *  @param  strObjectType a <code>String</code> value that contains
     *          the object's type.
     *  @return <code>MDObject</code> which represents the retrieved object, or
     *          null
     *
     *  @throws MetadataManagerException
     *
     *  @status hidden
     */
    public MDObject getMDObject(String strPropertyName,
                                String strPropertyValue,
                                String objectType)
                                throws MetadataManagerException {
     	PropertyBag propertyBag = new PropertyBag();
    	propertyBag.setStrPropertyValue(strPropertyName,
                                        strPropertyValue,
                                        MDU.UI_NONE);
    	propertyBag.setStrPropertyValue(MDU.OBJECT_TYPE,
                                        objectType,
                                        MDU.UI_NONE);
    	return getMDObject(propertyBag);
    }

  	/**
  	 * Retrieves the first <code>MDFolder</code> object that has a specified
     * property value.
     *
     * @param  strPropertyName a <code>String</code> value that
     *         represents the property name to find.
     * @param  strPropertyValue a String value that contains
     *         a property value to find.e.
     *
     * @return The first folder that has the <code>strPropertyValue</code> value
     *         for the <code>strPropertyName</code> property, or <code>null</code>
     *         if no folder can be found that has the property value.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDFolder getFolder(String strPropertyName,
                              String strPropertyValue )
                              throws MetadataManagerException {
        return (MDFolder) getMDObject ( strPropertyName,
                                        strPropertyValue,
                                        MM.FOLDER );
    }

  	/**
     * Retrieves the first selection that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first selection that has the specified property value, or
     *         <code>null</code> if no selection can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDSelection getSelection(String strPropertyName,
                                    String strPropertyValue )
                                    throws MetadataManagerException {
        return (MDSelection) getMDObject ( strPropertyName,
                                           strPropertyValue,
                                           MM.SELECTION );
    }

    /**
	   * Retrieves the first <code>MDComponent</code> that has a specified
     * property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return <code>MDComponent</code> that has the specified property value,
     *         or <code>null</code> if no object can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status documented
     */
    public MDComponent getComponent(String strPropertyName,
                                    String strPropertyValue )
                                    throws MetadataManagerException {
        return (MDComponent) getMDObject ( strPropertyName,
                                           strPropertyValue,
                                           MM.COMPONENT );
    }

  	/**
     * Retrieves the first measure that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first measurethat has the specified property value, or
     *         <code>null</code> if no measure can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDMeasure getMeasure(String strPropertyName,
                                String strPropertyValue )
                                throws MetadataManagerException {
        return (MDMeasure) getMDObject ( strPropertyName,
                                         strPropertyValue,
                                         MM.MEASURE );
    }

  	/**
     * Retrieves the first dimension that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first dimension that has the specified property value, or
     *         <code>null</code> if no dimension can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDDimension getDimension(String strPropertyName,
                                    String strPropertyValue )
                                    throws MetadataManagerException {
        return (MDDimension) getMDObject ( strPropertyName,
                                           strPropertyValue,
                                           MM.DIMENSION );
    }

  	/**
     * Retrieves the first hierarchy that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first hierarchy that has the specified property value, or
     *         <code>null</code> if no hierarchy can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDHierarchy getHierarchy(String strPropertyName,
                                    String strPropertyValue )
                                    throws MetadataManagerException {
        return (MDHierarchy) getMDObject ( strPropertyName,
                                           strPropertyValue,
                                           MM.HIERARCHY );
    }

  	/**
     * Retrieves the first attribute that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first attribute that has the specified property value, or
     *         <code>null</code> if no attribute can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDAttribute getAttribute(String strPropertyName,
                                    String strPropertyValue )
                                    throws MetadataManagerException {
        return (MDAttribute) getMDObject ( strPropertyName,
                                           strPropertyValue,
                                           MM.ATTRIBUTE );
    }

  	/**
     * Retrieves the first level that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first level that has the specified property value, or
     *         <code>null</code> if no level can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
    public MDLevel getLevel(String strPropertyName,
                            String strPropertyValue )
                            throws MetadataManagerException {
        return (MDLevel) getMDObject ( strPropertyName, strPropertyValue, MM.LEVEL );
    }

  	/**
     * @hidden
	 * Returns the <code>MDFolder</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDFolder</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDFolder getFolderByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getFolder(MM.OLAPI_METADATA_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDSelection</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDSelection</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDSelection getSelectionByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getSelection(MM.UNIQUE_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDComponent</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDComponent</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDComponent getComponentByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getComponent(MM.UNIQUE_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDMeasure</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDMeasure</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDMeasure getMeasureByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getMeasure(MM.UNIQUE_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDDimension</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDDimension</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDDimension getDimensionByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getDimension(MM.UNIQUE_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDAttribute</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDAttribute</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDAttribute getAttributeByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getAttribute(MM.OLAPI_METADATA_ID, strUniqueID);
    }

  	/**
     * @hidden
	 * Returns the <code>MDHierarchy</code> object that contains unique ID that
	 * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDHierarchy</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDHierarchy getHierarchyByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getHierarchy(MM.OLAPI_METADATA_ID, strUniqueID);
    }

  	/**
     * @hidden
	   * Returns the <code>MDLevel</code> object that contains unique ID that
	   * is equal to the given unique ID.
     *
     * @param  strUniqueID a <code>String</code> value that
     *         represents the unique ID to find.
     *
     * @return <code>MDLevel</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MDLevel getLevelByUniqueID(String strUniqueID)
                                                throws MetadataManagerException
    {
        return getLevel(MM.OLAPI_METADATA_ID, strUniqueID);
    }

    /**
     * Retrieves the dimensions that specified measures have.
     * To retrieve the dimensions that any of the measures has, pass
     * <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the dimensions that all of the measures have, pass
     * <code>MM.INTERSECTION</code>.
     *
     * @param measures The measures whose dimensions you want.
     * @param flags A constant that indicates whether to include the
     *              dimensions that any of the <code>measures</code> has or the
     *              dimensions that are common to all <code>measures</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status documented
     */
  	public MDDimension[] dimensionalityOfMeasures(MDMeasure[] measures, String flags)
                                                throws MetadataManagerException
    {
    	return m_MDRoot.dimensionalityOfMeasures(measures, flags);
  	}

    /**
     * Retrieves measures that have specified dimensions.
     * To retrieve measures that have any of the specified dimensions,
     * pass <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the measures that have all of the specified dimensions,
     * pass <code>MM.INTERSECTION</code>.
     *
     * @param dimensions The dimensions that the retrieved measures should have.
     * @param flags A constant that indicates whether to retrieve measures
     *              that have any of the <code>dimensions</code> or only the
     *              measures that have all of the <code>dimensions</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status documented
     */
    public MDMeasure[] measuresOfDimensions(MDDimension[] dimensions, String flags)
                                                throws MetadataManagerException
    {
      return m_MDRoot.measuresOfDimensions(dimensions, flags);
    }

    /**
     * Retrieves a hierarchy by its name.
     *
     * @param  strDimension The name of the dimension that contains the
     *             hierarchy that you want.
     * @param  strHierarchy The name of the hierarchy that you want.
     *
     * @return The named property, or
     *         <code>null</code> if no hierarchy by that name can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status documented
     */
   	public MDHierarchy getHierarchyByName(String strDimension, String strHierarchy)
                                                throws MetadataManagerException
    {
        return m_MDRoot.getHierarchyByName(strHierarchy, strDimension);
	}

    /************************************************************************
     * MetadataManager Server methods
     *************************************************************************/
    /****************************************************
     * Unpublished public shortcut methods
     ****************************************************/
    /**
     * @hidden
	 * Returns the <code>source</code> object using specified database string
     *
     * @param  dbString a <code>String</code> value that
     *                  represents datatbase string.
     *
     * @return <code>source</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public Object getDataProvider( String dbString )
                                                throws MetadataManagerException
    {
        PropertyBag propBag = new PropertyBag();
        propBag.setStrPropertyValue( MM.OBJECT_NAME, "DataProvider" );
        propBag.setStrPropertyValue( MDU.DRIVER_TYPE, MDU.MDM );
        propBag.setStrPropertyValue( MM.DATABASE_STRING, dbString );
        return getDriverSpecificObject ( propBag, null );
    }

    public void printTimeInfo(){
      System.out.println ( "To get Sources by OLAPI ID," );
      System.out.println ( "   - Olapi took " + m_OlapiTimeforSource + " ms" );
      System.out.println ( "   - MetadataManager took " + m_MMTimeforSource + " ms" );
      System.out.println ( "   - MetadataManager took " + m_MMCachedSourceTime + " ms to get Cached Sources" );

      System.out.println ( "To get Member Sources by OLAPI ID" );
      System.out.println ( "   - Olapi took " + m_OlapiTimeforMemberSource + " ms" );
      System.out.println ( "   - MetadataManager took " + m_MMTimeforMemberSource + " ms" );
    }

    public void resetTimeInfo(){
      System.out.println ( "MetadataManager is resetting the Time Information" );
      m_OlapiTimeforSource = 0;
      m_MMTimeforSource = 0;
      m_MMCachedSourceTime = 0;
      m_OlapiTimeforMemberSource = 0;
      m_MMTimeforMemberSource = 0;
    }
    
  	/**
     * @hidden
	 * Returns the <code>source</code> object using specified database string
     *
     * @param olapiMetadataID   olapiID to identify source object
     * @param dbString          a <code>String</code> value that
     *                          represents datatbase string.
     *
     * @return <code>source</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public Object getSourceByID (String olapiMetadataID, String dbString) throws MetadataManagerException {

      // Start the clock
      long before = System.currentTimeMillis();

      if (olapiMetadataID == null)
        return null;

      if (MM.PERSISTENCE.equals(MMUtilities._getDriverType(olapiMetadataID)))
        return null;

      olapiMetadataID = MMUtilities._extractID(olapiMetadataID);
  
      MDDimension mdMeasDim = getMeasureDimension (dbString);
      if (olapiMetadataID.equals (mdMeasDim.getOLAPIMetadataID())) {
        return getMeasureDimensionSource (dbString);
      }
      
      PropertyBag propBag = new PropertyBag();
      propBag.setStrPropertyValue (MM.OLAPI_METADATA_ID, olapiMetadataID);
      propBag.setStrPropertyValue (MM.DRIVER_TYPE, MM.MDM);
  
      Object object = null;
      MDObject mdObject = m_MDIndex.getFirstMDObject(propBag);
 
      // Stop the clock
      long after = System.currentTimeMillis();
      m_MMTimeforSource = m_MMTimeforSource + ( after - before );
          
      if (mdObject != null)
      {

        // Start the clock
        before = System.currentTimeMillis();

        UserObject srcUsrObject = (UserObject) m_MDIndex.getUserObject( mdObject, MM.OLAPI_SOURCE );
        if ( srcUsrObject  != null ) {
            object = srcUsrObject.getObject();
        }
        
        // Stop the clock
        after = System.currentTimeMillis();
        m_MMCachedSourceTime = m_MMCachedSourceTime + ( after - before);

        if (object != null) {
            return object;
        }
      }

      // Start the clock
      before = System.currentTimeMillis();
      propBag = new PropertyBag();
      propBag.setStrPropertyValue (MM.OBJECT_NAME, MM.OLAPI_SOURCE);
      propBag.setStrPropertyValue (MDU.DRIVER_TYPE, MDU.MDM);
      propBag.setStrPropertyValue (MM.DATABASE_STRING, dbString);
      propBag.setStrPropertyValue (MM.OLAPI_METADATA_ID, olapiMetadataID);
      
      // Allow to start the second clock
      m_IsMMTimed = true;

      object = getDriverSpecificObject (propBag, null );

      // Allow to stop second clock
      m_IsMMTimed = false;

      if ( object == null )
        return null;

      // Stop the clock
      after = System.currentTimeMillis();
      m_OlapiTimeforSource = m_OlapiTimeforSource + ( after - before );

      // Start the clock
      before = System.currentTimeMillis();
  
      if (  mdObject != null ) {
        UserObject usrObject = new UserObject(object, MDU.MDM, MDU.SERVER_ONLY);
        m_MDIndex.setUserObject( mdObject, usrObject, MM.OLAPI_SOURCE );
        m_MDIndex.setMDObject (mdObject.getObjectID(), mdObject);
      }

      // Stop the clock
      after = System.currentTimeMillis();
      m_MMCachedSourceTime = m_MMCachedSourceTime + ( after - before );

      return object;
    }

  	/**
     * @hidden
	 * Returns the <code>source</code> object using specified database string
     *
     * @param olapiMetadataID   olapiID to identify source object
     * @param object            object needed to retrieve source object
     * @param dbString          a <code>String</code> value that
     *                          represents datatbase string.
     *
     * @return <code>source</code> which represents the retrieved object, or
     *         null
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public Object getMemberSourceByID( String olapiMetadataID,
                                       Object object,
                                       String dbString )
                                       throws MetadataManagerException {

      // Start the clock
      Date before = new Date();

      olapiMetadataID = MMUtilities._extractID(olapiMetadataID);
      PropertyBag propBag = new PropertyBag();
      propBag.setStrPropertyValue( MM.OBJECT_NAME, MM.OLAPI_MEMBER_SOURCE );
      propBag.setStrPropertyValue( MDU.DRIVER_TYPE, MDU.MDM);
      propBag.setStrPropertyValue( MM.DATABASE_STRING, dbString );
      propBag.setStrPropertyValue( MM.OLAPI_METADATA_ID, olapiMetadataID );
      Date after = new Date();
      m_MMTimeforMemberSource = m_MMTimeforMemberSource + ( after.getTime() - before.getTime() );

      before = after;

      // Allow to start second clock
      m_IsMMTimed = true;

      Object src = getDriverSpecificObject ( propBag, object );

      // Allow to stop second clock
      m_IsMMTimed = false;

      // Stop the clock
      after = new Date();
      m_OlapiTimeforMemberSource = m_OlapiTimeforMemberSource + ( after.getTime() - before.getTime() );

      return src;
    }

    /**
     * Retrieves the measure dimension for this <code>MetadataManagerImpl</code>.
     * The measure dimension is the dimension that lists available measures.
     *
     * @param dbString  The analytic workspace whose measure dimension you want.
     *
     * @return The measure dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     * 
     * @status documented-PriorityReview is the description for dbString right?
    */
    public MDDimension getMeasureDimension( String dbString )
                                                throws MetadataManagerException
    {
        //return (MDDimension) m_MDRoot.getMeasureDimension();
        for(Enumeration _enum = m_ConnectionImpls.elements(); _enum.hasMoreElements();)
        {
            ConnectionImpl _conn = (ConnectionImpl)_enum.nextElement();
            if(MM.MDM.equals(_conn.getDriverType()))
            {
                MDFolder _mdmRoot = (MDFolder)m_MDRoot.getObjPropertyValue("MDM_ROOT");
                if(_mdmRoot != null)
                {
                    _mdmRoot.setMetadataManagerServices(this);
                    return (MDDimension)_mdmRoot.getFirstChild(MM.MEASURE_DIMENSION);
                }
            }
        }
        return null;
    }

    /**
     * Set labels for measure dimension for this <code>MetadataManager</code>.
     *
     * @param propertyBag  PropertyBag that contains labels settings
     *
     * @throws MetadataManagerException If there is a problem retrieving
     * Measure Dimension object or if propertyBag contains a property that
     * is a non-label property. e.g. MM.OBJECT_NAME
     *
     * @status Documented
     */
    public void setMeasureDimensionLabels(PropertyBag propertyBag)
                                                throws MetadataManagerException
    {
        if(propertyBag != null && propertyBag.size() > 0)
        {
            MDObject measDim = getMDRoot().getFirstChild(MM.MEASURE_DIMENSION);
            StringBuffer _strBuff = new StringBuffer();
            if(measDim != null)
            {
                Property[] props = propertyBag.getProperties();
                for(int i = 0; i < props.length; i++)
                {
                    String name = props[i].getName();
                    if(name.equals(MM.SHORT_LABEL) || name.equals(MM.SHORT_PLURAL_LABEL)
                       || name.equals(MM.LONG_LABEL) || name.equals(MM.LONG_PLURAL_LABEL)
                       || name.equals(MM.MEDIUM_LABEL))
                        measDim.setProperty(props[i]);
                    else
                        _strBuff.append(name + ",");
                }
            }
            else
            {
                getErrorHandler().log("Could not find Measure Dimension under root folder",
                                       getClass().getName(), "setMeasureDimensionLabels");
            }
            if(_strBuff.length() > 0)
            {
                String _str = _strBuff.toString().substring(0, _strBuff.length() - 1);
                throw new MetadataManagerException( MetadataManagerServerBundle.class,
                                                    MetadataManagerServerBundle.EXC_ILLEGAL_PROPERTY,
                                                    new String[]{_str},
                                                    m_Locale,
                                                    MDU.MDM);
            }
        }
    }

    /**
     * @hidden
     * Retrieve SPL executor from driver using databaseString
     *
     * @param databaseString    database string for connection from which
     *                          SPL executor is to be retrieved.
     *
     * @throws MetadataManagerException
     *
     * @return  object representing SPL executor.
     *
     * @status hidden
     */
    public Object getSPLExecutor( String databaseString )
                                                throws MetadataManagerException
    {
        PropertyBag propBag = new PropertyBag();
        propBag.setStrPropertyValue( MM.OBJECT_NAME, "SPLExecutor" );
        propBag.setStrPropertyValue( MDU.DRIVER_TYPE, MDU.MDM );
        propBag.setStrPropertyValue( MM.DATABASE_STRING, databaseString );
        return getDriverSpecificObject ( propBag, null );
    }

    /**
     * Specifies the locale that this <code>MetadataManagerImpl</code> uses.
     *
     * @param locale    The <code>Locale</code> for this
     *                   <code>MetadataManagerImpl</code>.
     *
     * @status documented
     */
    public void setLocale(Locale locale) {
        m_Locale = locale;
        if(m_MetadataDrivers != null)
        {
            Enumeration enumer = m_MetadataDrivers.elements();
            while( enumer.hasMoreElements() ) {
                ((MetadataDriver)enumer.nextElement()).setLocale( locale );
            }
        }
    }

    /**
     * Retrieves the locale that this <code>MetadataManagerImpl</code> uses.
     *
     * @return The locale for this <code>MetadataManagerImpl</code> uses.
     *
     * @status documented
     */
    public Locale getLocale() {
        return m_Locale;
    }

    /****************************************************
     * private methods
     ****************************************************/

    /**
     * @hidden
     * Retrieve drivers for specified driverType
     *
     * @param driverType    String representing driver type
     *
     * @return  Array of MetadataDriver containing MetadataDrivers for
     *          specified driverType
     *
     * @throws MetadataManagerException
     *
     * @status private
     */
    public MetadataDriver[] getMetadataDrivers ( String driverType )
                                                throws MetadataManagerException
    {
        int count = getDriverCount( driverType );
        MetadataDriver[] metadataDrivers = new MetadataDriver[count];
        for ( int i = 0, j =0; m_MetadataDrivers != null && ((i < m_MetadataDrivers.size()) && ( j < count )); i ++ ) {
            MetadataDriver mmDriver = (MetadataDriver) m_MetadataDrivers.elementAt(i);
            if ( (mmDriver.getDriverType()).equals (driverType) ) {
                metadataDrivers[j] = mmDriver;
                j++;
            }
        }
        return metadataDrivers;
    }

    /**
     * @hidden
     * Retrieve driver with properties specified in propertyBag
     *
     * @param propertyBag
     *
     * @return  Array of MetadataDriver containing MetadataDrivers for
     *          specified driverType
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public MetadataDriver getMetadataDriver( PropertyBag propertyBag )
                                                throws MetadataManagerException
    {
        String driverType = propertyBag.getStrPropertyValue( MDU.DRIVER_TYPE );
        String databaseStr = propertyBag.getStrPropertyValue( MM.DATABASE_STRING );
        String connectionStr = getConnectionString( databaseStr );

        MetadataDriver[] driverArray = getMetadataDrivers( driverType );
        String tempDatabaseStr = null;
        String tempConnectionStr = null;
        for( int i = 0; i < driverArray.length; i++ ) {
            tempDatabaseStr = driverArray[i].getDatabaseString();
            try {
                tempConnectionStr = driverArray[i].getConnectionString();
            }catch( MetadataManagerException e ) {
                continue;
            }
            if( tempDatabaseStr == null || tempConnectionStr == null )
                continue;
            if( tempDatabaseStr.equals( databaseStr ) && tempConnectionStr.equals( connectionStr ) )
                return driverArray[i];
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve driver count for specified driverType
     *
     * @param driverType    Driver type for MetadataDrivers whose count
     *                      is needed
     *
     * @return              <code>int</code> value representing driver count
     *                      for specified driverType
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    private int getDriverCount( String driverType )
                                                throws MetadataManagerException
    {
        int count = 0;
        for ( int i = 0; m_MetadataDrivers != null && i < m_MetadataDrivers.size(); i ++ ) {
            MetadataDriver mmDriver = (MetadataDriver) m_MetadataDrivers.elementAt(i);
            if ( (mmDriver.getDriverType()).equals (driverType) )
                count++;
        }
        return count;
    }

    /**
     * @hidden
     * Retrieve all MetadataDrivers in MetadataManagerImpl
     *
     * @return  Vector of MetadataDrivers in MetadataManager
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    private Vector getMetadataDrivers() throws MetadataManagerException {
        return getMetadataDrivers ( m_ConnectionImpls );
    }

    /**
     * @hidden
     * Retrieve MetadataDrivers for multiple connectionImpls
     *
     * @return  Vector of MetadataDrivers for specified ConnectionImpls
     *
     * @throws MetadataManagerException
     *
     * @status private
     */
    private Vector getMetadataDrivers( Vector connectionImpls )
                                                throws MetadataManagerException
    {
        if ( ( connectionImpls == null ) || ( connectionImpls.size() == 0) )
            return null ;
        Vector mmdrivers = new Vector();
        for ( int i = 0; i < connectionImpls.size(); i ++ ) {
            ConnectionImpl connectionImpl = (ConnectionImpl) connectionImpls.elementAt(i);

            // Check if the MetadataDriver has already been created for connectionImpl
            if(m_MetadataDrivers != null && m_MetadataDrivers.size() > 0)
            {
                boolean found = false;
                for(int j = 0; j < m_MetadataDrivers.size(); j++)
                {
                    MetadataDriver driver = (MetadataDriver)m_MetadataDrivers.elementAt(j);
                    if(driver.getConnectionDriver().equals(connectionImpl.getConnectionDriver()))
                    {
                        found = true;
                        mmdrivers.addElement(driver);
                        // break the inner for loop
                        break;
                    }
                }
                // skip to the next iteration of outer for loop
                if(found)
                    continue;
            }

            MetadataDriver mmDriver = getMetadataDriver ( connectionImpl );

            if ( mmDriver != null )
            {
                String tmpFlag = connectionImpl.getLoadParameter();
                if(tmpFlag != null ) {
                  mmDriver.setLoadParameter(connectionImpl.getLoadParameter() );
                }
                mmdrivers.addElement ( (Object) mmDriver );
            }
        }
        return mmdrivers;
    }

    /**
     * @hidden
     * Retrieve MetadataDrivers for specified connectionImpl
     *
     * @return  MetadataDriver for specified connectionImpl
     *
     * @throws  MetadataManagerException
     *
     * @status private
     */
    private MetadataDriver getMetadataDriver( ConnectionImpl connectionImpl )
                                                throws MetadataManagerException
    {
        if ( connectionImpl == null )
            return null;

        MetadataDriver mmDriver = null;
        String driverType = connectionImpl.getDriverType();

        try {
            if(driverType != null && m_driverImpl != null)
            {
                String _str = (m_driverImpl.containsKey(driverType))? (String)m_driverImpl.get(driverType) : "";
                mmDriver = (MetadataDriver)(Class.forName(_str).newInstance());
            }
            else 
                return null;
        }
        catch ( ClassNotFoundException cnfe ) {
            throw new MetadataManagerException( MetadataManagerServerBundle.class,
                                                MetadataManagerServerBundle.EXC_DRIVER_NOT_FOUND,
                                                null,
                                                m_Locale,
                                                driverType,
                                                cnfe );
        }
        catch ( InstantiationException ie ) {
            throw new MetadataManagerException( MetadataManagerServerBundle.class,
                                                MetadataManagerServerBundle.EXC_INSTANTIATION,
                                                null,
                                                m_Locale,
                                                driverType,
                                                ie );
        }
        catch ( IllegalAccessException iae ) {
            throw new MetadataManagerException( MetadataManagerServerBundle.class,
                                                MetadataManagerServerBundle.EXC_ILLEAGAL_ACCESS,
                                                null,
                                                m_Locale,
                                                driverType,
                                                iae );
        }

        if ( mmDriver != null ) {
            mmDriver.setConnectionDriver ( connectionImpl.getConnectionDriver() );
            if ( driverType.equals ( MDU.MDM ) )
            {
                String _str = connectionImpl.getOLAPServiceName();
                if(_str != null && !_str.equals(""))
                {
                    mmDriver.setDatabaseString(getDatabaseString(_str));
                }
                else if(connectionImpl.getConnectionString() != null)
                {
                    mmDriver.setDatabaseString ( getDatabaseString ( connectionImpl.getConnectionString() ) );
                }
                else
                    mmDriver.setDatabaseString("");
            }
        }
        return mmDriver;
    }

    /**
     * @hidden
     * Initialize MetadataManagerImpl
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>SUCCESS</code>
     *                  <code>FAILURE</code>
     *
     * @see oracle.dss.metadataManager.common.MM.FAILURE
     * @see oracle.dss.metadataManager.common.MM.SUCCESS
     *
     * @throws  MetadataManagerException
     *
     * @status private
     */
    private int initMetadataManagerImpl() {
        setupClasses();
        setAttachStatus( MM.NOT_ATTACHED );

        // set the default drivers
        m_driverImpl = new Hashtable();
        m_driverImpl.put(MDU.MDM, "oracle.dss.metadataManager.server.drivers.mdm.MDMMetadataDriverImpl");
        m_driverImpl.put(MDU.ECM, "oracle.dss.metadataManager.server.drivers.ecm.ECMMetadataDriverImpl");
        m_driverImpl.put(MDU.PERSISTENCE, "oracle.dss.metadataManager.server.drivers.persistence.PersistenceMetadataDriverImpl");
        m_driverImpl.put(MDU.DISCOVERER, "oracle.dss.metadataManager.server.drivers.disco.DiscovererMetadataDriverImpl");
        m_driverImpl.put(MDU.SBA, "oracle.dss.metadataManager.server.drivers.sba.SBAMetadataDriverImpl");

        // fill in caching semantics hashtable for each expected object type
        m_cachingSemantics = new Hashtable(20);
        m_cachingSemantics.put(PersistableConstants.FOLDER, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.SELECTION, new Integer(MDU.BOTH));
        m_cachingSemantics.put(PersistableConstants.CALCULATION, new Integer(MDU.BOTH));
        m_cachingSemantics.put(MM.MEASURE, new Integer(MDU.BOTH));
        m_cachingSemantics.put("Profile", new Integer(MDU.BOTH));

/*
        m_cachingSemantics.put(PersistableConstants.GRAPH, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.CROSSTAB, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.TABLE, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.UISTYLE, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.UIFORMAT, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.QUERYMANAGER, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.QUERY, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.QUERYBUILDER, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.CONNECTION, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.METADATAMANAGER, new Integer(MDU.CLIENT));
        m_cachingSemantics.put("Test", new Integer(MDU.SERVER));
        m_cachingSemantics.put("Aggregate", new Integer(MDU.CLIENT));
        m_cachingSemantics.put("Simple", new Integer(MDU.CLIENT));
        m_cachingSemantics.put("Compound", new Integer(MDU.CLIENT));
        m_cachingSemantics.put("Dynamic", new Integer(MDU.CLIENT));
        m_cachingSemantics.put("Reference", new Integer(MDU.SERVER));
        m_cachingSemantics.put("MIME", new Integer(MDU.SERVER));
*/
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Sets up classes for appmodule
     *
     * @status private
     */
    private void setupClasses() {
        //setProxyClassName(JboContext.PLATFORM_VB, "oracle.dss.appmodule.client.corba.MetadataManagerObjectImpl");
        //setProxyClassName(JboContext.PLATFORM_ORACLE8I, "oracle.dss.appmodule.client.corba.MetadataManagerObjectImpl");
        //setProxyClassName(JboContext.PLATFORM_EJB, "oracle.dss.appmodule.client.ejb.MetadataManagerObjectImpl");
    }

    /**
     * @hidden
     * Retrieve instance ID for this MetadataManagerImpl instance
     *
     * @return  <code>int</code> value representing instance ID.
     *
     * @status private
     */
    private static int getInstanceID() {
        return m_InstanceID;
    }

    /**
     * @hidden
     * Add mdObject to the cache.  This method will not call the driver and
     * save mdObject.
     *
     * @param mdObject MDObject that is to be added to cache.
     *
     * @status hidden
     */
    public void setMDObjectInCache( MDObject mdObject ) throws MetadataManagerException {
//        mdObject.setMetadataManagerServices(this);
        m_MDIndex.setMDObject( mdObject );
    }

    public void addMDObject(MDObject mdObject) throws MetadataManagerException
    {
        // give this to the driver
        Vector _drivers = mdObject.getDriverTypes();
        if (_drivers != null && _drivers.size() > 0)
        {
            MetadataManagerException _mme = null;
            for (int i=0; i<_drivers.size(); i++)
            {
                String _driverType = (String)_drivers.elementAt(i);
                MetadataDriver[] mmDrivers = getMetadataDrivers(_driverType);
                for(int j = 0; j < mmDrivers.length; j++)
                {
                    mmDrivers[j].addMDObject(mdObject);
                }
            }
        }        
        m_MDIndex.setMDObject(mdObject);
    }    
	/**
     * @hidden
     * Retrieve mdObject with specified properties from index.
     *
     * @param properties    properties that should exist in mdObject
     * @param fromServerIndex     <code>true</code>   return object from index only
     *                      <code>false</code>  return null
     *
     * @return mdObject from index that has similar properties.  Null is
     *         returned if no mdObject found.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public MDObject getMDObject(PropertyBag properties, boolean fromServerIndex) throws MetadataManagerException
    {
        if(fromServerIndex)
            return m_MDIndex.getMDObject(properties);
        return null;
    }

    /**
     * @hidden
     */
    public MDObject[] getChildrenFromIndex(MDObject mdObject)
    {
        OrderedHashtable childrenID = mdObject.getChildrenID();
        if(childrenID != null && childrenID.size() > 0)
        {
            OrderedHashtable table = m_MDIndex.getMDObjects(childrenID);
            if(table != null)
            {
                MDObject[] mdObjects = new MDObject[table.size()];
                Enumeration enumer = table.keys();
                for(int i = 0; enumer.hasMoreElements(); i++)
                {
                    mdObjects[i] = (MDObject)enumer.nextElement();
                }
                return mdObjects;
            }
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve errorhandler from metadataManager
     *
     * @return  errorhandler
     *
     * @status hidden
     */
    public ErrorHandler getErrorHandler()
    {
        return m_errHandler;
    }

    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @return  an integer representing cachingSemantics of object of the specified type 
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status hidden
     */
    public int getCachingSemanticsByObjType(String objType)
    {
        if (objType == null)
            return MDU.NONE;
        Integer _int = (Integer)m_cachingSemantics.get(objType);
        if (_int == null)
            return MDU.NONE;
        else
            return _int.intValue();
    }

    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @param   cachingSemantics caching semantics constant for the objType object type
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status hidden
     */
    public void setCachingSemanticsByObjType(String objType, int cachingSemantics)
    {
        m_cachingSemantics.put(objType, new Integer(cachingSemantics));
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @param referenceResolver a hashtable that gets passed when getting a UserObject
     * @return  a Persistable object
     *
     * @status hidden
     */
    public Persistable getPersistableObject(MDObject mdObj, Hashtable referenceResolver) throws BINamingException
    {
        Persistable _persistableObj = null;
        UserObject  _usrObj         = null;
        try
        {
            if (referenceResolver != null)
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE, referenceResolver);
            else
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE);
        }
        catch(MetadataManagerException e)
        {
            // process the exception
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, null, getLocale(), e);
        }

        if (_usrObj == null)
            return null;
        else
            _persistableObj = (Persistable)(_usrObj.getObject());

        if (_persistableObj instanceof MDPersistable)
        {
            // retrieve COMPSUBTYPE3 "id1:pos1,id2:pos2,..."
            // where id is and OLAPI runtime ID and pos is the position
            PersistableAttributes _pa = new PersistableAttributes();
            String _props = _persistableObj.getPersistableAttributes(_pa).getCompSubType3();
            if (_props != null)
            {
                StringTokenizer _tokenizer = new StringTokenizer(_props, ",");
                MDAggregateInfo[] _aggrs = new MDAggregateInfo[_tokenizer.countTokens() + 1];
                int i = 0; // counter for _aggrs
                while (_tokenizer.hasMoreTokens())
                {
                    String _temp = _tokenizer.nextToken();
                    int _sep = _temp.indexOf(':');

                    if (_sep != -1)
                    {
                        String _olapiID = _temp.substring(0, _sep);
                        int _pos = Integer.parseInt(_temp.substring(_sep+1, _temp.length()));
                        MDAggregateInfo _mdAggrInfo = new MDAggregateInfo(_olapiID, _pos);
                        _aggrs[i++] = _mdAggrInfo;
                    }
                }
                ((MDPersistable)_persistableObj).setMDComponents(_aggrs);
            }
        }

        return _persistableObj;
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @return  a Persistable object
     *
     * @status hidden
     */
    public Persistable getPersistableObject(MDObject mdObj) throws BINamingException
    {
        return getPersistableObject(mdObj, (Hashtable)null);
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @return  a Persistable object
     *
     * @status hidden
     */
    public MDObject getMDObject(Persistable persistable) throws MetadataManagerException
    {
        if(persistable instanceof MDObject)
        {
            PropertyBag _bag = new PropertyBag();
            _bag.setStrPropertyValue(MM.UNIQUE_ID, ((MDObject)persistable).getUniqueID());
            MDObject _obj = getMDObject(_bag);
            if(_obj != null)
                return _obj;
        }
        
        MetadataDriver[] _mmDrivers = getMetadataDrivers(MDU.PERSISTENCE);
        if (_mmDrivers != null)
        {
            // there should only be one Persistence driver....
            for(int i = 0; i < _mmDrivers.length; i++)
            {
                MDObject _mdObj = _mmDrivers[i].getMDObject(persistable);
                if (_mdObj != null)
                    return _mdObj;
            }
        }
        return null;
    }

    public MDObject getMDObjectUsingFullPath(String fullPath) throws MetadataManagerException
    {
        MDObject _mdObj = getMDObjectByPath(fullPath);
        if (_mdObj != null)
            return _mdObj;
            
        MetadataDriver[] _perDrivers = getMetadataDrivers(MDU.PERSISTENCE);
        if (_perDrivers != null && _perDrivers.length > 0)
        {
            // there should only be one Persistence driver....
            try
            {
                _mdObj = _perDrivers[0].getMDObjectUsingFullPath(fullPath);
                if (_mdObj != null)
                    return _mdObj;
            }
            catch (NameNotBoundException nnbe)
            {
                MetadataDriver[] _mdmDrivers = getMetadataDrivers(MDU.MDM);
                if (_mdmDrivers != null && _mdmDrivers.length > 0)
                {
                    _mdObj = _mdmDrivers[0].getMDObjectUsingFullPath(fullPath);
                    if (_mdObj != null)
                        return _mdObj;
                    else
                    {
                        MetadataDriver[] _discoDrivers = getMetadataDrivers(MDU.DISCOVERER);
                        if (_discoDrivers != null && _discoDrivers.length > 0)
                        {
                            _mdObj = _discoDrivers[0].getMDObjectUsingFullPath(fullPath);
                            if (_mdObj != null)
                                return _mdObj;
                        }           
                    }
                }
                throw nnbe;
            }
        }
        else
        {
            try
            {
                MetadataDriver[] _discoDrivers = getMetadataDrivers(MDU.DISCOVERER);
                if (_discoDrivers != null && _discoDrivers.length > 0)
                {
                    _mdObj = _discoDrivers[0].getMDObjectUsingFullPath(fullPath);
                    if (_mdObj != null)
                        return _mdObj;
                }           
            }
            catch(NameNotBoundException nnbe)
            {
                MetadataDriver[] _mdmDrivers = getMetadataDrivers(MDU.MDM);
                if (_mdmDrivers != null && _mdmDrivers.length > 0)
                {
                    _mdObj = _mdmDrivers[0].getMDObjectUsingFullPath(fullPath);
                    if (_mdObj != null)
                        return _mdObj;
                }
            }
        }
        return null;
    }

    // temp method to resolve bug#2799435 until bind method is activated in WritableDriver
    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException
    {
        MDObject _obj = getMDObjectByPath(fullPath);
        if (_obj != null)
        {
            if (_obj instanceof MDFolder)
                return (MDFolder)_obj;
            else
                return null;
        }

        MDFolder _folder = null;
        
        MetadataDriver[] _perDrivers = getMetadataDrivers(MDU.PERSISTENCE);
        if (_perDrivers != null && _perDrivers.length > 0)
        {
            // there should only be one Persistence driver....
            try
            {
                _folder = _perDrivers[0].getMDFolderUsingFullPath(fullPath);
                if (_folder != null)
                    return _folder;
            }
            catch (NameNotBoundException nnbe)
            {
                MetadataDriver[] _mdmDrivers = getMetadataDrivers(MDU.MDM);
                if (_mdmDrivers != null && _mdmDrivers.length > 0)
                {
                    MDObject _mdObj = _mdmDrivers[0].getMDObjectUsingFullPath(fullPath);
                    if (_mdObj != null && _mdObj instanceof MDFolder)
                        return (MDFolder)_mdObj;
                    else
                    {
                        MetadataDriver[] _discoDrivers = getMetadataDrivers(MDU.DISCOVERER);
                        if (_discoDrivers != null && _discoDrivers.length > 0)
                        {
                            _folder = _discoDrivers[0].getMDFolderUsingFullPath(fullPath);
                            if (_folder != null)
                                return _folder;
                        }           
                    }
                }
                throw nnbe;
            }
        }
        else
        {
            try
            {
                MetadataDriver[] _discoDrivers = getMetadataDrivers(MDU.DISCOVERER);
                if (_discoDrivers != null && _discoDrivers.length > 0)
                {
                    _folder = _discoDrivers[0].getMDFolderUsingFullPath(fullPath);
                    if (_folder != null)
                        return _folder;
                }           
            }
            catch(NameNotBoundException nnbe)
            {
                MetadataDriver[] _mdmDrivers = getMetadataDrivers(MDU.MDM);
                if (_mdmDrivers != null && _mdmDrivers.length > 0)
                {
                    MDObject _mdObj = _mdmDrivers[0].getMDObjectUsingFullPath(fullPath);
                    if (_mdObj != null && _mdObj instanceof MDFolder)
                        return (MDFolder)_mdObj;
                }
            }
        }
        return null;
    }

    public Attributes getAttributes(MDObject mdObj, String[] properties, int flag) throws MetadataManagerException
    {
        Vector _drivers = mdObj.getDriverTypes();
        if (_drivers != null && _drivers.size() > 0)
        {
            MetadataManagerException _mme = null;
            for (int i=0; i<_drivers.size(); i++)
            {
                String _driverType = (String)_drivers.elementAt(i);
                MetadataDriver[] mmDrivers = getMetadataDrivers(_driverType);
                for(int j = 0; j < mmDrivers.length; j++)
                {
                    try
                    {
                        Attributes _attrs = mmDrivers[j].getAttributes(mdObj, properties, flag);
                        if (_attrs != null)
                            return _attrs;
                    }
                    catch (UnsupportedOperationException uoe) {}
                    catch (MetadataManagerException mme)
                    {
                        _mme = mme;
                    } 
                }
            }

            if (_mme != null)
                throw _mme;
        }
        return null;
    }

    /**
     * @hidden
     */
    public void setDatabaseType(String databaseType, ConnectionImpl connection)
    {
        String _str = connection.getConnectionString();
        if(_str == null)
            _str = connection.getOLAPServiceName();

        if(_str == null || _str.equals(""))
            _str = connection.getService();

        if(_str == null || _str.equals(""))
            _str = connection.getPropertyBag().getStrPropertyValue(CB.SID);

        String _dbStr = getDatabaseString(_str);
        if(m_MDRoot != null && _dbStr != null)
            m_MDRoot.setStrings(_dbStr, databaseType);
    }

    /**
     * @hidden
     */
    public String getDatabaseType(ConnectionImpl connection)
    {
        String _str = connection.getConnectionString();
        if(_str == null)
            _str = connection.getOLAPServiceName();

        if(_str == null || _str.equals(""))
            _str = connection.getService();

        if(_str == null || _str.equals(""))
            _str = connection.getPropertyBag().getStrPropertyValue(CB.SID);

        String _dbStr = getDatabaseString(_str);
        if(m_MDRoot != null && _dbStr != null)
            return (String)m_MDRoot.getStringMap().get(_dbStr);
        return null;
    }

    // ObjectFactory proxy methods
    /*
    private ObjectFactory getObjectFactory(String driverType)
    {
        try
        {
            MetadataDriver[] _perDrivers = getMetadataDrivers(driverType);
            if (_perDrivers != null && _perDrivers.length > 0)
                return _perDrivers[0].getObjectFactory();
            else
                return null;
        }
        catch (Exception e)
        {
            return null;
        }
    }
    */

    public String getObjectInstanceClassName(String objType, String driverType)
    {
        //ObjectFactory _factory = getObjectFactory(driverType);
        //if (_factory != null)
        //    return _factory.getObjectInstanceClassName(objType);
        //else
            return null;
    }

    public void setObjectInstanceClassName(String objType, String instanceClassName, String driverType)
    {
        //ObjectFactory _factory = getObjectFactory(driverType);
        //if (_factory != null)
        //    _factory.setObjectInstanceClassName(objType, instanceClassName);
    }

    public String getObjectDefName(String objType, String driverType)
    {
//        ObjectFactory _factory = getObjectFactory(driverType);
//        if (_factory != null)
//            return _factory.getObjectDefName(objType);
//        else
            return null;
    }

    public void setObjectDefName(String objType, String defName, String driverType)
    {
//        ObjectFactory _factory = getObjectFactory(driverType);
//        if (_factory != null)
//            _factory.setObjectDefName(objType, defName);
    }

    public void dump(String driverType)
    {
        //ObjectFactory _factory = getObjectFactory(driverType);
        //if (_factory != null)
        //    _factory.dump();
    }

    /**
     * @hidden
     */
    public int _setReferencedObject(PropertyBag props)
    {
        String _mdObjectName = props.getStrPropertyValue(MM.REFERENCE_NAME);
        MDObject _referencedByObj = m_MDIndex.getMDObject(MM.UNIQUE_ID, 
                               props.getStrPropertyValue(MM.REFERENCE_BY_OBJ));
        MDObject _referencedObj =  m_MDIndex.getMDObject(MM.UNIQUE_ID, 
                               props.getStrPropertyValue(MM.REFERENCE_OBJ));
        if(_referencedByObj != null && _referencedObj != null)
        {
            // piggyback support
            if(props.getStrPropertyValue(MM.REQUEST_TYPE) == null)
            {
                MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, 
                                                                       false,
                                                                       new String[] 
                                                                       { _mdObjectName, 
                                                                         _referencedByObj.getUniqueID(), 
                                                                         _referencedObj.getUniqueID()
                                                                       },
                                                                       MetadataModifiedEvent.SET_REFERENCE);
                _evt.setPiggybacked(true);
                notifyClient(_evt);
            }
            else
                _referencedByObj._setReferencedObject(_mdObjectName, _referencedObj);
            
            return MM.SUCCESS;
        }
        return MM.FAILURE;
    }

    public int _removeReferencedObject(PropertyBag props)
    {
        String _mdObjectName = props.getStrPropertyValue(MM.REFERENCE_NAME);
        MDObject _referencedByObj = m_MDIndex.getMDObject(MM.UNIQUE_ID, 
                               props.getStrPropertyValue(MM.REFERENCE_BY_OBJ));

        if(_referencedByObj != null && _mdObjectName != null)
        {
            // piggyback support
            if(props.getStrPropertyValue(MM.REQUEST_TYPE) == null)
            {
                MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, 
                                                                       false,
                                                                       new String[] 
                                                                       { _mdObjectName, 
                                                                         _referencedByObj.getUniqueID(), 
                                                                       },
                                                                       MetadataModifiedEvent.REMOVE_REFERENCE);
                _evt.setPiggybacked(true);
                notifyClient(_evt);
            }
            else
                _referencedByObj._removeReferencedObject(_mdObjectName);
            
            return MM.SUCCESS;
        }
        return MM.FAILURE;
    }
    
    /**
     * @hidden
     */
    public Hashtable getEnvironment()
    {
        return null;
    }

    /**
     * @hidden
     */
    public boolean getFeature(String feature)
    {
        if (m_MetadataDrivers != null && m_MetadataDrivers.size() > 0)
        {
            // loop over drivers and calculate the net result
            // of whether the feature is supported
            if (BIConstants.WRITE.equals(feature) || BIConstants.ACL.equals(feature))
            {
                for (int i=0; i<m_MetadataDrivers.size(); i++)
                {
                    MetadataDriver _driver = (MetadataDriver)m_MetadataDrivers.elementAt(i);
                    boolean _flag = _driver.getFeature(feature);
                    if (_flag)
                        return true;
                }
                return false;
            }
            else
                return false;
        }
        else
            return false;
    }

    /**
     * @hidden
     */
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attributes, Attributes bindOptions, Hashtable env) throws MetadataManagerException
    {
        checkNameClash(folder, name);
        
        if (m_MetadataDrivers != null && m_MetadataDrivers.size() > 0)
        {
            for (int i=0; i<m_MetadataDrivers.size(); i++)
            {
                MetadataDriver _driver = (MetadataDriver)m_MetadataDrivers.elementAt(i);
                if(_driver.getConnectionDriver().getFeature(BIConstants.WRITE))
                {
                    String _bindOption = null;
                    try
                    {
                        if (bindOptions.get(MDU.BIND_OPTION) != null)
                            _bindOption = (String)bindOptions.get(MDU.BIND_OPTION).get();
                    }
                    catch (NamingException ne){}

                    Hashtable _clone = (env != null)? (Hashtable)env.clone() : new Hashtable();
                    if(!_clone.containsKey(MM.METADATA_MANAGER_SERVICES))
                        _clone.put(MM.METADATA_MANAGER_SERVICES, this);
                    Attributes _attrs = _driver.bind(folder, name, object, attributes, _bindOption, _clone);

                    MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, object);
                    m_EventSupport.fireMetadataModifiedEvent(event);
                    
                    if(object instanceof MDObject && !(object instanceof MDFolder))
                    {
                        MDObject _mdObj = (MDObject)object;
                        m_MDIndex.removeMDObject(_mdObj);
                        
                        if(_mdObj.getParent() != null)
                            _mdObj.getParent().removeChild(_mdObj);
                        
                        // replace the object in sysagg cache.  If the object is not in the cache,
                        // it will not be added to it.
                        updateLookupScopeCache(_mdObj.getUniqueID(), _mdObj.getPath(), _mdObj);
                    }
                    else
                    {
                        String _path = (folder.getPath() != "")? (folder.getPath() + '/') : "";
                        _path += name.toString();
                        if(_path != null)
                        {
                            PropertyBag _bag = new PropertyBag();
                            _bag.setStrPropertyValue(MM.PATH, _path);
                            MDObject[] _objs = m_MDIndex.getMDObjects(_bag);
                            if(_objs != null && _objs.length > 0 && !(_objs[0] instanceof MDFolder))
                                m_MDIndex.removeMDObject(_objs[0]);
                        }
                    }

                    return _attrs;
                }
            }
            throw new UnsupportedOperationException(null, getLocale());
        }
        return null;
    }

    public Object lookup(MDFolder folder, Name name, Persistable persistable, Hashtable args, Attributes options) throws MetadataManagerException
    {
//        boolean _isFolder = false;
        if(folder != null)
        {
            MetadataManagerException _me = null;
            Vector _driverTypes = folder.getDriverTypes();
            Vector _flds = new Vector(2);
            for(int i=0; _driverTypes != null && i < _driverTypes.size(); i++)
            {
                MetadataDriver[] _drivers = getMetadataDrivers((String)_driverTypes.elementAt(i));
                for (int j=0; j<_drivers.length; j++)
                {
                    Object _obj = null;
                    try
                    {
                        _obj = _drivers[j].lookup(folder, name, args, options);
                    }
                    catch(MetadataManagerException e)
                    {
                        _me = e;
                    }
                    if(_obj != null)
                    {
//                        _isFolder = _obj instanceof MDFolder;
//                        if(_isFolder)
//                            m_lookupCache.put(((MDFolder)_obj).getUniqueID(), ((MDFolder)_obj).getPath(), _obj);
                        // handle merged folders
                        if(_obj instanceof MDFolder)
                            _flds.addElement(_obj);
                        else
                            return _obj;
                    }
                }
            }

            if(_flds.size() > 0)
                return _flds.firstElement();
            
            if(_me != null)
                throw _me;
        }
        return null;
    }

    /**
     * Retrieve java.sql.Connection from the OLAP connection in the MetadataManager.
     * @return java.sql.Connection from the OLAP connection if an OLAP connection
     *         exist in the MetadataManager; null otherwise.
     * @status new
     */
    public java.sql.Connection getConnection() throws MetadataManagerException
    {
        java.sql.Connection _conn = null;
        if(m_ConnectionImpls != null && m_ConnectionImpls.size() > 0)
        {
            for(Enumeration _enum = m_ConnectionImpls.elements(); _enum.hasMoreElements();)
            {
                ConnectionImpl _tmp = (ConnectionImpl)_enum.nextElement();
                if(_tmp != null && MDU.MDM.equals(_tmp.getDriverType()) && _tmp.isConnected())
                {
                    try
                    {
                        PropertyBag _bag = new PropertyBag();
                        _bag.setStrPropertyValue(CB.CONNECTION, "");
                        _conn = (java.sql.Connection)_tmp.getDriverSpecificObject(_bag);
                        break;
                    }
                    catch(oracle.dss.connection.common.ConnectionException ce)
                    {
                        throw new MetadataManagerException(MetadataManagerServerBundle.class,
                                                           MetadataManagerServerBundle.EXC_NO_JDBC_CONNECTION,
                                                           null,
                                                           m_Locale,
                                                           _tmp.getDriverType(),
                                                           ce);
                    }
                }
            }
        }
        return _conn;
    }

    // New Methods
    public void renameMDObject(MDFolder mdFolder, Name oldName, Name newName) throws MetadataManagerException
    {
        // checks if the folder is a MDM only folder
        if (MMUtilities.isMDM(mdFolder) && !MMUtilities.isPersistence(mdFolder))
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());
        
        // Either a hybrid folder or a pure Persistence folder
        
        // checks if the rename object is an MDM object
        MDObject _mdObj = getMDObjectFromCache(mdFolder, oldName);
        if (_mdObj != null && MMUtilities.isMDM(_mdObj) && !MMUtilities.isPersistence(_mdObj))
            throw new UnsupportedOperationException(_mdObj.getDriverType(), getLocale());

        checkNameClash(mdFolder, newName);

        // must be a Persistence object
        if (MMUtilities.isPersistence(mdFolder))
        {
            MetadataDriver[] _drivers = getMetadataDrivers(MDU.PERSISTENCE);

            // should be only one persistence driver
            if(_drivers != null && _drivers.length > 0)
                _drivers[0].renameMDObject(mdFolder, oldName, newName);

            // if the renamed object is a hybrid folder, make it not hybrid
            if (_mdObj != null && _mdObj instanceof MDFolder && MMUtilities.isMDM(_mdObj))
                _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
        }
        else
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());

        // piggyback support
        if (_mdObj != null)
        {
            String _requestType = mdFolder.getStrPropertyValue(MM.REQUEST_TYPE);
            mdFolder.removeProperty(MM.REQUEST_TYPE);
            MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.RENAME);
            if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                // this is a server request, piggyback changes to client
                _evt.setPiggybacked(true);
            notifyClient(_evt);
        }

        // remove from lookup cache
        removeFromLookupCache(mdFolder, oldName);
    }

    public void modifyMDObject( MDFolder mdFolder, Name name, ModificationItem[] items ) throws MetadataManagerException
    {
        mdFolder.setMetadataManagerServices(this);
        if (items != null)
        {
            int _flag = MDU.SUCCESS;
            Vector driverType = mdFolder.getDriverTypes();

            UnsupportedOperationException _uoe = null;
            boolean _success = false;

            for (int j=0; j<driverType.size(); j++)
            {
                MetadataDriver[] drivers = getMetadataDrivers((String)driverType.elementAt(j));
                if( drivers != null )
                {
                    for (int i = 0; i < drivers.length; i++)
                    {
                        try
                        {
                            drivers[i].modifyMDObject(mdFolder, name, items);
                            _success = true;
                        }
                        catch (UnsupportedOperationException uoe)
                        {
                            _uoe = uoe;
                        }
                    }
                }
            }

            if (!_success && _uoe != null)
                throw _uoe;

            // update the object if it exist in cache
            MDObject[] _mdObjs = getChildrenFromIndex(mdFolder);
            MDObject _mdObj = null;
            for(int i=0; _mdObjs != null && i < _mdObjs.length; i++)
            {
                String _objName = _mdObjs[i].getName();
                if( _objName != null && _objName.equals(name.get(name.size()-1)))
                {
                    _mdObj = _mdObjs[i];
                    break;
                }
            }
            if (_mdObj != null)
            {
                // this is to handle the case where a MDM/Persistence hybrid
                // object is renamed, we only want to change the MDObject if
                // and only if it is not a MDM object
                if (!MMUtilities.isMDM(_mdObj))
                {
                    // populate MDObject properties (todo)
                }
                else
                {
                    if (MMUtilities.isPersistence(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
                    if (MMUtilities.isDiscoverer(_mdObj))
                        _mdObj.getDriverTypes().removeElement(MDU.DISCOVERER);
                }

                // piggyback support
                String _requestType = mdFolder.getStrPropertyValue(MM.REQUEST_TYPE);
                mdFolder.removeProperty(MM.REQUEST_TYPE);
                MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.MODIFY);
                if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                    // this is a server request, piggyback changes to client
                    _evt.setPiggybacked(true);
                notifyClient(_evt);
            }
            
            // remove object from sys_agg cache
            removeFromLookupCache(mdFolder, name);
        }
    }

    public void removeMDObject(MDFolder mdFolder, Name name, boolean isFolder ) throws MetadataManagerException
    {
        MDObject _mdFolder = getMDObjectByPath(mdFolder.getPath());

        // checks if the folder is a MDM only folder
        if (MMUtilities.isMDM(mdFolder) && !MMUtilities.isPersistence(mdFolder))
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());
        
        // Either a hybrid folder or a pure Persistence folder
        
        // checks if the delete object is an MDM object
        MDObject _mdObj = getMDObjectFromCache(mdFolder, name);
        if (_mdObj != null && MMUtilities.isMDM(_mdObj) && !MMUtilities.isPersistence(_mdObj))
            throw new UnsupportedOperationException(_mdObj.getDriverType(), getLocale());

        // must be a Persistence object
        if (MMUtilities.isPersistence(mdFolder))
        {
            MetadataDriver[] _drivers = getMetadataDrivers(MDU.PERSISTENCE);

            // should be only one persistence driver
            if(_drivers != null && _drivers.length > 0)
                _drivers[0].removeMDObject(mdFolder, name, isFolder);

            // if the deleted object is a hybrid folder, make it not hybrid
            if (_mdObj != null && isFolder && MMUtilities.isMDM(_mdObj))
                _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
        }
        else
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());

        // piggyback support
        if (_mdObj != null)
        {
            String _requestType = mdFolder.getStrPropertyValue(MM.REQUEST_TYPE);
            MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.REMOVE);
            if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                // this is a server request, piggyback changes to client
                _evt.setPiggybacked(true);
            else
                mdFolder.removeProperty(MM.REQUEST_TYPE);

            Vector _vec = _mdObj.getDriverTypes();
            if(_vec.size() == 1 && MMUtilities.isPersistence(_mdObj))
                m_MDIndex.removeMDObject(_mdObj);

            notifyClient(_evt);
        }
        
        // remove from lookup cache
        removeFromLookupCache(mdFolder, name);
    }
    
    public void copy (MDFolder mdFolder, Name objectToBeCopied, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        // checks if the source folder is a MDM only folder
        if (MMUtilities.isMDM(mdFolder) && !MMUtilities.isPersistence(mdFolder))
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());
        
        // Either a hybrid folder or a pure Persistence folder
        
        // checks if the copy object is an MDM object
        MDObject _mdObj = getMDObjectFromCache(mdFolder, objectToBeCopied);
        if (_mdObj != null && MMUtilities.isMDM(_mdObj) && !MMUtilities.isPersistence(_mdObj))
            throw new UnsupportedOperationException(_mdObj.getDriverType(), getLocale());

        // checks if there is an olap object with the same name
        checkNameClash(newParent, objectToBeCopied);

        // must be a Persistence object
        if (MMUtilities.isPersistence(mdFolder))
        {
            MetadataDriver[] _drivers = getMetadataDrivers(MDU.PERSISTENCE);

            // should be only one persistence driver
            if(_drivers != null && _drivers.length > 0)
                _drivers[0].copy(mdFolder, objectToBeCopied, newParent, properties);

            // if the target folder is a MDM folder, it is now also a persistence folder
            if (MMUtilities.isMDM(newParent) && !MMUtilities.isPersistence(newParent))
                newParent.getDriverTypes().addElement(MDU.PERSISTENCE);
        }
        else
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());
    }
        
    public void move (MDFolder mdFolder, Name objectToBeMoved, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        // checks if the source folder is a MDM only folder
        if (MMUtilities.isMDM(mdFolder) && !MMUtilities.isPersistence(mdFolder))
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());
        
        // Either a hybrid folder or a pure Persistence folder
        
        // checks if the moved object is an MDM object
        MDObject _mdObj = getMDObjectFromCache(mdFolder, objectToBeMoved);
        if (_mdObj != null && MMUtilities.isMDM(_mdObj) && !MMUtilities.isPersistence(_mdObj))
            throw new UnsupportedOperationException(_mdObj.getDriverType(), getLocale());

        // checks if there is an olap object with that name
        checkNameClash(newParent, objectToBeMoved);

        // must be a Persistence object
        if (MMUtilities.isPersistence(mdFolder))
        {
            MetadataDriver[] _drivers = getMetadataDrivers(MDU.PERSISTENCE);

            // should be only one persistence driver
            if(_drivers != null && _drivers.length > 0)
                _drivers[0].move(mdFolder, objectToBeMoved, newParent, properties);

            // if the target folder is a MDM folder, it is now also a persistence folder
            if (MMUtilities.isMDM(newParent) && !MMUtilities.isPersistence(newParent))
                newParent.getDriverTypes().addElement(MDU.PERSISTENCE);

            // if the moved object is a hybrid folder, then it is now not a hybrid folder
            if (_mdObj != null && _mdObj instanceof MDFolder && MMUtilities.isMDM(_mdObj))
                _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
        }
        else
            throw new UnsupportedOperationException(mdFolder.getDriverType(), getLocale());

        if (_mdObj != null)
        {
            // piggyback support
            String _requestType = properties.getStrPropertyValue(MM.REQUEST_TYPE);
            MetadataModifiedEvent _evt = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.MOVE);
            if (_requestType == null || _requestType.equals(MM.NONREMOTE))
                // this is a server request, piggyback changes to client
                _evt.setPiggybacked(true);
            notifyClient(_evt);
        }

        // remove object from sys_agg cache
        removeFromLookupCache(mdFolder, objectToBeMoved);
    }
    
    public Vector search (MDFolder mdFolder, Name name, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
        // This is for VB mode, should work for local too
        MDObject _obj = null;
        if(!MM.MDM.equals(mdFolder.getDriverType()))
            _obj = m_MDIndex.getMDObject(mdFolder.getObjectID());
        if(_obj != null)
            mdFolder = (MDFolder)_obj;

        mdFolder.setMetadataManagerServices(this);
        Vector driverTypes = mdFolder.getDriverTypes();
        Vector _result = new Vector(100, 100);

        String _showOnlyDriver = null;
        if (controls instanceof MDSearchControls)
            _showOnlyDriver = ((MDSearchControls)controls).getDriverType();

        MetadataManagerException _ex = null;
        boolean _success = false;

        // for now, this is okay, in the end we need to merge
        // results coming back from drivers
        for (int j=0; j<driverTypes.size(); j++)
        {
            String _driver = (String)driverTypes.elementAt(j);

            if (_showOnlyDriver == null || (_showOnlyDriver != null && _driver.equals(_showOnlyDriver)))
            {
                MetadataDriver[] drivers = getMetadataDrivers(_driver);
                if( drivers != null )
                {
                    for (int i = 0; i < drivers.length; i++)
                    {
                        try
                        {
                            Vector _temp = drivers[i].search(mdFolder, name, attributes, controls);
                            // at least one driver succeed
                            _success = true;
                            if (_temp != null && _temp.size() > 0)
                            {
                                for (int k=0; k<_temp.size(); k++)
                                    _result.addElement(_temp.elementAt(k));
                            }
                        }
                        catch(InvalidPropertyException ipe)
                        {
                            m_errHandler.log(ipe.getLocalizedMessage(), getClass().getName(), "search");
                        }
                        catch (MetadataManagerException e)
                        {
                            _ex = e;
                        }
                    }
                }
            }
        }

        if (_result.size() == 0 && _ex != null && !_success)
            throw _ex;

        // check for merged folders
        mergeFolderDrivertypes(_result);

        return _result;
    }
    public Attributes getAttributes(MDFolder mdFolder, Name name, String[] attrIds, int flag) throws MetadataManagerException
    {
        Vector _drivers = mdFolder.getDriverTypes();
        if (_drivers != null && _drivers.size() > 0)
        {
            MetadataManagerException _mme = null;

            BasicAttributes _finalAttrs = new BasicAttributes();
            for (int i=0; i<_drivers.size(); i++)
            {
                String _driverType = (String)_drivers.elementAt(i);
                MetadataDriver[] mmDrivers = getMetadataDrivers(_driverType);
                for(int j = 0; j < mmDrivers.length; j++)
                {
                    try
                    {
                        Attributes _attrs = mmDrivers[j].getAttributes(mdFolder, name, attrIds, flag);
                        if (_attrs != null)
                        {
                            NamingEnumeration _enum = _attrs.getAll();
                            while (_enum.hasMoreElements())
                            {
                                Attribute _attr = (Attribute)_enum.nextElement();
                                _finalAttrs.put(_attr);
                            }
                        }
                    }
                    catch (MetadataManagerException mme)
                    {
                        _mme = mme;
                    } 
                }
            }

            if (_mme != null && _finalAttrs.size() == 0)
                throw _mme;

            return _finalAttrs;
        }
        return null;
    }

    private void checkNameClash(MDFolder folder, Name name) throws NameClashException
    {
        MDObject _exists = getMDObjectFromCache(folder, name);        
        if (_exists != null)
        {
            if (_exists instanceof MDDimension)
            {
                NameClashException _nce = new NameClashException(name.get(name.size()-1), getLocale(), folder.getDriverType(), null);
                _nce.setRebindAllowed(false);
                throw _nce;
            }
            else if (!(_exists instanceof MDFolder))
            {
                if (!MMUtilities.isPersistence(_exists))
                {
                    NameClashException _nce = new NameClashException(name.get(name.size()-1), getLocale(), folder.getDriverType(), null);
                    _nce.setRebindAllowed(false);
                    throw _nce;
                }
            }
        }
    }

    private MDObject getMDObjectFromCache(MDFolder folder, Name name)
    {
        if (name == null || folder == null)
            return null;

        MDFolder _parent = folder;
        for (int i=0; i<name.size(); i++)
        {
            MDObject _obj = null;
            try
            {
                _obj = _parent.getChild(name.get(i));
            }
            catch(MetadataManagerException e){ /*ignore*/ }
            
            if (_obj == null)
                return null;
            else
            {
                if (i == name.size()-1)
                    return _obj;
                else
                {
                    if (_obj instanceof MDFolder)
                        _parent = (MDFolder)_obj;
                    else
                        return null;
                }
            }
        }
        return null;
    }    

    /**
     * @hidden
     */
    public Object getObject(String id, String driverType) throws MetadataManagerException
    {
        return getObject(id, driverType, null);
    }

    /**
     * @hidden
     */
    public Object getObject(String id, String driverType, Hashtable env) throws MetadataManagerException
    {
        if(driverType != null)
        {
            MetadataDriver[] _drivers = getMetadataDrivers(driverType);
            if(_drivers != null && _drivers.length > 0)
            {
                return _drivers[0].getObject(id, env);
            }
        }
        return null;
    }

    public MDObject setOlapObject(MDFolder parent, Object mdmObject) throws MetadataManagerException
    {
        MetadataDriver[] _driver = getMetadataDrivers(MM.MDM);
        if(_driver != null && _driver.length > 0 &&_driver[0].getClass().getName().equals("oracle.dss.metadataManager.server.drivers.mdm.MDMMetadataDriverImpl"))
        {
            try
            {
                Method method = _driver[0].getClass().getMethod("setOlapObject",new Class[] {parent.getClass(), Object.class});
                if(method != null)
                {
                    Object _val = method.invoke(_driver[0], new Object[] {parent, mdmObject});
                    if (_val instanceof MDObject)
                        return (MDObject)_val;
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * @hidden
     */
    public void addToLookupScopeCache(String oid, String path, Object sysAgg)
    {
        if(oid != null && path != null && sysAgg != null)
        {
            m_lookupCache.put(MMUtilities._makeUniqueID(MM.PERSISTENCE, oid), path, sysAgg);
        }
    }
    
    /**
     * @hidden
     */
    public void clearLookupScopeCache()
    {
        m_lookupCache.clear();
    }

    /**
     * Overwrite object in lookup cache
     */
    public void updateLookupScopeCache(String uid, String path, Object sysAgg)
    {
        if(m_lookupCache.get(uid) != null)
            m_lookupCache.put(uid, path, sysAgg);
    }
    
    /**
     * @hidden
     */
    public void setMDObjectInCacheByOLAPIRunID(MDObject mdObject, Vector idVec)
    {
        if(m_MDIndex != null)
            m_MDIndex.setMDObjectByOLAPIIDs(mdObject, idVec);
    }
    
    private void removeFromLookupCache(MDFolder parent, Name name)
    {
        String _path = MMUtilities.composePath(parent, name.toString());
        if(_path != null)
            m_lookupCache.removeByPath(_path);
    }

    public Vector listAssociates(MDFolder mdFolder, Name relativeSourceName, String[] attrsToReturn, Attribute identifier) throws MetadataManagerException
    {
        mdFolder.setMetadataManagerServices(this);
        Vector driverTypes = mdFolder.getDriverTypes();
        for (int j=0; j<driverTypes.size(); j++)
        {
            String _driver = (String)driverTypes.elementAt(j);
            MetadataDriver[] drivers = getMetadataDrivers(_driver);
            
            if( drivers != null )
            {
                if(drivers.length > 1)
                {
                    Vector _total = new Vector(10);
                    for (int i = 0; i < drivers.length; i++)
                    {
                        Vector _temp = drivers[i].listAssociates(mdFolder, relativeSourceName, attrsToReturn, identifier);
                        for(Enumeration _enum = _temp.elements(); _enum.hasMoreElements();)
                            _total.add(_enum.nextElement());
                    }
                }
                else
                    return drivers[0].listAssociates(mdFolder, relativeSourceName, attrsToReturn, identifier);
            }
        }
        return null;
    }

    public MDObject getMDObjectByUniqueID(String uniqueID) throws MetadataManagerException
    {
        return m_MDIndex.getMDObject(uniqueID);
    }

    public void setObjectInstanceClassName(String type, String clsName)
    {
        for(int i=0; m_MetadataDrivers != null && i < m_MetadataDrivers.size(); i++)
            ((MetadataDriver)m_MetadataDrivers.elementAt(i)).setObjectInstanceClassName(type, clsName);
    }

    /**
     * @hidden
     */
    public MDItemFolder[] getJoinableItemFolders(MDFolder folder, MDItemFolder itemFolder, boolean searchSubContext)
    {
        MDItemFolder[] _itemFlds = null;
        if(m_MetadataDrivers != null)
        {
            int size = m_MetadataDrivers.size();
            if(size > 1)
            {
                Vector _vec = new Vector(10);
                for(int i=0; i < size; i++)
                {
                    MDItemFolder[] _iFlds = ((MetadataDriver)m_MetadataDrivers.elementAt(i)).getJoinableItemFolders(folder, itemFolder, searchSubContext);
                    if(_iFlds != null)
                    {
                        for(int j=0; j < _iFlds.length; j++)
                            _vec.addElement(_iFlds[j]);
                    }
                }
                _itemFlds = new MDItemFolder[_vec.size()];
                _vec.copyInto(_itemFlds);
            }
            else if(size == 1)
                _itemFlds = ((MetadataDriver)m_MetadataDrivers.elementAt(0)).getJoinableItemFolders(folder, itemFolder, searchSubContext);
        }
            
        return _itemFlds;
    }
    
    /**
     * @hidden
     */
    /*
    public void addRuntimeDatasource(oracle.dss.metadataManager.client.RuntimeDatasource ds)
    {
        if(m_clientMM != null)
            ((oracle.dss.metadataManager.client.MetadataManager)m_clientMM).addRuntimeDatasource(ds);
    }
    */
    public void removeMDObjectFromCache(MDObject mdObj) {
      try {
        m_MDIndex.removeMDObject(mdObj);
      }
      catch(Exception e) {}
    }
}
