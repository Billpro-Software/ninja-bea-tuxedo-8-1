/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.client.resource;

import java.util.ListResourceBundle;

/**
 * @hidden
 * Defines the error codes and default error messages for operations on ManagerFactory.
 * <p>
 * These error codes may be localized by extending this class, and overriding
 * <code>getContents()</code> to return a table in which the error codes are
 * associated with other message strings. The subclass should be given a name of the
 * form <code>DatautilClientBundle_<em>locale</em></code>, where <em>Locale</em> is
 * the name of a language.
 *
 *      ************************
 *      ** LOCALIZATION TEAMS **
 *      ************************
 *      In the Array declared below, you will need to TRANSLATE THE SECOND
 *      COLUMN value into the appropriate language.  This FIRST COLUMN
 *      value should be left UNTOUCHED.
 *
 * @status Documented
 */
public class DataUtilClientBundle extends ListResourceBundle
{
    public static final String EXC_QUERYCONTEXT_NOT_SET          = "DVT-18008";
    public static final String EXC_SELECTION_NOT_SET             = "DVT-18009";
    public static final String EXC_QUERYACCESS_NOT_CREATED       = "DVT-18010";
    public static final String EXC_DATAACCESS_NOT_CREATED        = "DVT-18011";
    public static final String EXC_UNEXPECTED_ERROR              = "DVT-18012";

   /**
    * Retrieves the key-value association table.
    *
    * @return Array of key-value pairs.
    * @status Documented
    */
    public Object[][] getContents()
    {
        return sMessageStrings;
    }

    /**
     * Private 2-D array of key-value pairs
     */
    private static final Object[][] sMessageStrings =
    {
        /**
         * @error DVT-18008 No <code>QueryContext</code> is defined.
         * @cause A method was called that requires an existing <code>QueryContext</code> object.
         * @action Create a <code>QueryContext</code> object before calling the method.
         * @status Documented
         */
        { EXC_QUERYCONTEXT_NOT_SET, "No QueryContext is defined."},

        /**
         * @error DVT-18009 No <code>Selection</code> is defined.
         * @cause A method was called that requires an existing <code>Selection</code> object.
         * @action Create a <code>Selection</code> object before calling the method.
         * @status Documented
         */
        { EXC_SELECTION_NOT_SET, "No Selection is defined."},

        /**
         * @error DVT-18010 The <code>QueryAccess</code> object cannot be created.
         * @cause A <code>QueryAccess</code> object could not be created.
         * @action Verify that a valid <code>QueryContext</code> object exists.  To create a <code>QueryAccess</code> object, 
         *  use syntax such as <code>queryContext.createQueryAccess</code>.
         * @status Documented
         */
        { EXC_QUERYACCESS_NOT_CREATED, "The QueryAccess object cannot be created."},

        /**
         * @error DVT-18011 A <code>DataAccess</code> object cannot be created.
         * @cause A <code>DataAccess</code> object could not be created.
         * @action Verify that a valid <code>QueryAccess</code> object exists and that the dimension that is specified for the <code>Selection</code> is valid.
         * @status Documented
         */
        { EXC_DATAACCESS_NOT_CREATED, "A DataAccess object cannot be created."},

        /**
         * @error DVT-18012 unexpected error
         * @cause An unknown exception occurred in a call to a different class.
         * @action Check the underlying error stack to find the root cause of the problem.
         *
         * @status documented
         */
        { EXC_UNEXPECTED_ERROR, "unexpected error"},

    };
}
