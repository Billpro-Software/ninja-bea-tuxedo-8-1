/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.BIBaseException;

/**
 * @hidden
 * Thrown in internal cursor management when a position is out of range
 *
 */
public class OutOfBoundsException extends QueryException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     */
    public OutOfBoundsException(String s, Throwable e) {
        super(s, e);
    }    
}
