/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/CursorUtils.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     11/01/06 - Move files back to oracle.dss.util
    bmoroze     05/23/06 - 
    jramanat    05/03/06 - 
    bmoroze     11/09/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/CursorUtils.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import java.lang.reflect.Method;
import java.util.Vector;

import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.OlapQDR;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.transform.DataAccessLong;
import oracle.dss.util.transform.TransformUtils;

/**
 * @hidden
 * Common cursor utilities needed by the BICommon Beans cursors and the client tier Beans cursors
 */
public class CursorUtils extends TransformUtils
{
    /**
     * @hidden
     *  gek 04/24/00
     *
     *  Retrieves the metadata associated with the specified metadata map
     *  type and database object.  It maps the metadata map type to the
     *  appropriate database calls.
     *  
     *  @param  dbObject a <code>DBObject</code> value that represents the 
     *          database object whose label we are attempting to retrieve.
     *  @param  strMetadataType a <code>String</code> specifying the metadata
     *          of interest.
     *  @return <code>Object</code> which represents the object associated
     *          with specified database object and metadata type, or null. 
     */
    public static Object getDBMetadataObject(MDObject dbObject, String strMetadataType) 
        {
        // Check for invalid arguments
        if ((dbObject != null) && (strMetadataType != null))
            {
            if (strMetadataType.equals(MetadataMap.METADATA_VALUE))
                return dbObject.getUniqueID();

            if (strMetadataType.equals(MetadataMap.METADATA_LONGLABEL))
                return dbObject.getLongLabel();
            
            if (strMetadataType.equals(MetadataMap.METADATA_MEDIUMLABEL))
                return dbObject.getMediumLabel();
            
            if (strMetadataType.equals(MetadataMap.METADATA_SHORTLABEL))
                return dbObject.getShortLabel();

            if (strMetadataType.equals(MetadataMap.METADATA_DISPLAYNAME))
                return dbObject.getName();

            if (strMetadataType.equals(MetadataMap.METADATA_DATATYPE))
            {
                try
                {
                    Method m = dbObject.getClass().getMethod("getDataType", null);
                    return m.invoke(dbObject, null);
                }
                catch (Exception e)
                {
                    return null;
                }
            }

            // If we are attempting to retrive drill state or indent
            // information and we don't find any, simply return 0.
            if (isNumericType(strMetadataType)) 
                return new Integer (0);
            }    

        return null;
        }    
        
    private static MDObject getItem(Query q, String dimension) throws QueryException
    {
        if (dimension == null)
            return null;
            
        try
        {
            MDObject mdObj = q.getMDObject(MM.UNIQUE_ID, dimension, MM.OBJECT);
            return mdObj;
        }
        catch (MetadataManagerException mme)
        {
            throw new QueryException(mme.getMessage(), mme);
        }
    }
            

    public static Integer getLevelFromDrillItem(Query q, String dimension, String levelCol) throws QueryException
    {
        MDObject mdObj = null;
        try
        {
            mdObj = q.getMDObject(MM.UNIQUE_ID, dimension, MM.OBJECT);
        }
        catch (MetadataManagerException e)
        {
            throw new QueryException(e.getMessage(), e);
        }
        // Figure out where this member's column lies within its overall layer Column's drill paths
        if (mdObj instanceof MDItem)
        {
            MDItem itemObj = (MDItem)mdObj;
            int levelCount = 1;
            while (itemObj != null)
            {
                Vector paths = itemObj.getDrillDownPaths();
                String pathID = null;
                if (paths != null && paths.size() > 0)
                {                
                    MDItem pathObj = (MDItem)paths.elementAt(0);
                    pathID = pathObj.getUniqueID();
                    if (pathID.equals(levelCol))
                    {
                        // Found it
                        return new Integer(levelCount);
                    }
                    // Move down a level
                    itemObj = pathObj;
                    levelCount++;
                }
            }
        }
        return new Integer(0);
    }
    
    /**
     * @hidden
     * Check if the type is numeric
     */
    public static boolean isNumericType(String strType)
    {
        return strType.equals(MetadataMap.METADATA_DRILLSTATE) ||
                 strType.equals(MetadataMap.METADATA_REL_INDENT) ||
                 strType.equals(MetadataMap.METADATA_INDENT) ||
                 strType.equals(MetadataMap.METADATA_CHILDCOUNT);
    }    
 

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public static Object getParentType(SelectionList selections, String dimension, String type)
    {
        Selection sel = selections.find(dimension);
        if (sel != null && type != null)
        {
            // Get the last drill level step, if any
            int drillLevelStepCount = sel.getDrillLevelStepCount();
            if (drillLevelStepCount > 0)
            {
                DrillLevelStep dls = sel.getDrillLevelStep(drillLevelStepCount-1);
                if (dls != null)
                {
                    if (type.equals(MetadataMap.METADATA_DRILL_PARENT_LONGLABEL))
                    {
                        return dls.getParentLongLabel();
                    }
                    else if (type.equals(MetadataMap.METADATA_DRILL_PARENT_MEDIUMLABEL))
                    {
                        return dls.getParentMediumLabel();
                    }
                    else if (type.equals(MetadataMap.METADATA_DRILL_PARENT_SHORTLABEL))
                    {
                        return dls.getParentShortLabel();
                    }
                    else if (type.equals(MetadataMap.METADATA_DRILL_PARENT_DATE))
                    {
                        return dls.getParentDate();
                    }
                    else if (type.equals(MetadataMap.METADATA_DRILL_PARENT_DATESPAN))
                    {
                        return dls.getParentDateSpan();
                    }
                }
            }
        }
        return null;
    }
*/

    
   
    // Determine if the given dimension is asymmetric checking drills and selection
    // blm - Selection code moved to dvt-olap
/*    public static boolean isAsymmetric(QueryState state, String dimension)
    {
        if (state.getSelections() == null)
            return true;
            
        // Get the selection
        Selection sel = state.getSelections().find(dimension);
        if (sel != null)
        {
            return (sel.isAsymmetric() || sel.hasAsymmetricDrill());
        }
        return false;
    }*/
    

    /**
     * @hidden 
     * Return a dimension name given an edge and depth
     */
    public static String getDimensionNameFromLocation(DataAccessLong da, int edge, int depth) 
                    throws LayerOutOfRangeException, EdgeOutOfRangeException
    {
        if (edge == -1)
            return null;
            
        return (String)da.getLayerMetadata(edge, depth, 
                            LayerMetadataMap.LAYER_METADATA_NAME);
    }
 
    /**
     * @hidden
     * @param edge
     * @param dimension
     * @param throwExceptions
     * @param acceptBadLayer
     * @return
     * @throws EdgeOutOfRangeException
     * @throws LayerOutOfRangeException
     * Return the list of possible dimensions (generally one) at this location currently
     */    
    protected static String[] getDimName(DataAccessLong da, int edge, int dimension, boolean throwExceptions, boolean acceptBadLayer) throws EdgeOutOfRangeException, LayerOutOfRangeException {
        if (dimension == -1 && acceptBadLayer) {
            // List all dimensions
            try {
                String[] retval = new String[da.getLayerCount(edge)];
                for (int i = 0; i < retval.length; i++) {
                    retval[i] = getDimensionNameFromLocation(da, edge, i);
                }
                return retval;
            }
            catch (Exception e) {
                if (throwExceptions) {
                    if (e instanceof EdgeOutOfRangeException) {
                        throw (EdgeOutOfRangeException)e;
                    }
                    else if (e instanceof LayerOutOfRangeException) {
                        throw (LayerOutOfRangeException)e;
                    }
                }
                return null;
            }
        }
        else {
            try {
                return new String[] {getDimensionNameFromLocation(da, edge, dimension)};        
            }
            catch (Exception e) {
                if (throwExceptions) {
                    if (e instanceof EdgeOutOfRangeException) {
                        throw (EdgeOutOfRangeException)e;
                    }
                    else if (e instanceof LayerOutOfRangeException) {
                        return null;
                    }
                }
                return null;
            }
        }
    }

    /**
     * @hidden
     * @param edge
     * @param layer
     * @param slice
     * @param dimension
     * @return
     * @throws EdgeOutOfRangeException
     * @throws LayerOutOfRangeException
     * @throws SliceOutOfRangeException
     */
    protected static OlapQDR getOutsideLayerQDR(QueryState state, DataAccessLong da, int edge, int layer, long slice, String dimension) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException
    {
        // Are there any layers on this edge slower-varying than this target?
        if (layer > 0)
        {
            // Yes
            OlapQDR qdr = new OlapQDR(state.getMeasureDim());
            for (int l = 0; l < layer; l++)
            {
                // Look up the selection for this layer
                String layerDim = getDimName(da, edge, l, true, false)[0];
                if (layerDim != null)
                {
                    String member =  _makeString(da.getMemberMetadata(edge, l, slice, MetadataMap.METADATA_VALUE));
                    String level = _makeString(da.getMemberMetadata(edge, l, slice, MetadataMap.METADATA_LEVEL_NAME));
                    String strHier = _makeString(da.getMemberMetadata(edge, l, slice, MetadataMap.METADATA_HIERARCHY));
                    // blm - Selection code moved to dvt-olap
/*                    Selection sel = state.getSelections().find(layerDim);
                    if (strHier == null && sel != null)
                    {
                        if (member != null)
                        {
                            strHier = sel.getHierarchy();
                        }
                    }*/
                    // Put the dim/hier/member combination in to the qdr
                    qdr.addDimMemberPair(layerDim, member, strHier, level);
                }
            }
            return qdr;
        }
        return null;
    }

    /**
     *  @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    protected static QDR getAsymDrivingQDR(MetadataFunctions mf, QueryState state, QueryManagerInterface qm, DataAccessLong da, long pageSlice, int edge, long slice, String dim) throws EdgeOutOfRangeException, SliceOutOfRangeException
    {
        // Is this dim driven asymmetrically?
        // Get the selection
        // blm - Selection code moved to dvt-olap
        Selection sel = state.getSelections().find(dim);
        if (sel == null || !sel.isAsymmetric())
            return null;
        
        // It's driven asym: let's get the relevant dimensions
        Vector dependentDims = sel.getDependentDimensions();
        if (dependentDims == null || dependentDims.size() == 0)
            return null;
            
        // Get our localized slice QDR: we don't need to worry about the orthogonal dimensions, they can't drive us
        QDR localQDR = getSliceQDR(mf, state, qm, da, pageSlice, edge, slice, DataAccess.QDR_WITH_PAGE, false);
        QDR drivingQDR = new QDR(localQDR.getMeasureDim());        

        Enumeration dims = dependentDims.elements();
        while (dims.hasMoreElements())
        {
            String currDim = (String)dims.nextElement();
            // Find the member that goes with this
            drivingQDR.addDimMemberPair(currDim, localQDR.getDimMember(currDim));            
        }
        return drivingQDR;
    }*/

    /*
     * @hidden
     */
    // blm - Selection code moved to dvt-olap
/*      public static Integer getDrillState(MetadataFunctions mf, QueryState state, QueryManagerInterface qm, DataAccessLong da, CursorCarryoverInterface carryover, long pageSlice, String dimension, Object value, int edge, int depth, long[] hPos, long hIndex) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException
      {
          // Is this dim driven asymmetrically?
          // Get the selection
          QDR asymQDR = null;
          Selection sel = state.getSelections().find(dimension);
          long slice = da.getAbsoluteFromContext(edge, hPos, hPos.length-1);
          if (sel != null && sel.isAsymmetric())
          {
              asymQDR = getAsymDrivingQDR(mf, state, qm, da, pageSlice, edge, slice, dimension);
          }
          if (carryover != null)
          {
            Object retVal = carryover.getDrillState(dimension, value, asymQDR);
            // Found a leaf override
            if (retVal instanceof Integer)
                return (Integer)retVal;
          }
              
          // Now see if there's a specific drill step at this location.  That wins
          OlapQDR outerQDR = getOutsideLayerQDR(state, da, edge, depth, slice, dimension);
          if (sel != null)
          {
              DrillStep ds = sel.getDrillStep();
              if (ds != null)
              {
                  Vector down = ds.getDrillDownTargets();
                  Vector downQDRs = ds.getParentQDRs();
                  OlapQDR downQDR = null;
                  if (down != null)
                  {
                      int count = down.size();
                      for (int i = 0; i < count; i++)
                      {
                          if (value.equals(down.elementAt(i)))
                          {
                              // Found a drill down here: check the qdrs   
                              downQDR = downQDRs != null ? (OlapQDR)downQDRs.elementAt(i) : null;
                              if (downQDR == null || downQDR.isEmpty())
                              {
                                  // These match if this is true about the outerQDR
                                  if (outerQDR == null || outerQDR.isEmpty())
                                      return new Integer(DataDirector.DRILLSTATE_IS_DRILLED);
                              }
                              if (downQDR.equals(outerQDR))
                                  return new Integer(DataDirector.DRILLSTATE_IS_DRILLED);
                          }
                      }
                  }
                  // Check the ups
                  Vector up = ds.getDrillUpTargets();
                  if (up != null)
                  {
                      int count = up.size();
                      for (int i = 0; i < count; i++)
                      {
                          if (value.equals(up.elementAt(i)))
                          {
                              return new Integer(DataDirector.DRILLSTATE_DRILLABLE);
                          }
                      }
                  }
              }
          }
          return null;
      }
  */ 

    // blm - Selection code moved to dvt-olap
/*    private static Selection getSelection(QueryState state, String dim)
    {
        if (state.getSelections() != null)
            return state.getSelections().find(dim);
        return null;
    }*/
    
    
    /**
     * @hidden
     * Store value in cache
     * @param key
     * @param object
     */
/*    public static void updateCache(Hashtable dataCache, DataCacheKey key, Object object, long limit)
    {
        // Clear out the cache if we have exceeded the cache limit
        try
        {
            if (limit != -1 && dataCache.size() > limit)
            {
                dataCache.clear();
            }
        }
        catch (Exception nspe)
        {
            throw new QueryRuntimeException(nspe.getMessage(), nspe);
        }

        // Determine the cache key based on position and metadata type
        if (key != null)
        {
            // Determine whether the object is null before storing in cache
            if (object != null)
            {
                dataCache.put(key, object);
            }
            else
            {
                dataCache.put(key, m_nullMarker);
            }
        }
    }    
  */  
/*    public static boolean _compareArrays(long[] arr1, long[] arr2)
    {
        if (arr1 == null && arr2 == null)
            return true;

        if (arr1 == null || arr2 == null)
            return false;

        if (arr1.length != arr2.length)
            return false;

        for (int i = 0; i < arr1.length; i++)
        {
            if (arr1[i] != arr2[i])
                return false;
        }
        return true;
    }
*/
}
