/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

/****************************************************
 * Imports
 ****************************************************/
import java.io.Serializable;
import java.util.Properties;

/**
 * @hidden
 * A mapping of properties of two different platforms.
 *
 * This class a provides the mapping of the properties of a
 * Source platform to the target platfor ie. Metadata Manager.
 * This is used to map the stadard properies to the properties
 * of a particular source implementation.
 */
public class PropertyMap implements Serializable {
  /************************************************************************
  * Private members
  ************************************************************************/
  private Properties m_PropertyMap = null;

  /**
   * Constructor.
   *
   * @status hidden
   */
	public PropertyMap() {
		m_PropertyMap = new Properties();
	}
  
  /************************************************************************
  * Public Methods
  ************************************************************************/
  /**
   * Retrieves the size of this <code>PropertyMap</code>.
   * This method returns the size of the <code>Properties</code> that this
   * <code>PropertyMap</code> aggregates.
   *
   * @return The size of the <code>Properties</code> in this
   * <code>PropertyMap</code>.
   *
   * @see java.util.Properties
   *
   * @status hidden
   */
	public int size(){
		return m_PropertyMap.size();	
	}

  /**
   * Maps a source property to a target property.
   *
   * @param targetName The name of the property in the target environment.
   * @param sourceName The name of the property in the source environment.
   *
   * @status hidden
   */
	public void mapProperty( String targetName, String sourceName ) {
		m_PropertyMap.put ( targetName, sourceName);
	}
	
  /**
   * Removes a mapping in this <code>PropertyMap</code>.
   *
   * @param targetName The name of the property to remove in the target environment.
   *
   * @status hidden
   */
	public void unmapProperty( String targetName ) {
		m_PropertyMap.remove ( targetName );
		return;	 
	}

  /**
   * Retrieves the name of a source property.
   *
   * @param targetName The name of the target property whose source property
   *                   you want.
   *
   * @status hidden
   */
	public String getSourcePropertyName( String targetName ) {
		return (String) m_PropertyMap.get ( targetName );
	}
  
  /**
   * Retrieves the entire property map.
   *
   * @return The property map.
   *
   * @status hidden
   */
	public Properties getPropertyMap() {
		return m_PropertyMap;
	}

  /**
   * Specifies an entire property map.
   * In the <code>Properties</code> object that you pass, the target property
   * names should be the property names, and the source property names should
   * be the property values.
   *
   * @param props The property map.
   *
   * @status hidden
   */
	public void setPropertyMap( Properties props ) {
		m_PropertyMap = props;
		return;
	}
}