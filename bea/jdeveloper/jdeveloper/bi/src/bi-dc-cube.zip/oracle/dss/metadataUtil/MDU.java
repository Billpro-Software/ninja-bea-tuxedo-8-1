/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import java.lang.reflect.Array;
import oracle.dss.bicontext.BIConstants;

import oracle.dss.util.Utility;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * Generic static utility functions and constants.
 */
public class MDU
{
    // BIConstants - do not change
    public static final String OBJECT_TYPE      = BIConstants.OBJECT_TYPE;
    public static final String OBJECT_NAME      = BIConstants.OBJECT_NAME;
    public static final String OBJECT_LABEL     = BIConstants.OBJECT_LABEL;
    public static final String CLASS_NAME       = BIConstants.CLASS_NAME;

    public static final String SUB_OBJECT_TYPE  = "sub_object_type";

    /**
     * The operation did not succeed.
     *
     * @status Reviewed
     */
    public final static int FAILURE                         = 0;

    /**
     * The operation succeeded.
     *
     * @status Reviewed
     */
    public final static int SUCCESS                         = 1;

    public final static int FALSE                           = 0;
    public final static int TRUE                            = 1;

    public final static int CLIENT                          = 1;
    public final static int COMMON                          = 2;
    public final static int SERVER                          = 3;
    public final static int MDM_DRIVER                      = 4;
    public final static int ECM_DRIVER                      = 5;
    public final static int PERSISTENCE_DRIVER              = 6;

    public final static int NO_DEBUG                        = 0;
    public final static int DEBUG                           = 1;
    public final static int DEBUG_1                         = 2;
    public final static int DEBUG_2                         = 3;

    /**
     * There is a problem with the remote connection.
     *
     * @see oracle.dss.connection.client.Connection#connect
     * @see oracle.dss.connection.client.Connection#disconnect
     *
     * @status Reviewed
     */
    public final static int NO_REMOTE                       = 0;
    public final static int REMOTE_OK                       = 1;

    /**
     * Property data type: String.
     * @status Reviewed
     */
    public final static int STRING                          = 1;
    /**
     * Property data type: Long.
     * 
     * @status Documented
     */
    public final static int LONG                            = 2;
    /**
     * Property data type: Integer.
     * 
     * @status Documented
     */
    public final static int INTEGER                         = 3;
    /**
     * Property data type: <code>Object</code>.
     * 
     * @status Reviewed
     */
    public final static int OBJ                             = 4;
    /**
     * Property data type: A <code>Vector</code> of integers.
     * 
     * @status Documented
     */
    public final static int STRING_VECTOR                   = 5;
    /**
     * Property data type: All data types.
     * This includes <code>String</code> properties, 
     * <code>Object</code> properties
     * 
     * @status Reviewed
     */
    public final static int ALL_DATATYPES                   = 10;

    /**
     * Property bag flag: Keep existing properties.
     * Add properties from the property bag that is being set.
     *
     * @status Reviewed
     */
    public final static int KEEP                            = 8;
    /**
     * @hidden (hidden method in PropertyBag)
     */
    public final static int ADD                             = 9;
    /**
     * Property bag flag: Remove existing properties.
     * Replace existing properties with those in the property bag
     * that is being set.
     *
     * @status Reviewed
     */
    public final static int REMOVE                          = 10;

    /**
     * Illegal value for a <code>long</code> property.
     * @status Reviewed
     */
    public final static long ILLEGAL_LONG_VALUE             = -9999;
    /**
     * Illegal value for an <code>int</code> property.
     * @status Reviewed
     */
    public final static int  ILLEGAL_INT_VALUE              = -9999;

    /**
     * User-interface flag: Display the property in the JDE.
     * @status Reviewed
     */
    public final static int UI_VISIBLE                      = 0x0001;
    /**
     * User-interface flag: The property can be set through the user interface.
     * @status Reviewed
     */
    public final static int UI_WRITE                        = 0x0002;
    /**
     * User-interface flag: The property can be deleted through the user interface.
     * @status Reviewed
     */
    public final static int UI_DELETE                       = 0x0004;
    /**
     * User-interface flag: The value of this property should be encrypted.
     * Asterisks (***) should appear instead of characters.
     * @status Reviewed
     */
    public final static int UI_ENCRYPT                      = 0x0008;
    /**
     * User-interface flag: The property is visible in the user interface, and
     *                      it can be set and deleted through the user interface.
     * @status Reviewed
     */
    public final static int UI_ALL                          = 0x0010;
    /**
     * User-interface flag: Do not display the property in the user interface.
     * @status Reviewed
     */
    public final static int UI_NONE                         = 0x0020;

    public final static String DRIVER_TYPE                  = "Driver Type";
    /**
     * Driver type: MDM.
     * Driver type for the MetadataManager driver that reads
     * Metadata from OLAP schema.
     * 
     * @status Documented
     */
    public final static String MDM                          = PersistableConstants.MDM;
    /**
     * @hidden
     * Driver type: ECM
     * Store this object in an OLAP Schema.
     * 
     * @status hidden because not supported
     */
    public final static String ECM                          = "ECM";
    /**
     * Driver type: Persistence.
     * Store this object in the BI Beans Catalog.
     * 
     * @status Reviewed
     */
    public final static String PERSISTENCE                  = PersistableConstants.PERSISTENCE;
    public final static String BISESSION                    = "BISESSION";
    public final static String NO_DRIVER                    = "NO_DRIVER";

    public final static String OBJECT_ID                    = "ObjectID";

    public final static String CONNECTION_STATUS            = "Connection Status";
    public final static String CONNECTION_STRING            = "Connection String";

    /**
     * @hidden
     */
    public final static String COPY_MODE                    = "CopyMode";
    /**
     * @hidden
     */
    public final static String COPY_NAME                    = "CopyName";
    /**
     * @hidden
     */
    public final static String BIND_OPTION                  = "BindOption";
    /**
     * @hidden
     */
    public final static String BIND                         = "Bind";
    /**
     * @hidden
     */
    public final static String REBIND                       = "Rebind";
    /**
     * @hidden
     */
    public final static String LOOKUP_OPTION                = "LookupOption";
    /**
     * @hidden
     */
    public final static String LOOKUP                       = "Lookup";
    /**
     * @hidden
     */
    public final static String LOOKUP_LINK                  = "LookupLink";
    /**
     * @hidden
     * The name of the root folder
     */
    public final static String ROOT_FOLDER                  = "Root";

    /**
     * @hidden
     * Cache semantics: Cache the object on the client only.
     * @status hidden
     */
    public final static int CLIENT_ONLY                     = 1;

    /**
     * @hidden
     * Cache semantics: Cache the on the middle tier only.
     * @status hidden
     */
    public final static int SERVER_ONLY                     = 2;

    /**
     * @hidden
     * Cache semantics: Cache the object both on the client and on the middle
     * tier.
     * @status hidden
     */
    public final static int BOTH                            = 3;

    /**
     * @hidden
     * Cache semantics: Do not cache the object at all.
     * @status hidden
     */
    public final static int NONE                            = 4;

    /**
     * @hidden
     */
    public final static String CACHE_SEMANTIC               = "Cache Semantic";

    /**
     * @hidden
     */
    public final static String LOAD_TYPE                    = "Load Type";
    /**
     * @hidden
     */
    public final static String DEFERRED_LOAD                = "Deferred load";
    /**
     * @hidden
     */
    public final static String ASYNCHRONOUS_LOAD            = "Asynchronous load";
    /**
     * @hidden
     */
    public final static String LOAD_ALL                     = "Load All";

    /**
     * @hidden
     */
    public final static String TIME_LAPSED                  = "Time Lapsed";

    /**
     * @hidden
     */
    public final static String TOTAL_CALLS                  = "Total Calls";
    
    // DISCOVERER Constants

    public final static String DISCOVERER                   = "DISCOVERER";

    /**
     * The unique ID for the object.
     * @status Reviewed
     */
    public final static String UNIQUE_ID					= "Unique ID";
    /**
     * @hidden
     */
    public final static String PATH                         = "Path";
    /**
     * A metadata ID from the metadata driver.
     * @status Reviewed
     */
    public final static String OLAPI_METADATA_ID            = "Olapi Metadata ID";
    /**
     * @hidden
     */
    public final static String OLAPI_RUNTIME_ID             = "Olapi Runtime ID";
    /**
     * @hidden
     */
    public final static String OLAPI_RUNTIME_IDS            = "Olapi Runtime IDs";

    // bit types
    public final static short  UID_BIT                      = 0x1;      // unique id  00001
    public final static short  PATH_BIT                     = 0x2;      // path       00010
    public final static short  OLAPID_BIT                   = 0x4;      // olap id    00100
    public final static short  OLAPRUNID_BIT                = 0x8;      // olap runid 01000
    public final static short  OLAPRUNIDS_BIT               = 0x10;     // olap runid 10000

    /**
     * @hidden
     */
    public final static String OLAP_CATALOG                 = "Olap Catalog";

    /**
     * @hidden
     */
    public final static String OFF                          = "OFF";

    public final static String EUL                          = "EUL";
    public final static String DATASOURCE_TYPE              = "datasource_type";
    public static final String DATASOURCE                   = "datasource";

    /**
     * @hidden
     * Driver type for Runtime Datasource
     */
    public final static String RDS                          = "RDS";

    /**
     * @hidden
     * Driver type for Siebel
     */
    public final static String SBA                          = "SBA";

    /**
     * @hidden
     * Driver type for Siebel
     */
    public final static String SOAP                         = "soap";

    /**
     * Put the contents of an ArrayList into an array and return it
     *
     * @param ArrayList arrayList contents to put into an array
     * @return array containing ArrayList contents
     * @status New
     */

    public static Object[] copyArrayListToArray (ArrayList arrayList) {
      if ( arrayList == null )
        return null;
      int size = arrayList.size();
      if (size == 0)
          return null;

      // Scan up to a valid list value
      ListIterator list = arrayList.listIterator();
      Object elem = null;
      while (list.hasNext() && elem == null)
          {
          elem = list.next();
          }

      if (elem == null)
          {
          return null;
          }

      Object[] ret =
          (Object[])Array.newInstance(elem.getClass(), arrayList.size());

      arrayList.toArray(ret);
      return ret;
      }

    public static Object[] copyArrayListToArray (ArrayList arrayList, String className) {
      if (( className == null ) || ( className.equals("") ))
        return null;
      try {
        return copyArrayListToArray( arrayList, Utility.loadClass(className));
      }
      catch ( Exception e ) {
        //e.printStackTrace();        
      }
      return null;
    }

    public static Object[] copyArrayListToArray (ArrayList arrayList, Class className) {
      if ( arrayList == null )
        return null;
      if ( arrayList.size() == 0)
        return null;
      if( className == null )
        return null;
      Object[] ret = (Object[])Array.newInstance( className, arrayList.size());
      arrayList.toArray(ret);
      return ret;
    }

    public static Object[] copyListToArray (List list, Class className)
    {
        Object objArray[] = null;
        if(list != null && list.size() != 0 && className != null)
        {
            objArray = (Object[])Array.newInstance(className, list.size());
            list.toArray(objArray);
        }
        return objArray;
    }
}
