/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */
package oracle.dss.dataSource.common;

import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * Defines methods that manipulate the mapping of dimensions along
 * edges of an n-dimensional cube.
 *
 * @status Documented
 */
public interface LayoutManager extends BaseManager
{
   /**
    * Arranges a layout of dimensions along the edges of a <code>Query</code>
    * object.
    *
    * @param dimensions An array of dimension layout arrays.
    *                   The outer array maps to edges (such as column or row);
    *                   the inner array maps slowest to fastest varying within
    *                   an edge.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @return <code>true</code> if the operation is successful;
    *         <code>false</code> if the operation is not successful.
    *
    * @status Documented
    */
   public Boolean layout(String[][] items)  throws  QueryException, MetadataManagerException;
   
   /**
    * Performs the specified pivot operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension (if an edge is empty, then this
    *                     must be a number that indicates the target edge)
    * @param flags        A constant that indicates the type of pivot. Use
    *                     <code>PivotConstants.PIVOT_AFTER</code> or
    *                     <code>PivotConstants.PIVOT_BEFORE.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @see PivotConstants#PIVOT_AFTER
    * @see PivotConstants#PIVOT_BEFORE
    *
    * @status Documented
    */
   public void pivot(String source, String target, int flags) throws QueryException, MetadataManagerException;

   /**
    * Determines if the specified pivot operation is OK.
    *
    * @param source       The source dimension.
    * @param target       The target dimension (if an edge is empty, then this
    *                     must be a number that indicates the target edge)
    * @param flags        A constant that indicates the type of pivot. Use
    *                     <code>PivotConstants.PIVOT_AFTER</code> or
    *                     <code>PivotConstants.PIVOT_BEFORE.
    *                     
    * @return constant indicating if the pivot was legal, and if not, an indication
    *                  as to why not.
    *
    * @throws QueryException           If there is a problem during
    *                                  this operation.
    *
    * @see PivotConstants#PIVOT_AFTER
    * @see PivotConstants#PIVOT_BEFORE
    *
    * @status New
    */
   public int pivotCheck(String source, String target, int flags) throws QueryException;

   /**
    * Determines if the specified swap operation is OK.
    *
    * @param source       The source dimension.
    * @param target       The target dimension 
    *                     
    * @return constant indicating if the swap was legal, and if not, an indication
    *                  as to why not.
    *
    * @throws QueryException           If there is a problem during
    *                                  this operation.
    *
    * @status New
    */
   public int swapCheck(String source, String target) throws QueryException;

   /**
    * Performs the specified swap operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @status Documented
    */
   public void swap(String source, String target) throws QueryException, MetadataManagerException;

   /**
    * Performs the specified edge swap operation.
    *
    * @param source  A constant (<code>DataDirector.COLUMN_EDGE</code>,
    *               <code>DataDirector.PAGE_EDGE</code>, or
    *               <code>DataDirector.ROW_EDGE</code>) that represents
    *               the source edge.
    * @param target  A constant (<code>DataDirector.COLUMN_EDGE</code>,
    *               <code>DataDirector.PAGE_EDGE</code>, or
    *               <code>DataDirector.ROW_EDGE</code>) that represents
    *               the target edge.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @see oracle.dss.util.DataDirector#COLUMN_EDGE
    * @see oracle.dss.util.DataDirector#PAGE_EDGE
    * @see oracle.dss.util.DataDirector#ROW_EDGE
    *
    * @status Documented
    */
   public void swapEdges(int source, int target)  throws QueryException, MetadataManagerException;
   
   /**
    * Retrieves the current layout of dimensions in the <code>Query</code>
    * object as a two-dimensional <code>String</code>, using LayerMetadataMap.LAYER_METADATA_NAME.
    *
    * @return The current layout of the <code>Query</code> object.
    *
    * @status Documented
    */
   public String[][] getLayout();   
    
    /**
     * Retrieves the current layout of dimensions in the <code>Query</code>
     * object as a two-dimensional <code>String</code>, putting the given 
     * LayerMetadataMap type of IDs for the dimensions or items into the array.
     *
     * @param layerMetadataType The type of metadata object ID to use in the returned layout.
     * 
     * @return The current layout of the <code>Query</code> object.
     *
     * @status Documented
     */
    public String[][] getLayout(String layerMetadataType);            
}
