/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports

/**
 * Basic implementation of the <code>MetadataManagerListener</code> interface.
 * You can extend this class to implement your own
 * <code>MetadataManagerListener</code>.
 *
 * @status Reviewed
 */
public class MetadataManagerAdapter implements MetadataManagerListener {

  /**
   * Constructor.
   * This implementation does nothing.
   *
   * @status Reviewed
   */
  public MetadataManagerAdapter() {
  }

  /**
   * Responds to a request to add a connection to a
   * <code>MetadataManager</code>.
   * This implementation does nothing.
   * The object in the event that is passed is the <code>Connection</code>
   * that has been removed.
   *
   * @param evt   Information about the connection operation.
   *
   * @status Reviewed
   */
  public void addingConnection( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to the addition of a connection to a
   * <code>MetadataManager</code>.
   * This implementation does nothing.
   *
   * @param evt   Information about the connection operation.
   *
   * @status Reviewed
   */
  public void connectionAdded( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to a request to remove a connection from a
   * <code>MetadataManager</code>.
   * The object in the event that is passed is the <code>Connection</code>
   * that is being removed.
   * This implementation does nothing.
   *
   * @param evt   Information about the removal operation.
   *
   * @status Reviewed
   */
  public void removingConnection( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to the removal of a connection from a
   * <code>MetadataManager</code>.
   * This implementation does nothing.
   * The object in the event that is passed is the <code>Connection</code>
   * that has been removed.
   * This implementation does nothing.
   *
   * @param evt   Information about the removal operation.
   *
   * @status Reviewed
   */
  public void connectionRemoved( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to a request to attach an analytic workspace.
   * This method is called before the workspace is attached.
   * The object in the event that is passed is a <code>PropertyBag</code>
   * for the attach operation.
   * This implementation does nothing.
   *
   * @param evt    Information about the attach operation.
   *
   * @see oracle.dss.metadataUtil.PropertyBag
   *
   * @status Reviewed
   */
  public void attaching( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to the attaching of an analytic workspace.
   * This method is called after the workspace is attached.
   * The object in the event that is passed is a <code>PropertyBag</code>
   * for the attach operation.
   * This implementation does nothing.
   *
   * @param evt  Information about the attach operation.
   *
   * @see oracle.dss.metadataUtil.PropertyBag
   *
   * @status Reviewed
   */
  public void attached( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to a request to detach an analytic workspace.
   * This method is called before the workspace is detached.
   * The object in the event that is passed is a <code>PropertyBag</code>
   * for the detach operation.
   * This implementation does nothing.
   *
   * @param evt  Information about the detach operation.
   *
   * @see oracle.dss.metadataUtil.PropertyBag
   *
   * @status Reviewed
   */
  public void detaching( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to the detaching of an analytic workspace.
   * This method is called after the workspace is detached.
   * The object in the event that is passed is a <code>PropertyBag</code>
   * for the detach operation.
   * This implementation does nothing.
   *
   * @param evt  Information about the detach operation.
   *
   * @see oracle.dss.metadataUtil.PropertyBag
   *
   * @status Reviewed
  */
  public void detached( MetadataManagerEvent evt ) {
  }

  /**
   * Responds to a change in the metadata.
   * This method is called after metadata has been modified.
   * The object in the event that is passed is an <code>MDContentBag</code>.
   * The <code>MDContentBag</code> contains all of the <code>MDObjects</code>
   * that have been modified.
   * This implementation does nothing.
   *
   * @param evt  Information about the modified metadata.
   *
   * @see MDObject
   *
   * @status Reviewed
   */
  public void metadataModified( MetadataModifiedEvent evt ) {
  }

  /**
   * Responds to the refreshing of the metadata cache.
   * This method is called after metadata has been refreshed from the server
   * to the middle-tier cache, the client-tier cache, or both.
   * Normally, this method should repaint any user interface that displays
   * representations of metadata objects.
   * The object in the event that is passed is <code>null</code>.
   * This implementation does nothing.
   *
   * @param evt  Information about the modified metadata.
   *
   * @status Reviewed
   */
  public void metadataRefresh( MetadataManagerEvent evt ) {
  }
}