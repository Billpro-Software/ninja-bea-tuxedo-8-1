/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/BuilderRuntimeException.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.builder;

import oracle.dss.util.BIBaseRuntimeException;
import oracle.dss.util.gui.ResourceHandler;

/**
 * <pre>
 * Provides runtime exceptions that are thrown specifically by the 
 * <code>CalcBuilder</code>.
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.12
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   08/15/07 - 
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 *    gkellam   11/09/05 - Add BuilderRuntimeException and 
 *                         CalcBuilderRuntimeException. 
 *    gkellam   11/09/05 - Add BuilderRuntimeException and 
 *                         CalcBuilderRuntimeException. 
 * 
 */
public class BuilderRuntimeException extends BIBaseRuntimeException {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * A <code>ResourceHandler</code> used to retrieve resources.
   *
   * @status hidden
   */ 
  protected ResourceHandler m_resourceHandler = null;

  /**
   * @hidden
   * 
   * The resource bundle class used by the <code>BuilderRuntimeException</code> 
   * to retrieve resources.
   *
   * @status hidden
   */ 
  protected String m_strBundleClass = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>BuilderRuntimeException</code> constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated error string in the 
   *        resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be <code>null</code>).
   *
   * @status new
   */
  public BuilderRuntimeException (String strErrorCode, Throwable throwable) {
    super (strErrorCode, throwable);
  }

  /**
   * <code>BuilderRuntimeException</code> constructor.
   *
   * @param resourceHandler A <code>ResourceHandler</code> used to translate
   *        strings.
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated error string in the 
   *        resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   * @param throwable A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be <code>null</code>).
   *
   * @status new
   */
  public BuilderRuntimeException (ResourceHandler resourceHandler, String strErrorCode, Throwable throwable) {
    super (strErrorCode, throwable);
    setResourceHandler (resourceHandler);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * <pre>
   * Retrieves the error message.
   * 
   * If the error associated with the original error code is not found,
   * then this method retrieves the original error code.
   *
   * The message is formatted as follows:
   * ErrorCode <space> ErrorString
   *
   * For example: DVT-1500 MetadataManager not set
   * </pre>
   *
   * @return <code>String</code> that represents the formatted error message.
   *
   * @status new
   */
  public String getMessage() {
    // Retrieve the initial Error code
    String strMessage = super.getMessage();

    if (strMessage != null) {
      // Retrieve our error string
      String strError = (getResourceHandler() != null) ? 
        getResourceHandler().getResourceBundle (getResourceBundleClass()).getString (strMessage) : strMessage;
      
      if (strError != null) {
        // Create our new error message
        //  ErrorCode <space> ErrorString
        //  DVT-1500 MetadataManager not set
        StringBuffer strBuffer = new StringBuffer (strMessage);
        strBuffer.append (" ");
        return strBuffer.append(strError).toString();
      }
    }

    return strMessage;
  }

  /**
   * Specifies the resource bundle class used by the <code>BuilderRuntimeException</code> 
   * to retrieve resources.
   *
   * @param strBundleClass A <code>String</code> representing the resource
   *        bundle class.
   *
   * @status new
   */ 
  public void setResourceHandler (ResourceHandler resourceHandler) {
    m_resourceHandler = resourceHandler;
  }

  /**
   * Retrieves the resource bundle class used by the <code>BuilderRuntimeException</code> 
   * to retrieve resources.
   *
   * @return <code>String</code> representing the resource bundle class.
   *
   * @status new
   */ 
  public ResourceHandler getResourceHandler () {
    return m_resourceHandler;
  }

  /**
   * Specifies the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @param strBundleClass A <code>String</code> representing the resource
   *        bundle class.
   *
   * @status new
   */ 
  public void setResourceBundleClass (String strBundleClass) {
    m_strBundleClass = strBundleClass;
  }

  /**
   * Retrieves the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @return <code>String</code> representing the resource bundle class.
   *
   * @status new
   */ 
  public String getResourceBundleClass () {
    return m_strBundleClass;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
}
