/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Vector;
import java.util.Enumeration;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;

/**
 *
 * An enumeration for naming operations in persistence and metadata management
 * services.
 * Methods such as <code>list</code> and <code>search</code> return
 * <code>BINamingEnumeration</code> classes.
 * <P>
 * The methods that return this class declare that they return
 * <code>NamingEnumeration</code> objects.
 * This implementation of <code>NamingEnumeration</code> does not add anything
 * beyond the methods specified in the interface, so you do not need to cast
 * the return value from such methods.
 *
 * @see BIContext#search
 * @hidden
 */
public class BINamingEnumeration implements NamingEnumeration
{
    private final Enumeration m_enum;

    /**
     * Constructor that takes an enumeration.
     * Application developers should not have to construct a
     * <code>BINamingEnumeration</code>.
     * Persistence and metadata management code creates them.
     *
     * @param enumeration The enumeration of objects to store in this
     *             <code>BINamingEnumeration</code>.
     *
     * @status documented
     */
    public BINamingEnumeration(Enumeration enumeration)
    {
        m_enum = enumeration;
    }

    /**
     * Constructor that takes a vector.
     * Application developers should not have to construct a
     * <code>BINamingEnumeration</code>.
     * Persistence and metadata management code creates them.
     *
     * @param v The vector of objects to store in this
     *             <code>BINamingEnumeration</code>.
     *
     * @status documented
     */
    public BINamingEnumeration(Vector v)
    {
        m_enum = v.elements();
    }

    /**
     * Indicates whether this <code>BINamingEnumeration</code> has any more
     * elements, or whether you are at the end of the list.
     *
     * @return <code>true</code> if more elements exist in this
     *                           <code>BINamingEnumeration</code>,
     *         <code>false</code> if there are no more elements.
     *
     * @status documented
     */
    public boolean hasMoreElements()
    {
        return m_enum.hasMoreElements();
    }

    /**
     * Indicates whether this <code>BINamingEnumeration</code> has any more
     * elements, or whether you are at the end of the list.
     *
     * @return <code>true</code> if more elements exist in this
     *                           <code>BINamingEnumeration</code>,
     *         <code>false</code> if there are no more elements.
     *
     * @throws NamingException If a naming exception occurs in the attempt
     *                         to determine whether there are more elements.
     *
     * @status documented But this really doesn't throw any exceptions...
     */
    public boolean hasMore() throws NamingException
    {
        return hasMoreElements();
    }

    /**
     * Retrieves the next element in this <code>BINamingEnumeration</code>.
     * For example, a <code>search</code> operation returns a
     * <code>BINamingEnumeration</code> of objects that meet the search
     * criteria.
     * If you had searched for graphs, then this method would return the
     * next graph in the list.
     *
     * @return The next element in this <code>BINamingEnumeration</code>.
     *
     * @status documented
     */
    public Object nextElement()
    {
        return m_enum.nextElement();
    }

    /**
     * Retrieves the next element in this <code>BINamingEnumeration</code>.
     * For example, a <code>search</code> operation returns a
     * <code>BINamingEnumeration</code> of objects that meet the search
     * criteria.
     * If you had searched for graphs, then this method would return the
     * next graph in the list.
     *
     * @return The next element in this <code>BINamingEnumeration</code>.
     *
     * @throws NamingException If a naming exception occurs in accessing the
     *                         next element.
     *
     * @status documented But this doesn't really throw anything.
     */
    public Object next() throws NamingException
    {
        return nextElement();
    }

    // TODO
    public void close()
    {

    }
}
