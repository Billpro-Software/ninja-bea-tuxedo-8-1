/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.connection.server.drivers;

// Imports
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.PropertyMap;
import oracle.dss.connection.common.ConnectionException;

// Interface that needs to be implemented for all connection types.
/**
 * @hidden
 */
public interface ConnectionDriver
{
   /************************************************************************
    * Connection Support
    ************************************************************************/
    public boolean isConnected();
    public int connect() throws ConnectionException;
    public int disconnect() throws ConnectionException;

	// connect
    public PropertyBag connect( PropertyBag properties ) throws ConnectionException;

	// disconnect
	public PropertyBag disconnect ( PropertyBag properties ) throws ConnectionException;

   /************************************************************************
    * Support for Properties
    ************************************************************************/
	// Returns a PropertyBag contains Connection Property Names
	// and their values.
	public PropertyBag getConnectionPropertyBag() throws ConnectionException;

    public String getConnectionString();

    // High Priority
    public String getDriverType();

   /************************************************************************
    * SPL Support
    ************************************************************************/
	// This can be for hooking up for supporting SPL, SQL etc.
	public String executeCommand ( String command, PropertyBag properties ) throws ConnectionException;

    // Evaluates an SPL Expression and gets the results back.
    // The Expression Type is the data type of the expected
    // result such as string, long, decimal etc.
    public Object evaluateExpression(String expression, PropertyBag properties ) throws ConnectionException;

   /************************************************************************
    * Driver Specific Objects
    ************************************************************************/
	// get the driver specific objects from the driver
	public Object getDriverSpecificObject( PropertyBag properties ) throws ConnectionException;

	// set the driver specific objects from the driver
	public int setDriverSpecificObject( Object object, PropertyBag properties ) throws ConnectionException;

	// remove the driver specific objects at the driver
	public int removeDriverSpecificObjects( PropertyBag properties ) throws ConnectionException;
/*
    public void setSecurityDriverManager(SecurityDriverManager manager);
*/
    public Object getRemoteConnection();
    public void setRemoteConnection(Object remoteConnection);

    public PropertyBag getVersionInfo();

    public boolean getFeature(String feature);
}
