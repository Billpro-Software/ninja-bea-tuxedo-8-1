/*
 * ButtonPanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */   
package oracle.dss.datautil.gui;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.ImageIcon;

import java.util.BitSet;
import java.util.Locale;

import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import oracle.bali.ewt.graphics.ImageSetIcon;
import oracle.bali.ewt.graphics.ImageStrip;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.Timer;

/**
 * @hidden
 */
public class ButtonPanel extends JPanel {
	public static final int LEFT = 0;
	public static final int RIGHT = 1;

	public static final int SORT = 0;
	public static final int SAVE = 1;
	public static final int EXPAND = 2;
	public static final int COLLAPSE = 3;
	public static final int FIND = 4;
	public static final int MOVE_UP = 5;
	public static final int MOVE_DOWN = 6;

  private static final int TOP_INSET = 0;
  private static final int BOTTOM_INSET = 0;
  private static final int LEFT_INSET = 2;
  private static final int RIGHT_INSET = 2;
  
    protected JButton m_btnSave;
    protected JButton m_btnSort;
    protected JButton m_btnExpand;
    protected JButton m_btnCollapse;
    protected JButton m_btnFind;
	protected JButton m_btnMoveUp;
	protected JButton m_btnMoveDown;

    private JButton m_popupMenu;
    
    // Determines which buttons are turned on.
    private BitSet m_bitSet = new BitSet();
    
    // Stores a resource cache.
    private ResourceCache m_resourceCache = new ResourceCache();
    private boolean m_bSuperCalled = false;
    
	// Set the default buttons to display.
	{
		m_bitSet.set(SORT);
		m_bitSet.set(SAVE);
	}

    /**
    * "NEW"
    * Constructor which creates a new ButtonPanel.
    * It subclasses a JPanel and sets its layout manager
    * to be a FlowLayout, and then adds the appropriate
    * buttons.
    */
    public ButtonPanel() {
      m_bSuperCalled = true;
    	//super(new FlowLayout(FlowLayout.RIGHT));
    	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    	createButtons();
    }
    
    /**
    * "NEW"
    * Constructor which creates a new ButtonPanel.
    * It subclasses a JPanel and sets its layout manager
    * to be a FlowLayout, and then adds the appropriate
    * buttons.
    *
   	* @param BitSet explicitly determines which buttons to display.
    */
    public ButtonPanel(BitSet bitSet) {
      m_bSuperCalled = true;
    	//super(new FlowLayout(FlowLayout.RIGHT));
    	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    	setButtons(bitSet);
    	createButtons();
    }

    /**
    * "NEW"
    * Constructor which creates a new ButtonPanel.
    * It subclasses a JPanel and sets its layout manager
    * to be a FlowLayout, and then adds the appropriate
    * buttons.
    *
   	* @param BitSet explicitly determines which buttons to display.
    */
    public ButtonPanel(BitSet bitSet, int intAlignment) {
      m_bSuperCalled = true;
    	//super(new FlowLayout((intAlignment == LEFT) ? FlowLayout.LEFT : FlowLayout.RIGHT));
    	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    	setButtons(bitSet);
    	createButtons();
    }

	/**
	* "NEW"
	* Sets which buttons to display on the dialog.
	* @param bitSet BitSet used to determine which buttons to display.
	*/
	public void setButtons(BitSet bitSet) {
		m_bitSet = bitSet;
	}

	public void addComponent(JComponent component) {
		add(component);
	}

  public void setEnabled(int button, boolean enabled)
  {
    if ((button == SORT) && (m_btnSort != null))
      m_btnSort.setEnabled(enabled);
    else if ((button == SAVE) && (m_btnSave != null))
      m_btnSave.setEnabled(enabled);
    else if ((button == EXPAND) && (m_btnExpand != null))
      m_btnExpand.setEnabled(enabled);
    else if ((button == COLLAPSE) && (m_btnCollapse != null))
      m_btnCollapse.setEnabled(enabled);
    else if ((button == FIND) && (m_btnFind != null))
      m_btnFind.setEnabled(enabled);
    else if ((button == MOVE_UP) && (m_btnMoveUp != null))
      m_btnMoveUp.setEnabled(enabled);
    else if ((button == MOVE_DOWN) && (m_btnMoveDown != null))
      m_btnMoveDown.setEnabled(enabled);
  }
	/**
   * @hidden
	 * Set the locale for this component.
	 *
	 * @param locale The locale.
	 *
	 * @status hidden
	 */
	public void setLocale(Locale locale) {
    super.setLocale(locale);
    if (!m_bSuperCalled)
      return;
		m_resourceCache.setLocale(locale);
		updateResources();
	}

	/**
	 * Update the text for the buttons.
	 *
	 * @status private
	 */
	private void updateResources() {
    	if (m_btnSort != null) {
    		String strSort = m_resourceCache.getIntlString("Sort");
            String txtSort = StringUtils.stripMnemonic(strSort);
            m_btnSort.setText(txtSort);
	        m_btnSort.setToolTipText(txtSort);
            m_btnSort.setMnemonic(StringUtils.getMnemonicKeyCode(strSort));
		}
    	if (m_btnSave != null) {
    		String strSave = m_resourceCache.getIntlString("Save");
            String txtSave = StringUtils.stripMnemonic(strSave);
            m_btnSave.setText(txtSave);
	        m_btnSave.setToolTipText(txtSave);
            m_btnSave.setMnemonic(StringUtils.getMnemonicKeyCode(strSave));
		}
    	if (m_btnExpand != null) {
	        m_btnExpand.setToolTipText(m_resourceCache.getIntlString("expand"));
		}
    	if (m_btnCollapse != null) {
	        m_btnCollapse.setToolTipText(m_resourceCache.getIntlString("collapse"));
		}
    	if (m_btnFind != null) {
	        m_btnFind.setToolTipText(m_resourceCache.getIntlString("find"));
		}
		if (m_btnMoveUp != null) {
	    	m_btnMoveUp.setToolTipText(m_resourceCache.getIntlString("Move Up"));
		}
		if (m_btnMoveDown != null) {
	    	m_btnMoveDown.setToolTipText(m_resourceCache.getIntlString("Move Down"));
		}	
	}
	
	/**
	 * Create the buttons.
	 *
	 * @status private
	 */
    private void createButtons() {
      Insets insets = new Insets(TOP_INSET, LEFT_INSET, BOTTOM_INSET, RIGHT_INSET);
    	if (m_bitSet.get(SORT)) {
	        m_btnSort = new JButton();
          m_btnSort.setMargin(insets);
	    	m_btnSort.addActionListener(new ButtonPanelActionListener());
	        add(m_btnSort);
		}
    	if (m_bitSet.get(SAVE)) {
	        m_btnSave = new JButton();
          m_btnSave.setMargin(insets);
	    	m_btnSave.addActionListener(new ButtonPanelActionListener());
	        add(m_btnSave);
		}
    	if (m_bitSet.get(EXPAND)) {
	        m_btnExpand = new JButton(new ImageIcon(Utils.getImageResource(this, "images/expandall.gif")));
          m_btnExpand.setMargin(insets);
	    	m_btnExpand.addActionListener(new ButtonPanelActionListener());
	        add(m_btnExpand);
		}
    	if (m_bitSet.get(COLLAPSE)) {
	        m_btnCollapse = new JButton(new ImageIcon(Utils.getImageResource(this, "images/collapseall.gif")));
          m_btnCollapse.setMargin(insets);
	    	m_btnCollapse.addActionListener(new ButtonPanelActionListener());
	        add(m_btnCollapse);
		}
    	if (m_bitSet.get(FIND)) {
	        m_btnFind = new JButton(new ImageIcon(Utils.getImageResource(this, "images/search.gif")));
          m_btnFind.setMargin(insets);
	    	m_btnFind.addActionListener(new ButtonPanelActionListener());
	        add(m_btnFind);
		}
		if (m_bitSet.get(MOVE_UP)) {
			    m_btnMoveUp = new JButton(new ImageSetIcon(new ImageStrip(Utils.getImageResource(ButtonPanel.class, "images/reorderUpRight.gif"), ImageStrip.STATE_DISABLED)));
          m_btnMoveUp.setMargin(insets);      
        m_btnMoveUp.addActionListener(new ButtonPanelActionListener());
	        add(m_btnMoveUp);
		}
		if (m_bitSet.get(MOVE_DOWN)) {
	        m_btnMoveDown = new JButton(new ImageSetIcon(new ImageStrip(Utils.getImageResource(ButtonPanel.class, "images/reorderDownRight.gif"), ImageStrip.STATE_DISABLED)));
          m_btnMoveDown.setMargin(insets);
        m_btnMoveDown.addActionListener(new ButtonPanelActionListener());
	        add(m_btnMoveDown);
		}
    }

    /**
    * "NEW""
   	* Handles the user hitting the "Sort" button.
   	*/ 
	protected void doSort() {
		System.out.println("Sort not implemented.");
	}

    /**
    * "NEW""
   	* Handles the user hitting the "Save" button.
   	*/ 
	protected void doSave() {
		System.out.println("Save not implemented.");
	}

    /**
    * "NEW""
   	* Handles the user hitting the "Expand" button.
   	*/ 
	protected void doExpand() {
		System.out.println("Expand not implemented.");
	}

    /**
    * "NEW""
   	* Handles the user hitting the "Collapse" button.
   	*/ 
	protected void doCollapse() {
		System.out.println("Collapse not implemented.");
	}

    /**
    * "NEW""
   	* Handles the user hitting the "Find" button.
   	*/ 
	protected void doFind() {
		System.out.println("Find not implemented.");
	}
	
	/**
	 * Method for moving item up.
	 *
	 * @status protected
	 */	
	protected void doMoveUp() {
		System.out.println("Move Up not implemented.");
	}
	
	/**
	 * Method for moving item down.
	 *
	 * @status protected
	 */	
	protected void doMoveDown() {
		System.out.println("Move Down not implemented.");
	}
	
	/**
     * @hidden
     * Notification to this component that it now has a parent component. When this method is
     * invoked, the chain of parent components is set up with KeyboardAction event listeners.
     *
     * @status hidden
     */
	public void addNotify() {
		super.addNotify();
		updateResources();
	}
     
  	class ButtonPanelActionListener implements ActionListener {
	   	public void actionPerformed(ActionEvent e) {
	 		Object src = e.getSource();
             
            if (Timer.ON) {
                Timer.getTimer().start(((JButton)src).getToolTipText());
            }
             	   		
			if (src == m_btnSort) {
	   			doSort();
	   		}
			else if (src == m_btnSave) {
				doSave();
	   		}
	   		else if (src == m_btnExpand) {
	   			doExpand();
	   		}
	   		else if (src == m_btnCollapse) {
	   			doCollapse();
	   		}
	   		else if (src == m_btnFind) {
	   			doFind();
	   		}
			else if (src == m_btnMoveUp) {
				doMoveUp();
			}
			else if (src == m_btnMoveDown) {
				doMoveDown();
			}
            
            if (Timer.ON) {
                Timer.getTimer().stop(((JButton)src).getToolTipText());
            }
	    }
	}
}