/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

/**
 * @hidden
 */
public interface ParamConstants {
   // parameter names for AppModule
   public static final String APPMODULE_VBHOST_PARAMNAME = "AppModuleVBHost";
   public static final String APPMODULE_MODE_PARAMNAME = "AppModuleMode";

   // parameter names for Olap
   public static final String OLAP_SERVER_PARAMNAME = "OlapServerName";
   public static final String OLAP_SERVER_TYPE_PARAMNAME = "OlapServerType";
   public static final String OLAP_DRIVER_TYPE_PARAMNAME = "OlapDriverType";
   public static final String OLAP_DATABASE_PARAMNAME = "OlapDatabaseName";
   public static final String OLAP_USER_PARAMNAME = "OlapUser";
   public static final String OLAP_PASSWORD_PARAMNAME = "OlapPassword";

   // parameter names for persistence
   public static final String PERSISTENCE_ALLOWED_PARAMNAME = "PersistenceAllowed";
   public static final String PERSISTENCE_SERVICE_PARAMNAME = "PersistenceService";
   public static final String PERSISTENCE_USER_PARAMNAME = "PersistenceUser";
   public static final String PERSISTENCE_PASSWORD_PARAMNAME = "PersistencePassword";
   public static final String PERSISTENCE_DRIVER_TYPE_PARAMNAME = "PersistenceDriverType";
   public static final String PERSISTENCE_BIBEAN_MODE_PARAMNAME = "PersistenceBIBeanMode";

   // initial path name for file based persistence
   public static final String PERSISTENCE_INITIALPATH_PARAMNAME = "InitialPathname";

   public static final String DEFAULT_QUERY_PARAMNAME = "DefaultQuery";

   // use Olap data source or local data source
   public static final String USE_OLAP_DATA_SOURCE_PARAMNAME = "UseOlapDataSource";

   // default parameter values
   public static final String APPMODULE_VBHOST_DEFAULT = "sojackso-sun";
   public static final String APPMODULE_MODE_DEFAULT = "LOCAL";

   public static final String OLAP_SERVER_DEFAULT = "bibbox1-sun:OLAPServer_sojackso";
   public static final String OLAP_SERVER_TYPE_DEFAULT = "OLAPServer";
   public static final String OLAP_DRIVER_TYPE_DEFAULT = "MDM";
   public static final String OLAP_DATABASE_DEFAULT = "xademo";
   public static final String OLAP_USER_DEFAULT = "xademo";
   public static final String OLAP_PASSWORD_DEFAULT = "xademo";

   public static final String PERSISTENCE_SERVICE_DEFAULT = "SONGO";
   public static final String PERSISTENCE_USER_DEFAULT = "REL2";
   public static final String PERSISTENCE_PASSWORD_DEFAULT = "REL2";
   public static final String PERSISTENCE_DRIVER_TYPE_DEFAULT = "PERSISTENCE";
   public static final String PERSISTENCE_BIBEAN_MODE_DEFAULT = "Thin";
   public static final String PERSISTENCE_THICK_BIBEAN_MODE = "Thick";

   public static final boolean PERSISTENCE_ALLOWED_DEFAULT = true;
   public static final boolean DEFAUL_QUERY_DEFAULT = true;

   public static final boolean USE_OLAP_DATA_SOURCE_DEFAULT = true;

   // hash table key for applet
   public static final String APPLET_KEY = "Applet";
}
