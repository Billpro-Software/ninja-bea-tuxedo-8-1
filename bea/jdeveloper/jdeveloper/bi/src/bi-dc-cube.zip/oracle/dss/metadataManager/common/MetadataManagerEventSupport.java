/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Vector;

/**
 * @hidden
 * Support class for firing MetadataManager events.  MetadataManager class can
 * instanciate this class and fire desired events.
 *
 * @status New
 */
 
/**
 * @hidden
 */
 
public class MetadataManagerEventSupport {

   private Vector listeners;
   private Object source;

  /**
   * Constructor
   *
   * @param sourceBean  The bean that instantiates this
   *                   <code>MetadataManagerEventSupport</code>.
   *
   * @status Reviewed
   */
  public MetadataManagerEventSupport( Object sourceBean ) {
    listeners = new Vector();
    source = sourceBean;
  }

  /**
   * Adds a listener to this <code>MetadataManagerEventSupport</code>.
   *
   * @param listener  The listener to add.
   *
   * @status New
   */
  public synchronized void addMetadataManagerListener( MetadataManagerListener listener ) {
    if( !listeners.contains( listener ) )
      listeners.addElement( listener );
  }

  /**
   * Removes a listener from this <code>MetadataManagerEventSupport</code>.
   *
   * @param listener  The listener to remove.
   *
   * @status Reviewed
   */
  public synchronized void removeMetadataManagerListener( MetadataManagerListener listener ) {
    if( listeners.contains( listener ) )
      listeners.removeElement( listener );
  }

  /**
   * Fired before connect is added to MetadataManager
   *
   * @param evt    Event object.
   *
   * @status New (This doesn't seem to be called by anybody 02/15/01)
   */
  public void fireAddingConnectionEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.addingConnection(event);
     }
  }

  /**
   * Fired after connect is added to MetadataManager
   *
   * @param evt    Event object.
   *
   * @status New (Nobody's calling this; 2/15/01)
   */
  public void fireConnectionAddedEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.connectionAdded(event);
     }
  }

  /**
   * Fired before connect is removed from MetadataManager
   *
   * @param evt    Event object.
   *
   * @return      <code>true</code> if event was consumed
   *              <code>false</code> if event was not consumed
   * @status New (Nobody's calling this KE 2/15/01)
   */
  public boolean fireRemovingConnectionEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.removingConnection(event);
       if( event.isConsumable() && event.isConsumed() )
          return true;
     }
     return false;
  }

  /**
   * Fired after connect is removed from MetadataManager
   *
   * @param evt    Event object.
   *
   * @status New (Nobody's calling this one either)
   */
  public void fireConnectionRemovedEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.connectionRemoved(event);
     }
  }

  /**
   * Fired before attached
   *
   * @param evt    Event object.
   *
   * @status New
   */
  public void fireAttachingEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.attaching(event);
     }
  }

  /**
   * Fired after attached
   *
   * @param evt    Event object.
   *
   * @status New
   */
  public void fireAttachedEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.attached(event);
     }
  }

  /**
   * Fired before detached
   *
   * @param evt    Event object.
   *
   * @return      <code>true</code> if event was consumed
   *              <code>false</code> if event was not consumed
   * @status New
   */
  public boolean fireDetachingEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.detaching(event);
       if( event.isConsumable() && event.isConsumed() )
          return true;
     }
     return false;
  }

  /**
   * Fired after detached
   *
   * @param evt    Event object.
   *
   * @status New
   */
  public void fireDetachedEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.detached(event);
     }
  }

  /**
   * Fired after Metadata is Modified
   *
   * @param evt    Event object.
   *
   * @status New
   */
  public void fireMetadataModifiedEvent( MetadataModifiedEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.metadataModified(event);
     }
  }

  /**
   * Fired when a UI needs to to refreshed
   *
   * @param evt    Event object.
   *
   * @status New
   */
  public void fireMetadataRefreshEvent( MetadataManagerEvent event ) {
     Vector tempLst;
     synchronized( source ){
       tempLst = (Vector) listeners.clone();
     }

     int listenersCount = tempLst.size();

     for( int i = 0; i < listenersCount; i++ ) {
       MetadataManagerListener listener = (MetadataManagerListener) tempLst.elementAt(i);
       listener.metadataRefresh(event);
     }
  }
}