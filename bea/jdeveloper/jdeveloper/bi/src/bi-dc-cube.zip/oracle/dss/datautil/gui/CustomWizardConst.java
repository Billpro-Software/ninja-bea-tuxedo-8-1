/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
**3456789012345678901234567890123456789012345678901234567890123456789012345678
*/

package oracle.dss.datautil.gui;

import java.awt.AWTEvent;

/**
 * @hidden
 *  Defines constants for the <code>CustomWizard</code> object.
 *
 * @status hidden
 */
public class CustomWizardConst
{
    //---------------------------------------------------------
    // PUBLIC MEMBERS
    //---------------------------------------------------------

    // Base ID for all wizard states.
    private static final int _CUSTOMWIZARD_STATE = AWTEvent.RESERVED_ID_MAX + 1;
    
    /**
     * Custom wizard state indicating that the Next button is pressed.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_NEXT = _CUSTOMWIZARD_STATE;
    
    /**
     * Custom wizard state indicating that the Previous button is pressed.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_PREVIOUS = _CUSTOMWIZARD_STATE + 1;

    /**
     * Custom wizard state indicating that the Apply button is pressed.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_APPLY = _CUSTOMWIZARD_STATE + 2;
    
    /**
     * Custom wizard state indicating that the Cancel button is pressed.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_CANCEL = _CUSTOMWIZARD_STATE + 3;
    
    /**
     * Custom wizard state indicating that the Finish button is pressed.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_FINISH = _CUSTOMWIZARD_STATE + 4;

    /**
     * Custom wizard state indicating that the page selection is changing in the
     * reentrant wizard.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_PAGECHANGING = _CUSTOMWIZARD_STATE + 5;

    /**
     * Invalid custom wizard state.
     * 
     * @status hidden
     */
    public static final int CUSTOMWIZARD_INVALIDSTATE = _CUSTOMWIZARD_STATE + 6;
    
    //---------------------------------------------------------
    // CONSTRUCTOR
    //---------------------------------------------------------

    /**
     * Constructor.
     *
     */

    public CustomWizardConst ( ) 
    {
    }
}