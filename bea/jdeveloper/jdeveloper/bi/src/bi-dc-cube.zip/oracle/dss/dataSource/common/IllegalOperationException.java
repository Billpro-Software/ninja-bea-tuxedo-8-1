/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.Operation;

/**
 * Thrown if a call to the Query API is found to be illegal for some reason.
 *
 * @status Documented
 */
public class IllegalOperationException extends QueryException
{
    /**
     * @hidden
     * @serial Illegal operation
     */
    protected Operation m_oper = null;
    
    /**
     * @hidden
     * Constructor.
     *
     * @param s         Message to display.
     * @param operation Operation that caused the exception.
     *
     * @status Documented
     */
    public IllegalOperationException(String s, Operation operation)
    {
        super(s, null);
        m_oper = operation;
    }

    /**
     * @hidden
     * Constructor.
     *
     * @param s         Message to display.
     * @param operation Operation that caused the exception.
     * @param e         Previous exception that may have been caught
     *
     * @status Documented
     */
    public IllegalOperationException(String s, Operation operation, Throwable e)
    {
        super(s, e);
        m_oper = operation;
    }

    /**
     * @hidden
     * Retrieves the Operation that caused the problem.
     *
     * @return The <code>Operation</code> object.
     *
     * @status Documented
     */
    public Operation getOperation()
    {
        return m_oper;
    }
    
    
    /**
     * Retrieves this exception's message.
     *
     * @return  The exception's message.
     */
    public String getMessage()
    {
        return super.getMessage() + ": Operation: " + m_oper;
    }    
}