/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Hashtable;
import oracle.dss.util.ErrorHandler;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;

/**
 * A client-side representation of a hierarchy in an analytic workspace.
 * An <code>MDHierarchy</code> provides, to a java client, information about
 * a hierarchy in the workspace.
 * <P>
 * An OLAP hierarchy is a logical structure that uses levels to organize data.
 * A hierarchy can be used to define data aggregation: for example, in a
 * Time dimension, a hierarchy might be used to aggregate data from the "Month"
 * level to the "Quarter" level to the "Year" level.
 * A hierarchy can also be used to define a navigational drill path, regardless
 * of whether the levels in the hierarchy represent aggregated totals.
 * <P>
 * As an <code>MDFolder</code>, an <code>MDHierarchy</code> can contain
 * other <code>MDObjects</code>.
 * <code>MDHierarchy</code> objects can contain <code>MDLevels</code>.
 *
 * @see MDLevel
 *
 * @status Reviewed
 */
public class MDHierarchy extends MDFolder {

    /**
     * @hidden
     * Constructor.
     * Application developers should never construct an <code>MDHierarchy</code>.
     * Hierarchies are actually defined in the analytic workspace on the
     * server.
     * You cannot use the MetadataManager to create hierarchies in the
     * workspace.
     * <P>
     * To find the <code>MDHierarchy</code> that you want, call the
     * <code>getHierarchy</code> method of the
     * <code>MetadataManagerServices</code> that you are using.
     *
     * @see MetadataManagerServices#getHierarchy
     *
     * @status hidden
     */
    public MDHierarchy() {
        setObjectType(MM.HIERARCHY);
    }

    /**
     *
     * @hidden
     *
     */
    public MDHierarchy( MetadataManagerServices mmServices,
                        String                  hierarchyName,
                        MDObject                parent,
                        Hashtable               env,
                        ErrorHandler            handler )
    {
        super( mmServices, hierarchyName, parent, env, handler );
        setObjectType(MM.HIERARCHY);
    }

  	/**
     * Retrieves the dimension for this hierarchy.
     *
     * @return The dimension that this hierarchy structures.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDDimension getDimension() throws MetadataManagerException {
		  return (MDDimension)super.getParent();
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setDimension(MDDimension dimension) {
		  return super.setParent(dimension);
  	}
  	
  	/**
     * Retrieves the levels in this hierarchy.
     *
     * @return The levels of this hierarchy.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDLevel[] getLevels() throws MetadataManagerException {
		  return MDLevel.getLevelArray(getChildren(MM.LEVEL));
  	}

    /**
     *
     * @hidden
     *
     */
  	public int setLevels(MDLevel[] levels) {
  		if ( (levels == null) || (levels.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<levels.length; i++) {
  			setChild(levels[i], MM.LEVEL);
  		}
		  return MDU.SUCCESS;
  	}
  
     /**
     *
     * @hidden
     *
     */
    public int setLevel( MDLevel level) {
      if (level == null)
        return MM.FAILURE;
      return setChild( level, MM.LEVEL );
    }
  
    /**
     * Retrieves the data type of this hierarchy.
     *
     * @return A constant that represents the datatype.
     *         Valid constants are listed in the See Also section.
     *
     * @see MM#BOOLEAN
     * @see MM#SHORT
     * @see MM#INTEGER
     * @see MM#LONG
     * @see MM#FLOAT
     * @see MM#DOUBLE
     * @see MM#STRING
     *
     * @status Reviewed
     */
  	public String getDataType() {
		  return getStrPropertyValue(MM.DATA_TYPE);
  	}
  
    /**
     *
     * @hidden
     *
     */
  	public int setDataType(String dataType) {
	    if ((dataType != MM.BOOLEAN) && (dataType != MM.SHORT) &&
	        (dataType != MM.INTEGER) && (dataType != MM.LONG) &&
	        (dataType != MM.FLOAT) && (dataType != MM.DOUBLE) &&
	        (dataType != MM.STRING)) {
	    	return (MDU.FAILURE);
		}
  		setStrPropertyValue(MM.DATA_TYPE, dataType, MDU.UI_ALL);
		return MDU.SUCCESS;
  	}

 	  /**
     * @hidden
     * Retrieves the ancestors relation for this hierarchy.
     *
     * @return The ancestors relation.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDMemberMetadata getAncestorsRelation() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.ANCESTORS_RELATION);
  	}

    /**
     *
     * @hidden
     *
     */
  	public int setAncestorsRelation(MDMemberMetadata ancestorsRelation) {
  		if (ancestorsRelation == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(ancestorsRelation, MM.ANCESTORS_RELATION);
  	}

  	/**
     * @hidden
     * Retrieves the level relation for this hierarchy.
     *
     * @return The level relation for this hierarchy.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDMemberMetadata getLevelRelation() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.LEVEL_RELATION);
  	}

    /**
     *
     * @hidden
     *
     */
  	public int setLevelRelation(MDMemberMetadata levelRelation) {
  		if (levelRelation == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(levelRelation, MM.LEVEL_RELATION);
  	}

  	/**
     * @hidden
     * Retrieves parent relation for this hierarchy.
     *
     * @return The parent relation for this hierarchy.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDMemberMetadata getParentRelation() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.PARENT_RELATION);
  	}

    /**
     *
     * @hidden
     *
     */
  	public int setParentRelation(MDMemberMetadata parentRelation) {
  		if (parentRelation == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(parentRelation, MM.PARENT_RELATION);
  	}

  	/**
     * @hidden
     * Retrieves the value level depth for this hierarchy.
     *
     * @return The value level depth.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDMemberMetadata getValueLevelDepth() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.VALUE_LEVEL_DEPTH);
  	}

    /**
     *
     * @hidden
     *
     */
  	public int setValueLevelDepth(MDMemberMetadata valueLevelDepth) {
  		if (valueLevelDepth == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(valueLevelDepth, MM.VALUE_LEVEL_DEPTH);
  	}
  	
    /**
     *
     * @hidden
     *
     */
  	public static MDHierarchy[] getHierarchyArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDHierarchy[] hierarchies = new MDHierarchy[objects.length];
		for (int i=0; i<objects.length; i++) {
			hierarchies[i] = (MDHierarchy)objects[i];
		}
		return hierarchies;		
	}
  
    /**
     *
     * @hidden
     *
     */
  	public static MDHierarchy[] getHierarchyArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDHierarchy[] hierarchies = new MDHierarchy[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			hierarchies[i] = (MDHierarchy)propertyBag[i];
		}
		return hierarchies;		
	}
}