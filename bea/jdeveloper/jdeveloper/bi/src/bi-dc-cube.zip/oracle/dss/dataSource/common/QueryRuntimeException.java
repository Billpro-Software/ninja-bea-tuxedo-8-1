/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.BIBaseRuntimeException;
import oracle.dss.util.BIException;

/**
 * Runtime exceptions thrown specifically by the Query client.
 *
 * @status Documented
 */
public class QueryRuntimeException extends BIBaseRuntimeException
{
    /**
     * @hidden
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public QueryRuntimeException(String s, Throwable e) {
        super(s, e);
    }    
    
    /**
     * @hidden
     */
    public QueryRuntimeException(BIException e)
    {
        this(((Throwable)e).getMessage(), (Throwable)e);
    }
}