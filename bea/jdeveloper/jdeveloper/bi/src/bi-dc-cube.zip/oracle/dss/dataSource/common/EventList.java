/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.Vector;
import java.text.MessageFormat;

import oracle.dss.util.DataAccess;

/**
 * @hidden
 * Self-firing event list class passed back from middle tier to client.
 * Each location can contain one event or an EventList of events.
 * @status New
 */
public class EventList extends Vector implements java.io.Serializable
{
    /**
     * Set the IDs of all events in this list that don't yet have one
     */
/*    public void setIDs(String id)
    {
        Enumeration events = events();
        Object next = null;
        QueryEvent event = null;
        while (events.hasMoreElements())
        {
            next = events.nextElement();
            if (next instanceof QueryEvent) {
                event = (QueryEvent)next;
                if (event.getID() == null)
                {
                    event.setID(id);
                }
            }
            else {
                // Must be a list                
                ((EventList)next).setIDs(id);
            }
            
        }
    }
*/
    /**
     * Merge given event list into this one.
     *
     * @param tomerge event list to merge
     * @status New
     */
    public void merge(EventList tomerge) {
        Enumeration events = tomerge.events();
        while (events.hasMoreElements()) {
            addElement(events.nextElement());
        }
    }
    
    /**
     * Fire all of these events to the given list of listeners.
     *
     * @param s Query container (if non-null)
     * @param consumeList optional list of consumed events for caller
     * @param subList if true, this is the processing of an event sublist so a consume means
     *        we should quit processing
     * @throws Throwable thrown if there is a problem initializing the cursor
     * @status New
     */
    public void fire(QueryManager s, Query query, Vector consumeList, boolean subList) throws Throwable {
        m_events = events();
        QueryEvent event;
        Method method;
        Object next;
        //Query query = null;
        
        while (m_events.hasMoreElements()) {
            next = m_events.nextElement();
            if (next instanceof QueryEvent) {
                event = (QueryEvent)next;
            }
            else {
                // Must be a list                
                Vector consList = new Vector();
                ((EventList)next).fire(s, query, consList, true);
                trackConsume(consumeList, consList);
                continue;
            }
            
            // Replace source if we have to
/*            if (s != null) {
                //query = s.getQuery(event.getID());
                event.setSource(query);
            }*/

            // Check if event is "mergeable"
            if (event instanceof MergeEvent) {
                // Are there any more events of this type left in the queue?
                Enumeration newEvents = getCurrentEnumeration();
                MergeEvent nextEvent = (MergeEvent)moreEvents(event, newEvents);
                if (nextEvent != null) {
                    // Yes: merge this event with the next one of the same type
                    nextEvent.merge((MergeEvent)event);
                    // Move on to next event in list: don't fire this one
                    continue;
                }
                // No: check if there is a parent event list to merge into
                if (parentList != null) {
                    newEvents = parentList.getCurrentEnumeration();
                    nextEvent = (MergeEvent)moreEvents(event, newEvents);
                    if (nextEvent != null) {
                        // Yes: merge this event with the next one of the same type
                        nextEvent.merge((MergeEvent)event);
                        // Move on to next event in list: don't fire this one
                        continue;
                    }
                }
            }

            // Must get a separate data access for each eligible event here
            //setCursor(event, query);
            ListenerLists l = query.getListenerList();
            
            // Call event on fullname for each listener            
            try {
                method = l.getClass().getMethod(createEventName(event), new Class[] {event.getClass()});
            }
            catch (NoSuchMethodException e) {
                if (event.getSource() instanceof Query) {
                    ((Query)event.getSource()).getErrorHandler().log("Internal error - could not find event firing method: " + createEventName(event), getClass().getName(), "fire");
                }
                continue;
            }
            try {
                method.invoke(l, new Object[] {event});
                if (trackConsume(consumeList, event)) {
                    // Consumed: if we're in a list, quit
                    if (subList) {
                        return;
                    }
                }
            }
            catch (InvocationTargetException ite) {
                throw ite.getTargetException();
            }
        }
        
        return;
    }

    /**
     * Return an event list enumerator.
     *
     * @return event list enumeration
     * @status New
     */
    public Enumeration events() {
    	return new EventListEnumerator(this);
    }
    
    /**
     * Return a clone of this event list.
     *
     * @return cloned event list
     * @status New
     */
    public Object clone() {
        EventList newlist = new EventList();
        // Copy the events
        Enumeration list = events();
        QueryEvent dse = null;
        try {
            while (list.hasMoreElements()) {
                dse = (QueryEvent)list.nextElement();
                newlist.addElement(dse.clone());
            }
        }
        catch (CloneNotSupportedException e) {
            if (dse.getSource() instanceof Query)
            {
                throw new QueryRuntimeException(MessageFormat.format(((Query)dse.getSource()).getResourceString("Could not copy event: "), new String[] {dse.getClass().getName()}), e);
            }
            else
            {
                throw new QueryRuntimeException("Could not copy event: " + dse, e);
            }
        }
        
        return newlist;
    }

    /**
     * @hidden
     * Allow a parent to be set
     */
    public void setParentList(EventList el) {
        parentList = el;
    }
    
    // Return next event of the same type and target as the argument, if found.  Otherwise, null.
    private QueryEvent moreEvents(QueryEvent event, Enumeration remainingEvents) {
        Object next;
        QueryEvent nextEvent;
        while (remainingEvents.hasMoreElements()) {
            next = remainingEvents.nextElement();
            if (next instanceof EventList) {
                // Must process recursively
                nextEvent = moreEvents(event, ((EventList)next).events());                                
            }
            else {
                nextEvent = (QueryEvent)next;
            }
            if (event.getClass().isInstance(nextEvent) /*&& event.getID() == nextEvent.getID()*/)
            {
                // Same class: return this event as the next one
                return nextEvent;
            }
        }
        
        return null;
    }
    
    Enumeration getCurrentEnumeration() {
        return (Enumeration)((EventListEnumerator)m_events).clone();
    }
        
    // Set source's cursor from event if appropriate
/*    private void setCursor(QueryEvent event, Query source) throws QueryException {
        if (event instanceof CursorCarryingEvent)
        {
            //DataAccess datest = ((CursorCarryingEvent)event).getDataAccess();
            //if (!(datest instanceof QueryDataAccess))
                //return;
            //QueryDataAccess da = (QueryDataAccess)datest;            
            DataAccess[] daarr = source.generateDataAccess(1);
            if (daarr != null && daarr.length > 0)
                ((CursorCarryingEvent)event).setDataAccess(daarr[0]);
/*            if (da != null)
            {
                cursor = da.getCubeCursor();
            }
            // added to re-construct m_changeSupport
            //if (cursor != null) {
                // Cursor should not be null
                //if (source instanceof Query) {
                    //da.getDataDirector().setQuery((Query)source);
//                    Query ds = (Query)source;
                    //ds.transferRemoteInt(cursor);
                        //ds.setCursor(cursor);
                //}
/*            }
            else
            {
                if (source instanceof Query)
                {
                    Query ds = (Query)source;
                    // No cursor: make sure that fact gets through
                    ds.setCursor(null);
                }
            }*/
            /*if (source instanceof QueryClient) {
                ((QueryClient)source).setCursor(cursor);
            }
        }
        //return cursor;
    }*/
 
    // Create the event name from the event class name
    private String createEventName(QueryEvent event) {
        String name;
        String fullname = event.getClass().getName();
        int endPos = fullname.lastIndexOf(".");            
        if (endPos > -1) {
            name = fullname.substring(endPos+1);
        }
        else {
            name = fullname;
        }    
        return "fire" + name;
    }
    
    // Track event consumption
    private boolean trackConsume(Vector consumeList, QueryEvent event) {
        if (consumeList != null) {
            if (event instanceof Consumable) {
                consumeList.addElement(new Boolean(event.isConsumed()));
                return event.isConsumed();
            }
            else {
                consumeList.addElement(new Boolean(false));
            }
        }
        return false;
    }    
    
    // Track event consumption based on a list of events: if any of the events
    // are consumed, mark one consumed event
    private boolean trackConsume(Vector consumeList, Vector checkList) {
        Enumeration eventsToCheck = checkList.elements();
        Boolean currValue;
        while (eventsToCheck.hasMoreElements()) {
            currValue = (Boolean)eventsToCheck.nextElement();
            if (currValue.booleanValue()) {
                // Must consume
                consumeList.addElement(new Boolean(true));     
                return true;
            }
        }
        consumeList.addElement(new Boolean(false));
        return false;
    }    
       
    /**
     * @serial Event List's parent (may be null)
     */
    EventList parentList = null;
    
    /**
     * @serial Overall running event enumeration
     */
    Enumeration m_events   = null;
    
    // Our own event enumerator that can be copied
    final class EventListEnumerator implements Enumeration {
        Vector vector;
        int count;

        EventListEnumerator(Vector v, int c) {
            vector = v;
            count = c;
        }
        
        EventListEnumerator(Vector v) {
	        vector = v;
	        count = 0;
        }

        public boolean hasMoreElements() {
    	    return count < vector.size();
        }

        public Object nextElement() {
	        synchronized (vector) {
	            if (count < vector.size()) {
		            return vector.elementAt(count++);
	            }
	        }
	        throw new java.util.NoSuchElementException("EventListEnumerator");
        }        
        
        public Object clone() {
            return new EventListEnumerator(vector, count);
        }
    }        
}
