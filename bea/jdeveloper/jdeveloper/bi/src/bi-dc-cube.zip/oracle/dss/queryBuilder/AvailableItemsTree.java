/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/AvailableItemsTree.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.dnd.DnDConstants;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import java.util.Hashtable;
import java.util.Vector;

import javax.naming.directory.DirContext;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.TreePath;

import oracle.dss.bicontext.BIContext;
import oracle.dss.datautil.QueryEditor;
import oracle.dss.datautil.QueryEditorException;
import oracle.dss.datautil.QueryEditorListener;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.provider.BIProvider;
import oracle.dss.datautil.provider.DataProvider;
import oracle.dss.datautil.provider.MetadataProvider;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataAccessAdapter;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataSource;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.StatusInfo;
import oracle.dss.util.Utility;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.tree.ComponentTreeNode;


/**
 * @hidden
 * 
 * <pre>
 * <code>DataFilterPanel</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   04/08/08 - 
 *    gkellam   09/11/07 - Tweak shuttle handling.
 *    gkellam   09/10/07 - Look into focus issues.
 *    bmoroze   03/15/07 - 
 * 
 */
public class AvailableItemsTree extends ItemsTree {

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public AvailableItemsTree (ComponentContext context) {
    super (context);
    new AvailableItemsTreeTransferHandler (this, DnDConstants.ACTION_COPY);
    setRootVisible (false);
    setShowsRootHandles (true);
 
    addFocusListener (new FocusAdapter() {
      public void focusGained (FocusEvent focusEvent) {
      
        Object objSource = focusEvent.getSource();
        if (objSource instanceof ItemsTree) {

          ItemsTree itemsTree = (ItemsTree) objSource;        
          if (itemsTree.getSelectionCount() == 0) {
          // nothing is selected, so move to the next component
              if (focusEvent.getOppositeComponent() instanceof JTextField) {
                transferFocusBackward();
              }
              else {
                transferFocus();
              }
          }
        }
      }

      public void focusLost (FocusEvent focusEvent) {
        /*
        Object objSource = focusEvent.getSource();
        if (objSource instanceof ItemsTree) {
   
          if (!(focusEvent.getOppositeComponent() instanceof JButton)) {           
            ((ItemsTree)objSource).setSelectionPath (null);
            ((ItemsTree)objSource).setSelectionPaths (null);
          }
        }
        */
      }
    });
  }

  /**
   * @hidden
   * 
   * @status hidden
   */

  public static void main (String[] args) {
    AvailableItemsTree tree = new AvailableItemsTree (null);
    QBUtils.makeFrame (tree);
  }

  /////////////////////
  //
  // Package Methods
  //
  /////////////////////

  ComponentTreeNode makeSampleRoot (final JTree tree) {
    FolderItemsTreeNode root = 
      new FolderItemsTreeNode (tree, new ComponentNode ("root"), null);

    ComponentContext context = new ComponentContext();
    setContext (context);

    BIProvider provider = new BIProvider();

    SampleQueryEditor queryEditor = new SampleQueryEditor();
    provider.setQueryEditor (queryEditor);
    context.setBIProvider (provider);

    SampleDataProvider dataProvider = new SampleDataProvider();
    context.setDataProvider (dataProvider);

    SampleMetadataProvider metadataProvider = new SampleMetadataProvider();
    context.setMetadataProvider (metadataProvider);

    root.add (new DatasourceItemsTreeNode (tree, 
      new ComponentNode ("Video Department Data"), context) {
        protected Vector getChildren (int intIndex, int intOffset) {
          Vector v = new Vector();
          v.addElement (new ItemsFolderItemsTreeNode (tree, 
            new ComponentNode ("Video Analysis Information"), getContext()) {
              
              protected Vector getChildren (int intIndex, int intOffset) {
                Vector v = new Vector();
                v.addElement (new ItemItemsTreeNode (tree, 
                  new ComponentNode ("Country Name", "Country Name"), getContext()));
                    return v;
              }
            });

          return v;
        }
      });

    root.add (new DatasourceItemsTreeNode (tree, new ComponentNode ("XADEMO"), context) {
      protected Vector getChildren (int intIndex, int intOffset) {
        Vector v = new Vector();
        v.addElement (new DimensionItemsTreeNode (tree, 
          new ComponentNode ("Geography", "MDM!Geography"), getContext()) {
            protected Vector getChildren (int intIndex, int intOffset) {
              Vector v = new Vector();
              v.addElement (new HierarchyItemsTreeNode (tree, 
                new ComponentNode ("Standard", "MDM!L0"), getContext()));
              return v;
            }
          });
        return v;
      }
    });

    return root;
  }

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  private class SampleDataProvider implements DataProvider {

    /////////////////////
    //
    // Members
    //
    /////////////////////
    private Hashtable m_dataAccesses = new Hashtable();

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public SampleDataProvider() {
      String[] data = { 
        "Argentina", "Australia", "Brazil", "Canada", "China", "Denmark", 
        "France", "Germany", "India", "Ireland", "Italy", "Japan", "Malaysia", 
        "New Zealand", "Poland", "Saudi Arabia", "Singapore", "South Africa", 
        "Spain", "The Netherlands", "Turkey", "United Kingdom", 
        "United States of America" 
        };
      
      m_dataAccesses.put ("Country Name", 
        new SampleDataAccess (makeMemberNodes (data, DataDirector.DRILLSTATE_NOT_DRILLABLE)));
      
      String[] data2 = { "Worldwide" };
      m_dataAccesses.put ("MDM!L0", new SampleDataAccess (
        makeMemberNodes (data2, DataDirector.DRILLSTATE_DRILLABLE)));
      
      String[] data3 = { "Americas" };
      m_dataAccesses.put ("Worldwide", new SampleDataAccess (
        makeMemberNodes (data3, DataDirector.DRILLSTATE_DRILLABLE)));
      
      String[] data4 = { "United States of America" };
      m_dataAccesses.put ("Americas", 
        new SampleDataAccess (makeMemberNodes (data4, DataDirector.DRILLSTATE_DRILLABLE)));

      String[] data5 = { 
        "Boston, MA", "Chicago, IL", "Dallas, TX", "Denver, CO", 
        "Los Angeles, CA", "New York, NY", "Seattle, WA" 
        };
      
      m_dataAccesses.put ("United States of America", 
        new SampleDataAccess (makeMemberNodes (data5, DataDirector.DRILLSTATE_NOT_DRILLABLE)));
      
      DataFilter filter = new DataFilter();
      String[] strCmpValues = { 
        "Argentina", "Canada", "China", "Denmark", "France" 
        };
      
      Vector cmpValues = Utility.copyArrayToVector (strCmpValues);
      filter.setCmpValues (cmpValues);
      
      QBUtils.addDataFilter (filter, getContext());
    }

    public Vector getMembers (String item, String labelType)
      throws QueryEditorException {
      return null;
    }

      // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess (Selection selection) throws QueryEditorException {
      if (selection != null) {
        Step step = selection.getStep (0);
        Vector ids = null;
        
        if (step instanceof AllStep) {
          ids = ((AllStep)step).getLevels();
        }
        else if (step instanceof BasicFamilyStep) {
          ids = ((BasicFamilyStep)step).getFamilyValues();
        }
        
        if ((ids != null) && (!(ids.isEmpty()))) {
          Object o = ids.firstElement();
          
          if (o != null) {
            return getDataAccess (o.toString());
          }
        }
      }

      return null;
    }
*/
    public DataAccess getDataAccess (String strItemId) throws QueryEditorException {
      if (m_dataAccesses != null) {
        Object o = m_dataAccesses.get (strItemId);
       
        if (o instanceof DataAccess) {
          return (DataAccess)o;
        }
      }

      return null;
    }

    /**
     * Retrieves the <code>DataAccess</code> object for a specified item (LOV query) 
     * and optional set of data filters.
     * 
     * @param strItemID A <code>String</code> representing the item or dimension ID
     *        to return members for.
     * @param dataFilters A <code>BaseDataFilter[]</code> which specifies data filters 
     *        to use in the LOV query.
     * @return A <code>DataAccess</code>.
     *
     * @status Documented
     */
    public DataAccess getDataAccess (String strItemID, BaseDataFilter[] dataFilters) {
      return null;
    }
    
    /**
     * Retrieves a <code>DataAccess</code> object that contains dimension
     * member metadata positioned at the stored selection for the specified
     * item.
     * 
     * @param strItemID A <code>String</code> representing the item or dimension ID
     *        to return members for.
     * @param nInstance A <code>int</code> which represents the caller-defined ID 
     *        that determines which item DataAccess to get.
     * 
     * @return A <code>DataAccess</code> object that contains the specified
     *         item; an empty <code>DataAccess</code> object, which
     *         contains zero values, if there is no selection available to
     *         evaluate.
     *
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
    public DataAccess getDataAccess (String strItemID, int nInstance) throws QueryEditorException {
      return null;
    }

    private MemberNode[] makeMemberNodes (String[] data, int intDrillState) {
      if (data != null) {
        MemberNode[] nodes = new MemberNode[data.length];
        for (int i = 0; i < data.length; i++) {
          nodes[i] = new MemberNode (data[i], intDrillState);
        }
        return nodes;
      }
      return null;
    }
  }

  private class SampleDataAccess extends DataAccessAdapter {

    /////////////////////
    //
    // Members
    //
    /////////////////////
    private MemberNode[] m_data = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public SampleDataAccess (MemberNode[] data) {
      m_data = data;
    }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public int getMemberSiblingCount (int edge, int[] hPos, int memberLayer)
      throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException {
      
      if (m_data != null) {
        return m_data.length;
      }

      return 0;
    }

    public Object getMemberMetadata (int edge, int[] hPos, int memberLayer, 
                                    int hIndex, String type)
      throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException {
      
      if (m_data != null) {
        if (MetadataMap.METADATA_VALUE.equals (type)) {
          Object o = m_data[hIndex];
          if (o instanceof MemberNode) {
            return ((MemberNode)o).getLabel();
          }
        }
        else if (MetadataMap.METADATA_DRILLSTATE.equals (type)) {
          Object o = m_data[hIndex];
      
          if (o instanceof MemberNode) {
            return new Integer (((MemberNode)o).getDrillState());
          }
        }
      }
      
      return null;
    }
  }

  private class SampleMetadataProvider implements MetadataProvider {

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public Vector getDatasources() {
      return null;
    }

    public Object getObjectByUniqueId (String strUniqueId) {
      if ("MDM!L0".equals (strUniqueId)) {
        MDDimension mdDimension = new MDDimension();
        mdDimension.setUniqueID (MM.MDM, "MDM!Geography");
        mdDimension.setDriverType (MM.MDM);
        MDHierarchy mdHierarchy = new MDHierarchy();
        MDLevel mdLevel;

        for (int i = 0; i < 4; i++) {
          mdLevel = new MDLevel();
          mdLevel.setUniqueID (MM.MDM, "L" + Integer.toString (i));
          mdLevel.setDriverType (MM.MDM);
          mdHierarchy.setLevel (mdLevel);
        }

        mdHierarchy.setDimension (mdDimension);
        return mdHierarchy;
      }

      return null;
    }

    public DirContext getRoot() {
      return null;
    }

    public Object getDimensionByUniqueId (String strUniqueId) {
      return null;
    }

    public Vector getItemIds (boolean data, boolean nondata) {
      return null;
    }

    public Vector getItemObjects (boolean data, boolean nondata) {
      return null;
    }

    public MDFolder getCurrentDatasourceRootFolder() {
      return null;
    }

    public void setCurrentDatasourceRootFolder (MDFolder mdFolder) {
    }

    public BIContext getCurrentRuntimeDatasourceRootFolder() {
      return null;
    }

    public void setCurrentRuntimeDatasourceRootFolder (BIContext folder) {
    }

    public void setCurrentRuntimeDatasourceRootFolderByName (String strDataSourceName)
      throws Exception {
    }

    public MDFolder getBICatalogRootFolder() {
      return null;
    }

    public String getHierarchy (String dimension) {
      return null;
    }

    public MDFolder getFunctionsRootFolder() {
      return null;
    }

    public void setFunctionsRootFolder (MDFolder folder) {
    }
  }

  private class SampleQueryEditor implements QueryEditor {

    /////////////////////
    //
    // Members
    //
    /////////////////////

    private Vector m_dataFilters = new Vector();
    
    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public void addQueryEditorListener (QueryEditorListener l) {
    }

    public void removeQueryEditorListener (QueryEditorListener l) {
    }

    public boolean collapse (String item, int instance) throws QueryEditorException {
      return false;
    }

    public boolean expand (String item, int instance) throws QueryEditorException {
      return false;
    }

    public void setDataFilters (BaseDataFilter[] filters, int i)
      throws QueryEditorException {
    }

    public BaseDataFilter[] getDataFilters (int i) {
      BaseDataFilter[] dataFilters = new BaseDataFilter[m_dataFilters.size()];
      m_dataFilters.copyInto (dataFilters);
      return dataFilters;
    }

    public void addDataFilter (BaseDataFilter filter, int i)
      throws QueryEditorException {
      m_dataFilters.addElement (filter);
    }

    public boolean isDataFilterSet (int i) {
      return false;
    }

    public void removeDataFilter (BaseDataFilter filter, int i)
      throws QueryEditorException {
    }

    public boolean drill (String item, int instance, String value, int delta, 
                         boolean optimize)
      throws QueryEditorException {
      return false;
    }

    public DataAccess getDataAccess (String s, BaseDataFilter[] dataFilters) {
      return null;
    }

      // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess (Selection selection, MetadataMap map)
      throws QueryEditorException {
      return null;
    }

    public DataAccess getDataAccess (Selection selection) {
      return null;
    }*/

    public DataAccess getDataAccess (String item, int instance)
      throws QueryEditorException {
      return null;
    }

    public DataDirector getDataDirector (String item, int instance)
      throws QueryEditorException {
      return null;
    }

      // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection (String item)
      throws QueryEditorException {
      return null;
    }*/

    public Vector getValues (String item, int instance, String hierarchy, 
                             String type, int max)
      throws QueryEditorException {
      return null;
    }

    public Vector getValues (String item, int instance, String hierarchy, 
                             String[] type, int max)
      throws QueryEditorException {
      return null;
    }

      // blm - Selection code moved to dvt-olap
/*    public Selection getSelection (String item, int instance)
      throws QueryEditorException {
      return null;
    }

    public void setSelection (Selection sel, int instance)
      throws QueryEditorException {
    }*/

    public boolean isSelectionSet (String item, int instance)
      throws QueryEditorException {
      return false;
    }

    public void hideItems (String[] items, boolean hide)
      throws QueryEditorException {
    }

    public Object isSupported (int capability, Object data)
      throws QueryEditorException {
      return null;
    }

    public Object isValid (String validity, Object data)
      throws QueryEditorException {
      return null;
    }

    public String getMeasureItem (String type)
      throws QueryEditorException {
      return null;
    }

    public OlapQDR getQDR (String dataItem, String type, int instance)
      throws QueryEditorException {
      return null;
    }

    public void setMetadataMap (MetadataMap map) {
    }

    public StatusInfo fireEvents()
      throws QueryEditorException {
      return null;
    }

    public StatusInfo getStatus()
      throws QueryEditorException {
      return null;
    }

    public StatusInfo startExecution()
      throws QueryEditorException {
      return null;
    }

    public void cancel()
      throws QueryEditorException {
    }

    public Object getProperty (String name)
      throws QueryEditorException, 
             oracle.dss.util.xml.NoSuchPropertyException {
      return null;
    }

    public void setProperty (String name, Object value)
      throws QueryEditorException {
    }

    // LayoutAccess2 methods

    public int getItemEdge (String item) {
      return -1;
    }

    public int getItemLayer (String item, int edge) {
      return -1;
    }

    public void setItems (String[] dataItems, String[] items)
      throws Exception {
    }

    public String[] getItems (String type) {
      return null;
    }

    public String[] getDataItems (String type) {
      return null;
    }

    public int getMaxEdge() {
      return -1;
    }

    public String[][] getLayout () {
      return null;
    }

    public void resetItems (String[] dataItems, String[] items)
      throws Exception {
    }

    // LayoutAccess methods

    public void setCursorEvaluation (boolean on) {
    }

    public DataSource getDataSource() {
      return null;
    }

    public void setMeasures (String[] measures) {
    }

    public String[] getMeasures (String type) {
      return null;
    }

    public int getMeasureEdge() {
      return -1;
    }

    public int getMeasureLayer() {
      return -1;
    }

    public boolean isSpecialDimension (int edge, int layer, String type)
      throws EdgeOutOfRangeException, LayerOutOfRangeException {
      return false;
    }

    public void setLayout (String[][] layout) {
    }

    public void release() {
    }
  }

  private class MemberNode {
    
    /////////////////////
    //
    // Members
    //
    /////////////////////

    private String m_strLabel = null;
    private int m_intDrillState = DataDirector.DRILLSTATE_DRILLABLE;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public MemberNode (String strLabel, int intDrillState) {
      setLabel (strLabel);
      setDrillState (intDrillState);
    }

    /////////////////////
    //
    // Private Methods
    //
    /////////////////////

    private void setLabel (String strLabel) {
      m_strLabel = strLabel;
    }

    private String getLabel() {
      return m_strLabel;
    }

    private void setDrillState (int intDrillState) {
      m_intDrillState = intDrillState;
    }

    private int getDrillState() {
      return m_intDrillState;
    }
  }
}
