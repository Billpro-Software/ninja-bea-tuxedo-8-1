/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;


/**
 * Superclass for exceptions that are thrown because of errors that occur while
 * retrieving metadata from the database.
 *
 * @status Documented
 */
public class InvalidMetadataException extends QueryException
{
    /**
     * @hidden
     * @serial Invalid object names
     */
    protected String[] m_objects = null;
    
    /**
     * @hidden
     * @serial Invalid step, if metadata error came from evaluation of a step
     */
     // blm - Selection code moved to dvt-olap
/*    protected Step m_step = null;*/
    
    /**
     * @hidden
     * @serial Invalid dimension related to the invalid metadata, if appropriate
     */
    protected String m_dimension = null;
    
    /**
     * @hidden
     * @serial Invalid hierarchy related to the invalid metadata, if appropriate
     */
    protected String m_hierarchy = null;
    
    /**    
     * Constructor for a single error while getting metadata.
     *
     * @param s      Message to display.
     * @param object Name of invalid object.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMetadataException(String s, String object, Throwable e)
    {
        super(s, e);
        m_objects = new String[] {object};
    }
    
    /**
     * Constructor for a single error while getting metadata, with extra information.
     * @param s      Message to display.
     * @param object Name of invalid object.
     * @param dimension Optional dimension ID associated with invalid metadata
     * @param step   Optional Step containing invalid metadata
     * @param hierarchy Optional hierarchy ID associated with invalid metadata
     * @param e      Previous exception to carry (may be null).
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public InvalidMetadataException(String s, String object, String dimension, Step step, String hierarchy, Throwable e)
    {
        this(s, new String[] {object}, dimension, step, hierarchy, e);
    }*/
    
    /**    
     * Constructor for multiple errors while getting metadata, with extra information.
     *
     * @param s      Message to display.
     * @param object Names of invalid objects.
     * @param dimension Optional dimension ID associated with invalid metadata
     * @param step   Optional Step containing invalid metadata
     * @param hierarchy Optional hierarchy ID associated with invalid metadata
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public InvalidMetadataException(String s, String[] object, String dimension, Step step, String hierarchy, Throwable e)
    {
        super(s, e);
        m_objects = object;
        m_step = step;
        m_dimension = dimension;
        m_hierarchy = hierarchy;
    }    */
    
    /**    
     * Constructor for multiple errors while getting metadata.
     *
     * @param s      Message to display.
     * @param object Names of invalid objects.
     * @param e      Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMetadataException(String s, String[] object, Throwable e)
    {
        super(s, e);
        m_objects = object;
    }    
    
    /**
     * Retrieves the objects.
     *
     * @return  The list of objects.
     *
     * @status Documented
     */
    public String[] getObjects()
    {
        return m_objects;
    }
    
    /**
     * Indicates whether there are multiple invalid objects or a single invalid
     * object.
     *
     * @return <code>true</code> if one object; <code>false</code> if more than
     *         one invalid object.
     *
     * @status Documented
     */
    public boolean isMultipleObjects()
    {
        return m_objects != null && m_objects.length > 1;
    }        
    
    /**
     * Returns the <code>Step</code> associated with the invalid metadata, if any.
     * 
     * @return <code>Step</code> containing the invalid metadata reference, or <code>null</code>
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Step getStep()
    {
        return m_step;
    }*/
    
    /**
     * Returns the dimension associated with the invalid metadata, if no step is available and
     * the metadata itself isn't a dimension or measure.
     * 
     * @return dimension ID
     * @status New
     */
    public String getDimension()
    {
        return m_dimension;
    }
    
    /**
     * Returns the hierarchy associated with the invalid metadata, if no step is available and
     * the metadata itself isn't a hierarchy, dimension, or measure.
     * 
     * @return dimension ID
     * @status New
     */
    public String getHierarchy()
    {
        return m_hierarchy;
    }
}