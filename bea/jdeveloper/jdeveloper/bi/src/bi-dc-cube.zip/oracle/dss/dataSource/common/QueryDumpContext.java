package oracle.dss.dataSource.common;
/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

import java.util.Iterator;
import java.util.List;

import java.io.PrintWriter;


import oracle.dss.util.DumpContext;

import oracle.dss.util.MetadataPrinter;

/**
 *
 * Class to provide a text dump of query contents and cursors.
 *
 * @status New
 */
public class QueryDumpContext extends DumpContext
{
    
    /**
     * Dump the query state (Selections, measures)
     *
     * @param pw PrintWriter to dump to
     * @param query Query to dump
     *
     * @status New
     */
    public static void dumpQueryState(PrintWriter pw, Query query) throws CloneException
    {
        QueryState qs = null;
        qs = query.getQueryState();
        
        if (qs == null)
        {
            return;
        }
        
        pw.println("Measures:");
        String[] measures = qs.getMeasures();
        if (measures != null)
        {
            for (int m = 0; m < measures.length; m++)
            {
                pw.println(measures[m]);                
            }
        }
        
        pw.println("Dimension layout:");
        DimTree dims = qs.getDimTree();
        if (dims != null)
        {
            pw.println(dims.toString());
        }
        
        // blm - Selection code moved to dvt-olap
/*        pw.println("Selections:");
        List sels = qs.getSelections();
        if (sels != null)
        {
            Iterator iter = sels.iterator();
            while (iter.hasNext())
            {
                pw.println(iter.next().toString());
            }
        }*/

    }
    
    /**
     * @hidden
     * Dump the query state (Selections, measures)
     *
     * @param pw PrintWriter to dump to
     * @param query Query to dump
     * @param mp MetadataPrinter to use
     */
    public static void dumpQueryState(PrintWriter pw, Query query, MetadataPrinter mp) throws CloneException
    {
        QueryState qs = null;
        qs = query.getQueryState();
        
        if (qs == null)
        {
            return;
        }
        
        pw.println("Measures:");
        String[] measures = qs.getMeasures();
        if (measures != null)
        {
            for (int m = 0; m < measures.length; m++)
            {
                pw.println(mp.getMetadataName(measures[m], mp.getMeasureType()));                
            }
        }
        
        pw.println("Dimension layout:");
        if (qs.getDimTree() != null)
        {
            DimTree dims = null;
            try
            {
                dims = (DimTree)qs.getDimTree().clone();            
            }
            catch (CloneNotSupportedException e)
            {
                throw new CloneException(e.getMessage(), e);
            }
            dims.setMetadataPrinter(mp);
            pw.println(dims.toString());
        }
        
        // blm - Selection code moved to dvt-olap
/*        pw.println("Selections:");
        List sels = qs.getSelections();
        if (sels != null)
        {
            try
            {
                Iterator iter = sels.iterator();
                while (iter.hasNext())
                {
                    Selection sel = (Selection)((Selection)iter.next()).clone();
                    sel.setMetadataPrinter(mp);
                    pw.println(sel.toString());
                }
            }
            catch (CloneNotSupportedException e)
            {
                pw.print(e.getMessage());
            }
        }*/

    }    
}