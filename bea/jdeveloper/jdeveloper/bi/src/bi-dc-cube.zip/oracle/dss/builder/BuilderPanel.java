/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/BuilderPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
 
package oracle.dss.builder;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

import javax.swing.JPanel;

import oracle.bali.ewt.wizard.BaseWizard;

import oracle.bali.ewt.wizard.WizardEvent;
import oracle.bali.ewt.wizard.WizardListener;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.gui.ExceptionListenerGui;
import oracle.dss.datautil.gui.Utils;

import oracle.dss.util.gui.ResourceHandler;
import oracle.dss.util.help.HelpContext;

/**
 * <pre>
 * BuilderPanel used by <code>Builder</code>s, including <code>CalcBuilder</code>
 * and <code>QueryBuilder</code>.
 * </pre>
 *
 * @author rbalexan 
 * @since  11.0.0.0.5
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 *    gkellam   11/02/05 - Add Exception processing. 
 *    gkellam   10/17/05 - Additional custom expression integration. 
 *    gkellam   10/12/05 - Update name save panel. 
 * 
 */
public class BuilderPanel extends JPanel implements HelpContext, WizardListener {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Debug flag.
   * 
   * Note: Turn off for the final release build
   *
   * @status private
   */
  static private final boolean DEBUG = true;

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * @hidden
   * 
   * <code>BuilderContext</code> associated with the <code>BuilderPanel</code>.
   *
   * @status hidden
   */
  private BuilderContext m_builderContext = null;
  
  /**
   * @hidden
   * 
   * Determines whether a <code>BuilderPanel</code> is dirty or not.
   * 
   * @status hidden
   */
  private boolean m_bIsDirty = true;

  /**
   * @hidden
   * 
   * Help context ID associated with the <code>BuilderPanel</code>.
   * 
   * @status hidden
   */
  private String m_strHelpContextID = null;
    
  /**
   * @hidden
   * 
   * The resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @status hidden
   */ 
  protected String m_strBundleClass = null;

  /**
   * Determines whether the panel is active. 
   *
   * @status hidden
   */
  protected boolean m_bActive = false;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  /** 
   * Default <code>BuilderPanel</code> constructor.
   * 
   * @status new
   */
  public BuilderPanel() {
    super();
    //init();
  }
    
  /** 
   * <code>BuilderPanel</code> constructor.
   * 
   * @param layoutManager A <code>LayoutManager</code> used to manage panel
   *        layout.
   * 
   * @status new
   */
  public BuilderPanel (LayoutManager layoutManager) {
    super (layoutManager);
    //init();
  }

  /** 
   * <code>BuilderPanel</code> constructor.
   * 
   * @param builderContext A <code>BuilderContext</code> containing useful
   *        builder properties.
   * 
   * @status new
   */
  public BuilderPanel (BuilderContext builderContext) {
    this();
    setContext (builderContext);

    if (builderContext != null) {
      if (builderContext.getBuilder() != null) {
        builderContext.getBuilder().getWizard().addWizardListener (this);
      }
    }
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
    
  /**
   * This method is called when it is necessary to synchronize the panel
   * User Interface (UI) and its associated content. 
   *
   * @param bUpdateUI A <code>boolean</code> value that is <code>true</code> 
   *        when the panel needs to updated based on its content and 
   *        <code>false</code> when the content needs to be updated based on 
   *        panel.
   *
   * @return A <code>boolean</code> value that is <code>true</code> when the
   *         method succeeds and <code>false</code> otherwise.
   *
   * @status new
   */
  public boolean updateData (boolean bUpdateUI) {
    return true;
  }

  /** 
   * Retrieves the size used by the <code>BuilderPanel</code>.
   * 
   * @return A <code>Dimension</code> which represents the <code>BuilderPanel</code>
   *         size.
   * 
   * @status new
   */
  public Dimension getSize () {
    Dimension dimensionSize = 
      (getContext() != null) ? Utils.getDimension(getContext().getSize()) : null;
    
    if (dimensionSize == null) {
      dimensionSize = getPreferredSize ();
    }

    return dimensionSize;
  }
  
  /** 
   * Specifies the <code>BuilderContext</code>.
   * 
   * @param builderContext A <code>BuilderContext</code> containing useful
   *        builder properties.
   * 
   * @status new
   */
  public void setContext (BuilderContext builderContext) {
    m_builderContext = builderContext;
  }
    
  /** 
   * Retrieves the <code>BuilderContext</code>.
   * 
   * @return <code>BuilderContext</code> containing useful builder properties.
   * 
   * @status new
   */
  public BuilderContext getContext() {
    return m_builderContext;
  }
    
  /*
   * @hidden
   */
  /*
  public void addNotify() {
    super.addNotify();
    System.out.println("addNotify...");
    if (m_blnDirty) {
    //if (true) {
        m_blnDirty = false;
        // Set the context.
        BaseWizard wizard = getWizard(this);
        if (wizard != null) {
            Object o = wizard.getClientProperty(Builder.CONTEXT);
            if ( (o != null) && (o instanceof BuilderContext) ) {
                setContext((BuilderContext)o);
            }
        }
        // Initialize panel.
        initialize();
    }    
  }
  */
    
  /**
   * Specifies whether a <code>BuilderPanel</code> is dirty or not.
   * 
   * @param bIsDirty A <code>boolean</code> which is <code>true</code> when the 
   *         <code>BuilderPanel</code> is dirty and <code>false</code> otherwise.
   * 
   * @status new
   */
  public void setDirty (boolean bIsDirty) {
    m_bIsDirty = bIsDirty;
  }
  
  /**
   * Determines whether a <code>BuilderPanel</code> is dirty or not.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the 
   *         <code>BuilderPanel</code> is dirty and <code>false</code> otherwise.
   * 
   * @status new
   */
  public boolean isDirty() {
    return m_bIsDirty;
  }
    
  /**
   * Specifies the help context ID.
   * 
   * @param strHelpContextID A <code>String</code> representing the help context ID.
   * 
   * @status new
   */
  public void setHelpContextID (String strHelpContextID) {
    m_strHelpContextID = strHelpContextID;
  }
    
  /**
   * Retrieves the help context ID.
   * 
   * @return <code>String</code> representing the help context ID.
   * 
   * @status new
   */
  public String getHelpContextID() {
    if (m_strHelpContextID != null) {
      return m_strHelpContextID;
    }

    return this.getClass().getName();
  }
  
  /**
   * Initialize the <code>BuilderPanel</code>.
   * 
   * @status new
   */
  public void initialize() { 
  }
    
  /**
   * Retrieves the <code>String</code> resource associated with the specified
   * key.  If the specified key cannot be found, the key itself is returned.
   *
   * @return <code>String</code> representing the <code>String</code> resource 
   *         associated with the specified key.
   *
   * @status new
   */ 
  public String getResourceString (String strKey) {
    ResourceHandler resourceHandler = 
      (getContext() != null) ? getContext().getResourceHandler() : null;
   
    return (resourceHandler != null) ? 
      resourceHandler.getResourceString (getResourceBundleClass(), strKey) : strKey;
  }

  /**
   * Specifies the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @param strBundleClass A <code>String</code> representing the resource
   *        bundle class.
   *
   * @status new
   */ 
  public void setResourceBundleClass (String strBundleClass) {
    m_strBundleClass = strBundleClass;
  }

  /**
   * Retrieves the resource bundle class used by the <code>BuilderPanel</code> 
   * to retrieve resources.
   *
   * @return <code>String</code> representing the resource bundle class.
   *
   * @status new
   */ 
  public String getResourceBundleClass () {
    return m_strBundleClass;
  }

  /**
   * Processes the specified <code>Throwable</code> by invoking a
   * <code>ErrorHandler</code> if appropriate.
   *
   * @param throwable The <code>Throwable</code> to process.
   *
   * @return <code>int</code> which represents the dialog option chosen by the
   *         user.
   *
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#CANCEL_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#CLOSED_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#NO_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#NONE_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#OK_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#YES_OPTION
   *
   * @status protected
   */
  public int processException (Throwable throwable) {

   // Assume that we don't have a ExceptionListenerGui
   int nExceptionListenerResult = ExceptionListenerGui.NONE_OPTION;

    // Retrieve the ExceptionListener
    ExceptionListener exceptionListener = getExceptionListener();

    // Process Exception through ExceptionListenerErrorHandler
    if (exceptionListener != null) {

      // Process the error through the ErrorHandler
      nExceptionListenerResult =
        exceptionListener.processException (throwable, 
          "DefaultCalcStepView", "processException");
    }

    return nExceptionListenerResult;
  }

  /**
   * Retrieves the <code>ExceptionListener</code> associated with the underlying
   * <code>BuilderContext</code>, if any.
   *
   * @return <code>ExceptionListener</code> associated with the underlying
   *         <code>BuilderContext</code>.
   *
   * @status new
   */
  public ExceptionListener getExceptionListener() {
    ExceptionListener exceptionListener = null;

    BuilderContext builderContext = getContext();

    if (builderContext != null) {
      exceptionListener = builderContext.getExceptionListener();
    }

    return exceptionListener;
  }

  //.........................................................
  // Start - Implementation of WizardListener interface
  //.........................................................

  /**
   * <pre>
   * Invoked when the selection has been changed.  
   *
   * The <code>WizardEvent.SELECTION_CHANGED</code> event is currently used
   * to for updateData(boolean) callbacks.
   * 
   * </pre>
   * 
   * @param wizardEvent A <code>WizardEvent</code> to process.
   * 
   * @status new
   */
  public void wizardSelectionChanged (WizardEvent wizardEvent) { 
    switch (wizardEvent.getID()) {
      case WizardEvent.SELECTION_CHANGED:
        // Determin whether panel was selected
        boolean bSelected = wizardEvent.getPage().getLabel().equals (getName());
        
        // Determine whether panel was active
        boolean bWasActive = isActive();
        
        // Update the active state based on the current state
        if (bSelected) {
          setActive (true);            
        }
        else {
          setActive (false);
        }
        
        // Only issue updateData callbacks when going to/from the named page
        if (bSelected || bWasActive) {
          updateData (bSelected);
        }
        break;
      
      case WizardEvent.VALIDATE_PAGE:
      case WizardEvent.APPLY_STATE:
      case WizardEvent.CANCELED:
      case WizardEvent.FINISHED:
        break;
    }
  }         
    
  /**
   * Invoked when the user wishes to see the current state of the
   * wizard applied.
   *
   * @param wizardEvent A <code>WizardEvent</code> to process.
   * 
   * @status new
   */
  public void wizardApplyState (WizardEvent wizardEvent) { 
  }

  /**
   * Invoked when the user has canceled the wizard.
   * 
   * @param wizardEvent A <code>WizardEvent</code> to process.
   * 
   * @status new
   */
  public void wizardCanceled (WizardEvent wizardEvent) { 
  }

  /**
   * Invoked when the user has finished the wizard.
   * 
   * @param wizardEvent A <code>WizardEvent</code> to process.
   * 
   * @status new
   */
  public void wizardFinished (WizardEvent wizardEvent) { 
  }

  //.........................................................
  // End - Implementation of WizardListener interface
  //.........................................................

  /**
   * Allow this instance to remove resources and any listeners it has added.
   *
   * @status new
   */
  public void cleanUp () { 
  
    BuilderContext builderContext = getContext();
    if (builderContext != null) {
      if (builderContext.getBuilder() != null) {
        builderContext.getBuilder().getWizard().removeWizardListener (this);
      }
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Specifies whether the panel is active. 
   *
   * @param bActive A <code>boolean</code> value that is <code>true</code> 
   *        when the panel is active and <code>false</code> otherwise.
   *
   * @status new
   */
  protected void setActive (boolean bActive) {
    m_bActive = bActive;
  }

  /**
   * Specifies whether the panel is active. 
   *
   * @return A <code>boolean</code> value that is <code>true</code> when the
   *         panel is active and <code>false</code> otherwise.
   *
   * @status new
   */
  protected boolean isActive () {
    return m_bActive;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * @hidden
   * Retrieves the <code>BaseWizard</code> associated with the <code>Component</code>,
   *
   * @param component A <code>Component</code> to retrieve <code>BaseWizard</code> 
   *        for.
   *        
   * @status hidden
   */
  private BaseWizard getWizard (Component component) {
    if (component != null) {
      if (component instanceof BaseWizard) {
        return (BaseWizard)component;
      }
      else if (component instanceof Container) {
        return getWizard (((Container)component).getParent());
      }
    }
    
    return null;
  }

  /*
  private Vector getAllComponents(Component c, Vector v) {
      if (c != null) {
          if (v == null) {
              v = new Vector();
          }
          if (c instanceof Component) {
              v.add(c);
          }
          else if (c instanceof Container) {
              Component[] cs = ((Container)c).getComponents();
              if (cs != null) {
                  for (int i=0; i<cs.length; i++) {
                      getAllComponents(cs[i], v);
                  }
              }
          }
      }
      return v;
  }
  */

  /*
  private void setEnabled(Component c, boolean blnEnabled) {
      if (c != null) {
          if (c instanceof JComponent) {
              ((JComponent)c).setEnabled(blnEnabled);
          }
          else if (c instanceof Container) {
              //return setEnabled(((Container)c).getParent());
              Component[] cs = ((Container)c).getComponents();
              if (cs != null) {
                  for (int i=0; i<cs.length; i++) {
                      setEnabled(cs[i], blnEnabled);
                  }
              }
          }
      }
  }
  */
     
  /*
  private void init() {
    addComponentListener(new ComponentAdapter() {
      public void componentShown(ComponentEvent e) {
        System.out.println("componentShown..." + this.getClass().getName());
        if (m_blnDirty) {
          m_blnDirty = false;

          // Set the context.
          BaseWizard wizard = getWizard(BuilderPanel.this);
          if (wizard != null) {
            Object o = wizard.getClientProperty(Builder.CONTEXT);
            if ( (o != null) && (o instanceof BuilderContext) ) {
              setContext((BuilderContext)o);
            }
          }

          // Initialize panel.
          initialize();
        }
      }
    });
  }
  */
}
