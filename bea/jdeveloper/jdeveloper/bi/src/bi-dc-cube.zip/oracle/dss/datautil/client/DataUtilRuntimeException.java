/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.client;

import java.util.ResourceBundle;

import oracle.dss.util.BIBaseRuntimeException;

/**
 * Runtime exceptions thrown specifically by the DataUtil.
 *
 * @status New
 */
public class DataUtilRuntimeException extends BIBaseRuntimeException {

  private ResourceBundle m_bundle;

  /**
   * Constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *                     that is the key used to look up the associated
   *                     error string in the resource bundle.
   *
   *                     If the error associated with the error code is not found,
   *                     getMessage() will return the original error code.
   *
   * @param throwable  A <code>Throwable</code> exception that represents the
   *                   previous exception to carry (may be null).
   *
   * @status hidden
   * @hidden
   */
  public DataUtilRuntimeException(String strErrorCode, Throwable throwable) {
    super(strErrorCode, throwable);
    m_bundle = ResourceBundle.getBundle("oracle.dss.datautil.client.resource.DataUtilClientBundle");
  }

  /**
   * Returns the error message.
   *
   * If the error associated with the original error code is not found,
   * this routine will return the original error code.
   *
   * The message is formatted as follows:
   * ErrorCode <space> ErrorString
   *
   * Example:
   *  DVT-1500 MetadataManager not set
   *
   * @return <code>String</code> which represents the formatted error message.
   *
   * @status hidden
   * @hidden
   */
  public String getMessage() {
    // Retrieve the initial Error code
    String strErrorCode = super.getMessage();

    if ((strErrorCode != null) && (m_bundle != null)) {
      // Retrieve our error string
      String strError = m_bundle.getString(strErrorCode);
      if (strError != null) {
        // Create our new error message
        //  ErrorCode <space> ErrorString
        //  DVT-18000 MetadataManager not set
        StringBuffer strBuffer = new StringBuffer (strErrorCode);
        strBuffer.append (" ");
        return strBuffer.append(strError).toString();
      }
    }

    return strErrorCode;
  }
}