/**
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.query;

import java.util.Arrays;
import java.util.Vector;

import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerServices;

/**
 * @hidden
 * 
 * This class provides methods that can be used to compare sets of data, 
 * including dimensionality. 
 *
 * @status hidden
 */

public class SetUtils extends Object {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   * 
   * A <code>int</code> value used when the comparison between between the 
   * base and comparison sets should be ignored.
   *
   * @status hidden
   */
  public final static int COMPARE_IGNORE = -1;

  /**
   * @hidden
   * 
   * <pre>
   * A <code>int</code> value used when the relationship between the Base and 
   * Comparison sets are disjoint.
   *
   * Base and Comparison sets are <strong>disjoint</strong>
   *   Base Set         = {A, B}
   *   Comparison Set   = {C, D}
   *   Intersecting Set = {} 
   *
   * </pre>
   * 
   * @status hidden
   */
  public final static int COMPARE_DISJOINT = 1;

  /**
   * @hidden
   *
   * <pre>
   * A <code>int</code> value used when the relationship between the Base and 
   * Comparison sets represents an intersection.
   *
   * Base and Comparison sets contain an <strong>intersection</code>
   *   Base Set         = {A, B}
   *   Comparison Set   = {B, C}
   *   Intersecting Set = {B} 
   *
   * </pre>
   *
   * @status hidden
   */
  public final static int COMPARE_INTERSECTION = COMPARE_DISJOINT << 1;

  /**
   * @hidden
   *
   * <pre>
   * A <code>int</code> value used when the Base set is a subset of the 
   * Comparison set.
   *
   * Base set is a <strong>subset</strong> of the Comparison set
   *   Base Set         = {A, B}
   *   Comparison Set   = {A, B, C}
   *   Intersecting Set = {A, B} 
   *
   * </pre>
   *
   * @status hidden
   */
  public final static int COMPARE_SUBSET = COMPARE_INTERSECTION << 1;

  /**
   * @hidden
   *
   * <pre>
   * A <code>int</code> value used when the Base set is a superset of the 
   * Comparison set.
   *
   * Base set is a <strong>superset</strong> of the comparison set
   *   Base Set         = {A, B, C}
   *   Comparison Set   = {A, B}
   *   Intersecting Set = {A, B} 
   *
   * </pre>
   *
   * @status hidden
   */
  public final static int COMPARE_SUPERSET = COMPARE_SUBSET << 1;

  /**
   * @hidden
   *
   * <pre>
   * A <code>int</code> value used when the Base and Comparison sets are equal.
   *
   * Base and Comparison sets are <strong>equal</strong>
   *   Base Set         = {A, B, C}
   *   Comparison Set   = {A, B, C}
   *   Intersecting Set = {A, B, C} 
   *
   * </pre>
   *
   * @status hidden
   */
  public final static int COMPARE_EQUAL = COMPARE_SUPERSET << 1;

  /**
   * @hidden
   * 
   * Newline character used for logging output. 
   * 
   * @status hidden
   */
  protected static char NEWLINE = '\n';

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Create default <code>SetUtils</code>.
   *
   * @status hidden
   */
  public SetUtils() {
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Main method used to test <code>SetUtils</code>.
   * 
   * @status hidden
   */
  public static void main (String[] strArguments) {
    try {
      Vector vstr1 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      Vector vstr2 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      Vector vstrIntersectionSet = new Vector();
    
      int nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    
    
      vstr1 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a", "b"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    

      vstr1 = new Vector (Arrays.asList (new String[] {"a", "b"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    

      vstr1 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"d", "e", "f"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    

      vstr1 = new Vector (Arrays.asList (new String[] {"d", "e", "f"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    

      vstr1 = new Vector (Arrays.asList (new String[] {"a"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    

      vstr1 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    
    
      vstr1 = new Vector (Arrays.asList (new String[] {"a", "b", "c"}));
      vstr2 = new Vector (Arrays.asList (new String[] {"a", "d"}));
      vstrIntersectionSet.setSize (0);
      nCompare = SetUtils.compareSets (vstr1, vstr2, vstrIntersectionSet);
      System.out.println (SetUtils.debugCompareSets (vstr1, vstr2, vstrIntersectionSet, nCompare));    
    }
    
    catch (Exception exception) {
      exception.printStackTrace();
    }
  }

  /**
   * @hidden
   * 
   * Determines the relationship between two sets of <code>String</code>
   * values.  Null sets are considered to be disjoint.
   * <p>
   * Additional information on Sets can be found at:
   * <ul><code>
   *    http://www.ncsa.uiuc.edu/demoweb/url-primer.html
   * </code></ul>
   * <ul><code>
   *    http://appliedlearningscience.com/coreprinciples/mathcounts2.pdf
   * </code></ul>
   * <p>
   * Note: Given that this method currently needs to "consume" vector
   *       values for processing.  As a result, we work with cloned copies of 
   *       the input vectors.
   * <p>
   * 
   * @param vstrBaseSet A <code>Vector</code> of <code>String</code> values 
   *        representing the first set to compare.
   * @param vstrComparisonSet A <code>Vector</code> of <code>String</code> values 
   *        representing the second set to compare.
   * @param vstrIntersectionSet A <code>Vector</code> that will be filled with 
   *        <code>String</code> values that represent the intersection between
   *        the Base and Comparison sets.  If this value is null, no values will 
   *        be generated.
   *
   * @return <code>BitSet</code> value which represents the result of the comparison.
   *        
   * @see #COMPARE_DISJOINT
   * @see #COMPARE_INTERSECTION
   * @see #COMPARE_COMPLEMENTARY
   * @see #COMPARE_EQUAL
   * @see #COMPARE_SUBSET
   * @see #COMPARE_SUPERSET
   * @see #COMPARE_UNKNOWN
   * 
   * @status hidden
   */
  public static int compareSets (Vector vstrBaseSet, Vector vstrComparisonSet, 
                                 Vector vstrIntersectionSet) {
    int nResult = COMPARE_DISJOINT;
    
    boolean bIntersection = false;
    
    if ((vstrBaseSet != null) && (!vstrBaseSet.isEmpty()) && 
        (vstrComparisonSet != null) && (!vstrComparisonSet.isEmpty())) {
      int nIndex2;
     
      // For now, clone the input vectors
      vstrBaseSet = (Vector) vstrBaseSet.clone();
      vstrComparisonSet = (Vector) vstrComparisonSet.clone();
      
      // Move backwards through the list so that we can remove intersecting
      // values
      for (int nIndex1 = vstrBaseSet.size() - 1; nIndex1 > -1; nIndex1--) {
        nIndex2 = vstrComparisonSet.indexOf (vstrBaseSet.get (nIndex1));
        
        if (nIndex2 != -1) {
          if (vstrIntersectionSet != null) {
            vstrIntersectionSet.add (vstrBaseSet.get (nIndex1));
          }

          vstrComparisonSet.remove (nIndex2);       
          vstrBaseSet.remove (nIndex1);
          bIntersection = true;
        }
      }
   
      // Simply check to see if there were any intersecting values
      if (bIntersection) { 
        if (vstrBaseSet.size() == vstrComparisonSet.size()) {
          if (vstrBaseSet.size() == 0) {
            nResult = COMPARE_EQUAL;
          }
          else {
            nResult = COMPARE_INTERSECTION;
          }
        }
        else if (vstrBaseSet.size() > vstrComparisonSet.size()) {
          if (vstrComparisonSet.size() == 0) {
            nResult = COMPARE_SUPERSET;
          }
          else {
            nResult = COMPARE_INTERSECTION;
          }
        }
        else if (vstrComparisonSet.size() > vstrBaseSet.size()) {
          if (vstrBaseSet.size() == 0) {
            nResult = COMPARE_SUBSET;
          }
          else {
            nResult = COMPARE_INTERSECTION;
          }
        }
      }
    }
    
    return nResult;
  }


  /**
   * @hidden
   * 
   * Determines the relationship between the dimensionality associated with 
   * each specified measure.  Null sets are considered to be disjoint.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param strMeasureID1 A <code>String</code> which represents the 
   *        <code>MetadataManager</code> runtime ID associated with the 
   *        first measure.
   * @param strMeasureID2 A <code>String</code> which represents the 
   *        <code>MetadataManager</code> runtime ID associated with the second
   *        measure.
   * @param vstrIntersectionSet A <code>Vector</code> that will be filled with 
   *        <code>String</code> values that represent the 
   *        <code>MetadataManager</code> runtime IDs associated
   *        with the intersecting dimensionality.
   *
   * @return <code>int</code> value which represents the result of the comparison.
   *        
   * @see #COMPARE_DISJOINT
   * @see #COMPARE_INTERSECTION
   * @see #COMPARE_COMPLEMENTARY
   * @see #COMPARE_EQUAL
   * @see #COMPARE_SUBSET
   * @see #COMPARE_SUPERSET
   * @see #COMPARE_UNKNOWN
   *        
   * @throws <code>MetadataManagerException</code> if dimensions cannot be
   *         retrieved.
   *         
   * @status hidden        
   */
  public static int compareDimensionality (MetadataManagerServices metadataManagerServices,
    String strMeasureID1, String strMeasureID2, Vector vstrIntersectionSet) 
                                              throws MetadataManagerException {

    // Retrieve the dimensionality associated with the first measure    
    Vector vstrDimension1IDs = 
      DataUtils.getDimensionality (metadataManagerServices, strMeasureID1);
    
    // Retrieve the dimensionality associated with the second measure    
    Vector vstrDimension2IDs = 
      DataUtils.getDimensionality (metadataManagerServices, strMeasureID2);
  
    return compareSets (vstrDimension1IDs, vstrDimension2IDs, vstrIntersectionSet);
  }
  
  /**
   * @hidden
   * 
   * Determines the relationship between the dimensionality associated with 
   * each specified measure.  Null sets are considered to be disjoint.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param mdMeasure1 A <code>MDMeasure</code> which represents the 
   *        first measure.
   * @param mdMeasure2 A <code>MDMeasure</code> which represents the 
   *        second measure.
   * @param vstrIntersectionSet A <code>Vector</code> that will be filled with 
   *        <code>String</code> values that represent the 
   *        <code>MetadataManager</code> runtime IDs associated
   *        with the intersecting dimensionality.
   *
   * @return <code>int</code> value which represents the result of the comparison.
   *        
   * @see #COMPARE_DISJOINT
   * @see #COMPARE_INTERSECTION
   * @see #COMPARE_COMPLEMENTARY
   * @see #COMPARE_EQUAL
   * @see #COMPARE_SUBSET
   * @see #COMPARE_SUPERSET
   * @see #COMPARE_UNKNOWN
   *        
   * @throws <code>MetadataManagerException</code> if dimensions cannot be
   *         retrieved.
   *        
   * @status hidden       
   */
  public static int compareDimensionality (MetadataManagerServices metadataManagerServices,
    MDMeasure mdMeasure1, MDMeasure mdMeasure2, Vector vstrIntersectionSet) 
                                              throws MetadataManagerException {

    // Retrieve the dimensionality associated with the first measure    
    Vector vstrDimension1IDs = 
      DataUtils.getDimensionality (metadataManagerServices, mdMeasure1);
    
    // Retrieve the dimensionality associated with the second measure    
    Vector vstrDimension2IDs =
      DataUtils.getDimensionality (metadataManagerServices, mdMeasure2);
  
    return compareSets (vstrDimension1IDs, vstrDimension2IDs, vstrIntersectionSet);
  }

  /**
   * @hidden
   * 
   * Determines if the dimensionality of the specified measures is different.
   * 
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param strMeasureID1 A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique runtime ID for measure 1.
   * @param strMeasureID2 A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique runtime ID for measure 2.
   * 
   * @return <code>boolean</code> which is true if the dimensionality is the
   *         same and <code>false</code> otherwise.
   * 
   * @status hidden
   */
  public static boolean isDimensionalityEqual (MetadataManagerServices metadataManagerServices, 
                                  String strMeasureID1, String strMeasureID2) {
    boolean bIsDimensionalityEqual = false;
    
    try {
      int nCompare = compareDimensionality (metadataManagerServices, 
        strMeasureID1, strMeasureID2, null);
    
      bIsDimensionalityEqual = (nCompare == COMPARE_EQUAL);
    }
    
    catch (MetadataManagerException metadataManagerException) {
      // Ignore exceptions  
    }
    
    return bIsDimensionalityEqual; 
  }

  /**
   * @hidden
   * 
   * Determines whether the specified comparison value represents an intersection.
   *
   * @param nCompare A <code>int</code> value which represents the comparison 
   *        value to check.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         comparison value represents an intersection and <code>false</code>
   *         otherwise.
   *        
   * @see #COMPARE_DISJOINT
   * @see #COMPARE_INTERSECTION
   * @see #COMPARE_COMPLEMENTARY
   * @see #COMPARE_EQUAL
   * @see #COMPARE_SUBSET
   * @see #COMPARE_SUPERSET
   * @see #COMPARE_UNKNOWN
   * 
   * @status hidden
   */
  public static boolean hasIntersection (int nCompare) {
    boolean bHasIntersection = false;
    
    switch (nCompare) {
      case COMPARE_INTERSECTION:
      case COMPARE_EQUAL:
      case COMPARE_SUBSET:
      case COMPARE_SUPERSET:
        bHasIntersection = true;
        break;
    }
    
    return bHasIntersection;
  }

  /**
   * @hidden
   * 
   * Generates a <code>String</code> representation of the compare method
   * which is useful for debugging.
   * 
   * @param vstrBaseSet A <code>Vector</code> of <code>String</code> values 
   *        representing the first set to compare.
   * @param vstrComparisonSet A <code>Vector</code> of <code>String</code> values 
   *        representing the second set to compare.
   * @param vstrIntersectionSet A <code>Vector</code> that represents the 
   *        intersection between the Base and Comparison sets.
   * @param nComparison A <code>int</code> value which represents the result 
   *        of the comparison.
   *        
   * @see #COMPARE_DISJOINT
   * @see #COMPARE_INTERSECTION
   * @see #COMPARE_COMPLEMENTARY
   * @see #COMPARE_EQUAL
   * @see #COMPARE_SUBSET
   * @see #COMPARE_SUPERSET
   * @see #COMPARE_UNKNOWN
   * 
   * @status hidden
   */
  public static String debugCompareSets (Vector vstrBaseSet, Vector vstrComparisonSet, 
    Vector vstrIntersectionSet, int nIntersection) {
    
    String strIntersection = null;
    StringBuffer stringBuffer = new StringBuffer();
    
    switch (nIntersection) {
      case SetUtils.COMPARE_DISJOINT:
        strIntersection = "COMPARE_DISJOINT";
        break;
        
      case SetUtils.COMPARE_INTERSECTION:
        strIntersection = "COMPARE_INTERSECTION";
        break;

      case SetUtils.COMPARE_EQUAL:
        strIntersection = "COMPARE_EQUAL";
        break;

      case SetUtils.COMPARE_SUBSET:
        strIntersection = "COMPARE_SUBSET";
        break;

      case SetUtils.COMPARE_SUPERSET:
        strIntersection = "COMPARE_SUPERSET";
        break;
    }

    if (stringBuffer != null) {
      stringBuffer.append ("Base Set:         " + toString (vstrBaseSet) + NEWLINE);
      stringBuffer.append ("Comparison Set:   " + toString (vstrComparisonSet) + NEWLINE);
      stringBuffer.append ("Intersection Set: " + toString (vstrIntersectionSet) + NEWLINE);
      stringBuffer.append ("Result:           " + strIntersection + NEWLINE);
    }
    
    return stringBuffer.toString();
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Generates a <code>String</code> representation associated with the specified
   * <code>String</code> <code>Vector</code>.
   * 
   * @param vstrValues A <code>Vector</code> of <code>String</code> values 
   *        to generate <code>String</code> representation for.
   *
   * @param nComparison A <code>int</code> value which represents the result 
   *        of the comparison.
   *        
   * @return <code>String</code> representation of the specified <code>String</code> 
   *         <code>Vector</code> 
   * 
   * @status hidden
   */
  protected static String toString (Vector vstrValues) {
    String strValues = null;
    
    if (vstrValues != null) {
      StringBuffer strBufferValues = new StringBuffer();
      strBufferValues.append ("[");
      
      for (int nIndex = 0; nIndex < vstrValues.size(); nIndex++) {
        strBufferValues.append (vstrValues.get (nIndex));
        if (nIndex < vstrValues.size() - 1) {
          strBufferValues.append (", ");
        }
      }
      
      strBufferValues.append ("]");
      strValues = strBufferValues.toString();
    }
    
    return strValues;  
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}