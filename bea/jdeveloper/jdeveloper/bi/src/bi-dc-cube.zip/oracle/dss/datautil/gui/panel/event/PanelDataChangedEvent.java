/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui.panel.event;

import java.util.EventObject;

/**
 * Describes data changes in a particular panel.
 *
 * @status documented
 */

public class PanelDataChangedEvent extends EventObject
{
    /////////////////////////////////////////////////////////////////////
    // NON PUBLIC MEMBERS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * @hidden
     *
     * The type of the field that was changed.
     *
     * @status protected
     */
    protected String m_dataType = null;
    
    /**
     * @hidden
     *
     * Information about the data change.
     *
     * @status protected
     */
    protected Object m_dataChangedInfo = null;
    
    /////////////////////////////////////////////////////////////////////
    // CONSTRUCTOR
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Constructor that specifies all arguments.
     *
     * @param source The source of the event. This is the reference to the 
     * <code>StandardPanel</code> from which the event originated.
     * @param dataType The type of the data change.
     * @param dataChangedInfo The information about the data change.
     *
     * @status documented
     */
    public PanelDataChangedEvent ( Object source, 
                                   String dataType, Object dataChangedInfo ) 
    {
        super ( source );
        m_dataType = dataType;
        m_dataChangedInfo = dataChangedInfo;
    }        
    
    /////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    /////////////////////////////////////////////////////////////////////
    
    /**
     * Retrieves the information about the data change.
     *
     * @return The information about the data change.
     *
     * @status documented
     */
    public Object getDataChangedInfo ( )
    {
        return m_dataChangedInfo;
    }
    
    /**
     * Retrieves the type of the data change.
     *
     * @return The data type.
     *
     * @status documented
     */
    public String getType ( )
    {
        return m_dataType;
    }        
}

    
