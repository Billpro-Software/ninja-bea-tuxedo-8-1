/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;


import oracle.dss.util.Operation;
import oracle.dss.util.AbstractMap;

/**
 * Informs listeners that the state of a <code>Query</code> object has been
 * changed.
 *
 * @status Documented
 */
public class StateChangedEvent extends StateChangeEvent
{
    /**
     *  @hidden
     *  The state before the query was changed, for the .STATE type
     */
    protected QueryState m_beforeState = null;
    
    /**
     * Constructs the event for a specific operation.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param op     An <code>Operation</code> object.
     * @param type   A constant (<code>StateChangeEvent.STATE</code>) that represents the
     *               type of state change for the query.
     *
     * @see StateChangeEvent#STATE
     *
     * @status Documented
     */
    public StateChangedEvent(Object source, Operation op, int type) {
        super(source, op, type);
    }

    /**
     * Constructs the event for a specific operation.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param op     An <code>Operation</code> object.
     * @param beforeState The <code>QueryState</code> that represented the state of the 
     *                    query before the state was changed.
     * @param type   A constant (<code>StateChangeEvent.STATE</code>) that represents the
     *               type of state change for the query.
     *
     * @see StateChangeEvent#STATE
     *
     * @status New
     */
    public StateChangedEvent(Object source, Operation op, QueryState beforeState, int type) {
        super(source, op, type);
        m_beforeState = beforeState;
    }

    /**
     * Constructs the event with maps for a change in one or more dimensions.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of the dimension of the map that is involved;
     *               <code>null</code> means all dimensions.
     * @param m      The map that results from the change.
     * @param t      A constant (<code>StateChangeEvent.DATA_MAP</code> or
     *               <code>StateChangeEvent.METADATA_MAP</code>) that
     *               represents the type of map state change for the query.
     *
     * @see StateChangeEvent#DATA_MAP
     * @see StateChangeEvent#METADATA_MAP
     *
     * @status Documented
     */
    public StateChangedEvent(Object source, String d, AbstractMap m, int t) {
        super(source, d, m, t);        
    }

    /**
     * Constructs the event with maps for a change on a specific edge of the
     * query.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param e      A constant (such as <code>DataDirector.ROW_EDGE</code>)
     *               that represents the edge of the map that has changed.
     * @param m      The <code>Map</code> object that will be applied or set.
     * @param t      A constant (<code>StateChangeEvent.DATA_MAP</code>, or
     *               <code>StateChangeEvent.METADATA_MAP</code>) that indicates
     *               the type of map state change to the query.
     *
     * @see StateChangeEvent#DATA_MAP
     * @see StateChangeEvent#METADATA_MAP
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public StateChangedEvent(Object source, int e, AbstractMap m, int t) {
        super(source, e, m, t);
    }

    /**
     * Constructs the event with a selection.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of the dimension of the universe selection
     *               that is involved in the query change.
     * @param s      The <code>Selection</code> object to be used after
     *               the change.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public StateChangedEvent(Object source, String d, Selection s) {
        super(source, d, s);        
    }*/
    
    /**
     * Return the <code>QueryState</code> of the query before this change,
     * if the type is <code>StateChangeEvent.STATE</code>
     * 
     * @return <code>QueryState</code> before the change, or <code>null</code> if not a state change type.
     * 
     * @status New
     */
    public QueryState getStateBeforeChange()
    {
        return m_beforeState;
    }
    
    /**
     * Generates a <code>String</code> representation of this object.
     *
     * @status Documented
     */
    public String toString() {
        if (getOperation() == null) {
            return getClass().getName() + "()";
        }
        return getClass().getName() + "(" + getOperation().toString() + ")";
    }
}
