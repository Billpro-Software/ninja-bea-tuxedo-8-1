/**
 * JTextFieldExtended.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
  
package oracle.dss.datautil.gui;

import java.awt.Toolkit;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.text.AttributeSet; 
import javax.swing.text.BadLocationException; 
import javax.swing.text.Document; 
import javax.swing.text.PlainDocument; 

/**
 * @hidden
 * 
 * Provides extended <code>JTextArea</code> functionality.
 * 
 * In particular, this class allows us to limit the number of maximum 
 * characters that the user will be allowed to type or specify invalid 
 * characters.
 *
 * @status hidden
 */
 
public class JTextFieldExtended extends JTextField {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Specifies an invalid character array that only includes a space 
   * character.
   *
   * @status hidden
   */
  public static char[] INVALID_CHARS_BLANK = {' '}; 

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Specifies the default value for the maximum number of characters allowed.
   *
   * @status private
   */
  private int nMaxChars = 64; 

  /**
   * @hidden
   * 
   * Specifies the characters that are considered invalid.
   *
   * @status private
   */
  private char[] m_charArrayInvalid = null; 

  /**
   * @hidden
   * 
   * Specifies whether a beep is generated when the user attempts to enter
   * an invalid character.
   *
   * @status private
   */
  private boolean m_bInvalidCharsBeep = true; 

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   *
   * Default constructor.
   *
   * @status hidden
   */
  public JTextFieldExtended () {
    super();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Specifies the maximum number of characters allowed.
   * 
   * @param nMaxChars A <code>int</code> value used to specify the maximum 
   *        number of characters allowed.
   *
   * @status hidden
   */
  public void setMaxCharacters (int nMaxChars) {
    if (nMaxChars < 0) {
      this.nMaxChars = 0;
    }
    else {
      this.nMaxChars = nMaxChars;
    }
  }

  /**
   * @hidden
   *
   * Specifies the characters that are considered invalid.  As a result, these
   * characters are not allowed in the <code>JTextField</code>.
   * 
   * @param charArrayInvalid A <code>char[]</code> of values that are
   *        considered to be invalid.
   *
   * @status hidden
   */
  public void setInvalidChars (char[] charArrayInvalid) {
    m_charArrayInvalid = charArrayInvalid;
  }

  /**
   * @hidden
   *
   * Retrieves the characters that are considered invalid.  As a result, these
   * characters are not allowed in the <code>JTextField</code>.
   * 
   * @return <code>char[]</code> of values that are considered to be invalid.
   *
   * @status hidden
   */
  public char[] getInvalidChars() {
    return m_charArrayInvalid;
  }

  /**
   * @hidden
   *
   * Specifies whether a beep is generated when the user attempts to enter
   * an invalid character.
   * 
   * @param bInvalidCharsBeep A <code>boolean/code> which is <code>true</code>
   *        when a beep should be generated when the user attempts to enter an 
   *        invalid character, and <code>false</code> otherwise.
   *
   * @status hidden
   */
  public void setInvalidCharsBeep (boolean bInvalidCharsBeep) {
    m_bInvalidCharsBeep = bInvalidCharsBeep;
  }

  /**
   * @hidden
   *
   * Determines whether a beep is generated when the user attempts to enter
   * an invalid character.
   * 
   * @return <code>boolean/code> which is <code>true</code> when a beep 
   *         should be generated when the user attempts to enter an invalid 
   *         character, and <code>false</code> otherwise.
   *
   * @status hidden
   */
  public boolean isInvalidCharsBeep() {
    return m_bInvalidCharsBeep;
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Creates a default <code>Document</code> model which allows us to override
   * the number of characters allowed.
   *
   * @return <code>Document</code> which represents the default model.
   * 
   * @status hidden
   */
  protected Document createDefaultModel() {
    return new JTextFieldExtendedDocument(); 
  }  

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  /**
   * @hidden
   *
   * @status hidden
   */
  protected class JTextFieldExtendedDocument extends PlainDocument {

    /**
     * @hidden
     * 
     * Inserts some content into the document.
     * 
     * Inserting content causes a write lock to be held while the
     * actual changes are taking place, followed by notification
     * to the observers on the thread that grabbed the write lock.
     * <p>
     * This method is thread safe, although most Swing methods
     * are not. Please see 
     * <A HREF="http://java.sun.com/products/jfc/swingdoc-archive/threads.html">Threads
     * and Swing</A> for more information.
     *
     * @param nStartingOffset A <code>int</code that represents the starting 
     *        offset >= 0
     * @param strInsert A <code>String</code> that represents the string to 
     *        insert; does nothing with null/empty strings
     * @param attributeSet A <code>AttributeSet</code> that represnt the 
     *        attributes for the inserted content
     *        
     * @throws <code>BadLocationException</code> if the given insert position 
     *         is not a valid position within the document
     *   
     * @status hidden
     */
    public void insertString (int nStartingOffset, String strInsert, 
                    AttributeSet attributeSet) throws BadLocationException {
      if (strInsert == null) {
        return; 
      }

      // Determine if we are checking for invalid characters
      if (getInvalidChars() != null) {
        
        for (int nIndex = 0; nIndex < getInvalidChars().length; nIndex++) {
          if (strInsert.indexOf (getInvalidChars()[nIndex]) != -1) {
            if (isInvalidCharsBeep()) {
              // Generate a Beep
              Toolkit.getDefaultToolkit().beep();
            }

            return;
          }
        }
      }

      // Get the length of the text in JTextArea
      int nLength = 0;
        
      if (JTextFieldExtended.this.getText() == null) {
        nLength = 0;
      }
      else {
        nLength = JTextFieldExtended.this.getText().length();
      }

      // Check to see if we have exceeded the maximum number of characters
      if (nLength + strInsert.length() > JTextFieldExtended.this.nMaxChars) {
        // Simply return if the total number of characters is more than 
        // the maximum allowed.
        return;
      }
      else { 
        // Update the text field
        super.insertString (nStartingOffset, strInsert, attributeSet);
      }
    }
  }
}


