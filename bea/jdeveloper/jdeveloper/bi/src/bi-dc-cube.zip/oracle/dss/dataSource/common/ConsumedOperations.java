/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.Vector;

/**
 * @hidden
 * Contains all operations consumed by listeners for operations in this call, if any
 *
 * @status New
 */
public class ConsumedOperations extends Vector
{
    public ConsumedOperations()
    {
        super();
    }
}