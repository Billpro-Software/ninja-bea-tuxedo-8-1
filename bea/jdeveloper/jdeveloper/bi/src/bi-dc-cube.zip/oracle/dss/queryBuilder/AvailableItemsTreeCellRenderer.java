/*
 * AvailableItemsTreeRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTree;

import oracle.bali.ewt.graphics.ImageUtils;

import oracle.dss.util.gui.component.tree.Checkable;

public class AvailableItemsTreeCellRenderer extends ItemsTreeCellRenderer {

    /*
     * Public
     */
     
    public AvailableItemsTreeCellRenderer(JTree tree) {
        super(tree);
    }

    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        Component c = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
        if (value instanceof Checkable) {
            JPanel p = new JPanel(new BorderLayout());
            boolean blnChecked = ((Checkable)value).isChecked();
            JButton b = (blnChecked) ? m_btnActive : m_btnInactive;
            if (tree != null) {
                b.setBackground(tree.getBackground());
                b.setForeground(tree.getForeground());
                //btnActive.setOpaque(false);
                p.setOpaque(false);
            }
            p.add(b, BorderLayout.WEST);
            p.add(c, BorderLayout.CENTER);
            return p;
        }
        return c;        
    }
    
    /*
     * Private
     */
     
    private static final ImageIcon m_imgActive = new ImageIcon(ImageUtils.getImageResource(AvailableItemsTreeCellRenderer.class, "images/active.gif"));
    private static final ImageIcon m_imgInactive = new ImageIcon(ImageUtils.getImageResource(AvailableItemsTreeCellRenderer.class, "images/inactive.gif"));
    private static final JButton m_btnActive = new JButton(m_imgActive);
    private static final JButton m_btnInactive = new JButton(m_imgInactive);
    
    static {
        m_btnActive.setBorder(BorderFactory.createEmptyBorder());
        m_btnActive.setBorderPainted(false);
        m_btnInactive.setBorder(BorderFactory.createEmptyBorder());
        m_btnInactive.setBorderPainted(false);
    }
}

