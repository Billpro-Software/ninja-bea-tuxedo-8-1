/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.client;

/****************************************************
 * Imports
 ****************************************************/
import java.io.Serializable;
import java.util.Locale;
import java.util.Hashtable;
import oracle.dss.metadataManager.common.MDFolder;

import oracle.dss.connection.common.BISession;


import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;

import oracle.dss.connection.common.CB;
import oracle.dss.connection.common.ConnectionObj;
import oracle.dss.connection.common.ConnectionObject;
import oracle.dss.connection.common.ConnectionException;
import oracle.dss.connection.common.ConnectionEventSupport;
import oracle.dss.connection.common.ConnectionListener;
import oracle.dss.connection.client.handlers.ConnectionHandler;
import oracle.dss.connection.client.resource.ConnectionClientBundle;

import oracle.dss.util.persistence.AggregateInfo;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.PersistableConstants;

import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.PropertyNode;
import oracle.dss.util.xml.BIXMLException;
import oracle.dss.util.xml.XMLObjectWriter;
import oracle.dss.util.xml.XMLObjectReader;
import oracle.dss.util.xml.NoSuchPropertyException;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.VersionInfo;

/**
 * The main class of the connection bean.
 * The connection bean manages connections to data.
 * Each type of connection must have a separate <code>Connection</code> instance.
 * For example, if you connect to the repository and to an RDBMS where OLAP
 * services metadata is stored, then you need two <code>Connection</code>
 * instances, one <code>Connection</code> for the repository and one for the
 * RDBMS.
 * A <code>BISession</code> can have multiple connections.
 *
 * @status Reviewed
 */
public class Connection implements Serializable, Persistable, ErrorHandlerCallback
{
	/****************************************************
	 * Protected members
	 ****************************************************/
    // This is the Proxy object that represent the
    // middle tier component oc Connection Bean.
    protected  ConnectionObject m_ConnectionProxy = null;

    private String m_connectionKey;

  /**
   * For event handling
   */
    private ConnectionEventSupport eventSupport;

	// Orb.
	protected org.omg.CORBA.ORB m_orb = null;

	/****************************************************
	 * Private members
	 ****************************************************/
    // The instance ID. This is a  static member.
    private static int m_InstanceID = 0;

    // The connection structure. This contains all connection
    // information. This class will be send across the tiers.
    private ConnectionObj m_ConnectionObj = null;

	// To run the applet mode.
    private java.applet.Applet m_Applet = null;

	// Is Design Time connection is OK?
	private boolean m_IsRemoteOK = true;

    private static final String s_xmlNameTag = "Connection";
    private static final int s_xmlVersion = 1;

    private ConnectionHandler m_handler;

    private ErrorHandler m_eh = null;

    private Object m_remoteConnection = null;
    private Locale m_Locale;
    private BISession m_session;
    private String m_deployMode;
    private Hashtable m_driverImpl;
    private boolean m_remoteConnectionUsed = false;
    
    private MDFolder m_root;
	/****************************************************
	 * Constructors
	 ****************************************************/
    /**
     * Constructor.
     *
     * @status Documented
     */
    public Connection() {
        m_ConnectionObj = new ConnectionObj();
        init();
    }

    /**
     * Constructor
     * @param host Database host name
     * @param port Database port number
     * @param sid  Database SID
     * @param user Database username
     * @param pass Database password
     * @param datasourceType The datasource type.  The possible values are CB.MDM or CB.EUL
     * @param datasourceName The name of the datasource object.
     */
    public Connection(String connectString, String user, String pass, String datasourceType, String datasourceName)
    {
        m_ConnectionObj = new ConnectionObj();
        if(connectString != null && user != null && pass != null && datasourceType != null && datasourceName != null)
        {
            m_ConnectionObj.setStrPropertyValue(CB.CONNECTION_STRING, connectString);
            m_ConnectionObj.setUsername(user);
            m_ConnectionObj.setPassword(pass);
            m_ConnectionObj.setStrPropertyValue(CB.DATASOURCE_TYPE, datasourceType);
            m_ConnectionObj.setStrPropertyValue(CB.DATASOURCE_NAME, datasourceName);
        }
        init();
    }

    /**
     * @hidden until we support applets
     * Constructor that takes an <code>Applet</code>.
     * Use this constructor if you are developing an <code>Applet</code>.
     *
     * @param applet The <code>Applet</code> that uses this
     *               <code>Connection</code>.
     *
     * @see #Connection()
     *
     * @status hidden
     */
    public Connection ( java.applet.Applet applet ) {
        m_Applet = applet;
        m_ConnectionObj = new ConnectionObj();
        init();
    }

    /**
     * @hidden
     * Constructor that takes arguments and properties of an Object Request
     * Broker (ORB).
     * Use this constructor only if you already have an ORB to which you
     * want to connect.
     *
     * @param args  ORB arguments.
     * @param properties ORB properties.
     *
     * @status hidden
     */
    public Connection ( String[] args, java.util.Properties properties ) {
        m_ConnectionObj = new ConnectionObj();
        m_ConnectionObj.setORBArgs( args );
        m_ConnectionObj.setORBProperties( properties );
        m_ConnectionObj.setOrbInitStatus( true );
        init();
    }

    /**
     * @hidden
     *
     * Constructor with a PropertyBag (For JDeveloper)
     *
     * @param propertyBag  PropertyBag containg all Poperties.
     *
     * @status hidden
     */
    public Connection ( PropertyBag propertyBag ) {
        m_ConnectionObj = new ConnectionObj();
        m_ConnectionObj.setPropertyBag ( propertyBag, CB.KEEP ) ;
        init();
    }

   	/**
     * Specifies the session to which this <code>Connection</code>
     * belongs.
     *
     * @param session  The <code>BISession</code> to which this <code>Connection</code>
     *                 object belongs.
     *
     * @status Reviewed
     */
    public void setSession(BISession session)
    {
        m_session = session;
        if (m_session != null)
        {
            if (m_session.getErrorHandler() != null)
                m_eh = m_session.getErrorHandler();

            if (m_session.getLocale() != null)
                setLocale(m_session.getLocale());
        }
        
        // need to set this up for Persistence acl operations
        if (getDriverType() != null && getDriverType().equals(MDU.PERSISTENCE))
        {
            if (session.getApplicationName() != null)
                setProperty(CB.APPLICATION_NAME, m_session.getApplicationName(), MDU.STRING, MDU.UI_VISIBLE);
        }
    }

   	/**
     * Retrieves the session to which this <code>Connection</code> belongs.
     *
     * @return the <code>BISession</code> to which this <code>Connection</code>
     *         object belongs.
     *
     * @status Reviewed
     */
    public BISession getSession()
    {
        return m_session;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
    private void init() {
        eventSupport = new ConnectionEventSupport( this );
        m_InstanceID++;
        m_ConnectionObj.setName( "Connection_" + Integer.toString(getInstanceID() ).trim());
        m_eh = new DefaultErrorHandler();
        m_driverImpl = new Hashtable();
        m_driverImpl.put(MDU.MDM, "oracle.dss.connection.server.drivers.mdm.MDMConnectionDriverImpl");
        m_driverImpl.put(MDU.ECM, "oracle.dss.connection.server.drivers.ecm.ECMConnectionDriverImpl");
        m_driverImpl.put(MDU.PERSISTENCE, "oracle.dss.connection.server.drivers.persistence.PersistenceConnectionDriverImpl");
        m_driverImpl.put(MDU.DISCOVERER, "oracle.dss.connection.server.drivers.disco.DiscovererConnectionDriverImpl");
        m_driverImpl.put(MDU.SBA, "oracle.dss.connection.server.drivers.sba.SBAConnectionDriverImpl");
        setConnectionStatus(CB.NOT_CONNECTED);
    }

   /************************************************************************
    * BC4J Methods
    ************************************************************************/

    /**
     * @hidden until we support applets
     * Specifies an <code>Applet</code> that uses this connection.
     *
     * @param applet   The <code>Applet</code> that uses this connection.
     *
     * @return        <code>oracle.dss.connection.common.CB.SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status hidden
     */
    public int setApplet(java.applet.Applet applet) {
      m_Applet = applet;
      return CB.SUCCESS;
    }

   /************************************************************************
    * Connection Support
    ************************************************************************/
    /**
     * Indicates whether this connection instance is connected to the server.
     *
     * @return  <code>true</code> if this connection is connected,
     *          <code>false</code> if it is not connected.
     *
     * @status hidden
     */
    public boolean isConnected() {
        return m_ConnectionObj.isConnected();
    }
    
    /**
     * Indicates whether a connection is successful or has failed.
     * Call this method to see if an attempt was made to connect and
     * if the attempt was successful.
     *
     * @return  <code>true</code>  if this connection failed while an attempt
     *                             was made to connect,
     *          <code>false</code> if the connection attempt succeeded and the
     *                             connection is in a connected state.
     *
     * @status Reviewed
     */
    public boolean isConnectionFailed() {
      return m_ConnectionObj.isConnectionFailed();
    }    
    
    /************************************************************************
    * Event Support.
    ************************************************************************/
    /**
     * Adds a <code>ConnectionListener</code> to this connection.
     * A <code>ConnectionListener</code> listens for connection events.
     *
     * @param listener  The listener to add.
     *
     * @status Reviewed
     */
    public void addListener( ConnectionListener listener ) {
        eventSupport.addConnectionListener( listener );
    }

    /**
     * Removes a <code>ConnectionListener</code> from this connection.
     *
     * @param listener The listener to remove.
     *
     * @status Reviewed
     */
    public void removeListener( ConnectionListener listener ) {
      eventSupport.removeConnectionListener( listener );
    }

    /**
     * Connects this connection to the server.
     *
     * @return A constant that represents connection status.
     *         Possible values are listed in the See Also section.
     *
     * @throws ConnectionException If the connection process fails
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status Reviewed
     */
    public int connect() throws ConnectionException {
		  return connect ( (PropertyBag) null ) ;
	  }

    /**
     * Disconnects this connection from the server.
     *
     * @return A constant that represents connection status.
     *                  Possible values are listed in the See Also section.
     *
     * @throws ConnectionException If the disconnection process fails
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status Reviewed
     */
    public int disconnect() throws ConnectionException {
        return disconnect ( (PropertyBag) null ) ;
    }

     /**
     * @hidden
     * Connect the Bean instance to the Server.
     *
     * @return Integer constant representing connection status.
     *                  Possible values are:
     *                  <code>CONNECTED</code> if connected.
     *                  <code>NOT_CONNECTED</code> if not connected.
     *                  <code>FAILURE</code> if connection failed
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @param connectParams  PropertyBag
     *
     * @throws ConnectionException if connection process is failed
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */

    public int connect( PropertyBag connectParams )	throws ConnectionException
    {
        if ( initConnection() != CB.SUCCESS )
            return CB.FAILURE;

 		if (!isProxyOK() || !isRemoteOK())
            return CB.NO_REMOTE;

        if ( getConnectionStatus() == CB.NOT_CONNECTED )
        {
            eventSupport.fireConnectingEvent();

            m_eh.trace("-ConnectionBean-Client: is going to connect ", getClass().getName(), "connect");
            // set error handler on middle-tier through m_ConnectionObj
            m_ConnectionObj.setObjPropertyValue("ErrorHandler", m_eh);

            if(m_driverImpl != null)
                m_ConnectionObj.setObjPropertyValue(CB.CONNECTION_DRIVER, m_driverImpl);

            if(getLocale() != null)
                m_ConnectionObj.setObjPropertyValue("locale", getLocale());
/*
            Property [] _newProps = m_ConnectionObj.getProperties();
            Property changed = null;
            for (int i = 0; i < _newProps.length; i++)
            {
                Object _val = _newProps[i].getObjValue();
                if (_val instanceof JboContainer)
                {
                    changed = new Property();
                    changed.setDataType(_newProps[i].getDataType());
                    changed.setObjValue(_newProps[i].getName(), _newProps[i].getObjValue(), _newProps[i].getFlags());
                    ComponentObject _comp = ((JboContainer)_val).getComponentObject();
                    _newProps[i].setObjValue(_newProps[i].getName(), _comp, _newProps[i].getFlags());
                    m_ConnectionObj.setProperty(_newProps[i]);
                }
            }
*/
            ConnectionObj cObj = m_ConnectionProxy.connect( m_ConnectionObj, connectParams );

            // remove error handler from m_ConnectionObj
            m_ConnectionObj.removeProperty("ErrorHandler");
            m_ConnectionObj.removeProperty("locale");

      		if ( cObj == null )
            {
                // restore the original values of m_ConnectionObj
                //if (changed != null)
                //    m_ConnectionObj.setProperty(changed);

  	            setConnectionStatus( CB.NOT_CONNECTED );
  			    return getConnectionStatus();
  		    }

  		    if ( cObj.getConnectionStatus() == CB.CONNECTED )
            {
  		        m_ConnectionObj = cObj;

                // restore the original values of m_ConnectionObj
                //if (changed != null)
                //    m_ConnectionObj.setProperty(changed);

                eventSupport.fireConnectedEvent();
  	        }
            else
  		        return CB.FAILURE;

        	return getConnectionStatus();
        }
        return getConnectionStatus();
    }

     /**
     * @hidden
     * Disonnect the Bean instance from the Server.
     *
     * @return Integer constant representing connection status.
     *                  Possible values are:
     *                  <code>CONNECTED</code> if connected.
     *                  <code>NOT_CONNECTED</code> if not connected.
     *                  <code>FAILURE</code> if connection failed
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @param disconnectParams  PropertyBag
     *
     * @throws ConnectionException if disconnect process is failed
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */
    public int disconnect( PropertyBag disconnectParams) throws ConnectionException {
  	    if (!isProxyOK() || !isRemoteOK())
  		    return CB.NO_REMOTE;

        if ( getConnectionStatus() == CB.CONNECTED )
        {
    		if( eventSupport.fireDisconnectingEvent() )
            {
              m_eh.trace("-ConnectionBean-Client: disconnecting event is consumed ", getClass().getName(), "disconnect");
              return CB.FAILURE;
            }

              m_eh.trace("-ConnectionBean-Client: is going to disconnect ", getClass().getName(), "disconnect");
  			ConnectionObj cObj = m_ConnectionProxy.disconnect( disconnectParams );
  			if ( cObj.getConnectionStatus() == CB.NOT_CONNECTED )
            {
  				m_ConnectionObj = cObj;
                eventSupport.fireDisconnectedEvent();
  			}
            else
  				return CB.FAILURE;
	 		return getConnectionStatus();
  	    }
  	    return getConnectionStatus();
    }

   /************************************************************************
    * SPL Support.
    ************************************************************************/
    /**
     * @hidden
     * Executes an command on the server.
     * The command must be correct for the stored procedure language of the
     * server to which this connection connects.
     *
     * @return The result of execution of the command.
     *
     * @param command  The command to execute.
     * @param properties  Properties of the command.
     *
     * @throws ConnectionException If the execution fails.
     *
     * @status hidden
     */
    public String executeCommand(String command, PropertyBag properties) throws ConnectionException {
        if(!isProxyOK() || !isRemoteOK())
            throw new ConnectionException(ConnectionClientBundle.class,
                                          ConnectionClientBundle.EXC_CONNECT_NOT_INITIALIZED,
                                          null,
                                          getLocale(),
                                          null,
                                          MDU.MDM);

        if(getConnectionStatus() == CB.CONNECTED)
            return m_ConnectionProxy.executeCommand(command, properties);
        else
        {
            throw new ConnectionException(ConnectionClientBundle.class,
                                          ConnectionClientBundle.EXC_CONNECT_NOT_INITIALIZED,
                                          null,
                                          getLocale(),
                                          null,
                                          MDU.MDM);
        }
    }

    /**
     * Executes the OLAP DML command and returns the result of the command.  It
     * is only supported with the 9i2 and higher database.
     *
     * @param command  The OLAP DML command to execute.
     * @return A String that contains the execution log that results from the
     *         execution of the specified DML command. If the command was
     *         successful, then the log contains the return value of the
     *         command. If the command was unsuccessful, then the log
     *         contains the resulting error report.
     *
     * @throws ConnectionException If the execution failed.
     *
     * @status New
     */
    public String executeCommand(String command) throws ConnectionException
    {
        return executeCommand(command, null);
    }
    /**
     * @hidden
     * Evaluates an expression and retrieves results of the expression.
     * The expression should be in terms of the stored procedure language
     * of the server.
     *
     * @return The result of evaluated expression.
     *
     * @param expression The expression to evaluate.
     * @param properties Properties of the expression.
     *
     * @throws ConnectionException If the evaluation fails.
     *
     * @status hidden
     */
    public Object evaluateExpression(String expression, PropertyBag properties ) throws ConnectionException {
 		if (!isProxyOK() || !isRemoteOK())
      		return null;

      	if ( getConnectionStatus() == CB.CONNECTED )
  			return m_ConnectionProxy.evaluateExpression( expression, properties );

  	    return null;
    }

   /************************************************************************
    * Operations on the objects that only exist on the source platform.
    ************************************************************************/
    /**
     * @hidden
     * Retrieve the driver specific objects from the driver
     *
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              driver specific object
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public Object getDriverSpecificObject( PropertyBag properties ) throws ConnectionException 
    {
        if(properties != null && properties.getStrPropertyValue(CB.SERVICE_CREDENTIALS) != null)
        {
            //return getServiceCredentials();
            return null;
        }
        if (!isProxyOK() || !isRemoteOK())
            initConnection();
        return m_ConnectionProxy.getDriverSpecificObject( properties );
    }

   /************************************************************************
    * Operations on the objects that only exist on the source platform.
    ************************************************************************/
    /**
     * @hidden
     * Set the driver specific objects on the driver
     *
     * @param properties    the driver specific object to be set.
     * @param properties    properties that should match with the object we are
     *                      looking for
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	public int setDriverSpecificObject( Object object, PropertyBag properties ) throws ConnectionException {
 		if (!isProxyOK() || !isRemoteOK())
  	    	return CB.FAILURE;

      	if ( getConnectionStatus() == CB.CONNECTED )
  			return m_ConnectionProxy.setDriverSpecificObject( object, properties );

  	    return CB.FAILURE;
    }

    /**
     * @hidden
     * Remove the driver specific objects at the driver level
     *
     * @param properties    properties needed to remove driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              ConnectionException
     *
     * @status hidden
     */
	  public int removeDriverSpecificObjects( PropertyBag properties ) throws ConnectionException {
 		  if (!isProxyOK() || !isRemoteOK())
        return CB.FAILURE;

  	  if ( getConnectionStatus() == CB.CONNECTED )
  			return m_ConnectionProxy.removeDriverSpecificObjects( properties );

      return CB.FAILURE;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
    public Property getServerProperty( String propertyName ) throws ConnectionException {
      if (!isProxyOK() || !isRemoteOK())
        return null;

      return m_ConnectionProxy.getServerProperty ( propertyName );
    }

    /**
     * @hidden
     *
     * Sets the property of the server side of connection
     *
     * @status hidden
     */
    public int setServerProperty( Property property ) throws ConnectionException {
      if (!isProxyOK() || !isRemoteOK())
        return CB.FAILURE;
      return m_ConnectionProxy.setServerProperty( property );
    }

    /**
     * @hidden
     *
     * @status hidden
     */
	  public ConnectionObj getConnectionObj() {
  	  return m_ConnectionObj;
	  }

    /**
     * @hidden
     *
     * @status hidden
     */
	  public int setConnectionObj( ConnectionObj connectionObj) {
		  m_ConnectionObj = connectionObj;
  		return CB.SUCCESS;
	  }

    /**
     * @hidden
     *
     * @status hidden
     */
	  public ConnectionObj getServerConnectionObj() throws ConnectionException {
      if (!isProxyOK() || !isRemoteOK())
        return null;
      return m_ConnectionProxy.getConnectionObj();
	  }

    /**
     * @hidden
     *
     * @status hidden
     */
    public int setConnection() throws ConnectionException {
        return setServerConnectionObj ( m_ConnectionObj ) ;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
	  public int setServerConnectionObj( ConnectionObj connectionObj) throws ConnectionException {
      if (!isProxyOK() || !isRemoteOK())
        return CB.FAILURE;
      return m_ConnectionProxy.setConnectionObj( connectionObj );
	  }

	/****************************************************
	 * Generic methods for property Setting from Property Bag
	 ****************************************************/
    /**
     * @hidden
     *
     * @status hidden
     */
	public Property getProperty( String name ) {
		return m_ConnectionObj.getProperty( name );
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public Property[] getProperties() {
		return m_ConnectionObj.getProperties();
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public void setProperty ( Property property ) {
		m_ConnectionObj.setProperty( property );
	}

    /**
     * Set a property on this connection.
     *
     * @param name      The name of the property
     * @param object    The value of the property
     * 
     * For example, to create a file based persistence connection, the user 
     * should set the following name, object pairs as shown below:
     * 
     * setProperty(PSRConstants.STORAGEMANAGER_DRIVER, 
     *             "oracle.dss.persistence.storagemanager.bi.BIFileStorageManagerImpl")
     * setProperty(PSRConstants.INITIAL_PATHNAME, "c:/temp")
     * 
     * @status New
     */
	public void setProperty ( String name, Object object) {
		setProperty ( name, object, MDU.OBJ, MDU.UI_VISIBLE );
	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public void setProperty ( String name, Object object, int dataType, int flags) {
		m_ConnectionObj.setProperty ( name, object, dataType, flags );
	}

    /**
     * @hidden
     *
     * @status hidden
     */
 	public void removeProperty(String name) {
		m_ConnectionObj.removeProperty( name );
 	}

    /**
     * @hidden
     *
     * @status hidden
     */
	public PropertyBag getPropertyBag() {
		return m_ConnectionObj.getPropertyBag();
  }

    /**
     * @hidden
     *
     * @status hidden
     */
  public int setPropertyBag( PropertyBag propertyBag , int keepRemoveFlags ) {
    return m_ConnectionObj.setPropertyBag ( propertyBag, keepRemoveFlags );
  }

	/****************************************************
	 * Short cut methods for property setting
	 ****************************************************/
    /**
     * Retrieves the name of this connection.
     *
     * @return The name of this connection.
     *
     * @status Reviewed
     */
    public String getBeanName() {
  	  return m_ConnectionObj.getName();
    }

    /**
     * Specifies the name of this connection.
     *
     * @param name The name of this connection.
     *
     * @status Reviewed
     */
    public void setBeanName(String name) {
 		  m_ConnectionObj.setName( name );
    }

    /**
     * Retrieves the type of service that this connection is for.
     * This method returns "OlapServer".
     *
     * @return The type of service that this connection is for.
     *
     * @status NeedsChange change "OlapServer" to "OLAPServer"
     * When we support MOLAP, we can add:
     * If this connection is for MOLAP (Multidimensional OLAP), then this
     * method returns "ExpressServer".
     * If this connection is for ROLAP (Relational OLAP), t
     */
    public String getServerType() {
        if(m_ConnectionObj != null)
            return m_ConnectionObj.getServerType();
        return null;
    }

    /**
     * Specifies the type of service that this connection is for.
     *
     * @param serverType
     *        "OlapServer" for a ROLAP (Relational OLAP) connection.
     *
     * @status NeedsChange Change "OlapServer" to "OLAPServer"
     * "ExpressServer" for a MOLAP (Multidimensional OLAP) connection,
     */
    public void setServerType( String serverType ) {
  	  m_ConnectionObj.setServerType( serverType );
    }

    /**
     * Retrieves the type of driver that this connection uses.
     * Possible return values are:
     * <p>
     * <ul><li><code>MDU.MDM</code> for a MetadataManager connection</li>
     * <li><code>MDU.PERSISTENCE</code> for a connection to the persistence service</li>
     * </ul>
     * @return The type of driver that this connection uses.
     *
     * @see oracle.dss.metadataUtil.MDU#MDM
     * @see oracle.dss.metadataUtil.MDU#PERSISTENCE
     *
     * @status Reviewed
     */
    public String getDriverType() {
      return m_ConnectionObj.getDriverType();
    }

    /**
     * Specifies the type of driver that this connection uses.
     *
     * @param driverType A constant that indicates the type of driver for
     *                   this connection. Valid constants are listed in the
     *                   See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#MDM
     * @see oracle.dss.metadataUtil.MDU#PERSISTENCE
     *
     * @status Reviewed
     */
    public void setDriverType( String driverType ) {
      m_ConnectionObj.setDriverType( driverType );
      if (driverType.equals(MDU.PERSISTENCE) && m_handler == null)
      {
        // need to set this up for Persistence acl operations
        //if (m_session != null && m_session.getBIUser() != null)
        //    setProperty(javax.naming.Context.SECURITY_PRINCIPAL, m_session.getBIUser().getName(), MDU.STRING, MDU.UI_VISIBLE);
            
        try {
          m_handler = (ConnectionHandler)Class.forName("oracle.dss.connection.client.handlers.persistence.PersistenceConnectionHandler").newInstance();
        }
        catch (Exception e) {
          // log the error message!
        }
      }
    }

    /**
     * Retrieves the status of this connection.
     *
     * @return  A constant that represents the status of this connection.
     *          Possible values are listed in the See Also section.
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.connection.common.CB#CONNECTING
     *
     * @status Reviewed
     */
    public int getConnectionStatus() {
        if(m_ConnectionObj != null)
            return m_ConnectionObj.getConnectionStatus();
        else
            return CB.NOT_CONNECTED;
    }

    /**
     * Specifies the current status of this connection.
     *
     * @param status A constant that represents the status of this connection.
     *         Valid values are listed in the See Also section.
     *
     * @see oracle.dss.connection.common.CB#CONNECTED
     * @see oracle.dss.connection.common.CB#NOT_CONNECTED
     * @see oracle.dss.connection.common.CB#CONNECTING
     *
     * @status Reviewed
     */
    public void setConnectionStatus( int status ) {
  	  m_ConnectionObj.setConnectionStatus( status );
    }

    /**
     * @hidden
     * Retrieves the connection string.
     * The connection string is the string that was used to connect to the
     * server.
     *
     * @return The connection string for this connection.
     *
     * @status hidden
     */
    public String getConnectionString() {
  	  return m_ConnectionObj.getConnectionString();
    }

    /**
     * @hidden
     * Specifies the string to use to connect.
     * The string should be a valid connection string for the server to which
     * this connection connects.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the connection string from the DAD.
     *
     * @param connectionString The connection string for this connection.
     *
     * @status hidden
     */
    public void setConnectionString(String connectionString) {
  	  m_ConnectionObj.setConnectionString(connectionString);
    }

/*
    public String getServerUrl() {
        return m_ConnectionObj.getStrPropertyValue(CB.SERVER_URL);
    }

    public void setServerUrl(String serverUrl) {
        m_ConnectionObj.setStrPropertyValue(CB.SERVER_URL, serverUrl);
    }
*/

    /**
     * Retrieves the user name for this connection.
     *
     * @return  The user name for this connection.
     *
     * @status Reviewed
     */
    public String getUsername() {
        if(m_ConnectionObj != null)
            return m_ConnectionObj.getUsername();
        return null;
    }

    /**
     * Specifies the user name for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the user name from the DAD.
     *
     * @param username The user name for this connection.
     *
     * @status Reviewed
     */
    public void setUsername(String username) {
  	  m_ConnectionObj.setUsername(username);
    }

    /**
     * Retrieves the password for this connection.
     *
     * @return  The password for this connection.
     *
     * @status Reviewed
     */
    public String getPassword() {
  	  return m_ConnectionObj.getPassword();
    }

    /**
     * Specifies the password for this connection.
     * <P>
     * If you use single sign-on, you do not need to call this method.
     * The connection retrieves the password from the DAD.
     *
     * @param password The password for this connection.
     *
     * @status Reviewed
     */
    public void setPassword(String password) {
  	  m_ConnectionObj.setPassword(password);
    }

    /**
     * Retrieves the service name for this connection.
     *
     * @return  The service name for this connection.
     *
     * @status Reviewed
     */
    public String getService() {
      return m_ConnectionObj.getStrPropertyValue(CB.SERVICE);
    }

    /**
     * Specifies the service name for this connection.
     *
     * @param service The service name for this connection.
     *
     * @status Reviewed
     */
    public void setService(String service) {
      m_ConnectionObj.setStrPropertyValue(CB.SERVICE, service);
    }

    /**
     * Retrieves the host name for this connection.
     *
     * @return  The host name for this connection.
     *
     * @status Reviewed
     */
    public String getHostName() {
      return m_ConnectionObj.getStrPropertyValue(CB.HOSTNAME);
    }

    /**
     * Specifies the host name for this connection.
     *
     * @param hostname The host name for this connection.
     *
     * @status Reviewed
     */
    public void setHostName(String hostname) {
      m_ConnectionObj.setStrPropertyValue(CB.HOSTNAME, hostname);
    }

    /**
     * Retrieves the port number for this connection.
     *
     * @return  The port number for this connection.
     *
     * @status Reviewed
     */
    public int getPortNumber() {
      String _port = m_ConnectionObj.getStrPropertyValue(CB.PORT);
      if (_port == null)
        return -1;
      else
        return Integer.parseInt(_port);
    }

    /**
     * Specifies the port number for this connection.
     *
     * @param port The port number for this connection.
     *
     * @status Reviewed
     */
    public void setPortNumber(int port) {
      m_ConnectionObj.setStrPropertyValue(CB.PORT, Integer.toString(port));
    }

    /**
     * Retrieves the Oracle SID for this connection.
     *
     * @return  The Oracle SID for this connection.
     *
     * @status Reviewed
     */
    public String getSID() {
      return m_ConnectionObj.getStrPropertyValue(CB.SID);
    }

    /**
     * Specifies the Oracle SID for this connection.
     *
     * @param sid The Oracle SID for this connection.
     *
     * @status Reviewed
     */
    public void setSID(String sid) {
      m_ConnectionObj.setStrPropertyValue(CB.SID, sid);
    }

    /**
     * Retrieves the JDBC URL for this connection.
     *
     * @return The JDBC URL for this connection.
     *
     * @status Reviewed
     */
    public String getJdbcUrl() {
        return m_ConnectionObj.getStrPropertyValue(CB.JDBC_URL);
    }

    /**
     * Specifies the JDBC URL for this connection.
     * The URL is currently only used by an OLAP service connection
     * The URL should use the following syntax.
     * <pre>
     * jdbc:oracle:[Protocol]:@[Host]:[Jdbc Port]:[Database Sid]
     * </pre>
     *
     * @param jdbcUrl The JDBC URL for this connection.
     *
     * @status Reviewed
     */
    public void setJdbcUrl(String jdbcUrl) {
        m_ConnectionObj.setStrPropertyValue(CB.JDBC_URL, jdbcUrl);
    }

    /**
     * Retrieves the name of the OLAP service.
     *
     * @return  The name of the OLAP service.
     *
     * @status Reviewed
     */
    public String getOLAPServiceName() {
        return m_ConnectionObj.getStrPropertyValue(CB.OLAP_SERVICE);
    }

    /**
     * Specifies the name of the OLAP service.
     *
     * @param olapService The name of the OLAP service.
     *
     * @status Reviewed
     */
    public void setOLAPServiceName(String olapService) {
        m_ConnectionObj.setStrPropertyValue(CB.OLAP_SERVICE, olapService);
    }

    /**
     * Retrieves the type of JDBC driver used to connect to the OLAP service.
     *
     * @return  The type of JDBC driver used to connect to the OLAP service.
     *
     * @status Reviewed
     */
    public String getJdbcDriverType() {
        return m_ConnectionObj.getStrPropertyValue(CB.JDBC_TYPE);
    }

    /**
     * Specifies the type of JDBC driver used to connect to the OLAP service.
     * For an OLAP connection, the default is "thin".
     * For a connection to the BI Beans Catalog, the default is "oci8".
     *
     * @param driverType The type of JDBC driver used to connect to the OLAP service.
     *                   Valid values are "thin" and "oci8".
     *
     * @status Reviewed
     */
    public void setJdbcDriverType(String driverType) {
        m_ConnectionObj.setStrPropertyValue(CB.JDBC_TYPE, driverType);
    }

	/****************************************************
	 * Unpublished public Methods
	 ****************************************************/
    /**
     * @hidden
     *
     * @status hidden
     */
    public boolean isRemoteOK() {
		  return m_IsRemoteOK;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
	public int setRemoteOK( boolean isRemoteOK ) {
		m_IsRemoteOK = 	isRemoteOK;
		return CB.SUCCESS;
	}

    /**
     * @hidden
     *
     *  Retrieves connection proxy associated with this connection.
     *  return ConnectionObject proxy.
     *
     * @status hidden
     */
    public ConnectionObject getProxy() {
  		if (isProxyOK())
          	return m_ConnectionProxy;
        return null;
    }

    /**
     * @hidden
     *
     * @status hidden
     */
    public org.omg.CORBA.ORB getORB() throws ConnectionException 
    {
        if(m_orb == null && isProxyOK())
        {
            PropertyBag bag = new PropertyBag();
            bag.setStrPropertyValue("ORB", CB.ORB);
            m_orb = (org.omg.CORBA.ORB)m_ConnectionProxy.getDriverSpecificObject(bag);
        }
        return m_orb;
    }

    /**
     * Frees all resources that were allocated by this connection.
     * This method disconnects this connection and releases all its resources.
     *
     * @return <code>CB.SUCCESS</code>.
     *
     * @throws ConnectionException If a problem occurs in releasing resources.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status Reviewed
     */
    public int free() throws ConnectionException {
  	  if ( getConnectionStatus() == CB.CONNECTED )
	      disconnect();

      if ( m_ConnectionProxy != null ) {
		    int remoteStatus = m_ConnectionProxy.free();
		    if ( remoteStatus == CB.SUCCESS ) {
          //m_ConnectionProxy.remove();
			    m_ConnectionProxy = null;
        }
		  }

      if ( m_ConnectionObj != null )
        m_ConnectionObj.free();

      m_ConnectionObj = null;
      return CB.SUCCESS;
    }

	/****************************************************
	 * Private Methods
	 ****************************************************/
    /**
     *  Gets the Instance ID.
     *
     * @status private
     */
    private static int getInstanceID() {
  	  return m_InstanceID;
    }

     /**
     * Is the proxy OK?
     *
     * @status private
     */
    private boolean isProxyOK() {
      if ( m_ConnectionProxy == null )
        return false;
      return true;
    }

     /**
     * @status private
     */
    private int initConnection() throws ConnectionException
    {
        if (!isRemoteOK())
		    return CB.FAILURE;

        if (m_session == null)
            throw new ConnectionException(ConnectionClientBundle.class, ConnectionClientBundle.EXC_NO_BISESSION, null, getLocale(), null, "");

        if(m_ConnectionProxy == null)
            m_ConnectionProxy = (ConnectionObject) new oracle.dss.connection.server.ConnectionImpl();


        // Determine if our proxy object already exists
/*        if (m_ConnectionProxy == null)
        {
            // if no application module present, must throw exception
            try
            {
                ApplicationModule _am = m_session.getApplicationModule();
                m_deployMode = (String)_am.getSession().getEnvironment().get(JboContext.DEPLOY_PLATFORM);
                m_ConnectionProxy = (ConnectionObject)_am.createComponentObject(null, "oracle.dss.appmodule.Connection");
            }
            catch (Exception ex)
            {
                throw new ConnectionException(ConnectionClientBundle.class, ConnectionClientBundle.EXC_APPMODULE, null, getLocale(), ex, "");
            }
        }*/
        setConnectionStatus( CB.NOT_CONNECTED );

        if (m_ConnectionProxy != null)
        {
            m_InstanceID ++;
            if(m_deployMode != null
               //&& m_deployMode.equals(oracle.jbo.JboContext.PLATFORM_LOCAL)
               && m_Applet != null)
            {
                m_ConnectionProxy.setApplet(m_Applet);
            }
            m_ConnectionProxy.getConnectionObj().setDriverType(getDriverType());
        }
        return CB.SUCCESS;
    }

   	/****************************************************
	 * Persistable Methods
	 ****************************************************/
    /**
     * @hidden
     * Initializes this connection with the persistence environment.
     * The persistence service calls this method when it loads the
     * connection, so that the connection can use environment properties to
     * initialize itself.
     * Environment properties in the <code>Context</code> interface in
     * JNDI.
     * <P>
     * Application developers do not need to call this method.
     *
     * @param env   Environment properties.
     *
     * @status hidden
     */
    public void initialize(Hashtable env)
    {
        if(env == null)
            return;
        if(env.containsKey(PersistableConstants.PERSISTENCE_ERRORHANDLER))
            addErrorHandler((ErrorHandler)env.get(PersistableConstants.PERSISTENCE_ERRORHANDLER));
        if(env.containsKey(PersistableConstants.PERSISTENCE_LOCALE))
            setLocale((Locale)env.get(PersistableConstants.PERSISTENCE_LOCALE));
        m_remoteConnection = env.get(CB.REMOTE_CONNECTION);
        setSession((BISession)env.get(CB.BISESSION));
    }

    /**
     * @hidden
     * Retrieves a list of <code>Persistable</code> components that this
     * connection aggregates.
     * The Connection bean does not have any aggregates.
     *
     * @return <code>null</code>.
     *
     * @status hidden
     */
    public AggregateInfo[] getPersistableComponents() {
      return null;
    }

    /**
     * @hidden
     * Specifies a list of <code>Persistable</code> components that this
     * connection aggregates.
     * The Connection bean does not have any aggregates, so this method
     * does nothing.
     *
     * @param persistables  An array of <code>AggregateInfo</code>.
     *
     * @status hidden
     */
    public void setPersistableComponents(AggregateInfo[] persistables) {
      // do nothing
    }

    /**
     * @hidden
     * Retrieves the attributes of this connection, for searching.
     * This method adds the attributes that this connection defines to
     * any attributes that the application has defined.
     * The attributes are used by the persistence service, when users
     * search the repository for components that have particular attribute
     * values.
     *
     * @param attrs The searchable attributes that the application has
     *              defined for this component.
     *
     * @return The full set of attributes for this connection.
     *
     * @status hidden
     */
    public PersistableAttributes getPersistableAttributes(PersistableAttributes attrs) {
        PersistableAttributes _attrs = null;

        if (attrs != null)
            _attrs = attrs;
        else
            _attrs = new PersistableAttributes();

        _attrs.setObjectType(PersistableConstants.CONNECTION);
        _attrs.setObjectTypeVersion(s_xmlVersion);
        _attrs.setCompSubType1(getDriverType());
        if (getConnectionString() != null)
            _attrs.setCompSubType2(getConnectionString());
        
        return _attrs;
    }

    /**
     * @hidden
     * Specifies attributes that can be used for searching in the repository.
     * This implementation does nothing.
     *
     * @param attrs Any <code>PersistableAttributes</code>.
     *
     * @status hidden
     */
    public void setPersistableAttributes(PersistableAttributes attrs)
    {
        // do nothing
    }

    /**
     * Retrieves the XML representation of this connection.
     * This method is called by the persistence service when you save the
     * connection to the repository.
     * Application developers should not need to call this method.
     *
     * @return The XML representation of this connection.
     *
     * @throws BIPersistenceException If a problem occurs in getting the
     *          XML.
     *
     * @status Reviewed
     */
    public String getXMLAsString() throws BIPersistenceException
    {
        ObjectNode _root = new ObjectNode(s_xmlNameTag);

        if (getDriverType().equals(MDU.MDM))
        {
            _root.addProperty("DriverType", MDU.MDM);
            _root.addProperty("ServerType", getServerType());

            if (getUsername() != null)
                _root.addProperty("UserName", getUsername());
            if (getPassword() != null)
                _root.addProperty("Password", getPassword());
            if (getService() != null)
                _root.addProperty("Service", getService());
            if (getHostName() != null)
                _root.addProperty("HostName", getHostName());
            if (getPortNumber() != -1)
                _root.addProperty("PortNumber", getPortNumber());
            if (getSID() != null)
                _root.addProperty("SID", getSID());
            if (getJdbcUrl() != null)
                _root.addProperty("JdbcUrl", getJdbcUrl());
            if (getJdbcDriverType() != null)
                _root.addProperty("JdbcDriverType", getJdbcDriverType());
            if (getOLAPServiceName() != null)
                _root.addProperty("OLAPServiceName", getOLAPServiceName());
        }
        else if (getDriverType().equals(MDU.PERSISTENCE))
        {
            _root.addProperty("DriverType", MDU.PERSISTENCE);

            if (getUsername() != null)
                _root.addProperty("UserName", getUsername());
            if (getPassword() != null)
                _root.addProperty("Password", getPassword());
            if (getService() != null)
                _root.addProperty("Service", getService());
            if (getHostName() != null)
                _root.addProperty("HostName", getHostName());
            if (getPortNumber() != -1)
                _root.addProperty("PortNumber", getPortNumber());
            if (getSID() != null)
                _root.addProperty("SID", getSID());
            if (getJdbcDriverType() != null)
                _root.addProperty("JdbcDriverType", getJdbcDriverType());
            if (getPersistenceInfo("sm_driver") != null)
                _root.addProperty("StorageManagerDriver", getPersistenceInfo("sm_driver"));
            if (getPersistenceInfo("path") != null)
                _root.addProperty("InitialPath", getPersistenceInfo("path"));
            if (getPersistenceInfo("zip") != null)
            {
                _root.addProperty("ZipFile", getPersistenceInfo("zip"));
                if (getPersistenceInfo("path") != null)
                    _root.addProperty("ZipPath", getPersistenceInfo("path"));
            }
        }
        else
            return null;

        String _xml = null;

        try
        {
            XMLObjectWriter _writer = new XMLObjectWriter();
            _writer.setIndentEnabled(true);
            _writer.writeObjectNode(_root);
            _xml = _writer.toString();
        }
        catch (BIXMLException pe)
        {
            throw new BIPersistenceException(pe.getLocalizedMessage() , pe);
        }

        return _xml;
    }

    /**
     * Specifies the XML representation of this connection.
     * The persistence service calls this method when the connection is
     * restored from the repository.
     * Application developers should not need to call this method.
     *
     * @param name  The XML representation of this connection.
     * @return <code>true</code> the XML was successfully set,
     *         <code>false</code> if not.
     *
     * @throws BIPersistenceException If a problem occurs in setting the XML.
     *
     * @status Reviewed
     */
    public boolean setXMLAsString(String xml) throws BIPersistenceException
    {
        try
        {
            XMLObjectReader _reader = new XMLObjectReader(xml);
            ObjectNode _node = _reader.readObjectNode();
            setDriverType(_node.getPropertyValueAsString("DriverType"));

            if (getDriverType().equals(MDU.MDM))
            {
                setServerType(_node.getPropertyValueAsString("ServerType"));

                PropertyNode _prop = _node.getProperty("UserName");
                if (_prop != null)
                    setUsername(_prop.getValueAsString());

                _prop = _node.getProperty("Password");
                if (_prop != null)
                    setPassword(_prop.getValueAsString());

                _prop = _node.getProperty("Service");
                if (_prop != null)
                    setService(_prop.getValueAsString());

                _prop = _node.getProperty("HostName");
                if (_prop != null)
                    setHostName(_prop.getValueAsString());

                _prop = _node.getProperty("PortNumber");
                if (_prop != null)
                    setPortNumber(_prop.getValueAsInteger());

                _prop = _node.getProperty("SID");
                if (_prop != null)
                    setSID(_prop.getValueAsString());

                _prop = _node.getProperty("JdbcUrl");
                if (_prop != null)
                    setJdbcUrl(_prop.getValueAsString());

                _prop = _node.getProperty("JdbcDriverType");
                if (_prop != null)
                    setJdbcDriverType(_prop.getValueAsString());

                _prop = _node.getProperty("OLAPServiceName");
                if (_prop != null)
                    setOLAPServiceName(_prop.getValueAsString());
            }
            else if (getDriverType().equals(MDU.PERSISTENCE))
            {
                PropertyNode _prop = _node.getProperty("UserName");
                if (_prop != null)
                    setUsername(_prop.getValueAsString());

                _prop = _node.getProperty("Password");
                if (_prop != null)
                    setPassword(_prop.getValueAsString());

                _prop = _node.getProperty("Service");
                if (_prop != null)
                    setService(_prop.getValueAsString());

                _prop = _node.getProperty("HostName");
                if (_prop != null)
                    setHostName(_prop.getValueAsString());

                _prop = _node.getProperty("PortNumber");
                if (_prop != null)
                    setPortNumber(_prop.getValueAsInteger());

                _prop = _node.getProperty("SID");
                if (_prop != null)
                    setSID(_prop.getValueAsString());

                _prop = _node.getProperty("JdbcDriverType");
                if (_prop != null)
                    setJdbcDriverType(_prop.getValueAsString());

                _prop = _node.getProperty("StorageManagerDriver");
                if (_prop != null)
                    setProperty("sm_driver", _prop.getValueAsString(), MDU.STRING, MDU.UI_VISIBLE);

                _prop = _node.getProperty("InitialPath");
                if (_prop != null)
                    setProperty("path", _prop.getValueAsString(), MDU.STRING, MDU.UI_VISIBLE);

                _prop = _node.getProperty("ZipFile");
                if (_prop != null)
                    setProperty("zip", _prop.getValueAsString(), MDU.STRING, MDU.UI_VISIBLE);

                _prop = _node.getProperty("ZipPath");
                if (_prop != null)
                    setProperty("path", _prop.getValueAsString(), MDU.STRING, MDU.UI_VISIBLE);

                if (m_remoteConnection != null)
                    setRemoteConnection(m_remoteConnection);
            }
            else
            {
                // log some message here
                return false;
            }

            if (isConnected())
                disconnect();

            connect();
        }
        catch (BIXMLException ioe)
        {
            throw new BIPersistenceException(ioe.getLocalizedMessage(), ioe);
        }
        catch (NoSuchPropertyException npe)
        {
            throw new BIPersistenceException(npe.getLocalizedMessage(), npe);
        }
        catch (ConnectionException ce)
        {
            throw new BIPersistenceException(ce.getLocalizedMessage(), ce);
        }

        return true;
    }


    /**
     * @hidden
     * (no need for @hidden - this is a private method; we only expose public)
     */
    private String getPersistenceInfo(String name)
    {
		Property _prop = m_ConnectionObj.getProperty(name);
        if (_prop != null)
            return _prop.getStrValue();
        else
            return null;
    }

    /**
     * @hidden for now
     */
    /*
  	public String getPersistenceUsername()
    {
		return getPersistenceInfo(oracle.dss.security.BISecurityConstants.USERNAME);
	}
*/
    /**
     * @hidden for now
     */
/*
  	public String getPersistencePassword()
    {
        return getPersistenceInfo(oracle.dss.security.BISecurityConstants.PASSWORD);
	}
*/
    /**
     * @hidden for now
     */
  	public String getPersistenceService()
    {
		return getPersistenceInfo("service");
	}

    /**
     * @hidden
     */
    public Object getRemoteConnectionLocal()
    {
        return m_remoteConnection;
    }

    /**
     * @hidden for now
     */
    public Object getRemoteConnection()
    {
        if (m_remoteConnection != null)
            return m_remoteConnection;

        Object _proxy = m_ConnectionProxy.getRemoteConnection();
        if (_proxy != null)
        {
            if (m_handler != null)
            {
                PropertyBag _bag = getPropertyBag();
                if (_bag != null)
                {
                    _bag.setObjPropertyValue(CB.BISESSION, getSession());
                    _bag.setObjPropertyValue(CB.ERROR_HANDLER, m_eh);
                    _bag.setObjPropertyValue(CB.LOCALE, getLocale());
                }
                Object _remoteCon = m_handler.handleGetRemoteConnection(_proxy, getPropertyBag());
                m_remoteConnection = _remoteCon;
                return _remoteCon;
            }
            else
                return null;
        }
        else
            return null;
    }

    /**
     * @hidden for now
     */
    public void setRemoteConnection(Object remoteConnection)
    {
        Object _proxy = null;
        if (remoteConnection != null)
        {
            m_remoteConnection = remoteConnection;
            if (m_handler != null)
                _proxy = (Object)m_handler.handleSetRemoteConnection(remoteConnection, getPropertyBag());
        }

        if (isConnected())
            m_ConnectionProxy.setRemoteConnection(_proxy);
        else
            setProperty(CB.REMOTE_CONNECTION, _proxy, MDU.OBJ, MDU.UI_NONE);

        m_remoteConnectionUsed = true;
    }

    /**
     * @hidden
     * Fixed bug 3714849 (D4O bug)
     * This flag is used by getObjectFactory method in MetadataManager
     */
    public boolean isRemoteConnectionUsed()
    {
        return m_remoteConnectionUsed;
    }

    /**
     * @hidden
     */
    public void setLoadParameter(String loadType)
    {
        Property prop = new Property();
        prop.setStrValue(MDU.LOAD_TYPE, loadType, MDU.UI_NONE);
        m_ConnectionObj.setProperty(prop);
    }

    /**
     * @hidden
     */
    public String getLoadParameter()
    {
        Property prop = m_ConnectionObj.getProperty(MDU.LOAD_TYPE);
        if(prop != null)
        {
            return prop.getStrValue();
        }
        return null;
    }

    /**
     * @hidden
     * Set ErrorHandler on Connection
     *
     * @param errHandler    ErrorHandler that needs to be set on Connection
     *
     * @status hidden
     */
    public void addErrorHandler(ErrorHandler errHandler)
    {
        m_eh = errHandler;
        if(isProxyOK())
        {
            PropertyBag propBag = new PropertyBag();
            propBag.setStrPropertyValue("ErrorHandler", "add");
            try{
                m_ConnectionProxy.setDriverSpecificObject(m_eh, propBag);
            }
            catch(ConnectionException mme)
            {
                m_eh.error(mme, getClass().getName(), "addErrorHandler");
            }
        }
    }

    /**
     * @hidden
     * Remove currently set error handler and set it back to DefaultErrorHandler
     *
     * @status hidden
     */
    public void removeErrorHandler()
    {
        m_eh = new DefaultErrorHandler();
        if(isProxyOK())
        {
            PropertyBag propBag = new PropertyBag();
            propBag.setStrPropertyValue("ErrorHandler", "remove");
            try{
                m_ConnectionProxy.setDriverSpecificObject("Default", propBag);
            }
            catch(ConnectionException mme)
            {
                m_eh.error(mme, getClass().getName(), "removeErrorHandler");
            }
        }
    }

    /**
     * Specifies the locale that this <code>Connection</code> uses.
     *
     * @param locale    The <code>Locale</code> for this
     *                   <code>Connection</code>.
     *
     * @status Reviewed
     */
    public void setLocale(Locale locale)
    {
        if (locale != null)
        {
            m_Locale = locale;
            if (m_ConnectionProxy != null)
                m_ConnectionProxy.setLocale( locale );
            else
                m_ConnectionObj.setObjPropertyValue("locale", m_Locale);
        }
    }

    /**
     * Retrieves the locale that this <code>MetadataManager</code> uses.
     *
     * @return The locale for this <code>MetadataManager</code> uses.
     *
     * @status Reviewed
     */
    public Locale getLocale()
    {
        if (m_Locale == null)
            return Locale.getDefault();
        else
            return m_Locale;
    }

    /**
     * Indicates whether the CORBA stub can still talk to Oracle OLAP through
     * the ORB and has not timed out.
     *
     * @return <code>true</code> if the CORBA stub is viable.
     *         <code>false</code> if the CORBA stub is dead.
     *
     * @status Reviewed
     */
    public boolean isAlive()
    {
      return m_ConnectionProxy != null ?  m_ConnectionProxy.isAlive() : false;
    }

    /**
     * Reconnects this <code>Connection</code>.
     *
     * @param reconnectParams Properties for reconnecting. Valid constants
     *                        for an OLAP connecton are listed in the
     *                        See Also section.
     *
     * @throws ConnectionException If there is a problem during the reconnection.
     *
     * @see oracle.dss.connection.common.CB#USERNAME
     * @see oracle.dss.connection.common.CB#PASSWORD
     * @see oracle.dss.connection.common.CB#HOSTNAME
     * @see oracle.dss.connection.common.CB#PORT
     * @see oracle.dss.connection.common.CB#SID
     * @see oracle.dss.connection.common.CB#SERVER_TYPE
     * @see oracle.dss.metadataUtil.MDU#DRIVER_TYPE
     *
     * @status Reviewed
     */
    public int reconnect( PropertyBag reconnectParams) throws ConnectionException {
        Property[] props = null;
        if(reconnectParams != null)
        {
          props = reconnectParams.getProperties();
        }

        for(int i = 0; props != null && i < props.length ; i++)
        {
          getPropertyBag().setProperty(props[i]);
        }
        disconnect();
        return connect(reconnectParams);
    }

    /**
     * This method validates the internal connection version.
     * This method verifies the OLAP connection against the version of the
     * OLAP API.
     * It verifies the connection to the BI Beans Catalog against the version
     * of the Catalog schema and the Java version.
     *
     * @return <code>true</code>  if the version is valid,
     *         <code>false</code> if it is not.
     *
     * @status Reviewed
     */
    public boolean verifyVersion()
    {
        int _flag = m_ConnectionObj.getIntPropertyValue(CB.VERSION);

        if(_flag == CB.NOT_VALID)
            return false;
        else
            return true;
    }

    public PropertyBag getVersionInfo()
    {
        if(isProxyOK())
            return getProxy().getVersionInfo();

        PropertyBag _bag = new PropertyBag();
        String _beanVersion = VersionInfo.getProperty(this, VersionInfo.BUILD_VERSION);
        if(_beanVersion != null)
            _bag.setStrPropertyValue(CB.CONNECTION_BEAN_VERSION, _beanVersion);

        return _bag;
    }

    /**
     * Retrieve the connection object used by the connection bean to communicate
     * with the underlying datasource.
     * 
     * @return the connection object.
     * @throws ConnectionException if the connection bean is in disconnected
     *         state or if the connection bean is running in multi-tier mode.
     * @status New
     */
    public Object getConnectionObject() throws ConnectionException
    {
        if(!isConnected())
            throw new ConnectionException(ConnectionClientBundle.class,
                                          ConnectionClientBundle.EXC_CONNECT_NOT_INITIALIZED,
                                          null,
                                          getLocale(),
                                          null,
                                          MDU.MDM);

        //if(m_session != null && BISession.LOCAL.equals(m_session.getDeploymentOption()))
        //{
            PropertyBag bag = new PropertyBag();
            bag.setStrPropertyValue(CB.CONNECTION, "");
            return getDriverSpecificObject(bag);
        //}
        //else
        /*
            throw new ConnectionException(ConnectionClientBundle.class,
                                          ConnectionClientBundle.EXC_NON_SERIALIZABLE_OBJ,
                                          null,
                                          getLocale(),
                                          null,
                                          MDU.MDM);
        */
    }

    /**
     * Set the connection object on the connection bean.  The connection object
     * should be set before calling the connect method on the connection bean.
     * 
     * @throws ConnectionException if the connection bean is in connected state.
     * @status New
     */
    public void setConnectionObject(Object object) throws ConnectionException
    {
        if(isConnected())
        {
            throw new ConnectionException(ConnectionClientBundle.class,
                                          ConnectionClientBundle.EXC_SET_CONN_OBJ_FAILED,
                                          null,
                                          getLocale(),
                                          null,
                                          MDU.MDM);
        }
        m_ConnectionObj.setObjPropertyValue(CB.CONNECTION, object);
        if(object != null) setConnectionString(object.toString());
    }

    /**
     * @hidden
     */
    public boolean getFeature(String feature)
    {
        if (m_ConnectionProxy != null)
            return m_ConnectionProxy.getFeature(feature);
        else
            return false;
    }

    /**
     * Set the driverType and register the driver implementation for the 
     * specified the driverType.  This driver will be used to establish
     * the connection
     *
     * @param driverType String associated with the ConnectionDriver.
     * @param driverImpl String representing the fully qualified class name of the
     *                   ConnectionDriver implementation.  The connection bean will
     *                   instantiate the class at connect time.
     */
    public void setDriverImpl(String driverType, String driverClassName)
    {
        if(driverType != null && driverClassName != null) {
            setDriverType(driverType);
            m_driverImpl.put(driverType, driverClassName);
        }
    }
    
    /**
     * List the drivers associated with the connection bean
     *
     * @return Hashtable containing properties where the driverType is the key
     * and driverImpl class name is the value.
     */
    public Hashtable listDriverImpl()
    {
        return (Hashtable)m_driverImpl.clone();
    }

    /**
     * Retrieve the driver associated with the specified drivertype from the connection bean.  
     *
     * @param driverType String associated with the ConnectionDriver.
     * @return String representing the driver class name
     */
    public String getDriverImpl(String driverType)
    {
        return (String)m_driverImpl.get(driverType);
    }

    /**
     * De-register the driver from the connection bean.
     *
     * @param driverType String associated with the ConnectionDriver that should be removed.
     */
    public void removeDriverImpl(String driverType)
    {
        if(driverType != null)
            m_driverImpl.remove(driverType);
    }
    
    /**
     * @hidden
     */
    public void setRoot(MDFolder root)
    {
        m_root = root;
    }
    
    public MDFolder getRoot() throws ConnectionException
    {
        if(m_root == null)
        {
            MDFolder s_root = (MDFolder)m_ConnectionObj.getObjPropertyValue(CB.SUPER_ROOT);
            String r_name = (String)m_ConnectionObj.getObjPropertyValue(CB.ROOT_NAME);
            if(m_connectionKey != null && s_root != null)
            {
                m_root = (MDFolder)m_ConnectionObj.getObjPropertyValue(CB.ROOT_FOLDER);
                /*
                try
                {
                    //m_root = (MDFolder)s_root.lookup("metadata/" + r_name);
                    m_root = (MDFolder)m_ConnectionObj.getObjPropertyValue(CB.ROOT_FOLDER);
                }
                catch(NamingException e)
                {
                    e.printStackTrace();
                }
                */
            }
        }
        return m_root;
    }
    
    public void setConnectionKey(String key)
    {
        m_connectionKey = key;
    }
    
    public String getConnectionKey()
    {
        return m_connectionKey;
    }

/*    private UsernamePasswordServiceCredentials getServiceCredentials()
    {
        UsernamePasswordServiceCredentials _serviceCredentials = null;
        if(m_ConnectionObj != null)
        {
            //ConnectSettings _settings = (ConnectSettings)m_ConnectionObj.getObjPropertyValue(CB.CONNECT_SETTINGS);
//            if(_settings != null)
            //{
                String _user = (String)m_ConnectionObj.getStrPropertyValue(Context.SECURITY_PRINCIPAL);
                String _pass = (String)m_ConnectionObj.getStrPropertyValue(Context.SECURITY_CREDENTIALS);
                if(_user != null && _pass != null)
                    _serviceCredentials = new UsernamePasswordServiceCredentials(_user, _pass.toCharArray());
            //}
        }
        return _serviceCredentials;
    }*/
    
    public String getDatasourceType()
    {
        String _str = m_ConnectionObj.getStrPropertyValue(CB.DATASOURCE_TYPE);
        if(_str == null)
            _str = CB.PERSISTENCE;
        return _str;
    }
}
