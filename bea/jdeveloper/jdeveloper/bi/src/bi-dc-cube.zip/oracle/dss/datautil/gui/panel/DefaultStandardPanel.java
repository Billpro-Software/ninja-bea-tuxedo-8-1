/**
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.panel;

import java.awt.Image;
import java.awt.Component;

import java.util.BitSet;
import java.util.EventObject;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import javax.swing.event.EventListenerList;

import oracle.dss.datautil.client.DataUtilException;

import oracle.dss.datautil.ExceptionListener;

import oracle.dss.datautil.gui.BuilderCombo;
import oracle.dss.datautil.gui.BuilderContext;
import oracle.dss.datautil.gui.ExceptionListenerGui;
import oracle.dss.datautil.gui.panel.event.PanelEventListener;

import oracle.dss.util.ErrorHandler;
import oracle.dss.util.help.HelpContext;

/**
 * A default standard panel. Used as the superclass for many of the
 * CalcBuilder and QueryBuilder panels. If you want to add a custom panel, then 
 * you can extend <code>DefaultStandardPanel</code> rather than implementing 
 * the entire <code>StandardPanel</code> interface.
 *
 * @status documented
 */
public abstract class DefaultStandardPanel extends JPanel
                                           implements StandardPanel, HelpContext {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   *
   * Marks this panel as being in the process of being initialized.
   *
   * @status Documented
   */
  protected boolean m_bIsInitializing = false;

  /**
   * @hidden
   *
   * Indicates whether this panel state is dirty. Default is
   * <code>false</code>.
   *
   * @status Documented
   */
  public final static int PANELSTATE_ISDIRTY = 0;

  /**
   * @hidden
   *
   * Indicates whether this panel state is enabled. Default is
   * <code>true</code>.
   *
   * @status Documented
   */
  public final static int PANELSTATE_ENABLED = 1;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * @hidden
   *
   * The panel states.
   *
   * @status protected
   */
  protected BitSet m_panelState = null;

  /**
   * @hidden
   *
   * Has the UI been initialized.
   *
   * @status protected
   */
  protected boolean m_bIsUIInited = false;

  /**
   * @hidden
   *
   * The BuilderContext instance for this panel.
   *
   * @status protected
   */
  protected BuilderContext m_builderContext = null;

  /**
   * @hidden
   *
   * Reference to the container object.
   * 
   * @status protected
   */
  protected Component m_container = null;

  /**
   * @hidden
   *
   * List of panel event listeners.
   * 
   * @status protected
   */
  protected EventListenerList m_listenerList = new EventListenerList ();

  /**
   * @hidden
   *
   * The panel content.
   *
   * @status protected
   */
  protected Object m_panelContent = null;
  
  /**
   * @hidden
   *
   * The Help context id.
   *
   * @status protected
   */
  protected String m_helpContextId = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor.
   *
   * @status Documented
   */
  public DefaultStandardPanel() {
    super ();
    initializeMembers ();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  //-----------------------------------------------------------------------
  // Begin - Implentation of StandardPanel interface.
  //-----------------------------------------------------------------------

  /**
   * Adds a listener for panel events.
   *
   * @param listener The listener for the panel events.
   *
   * @status Documented
   */
  public void addPanelEventListener (PanelEventListener listener) {
    m_listenerList.add (PanelEventListener.class, listener);
  }

  /**
   * Cleans up any resources that were allocated by this panel.
   *
   * @status Documented
   */
  public void cleanup() {
    m_builderContext = null;
  }

  /**
   * Retrieves the <code>BuilderContext</code> object that is associated with 
   * this panel.
   *
   * @return The <code>BuilderContext</code> object.
   *
   * @status Documented
   */
  public BuilderContext getBuilderContext() {
    return m_builderContext;
  }

  /**
   * Retrieves the component that is associated with this panel.
   *
   * @return The component for this panel.
   *
   * @status Documented
   */
  public Component getComponent() {
    return this;
  }

  /**
   * Retrieves the container that is associated with this panel.
   *
   * @return The container that is associated with this panel.
   *
   * @status Documented
   */
  public Component getContainer() {
    return m_container;
  }

  /**
   * Retrieves the identifier for this panel.
   *
   * @return The identifier for this panel.
   *
   * @status Documented
   */
  abstract public String getId ();

  /**
   * Retrieves the image for this panel. Typically this image is displayed
   * on the left side of a wizard.
   *
   * @return The image to be displayed for this panel.
   *
   * @status Documented
   */
  public Image getImage() {
    return null;
  }

  /**
   * Retrieves the image icon for this panel.
   *
   * @return The icon that is to be displayed for this
   *         panel.
   *
   * @status Documented
   */
  public ImageIcon getImageIcon() {
    return null;
  }

  /**
   * Retrieves the content of this panel.
   *
   * @return The panel content.
   *
   * @status Documented
   */
  public Object getPanelContent() {
    return m_panelContent;
  }

  /**
   * Retrieves the title of this panel.
   *
   * @return The panel title.
   *
   * @status Documented
   */
  public String getTitle() {
    return null;
  }

  /**
   * Indicates whether the view is marked as being in the process of 
   * being initialized.
   *
   * @return <code>true</code> if the view is marked as in the process of being
   * initialized, <code>false</code> otherwise.
   *
   * @status Documented
   */
  public boolean isInitializing() {
    return m_bIsInitializing;
  }

  /**
   * Specifies whether the view is to be marked as being in the process of 
   * being initialized.
   *
   * @param bInitializing <code>true</code> if the view is to be marked as in the
   * process of being initialized, <code>false</code> otherwise.
   *
   * @status Documented
   */
  public void setInitializing (boolean bInitializing) {
    m_bIsInitializing = bInitializing;
  }

  //-------------------------------------------------------------------
  // Start Implementation of HelpContext interface
  //-------------------------------------------------------------------

  /**
   * Retrieves the Help context ID for this panel.
   * The default Help context ID is the full class path for this panel.
   * To set a different Help context ID, use the method
   * <code>setHelpContextID(String)</code>.
   *
   * The Help context ID that is used when listening for the user event
   * that requests the display of Help for this panel.
   *
   * @return The Help context ID for this panel
   *
   * @status Documented
   */
  public String getHelpContextID() {
    // If the Help context ID has been set by the application developer,
    // use that context ID, otherwise use the class name
    if (m_helpContextId != null) {
      return (m_helpContextId);
    }

    return this.getClass().getName();
  }

  /**
   * Specifies the Help context ID for this panel.
   * This Help context ID is used when listening for the user event
   * that requests the display of Help for this panel.
   *
   * @param helpContextId   The Help context ID for this panel.
   *
   * @status Documented
   */
  public void setHelpContextID (String helpContextId) {
    m_helpContextId = helpContextId;
  }

  //-------------------------------------------------------------------
  // End Implementation of HelpContext interface
  //-------------------------------------------------------------------

  /**
   * Removes a listener for the panel events.
   *
   * @param listener The listener for the panel events.
   *
   * @status Documented
   */
  public void removePanelEventListener (PanelEventListener listener) {
    m_listenerList.remove (PanelEventListener.class, listener);
  }

  /**
   * Specifies whether the panel is to be active or inactive.
   *
   * @param bIsActive <code>true</code> if the panel
   *                  is to be active; <code>false</code> if the panel
   *                  is to be inactive.
   *
   * @return <code>true</code> if the operation was successful,
   *         <code>false</code> if the operation was not successful.
   *
   * @throws <code>DataUtilException</code> if the operation is unsuccessful.
   *
   * @status Documented
   */
  public boolean setActive (boolean bIsActive) throws DataUtilException {
    boolean bRetVal = false;

    // If the panel has not been initialized and we are invoked with
    // bIsActive = false, return false indicating an error condition.
    if (!m_bIsUIInited && !bIsActive)
      return false;

    if (!m_bIsUIInited) {
      bRetVal = initUIContent ();

      if (!bRetVal) {
        // Remove all elements from the panel.
        removeAll ();
        return bRetVal;
      }

      m_bIsUIInited = true;
    }

    return updateData (bIsActive);
  }

  /**
   * Specifies the <code>BuilderContext</code> instance for this panel.
   *
   * @param The <code>BuilderContext</code> instance.
   *
   * @status documented
   */
  public void setBuilderContext (BuilderContext builderContext) {
    m_builderContext = builderContext;
  }

  /**
   * Specifies the container that is associated with this panel.
   *
   * @param container The container.
   *
   * @status Documented
   */
  public void setContainer (Component container) {
    m_container = container;
  }

  /**
   * Specifies the content for this panel.
   *
   * @param panelContent The panel content.
   *
   * @status Documented
   */
  public void setPanelContent (Object panelContent) {
    m_panelContent = panelContent;
  }

  /**
   * Validates the contents of the panel.
   *
   * @param hintValidate A hint object to help in the validation process.
   *
   * @return <code>true</code> if the operation was successful,
   *         <code>false</code> if the operation was not successful.
   *
   * @status Documented
   */
  public boolean validateContents (Object hintValidate) {
    return true;
  }

  //-----------------------------------------------------------------------
  // End - Implentation of StandardPanel interface.
  //-----------------------------------------------------------------------

  /**
   * Fires the supplied panel event to the registered listeners.
   *
   * @param panelEvent The panel event to be fired.
   *
   * @status Documented
   */
  public boolean firePanelEvent (EventObject panelEvent) {
    int      nIndex   = -1;
    Object[] listeners = null;

    if (panelEvent == null)
      return false;

    // Guaranteed to return a non-null array
    listeners = m_listenerList.getListenerList ();

    // Process the listeners last to first, notifying those
    // that are interested in this event
    for (nIndex = listeners.length - 2; nIndex >= 0; nIndex -= 2) {
      if  (listeners [nIndex] == PanelEventListener.class) {
        ((PanelEventListener) listeners [nIndex + 1]).panelActionPerformed (panelEvent);
      }
    }

    return true;
  }

  /**
   * Retrieves the value of the panel state.
   *
   * @param nPanelState The panel state whose value is to be checked.
   *
   * @return <code>true</code> if the panel state was set;
   *         <code>false</code> if the panel state was not set.
   *
   * @status Documented
   */
  public boolean getPanelState (int nPanelState) {
    if (nPanelState < 0)
      return false;

    return m_panelState.get (nPanelState);
  }

  /**
   * Retrieves whether the panel is dirty or not.
   *
   * @return  <code>true</code> if the panel is marked dirty;
   *          <code>false</code> otherwise.
   *
   * @status Documented
   */
  public boolean isDirty () {
    return getPanelState (PANELSTATE_ISDIRTY);
  }

  /**
   * Initializes the class members.
   *
   * @status Documented
   */
  public void initializeMembers() {
    m_panelState = new BitSet ();

    // Set the default bit values for the panel states. We do not
    // use the setPanelState method as we do not want the overridden
    // versions to get invoked.
    m_panelState.clear (PANELSTATE_ISDIRTY);
    m_panelState.set (PANELSTATE_ENABLED);
  }

  /**
   * Initializes the user interface content of the panel.
   * Subclasses should override this method.
   *
   * @return <code>true</code> if the operation was successful;
   *         <code>false</code> if the operation was not successful.
   *
   * @throws <code>DataUtilException</code> if the operation is unsuccessful.
   *
   * @status Documented
   */
  public boolean initUIContent () throws DataUtilException {
    return true;
  }

  /**
   * Specifies whether the panel is dirty or not.
   *
   * @param bIsDirty <code>true</code> if the panel needs to be marked dirty;
   *                 <code>false</code> if the panel does not need to be
   *                 marked dirty.
   *
   * @status Documented
   */
  public void setDirty (boolean bIsDirty) {
    setPanelState (PANELSTATE_ISDIRTY, bIsDirty);
  }

  /**
   * Specifies the value of a panel state.
   *
   * @param nPanelState The panel state whose value is to be checked.
   * @param bValue      The value of the panel state. <code>true</code> if the
   *                    panel state is to be set; <code>false</code> if the
   *                    panel state is to be cleared.
   *
   * @status Documented
   */
  public void setPanelState (int nPanelState, boolean bValue) {
    if (nPanelState < 0)
      return;

    if (bValue) {
      m_panelState.set (nPanelState);
    }
    else {
      m_panelState.clear (nPanelState);
    }
  }

  /**
   * Updates data from the user interface component to the underlying
   * data structure and vice versa.
   *
   * @return <code>true</true> if the operation was successful,
   *         <code>false</true> if the operation was not successful.
   *
   * @throws <code>DataUtilException</code> if the operation is unsuccessful.     
   *
   * @status Documented
   */
  public boolean updateData (boolean bUpdateUI) throws DataUtilException {
    return true;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Sets the <code>BuilderCombo</code> to the specified index.
   *
   * @param builderCombo a <code>BuilderCombo</code> value that represents the
   *        combo box that needs to be reset.
   *
   * @param nIndex a <code>int</code> value that represents the index value
   *        to set on the combo box.
   *
   * @status protected
   */
  protected void setCombo (BuilderCombo builderCombo, int nIndex) {
    if (builderCombo != null) {
      // If an error occurred, re-set the selected index to the zeroth item
      setInitializing (true);
      builderCombo.setSelectedIndex (nIndex);
      setInitializing (false);
    }
  }

  /**
   * @hidden
   *
   * Retrieves the <code>ErrorHandler</code> associated with the
   * <code>DefaultBuilderContext</code>, if any.
   *
   * @return <code>ErrorHandler</code> associated with the <code>DefaultBuilderContext</code>.
   *
   * @status protected
   */
  protected ErrorHandler getErrorHandler () {
    ErrorHandler errorHandler = null;

    //BuilderContext builderContext = getBuilderContext();

    //if (builderContext != null) {
        //return builderContext.getErrorHandler();
    //}

    return errorHandler;
  }

  /**
   * @hidden
   *
   * Retrieves the <code>ExceptionListener</code> associated with the
   * <code>DefaultBuilderContext</code>, if any.
   *
   * @return <code>ExceptionListener</code> associated with the <code>DefaultBuilderContext</code>.
   *
   * @status protected
   */
  protected ExceptionListener getExceptionListener () {
    ExceptionListener exceptionListener = null;

    //BuilderContext builderContext = getBuilderContext();

    //if (builderContext != null) {
        //if (builderContext instanceof DefaultBuilderContext)
        //exceptionListener = ((DefaultBuilderContext)builderContext).getExceptionListener();
  //  }

    return exceptionListener;
  }

  /**
   * @hidden
   *
   * Processes the specified <code>Exception</code> by invoking a
   * <code>ErrorHandler</code> if appropriate.
   *
   * @param exception The <code>Exception</code> to process.
   *
   * @return <code>int</code> which represents the dialog option chosen by the
   *         user.
   *
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#CANCEL_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#CLOSED_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#NO_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#NONE_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#OK_OPTION
   * @see oracle.dss.datautil.gui.ExceptionListenerGui#YES_OPTION
   *
   * @status protected
   */
  protected int processException (Exception exception) {

   // Assume that we don't have a ExceptionListenerGui
   int nExceptionListenerResult = ExceptionListenerGui.NONE_OPTION;

    // Retrieve the ExceptionListener
    ExceptionListener exceptionListener = getExceptionListener();

    // Process Exception through ExceptionListenerErrorHandler
    if (exceptionListener != null) {

      // Process the error through the ErrorHandler
      nExceptionListenerResult =
        exceptionListener.processException (exception, 
          "DefaultCalcStepView", "processException");
    }

    return nExceptionListenerResult;
  }

  /**
   * @hidden
   * 
   * Determines if the current builder mode is the same as that specified.
   * 
   * @param strBuilderMode A <code>String</code> which represents the value
   *        of the builder mode to check.
   * 
   * @return <code>boolean</code> that is <code>true</code> when the builder
   *         mode matches and <code>false</code> otherwise.
   * 
   * @see oracle.dss.datautil.gui.BuilderContext.TABBED
   * @see oracle.dss.datautil.gui.BuilderContext.WIZARD
   * 
   * @status hidden
   */
  protected boolean isBuilderMode (String strBuilderMode) {
    boolean bIsBuilderMode = false;

    //BuilderContext builderContext = getBuilderContext();
    
    //if (builderContext != null) {
    
      //String strBuilderModeCurrent = builderContext.getMode();
      //if (strBuilderModeCurrent != null) {
        //bIsBuilderMode = strBuilderModeCurrent.equalsIgnoreCase (strBuilderMode);
      //}
    //}
    
    return bIsBuilderMode;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
