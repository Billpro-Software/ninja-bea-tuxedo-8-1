/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryUtil2.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/12/05 - 
    bmoroze     09/07/05 - 
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     08/15/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/QueryUtil2.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.MetadataMap;

/**
 * @hidden
 * Utilities
 * 
 */
public class QueryUtil2 extends QueryUtil
{
    /*public static String maketoStringArray(Object[] array)
    {
        if (array == null)
            return null;
            
        String retVal = null;
        for (int i = 0; i < array.length; i++)
            if (array[i] != null)
                if (i == 0)
                    retVal = array[i].toString();
                else
                    retVal += "," + array[i].toString();
        
        return retVal == null ? "{}" : "{" + retVal + "}";            
    }*/
    
    public static void apiOutput(Query query, String marker, String retVal, String object, String routine, String[] args)
    {
        if (query.getProperty(QueryConstants.PROPERTY_DEBUG_MODE).equals(Boolean.valueOf(true)))
        {
            // Build output            
            String output = null;
            if (retVal != null)
            {
                if (object != null)
                    output = retVal + " = " + object + "." + routine + "(";
                else
                    output = retVal + " = " + routine + "(";
            }
            else
                if (object != null)                
                    output = object + "." + routine + "(";
                else
                    output = routine + "(";
                
            if (args != null)
                for (int i = 0; i < args.length; i++)
                    if (i == 0)
                        output += args[i];
                    else
                        output += "," + args[i];
            output += ");";
            query.getErrorHandler().trace(marker + ":: " + output, null, null);
        }
    }

    // Alter dimensionality based on change to measure list
    // blm - Selection code moved to dvt-olap
/*    public static boolean changeDimensionality(DimTree oldDimTree, SelectionList selList, String[] newMeasures, String measDimName, Query query) throws CloneException, MetadataManagerException, InvalidMeasureException
    {
        MetadataManagerServices mm = query.getMetadataManager();
        boolean dimensionalityChanged = false;
        if (oldDimTree != null) {
            Vector dimList = null;
            if (newMeasures != null) {
                MDDimension[] dimarr = mm.dimensionalityOfMeasures(convertToMDMeasures(newMeasures, query), MM.UNION);
                dimList = Utility.copyArrayToVector(dimarr);
            }
            String[] dimensions = null;
            if (dimList != null) {
                // Convert dimlist to a straight list of dims
                Enumeration dims = dimList.elements();
                // Will we need to add measure dim?
                int count;
                if (isDimInTree(measDimName, oldDimTree)) {
                    dimensions = new String[dimList.size()+1];
                    dimensions[0] = measDimName;
                    count = 1;
                }
                else {
                    dimensions = new String[dimList.size()];
                    count = 0;
                }
                while (dims.hasMoreElements()) 
                    dimensions[count++] = ((MDDimension)dims.nextElement()).getUniqueID();
            }
                            
            try
            {
                dimensionalityChanged = !Utility.compareLists(dimensions, Utility.flattenArray(Node.getStringArray(oldDimTree.getDimTree())));
            }
            catch (CloneNotSupportedException e)
            {
                throw new CloneException(e.getMessage(), e);
            }
            // Reconcile the new dimensionality with the current tree
            if (dimensionalityChanged) {
                boolean[] asym = null;
                List[] depend = null;
                if (dimensions != null)
                {
                    asym = new boolean[dimensions.length];
                    depend = new List[dimensions.length];
                    for (int dim = 0; dim < dimensions.length; dim++) {
                        asym[dim] = isAsymmetric(dimensions[dim], selList);
                        depend[dim] = getDependentDimensions(dimensions[dim], selList);
                    }
                }
                List removedDims = oldDimTree.reconcileNodes(Node.getNodeList(dimensions, asym, depend));
                if (removedDims != null)
                {
                    // Clean up removed dimensions
                    Iterator iter = removedDims.iterator();
                    while (iter.hasNext())
                    {
                        List tupleSels = getTupleSelections(selList);
                        // Check for straightforward selections to remove
                        String dimName = ((Node)iter.next()).getName();
                        Selection sel = selList.find(dimName);
                        if (sel != null)
                        {
                            selList.remove(sel);
                        }
                        // Now check for tuple selections matching
                        if (tupleSels != null)
                        {
                            Iterator sels = tupleSels.iterator();
                            Selection tupleSel = null;
                            List dims = null;
                            while (sels.hasNext())
                            {
                                tupleSel = (Selection)sels.next();
                                // See if the current dim name matches any of the dims
                                // in this tuple sel
                                Vector dimv = tupleSel.getDimensions();
                                if (dimv != null)
                                {
                                    String tupleName = null;
                                    for (int v = 0; v < dimv.size(); v++)
                                    {
                                        tupleName = (String)dimv.elementAt(v);
                                        if (dimName.equals(tupleName))
                                        {
                                            // Matched: remove it
                                            selList.remove(tupleSel);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return dimensionalityChanged;
    }    

    public static boolean isEdgeAsymmetric(int edge, DimTree dt, SelectionList selList) throws QueryException
    {
        // Check edge using layout, and then for tuples
        boolean mainSels = false;
        try
        {
            mainSels = dt.isEdgeAsymmetric(edge, -1, selList);
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryException(e.getMessage(), e);            
        }
        
        if (mainSels)
            return true;
            
        // Make sure there are no tuples
        return anyTuples(edge, dt, selList);
    }
    
    protected static boolean anyTuples(int startEdge, DimTree dt, SelectionList selList)
    {
        // Determine if there are any tuple steps involved here
        java.util.List tupleSels = QueryUtil.getTupleSelections(selList);
        if (tupleSels == null)
        {
            // None to process
            return false;
        }
        java.util.Iterator sels = tupleSels.iterator();
        Selection sel = null;
        java.util.List dims = null;
        if (dt == null)
        {
            return false;
        }
        int edge = -1;
        while (sels.hasNext())
        {
            sel = (Selection)sels.next();
            // Match up each sel with its edge and set it on the cube, if applicable
            Vector dimv = sel.getDimensions();
            if (dimv != null && dimv.size() > 0)
            {
                dims = QueryUtil.convertVectorToList(dimv);
                edge = dt.getEdgeForTuple(dims);
                if (edge >= startEdge)
                {
                    // This edge is in the range of startEdge...end that we want to check
                    return true;
                }
            }
        }

        return false;
    }    
  
    public static void checkMeasures(String[] measures, Query query) throws QueryException, MetadataManagerException
    {
        if (measures == null) {
            // Not found
            throw new InvalidMeasureException(MessageFormat.format(query.getResourceString("Invalid measure specified"), new String[] {QueryUtil.strList(measures)}), measures, null);
        }
        for (int i = 0; i < measures.length; i++) {
            if (query.getMDObject(MM.UNIQUE_ID, measures[i], MM.MEASURE) == null) {
                // Are there any measures in the database?
                MDMeasure[] measlist = query.getMMMeasures();
                if (measlist == null || measlist.length == 0) {
                    throw new InvalidMeasureException(query.getResourceString("No measures found in database"), (String[])null, null);
                }
                // Not found: build list
                throw new InvalidMeasureException(MessageFormat.format(query.getResourceString("Invalid measure specified"), new String[] {QueryUtil.strList(measures)}), measures, null);
            }
        }
    }         
    
    // Build a dimension tree given a list of dimensions, putting measure
    // as the first dimension on the page edge
    public static DimTree buildDefaultDimTree(String[] measures, boolean isRelational, Query query) throws MetadataManagerException, QueryException
    {
        MetadataManagerServices mm = query.getMetadataManager();
        MDDimension[] dimList = null;
        try {
            dimList = mm.dimensionalityOfMeasures(convertToMDMeasures(measures, query), MM.UNION);
        }
        catch (Exception e) {
            throw new InvalidMeasureException(MessageFormat.format(query.getResourceString("Invalid measure specified"), new String[] {QueryUtil.strList(measures)}), measures, e);
        }
        Vector dims = Utility.copyArrayToVector(dimList);
        dims.addElement(query.getMeasureDimObj());
        return new DimTree(query.getMeasureDim(), convertFromMDDimensions(dims), query.getPropertySupport().getDefaultColumnCount(), query.getPropertySupport().getDefaultRowCount(), isRelational);
    }

    // Convert a list of measures to a list of database measures
    public static MDMeasure[] convertToMDMeasures(String[] measures, Query query) throws InvalidMeasureException
    {
        if (measures == null)
            return null;
        Vector newList = new Vector();
        for (int i = 0; i < measures.length; i++)
        {
            if (measures[i] != null)
            {
                newList.addElement(measures[i]);
            }
        }
        MDMeasure[] dssmeasures = new MDMeasure[newList.size()];
        int i = 0;
        try
        {
            for (i = 0; i < dssmeasures.length; i++) {

                dssmeasures[i] =
                    (MDMeasure)query.getMDObject(MM.UNIQUE_ID, (String)newList.elementAt(i), MM.MEASURE);
            }
        }
        catch (MetadataManagerException mme)
        {
            throw new InvalidMeasureException(MessageFormat.format(query.getResourceString("Invalid measure specified"), new String[] {(String)newList.elementAt(i)}),(String)newList.elementAt(i), mme);
        }

        return dssmeasures;
    }
*/
    /**
     * @hidden
     * Determine the correct metadata map for the edge/depth (used on middle tier also)
     */
    public static MetadataMap getMetadataMap(MainManager ds, String[] dimList, int edge, int depth) {
        if (depth == -1) {
            // Want result for entire edge
            return ds.getMetadataMap(edge);
        }
        MetadataMap map;
        if (dimList == null) {
            map = ds.getMetadataMap(edge);
            if (map == null)
                map = ds.getMetadataMap(null);
                    
            return map;
        }
        map = ds.getMetadataMap(dimList[0]);
        if (map == null) {
            // Fall back on edge or default
            map = ds.getMetadataMap(edge);
            if (map == null)
                map = ds.getMetadataMap(null);
        }

        return map;
    }        

    /**
     * @hidden
     */
    public synchronized static DAQuery _getDataForDataFilters(Query query, String item, BaseDataFilter[] dataFilter, MetadataMap map, DataDirectorListener ddl) throws Exception
    {
        query.setProperty(QueryConstants.PROPERTY_LOV, new Boolean(true));
        query.setMetadataMap(null, map);
        if (ddl != null)
        {
            DataDirector dd = query.createCubeDataDirector();
            dd.addDataDirectorListener(ddl);
        }
        query.setDataFilters(dataFilter);
        query.initQuery(new String[][] {{item}}, null);
        DAQuery daq = new DAQuery(query);
        DAQueryAdapter qa = new DAQueryAdapter(daq);
        query.addQueryListener(qa);
        return daq;
    }    

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized static DAQuery _getDataForSelection(Query query, Selection sel, MetadataMap map, DataDirectorListener2 ddl) throws InvalidStepArgException, SelectionException, QueryException, MetadataManagerException
    {
        query.setMetadataMap(null, map);
        if (ddl != null)
        {
            DataDirector3 dd = (DataDirector3)query.createCubeDataDirector();
            dd.addDataDirectorListener(ddl);
        }
        query.applySelection(sel);
        query.initQuery(new String[][] {{sel.getDimension()}}, null);
        DAQuery daq = new DAQuery(query);
        DAQueryAdapter qa = new DAQueryAdapter(daq);
        query.addQueryListener(qa);
        return daq;
    }    
  */  
    /**
     * @hidden
     */
    public static class DAQuery extends Object
    {
        public DAQuery(Query query)
        {
            m_query = query;
        }
        
        public Query getQuery()
        {
            return m_query;
        }
        
        protected void setDataAccess(DataAccess da)
        {
            m_dataAccess = da;
        }
        
        public DataAccess getDataAccess()
        {
            return m_dataAccess;
        }
        
        protected DataAccess m_dataAccess = null;
        protected Query m_query = null;
    }
    
    static class DAQueryAdapter extends QueryAdapter
    {        
        protected DAQuery m_daq = null;
        
        protected DAQueryAdapter(DAQuery daq)
        {
            super();
            m_daq = daq;
        }
        
        public void dataAvailable(DataAvailableEvent e) {
            if (e.isAvailable())
            {
                setDataAccess(e.getDataAccess());
            }
        }
        public void dataChanged(DataChangedEvent e)
        {
            setDataAccess(e.getDataAccess());
        }
        protected void setDataAccess(DataAccess da)
        {
            m_daq.setDataAccess(da);
        }
    }    
}