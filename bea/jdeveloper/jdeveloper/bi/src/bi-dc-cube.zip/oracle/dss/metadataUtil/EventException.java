
// Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
// All rights reserved. 


package oracle.dss.metadataUtil;

import oracle.dss.util.BIBaseException;

/**
 * Indicates a problem with an event.
 *
 * @status Reviewed
 */
public class EventException extends BIBaseException {

  /**
   * @hidden
   * Constructor.
   *
   * @param str        The text of the error message.
   *
   * @status hidden
   */
  public EventException( String str ) {
    super( str, null );
  }

  /**
   * @hidden
   * Constructor for an exception that passes on a previous exception.
   *
   * @param str     The text of the error message.
   * @param prevException   The underlying exception.
   *
   * @status hidden
   */
  public EventException( String str, Throwable prevException ) {
    super( str, prevException );
  }
}