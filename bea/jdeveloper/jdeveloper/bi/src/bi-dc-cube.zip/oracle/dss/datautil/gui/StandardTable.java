/**
 * StandardTable.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;

import java.util.Vector;

import javax.swing.FocusManager;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import oracle.dss.datautil.DimensionMember;

import oracle.dss.util.gui.LightWeightComboBox;

/**
 * @hidden
 * 
 * This class is primarily used by BI Beans to fix tabbing and ADA issues 
 * associated with the <code>JTable</code>.
 * 
 * @status hidden
 */

public class StandardTable extends JTable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Dimension Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  private DimensionMember m_oldValue = null;

  /**
   * @hidden
   * 
   * @status hidden
   */
  private LightWeightComboBox m_editorCombo;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable() {
    super();
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable(TableModel dm) {
    super (dm);
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable (TableModel dm, TableColumnModel cm) {
    super (dm, cm);
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable (TableModel dm, TableColumnModel cm, ListSelectionModel sm) {
    super (dm, cm, sm);
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable (int numRows, int numColumns) {
    super (numRows, numColumns);
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable (Vector rowData, Vector columnNames) {
    super (rowData, columnNames);
    init();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTable (Object[][] rowData, Object[] columnNames) {
    super (rowData, columnNames);        
    init();
  }

  /////////////////////
  //
  // Public Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  public void setValueAt(Object aValue, int row, int column) {
    super.setValueAt(aValue, row, column);
    resizeAndRepaint();
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public JComboBox getEditor() {
    return m_editorCombo;
  }

  /**
   * @hidden
   * 
   * @status hidden
   */
  public DimensionMember getOldValue() {
    return m_oldValue;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  protected void processKeyEvent(KeyEvent e) {
      if (e.getKeyCode() == KeyEvent.VK_TAB && 
        e.getID() == KeyEvent.KEY_PRESSED && 
        !e.isControlDown()) {

      // Get the column and row of the currently selected cell.
      int anchorRow = getSelectionModel().getAnchorSelectionIndex();
      int anchorColumn = getColumnModel().getSelectionModel().getAnchorSelectionIndex();

      // If we're in the last cell of the table and we are tabbing
      // forward (i.e. the Shift key is not held down), then return
      // so that the JTable's parent container will process the event
      // and tab to the next component.
      if (anchorColumn == getColumnCount() - 1 &&
          anchorRow == getRowCount() - 1 &&
          !e.isShiftDown()) {

          // move focus to next component, don't simply return and depend
          // on parent container doing it
          if (FocusManager.isFocusManagerEnabled()) {
            super.processKeyEvent(e);
            FocusManager.getCurrentManager().focusNextComponent (this);
            e.consume();
          }

        return;
      }

      // If we're in the first cell of the table and we are tabbing
      // backward (i.e. the Shift key is held down), then return
      // so that the JTable's parent container will process the event
      // and tab to the previous component.

      if (anchorColumn == 0 && anchorRow == 0 && e.isShiftDown()) {

        // Move focus to previous component, don't simply return and depend
        // on parent container doing it
        if (FocusManager.isFocusManagerEnabled()) {
          FocusManager.getCurrentManager().focusPreviousComponent(this);
          e.consume();
        }

        return;

      }
    }

    // If this isn't one of the special cases above, let the JTable
    // process the Tab.
    super.processKeyEvent(e);
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
  
  /**
   * @hidden
   * 
   * @status hidden
   */
   private void init() {

    setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    setBackground(Color.white);
    sizeColumnsToFit(JTable.AUTO_RESIZE_ALL_COLUMNS);

    m_editorCombo = new LightWeightComboBox();
    m_editorCombo.addItemListener (new ItemListener() {

    public void itemStateChanged(ItemEvent e) {
      if (e.getStateChange() == ItemEvent.SELECTED) {
        Object o = e.getItem();
        if ( (o != null) && (o instanceof DimensionMember) ) {
          m_oldValue = (DimensionMember)o;
        }
      }
    }});

    setRowHeight(m_editorCombo.getPreferredSize().height);

    getTableHeader().setReorderingAllowed(false);

    // Register the space key strokes to start editing and request focus
    ActionListener editAction = new ActionListener() {

      public void actionPerformed (ActionEvent e) { 

        // Start editing the table cell
        ListSelectionModel rsm = getSelectionModel(); 
        int anchorRow = rsm.getAnchorSelectionIndex(); 

        ListSelectionModel csm = getColumnModel().getSelectionModel(); 

        int anchorColumn = csm.getAnchorSelectionIndex(); 

        editCellAt (anchorRow, anchorColumn); 

        // Make sure the editor has focus
        Component editor = getEditorComponent(); 
        if (editor != null) {
          editor.requestFocus();
        }
        else {
          requestFocus();
        }
      }
    };

    // Register the action when the space key is pressed
    registerKeyboardAction(editAction, 
    KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0),
    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    // Register the same action for F2 key
    // to fix the bug in BasicTableUI
    registerKeyboardAction(editAction,
    KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0),
    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);   
  }
}