/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;

public class MDInitializerException extends MetadataManagerException
{
    /**
     * @hidden
     * Application/user specified error message
     *
     * @param message  The text of the error message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public MDInitializerException(String message, String driverType, Throwable prevException)
    {
        super(message, driverType, prevException);
    }

    public MDInitializerException(Class resBundleClass, String errorCode, Object[] params, Locale locale, String driverType, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, locale, driverType, prevException);
    }
}
