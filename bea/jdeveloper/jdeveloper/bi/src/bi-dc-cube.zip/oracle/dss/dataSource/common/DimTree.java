/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Hashtable;

import oracle.dss.util.DataDirector;

import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.NoSuchPropertyException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.util.MetadataPrinter;
import oracle.dss.util.DefaultMetadataPrinter;

import oracle.dss.util.QDR;
import oracle.dss.util.QDRMember;
import oracle.dss.util.Utility;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.transform.BaseNode;

/**
 * @hidden
 * Private class for storing node trees
 */
public class DimTree extends Object implements Cloneable, java.io.Serializable, XMLizable
{
    protected final static String EDGE_PROP = "edgename";
                                  
    // Construct empty
    public DimTree() {
        super();
        
        m_tree = new ArrayList();
    }
    
    // Construct from a node tree
    public DimTree(BaseNode[][] dimTree, List nullEdges) {        
        this();
        _setTree(dimTree);
        m_nullEdges = nullEdges;
        if (m_nullEdges == null)
        {
            clearNullEdges();
        }
    }

    // Construct from a list of nodes: do a default layout
    public DimTree(String measName, BaseNode[] dims, int numCol, int numRow, boolean isRelational) {
        this();
        _setTree(buildDefaultNodeArray(measName, dims, numCol, numRow, isRelational));
        clearNullEdges();
    }

    // Construct from a list of nodes: use default placements
    public DimTree(String measName, BaseNode[] dims, Vector placements, boolean isRelational)
    {
        this();
        _setTree(buildDefaultNodeArray(measName, dims, placements, isRelational));
        clearNullEdges();
    }
    
    private void _setTree(BaseNode[][] dimTree)
    {
        if (dimTree == null)
            return;
            
       List nodeList;
        int len;
        for (int edge = 0; edge < dimTree.length; edge++) {
            nodeList = new ArrayList();
            m_tree.add(nodeList);
            len = (dimTree[edge] == null) ? 0 : dimTree[edge].length;
            for (int node = 0; node < len; node++) {
                nodeList.add(dimTree[edge][node]);
            }
        }
    }

    /**
     * @hidden
     */
    public void setMetadataPrinter(MetadataPrinter metadataPrinter)
    {
        if (metadataPrinter != null)
        {
            m_metadataPrinter = metadataPrinter;
        }
        else
        {
            m_metadataPrinter = new DefaultMetadataPrinter();
        }
    }
    
    public boolean equals(Object obj)
    {
        if (obj == null || !(obj instanceof DimTree))
        {
            return false;
        }
        DimTree dt = (DimTree)obj;
        
        boolean treeEqual = m_tree != null ? m_tree.equals(dt.m_tree) : m_tree == dt.m_tree;
        boolean nullEqual = m_nullEdges != null ? m_nullEdges.equals(dt.m_nullEdges) : m_nullEdges == dt.m_nullEdges;
        return treeEqual && nullEqual && Utility.compareHashtables(m_unassignedTotals, dt.m_unassignedTotals) /*&&
                Utility.compareObj(m_colTotalStep, dt.m_colTotalStep) && Utility.compareObj(m_rowTotalStep, dt.m_rowTotalStep)*/;
    }
    
    
    public void clearNullEdges() {
        m_nullEdges = new ArrayList();
    }
    
    public void setEdgeNull(int edge, boolean isNull) {
        if (m_nullEdges == null) {
            m_nullEdges = new ArrayList();
        }
        // Expand out far enough to cover
        for (int i = m_nullEdges.size(); i <= edge; i++) {
            m_nullEdges.add(new Boolean(false));
        }
        // Set this edge
        m_nullEdges.set(edge, new Boolean(isNull));
    }
    
    public boolean isEdgeNull(int edge) {
        if (m_nullEdges != null && edge < m_nullEdges.size()) {
            return ((Boolean)m_nullEdges.get(edge)).booleanValue();
        }
        return false;
    }
    
    // Return true if any of the edges had no status
    public boolean areAnyEdgesNull() {
        if (m_nullEdges != null) {
            for (int i = 0; i < m_nullEdges.size(); i++) {
                if (isEdgeNull(i)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public int getNodeCount()
    {
        int edgeCount = getEdgeCount();
        int nodeCount = 0;
        for (int i = 0; i < edgeCount; i++)
        {
            nodeCount += getNodeCount(i);
        }
        return nodeCount;
    }
    
    // Return the overall number of edges requested
    public int getRawEdgeCount()
    {
        return m_tree.size();
    }
    
    // Return the number of edges in this tree
    public int getEdgeCount() {
        int startingSize = getRawEdgeCount();
        List edgeList = null;
        for (int edge = startingSize-1; edge >=0; edge--) {
            // The first one we find with dimensions marks where we stop lopping off
            // extra edge counts
            edgeList = (List)m_tree.get(edge);
            if (edgeList != null && edgeList.size() > 0)
                break;
            else
                startingSize--;
        }
        return startingSize;
    }

    // Return the edge on which a tuple is found, if any
    public int getEdgeForTuple(List dimensions)
    {
        Iterator dims = dimensions.iterator();
        BaseNode node = null;
        List edges = new ArrayList();
        while (dims.hasNext())
        {
            node = getNode((String)dims.next());
            if (node != null)
            {
                // Determine what edge
                int dimEdge = getEdge(node);
                edges.add(new Integer(dimEdge));
            }
            else
            {
                // Node not found at all: this can't match
                return -1;
            }
        }
        Iterator edgeList = edges.iterator();
        // Pick off first one
        int firstedge = -1;
        if (edgeList.hasNext())
        {
            Integer nextEdge = (Integer)edgeList.next();
            if (nextEdge != null)
            {
                firstedge = nextEdge.intValue();
            }
        }
        else
        {
            // No nodes/edges
            return -1;
        }
        int edge = -1;
        while (edgeList.hasNext())
        {
            Integer nextEdge = (Integer)edgeList.next();
            if (nextEdge != null)
            {
                edge = nextEdge.intValue();
                if (edge != firstedge)
                {
                    return -1;
                }
            }
        }
        return firstedge;
    }
    
    // Return a bitset with bits set for edges that differ from the argument
    public BitSet getEdgeDifferences(DimTree tree) {
        if (tree == null)
            tree = new DimTree();
        
        int numBits = Math.max(tree.getEdgeCount(), Math.max(getEdgeCount(), 3));
        BitSet diff = new BitSet(numBits);
        DimTree smaller = null;
        DimTree larger = null;
        if (tree.getEdgeCount() < getEdgeCount()) {
            // Walk up to the arguments bits
            smaller = tree;
            larger = this;
        }
        else {
            // Walk up to this dimension tree's bits
            smaller = this;
            larger = tree;
        }
        // Walk the edges, comparing
        int node, edge;
        List smallEdge, largeEdge;
        for (edge = 0; edge < smaller.getEdgeCount(); edge++) {
            smallEdge = smaller._getNode(edge);
            largeEdge = larger._getNode(edge);
            // If they're equal for some reason, or even both null, then there's no difference
            if (smallEdge == largeEdge)
                continue;

            // If they're not equal, but one is null, then they must be different and we can move on
            if (smallEdge == null || largeEdge == null) {
                diff.set(edge);
                continue;
            }
            
            // If the lengths aren't equal, they're different
            if (smallEdge.size() != largeEdge.size()) {
                diff.set(edge);
                continue;
            }
            
            for (node = 0; node < smallEdge.size(); node++) {
                if (!_getNode(smallEdge, node).equals(_getNode(largeEdge, node))) {
                    diff.set(edge);
                    break;
                }
            }
        }
        // Fill out the rest
        for (edge = smaller.getEdgeCount(); edge < numBits; edge++)
            diff.set(edge);
            
        return diff;
    }
    
    // Return the number of nodes for a given edge
    public int getNodeCount(int edge) {
        List nodeList = _getNode(edge);
        return nodeList == null ? 0 : nodeList.size();
    }
    
    // Return the total number of nodes in this tree
    public int getTotalNodes() {
        int edgeCount = getEdgeCount();
        int total = 0;
        for (int edge = 0; edge < edgeCount; edge++)
            total += getNodeCount(edge);
            
        return total;            
    }
        
    // Return the node as a node list for a given edge
    public BaseNode[] getNode(int edge) {
        List nodeList = _getNode(edge);
        return (BaseNode[])nodeList.toArray(new BaseNode[]{});
    }
    
    // Return a node if found by name regardless of asym setting
    public BaseNode getNode(String name) {
        if (m_tree == null || name == null) {
            return null;
        }
        try {
            int edge = Integer.parseInt(name);
            // Return a placeholder
            return new Node(name);
        }
        catch (NumberFormatException e) {
            // Couldn't convert: keep going                      
        }
        
        for (int edge = 0; edge < m_tree.size(); edge++) {
            List nodeList = _getNode(edge);
            if (nodeList != null) {
                for (int node = 0; node < nodeList.size(); node++) {
                    BaseNode found = (BaseNode)nodeList.get(node);
                    if (found != null && found.getName().equals(name)) {
                        return found;
                    }
                }
            }
        }
        return null;
    }
    
    // Return a copy of the stored node object at a given edge, node position
    public BaseNode getNode(int edge, int node) throws CloneException
    {
        List nodeList = _getNode(edge);
        try
        {
            return nodeList == null ? null : node < getNodeCount(edge) ? (BaseNode)((BaseNode)nodeList.get(node)).clone() : null;
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
    }
    
    // Return a single node from the list
    private BaseNode _getNode(List nodeList, int node) {
        return (node < nodeList.size()) ? (BaseNode)nodeList.get(node) : null;
    }
    
    // Return the node as a list
    private List _getNode(int edge) {
        return edge == -1 || edge >= getEdgeCount() ? null : (List)m_tree.get(edge);
    }
           
    // Return the entire tree laid out as a node array
    public BaseNode[][] getDimTree() throws CloneNotSupportedException
    {
            BaseNode[][] newTree = new BaseNode[getRawEdgeCount()][];
            List nodeList = null;
            for (int edge = 0; edge < newTree.length; edge++) {
                newTree[edge] = new BaseNode[getNodeCount(edge)];
                nodeList = _getNode(edge);
                for (int node = 0; node < newTree[edge].length; node++) {
                    newTree[edge][node] = (BaseNode)((BaseNode)nodeList.get(node)).clone();
                }
            }
            return newTree;
    }
    
    // Clone this tree
    public Object clone() throws CloneNotSupportedException
    {
        DimTree dt = new DimTree(getDimTree(), m_nullEdges);
        if (m_nullEdges != null)
        {
            dt.m_nullEdges = (List)((ArrayList)m_nullEdges).clone();
        }
        // blm - Selection code moved to dvt-olap
/*        if (m_colTotalStep != null)
        {
            dt.m_colTotalStep = (TotalStep)m_colTotalStep.clone();
        }
        if (m_rowTotalStep != null)
        {
            dt.m_rowTotalStep = (TotalStep)m_rowTotalStep.clone();
        }
        dt.m_unassignedTotals = Utility.cloneHashtable(m_unassignedTotals);*/
        return dt;
    }

    // blm - Selection code moved to dvt-olap
/*    public String validateTotals(SelectionList sels, String measDim)
    {
        Iterator seliter = sels.iterator();
        while (seliter.hasNext())
        {
            Selection sel = (Selection)seliter.next();
            if (sel != null && sel.getTotalStep() != null)
            {
                // There's a total step here: check it
                String dim = validateTotal(sel.getDimension(), measDim);
                if (dim != null)
                {
                    return dim;
                }
            }
        }
        return null;
    }
*/

    /**
     * Check total steps vs. the layout
     */
    public String validateTotal(String dim, String measDim)
    {
        if (measDim.equals(dim))
        {
            return dim;
        }

        // Find the location of the measure dimension and make sure it is not faster varying than
        // the total's dim
        String[] innerDims = null;
        try
        {
            innerDims = getInnerDimensions(dim);
        }
        catch (CloneException cnse)
        {
            return dim;
        }

        if (innerDims != null)
        {
            // Check for a measure dim
            for (int i = 0; i < innerDims.length; i++)
            {
                if (innerDims[i].equals(measDim))
                {
                    return innerDims[i];
                }
            }
        }
        return null;
    }

    // blm - Selection code moved to dvt-olap
/*    public TotalStep getAllLayerTotal(int edge)
    {
        if (edge == DataDirector.COLUMN_EDGE)
        {
            return m_colTotalStep;
        }
        if (edge == DataDirector.ROW_EDGE)
        {
            return m_rowTotalStep;
        }
        return null;
    }
*/
    /**
     * Modify selections applying the given total step to all of them on an edge
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection[] applyTotalSteps(SelectionList selections, TotalStep ts, int edge, int layerStart, int layerCount, boolean allLayers) throws CloneException
    {
        if (allLayers)
        {
            try
            {
                switch (edge)
                {
                    case DataDirector.COLUMN_EDGE:
                        if (ts != null)
                        {
                            m_colTotalStep = (TotalStep)ts.clone();
                        }
                        else
                        {
                            m_colTotalStep = null;
                        }
                        break;
                    case DataDirector.ROW_EDGE:
                        if (ts != null)
                        {
                            m_rowTotalStep = (TotalStep)ts.clone();
                        }
                        else
                        {
                            m_rowTotalStep = null;
                        }
                        break;
                }
            }
            catch (CloneNotSupportedException e)
            {
                throw new CloneException(e.getMessage(), e);
            }
        }

        Vector selRet = new Vector();
        for (int layer = layerStart; layer < layerCount+layerStart; layer++)
        {
            // Lookup the selection for the given dimension
            Selection sel = selections.find(getNode(edge, layer).getName());
            if (sel != null)
            {
                // Found the selection: either set the total or clear it
                if (ts == null)
                {
                    // Clear it and reapply
                    TotalStep oldTS = sel.getTotalStep();
                    if (oldTS != null)
                    {
                        sel.setClearDrillStep(false);
                        sel.setTotalStep(null);
                        selRet.addElement(sel);
                    }
                }
                else
                {
                    TotalStep tempTotal = null;
                    try
                    {
                        tempTotal = (TotalStep)ts.clone();
                    }
                    catch (CloneNotSupportedException e)
                    {
                        throw new CloneException(e.getMessage(), e);
                    }
                    tempTotal.setDimension(sel.getDimension());
                    tempTotal.setHierarchy(sel.getHierarchy());
                    if (!tempTotal.equals(sel.getTotalStep()))
                    {
                        boolean hadTotal = (sel.getTotalStep() != null);
                        // This is new: apply it
                        sel.setClearDrillStep(false);
                        sel.setTotalStep(tempTotal);
                        selRet.addElement(sel);
                    }
                }
            }
        }

        if (ts == null && !allLayers)
        {
            // If this was a total step deletion, and not an all deletion, then we'd better
            // reapply any all edge steps because the layer that had a local ts knocked out
            // will not total that layer under the guidance of the all layer total anymore
            if (m_colTotalStep != null)
            {
                Selection[] colSels = applyTotalSteps(selections, m_colTotalStep, DataDirector.COLUMN_EDGE, layerStart, layerCount, false);
                selRet = _addAllTotalSteps(colSels, selRet);
            }
            if (m_rowTotalStep != null)
            {
                Selection[] rowSels = applyTotalSteps(selections, m_rowTotalStep, DataDirector.ROW_EDGE, layerStart, layerCount, false);
                selRet = _addAllTotalSteps(rowSels, selRet);
            }

        }

        return (Selection[])Utility.copyVectorToArray(selRet);
    }

    private Vector _addAllTotalSteps(Selection[] sels, Vector selRet)
    {
        if (sels != null)
        {
            for (int i = 0; i < sels.length; i++)
            {
                if (selRet != null)
                {
                    Vector removal = new Vector();
                    Enumeration retsels = selRet.elements();
                    while (retsels.hasMoreElements())
                    {
                        Selection sel = (Selection)retsels.nextElement();
                        if (sel != null && sel.getDimension().equals(sels[i].getDimension()))
                        {
                            // Match: remove it
                            removal.addElement(sel);
                        }
                    }
                    Enumeration removeSels = removal.elements();
                    while (removeSels.hasMoreElements())
                    {
                        selRet.removeElement(removeSels.nextElement());
                    }
                }
                selRet.addElement(sels[i]);
            }
        }
        return selRet;
    }
*/
    /**
     * Adjust positional TotalSteps based on layout
     */
     // blm - Selection code moved to dvt-olap
/*    public SelectionList adjustTotalSteps(SelectionList selections) throws CloneException
    {
        if (!anyTotals(selections) && m_unassignedTotals.size() == 0)
        {
            return selections;
        }
        
        // Gather all the location dependent TotalSteps and store them by their location keys
        Iterator iter = selections.iterator();
        while (iter.hasNext())
        {
            TotalStep ts = ((Selection)iter.next()).getTotalStep();
            if (ts != null && ts.isLocationDependent())
            {
                // Make a key
                String key = _formTotalLocationKey(ts.getEdge(), ts.getLayer());
                m_unassignedTotals.put(key, ts);
            }
        }

        // Don't bother if we didn't find any location dependent totals
        if (m_unassignedTotals.isEmpty() && m_colTotalStep == null && m_rowTotalStep == null)
        {
            return selections;
        }

        // Now walk layout and place total steps in Selections
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode = null;
        Selection currentSel = null;
        int edgeNum = 0;
        List nodeList = null;
        while (edgeIter.hasNext())
        {
            nodeList = (List)edgeIter.next();
            if (nodeList != null)
            {
                nodeIter = nodeList.iterator();
                int nodeNum = 0;
                while (nodeIter.hasNext())
                {
                    currentNode = (BaseNode)nodeIter.next();
                    TotalStep ts = null;
                    if (currentNode != null)
                    {
                        // See if there's anything that belongs here
                        // First do the overall all layers total if there
                        try
                        {
                            switch (edgeNum)
                            {
                                case DataDirector.COLUMN_EDGE:
                                    if (m_colTotalStep != null)
                                    {
                                        ts = (TotalStep)m_colTotalStep.clone();
                                    }
                                    break;
                                case DataDirector.ROW_EDGE:
                                    if (m_rowTotalStep != null)
                                    {
                                        ts = (TotalStep)m_rowTotalStep.clone();
                                    }
                                    break;
                                default:
                                    ts = null;
                                    break;
                            }
                        }
                        catch (CloneNotSupportedException e)
                        {
                            throw new CloneException(e.getMessage(), e);
                        }
                        String key = null;
                        if (ts == null)
                        {
                            // Check totals from the unassigned list
                            key = _formTotalLocationKey(edgeNum, nodeNum);
                            ts = (TotalStep)m_unassignedTotals.get(key);
                        }
                        if (ts != null)
                        {
                            // We've got to put this totalstep in to the selection that
                            // belongs to the dimension here
                            Selection sel = selections.find(currentNode.getName());
                            // If we find the selection for this node and its dimension
                            // does not match the total step that's going here, then
                            // fix it up
                            if (sel != null && !sel.getDimension().equals(ts.getDimension()))
                            {
                                // Grab the old dimension from the total step so we can
                                // disassociate it from its old selection
                                String oldDim = ts.getDimension();
                                Selection oldSel = null;
                                if (oldDim != null)
                                {
                                    oldSel = selections.find(oldDim);
                                }
                                if (oldSel != null && ts.equals(oldSel.getTotalStep()))
                                {
                                    selections.remove(oldSel);
                                    oldSel.setTotalStep(null);
                                    selections.add(oldSel);
                                }

                                // Remove the current selection from the list
                                selections.remove(sel);
                                // Make the positional totalstep's dimension match the new location
                                ts.setDimension(sel.getDimension());
                                ts.setHierarchy(sel.getHierarchy());
                                // Connect the total step to the dimension
                                // Clear the level because we're moving the total step
                                ts.setLevel(null);
                                ts.setEnabled(true);
                                sel.setTotalStep(ts);
                                // Put the modified selection back in the list
                                selections.add(sel);
                                if (key != null)
                                {
                                    // Remove it from the hash list
                                    m_unassignedTotals.remove(key);
                                }
                            }
                            else if (sel!= null && sel.getDimension().equals(ts.getDimension()))
                            {
                                if (key != null)
                                {
                                    // It's no longer unassigned: there was no change
                                    // Remove it from the hash list
                                    m_unassignedTotals.remove(key);
                                }
                            }
                        }
                    }
                    nodeNum++;
                }
            }
            edgeNum++;
        }

        // Now any Selections with totalsteps should have their positional total steps removed if they
        // a) don't match the current location of the selection in the layout, and b) are in the unassigned list
        Vector selChange = new Vector();
        Iterator sels = selections.iterator();
        while (sels.hasNext())
        {
            Selection sel = (Selection)sels.next();
            TotalStep ts = sel.getTotalStep();
            if (sel != null && ts != null)
            {
                BaseNode node = new Node(sel.getDimension());
                int edge = getEdge(node);
                if (ts.isLocationDependent())
                {
                    if (edge > -1)
                    {
                        int layer = getNode(edge, node);
                        if (layer > -1)
                        {
                            if (edge != ts.getEdge() || layer != ts.getLayer())
                            {
                                // Mismatch: is it in the remaining list?
                                if (isUnassignedTotal(ts))
                                {
                                    // Must remove it from this selection
                                    selChange.addElement(sel);
                                }
                            }
                        }
                    }
                }
                else if (ts.isAllLayers())
                {
                    // Check if the edges still match
                    if (ts.getEdge() != edge)
                    {
                        // If not, this one needs to be dissociated
                        selChange.addElement(sel);
                    }
                }
            }
        }
        // Go through the sel change list and nix their total steps
        Enumeration selenum = selChange.elements();
        while (selenum.hasMoreElements())
        {
            Selection sel = (Selection)selenum.nextElement();
            if (sel != null)
            {
                selections.remove(sel);
                sel.setTotalStep(null);
                selections.add(sel);
            }
        }

        return selections;
    }

    protected Hashtable getUnassignedTotals()
    {
        return m_unassignedTotals;
    }

    protected boolean isUnassignedTotal(TotalStep ts)
    {
        if (ts == null)
        {
            return false;
        }
        if (ts.isLocationDependent())
        {
            return m_unassignedTotals.get(_formTotalLocationKey(ts.getEdge(), ts.getLayer())) != null;
        }
        return false;
    }

    public String _formTotalLocationKey(int edge, int layer)
    {
        return edge + "," + layer;
    }

    // Determine if any of the dimension selections in this layout are marked as "defaults"
    // and are not of the given default replacement type--in other words, they need to be run
    // for caching and they need to be replaced
    // Returns a default step table pairing dimension IDs with their replacement steps or step types, if any
    public DefaultStepTable getDefaultSelectionsForReplacement(SelectionList selList, DefaultStepTable replacementSteps, MetadataFunctions query)
    {
        DefaultStepTable retVal = new DefaultStepTable();
        if (replacementSteps == null)
            return retVal;
            
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode = null;
        Selection currentSel = null;
        int edgeNum = 0;
        List nodeList = null;
        while (edgeIter.hasNext())
        {
            nodeList = (List)edgeIter.next();
            if (nodeList != null)
            {
                nodeIter = nodeList.iterator();
                int nodeNum = 0;
                while (nodeIter.hasNext())
                {
                    currentNode = (BaseNode)nodeIter.next();
                    if (currentNode != null)
                    {
                        // Determine if this node has any asym dependencies
                        currentSel = selList.find(currentNode.getName());
                        if (currentSel != null && currentSel.isFirstStepDefault())
                        {
                            Step s = replacementSteps.getReplacementForSelection(currentSel, query);
                            if (addIt(currentSel, s))
                            {
                                retVal.setStep(currentSel.getDimension(), s);
                            }
                        }
                    }
                }
            }
        }
        return retVal;
    }

    protected boolean addIt(Selection sel, Step s)
    {
        if (sel.getStepCount() > 0 && s != null)
        {
            Step currentStep = sel.getStep(0);
            // Make sure current step is not already an instanceof the replacement--if so, we don't need to replace
            return !currentStep.getClass().equals(s.getClass());
        }
        return false;
    }

    // Determine if this layout is acceptable given the list of selections
    // Checking asymmetry, etc.
    // Return selections whose asym drills must be deactivated or deleted
    // Return true if layout is otherwise acceptable, false if not
    public boolean isLayoutAcceptable(SelectionList selList, Vector asymDrillSels, Hashtable nonAsymDrillSels)
    {
        // Walk the tree, checking each found Node's dimension Selection for dependencies
        // and where that dependent might be in the layout
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode = null;
        Selection currentSel = null;
        int edgeNum = 0;
        List nodeList = null;
        while (edgeIter.hasNext())
        {
            nodeList = (List)edgeIter.next();
            if (nodeList != null)
            {
                nodeIter = nodeList.iterator();
                int nodeNum = 0;
                while (nodeIter.hasNext())
                {
                    currentNode = (BaseNode)nodeIter.next();
                    if (currentNode != null)
                    {
                        // Determine if this node has any asym dependencies
                        currentSel = selList != null ? selList.find(currentNode.getName()) : null;
                        if (currentSel != null)
                        {
                            Vector depDims = currentSel.getDependentDimensions();
                            if (depDims != null)
                            {
                                // Check locations of dimensions on which this node is dependent
                                // First of all, if the driver dimension is on the page edge, it's
                                // OK
                                Enumeration depDim = depDims.elements();
                                String dim = null;
                                BaseNode node = null;
                                while (depDim.hasMoreElements())
                                {
                                    dim = (String)depDim.nextElement();
                                    if (dim != null)
                                    {
                                        // Find the driver dim's Node and location
                                        node = getNode(dim);
                                        if (node != null)
                                        {
                                            int driverEdge = getEdge(node);
                                            switch (driverEdge)
                                            {
                                                case DataDirector.COLUMN_EDGE:
                                                    if (edgeNum == DataDirector.ROW_EDGE)
                                                    {
                                                        // Driver on column, driven is the row
                                                        // Orthogonal, unacceptable
                                                        return false;
                                                    }
                                                    if (edgeNum == DataDirector.PAGE_EDGE)
                                                    {
                                                        // Driver on column, driven on page
                                                        // Unacceptable
                                                        return false;
                                                    }
                                                    if (edgeNum > DataDirector.max_edge)
                                                    {
                                                        // Driver on column, driven hidden
                                                        // Unacceptable
                                                        return false;
                                                    }
                                                    break;
                                                case DataDirector.ROW_EDGE:
                                                    if (edgeNum == DataDirector.COLUMN_EDGE)
                                                    {
                                                        // Driver on row, driven is on column
                                                        // Orthogonal, unacceptable
                                                        return false;
                                                    }
                                                    if (edgeNum == DataDirector.PAGE_EDGE)
                                                    {
                                                        // Driver on row, driven on page
                                                        // Unacceptable
                                                        return false;
                                                    }
                                                    if (edgeNum > DataDirector.max_edge)
                                                    {
                                                        // Driver on row, driven hidden
                                                        // Unacceptable
                                                        return false;
                                                    }
                                                    break;
                                                case DataDirector.PAGE_EDGE:
                                                    if (edgeNum > DataDirector.max_edge)
                                                    {
                                                        // Driver on page, driven hidden
                                                        // Unacceptable
                                                        return false;
                                                    }
                                                    break;
                                                default:
                                                    break;
                                            }
                                            int driverLayer = getNode(driverEdge, node);
                                            if (edgeNum == driverEdge && nodeNum < driverLayer) {
                                              // Driven is outer dimension of driver
                                              // Unacceptable
                                              return false;
                                            }
                                        }
                                    }
                                }
                            }
                            // Now, check for asym drill dependencies
                            Vector asymDrillDeps = currentSel.getDependentDrillDimensions();
                            if (asymDrillDeps != null)
                            {
                                // Walk the list, checking their location.  They must be outside
                                // the location if this node, on the same edge
                                Enumeration depDim = asymDrillDeps.elements();
                                String dim = null;
                                BaseNode node = null;
                                while (depDim.hasMoreElements())
                                {
                                    dim = (String)depDim.nextElement();
                                    if (dim != null)
                                    {
                                        // Find the dependent's Node and location
                                        node = getNode(dim);
                                        if (node != null)
                                        {
                                            int depEdge = getEdge(node);
                                            if (depEdge != edgeNum)
                                            {
                                                // Edges are different: this sel must be cleaned
                                                if (asymDrillSels != null)
                                                {
                                                    asymDrillSels.addElement(currentSel);
                                                }
                                            }
                                            else
                                            {
                                                int depLayer = getNode(depEdge, node);
                                                if (depLayer > nodeNum)
                                                {
                                                    // Dependent is now inside selection: not good
                                                    if (asymDrillSels != null)
                                                    {
                                                        asymDrillSels.addElement(currentSel);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            // Now, if requested, return this node if there are non-asym drills
                            // and the node would now be under asymmetric drilling constraints
                            if (nonAsymDrillSels != null)
                            {
                                // We want to check nodes that now have something in a layer
                                // "outside" themselves now
                                if (nodeNum > 0)
                                {
                                    // Check if any non-asym drills
                                    Vector targets = currentSel.getNonAsymDrills();
                                    if (targets != null && targets.size() > 0)
                                    {
                                        // Store vector of targets in table by node name
                                        nonAsymDrillSels.put(currentNode.getName(), targets);
                                    }
                                }
                            }
                        }
                    }
                    // Track the node we're on
                    nodeNum++;
                }
            }
            // Track the edge we're on
            edgeNum++;
        }

        // Made it through: acceptable
        return true;
    }

    // Determine if this layout contains any TotalSteps
    public boolean anyTotals(SelectionList selList)
    {
        if (selList == null)
        {
            return false;
        }

        if (m_colTotalStep != null || m_rowTotalStep != null)
        {
            return true;
        }

        // Walk the tree, checking each found Node's dimension Selection for TotalSteps
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode = null;
        Selection currentSel = null;
        int edgeNum = 0;
        List nodeList = null;
        while (edgeIter.hasNext())
        {
            nodeList = (List)edgeIter.next();
            if (nodeList != null)
            {
                nodeIter = nodeList.iterator();
                int nodeNum = 0;
                while (nodeIter.hasNext())
                {
                    currentNode = (BaseNode)nodeIter.next();
                    if (currentNode != null)
                    {
                        // Determine if this node has any asym dependencies
                        currentSel = selList.find(currentNode.getName());
                        if (currentSel != null)
                        {
                            // Check for a total step
                            if (currentSel.getTotalStep() != null)
                            {
                                // We've found one: return
                                return true;
                            }
                        }
                    }
                    // Track the node we're on
                    nodeNum++;
                }
            }
            // Track the edge we're on
            edgeNum++;
        }

        // Made it through: no totals found
        return false;
    }
*/
    // Swap by node name
    public boolean swap(BaseNode sourceNode, BaseNode targetNode, boolean doSwap) throws CloneException
    {
        BaseNode foundSource = (BaseNode)_getNodeOrEdge(sourceNode, NODE_OBJECT, null);
        BaseNode foundTarget = (BaseNode)_getNodeOrEdge(targetNode, NODE_OBJECT, null);

        if (foundSource == null || foundTarget == null)
            return false;


        if (doSwap) {
            try
            {
                targetNode = (BaseNode)targetNode.clone();
                sourceNode = (BaseNode)sourceNode.clone();
            }
            catch (CloneNotSupportedException e)
            {
                throw new CloneException(e.getMessage(), e);
            }
            foundSource.setNode(targetNode);
            foundTarget.setNode(sourceNode);
        }
        return true;
    }
    
    // Swap by node position
    public boolean swap(int sourceEdge, int sourceNode, int targetEdge, int targetNode, boolean doSwap) throws CloneException
    {
        return swap(getNode(sourceEdge, sourceNode), getNode(targetEdge, targetNode), doSwap);
    }
    
    // Move by node name
    public boolean move(BaseNode sourceNode, BaseNode targetNode, boolean after, boolean doMove) throws CloneException
    {
        List sourceList = sourceNode == null ? null : _getNode(getEdge(sourceNode));
        List targetList = targetNode == null ? null : _getNode(getEdge(targetNode));
        if (sourceList == null || (targetList == null && targetNode == null))
            return false;

        // Test target node to see if it's a number, indicating an edge
        int targetEdge = -1;
        try {
            targetEdge = Integer.valueOf(targetNode.getName()).intValue();
        }
        catch (NumberFormatException nfe) {
            // Not an edge: actual dimension
        }
/*
        if (_willDependentsBeOrthogonal(sourceNode, targetEdge == -1 ? getEdge(targetNode) : targetEdge, selList))
        {
            return false;
        }
        if (_willNodeBeOrthogonalDependent(sourceNode, targetEdge == -1 ? getEdge(targetNode) : targetEdge, selList))
        {
            return false;
        }
        */
        int targetLoc = -1;
        if (doMove) {
            // Remove the source from its list
            sourceList.remove(sourceNode);
        }
        // Add it in to the target before or after
        if (targetEdge == -1) {
            targetLoc = targetNode == null ? 0 : (targetList == null) ? -1 : targetList.indexOf(targetNode);
        }
        else {
            targetList = _getNode(targetEdge);
            if (doMove) {
                if (targetList == null) {
                    targetList = new ArrayList();
                    targetList.add(sourceNode);
                }
                else {
                    if (after) {
                        targetList.add(sourceNode);
                    }
                    else {
                        targetList.add(0, sourceNode);
                    }
                }
                // Expand
                _growEdges(targetEdge);
                m_tree.set(targetEdge, targetList);
            }
            return true;
        }
        if (targetLoc == -1)
            return false;

        if (doMove) {
            if (after && targetNode != null) {
                targetLoc++;
            }
            targetList.add(targetLoc, sourceNode);
        }
        return true;
    }
    

    // Swap entire edges
    public boolean swapEdge(int sourceEdge, int targetEdge, boolean doSwap) {
        List sourceList = _getNode(sourceEdge);
        List targetList = _getNode(targetEdge);
        if (sourceList == null || targetList == null)
            return false;

        if (doSwap) {
            if (targetList != null) {
                // Expand
                _growEdges(sourceEdge);
                m_tree.set(sourceEdge, targetList);
            }
                                
            if (sourceList != null) {
                // Expand
                _growEdges(targetEdge);
                m_tree.set(targetEdge, sourceList);
            }
        }
            
        return true;
    }

    private int getPlacementFromID(Vector placement, String ID, boolean isRelational)
    {
        if (placement == null)
            return DataDirector.PAGE_EDGE;
            
        Enumeration items = placement.elements();
        while (items.hasMoreElements())
        {
            Object[] obj = (Object[])items.nextElement();
            if (obj != null && obj.length == 2)
            {
                if (obj[0] instanceof String)
                {
                    if (obj[0].equals(ID))
                    {
                        // Found
                        if (obj[1] instanceof Integer)
                        {
                            int edge = ((Integer)obj[1]).intValue();
                            if (isRelational && edge == DataDirector.ROW_EDGE)
                                return DataDirector.PAGE_EDGE;
                            return edge;
                        }
                    }
                }
            }
        }
        return DataDirector.PAGE_EDGE;
    }
    
    /**
     * @hidden
     * Build a default tree based on placements
     */
    public BaseNode[][] buildDefaultNodeArray(String measName, BaseNode[] dims, Vector placement, boolean isRelational) {
        BaseNode[][] dimTree = null;
        List dimList = Node.getList(dims);
        int size = dimList.size();
        dimTree = new BaseNode[3][];
            
        BaseNode measDim = null;
        measDim = new Node(measName);
        // See if measure is in placement list
        int measEdge = getPlacementFromID(placement, measName, isRelational);
        boolean bFoundMeas = false;
        Vector[] edges = new Vector[dimTree.length];
        for (int i = size - 1; i >= 0; i--)
        {
            if (dimList.get(i).equals(measDim)) {
                // Place it
                edges[measEdge] = new Vector();
                edges[measEdge].addElement(dimList.get(i));
                // Remove it from the list
                dimList.remove(i);
                bFoundMeas = true;
                break;
            }
        }
        
        // Place the rest of the items
        size = dimList.size();
        for (int i = 0; i < size; i++)
        {
            BaseNode currNode = (BaseNode)dimList.get(i);
            int edge = getPlacementFromID(placement, currNode.getName(), isRelational);
            if (edges[edge] == null)
                edges[edge] = new Vector();
            edges[edge].addElement(currNode);
        }
        
        // Transfer to array
        for (int edge = 0; edge < dimTree.length; edge++)
        {
            dimTree[edge] = (BaseNode[])Utility.copyVectorToArray(edges[edge]);            
        }

        return dimTree;
    }

    /**
     * @hidden
     * Build a default tree based on parameters
     */
    public BaseNode[][] buildDefaultNodeArray(String measName, BaseNode[] dims, int numColDims, int numRowDims, boolean isRelational) {
        BaseNode[][] dimTree = null;
        List dimList = Node.getList(dims);
        int size = dimList.size();
        dimTree = new BaseNode[3][];
            
        // From database bean: move measure up in list or to last place in column
        // if available
        BaseNode measDim = null;
        measDim = new Node(measName);
        int measLoc = isRelational ? numColDims-1 : 0;
        if (measLoc < 0)
        {
            measLoc = 0;
        }
        boolean bFoundMeas = false;
        int dimListSize = dimList.size();
        if (dimListSize == 0)
            return null;
        if (measLoc >= dimListSize)
        {
            measLoc = dimListSize-1;
        }
        for (int i = size - 1; i >= 0; i--)
        {
            if (dimList.get(i).equals(measDim)) {
                // Remove it from the list
                dimList.remove(i);
                bFoundMeas = true;
                break;
            }
        }
        // Redo the list with measure in the right place
        int counter = 0;
        List newDimList = new ArrayList();
        for (int d = 0; d < dimListSize; d++)
        {
            if (d == measLoc && bFoundMeas)
            {
                // Put in measure
                newDimList.add(measDim);
            }
            else
            {
                newDimList.add(dimList.get(counter));
                counter++;
            }
        }

        // Now allocate the dimensions in order according to their amounts
        // Columns
        counter = 0;
        // Special case: if the dimListSize-counter is less than the minimum number of col dims, guarantee one on the row
        // by setting numColDims one less than the dimListSize-counter
        if (dimListSize-counter <= numColDims)
            numColDims = dimListSize-counter-1;
            
        dimTree[0] = new BaseNode[Math.min(numColDims, dimListSize-counter)];
        for (int d = 0; d < dimTree[0].length; d++)
        {
            dimTree[0][d] = (BaseNode)newDimList.get(counter);
            counter++;
        }
        // Now allocate next batch on rows
        dimTree[1] = new BaseNode[Math.min(numRowDims, dimListSize-counter)];
        for (int d = 0; d < dimTree[1].length; d++)
        {
            dimTree[1][d] = (BaseNode)newDimList.get(counter);
            counter++;
        }
        // Now allocate rest on pages
        dimTree[2] = new BaseNode[dimListSize-counter];
        for (int d = 0; d < dimTree[2].length; d++)
        {
            dimTree[2][d] = (BaseNode)newDimList.get(counter);
            counter++;
        }
        return dimTree;
    }

/*    public boolean isNodeADependent(Node node, SelectionList selList) throws CloneNotSupportedException
    {
        Node[][] nodes = getDimTree();
        if (nodes == null) {
            // No nodes in tree: can't be a dependent
            return false;
        }
        if (node == null) {
            // Not found: can't be a dependent of any other node
            return false;
        }
        List dependents = null;
        for (int edge = 0; edge < nodes.length; edge++) {
            if (nodes[edge] != null) {
                for (int n = 0; n < nodes[edge].length; n++) {
                    Selection sel = selList.find(nodes[edge][n].getName());
                    if (sel != null)
                    {
                        dependents = QueryUtil.convertVectorToList(sel.getDependentDimensions());
                        if (dependents != null) {
                            // Scan the list for this node
                            if (dependents.indexOf(node.getName()) > -1) {
                                // Found it
                                return true;
                            }
                        }
                    }
                }
            }
        }
        // Wasn't found
        return false;
    }

    // Retrieve the list of nodes on which this node depends (dependent dimension asymmetry)
    public List getNodeDependencies(Node node, SelectionList selList) throws CloneNotSupportedException
    {
        List dependents = new ArrayList();
        Node[][] nodes = getDimTree();
        if (nodes == null) {
            // No nodes in tree: can't have dependents
            return dependents;
        }
        if (node == null) {
            // Not found: can't have dependents
            return dependents;
        }
        Selection sel = selList.find(node.getName());
        if (sel != null)
        {
            Vector names = sel.getDependentDimensions();
            if (names != null)
            {
                Enumeration name = names.elements();
                while (name.hasMoreElements())
                {
                    dependents.add(getNode((String)name.nextElement()));
                }
            }
        }
        return dependents;

    }

    // Return a list of Nodes that depend on the given node
    public List getDependentNodes(BaseNode node, SelectionList selList) throws CloneNotSupportedException
    {
        BaseNode[][] nodes = getDimTree();
        List dependents = new ArrayList();
        if (nodes == null) {
            // No nodes in tree: no one can depend
            return dependents;
        }
        if (node == null) {
            // Not found: no one can depend
            return dependents;
        }
        for (int edge = 0; edge < nodes.length; edge++) {
            if (nodes[edge] != null) {
                for (int n = 0; n < nodes[edge].length; n++) {
                    Selection sel = selList.find(nodes[edge][n].getName());
                    if (sel != null)
                    {
                        List tempDep = QueryUtil.convertVectorToList(sel.getDependentDimensions());
                        if (tempDep != null) {
                            // Scan the list for this node
                            if (tempDep.indexOf(node.getName()) > -1) {
                                // Found one: the current node depends on the given node
                                dependents.add(nodes[edge][n]);
                            }
                        }
                    }
                }
            }
        }
        return dependents;
    }

    // Determine if a given edge depends on one or more nodes in a second edge
    public boolean checkEdgeDependencies(int edgeToCheck, int drivingEdge, SelectionList selList) throws CloneNotSupportedException
    {
        BaseNode[] drivingEdgeNodes = getNode(drivingEdge);
        BaseNode[] checkNodes = getNode(edgeToCheck);
        if (drivingEdgeNodes == null || checkNodes == null)
            return false;

        // For each driving edge node, get a list of dependencies on it
        // and check those against the list of nodes on the edge to check
        for (int i = 0; i < drivingEdgeNodes.length; i++)
        {
            List depNodes = getDependentNodes(drivingEdgeNodes[i], selList);
            if (depNodes != null)
            {
                for (int c = 0; c < checkNodes.length; c++)
                {
                    if (depNodes.contains(checkNodes[c]))
                    {
                        // We found at least one of the nodes from the edge we're checking as dependent
                        // on a driving edge node
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Return a list of all the asymmetric nodes in this tree
    public List getAsymmetricNodes(SelectionList selList) throws CloneNotSupportedException
    {
        ArrayList retList = new ArrayList();
        Node[][] nodes = getDimTree();
        if (nodes == null) {
            return retList;
        }
        for (int edge = 0; edge < nodes.length; edge++) {
            if (nodes[edge] != null) {
                for (int node = 0; node < nodes[edge].length; node++) {
                    Selection sel = selList.find(nodes[edge][node].getName());
                    if (sel != null && sel.isAsymmetric()) {
//                    if (nodes[edge][node].isAsymmetric()) {
                        retList.add(nodes[edge][node]);
                    }
                }
            }
        }

        return retList;
    }

    // Determine if a given edge is asymmetric
    public boolean isEdgeAsymmetric(int startEdge, int count, SelectionList selList) throws CloneNotSupportedException
    {
        BaseNode[][] nodes = getDimTree();
        if (nodes == null)
        {
            return false;
        }
        int endEdge = nodes.length;
        if (count > -1)
            endEdge = startEdge + count;
        for (int edge = startEdge; edge < endEdge && edge < nodes.length; edge++)
        {
            if (nodes[edge] != null)
            {
                for (int node = 0; node < nodes[edge].length; node++)
                {
                    Selection sel = selList.find(nodes[edge][node].getName());
                    if (sel != null && (sel.isAsymmetric() || sel.hasAsymmetricDrill()))
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }
*/
    
    // Return the number of actual list objects at the edge storage in the tree
    private int _getEdgeHolderCount()
    {
        int count = 0;
        Iterator edgeIter = m_tree.iterator();
        while (edgeIter.hasNext())
        {
            if (edgeIter.next() != null)
            {
                count++;
            }
        }
        return count;
    }

    // Make sure there are enough edges to hold out to toEdge
    private void _growEdges(int toEdge) {
//        for (int edge = getEdgeCount()-1; edge < toEdge; edge++)
        for (int edge = _getEdgeHolderCount()-1; edge < toEdge; edge++)
        {
            m_tree.add(null);
        }
    }
    
    // Add in a list of nodes if not already in tree
    public void addNodes(Object[] nodeList, int startEdge) 
    {
        addNodes(nodeList, null, startEdge, false);
    }
    
    public void addNode(BaseNode node, int startEdge)
    {
        addNodes(new BaseNode[] {node}, startEdge);
    }
    
    // Add in a list of nodes if not already in tree
    public void addNodes(Object[] nodeList, Vector placement, int startEdge, boolean isRelational) {
        // Walk the list of nodes, and handle each one in turn
        for (int node = 0; node < nodeList.length; node++) {
            // Make sure it's not already here
            if (getNode((BaseNode)nodeList[node]) > -1)
                continue;
            
            boolean placed = false;
            if (placement != null)
            {
                int edge = getPlacementFromID(placement, ((BaseNode)nodeList[node]).getName(), isRelational);
                if (edge > -1)
                {
                    placed = true;
                    List currNode = _getNode(edge);
                    if (currNode == null || currNode.size() == 0)
                    {
                        _growEdges(edge);
                        ArrayList newList = new ArrayList();
                        newList.add(nodeList[node]);
                        m_tree.set(edge, newList);
                    }
                    else
                    {
                        currNode.add(nodeList[node]);
                        m_tree.set(edge, currNode);                        
                    }
                }
            }
            else
            {
                // Put it in the first completely open edge, or the page if none
                if (startEdge == -1)
                    startEdge = 0;
                for (int edge = startEdge; edge < Math.max(getEdgeCount(), DataDirector.PAGE_EDGE+1); edge++) {
                    List currNode = _getNode(edge);                
                    if (currNode == null || currNode.size() == 0) {
                        // Put it here and get out
                        _growEdges(edge);
                        ArrayList newList = new ArrayList();
                        newList.add(nodeList[node]);
                        m_tree.set(edge, newList);
                        placed = true;
                        break;
                    }
                }
            }
            if (placed)
                continue;
            
            // OK: put it in the page
            List currNode = _getNode(DataDirector.PAGE_EDGE);
            currNode.add(nodeList[node]);
        }
    }
    
    public void removeNodes(Object[] nodeList, int fromEdge)
    {
        // Walk the list of nodes, and handle each one in turn
        for (int node = 0; node < nodeList.length; node++) {
            // Make sure it's already here
            for (int edge = 0; edge < m_tree.size(); edge++) {
                List edgeNodes = _getNode(edge);
                if (edgeNodes != null) {
                    for (int n = 0; n < edgeNodes.size(); n++) {
                        if (nodeList[node] == null)
                            continue;
                        BaseNode found = (BaseNode)edgeNodes.get(n);
                        if (found != null && found.getName().equals(((BaseNode)nodeList[node]).getName())) {
                            if (fromEdge > -1) {
                                // Edge must match
                                if (fromEdge == edge) {
                                    // Remove it
                                    List currNodeList = _getNode(edge);
                                    currNodeList.remove(nodeList[node]);
                                }
                            }
                            else {
                                // Remove it
                                List currNodeList = _getNode(edge);
                                currNodeList.remove(nodeList[node]);                                
                            }
                        }
                    }
                }
            }
        }                
    }
    
    public void removeNode(BaseNode node)
    {
        removeNodes(new BaseNode[] {node});
    }
    
    // Remove a list of nodes if in tree
    public void removeNodes(Object[] nodeList) {
        removeNodes(nodeList, -1);
    }
    
    // Replace a node with another
    public void replaceNode(BaseNode nodeToReplace, BaseNode replacement)
    {
        int edge = getEdge(nodeToReplace);
        
        // Not found?
        if (edge == -1)
            return;
        
        // Remove it
        List currNodeList = _getNode(edge);
        int loc = currNodeList.indexOf(nodeToReplace);
        if (loc != -1)
            currNodeList.set(loc, replacement);            
    }
    
    // Remove all nodes in the tree that are not in the list
    public List pruneExtraNodes(BaseNode[] nodeList)
    {
        List remove = new ArrayList();
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode = null;
        while (edgeIter.hasNext())
        {
            List edgeList = (List)edgeIter.next();
            if (edgeList != null)
            {
                nodeIter = edgeList.iterator();
                while (nodeIter.hasNext()) {
                    currentNode = (BaseNode)nodeIter.next();
                    boolean found = false;
                    if (nodeList != null) {
                        for (int findNode = 0; findNode < nodeList.length; findNode++) {
                            if (currentNode.equals(nodeList[findNode])) {
                                found = true;
                                break;
                            }
                        }
                    }
                    if (!found)
                        remove.add(currentNode);
                }
            }
        }        
        if (remove.size() > 0)
            removeNodes(remove.toArray());
        return remove;
    }
    
    // Make sure a tree layout matches a given list of nodes, adding and/or
    // removing as necessary
    public List reconcileNodes(BaseNode[] nodeList)
    {
        // Must decide which to add, which to remove
        List add = new ArrayList();
        int edge;
        if (nodeList != null) {
            for (int node = 0; node < nodeList.length; node++) {
                edge = getEdge(nodeList[node]);
                // Is this an addition?
                if (edge == -1) {
                    add.add(nodeList[node]);
                }
            }
        }
        // Now walk the tree and see if each node here is in the given list
        List remove = pruneExtraNodes(nodeList);
        
        if (add.size() > 0) {
            addNodes(add.toArray(), -1);
        }
        return remove;
    }

    // Return the edge on which a given node is found: -1 if not found
    public int getEdge(BaseNode node) {
        return getEdge(node, null);
    }
    
    // Return the edge on which a given node is found: -1 if not found
    public int getEdge(BaseNode node, QDR loc) {
        return ((Integer)_getNodeOrEdge(node, EDGE, loc)).intValue();
    }

    // Return the node within some edge at which a given node is found
    public int getNode(BaseNode node) {
        return getNode(node, null);
    }

    // Return the node within some edge at which a given node is found
    public int getNode(BaseNode node, QDR loc) {
        return ((Integer)_getNodeOrEdge(node, NODE, loc)).intValue();
    }

    // Return the position within a given edge at which a given node is found
    public int getNode(int edge, BaseNode node) {
        BaseNode[] nodeList = getNode(edge);
        if (nodeList == null)
        {
            return -1;
        }
        for (int n = 0; n < nodeList.length; n++) {
            if (nodeList[n].equals(node)) {
                return n;
            }
        }
        return -1;
    }
    
    public String toString()
    {
        return toString(null);
    }
    
    public String toString(MetadataFunctions metadataManager)
    {
        BaseNode[][] tree = null;
        try
        {
            tree = getDimTree();
        }
        catch (CloneNotSupportedException e)
        {
            return "";
        }
        String output = "";
        if (tree != null)
            for (int edge = 0; edge < tree.length; edge++) {
                output += "Edge " + Integer.toString(edge) + ": ";
                for (int node = 0; node < tree[edge].length; node++)
                {
                    if (tree[edge][node] instanceof Node) {
                      ((Node)tree[edge][node]).setMetadataPrinter(m_metadataPrinter);
                    }
                    if (metadataManager != null)
                    {
                        try
                        {
                            MDObject obj = metadataManager.getMDObject(MM.UNIQUE_ID, tree[edge][node].toString(), MM.OBJECT);
                            if (obj != null)
                                output += tree[edge][node].toString() + "(" + obj.getName() + ");";
                            else
                                output += tree[edge][node].toString() + ";";                    
                        }
                        catch (MetadataManagerException e)
                        {                            
                        }
                    }
                    output += tree[edge][node].toString() + ";";                    
                }
                output += "\n";
            }
            
        return output;        
    }
    
    /**
     * @hidden
     */
    public String getTagName()
    {
        return XMLName;
    }

     /**
      * @hidden
      */
     public Object getXML(XMLContext retCons) {
        ObjectNode root = new ObjectNode(PersistableConstants.XMLNS + ":" + XMLName);
        root.addProperty("name", XMLName.toLowerCase());
        ContainerNode edges = new ContainerNode(PersistableConstants.XMLNS + ":Edges");
        edges.addProperty("name", "edges");
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        BaseNode currentNode;
        int edgeCount = 0;
        while (edgeIter.hasNext()) {
            List edgeList = (List)edgeIter.next();
            if (edgeList != null)
            {
                nodeIter = edgeList.iterator();
                while (nodeIter.hasNext()) {
                    currentNode = (BaseNode)nodeIter.next();
                    ObjectNode edgeNode = new ObjectNode(PersistableConstants.XMLNS + ":Dimension");
                    edgeNode.addProperty("name", currentNode.getName());
                    //edgeNode.addProperty(EDGE_PROP, edgeCount);
                    if(edgeCount == 0)
                      edgeNode.addProperty(EDGE_PROP, "columnedge");
                    else if(edgeCount == 1)
                      edgeNode.addProperty(EDGE_PROP, "rowedge");
                    else if(edgeCount == 2)
                      edgeNode.addProperty(EDGE_PROP, "pageedge");
                    else
                      edgeNode.addProperty(EDGE_PROP, "sectionedge");
                    edges.addContainedObject(edgeNode);
                }
                    edgeCount++;
            }
        }
        root.addContainer(edges);

        ContainerNode nulls = new ContainerNode(PersistableConstants.XMLNS + ":NullEdges");
        if (m_nullEdges != null) {
            ObjectNode node;
            for (int i = 0; i < m_nullEdges.size(); i++) {
                node = new ObjectNode("NullEdge");
                node.addProperty("Value", ((Boolean)m_nullEdges.get(i)).booleanValue());
                nulls.addContainedObject(node);
            }
        }
        root.addContainer(nulls);
        return root;
     }
     
     private int getEdge(String prop)
     {
         if (prop.equals("columnedge"))
             return DataDirector.COLUMN_EDGE;
         else if (prop.equals("rowedge"))
             return DataDirector.ROW_EDGE;
         else if (prop.equals("pageedge"))
             return DataDirector.PAGE_EDGE;
         return DataDirector.SECTION_EDGE;
     }
     
     /**
      * @hidden
      */
     public void setXML(XMLContext context, Object node) {
        ObjectNode root = (ObjectNode)node;
        ContainerNode edgelist = root.getContainer(PersistableConstants.XMLNS + ":Edges");
        Enumeration edges = edgelist.getContainerNodes();
        m_tree = new ArrayList();
        ArrayList nodeList = null;
        while (edges.hasMoreElements()) {
              BaseNode newNode = new Node("");
              ContainerNode edgeNode = (ContainerNode)edges.nextElement();
              newNode.setXML(context, edgeNode);
              int edge = getEdge(edgeNode.getProperty(EDGE_PROP).getValueAsString());
              _growEdges(edge);
              nodeList = (ArrayList)m_tree.get(edge);
              if (nodeList == null)
                  nodeList = new ArrayList();
              nodeList.add(newNode);
              m_tree.set(edge, nodeList);
        }
        m_nullEdges = new ArrayList();
        ContainerNode nulls = root.getContainer(PersistableConstants.XMLNS + ":NullEdges");
        if (nulls != null) {
            Enumeration nullEdges = nulls.getContainedObject();
            try
            {
                while (nullEdges.hasMoreElements()) {
                    ObjectNode nodeval = (ObjectNode)nullEdges.nextElement();
                    m_nullEdges.add(new Boolean(nodeval.getPropertyValueAsBoolean("Value")));
                }
            }
            catch (NoSuchPropertyException nspe)
            {
                throw new oracle.dss.dataSource.common.NoSuchPropertyException("Could not find property", nspe.getMessage(), nspe);
            }
        }
     }
	 
     
    // Walk tree to find node: field wanted true means edge, false means node
    private Object _getNodeOrEdge(BaseNode node, int fieldwanted, QDR loc) {
        // Walk the edges and then nodes until found
        Iterator edgeIter = m_tree.iterator();
        Iterator nodeIter;
        int edgeCount = 0;
        int nodeCount = 0;
        BaseNode currentNode = null;
        int lastFoundEdge = -1;
        int lastFoundLayer = -1;
        BaseNode lastFoundNode = null;
        while (edgeIter.hasNext())
        {
            List nodeList = (List)edgeIter.next();
            if (nodeList != null)
            {
                nodeIter = nodeList.iterator();
                nodeCount = 0;
                while (nodeIter.hasNext())
                {
                    currentNode = (BaseNode)nodeIter.next();
                    if (currentNode != null && currentNode.equals(node))
                    {
                        boolean found = true;
                        if (loc != null)
                        {
                            // Test against earlier nodes in the edge to see if this is the right one
                            for (int n = 0; n < nodeCount+1; n++)
                            {
                                QDRMember member = loc.getDimMember(currentNode.getName());
                                if (member == null)
                                {
                                    // We don't have this one: might be wrong edge, but let's remember this location just in case
                                    lastFoundEdge = edgeCount;
                                    lastFoundLayer = nodeCount;
                                    lastFoundNode = currentNode;
                                    found = false;
                                    break;
                                }
                            }
                        }
                        if (found)
                            return _getWalkedValue(fieldwanted, currentNode, edgeCount, nodeCount);
                    }
                    nodeCount++;
                }
            }
            edgeCount++;
        }
        if (lastFoundNode != null)
            return _getWalkedValue(fieldwanted, lastFoundNode, lastFoundEdge, lastFoundLayer);
        return _getWalkedValue(fieldwanted, null, -1, -1);
    }
    
    private Object _getWalkedValue(int fieldwanted, BaseNode nodeobj, int edge, int node) {
        switch (fieldwanted) {
            case EDGE:
                return new Integer(edge);
            case NODE:
                return new Integer(node);
            default:
                return nodeobj;
        }
    }


    // blm - Selection code moved to dvt-olap
/*    public void setUnassignedTotalState(ObjectNode objNode)
    {
        if (objNode == null)
            return;

        // Handle total state
        m_unassignedTotals = new Hashtable();
        ContainerNode totals = objNode.getContainer(UNASSIGNED_TOTAL_STATE);
        if (totals != null)
        {
            Enumeration totalSteps = totals.getContainedObject();
            while (totalSteps.hasMoreElements())
            {
                ObjectNode tsnode = (ObjectNode)totalSteps.nextElement();
                TotalStep ts = new TotalStep(null);
                ts.setState(tsnode);
                m_unassignedTotals.put(_formTotalLocationKey(ts.getEdge(), ts.getLayer()), ts);
            }
        }
    }


    public void setColEdgeTotalState(ObjectNode objNode)
    {
        if (objNode == null)
            return;

        // Process the TotalStep state
        m_colTotalStep = null;
        ContainerNode edgeTotals = objNode.getContainer(COL_EDGE_TOTAL_STATE);
        if (edgeTotals != null)
        {
            Enumeration totalSteps = edgeTotals.getContainedObject();
            while (totalSteps.hasMoreElements())
            {
                ObjectNode tsnode = (ObjectNode)totalSteps.nextElement();
                TotalStep ts = new TotalStep(null);
                ts.setState(tsnode);
                m_colTotalStep = ts;
            }
        }
    }


    public void setRowEdgeTotalState(ObjectNode objNode)
    {
        if (objNode == null)
            return;

        // Process the TotalStep state
        m_rowTotalStep = null;
        ContainerNode edgeTotals = objNode.getContainer(ROW_EDGE_TOTAL_STATE);
        if (edgeTotals != null)
        {
            Enumeration totalSteps = edgeTotals.getContainedObject();
            while (totalSteps.hasMoreElements())
            {
                ObjectNode tsnode = (ObjectNode)totalSteps.nextElement();
                TotalStep ts = new TotalStep(null);
                ts.setState(tsnode);
                m_rowTotalStep = ts;
            }
        }
    }

    public ContainerNode getColEdgeTotalState()
    {
        ContainerNode edgeTotal = null;
        if (m_colTotalStep != null)
        {
            edgeTotal = new ContainerNode(COL_EDGE_TOTAL_STATE);
            edgeTotal.addContainedObject(m_colTotalStep.getState());
        }
        return edgeTotal;
    }

    public ContainerNode getRowEdgeTotalState()
    {
        ContainerNode edgeTotal = null;
        if (m_rowTotalStep != null)
        {
            edgeTotal = new ContainerNode(ROW_EDGE_TOTAL_STATE);
            edgeTotal.addContainedObject(m_rowTotalStep.getState());
        }
        return edgeTotal;
    }
    
    public ContainerNode getUnassignedTotalState()
    {
        ContainerNode totals = null;
        if (m_unassignedTotals != null && m_unassignedTotals.size() > 0)
        {
            totals = new ContainerNode(UNASSIGNED_TOTAL_STATE);

            ObjectNode node;
            Enumeration elems = m_unassignedTotals.elements();
            while (elems.hasMoreElements())
            {
                TotalStep ts = (TotalStep)elems.nextElement();
                if (ts != null)
                {
                    totals.addContainedObject(ts.getState());
                }
            }
        }
        return totals;
    }
*/
	 /**
	  * Sets the state as String
      * @hidden
      */
	  // blm - Selection code moved to dvt-olap
/*	 public void setStateAsString(String state)
	 {
	 	StringTokenizer st = new StringTokenizer(state, String.valueOf(EDGE_DELIMITER));
		m_tree = new ArrayList();

		String edgeState = null;
		String nodeState = null;
				
		while (st.hasMoreTokens()) 
		{
			List nodeList = new ArrayList(); 
			edgeState = (String)st.nextToken();

			StringTokenizer nodes = new StringTokenizer(edgeState, String.valueOf(NODE_DELIMITER));
            while (nodes.hasMoreTokens()) 
			{
                BaseNode newNode = new Node("");
                String token = (String)nodes.nextToken();
                if (token != null && token.equals(String.valueOf(NULL_DELIMITER)))
                {
                    continue;
                }
				nodeState = Selection.unescapeStateString(token, DELIMITERS, null, ESCAPE_CHAR);
                newNode.setStateAsString(nodeState);
                nodeList.add(newNode);
            }
            m_tree.add(nodeList);
        }        	
	 }
*/	 
	 /**
	  * Retrieves the state as String
      * @hidden
      */
	  // blm - Selection code moved to dvt-olap
/*	 public String getStateAsString() throws CloneNotSupportedException
	 {
	 	BaseNode[][] tree = getDimTree();
        StringBuffer state = new StringBuffer();
        if (tree != null)
		{
            for (int edge = 0; edge < tree.length; edge++) 
			{
                if (edge > 0) state.append(EDGE_DELIMITER);
                if (tree[edge] == null || tree[edge].length == 0)
                {
                    // This edge is empty: put in a null
                    state.append(NULL_DELIMITER);
                }
                else
                {
                    for (int node = 0; node < tree[edge].length; node++)
                    {
                        state.append(Selection.escapeStateString
                            (tree[edge][node].getName(), DELIMITERS, null, ESCAPE_CHAR));
     					if (node < tree[edge].length - 1)
    					{
    						state.append(NODE_DELIMITER);
    					}
                    }
                }
            }
		}
            
        return state.toString();    	
	 }
*/
     public String[] getOuterDimensions(String dimension)
     {
        // Find the edge this dimension is on
        if (m_tree != null)
        {
            for (int edge = 0; edge < m_tree.size(); edge++)
            {
                List nodeList = _getNode(edge);
                if (nodeList != null)
                {
                    for (int node = 0; node < nodeList.size(); node++)
                    {
                        BaseNode dimNode = (BaseNode)nodeList.get(node);
                        if (dimNode != null && dimNode.getName().equals(dimension))
                        {
                            String[] outerDimensions = new String[node];
                            for (int i=0; i < node; i++)
                            {
                                BaseNode outerDimNode = (BaseNode)nodeList.get(i);
                                if (dimNode != null)
                                {
                                    outerDimensions[i] = outerDimNode.getName();
                                }
                            }
                            return outerDimensions;
                        }
                    }
                }
            }
        }
        return null;
     }

	//--------- End State Management implementation ---------//


     public String[] getInnerDimensions(String dimension) throws CloneException
     {
        // Find the edge this dimension is on
        BaseNode findNode = new Node(dimension);
        int edge = getEdge(findNode);
        if (edge != -1)
        {
            // Find the node
            int node = getNode(edge, findNode);
            if (node != -1)
            {
                int count = getNodeCount(edge);
                String[] retList = new String[count-node-1];

                // Walk the rest of the nodes inside
                for (int n = node+1; n < count; n++)
                {
                    retList[n - node - 1] = getNode(edge, n).getName();
                }
                return retList;
            }
        }
        return null;
     }


	
	
    // Field codes
    protected static final int  EDGE = 0;
    protected static final int  NODE = 1;
    protected static final int  NODE_OBJECT = 2;
    
    /**
     * @serial Tree storage: List of Lists
     */
    protected List m_tree = null;

    protected transient MetadataPrinter m_metadataPrinter = new DefaultMetadataPrinter();
    
    /**
     * @serial List of flags indicating null edges
     */
    protected List m_nullEdges = new ArrayList();

    // Positional totals that don't match a current dimension
    protected Hashtable m_unassignedTotals = new Hashtable();

    // Total steps to be applied to all layers on the column and/or row edges
    // blm - Selection code moved to dvt-olap
/*    protected TotalStep m_colTotalStep = null;
    protected TotalStep m_rowTotalStep = null;*/

    protected static final String XMLName = "DimTree";
	
	/***************************
	 * State Management support
	 ***************************/
	protected static final String STATE_NAME 			= "L";
	protected static final String EDGE_LIST_STATE 		= "EL";
	protected static final String NODE_LIST_STATE 		= "NL";
	protected static final String NULL_EDGE_LIST_STATE 	= "NEL";
	protected static final String NULL_EDGE_STATE 		= "NE";
	protected static final String EDGE_VALUE_STATE 		= "EV";
    protected static final String UNASSIGNED_TOTAL_STATE= "UTS";
    public static final String COL_EDGE_TOTAL_STATE  = "CTSS";
    public static final String ROW_EDGE_TOTAL_STATE  = "RTSS";

	protected static final char ESCAPE_CHAR         = 'q';
	protected static final char NODE_DELIMITER		= '*';
	protected static final char EDGE_DELIMITER		= '-';
    protected static final char NULL_DELIMITER      = '^';
    protected static final char[] DELIMITERS = {NODE_DELIMITER, EDGE_DELIMITER, NULL_DELIMITER};
}
