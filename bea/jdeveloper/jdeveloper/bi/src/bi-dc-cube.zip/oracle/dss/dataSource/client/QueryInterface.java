/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.client;

import java.util.List;
import java.util.BitSet;

import oracle.dss.dataSource.common.Delegate;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.RecoveryInfo;
import oracle.dss.datautil.QueryEditor;

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;

import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;

import oracle.dss.util.BIBaseException;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.StatusInfo;
import oracle.dss.util.transform.BaseProjection;

/**
 * @hidden
 * 
 * Pluggable interface defining a class that implements the common Query API.
 * 
 * @status New
 */
public interface QueryInterface
{    
    /**
     * Adds one or more items to an existing query in a <code>Query</code>
     * object. Creates a query if none exists.
     *
     * @param dataItems An array of the names of data Items to add to the query.
     * @param items An array of the names of the items to add to the query.  Ignored for dimensional queries
     *
     * @return BitSet representing edges affected by the change
     * 
     * @throws QueryException           If there is a problem with this operation.
     *
     * @status New
     */
    public BitSet addItems(String[] dataItems, String[] items) throws QueryException;
    
    /**
     * Adds the types in the specified data map to the DataMap for this
     * <code>Query</code> object.
     * These data map types will be included in subsequent data cursors for
     * the <code>Query</code> object.
     *
     * @param map   The <code>DataMap</code> that contains the desired types
     *              (such as formatted or unformatted data).
     *
     * @throws QueryException if an error occurs
     * 
     * @status New
     */
    public void applyDataMap(DataMap map) throws QueryException;
    
    /**
     * Adds the types in the specified metadata map to the MetadataMap for
     * a specific item in this <code>Query</code> object.
     * These metadata types will be included in subsequent metadata
     * cursors for this <code>Query</code> object.
     *
     * @param item      The item to which this map should be applied.
     * @param map       The <code>MetadataMap</code> that contains the
     *                  desired types (such as short labels or long labels).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status Needs change
     */
    public void applyMetadataMap(String item, MetadataMap map) throws QueryException;

    /**
     * Adds the types in the specified metadata map to the MetadataMap of
     *  this <code>Query</code> object.
     * These metadata types will be included in subsequent metadata cursors
     * for the edges of this <code>Query</code> object.
     *
     * @param edge  The edge to which these metadata types apply.
     *              Use the <code>oracle.dss.util.DataDirector</code> constants
     *              with the suffix _EDGE to specify edges.
     * @param map   The <code>MetadataMap</code> that contains the desired
     *              types (such as short labels or long labels).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     *
     * @status Documented
     */
    public void applyMetadataMap(int edge, MetadataMap map) throws QueryException;
    
    /**
     * Updates the implementing <code>Query</code> object with the changed
     * selection and/or layout information in the specified <code>QueryEditor</code> object.
     *
     * @param qa     The <code>QueryEditor</code> object that contains the
     *               state changes to apply to the QueryContext
     *               implementor, assuming that it has been initialized.
     * @param update <code>true</code> if the <code>QueryEditor</code> object
     *               is finished with the QueryContext and the implementor may
     *               run a query based on the new state, if desired;
     *               <code>false</code> if the <code>QueryEditor</code> object
     *               is not finished with the QueryContext.
     *
     * @return <code>true</code> if the update is successful;
     *                           <code>false</code> if the update is not
     *                           successful.
     *                           
     * @throws BIBaseException if an error occurs
     *
     * @status New
     */
    public boolean applyQueryEditor(QueryEditor qe, boolean update) throws BIBaseException;        
    
    /**
     * Applies the specified <code>Selection</code> objects to the
     * corresponding <code>Selection</code> objects in the Query.
     *
     * @param selections The <code>Selection</code> objects to apply.
     * @param dimensionalityChanged Was the dimensionality changed in the process of accepting these selections?
     *
     * @return BitSet representing edges affected by the change
     * 
     * @throws QueryException           If there is a problem fetching data.
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public BitSet applySelections(Selection[] selections) throws QueryException;*/
    
    /**
     * Cancels a current operation on the stack.
     *
     * @status Documented
     * @throws QueryException if an error occurs
     */
    public void cancel() throws QueryException;
    
    /**
     * Clones this Query.
     *
     * @return A newly-created copy of the <code>Query</code>.
     *
     * @throws CloneNotSupportedException If an error occurs
     *
     * @status New
     */
    public Object clone() throws CloneNotSupportedException;    
    
    /**
     * Creates a relational DataDirector 
     *
     * @return An implementation of the DataDirector interface.
     * @status New
     */
    public Delegate createRelationalDataDirector();    
    
    /**
     * Creates a cube DataDirector 
     *
     * @return An implementation of the DataDirector interface.
     * @status New
     */
    public Delegate createCubeDataDirector();    

    /**
     * Return the DataDirector associated with a given a DataAccess
     * 
     * @param da DataAccess2 for which to return a DataDirector
     * @return DataDirector used by the DataAccess
     */
    public DataDirector getDataDirector(DataAccess da);
    
    /**
     * Drills to relative levels of the specified hierarchies accepting
     * values' parents for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param target       The dimension drill targets, also known as the
     *                     dimension members, to drill.
     * @param hierarchy    The target hierarchies for the drill.
     * @param delta        The relative numbers of levels to traverse within the
     *                     specified hierarchies. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param above        If true, insert the targets' drill results above the targets rather
     *                     than below, which is the default.
     * @param valueParent  Values' parent dimension values; used for
     *                     optimizing later potential drill up requests.
     * @param queryAncestor The items from the original query members under
     *                     which these drills occur.
     * @param levelDepth   Optional performance hints indicating the numeric 
     *                     levels at which the drill targets sit within their 
     *                     hierarchies.
     * @param parentQDR    Optional OlapQDRs specifying dimension/member pairs
     *                     that limits where drills (down) should occur 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status New
     */
    public void drill(String dimension, String[] target, String[] hierarchy, Integer[] delta, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException;

    /**
     * Drills to specific levels of the specified hierarchies accepting
     * a values' parents for later optimization of drill steps.
     *
     * @param dimension    The dimension to drill.
     * @param target       The dimension drill targets, also known as the
     *                     dimension members, to drill.
     * @param hierarchy    The target hierarchies for the drill.
     * @param level        The specific levels to drill to within the
     *                     specified hierarchies. 
     * @param above        If true, insert the targets' drill results above the targets rather
     *                     than below, which is the default.
     * @param valueParent  Values' parent dimension values; used for
     *                     optimizing later potential drill up requests.
     * @param queryAncestor The items from the original query members under
     *                     which these drills occur.
     * @param levelDepth   Optional performance hints indicating the numeric 
     *                     levels at which the drill targets sit within their 
     *                     hierarchies.
     * @param parentQDR    Optional OlapQDRs specifying dimension/member pairs
     *                     that limits where drills (down) should occur 
     *                     (parents of the target).
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status New
     */
    public void drill(String dimension, String[] target, String[] hierarchy, String[] level, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException;
    
    /**
     * Drills to specified level of the specified hierarchy, or to the specified item (level).
     *
     * @param item The item to drill.
     * @param value     The item's value (also known as member) to drill.
     * @param valueLevel The item value's level.
     * @param hierarchy The name of the target hierarchy, if any.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @param data     Extra metadata/data
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * @status new
     */
    public void drill(String item, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException;
    
   /**
     * Drills the specified members to the specified drill targets using the specified drill paths.
     *
     * @param item      The item to drill.
     * @param onEdge    Edge on which drill took place, if a layer (item) might exist on multiple edges
     * @param target    The members to drill.
     * @param drillPath The drill paths (e.g., hierarchies) to use.
     * @param drillTarget The drill targets (e.g., levels) to use.
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @status new
     */
    public void drill(String item, int onEdge, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException;
    
    /**
     * Returns a default Selection/Step that the Query would define for the
     * given dimension.
     *
     * @param  Dimension for which to return a default Selection
     * @return A default Selection/Step that the Query would define if none were provided.
     *         Returns null if no default can be defined.
     *
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String dimension) throws QueryException;*/

    /**
     * Returns a default layout from a list of item IDs.
     *
     * @param dataItems data point items that may be laid out if tabular
     * @param items items to lay out.
     * @return Edge-by-layer array of item IDs in a default layout.
     *
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public String[][] getDefaultLayout(String[] dataItems, String[] items) throws QueryException;
    
    /**
     * Return an implementation-specific object representing the current "query"
     * 
     * @return implementation specific query object, or null if nothing has been defined
     */
    public Object getQueryObject();
    
    /**
     * Returns a set of objects implementing DataAccess2 based on the current query
     * result set.
     * 
     * @param dd DataDirector3 objects to embed in each DataAccess returned.  The number of 
     *           DataAccess objects returned should match the number of DataDirector3's passed in.
     * @param changeType Type of change for which a DataAccess is being requested, defined in oracle.dss.util.DataChangedEvent.
     * 
     * @return DataAccess2 implemenation objects, if query has been initialized
     * 
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public DataAccess[] generateDataAccess(DataDirector[] dd, int changeType) throws QueryException;

    /**
     * Return the SQL generated by the last query execution, if available.
     * 
     * @param edge  Edge for which to return last SQL, or -1 for all available SQL.
     * 
     * @return SQL for last executed query, if available.  null if not.
     * 
     * @throws QueryException if an error occurs.
     */
    public String getQuerySQL(int edge) throws QueryException;    
    
    /**
     * Specifies the full set of CalcDefinitions to be used by this Query.  If definitions
     * involves a change to the Query's CalcDefinitions, the Query will refresh.
     *
     * @param definitions all non item-based calculations to be used by the Query
     *
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public void setCalcDefinitions(Object[] definitions) throws QueryException;

    /**
     * Returns the full set of CalcDefinitions used by this Query. 
     *
     * @return all non item-based calculations used by the Query
     *
     * @status New
     */
    public Object[] getCalcDefinitions();

    /**
     * Checks a given MDObject (measures are the only
     * type of MDObject checked at this time) and determines
     * if the query makes use of the object in its selections
     * or measure list.
     *
     * @param object MDObject representing the object to check
     * @return <code>true</code> if the query uses the object,
     *         <code>false</code> otherwise
     *
     * @status New
     */
    public Boolean isDependentOn(MDObject object);

    /**
     * Returns an Object indicating support or level of support for 
     * a given capability.  The capability parameter is a set of predefined constants covering capability
     * support that will change with data source type.  These constants will be defined as needed.  
     * Each capability constant will define its expected return value.
     *
     * @param capability A predefined capability constant about which to inquire.
     * @param data      Optional object to check against the capability property passed in
     *                  (for example, an inquiry may be made about a capability given a certain metadata ID).
     * 
     * @return Object defined by the capability constant representing the support level for the capability.
     *
     * @status New
     */
    public Object isSupported(int capability, Object data) throws QueryException;

    /**
     * Informs an interface implementation about a property being set, in case the implementation
     * needs to update the query, etc.
     *
     * @param property A property constants (see QueryConstants)
     * @param value     New value of the property.
     * 
     * @status New
     */
    public void setProperty(String property, Object value) throws QueryException;

   /**
    * Arranges a layout of dimensions along the edges of a <code>Query</code>
    * object.
    *
    * @param dimensions An array of dimension layout arrays.
    *                   The outer array maps to edges (such as column or row);
    *                   the inner array maps slowest to fastest varying within
    *                   an edge.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @return edges changed if successful, null if failure
    *
    * @status Documented
    */
   public BitSet layout(String[][] items) throws QueryException, MetadataManagerException;

    /**
     * Facilitates the re-execution of a query loaded from a persistent store.
     * 
     * @return <code>true</code> if successful, <code>false</code> if not.
     */
    public boolean loadQuery() throws QueryException;
    
   /**
    * Performs the specified pivot operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension (if an edge is empty, then this
    *                     must be a number that indicates the target edge)
    * @param flags        A constant that indicates the type of pivot. Use
    *                     <code>PivotConstants.PIVOT_AFTER</code> or
    *                     <code>PivotConstants.PIVOT_BEFORE.
    * @return BitSet representing edges affected by the pivot
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    *
    * @see PivotConstants#PIVOT_AFTER
    * @see PivotConstants#PIVOT_BEFORE
    *
    * @status Documented
    */
   public BitSet pivot(String source, String target, int flags) throws QueryException;

   /**
    * Determines if the specified pivot operation is OK.
    *
    * @param source       The source dimension.
    * @param target       The target dimension (if an edge is empty, then this
    *                     must be a number that indicates the target edge)
    * @param flags        A constant that indicates the type of pivot. Use
    *                     <code>PivotConstants.PIVOT_AFTER</code> or
    *                     <code>PivotConstants.PIVOT_BEFORE.
    *                     
    * @return DataDirector3 code indicating if the proposed pivot operation is OK, and if not, why not.
    *
    * @throws QueryException           If there is a problem during this operation.
    *
    * @see PivotConstants#PIVOT_AFTER
    * @see PivotConstants#PIVOT_BEFORE
    *
    * @status New
    */
   public int pivotCheck(String source, String target, int flags) throws QueryException;

   /**
    * Determines if the specified swap operation is OK.
    *
    * @param source       The source dimension.
    * @param target       The target dimension
    * 
    * @return DataDirector3 code indicating if the proposed swap operation is OK, and if not, why not.
    *
    * @throws QueryException           If there is a problem during this operation.
    *
    * @status New
    */
   public int swapCheck(String source, String target) throws QueryException;

   /**
    * Performs the specified swap operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension.
    * @return BitSet representing edges affected by the pivot
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    *
    * @status Documented
    */
   public BitSet swap(String source, String target) throws QueryException;

   /**
    * Performs the specified edge swap operation.
    *
    * @param source  A constant (<code>DataDirector.COLUMN_EDGE</code>,
    *               <code>DataDirector.PAGE_EDGE</code>, or
    *               <code>DataDirector.ROW_EDGE</code>) that represents
    *               the source edge.
    * @param target  A constant (<code>DataDirector.COLUMN_EDGE</code>,
    *               <code>DataDirector.PAGE_EDGE</code>, or
    *               <code>DataDirector.ROW_EDGE</code>) that represents
    *               the target edge.
    *
    * @throws QueryException           If there is a problem fetching data after
    *                                  this operation.
    * @throws MetadataManagerException If an error occurred using the
    *                                  MetadataManager bean.
    *
    * @see oracle.dss.util.DataDirector#COLUMN_EDGE
    * @see oracle.dss.util.DataDirector#PAGE_EDGE
    * @see oracle.dss.util.DataDirector#ROW_EDGE
    *
    * @status Documented
    */
   public void swapEdges(int source, int target)  throws QueryException;
    
    /**
     * If called after a Query fails to evaluate after a persistence
     * lookup, recover will return an object containing a code
     * and a list of names or IDs found to cause the failure.
     * recover will optionally attempt to modify and refresh the Query 
     * to avoid the failure.
     * recover will optionally return information about dimensions that
     * caused no data conditions.
     * 
     * @param fix if <code>true</code>, recover will attempt to 
     * 		modify and refresh the Query to avoid the failure
     * @param nodata if <code>true</code>, recover will 
     * 		determine which dimensions caused a no data 
     * 		condition and return this information
     * @param If specified, a structure allowing an application to specify
     *        replacement metadata where a loaded query definition may be lacking
     *        or have invalid metadata IDs.
     * 
     * @return A <code>RecoverInformation</code> object, containing
     * 		an error code and possible metadata IDs found to have
     * 		caused a load failure.
     * 
     * @throws QueryException if an error occurs
     * 
     * @status New
     */
    public RecoveryInfo recover(boolean fix, boolean nodata, Object specification) throws QueryException;    
    
    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object.
     *
     * @param type      Enumerated QueryConstant:
     *                      REFRESH_ALL (reload saved selections, calculations, conditions, etc., rebuild structures
     *                                   and re-execute)
     *                      REFRESH_REBUILD (rebuild all structures and re-execute)
     *                      REFRESH_CURSORS (refresh cursors)
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status New
     */
    public void refresh(int type) throws QueryException;
    
    /**
     * Cleans up all structures used in the query implementation.  Called when the query is closing.
     * 
     * @status New
     */
    public void release() throws QueryException;
    
    /**
     * Removes one or more items from an existing query.  
     *
     * @param measures An array of the names of the measures to be removed.
     * 
     * @return BitSet representing edges affected by the change
     * 
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status new
     */
    public BitSet removeItems(String[] items) throws QueryException;

    /**
     * Removes the specified <code>Selection</code> object from
     * this <code>Query</code>.
     *
     * @param selection The <code>Selection</code> object to remove.
     *
     * @return BitSet representing edges affected by the change
     * 
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
  // blm - Selection code moved to dvt-olap
/*    public BitSet removeSelection(Selection selection) throws QueryException, MetadataManagerException;*/

    /**
     * Rolls back data write back changes.
     * 
     * @return <code>true</code> if successful.
     * 
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public boolean rollback() throws QueryException;
    

    /**
     * Specifies the full set of DataFilters to be used by this Query.  If filters
     * involves a change to the Query's DataFilters, the Query will refresh.
     *
     * @param filters all DataFilters to be used by the Query
     * @return BitSet representing edges affected by the pivot
     *
     * @throws QueryException thrown if an error occurs, or if data filters are not supported
     * 
     * @status New
     */
    public BitSet setDataFilters(BaseDataFilter[] filters) throws QueryException;      
    
    /**
     * Specifies the full set of ColumnSorts to be used by this Query.  If sorts
     * involves a change to the Query's ColumnSorts, the Query will refresh.
     *
     * @param sorts all ColumnSorts to be used by the Query
     * @return BitSet representing edges affected by the pivot
     *
     * @throws QueryException thrown if an error occurs, or if column sorts are not supported
     * 
     * @status New
     */
    public BitSet setColumnSorts(ColumnSortWrapper[] sorts) throws QueryException;      
    
    /**
     * Specifies the full set of ItemSorts to be used by this Query.  If sorts
     * involves a change to the Query's ItemSorts, the Query will refresh.
     *
     * @param sorts all ItemSorts to be used by the Query
     * @return BitSet representing edges affected by the pivot
     *
     * @throws QueryException thrown if an error occurs, or if item sorts are not supported
     * 
     * @status New
     */
    public BitSet setItemSorts(ItemSortWrapper[] sorts) throws QueryException;      
    
    /**
     * Sets items or data items on the query.  Also see <code>addItems</code> and
     * <code>removeItems</code>.  The items will be placed in a default layout if none is given, and/or
     * dimensions will be chosen based on the data items and placed in a default layout.
     *
     * @param dataItems the data items to set.
     * @param items the non-data items to set (if no layout: ignored if dataItems are measures).
     * @param layout layout of items
     *
     * @return BitSet describing which edges changed
     * 
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public BitSet setItems(String[] dataItems, String items[], String[][] layout) throws QueryException;
    
    /**
     * Specifies a map that determines the contents of future data cursors
     * for this query for all clients of this <code>Query</code>.
     * (Resets cumulative <code>applyDataMap</code> operations; generally only
     * called on a clone of the <code>Query</code>.)
     *
     * @param map The map that contains the desired data types.
     *
     * @throws QueryException if an error occurs
     * 
     * @status Documented
     */
    public void setDataMap(DataMap map) throws QueryException;

    /**
     * Specifies a map that determines the contents of future metadata cursors
     * for all clients of this <code>Query</code> object.
     * (Resets cumulative <code>applyMetadataMap</code> operations; generally
     * only called on a clone of the <code>Query</code>.)
     *
     * @param dimension The name of the dimension for which the
     *                  <code>MetadataMap</code> is to be specified.
     * @param map       The <code>MetadataMap</code> that contains the desired
     *                  metadata types.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     *
     * @status Documented
     */
    public void setMetadataMap(String dimension, MetadataMap map) throws QueryException;        
    
    /**
     * Submits a list of QDRs for write back, if possible.
     * 
     * @param list List of QDRoverride objects to write back, if possible.
     * 
     * @return <code>true</code> if successful
     * 
     * @throws QueryException thrown if an error occurs.
     * 
     * @status New
     */
    public boolean submit(List list) throws QueryException;
    
    /**
     * Signals this Query to execute pending operations in order.
     *
     * @throws  Exception Any middle tier exception.
     *
     * @status Documented
     */
    public void update() throws Exception;    
    
    /**
     * Validate a Query, edge, Selection, or Step depending on the given argument.
     * 
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param object object to validate: can be Query, edge Integer, Selection or Step.
     * 
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     *         
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Object object) throws QueryException;*/
    
   
    /**
     * Returns an object that contains progress information (if supported) and contains 
     * an enumerated status constant, and a return value if the call has completed successfully
     * and the call returns a value.
     * 
     * @param startExecution    Should execution be started if query is not in that state, or status just returned
     *                          if not in an executing state?  Note: false will continue execution if the query is
     *                          already executing.
     * @return Object containing status, progress information (if supported), and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo getStatus(boolean startExecution) throws QueryException;   
    
   /**
    * Specifies the current page if pages are shared among listeners.
    *
    * @param page    Page number to share among listeners.
    * @param qdrPage QDR version of the page.
    *
    * @throws QueryException if an error occurs.
    * 
    * @status New
    */
   public void setCurrentPage(long page, QDR qdrPage) throws QueryException;
   
   /**
    * Is data currently available?
    * 
    * @return <code>true</code> if data is available, <code>false</code> if not
    * 
    * @status New
    */
   public boolean isDataAvailable();
    
    /**
     * Return the current data set projection from this query, if any
     * 
     * @param layerMetadataType The type of metadata object ID to use in the returned projection.
     * 
     * @return BaseProjection object, if available and relevant
     * 
     * @throws QueryException if an error occurs.
     */
    public BaseProjection getProjection(String layerMetadataType) throws QueryException;    
}
