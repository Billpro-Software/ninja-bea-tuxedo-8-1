/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.awt.Color;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

/**
 * @hidden
 * Methods that are used to set atttributes for specified values.
 *
 * @status New
 */

public class KeyAttributeSetHashtableImpl
{
    //-------------------------------------------------------------------------
    // PUBLIC CONSTANTS
    //-------------------------------------------------------------------------

    /**
     * Action that adds one or more attributes to a key object.
     *
     * @status New
     */
    public static final int KEYATTRIBUTESET_ATTRIBADD = 1;
    
    /**
     * Action that removes one or more attributes from a key object.
     *
     * @status New
     */
    public static final int KEYATTRIBUTESET_ATTRIBREMOVE = 2;
    
    /**
     * Action that modifies one or more existing attributes of a key object.
     *
     * @status New
     */
    public static final int KEYATTRIBUTESET_ATTRIBSET = 3;
    
    /**
     * The character delimiting key value pairs.
     *
     * @status New
     */
    public static final String KEYATTRIBUTESET_PAIRDELIMITER = ":";
     
    /**
     * The character separating key value pairs.
     *
     * @status New
     */
    public static final String KEYATTRIBUTESET_PAIRSEPARATOR = "#";
    
    //-------------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-------------------------------------------------------------------------
        
    /**
     * The list of key objects and their attributes.
     *
     * @status New
     */
    protected Hashtable m_keyList = null;

    /**
     * The resource bundle containing the list of key and and their attributes.
     *
     * @status New
     */
    protected ResourceBundle m_resources = null;
    
    /**
     * List of key attribute listeners
     *
     * @status New
     */
    protected Vector m_listKeyAttributeListeners = null;

    //-------------------------------------------------------------------------
    // CONSTRUCTOR
    //-------------------------------------------------------------------------

    /**
     * Constructs a default DefaultKeyAttributeSet object.
     *
     * @status New
     */
    public KeyAttributeSetHashtableImpl ( )
    {
        m_keyList = new Hashtable ( );
    }
    
    //-------------------------------------------------------------------------
    // PUBLIC METHODS
    //-------------------------------------------------------------------------

    /**
     * Adds a listener to the current object.
     *
     * @param keyAttributeListener a <code>KeyAttributeListener</code> value 
     * that represents the listener to add.
     *
     * @status New
     */
    public void addKeyAttributeListener ( KeyAttributeListener keyAttributeListener )
    {
        boolean bDuplicate = false;

        if ( m_listKeyAttributeListeners == null )
            m_listKeyAttributeListeners = new Vector ( );

        bDuplicate = ! m_listKeyAttributeListeners.isEmpty ( ) &&
                       m_listKeyAttributeListeners.contains ( keyAttributeListener );

        // Only add listener if it doesn't already exist
        if ( ! bDuplicate )
            m_listKeyAttributeListeners.addElement ( keyAttributeListener );
    }
    
    /**
     * Fires a KeyAttributeEvent with the specified event type.
     *
     * @param token a <code>Token</code> value that represents the 
     * token's associated data.
     *     
     * @status New
     */
    public boolean fireKeyAttributeAvailableEvent ( Hashtable keyAttributes, 
                                                    String strKey, String strValue )
    {
        boolean                 bRetVal                 = false;
        int                     nIndex                  = -1;
        KeyAttributeEvent       keyAttributeEvent       = null;
        KeyAttributeListener    keyAttributeListener    = null;

        if ( null == keyAttributes ||
             null == strKey || null == strValue )
            return false;

        if ( null == m_listKeyAttributeListeners ||
             0 == m_listKeyAttributeListeners.size ( ) )
             return false;
             
        keyAttributeEvent = new KeyAttributeEvent ( keyAttributes, strKey, strValue );
        for ( nIndex = 0; nIndex < m_listKeyAttributeListeners.size ( ); nIndex++ )
        {
            keyAttributeListener = ( KeyAttributeListener ) m_listKeyAttributeListeners.
                                                            elementAt ( nIndex );
            keyAttributeListener.keyAttributeAvailable ( keyAttributeEvent );
        }
        
        return true;
    }

    /**
     * Initializes the contents of the object using the specified resource
     * file
     *
     * @param strResourceFilePath The specified resource file path.
     *
     * @return The initialized contents of the file.
     *
     * @status New
     */
    public boolean initializeContents ( String strResourceFilePath )
    {
        m_resources = initializeResources ( strResourceFilePath );
        if ( null == m_resources )
            return false;
                                      
        return loadKeyAttributeSet ( m_resources, m_keyList );
    }
    
    /**
     * Removes a listener from this objects listener list.
     *
     * @param keyAttributeListener a <code>KeyAttributeListener</code> value 
     * that represents the listener to remove.
     *
     * @status New
     */
    public void removeKeyAttributeListener ( KeyAttributeListener keyAttributeListener )
    {
        if ( m_listKeyAttributeListeners != null )
            m_listKeyAttributeListeners.removeElement ( keyAttributeListener );
    }

    //-------------------------------------------------------------------------
    // Start implementation of KeyAttributeSet interface
    //-------------------------------------------------------------------------
    
    /**
     * Retrieves the list of key objects that contain the specified attribute name
     * and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     *
     * @return The list of key objects
     *
     * @status New
     */
    public Vector getAttributeNameList ( Object attribFind, Object attribValue )
    {
        Enumeration attribNames     = null;
        Object      retVal          = null;
        Hashtable   attribSet       = null;
        String      key             = null;      
        Vector      attribList      = null;

        if ( null == attribFind || null == attribValue ) 
            return null;
        
        attribNames = m_keyList.keys ( );
        if ( null == attribNames ) 
            return null;
        
        attribList = new Vector ( );
        while ( attribNames.hasMoreElements ( ) )
        {
            key = ( String ) attribNames.nextElement ( );
            
            retVal = getKeyAttributes ( key );
            if ( ! ( retVal instanceof Hashtable ) ) 
                continue;

            attribSet = ( Hashtable ) retVal;
            if ( attribValue.equals ( attribSet.get ( attribFind ) ) )
            {
                attribList.addElement ( new String ( key ) );
            }                
        }
        
        return attribList;
    }
    
    /**
     * Retrieves the mutable attributes of the specified key object
     * The mutable attributes of key that have null names cannot be retrieved.
     *
     * @param key  The name of the key.
     *
     * @return The <code>Hashtable</code> object.
     *                   
     * @status New
     */
    public Hashtable getKeyAttributes ( String key )
    {
        Object keyAttributes = null;

        if ( null == key )
            return null;

        if ( m_keyList.containsKey ( key ) )
            keyAttributes = m_keyList.get ( key );
            
        if ( keyAttributes != null && keyAttributes instanceof Hashtable )
            return ( Hashtable ) keyAttributes;
            
        return null;
    }
    
    /**
     * Retrieves the value of an attribute for the specified key object
     *
     * @param key The name of the key.
     * @param attribute The attribute for the specified key.
     *
     * @return The value for the specified attribute.
     *                   
     * @status New
     */
    public Object getKeyAttributeValue ( String key, Object attribute )
    {
        Hashtable attributeSet = null;
        
        attributeSet = getKeyAttributes ( key );
        if ( null == attributeSet ) 
            return null;
            
        if ( attribute != null && attributeSet.containsKey ( attribute ) )
            return attributeSet.get ( attribute );
            
        return null;            
    }
    
    /**
     * Retrieves the immutable list of key objects.
     *
     * @return The <code>Hashtable</code> object.
     *                   
     * @status New
     */
    public Hashtable getKeyList ( )
    {
        return ( Hashtable ) m_keyList;
    }            

    /**
     * Adds, modifies, or removes an attribute for any key object that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *                   
     * @status New
     */
    public boolean updateAttribute ( Object attribFind, Object attribValue, 
                                     Object name, Object value, int actionType )
    {                                  
        boolean     bRetVal         = false;
        Hashtable   attribTarget    = null;
        int         nIndex          = -1;
        Vector      attribNames     = null;
        
        attribNames = getAttributeNameList ( attribFind, attribValue );
        for ( nIndex = 0; nIndex < attribNames.size ( ); nIndex++ )
        {
            attribTarget = getKeyAttributes ( ( String ) attribNames.elementAt ( nIndex ) );
            if ( null == attribTarget ) 
                continue;
            
            bRetVal = performAction ( attribTarget, name, value, actionType );
            if ( ! bRetVal ) 
            {
                break;
            }                
        }
        
        return bRetVal;
    }
    
    /**
     * Adds, modifies, or removes a set of attributes for any key that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param attribSet The <code>Hashtable</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status New
     */
    public boolean updateAttributeSet ( Object attribFind, Object attribValue, 
                                        Hashtable attribSet, int actionType )
    {                                     
        boolean     bRetVal         = false;
        Hashtable   attribTarget    = null;
        int         nIndex          = -1;
        Vector      attribNames     = null;
        
        attribNames = getAttributeNameList ( attribFind, attribValue );
        for ( nIndex = 0; nIndex < attribNames.size ( ); nIndex++ )
        {
            attribTarget = getKeyAttributes ( ( String ) attribNames.elementAt ( nIndex ) );
            if ( null == attribTarget ) 
                continue;
            
            bRetVal = performAction ( attribTarget, attribSet, actionType );
            if ( ! bRetVal ) 
            {
                break;
            }                
        }
        
        return bRetVal;
    }
    
    /**
     * Adds, modifies, or removes an attribute for a specified key.
     *
     * @param key The name of the key.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status New
     */
    public boolean updateKeyAttribute ( String key, Object name, 
                                        Object value, int actionType )
    {                                       
        boolean     bRetVal         = false;
        Hashtable   attribTarget    = null;
        
        attribTarget = getKeyAttributes ( key );
        bRetVal = performAction ( attribTarget, name, value, actionType );
        
        return bRetVal;
    }                                   

    /**
     * Adds, modifies, or removes a set of attributes for a specified key. 
     *
     * @param key The name of the key.
     * @param attribSet The <code>Hashtable</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status New
     */
    public boolean updateKeyAttributeSet ( String key, Hashtable attribSet, int actionType )
    {
        boolean     bRetVal         = false;
        Hashtable   attribTarget    = null;
        
        attribTarget = getKeyAttributes ( key );
        bRetVal = performAction ( attribTarget, attribSet, actionType );
        
        return bRetVal;
    }                                       
    
    //-------------------------------------------------------------------------
    // End implementation of KeyAttributeSet interface
    //-------------------------------------------------------------------------

    /**
     * Initializes the resource path
     *
     * @status New
     */
    private ResourceBundle initializeResources ( String strResourceFilePath )
    {
        ResourceBundle resources = null;
        
        try
        {
            resources = ResourceBundle.getBundle ( strResourceFilePath );
        }
        catch ( MissingResourceException missingResource )
        {
            resources = null;
        }
        
        return resources;
    }
    
    /**
     * Adds an entry into the key list.
     *
     * @status New
     */
    private boolean loadKeyAttributes ( String key, 
                                        String strKeyAttributes,
                                        Hashtable keyList )
    {
        Hashtable keyAttributes = null;
        
        if ( null == key || 0 == key.length ( ) ||
             null == strKeyAttributes || 0 == strKeyAttributes.length ( ) )
        {             
             return false;
        }
        
        keyAttributes = parseKeyAttributes ( strKeyAttributes );
        if ( null == keyAttributes ) 
            return false;
        
        keyList.put ( key, keyAttributes ); 
        
        return true;
    }

    /**
     * Loads the key and their attribute sets from the resource bundle.
     *
     * @status New
     */
    private boolean loadKeyAttributeSet ( ResourceBundle resources, 
                                          Hashtable keyList )
    {
        boolean     bRetVal = false;
        Enumeration keys    = null;
        String      key     = null, strKeyAttributes = null;
        
        if ( null == resources || null == keyList ) 
            return false;

        keys = resources.getKeys ( );
        if ( null == keys ) 
            return false;
        
        while ( keys.hasMoreElements ( ) )
        {
            key = ( String ) keys.nextElement ( );
            strKeyAttributes = resources.getString ( key );
            
            bRetVal = loadKeyAttributes ( key, strKeyAttributes, keyList );
            if ( ! bRetVal ) 
                break;
        }
        
        return bRetVal;
    }

    /**
     * Parse the key value pair and add it to the attribute set
     * of the key
     *
     * @status New
     */
    private boolean parseAttribute ( Hashtable keyAttributes, 
                                     String strKey, String strValue )
    {
        boolean bRetVal = false;
        
        if ( null == keyAttributes || 
             null == strKey || 0 == strKey.length ( ) ||
             null == strValue || 0 == strValue.length ( ) )
        {
            return false;
        }

        try 
        {   
            keyAttributes.put ( new String ( strKey ), new String ( strValue ) );
            bRetVal = true;
        }
        catch ( Exception exception )
        {
            bRetVal = false;
        }            
        
        return bRetVal;
    }
    
    /**
     * Parses the key attributes into a Hashtable.
     *
     * @status New
     */
    private Hashtable parseKeyAttributes ( String strKeyAttributes )
    {
        boolean     bRetVal         = false;
        Hashtable   keyAttributes   = null;
        int         nAttribDelim    = -1, nValueDelim = -1;
        String      strAttribs      = null, strAttribute = null;
        String      strAttribKey    = null, strAttribValue = null;

        String      strPairSeparator  = KEYATTRIBUTESET_PAIRSEPARATOR;
        String      strPairDelimiter   = KEYATTRIBUTESET_PAIRDELIMITER;
        
        
        if ( null == strKeyAttributes || 0 == strKeyAttributes.length ( ) ) 
            return null;
            
        strAttribute = new String ( );            
        strAttribKey = new String ( );
        strAttribValue = new String ( );
        
        keyAttributes = new Hashtable ( );
        strAttribs = new String ( strKeyAttributes );            
        
        while ( true )
        {
            if ( 0 == strAttribs.length ( ) ) break;
            
            nAttribDelim = strAttribs.indexOf ( strPairSeparator );
            if ( nAttribDelim < 0 )
            {
                // If no attribute delimiter found, assume that the 
                // rest of the string is one attribute.
                strAttribute = strAttribs;
                
                // No more parsing required.
                strAttribs = "";
            }
            else 
            {
                // Extract the attribute from the string.
                strAttribute = strAttribs.substring ( 0, nAttribDelim );
                if ( strAttribs.length ( ) <= nAttribDelim + 1 )
                {
                    // No more parsing required.
                    strAttribs = "";
                }                    
                else                    
                {
                    strAttribs = strAttribs.substring ( nAttribDelim + 1 );
                }                    
            }
            
            // Not a valid key value pair. Not the end of the world
            // though. Continue.
            if ( 0 == strAttribute.length ( ) ) 
                continue;
            
            // Attempt to break the attribute into key value pair
            nValueDelim = strAttribute.indexOf ( strPairDelimiter );
            if ( nValueDelim < 0 )
            {
                continue;
            }
            
            strAttribKey = strAttribute.substring ( 0, nValueDelim );
            strAttribValue = strAttribute.substring ( nValueDelim + 1 );
            
            bRetVal = fireKeyAttributeAvailableEvent ( keyAttributes, 
                                                       strAttribKey, strAttribValue );
            if ( bRetVal )
                continue;
            
            bRetVal = parseAttribute ( keyAttributes, strAttribKey, strAttribValue );
        }
        
        return keyAttributes;
    }

    /**
     * Performs the appropriate action for the attribute set.
     * 
     * @param strName    The name of the key to set the attributes for.
     *
     * @return           <code>true</code> if the operation was successful.
     *                   <code>false</code> if the operation failed.
     *
     * @status New
     */
    private boolean performAction ( Hashtable attribTarget, 
                                    Object name, Object value, int actionType )
    {                            
        if ( null == attribTarget || 
             null == name || null == value || actionType < 0 )
            return false;
            
        if ( KEYATTRIBUTESET_ATTRIBADD == actionType )
        {
            attribTarget.put ( name , value );
            
            return true;
        }
        else if ( KEYATTRIBUTESET_ATTRIBREMOVE == actionType )
        {
            attribTarget.remove ( name );
            
            return true;
        }            
        else if ( KEYATTRIBUTESET_ATTRIBSET == actionType )
        {
            attribTarget.remove ( name );
            attribTarget.put ( name, value );                
            
            return true;
        }
        return false;
    }

    /**
     * Performs the appropriate action for the attribute set.
     * 
     * @param strName    The name of the key to set the attributes for.
     *
     * @return           <code>true</code> if the operation was successful.
     *                   <code>false</code> if the operation failed.
     *
     * @status New
     */
    private boolean performAction ( Hashtable attribTarget, 
                                    Hashtable attribAction, int actionType )
    {   
        Enumeration names   = null;
        Object      name    = null;
        
        if ( null == attribTarget || null == attribAction || actionType < 0 )
            return false;
            
        names = attribAction.keys ( );
        while ( names.hasMoreElements( ) ) 
        {
            name = names.nextElement ( );
            if ( KEYATTRIBUTESET_ATTRIBADD == actionType )
            {
                attribTarget.put ( name, attribAction.get ( name ) );
                
                return true;
            }
            else if ( KEYATTRIBUTESET_ATTRIBREMOVE == actionType )
            {
                attribTarget.remove ( name );
                
                return true;
            }            
            else if ( KEYATTRIBUTESET_ATTRIBSET == actionType )
            {
                attribTarget.remove ( name );
                attribTarget.put ( name, attribAction.get ( name ) );
                
                return true;
            }
        }
        
        return false;
    }
    
}