/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * The main listener for <code>Query</code> object events.
 *
 * @status Documented
 */
public interface QueryListener extends java.util.EventListener
{
    /**
     * Responds when data, metadata, or both data and metadata are available or
     * revoked.
     * This event cannot be consumed.
     *
     * @param e DataAvailableEvent
     *
     * @status Documented
     */
    public void dataAvailable(DataAvailableEvent e);
    
    /**
     * Responds when data, metadata, or both data and metadata have changed.
     * This event cannot be consumed.
     * 
     * @param e DataChangedEvent
     *
     * @status Documented
     */
    public void dataChanged(DataChangedEvent e);
    
    /**
     * Responds when an operation will change data if it succeeds.
     * This event cannot be consumed.
     *
     * @param e DataChangingEvent
     *
     * @status Documented
     */
    public void dataChanging(DataChangingEvent e);
    
    /**
     * Responds when the dimensionality of a <code>Query</code> object changes.
     * This event cannot be consumed.
     *
     * @param e DimensionalityChangedEvent
     *
     * @status Documented
     */
    public void dimensionalityChanged(DimensionalityChangedEvent e);
    
    /**
     * Responds when a drill has been executed.
     * This event is fired after the drill operation executes.
     * This event cannot be consumed.
     *
     * @param e DrillRequestedEvent
     *
     * @status needs change
     */
    public void drillRequested(DrillRequestedEvent e);
    
    /**
     * Responds when a drill has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     *
     * @param e DrillRequestingEvent
     *
     * @status Documented
     */
    public void drillRequesting(DrillRequestingEvent e);
    
    /**
     * Responds when a layout change has been executed.
     * This event is fired after the layout change executes.
     * This event cannot be consumed.
     *
     * @param e LayoutChangedEvent
     *
     * @status needs change
     */
    public void layoutChanged(LayoutChangedEvent e);
    
    /**
     * Responds when a layout change has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     *
     * @param e LayoutChangingEvent
     *
     * @status Documented
     */
    public void layoutChanging(LayoutChangingEvent e);
    
    /**
     * Responds when one or more of the edges of a <code>Query</code> object
     * evaluate to null.
     *
     * @param e NullStatusEvent
     *
     * @status Documented
     */
    public void nullStatus(NullStatusEvent e);
    
    /**
     * Responds when a selection has been changed.
     * This event is fired after the actual selection and query are changed.
     * This event cannot be consumed.
     *
     * @param e SelectionChangedEvent
     *
     * @status needs change
     */
    public void selectionChanged(SelectionChangedEvent e);
    
    /**
     * Responds when a selection has been requested to change.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e SelectionChangingEvent
     *
     * @status Documented
     */
    public void selectionChanging(SelectionChangingEvent e);
    
    /**
     * Responds when the state of the <code>Query</code> object has been
     * asked to change through the use of the undo mechanism.
     *
     *
     * @param e StateChangingEvent
     *
     * @status Documented
     */
    public void stateChanging(StateChangingEvent e);
    
    /**
     * Responds when the state of the <code>Query</code> object has been changed
     * through the use of the undo mechanism.
     *
     * @param e StateChangedEvent
     *
     * @status Documented
     */
    public void stateChanged(StateChangedEvent e);
    
    /**
     * Responds when a new undoable edit is available for a <code>Query</code>
     * object.
     *
     * @param e UndoAvailableEvent
     *
     * @status Documented
     */
    public void undoAvailable(UndoAvailableEvent e);
    
    /**
     * Responds when the data in a cell is about to be overwritten.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e CellOverridingEvent
     *
     * @status Documented
     */
    public void cellOverriding( CellOverridingEvent e);
    
    /**
     * Responds when the data in a cell has been overwritten.
     *
     * @param e CellOverriddenEvent
     *
     * @status Documented
     */
    public void cellOverridden( CellOverriddenEvent e);
    
    /**
     * Responds when changes to the data in cells are about to be submitted for
     * update in the database.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e CellsSubmittingEvent
     *
     * @status Documented
     */
    public void cellsSubmitting( CellsSubmittingEvent e);
    
    /**
     * Responds when changes to the data in cells have been submitted for
     * update in the database.
     *
     * @param e CellsSubmittedEvent
     *
     * @status Documented
     */
    public void cellsSubmitted( CellsSubmittedEvent e );

    /**
     * Responds when a total has been changed.
     * This event is fired after the actual total and query are changed.
     * This event cannot be consumed.
     *
     * @param e TotalChangedEvent
     *
     * @status new
     */
     // blm - Selection code moved to dvt-olap
/*    public void totalChanged(TotalChangedEvent e);*/
    
    /**
     * Responds when a total has been requested to change or is changing
     * due to a layout change.
     * A listener can veto this event by calling its <code>consume</code>
     * method.  A listener can alter the TotalSteps sent to the Query
     * by changing the TotalSteps in the event object.
     *
     * @param e TotalChangingEvent
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*public void totalChanging(TotalChangingEvent e);*/
}
