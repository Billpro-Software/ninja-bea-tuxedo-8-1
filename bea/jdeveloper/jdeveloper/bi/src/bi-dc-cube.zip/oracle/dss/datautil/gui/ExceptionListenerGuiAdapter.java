/*
 * ExceptionListenerGuiAdapter.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;

import java.util.Locale;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.ExceptionListenerAdapter;
import oracle.dss.datautil.gui.ExceptionListenerDialog;
import oracle.dss.datautil.gui.ExceptionListenerDialogAdapter;
import oracle.dss.datautil.gui.ExceptionListenerGui;

import oracle.dss.util.ErrorHandler;
import oracle.dss.util.Localizable;
import oracle.dss.util.gui.BIExceptionDialog;
import oracle.dss.util.gui.BIJOptionPane;

/**
 * @hidden
 *
 * Default exception listener GUI adapter.
 *
 * This is the default implementation of the <code>ExceptionListener</code>
 * interface.
 *
 * This implementation displays the <code>BIExceptionDialog</code>.
 *
 * @status hidden
 */
public class ExceptionListenerGuiAdapter extends ExceptionListenerAdapter implements ExceptionListenerGui {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Start of OPTION literals

  /**
   * Show exception with a dialog.
   *
   * @status hidden
   */
  public static final int OPTION_DIALOG = 0x10;

  // End of OPTION literals

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * An <code>ExceptionListenerDialog</code> which represents the dialog used to
   * display exception messages.
   *
   * @status private
   */
  private transient ExceptionListenerDialog m_exceptionListenerDialog =
    new ExceptionListenerDialogAdapter();

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  //-----------------------------------------------------------------------
  // Begin - Implementation of the ExceptionListenerDialogCallback
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Adds a single exception listener dialog to the bean.
   *
   * The bean then calls the exception listener with error or alert messages.
   *
   * @param exceptionListenerDialog A <code>ExceptionListenerDialog</code> to add.
   *
   * @status hidden
   */
  public void addExceptionListenerDialog (ExceptionListenerDialog exceptionListenerDialog) {
    m_exceptionListenerDialog = exceptionListenerDialog;
  }

  /**
   * @hidden
   * Retrieves the <code>ExceptionListenerDialog</code> used to display error or alert
   * messages.
   *
   * @return <code>AlertHandlerDialogn</code> which is the dialog used to display
   *         alerts.
   */
  public ExceptionListenerDialog getExceptionListenerDialog () {
    return m_exceptionListenerDialog;
  }

  /**
   * @hidden
   * Removes the exception listener dialog from the bean.
   *
   * @status hidden
   */
  public void removeExceptionListenerDialog() {
    m_exceptionListenerDialog = null;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the ExceptionListenerDialogCallback
  //-----------------------------------------------------------------------

  //-----------------------------------------------------------------------
  // Begin - Override of the DefaultAlertHandler
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Specifies the options for the exception listener.
   *
   * This method allows user specify multiple options through bitwise literals.
   *
   * @param nOption A <code>int</code> which contains the options associated
   *                with this <code>ExceptionListener</code>.
   *
   * @return <code>int</code> value which represents the current options.
   *
   * @see oracle.dss.datautil.ExceptionListener#OPTION_NONE
   * @see oracle.dss.datautil.ExceptionListener#OPTION_EXCEPTION
   * @see oracle.dss.datautil.ExceptionListener#OPTION_EVENT
   * @see oracle.dss.datautil.ExceptionListener#OPTION_ALL
   * @see #OPTION_DIALOG
   *
   * @status hidden
   */
  public int setOptions (int nOptions) {
    super.setOptions (nOptions);

    if ((nOptions & OPTION_DIALOG) > 0) {
      m_nOptions = nOptions;
    }

    return m_nOptions;
  }

  /**
   * @hidden
   * Responds to trapped exception alerts.
   *
   * <code>ExceptionListenerCallback</code> implementations call this method when
   * an alert is required in response to an exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return <code>int</code> value which represents a positive response
   *         when zero and a negative response when non-zero.
   *
   * @see ExceptionListenerGui#OK_OPTION
   * @see ExceptionListenerGui#YES_OPTION
   * @see ExceptionListenerGui#NO_OPTION
   * @see ExceptionListenerGui#CANCEL_OPTION
   * @see ExceptionListenerGui#NONE_OPTION
   * @see ExceptionListenerGui#CLOSED_OPTION
   *
   * @status hidden
   */
  public int processException (Throwable throwable, String strClass, String strRoutine) {

    // Dialog has not been displayed
    int nResult = ExceptionListenerGui.NONE_OPTION;

    // Check for non-null exception
    if ((throwable != null) && ((getOptions() & OPTION_DIALOG) > 0)) {
      ExceptionListenerDialog exceptionListenerDialog = getExceptionListenerDialog();
      if (exceptionListenerDialog != null) {
        nResult = exceptionListenerDialog.processException (throwable, strClass, strRoutine);
      }
    }

    return nResult;
  }

  //-----------------------------------------------------------------------
  // End - Override of the DefaultErrorHandler
  //-----------------------------------------------------------------------

	//-------------------------------------------------------------------
	// Start implementation of ErrorHandlerCallback interface
	//-------------------------------------------------------------------

  /**
   * Adds an <code>ErrorHandler</code> object to this
   * <code>DefaultBuilderContext</code> object.
   *
   * The <code>ErrorHandler</code> object will be
   * called when the visual component traps an error from other parts
   * of the system.
   *
   * @param errorHandler The <code>ErrorHandler</code> object.
   *
   * @status New
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    super.addErrorHandler (errorHandler);

    // Pass the ErrorHandler to the ExceptionListenerDialog
    if (getExceptionListenerDialog() != null) {
      getExceptionListenerDialog().addErrorHandler (errorHandler);    
    }
  }

  /**
   * Overrides a previously set <code>ErrorHandler</code> object in this
   * <code>DefaultBuilderContext</code> object with a default one.
   *
   * @status New
   */
  public void removeErrorHandler() {
    super.removeErrorHandler();

    // Pass the ErrorHandler to the ExceptionListenerDialog
    if (getExceptionListenerDialog() != null) {
      getExceptionListenerDialog().removeErrorHandler ();    
    }
  }
}

