/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import java.util.Vector;
import java.util.Map;
import java.util.HashMap;

public class MDItem extends MDObject
{
    protected Map<String, Boolean> m_deferredCheck = new HashMap<String, Boolean>();
    
    public MDItem()
    {
        setObjectType(MM.ITEM);
    }
        
    public String getDefaultPlacement()
    {
        return getStrPropertyValue(MM.DEFAULT_PLACEMENT);
    }

    public String getDatatype()
    {
        return getStrPropertyValue(MM.DATA_TYPE);
    }

    public String getDefualtAggregateFunction()
    {
        return getStrPropertyValue(MM.DEFAULT_AGG_FUNCTION);
    }

    public String[] getAggregateFunctions()
    {
        return (String[])getObjPropertyValue(MM.AGG_FUNCTION);
    }
    
    public String getAlignment()
    {
        return getStrPropertyValue(MM.ALIGNMENT);
    }
    
    public String getFormatMask()
    {
        return getStrPropertyValue(MM.FORMAT_MASK);
    }
    
    private Map<String, Boolean> getDeferredCheck()
    {
       if (m_deferredCheck == null)
       {
            m_deferredCheck = new HashMap<String, Boolean>();
       }
       return m_deferredCheck;
    }

    /**
     * Get the items that can be drilled down from this item.
     * @return Vector contains MDItems
     */
    public Vector getDrillDownPaths() {
        Vector retVal = (Vector)getObjPropertyValue(MM.DRILL_DOWN_PATHS);
        Object obj = getDeferredCheck().get(MM.DRILL_DOWN_PATHS);
        Boolean b = obj == null ? null : (Boolean)obj;
        if (retVal == null && (b == null || !b.booleanValue()))
        {
            getMetadataManagerServices().deferredObjectSetUp(this);
            retVal = (Vector)getObjPropertyValue(MM.DRILL_DOWN_PATHS);
            getDeferredCheck().put(MM.DRILL_DOWN_PATHS, Boolean.valueOf(true));
        }
        return retVal;
    }

    /**
     * Get the items that can be drilled up from this item.
     * @return Vector contains MDItems
     */
    public Vector getDrillUpPaths() {
        Vector retVal = (Vector)getObjPropertyValue(MM.DRILL_UP_PATHS);
        Object obj = getDeferredCheck().get(MM.DRILL_UP_PATHS);
        Boolean b = obj == null ? null : (Boolean)obj;
        if (retVal == null && (b == null || !b.booleanValue()))
        {
            getMetadataManagerServices().deferredObjectSetUp(this);
            retVal = (Vector)getObjPropertyValue(MM.DRILL_UP_PATHS);
            getDeferredCheck().put(MM.DRILL_UP_PATHS, Boolean.valueOf(true));
        }
        return retVal;
    }
}
