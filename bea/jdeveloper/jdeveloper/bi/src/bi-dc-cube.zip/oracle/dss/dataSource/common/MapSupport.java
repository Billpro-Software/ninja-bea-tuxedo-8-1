package oracle.dss.dataSource.common;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
 
import java.util.Hashtable;
import java.util.Enumeration;

import oracle.dss.util.AbstractMap;
import oracle.dss.util.DataMap;
import oracle.dss.util.MetadataMap;

import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.PropertyNode;
import oracle.dss.util.xml.NoSuchPropertyException;

/**
 * @hidden
 * Class designed to support both tiers equally.
 */
public class MapSupport extends Object implements java.io.Serializable, Cloneable, XMLizable
{
    protected boolean m_allowAnnotations = false;
    
    public MapSupport(boolean allowAnnotations)
    {
        super();
        m_allowAnnotations = allowAnnotations;
        // Default to annotations on if switch is set
        if (allowAnnotations)
        {
            // Add in annotation data map
            _dataMap.addType(DataMap.DATA_ANNOTATION);
        }
    }

    /**
     * Compare the content equality of two maps: if they have an equal number of elements, and
     * one is a superset of the other, then they should be equal.
     */
    protected boolean compareMaps(AbstractMap map1, AbstractMap map2)
    {
        if ((map1.size() == map2.size()) && map1.isSuperset(map2))
        {
            return true;            
        }
        return false;
    }
    
    /**
     * Return a DataMap containing only the supported items given in map
     */
    protected DataMap getSupportedItems(DataMap map)
    {
        DataMap newMap = new DataMap();
        Enumeration types = map.types();
        String type = null;
        while (types.hasMoreElements())
        {
            type = (String)types.nextElement();
            if (getSupportedDataMap().containsType(type) > -1)
            {
                newMap.addType(type);
            }
        }
        
        if (newMap.size() == 0)
        {
            // Return the supported map
            return getSupportedDataMap();
        }
        return newMap;
    }
    
    /**
     * Return a MetadataMap containing only the supported items given in map
     */
    protected MetadataMap getSupportedItems(MetadataMap map)
    {
        MetadataMap newMap = new MetadataMap();
        Enumeration types = map.types();
        String type = null;
        while (types.hasMoreElements())
        {
            type = (String)types.nextElement();
            if (getSupportedMetadataMap().containsType(type) > -1)
            {
                newMap.addType(type);
            }
        }
        
        if (newMap.size() == 0)
        {
            // Return the supported map
            return getSupportedMetadataMap();
        }
        return newMap;
    }

    /**
     * Get the supported MetadataMap for the Query
     */
    public MetadataMap getSupportedMetadataMap()
    {
        return _supportedMetadataMap;
    }

    /**
     * Set the supported DataMap for the Query
     */
    public void setSupportedDataMap(DataMap map)
    {
        defaultChanged = true;
        _supportedDataMap = (DataMap)map.clone();
    }

    /**
     * Get the supported DataMap for the Query
     */
    public DataMap getSupportedDataMap()
    {
        // Need to mix in a check for whether annotations are enabled at all
        DataMap supportedMap = (DataMap)_supportedDataMap.clone();
        // Ask whether annotations are allowed at all
        if (m_allowAnnotations)
        {
            // Add in annotation data map
            supportedMap.addType(DataMap.DATA_ANNOTATION);
        }
        return supportedMap;
    }
    
    /**
     * Request that the specified data layers be added to the underlying query
     * These data layers will be included in subsequent cursors.
     *
     * @param map the DataMap containing desired layers
     * @return <code>true</code> if change accepted
     */
    public boolean applyDataMap(DataMap map) {
        if (map != null)
        {
            // Make sure we're only dealing with fully supported types           
            DataMap newMap = getSupportedItems(map);
//            DataMap newMap = map;
            // If there's a current datamap
            if (_dataMap != null)
            {
                // Don't apply any change if we've already got all these types
                if (_dataMap.isSuperset(newMap))
                {
                    return false;
                }
                // Otherwise, merge in the new items
                _dataMap.merge(newMap);
            }
            else
            {
                // Need to fully replace the datamap
                _dataMap = newMap;
            }
            // If we fall through here, we made a change of some kind...
            return true;
        }
            
        // Bad argument            
        return false;
    }
    
    /**
     * Request that the specified metadatadata layers be added to the underlying query
     * These metadata layers will be included in subsequent cursors.
     *
     * @param dimension dimension whose map needs merging
     * @param map the MetadataMap containing desired layers
     * @return <code>true</code> if change accepted
     */
    public boolean applyMetadataMap(String dimension, boolean isTime, MetadataMap map) {
        // Lookup map
        MetadataMap tempMap = null;
        // Make sure the map being applied is a clone with only the supported items in it
        MetadataMap newMap = getSupportedItems(map);
        // If they told us what dimension this goes to:
        if (dimension != null)
        {
            // Get the current map for the dimension, if any
            tempMap = (MetadataMap)_metadataMaps.get(dimension);
        }
        if (tempMap != null)
        {
            // Merge in the supported changes if there is a current map
            tempMap.merge(newMap);
        }
        else
        {
            // if no current map, start with the default and merge in the changes
            tempMap = (MetadataMap)_defaultMetadataMap.clone();
            if (isTime)
            {
                tempMap = constructTimeMetadataMap(tempMap);
            }
            
            tempMap.merge(newMap);
        }
        // Store the end result by dimension
        return storeMap(dimension, tempMap);
    }

    /**
     * Request that the specified metadatadata layers be added to the underlying query
     * These metadata layers will be included in subsequent cursors.
     *
     * @param edge edge whose map needs merging
     * @param map the MetadataMap containing desired layers
     * @return <code>true</code> if change accepted
     */
    public boolean applyMetadataMap(int edge, MetadataMap map) {
        // Lookup map
        MetadataMap tempMap = null;
        // Make sure the given map is a copy with only supported items
        MetadataMap newMap = getSupportedItems(map);
        // Look up any current edge map
        tempMap = (MetadataMap)_edgeMaps.get(getEdgeKey(edge));
        if (tempMap == null)
        {
            // If no current edge map, start with the default, merge in the changes, and store it by edge
            tempMap = (MetadataMap)_defaultMetadataMap.clone();
            tempMap.merge(newMap);
            return storeEdgeMap(edge, tempMap);
        }
        if (tempMap != null)
        {
            // If there is a current map, make sure there's a reason to change it
            if (tempMap.isSuperset(newMap))
            {
                return false;
            }
            // Merge it in, which automatically updates the hash table
            tempMap.merge(newMap);
        }
        // We made a change of one kind or another
        return true;
    }

    /**
     * Request that the specified data layers be fetched for all clients
     * and all subsequent cursors.
     *
     * @param map the DataMap containing desired layers
     * @return <code>true</code> if change accepted
     *
     */
    public boolean setDataMap(DataMap map) {
        if (map == null)
        {
            // Bad argument
            return false;
        }
        DataMap newMap = getSupportedItems(map);
/**        if (_dataMap.isSuperset(newMap))
        {
            // No reason to affect a change
            return false;
        }*/
        // Substitute the new map
        _dataMap = newMap;
        defaultChanged = true;
        return true;
    }
    
    /**
     * Request that the specified metadatadata layers be fetched for all clients
     * and all subsequent cursors.
     *
     * @param dimension for which the map should be set.  If null,
     * map will be set as the default
     * @param map the MetadataMap containing desired layers
     * @return <code>true</code> if change accepted
     *
     */
    public boolean setMetadataMap(String dimension, MetadataMap map) {
        // Make sure we only have fully supported types
        MetadataMap newMap = getSupportedItems(map);
        if (dimension == null)
        {
            checkForRequiredTypes(newMap);
            // Save the new map, removing date types
            _defaultMetadataMap = removeDateTypes(newMap);
            return true;
        }

        // Delete the old per the given dimension
        _metadataMaps.remove(dimension);
        // Store the new
        defaultChanged = true;
        return storeMap(dimension, newMap);
    }    

    private MetadataMap removeDateTypes(MetadataMap map)
    {
        Enumeration types = _extraTimeTypes.elements();
        while (types.hasMoreElements())
        {
            map.removeType((String)types.nextElement());
        }
        return map;
    }

    /**
     * Set map for an edge
     *
     * @param edge edge to set
     * @param map map to set on edge
     * @return <code>true</code> if change accepted
     */     
    public boolean setMetadataMap(int edge, MetadataMap map)
    {
        // Deal only with supported types
        MetadataMap newMap = getSupportedItems(map);
        // Store the map
        defaultChanged = true;
        return storeEdgeMap(edge, newMap);
    }
    
    /**
     * Get the map representing all data layers requested by all current clients
     * of this Query.
     *
     * @return the DataMap containing all layers
     *
     */
    public DataMap getDataMap()
    {
        return _dataMap == null ? null : (DataMap)_dataMap.clone();
    }
    
    /**
     * Get the map representing all metadata layers requested by all current clients
     * of this Query for a given dimension.
     *
     * @param dimension dimension for which map should be returned
     * @return the MetadataMap containing all layers; returns default map
     * if dimension is null
     *
     */
    public MetadataMap getMetadataMap(String dimension, boolean isTime)
    {
        if (dimension == null)
        {
            MetadataMap tempMap = _defaultMetadataMap == null ? null : (MetadataMap)_defaultMetadataMap.clone();
            if (tempMap != null && isTime)
            {
                tempMap = constructTimeMetadataMap(tempMap);
            }
            return tempMap;
        }

        MetadataMap map = (MetadataMap)_metadataMaps.get(dimension);        
        return (map == null) ? null : (MetadataMap)map.clone();
    }
        
    /**
     * Return map for an entire edge
     *
     * @param edge edge to return
     * @return map at edge, null if not found
     */
    public MetadataMap getMetadataMap(int edge)
    {
        MetadataMap map = (MetadataMap)_edgeMaps.get(getEdgeKey(edge));
        return map == null ? null : (MetadataMap)map.clone();
    }

    /**
     * @hidden
     */
    public String getTagName()
    {
        return XMLName;
    }

    public Object getXML(XMLContext retCons) {
        ObjectNode root = new ObjectNode(XMLName);
        root.addContainer(getXMLFromMap("DataMap", _dataMap));
        root.addContainer(getXMLFromMap("DefaultMetadataMap", _defaultMetadataMap));
        
        ContainerNode edgeMaps = new ContainerNode("EdgeMaps");
        Enumeration edges = _edgeMaps.elements();
        Enumeration keys = _edgeMaps.keys();
        while (edges.hasMoreElements()) {
            ObjectNode obj = new ObjectNode("EdgeMap");
            obj.addProperty("Key", ((Integer)keys.nextElement()).intValue());
            obj.addContainer(getXMLFromMap("MetadataMap", (AbstractMap)edges.nextElement()));
            edgeMaps.addContainedObject(obj);
        }
        root.addContainer(edgeMaps);
        
        ContainerNode metadataMaps = new ContainerNode("MetadataMaps");
        Enumeration mapkeys = _metadataMaps.keys();
        while (mapkeys.hasMoreElements()) {
            ObjectNode obj = new ObjectNode("Map");
            Object key = mapkeys.nextElement();
            if (key instanceof Integer) {
                obj.addProperty("KeyType", "I");
                obj.addProperty("Key", ((Integer)key).intValue());
            }
            else {
                obj.addProperty("KeyType", "S");
                
            }
            
            obj.addContainer(getXMLFromMap("MetadataMap", (AbstractMap)_metadataMaps.get(key)));
            metadataMaps.addContainedObject(obj);
        }
        root.addContainer(metadataMaps);
        return root;
    }
     
    /**
    * @hidden
    */
    public void setXML(XMLContext context, Object node) {
        try {
            ObjectNode root = (ObjectNode)node;
            DataMap tempDataMap = (DataMap)MapSupport.getMapFromXML(root.getContainer(PersistableConstants.XMLNS + ":DataMap"), DataMap.class);
            // Use the same standards as a straight API apply call to make sure we don't shrink our supported map due
            // to XML loads to prevent extra OLAPI calls when views hook up
            applyDataMap(tempDataMap);
            MetadataMap tempMetadataMap = (MetadataMap)MapSupport.getMapFromXML(root.getContainer(PersistableConstants.XMLNS + ":DefaultMetadataMap"), MetadataMap.class);
            // If there is a current map, make sure there's a reason to change it
            if (tempMetadataMap.isSuperset(_defaultMetadataMap))
            {
                _defaultMetadataMap = tempMetadataMap;
            }
            ContainerNode maps = root.getContainer(PersistableConstants.XMLNS + ":EdgeMaps");
            Enumeration map = maps.getContainedObject();
            _edgeMaps = new Hashtable();
            ObjectNode singleMap = null;
            while (map.hasMoreElements()) {
                singleMap = (ObjectNode)map.nextElement();
                int key = singleMap.getPropertyValueAsInteger(PersistableConstants.XMLNS + ":Key");
                storeEdgeMap(key, (MetadataMap)getMapFromXML(singleMap.getContainer(PersistableConstants.XMLNS + ":MetadataMap"), MetadataMap.class));
            }
            _metadataMaps = new Hashtable();
            maps = root.getContainer(PersistableConstants.XMLNS + ":MetadataMaps");
            map = maps.getContainedObject();
            while (map.hasMoreElements()) {
                singleMap = (ObjectNode)map.nextElement();
                String keyType = singleMap.getPropertyValueAsString("KeyType");            
                Object Key = null;
                if (keyType.equals("I")) {
                    int key = singleMap.getPropertyValueAsInteger("Key");
                    Key = new Integer(key);
                }
                else {
                    String key = singleMap.getPropertyValueAsString("Key");
                    if (key != null && key.equals(""))
                    {
                        key = null;
                    }
                    Key = key;
                }
                storeMap(Key, (MetadataMap)getMapFromXML(singleMap.getContainer(PersistableConstants.XMLNS + ":Map"), MetadataMap.class));
            }
        }
        catch (NoSuchPropertyException e) {
            throw new oracle.dss.dataSource.common.NoSuchPropertyException("Could not find property", e.getMessage(), e);
        }
    }

    /**
     * Copy this map support object
     *
     * @return copy of this map support
     */
    public Object clone() {
        MapSupport newMs = new MapSupport(m_allowAnnotations);
        
        // Copy the edge maps
        Enumeration keyList = _edgeMaps.keys();
        Enumeration objectList = _edgeMaps.elements();
        while (keyList.hasMoreElements()) {
            newMs._edgeMaps.put(keyList.nextElement(), ((AbstractMap)objectList.nextElement()).clone());
        }
        // Copy the metadata maps
        keyList = _metadataMaps.keys();
        objectList = _metadataMaps.elements();
        while (keyList.hasMoreElements()) {
            newMs._metadataMaps.put(keyList.nextElement(), ((AbstractMap)objectList.nextElement()).clone());
        }
        // Copy the data map
        newMs._dataMap = (DataMap)_dataMap.clone();
        // Copy the supported data map
        newMs._supportedDataMap = (DataMap)_supportedDataMap.clone();
        // Copy the default map
        newMs._defaultMetadataMap = (MetadataMap)_defaultMetadataMap.clone();
        return newMs;
    }
    
    // Store a metadata map in the map table: return false if the change was unnecessary
    protected boolean storeMap(Object key, MetadataMap map)
    {
        checkForRequiredTypes(map);
        if (key == null)
        {
            // Must be the default map
            if (_defaultMetadataMap.isSuperset(map))
            {
                return false;
            }
            defaultChanged = true;
            _defaultMetadataMap = removeDateTypes(map);
            return true;
        }
        MetadataMap oldMap = (MetadataMap)_metadataMaps.get(key);
        if (oldMap == null)
        {
            // Only store it if it's not equal to the default map
            if (compareMaps(_defaultMetadataMap, map))
            {
                return false;
            }
            defaultChanged = true;
            _metadataMaps.put(key, map);
            return true;
        }
        if (!oldMap.isSuperset(map))
        {
            _metadataMaps.put(key, map);        
            defaultChanged = true;
            return true;
        }
        return false;
    }
    
    protected boolean storeEdgeMap(int edge, MetadataMap map)
    {
        checkForRequiredTypes(map);
        Object key = getEdgeKey(edge);
        MetadataMap oldMap = (MetadataMap)_edgeMaps.get(key);
        if (oldMap == null)
        {
            // Only store if the new map isn't equal to the default
            if (compareMaps(_defaultMetadataMap, map))
            {
                return false;
            }
            defaultChanged = true;
            _edgeMaps.put(key, map);
            return true;
        }
        if (!oldMap.isSuperset(map))
        {
            defaultChanged = true;
            _edgeMaps.put(key, map);
            return true;
        }
        return false;
    }

    // Make sure METADATA_VALUE are always present and first
    // in the list
    private void checkForRequiredTypes(MetadataMap map)
    {
        for (int i = _requiredTypes.length-1; i >= 0; i--)
        {
            int loc = map.indexOf(_requiredTypes[i]);
            if (loc > -1)
            {
                // Found, remove it
                map.removeElementAt(loc);
            }
            // Make sure it's there and at beginning
            map.insertElementAt(_requiredTypes[i], 0);
        }
    }

    // Support for converting maps to/from XML
    public static AbstractMap getMapFromXML(ContainerNode root, Class mapType) {
        AbstractMap map = null;
        try {
            map = (AbstractMap)mapType.newInstance();
        }
        catch (Exception e) {
            return null;
        }
        //ContainerNode types = root.getContainer("Type");
        Enumeration type = root.getPropertyNodes();
        PropertyNode prop;
        while (type.hasMoreElements()) {
            prop = (PropertyNode)type.nextElement();
            map.addType(prop.getValueAsString());
        }

        return map;
    }
    
    public static ContainerNode getXMLFromMap(String name, AbstractMap map) {
        ContainerNode types = new ContainerNode(name);
        Enumeration type = map.types();
        while (type.hasMoreElements()) {
            types.addContainedObject(new PropertyNode("Type", (String)type.nextElement()));
        }        
        return types;
    }
    
    private Integer getEdgeKey(int edge) {
        return new Integer(edge);
    }

    private MetadataMap constructTimeMetadataMap(MetadataMap map)
    {
        map.merge(_extraTimeTypes);
        return map;
    }
    
    public String toString()
    {
        String message = "DataMap:\n";
        
        message += _dataMap.toString() + "\n";
        
        Enumeration dims = _metadataMaps.keys();
        while (dims.hasMoreElements())
        {            
            String dim = (String)dims.nextElement();
            MetadataMap map = (MetadataMap)_metadataMaps.get(dim);
            if (map != null)
                message += "\nMetadataMap: " + dim + "\n" + map.toString();
        }
        Enumeration keys = _edgeMaps.keys();
        while (keys.hasMoreElements())
        {            
            Object key = keys.nextElement();
            MetadataMap map = (MetadataMap)_edgeMaps.get(key);
            if (map != null)
                message += "\nEdge MetadataMap: " + key.toString() + "\n" + map.toString();
        }
        
        return message;
    }
    
    /**
     * @serial Data map
     */
    protected DataMap _dataMap = new DataMap(new String[] {DataMap.DATA_UNFORMATTED, DataMap.DATA_VIEWFORMAT, DataMap.DATA_NAME, DataMap.DATA_ISTOTAL, DataMap.DATA_TYPE});
    protected DataMap _supportedDataMap = _dataMap;
        
    /**
     * @serial Metadata maps
     */
    protected Hashtable _metadataMaps    = new Hashtable();

    /**
     * The _defaultMetadataMap should ALWAYS have MetadataMap.METADATA_VALUE 
     * listed since it is required for successful cursor evaluation.
     *
     * In addition, the order of this list should reflect the order in which
     * attribute metadata is requested in a given DimensionTemplate.
     *
     *  Example: 
     *  // Set up product attribute information    
     *  productDimension = new DimensionTemplate(productMultiStep);
     *  productDimension.addAttribute(getLongLabelSource(productMultiStep));
     *  productDimension.addAttribute(getShortLabelSource(productMultiStep));
     *  productDimension.addAttribute(getMediumLabelSource(productMultiStep));
     *  productDimension.addAttribute(getDrillInformation(productMultiStep));
     *  productDimension.addAttribute(getLevelDepthSource(productMultiStep));
     *
     *  In this case _defaultMetadataMap should have 
     *  MetadataMap.METADATA_LONGLABEL
     *  MetadataMap.METADATA_SHORTLABEL
     *  MetadataMap.METADATA_MEDIUMLABEL
     *  MetadataMap.METADATA_DRILLSTATE
     *  MetadataMap.METADATA_INDENT
     *  MetadataMap.METADATA_VALUE
     *
     *  @serial special default map
     */

    protected MetadataMap _defaultMetadataMap =
        new MetadataMap(new String[] {
                                      MetadataMap.METADATA_VALUE,
                                      MetadataMap.METADATA_DISPLAYNAME,
                                      MetadataMap.METADATA_LONGLABEL,
                                      MetadataMap.METADATA_MEDIUMLABEL,
                                      MetadataMap.METADATA_SHORTLABEL,
                                      MetadataMap.METADATA_DRILLSTATE,
                                      MetadataMap.METADATA_INDENT,
                                      MetadataMap.METADATA_REL_INDENT,
                                      MetadataMap.METADATA_PARENT,
                                      MetadataMap.METADATA_LEVEL,
                                      MetadataMap.METADATA_LEVEL_LABEL,
                                      MetadataMap.METADATA_LEVEL_NAME,
                                      MetadataMap.METADATA_DATATYPE,
                                      MetadataMap.METADATA_ISTOTAL,
                                      MetadataMap.METADATA_HIERARCHY,                                      
                                      MetadataMap.METADATA_PARENT_LEVEL,
                                      MetadataMap.METADATA_VALUE_RAW,
                                      MetadataMap.METADATA_VIEWSTYLE,
                                      });
    protected final MetadataMap _supportedMetadataMap =
        new MetadataMap(new String[] {
                                      MetadataMap.METADATA_VALUE,
                                      MetadataMap.METADATA_DISPLAYNAME,
                                      MetadataMap.METADATA_LONGLABEL,
                                      MetadataMap.METADATA_MEDIUMLABEL,
                                      MetadataMap.METADATA_SHORTLABEL,
                                      MetadataMap.METADATA_DRILLSTATE,
                                      MetadataMap.METADATA_INDENT,
                                      MetadataMap.METADATA_REL_INDENT,
                                      MetadataMap.METADATA_PARENT,
                                      MetadataMap.METADATA_LEVEL,
                                      MetadataMap.METADATA_LEVEL_LABEL,
                                      MetadataMap.METADATA_LEVEL_NAME,
                                      MetadataMap.METADATA_DATE,
                                      MetadataMap.METADATA_DATATYPE,
                                      MetadataMap.METADATA_ISTOTAL,
                                      MetadataMap.METADATA_HIERARCHY,
                                      MetadataMap.METADATA_PARENT_LEVEL,
                                      MetadataMap.METADATA_VALUE_RAW,
                                      MetadataMap.METADATA_VIEWSTYLE,
                                      MetadataMap.METADATA_DRILL_PARENT_LONGLABEL,
                                      });

    protected final MetadataMap _extraTimeTypes =
        new MetadataMap(new String[] {
                                      MetadataMap.METADATA_DATE,
                                      MetadataMap.METADATA_DATESPAN,
                                      });

    public boolean isDefaultChanged() {
        return defaultChanged;
    }

    /**
     * @serial Edge maps
     */
    protected Hashtable _edgeMaps        = new Hashtable();
        
    // XML name
    protected static final String XMLName = "Maps";
    
    private static String[] _requiredTypes = new String[] {MetadataMap.METADATA_VALUE};
    private boolean defaultChanged = false;
}
