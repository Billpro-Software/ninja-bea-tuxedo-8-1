/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * Defines methods for accessing <code>Selection</code> objects that
 * represent an ordered list of query steps for a particular dimension.
 *
 * @status Documented
 */
public interface SelectionManager extends BaseManager
{
    /**
     * Applies the specified <code>Selection</code> object to the corresponding
     * <code>Selection</code> object in this <code>Query</code>.
     *
     * @param selection The <code>Selection</code> to apply.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public void applySelection(Selection selection) throws QueryException, MetadataManagerException;*/

    /**
     * Applies the specified <code>Selection</code> objects to the
     * corresponding <code>Selection</code> objects in the Query.
     *
     * @param selections The <code>Selection</code> objects to apply.
     *
     * @throws QueryException           If there is a problem fetching data.
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public void applySelections(Selection[] selections) throws QueryException, MetadataManagerException;*/

    /**
     * Removes the specified <code>Selection</code> object from
     * this <code>Query</code>.
     *
     * @param selection The <code>Selection</code> object to remove.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public void removeSelection(Selection selection) throws QueryException, MetadataManagerException;*/


    /**
     * Retrieves a reference to the complete collection of
     * <code>Selection</code> objects for this <code>Query</code>.
     * Each <code>Selection</code> corresponds to an underlying dimension
     * (including the Measure dimension).
     * The <code>Query</code> is registered as a listener to  all the
     * <code>Selection</code> objects in the collection, such that changes to
     * any one of them are captured as <code>Query</code> operations.
     *
     * @return The list of <code>Selection</code> objects.
     *
     * @status Documented
     */
    //public java.util.List getAllSelections();

    /**
     * Retrieves a <code>Selection</code> object that corresponds to the
     * specified dimension.
     *
     * @param dimension The name of the dimension for which
     *                  the current <code>Selection</code> object should be
     *                  returned.
     *
     * @return The <code>Selection</code> object that corresponds to the
     *         specified dimension.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection findSelection(String dimension);        */

 
    /**
     * Retrieves a <code>Selection</code> object that corresponds to the
     * specified dimensions. The <code>Query</code> is registered as a
     * listener to this object so that changes to the underlying list of
     * <code>Step</code> objects are captured as <code>Query</code>
     * operations.
     *
     * @param dimension The dimensions for which to return the current
     *                  <code>Selection</code> object.
     *
     * @return The <code>Selection</code> object that corresponds to the
     *         specified dimensions.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection findSelection(java.util.List dimensions);*/

    /**
     * Specifies a <code>Selection</code> object for the starting
     * <I>universe</I> that corresponds to the specified item. This
     * selection scopes the specified item for all future selection work
     * that is applied to that item or query.
     * Note that universe Selections may not be set for the measure dimension.
     *
     * @param item  The item for which the universe will be specified.
     * @param selection  The <code>Selection</code> to specify as the universe.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Needs change Note that universe Selections may not be set for the measure dimension.
     */
  // blm - Selection code moved to dvt-olap
/*    public void setUniverseSelection(String item, Selection selection) throws MetadataManagerException, QueryException;*/

    /**
     * Retrieves the <code>Selection</code> object that is currently used as
     * the starting <I>universe</I> for the specified item.
     *
     * @param The item for which the <I>universe</I> selection will
     *        be retrieved.
     *
     * @return The <I>universe</I> <code>Selection</code> object;
     *         <code>null</code> if there is no <I>universe</I>
     *         <code>Selection</code> object.
     *
     * @throws IllegalArgException If arguments are invalid.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getUniverseSelection(String item) throws IllegalArgException;*/

    /**
     * Returns a default Selection/Step that the Query would define for the
     * given item.
     *
     * @return A default Selection/Step that the Query would define if none were provided.
     *         Returns null if no default can be defined.
     *
     * @throws QueryException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String item) throws QueryException;*/

    /**
     * Sets the specified <code>TotalStep</code> to enable row or column totals
     * on the specified dimension in the query.
     *
     * @param dimension The dimension on which to set the row or column total.
     * @param totalStep The <code>TotalStep</code> containing information about the row or column total.  If <code>null</code>,
     *                  any <code>TotalStep</code> set for the given dimension is cleared.
     * @return <code>true</code> if successful, <code>false</code> if unsuccessful or user canceled via event
     *
     * @throws QueryException           If there is a problem fetching data.
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setCalcDefinitions()}
     * 
     * @status New
     */
  // blm - Selection code moved to dvt-olap
/*    public boolean setTotal(String dimension, TotalStep totalStep) throws QueryException, MetadataManagerException;*/

    /**
     * Retrieves the <code>TotalStep</code> object that is currently set for the
     * specified dimension, if any.  Returns <code>null</code> otherwise.
     *
     * @param dimension The dimension for which the <code>TotalStep</code> will
     *        be retrieved.
     *
     * @return The <code>TotalStep</code> object;
     *         <code>null</code> if there is no <code>TotalStep</code> for the
     *         specified dimension.
     *
     * @throws IllegalArgException If arguments are invalid.
     * @throws QueryException If there was a problem getting the <code>TotalStep</code>
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #getCalcDefinitions()}
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public TotalStep getTotal(String dimension) throws IllegalArgException, QueryException;*/

    /**
     * @hidden
     * Sets the specified <code>TotalStep</code> to enable row or column totals
     * on the specified edge and layer in the query
     *
     * @param edge The edge on which to set the row or column total.
     * @param layer The layer on which to set the row or column total.
     * @param totalStep The <code>TotalStep</code> containing information about the row or column total.  If <code>null</code>,
     *                  any <code>TotalStep</code> set for the given edge and layer is cleared.
     * @return <code>true</code> if successful, <code>false</code> if unsuccessful or user canceled via event
     *
     * @throws QueryException           If there is a problem fetching data.
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setCalcDefinitions()}
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public boolean setTotal(int edge, int layer, TotalStep totalStep) throws QueryException, MetadataManagerException;*/

    /**
     * @hidden
     * Retrieves the <code>TotalStep</code> object that is currently set for the
     * specified edge and layer, if any.  Returns <code>null</code> otherwise.
     *
     * @param edge The edge for which the <code>TotalStep</code> will
     *        be retrieved.
     * @param layer The layer for which the <code>TotalStep</code> will
     *        be retrieved.
     *
     * @return The <code>TotalStep</code> object;
     *         <code>null</code> if there is no <code>TotalStep</code> for the
     *         specified dimension.
     *
     * @throws IllegalArgException If arguments are invalid.
     * @throws QueryException If there was a problem getting the <code>TotalStep</code>
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #getCalcDefinitions()}
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public TotalStep getTotal(int edge, int layer) throws IllegalArgException, QueryException;*/
    
    /**
     * Specifies the full set of DataFilters to be used by this Query.  If filters
     * involves a change to the Query's DataFilters, the Query will refresh.
     *
     * @param filters all DataFilters to be used by the Query
     *
     * @throws QueryException thrown if an error occurs, or if data filters are not supported
     * 
     * @status New
     */
    public void setDataFilters(BaseDataFilter[] filters) throws QueryException;

    /**
     * Returns the full set of DataFilters used by this Query. 
     *
     * @return all non-item based calculations used by the Query
     *
     * @status New
     */
    public BaseDataFilter[] getDataFilters();    
}
