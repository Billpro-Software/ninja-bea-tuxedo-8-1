/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.common;


import java.lang.reflect.Constructor;
import java.util.EventObject;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import java.util.Enumeration;
import java.util.BitSet;
import java.beans.PropertyChangeListener;

import oracle.dss.connection.client.Connection;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.selection.dataFilter.BaseDataFilter;

import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;

import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.PollingRequiredEvent;
import oracle.dss.util.DataDirector;
import oracle.dss.util.StatusInfo;
import oracle.dss.util.Utility;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.DataMap;
import oracle.dss.util.Operation;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.LayoutAccess;
import oracle.dss.util.CubeDataDirector;
import oracle.dss.util.QDR;
import oracle.dss.util.RelationalDataDirector;
import oracle.dss.util.persistence.Persistable2;
import oracle.dss.util.IDResolver;
import oracle.dss.util.LayoutContext;
import oracle.dss.util.parameters.ParameterManager;
import oracle.dss.util.persistence.AggregateInfo;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.persistence.ObjectScope;
import oracle.dss.util.persistence.GUIDConverter;
import oracle.dss.util.xml.XMLObjectReader;
import oracle.dss.util.xml.XMLObjectWriter;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.BIParseException;

import oracle.dss.datautil.QueryContext;


/**
 * Defines the data source API.  Concrete classes are defined to implement
 * certain calls on both the server and the client side of the QueryManager.
 * Users should reference the Query class in their code to keep their code
 * "tier agnostic."  Only those who instantiate an actual Query object need
 * to worry about the exact implementation subclass of Query (QueryClient or
 * QueryServer).
 *
 * @status Documented
 */ 
public abstract class Query extends Object implements oracle.dss.util.DataSource, DrillManager, MainManager, BaseManager, SelectionManager, LayoutManager, java.io.Serializable, /*WritebackWorker, */Persistable2, QueryContext, LayoutContext, /*MemberLevelCache, MetadataInfo, */QueryFunctions, ParameterManager
{
    // Debug flags

    // Setting DEBUG to false turns off all debugging 'System.out.println'
    // statements.  This should be the default for release code!

    // Setting DEBUG to true turns on lots of debugging 'System.out.println'
    // statements.  This is helpful for debugging!

    /**
     * @hidden
     * Indicates whether debugging statements should be produced.
     *
     * @status Documented
     */
    public final static boolean DEBUG = false;

    /**
     * @hidden
     */
    protected final static String MEASUREDIM = "MEASUREDIMENSION";
    
    /**
     * @hidden
     */
    public boolean MDCACHE = true;

    /**
     * @hidden
     */
    protected boolean m_sqlOnly = false;
    
    // Before state for restoring after failures or interruptions
    /**
     * @hidden
     */
    public transient QueryState m_beforeState = null;    
    
    /**
     * @hidden
     * Current operation
     */
    protected transient Operation m_currOp = null;
    // Current queue
    private transient BaseOperationQueue m_currQueue = null;
    // Current return value 
    private transient Object m_currRetVal = null;
    
    /**
     * @hidden
     * Current ds
     */
    protected Connection m_currentDataSource = null;    
    
    /**
     * @hidden
     * Layer metadata override storage
     */
    protected Hashtable m_layerMetadata = new Hashtable();
    
    /**
     *  @hidden
     */
    protected transient Object m_migrationFlag = null;
    
    /**
     *  @hidden
     */
    protected static final String MIGRATION_MEASDIM = "MDM!MEASUREDIMENSION";
   
    // Current Query XML version
    /**
     * @hidden
     */
    protected static final String m_version = "3.2";
    
    /**
     * @hidden
     */
  protected static final String PRE_GUID_VERSION = "2.7.0.1";
    /**
     * @hidden
     */
  protected static final String PRE_STAMP_VERSION = "2.5.0.7.1";

    /**
     * @hidden
     * 
     * Value used to represent null MDObject values that need to be stored
     * within the MDObject cache hashtable.
     */
    protected final static NullMDObject m_nullMDObject = new NullMDObject();

    /**
     * @hidden
     * 
     * Class used to represent null MDObject values that need to be stored
     * within the MDObject cache hashtable.
     */
    public static class NullMDObject extends MDObject {
    }

    /**
     * @hidden
     */
    protected MDObjectKey[] m_mdObjectKeyPool = new MDObjectKey[10];
    
    /**
     * @hidden
     * Current query state
     */
    protected QueryState m_queryState = null;
    
    /////////////////////
    //
    // Constants
    //
    /////////////////////    
    // Data Items (DATAITEM_XXX)


    // Persistence name
    /**
     * @hidden
     */
    protected static final String XMLName = "Query";

    // OLAP server constant
    /**
     * @hidden
     */
    protected static final String OLAPSERVER = "OLAPServer";

    /**
     * Name of reference resolver.  This is the name to use when passing the
     * QueryManager in the PersistenceManager's environment argument
     * for automatic connection on lookup().
     *
     * @status Documented
     */
    public static final String QUERY_MANAGER = "QueryManager";

    /**
     * Name of property that can be given to the Persistence environment when
     * reloading a Query or a view that contains a query to indicate that the
     * query should not be evaluated initially (sets the "EvaluateCursor" property
     * to false).
     * @status New
     */
    public static final String NO_EVALUATE_ON_LOAD = "NoEvalOnLoad";
    
    /////////////////////
    //
    // Member Variables
    //
    /////////////////////
    // ID
    private String m_id    = null;
    
    // Backing QueryManager instance
    private QueryManager  m_queryManager  = null;
    
    // Debug mode
    private transient boolean   m_debugMode = false;

    // SQL print?
    private transient long m_dumpSQLType = 0;

    // Name of SPL program to validate a given QDR before writing back
    private transient String m_wbValidator = null;
    
    // Have we dumped the SQL yet?
    /**
     * @hidden
     */
    public transient boolean m_dumped = false;

    /**
     * @hidden
     * Debug mode for QueryAccess
     */
    public transient boolean m_QADebugMode = false;

    // Temporary queue for "access" updates
    /**
     * @hidden
     */
    protected transient BaseOperationQueue m_accessOperationQueue = null;
    
    /**
     * @serial list of registered directors to private interface
     */
    private Vector                  m_dataDirectors   = null;
    
    /**
     *  @hidden
     */
    protected boolean m_mustClearDrillCaches = false;
    
    /**
     * @hidden
     * @serial Query name
     */
    protected String    m_name    = null;

    /**
     *  @hidden
     */
    protected IDResolver m_idResolver = null;
    
    /**
     * @hidden
     * Migration converter
     */
    protected GUIDConverter m_converter = null;
    
    // Queue
    /**
     * @hidden
     */
    protected transient BaseOperationQueue    m_opQueue = null;
    
    // Data source listener cube cursors
//    private transient Vector    m_cubeCursors    = null;  
    //private transient Vector    m_oldCursors     = null;
    // Data director listener cube cursors
//    private transient Vector    m_ddlCursors    = null;
    //private transient Vector    m_oldDDLCursors = null;
    // Listener list
    /**
     * @hidden
     */
    protected transient ListenerLists m_listeners;
    
    // Flag indicating persistent state has been just set
    /**
     * @hidden
     */
    protected transient boolean m_persistentStateSet = false;    

    // Flag indicating this query is in the process of closing
    /**
     * @hidden
     */
    protected transient boolean m_isClosing = false;
    
    /**
     * @hidden
     * @serial Should a default query be generated?
     */
    protected boolean m_defaultQuery = true;        

    /**
     * @hidden
     * @serial Support for client-side maps
     */
    //protected MapSupport    m_queryState.getMapSupport() = new MapSupport(this);
    
    /**
     * @hidden
     * @serial property value storage
     */
    //public PropertySupport       m_queryState.getPropertySupport()     = new PropertySupport(this, this);

    // Persistable attributes
    /**
     * @hidden
     */
    protected transient PersistableAttributes m_attrs   = null;
    
    // The flag used for XML validation
    private boolean m_validateXML = false;
    

    // Backup error handler
    private transient ErrorHandler m_eh = new DefaultErrorHandler();

    // MDObject cache
    /**
     * @hidden
     */
    protected transient Hashtable m_mdObjectCache = new Hashtable();
    
    // ThinBean name
    /**
     * @hidden
     */
    //protected String m_thinBeanName = null;
    
    /**
     * @hidden
     * Registration table by data source type for various pluggable classes
     */
    protected Hashtable m_registrationTable = new Hashtable();
        
    /////////////////////
    //
    // Constructors
    //
    /////////////////////
        
    /**
     *  <pre>
     *      Constructor for the <code>Query</code>.<br>
     *
     *  </pre>
     *
     * @return     Newly constructed Consumer object, or null.
     *
     * @status Documented
     */

    public Query()
    {
        super();

        setupCacheKeyPool();
        m_listeners = new ListenerLists();        

    }
        
    /**
     * @hidden
     *  <pre>
     *      Constructor for the <code>Query</code>.<br>
     *
     *  </pre>
     *
     * @param      qmc  Backing QueryManager instance
     * @return     Newly constructed Consumer object, or null.
     *
     * @status hidden
     */

    public Query(QueryManager qmc)
    {
        this();
        try
        {
            setQueryManager(qmc);
        }
        catch (Exception e)
        {
        }
    }
    
    /**
     * @hidden
     * Set the Query ID (used to synchronize between tiers)
     *
     * @param id id to set
     * @status hidden
     */
    public void setID(String id)
    {
        m_id = id;
    }

    /**
     * @hidden
     * Get the Query ID
     * @return id
     * @status hidden
     */     
    public String getID()
    {
        return m_id;
    }
    

    
    /**
     * Specifies the QueryManager property. If a <code>Query</code> object
     * is created by the factory method (createQuery) of the QueryManager, then
     * this property is also specified automatically at that time.
     * If you create a <code>Query</code> object by using the constructor in
     * this Query class, then you must also specify the QueryManager property
     * before the Query object can run.
     *
     * @param qmc  QueryManager instance
     *
     * @throws Exception Error encountered when bringing back a query from
     *         persistence.
     *
     * @status Documented
     */
    public void setQueryManager(QueryManager qmc) throws Exception
    {
        m_queryManager = qmc;
    }
    
    /**
     * Retrieves the QueryManager property value.
     *
     * @return A reference to the <code>QueryManager</code> object or
     *         <code>null</code>.
     *
     * @throws QueryRuntimeException thrown if the QueryManager is null.
     *
     * @status Documented
     */
    public QueryManager getQueryManager() 
    {
        if (m_queryManager == null)
        {
            // Note there is no way to pass this through the resource bundle
            throw new NoQueryManagerException("QueryManager has not been set", null);
        }
        return m_queryManager;
    }

    /**
     * @hidden
     * @return 
     */
    public QueryManagerInterface getQueryManagerInterface()
    {       
        return getQueryManager();
    }

    /**
     * Removes a listener from this <code>Query</code>.
     *
     * @param l The listener that is to be removed.
     *
     * @status Documented
     */
    public void removeQueryListener(QueryListener l) {
        int index = m_listeners.listeners.indexOf(l);
        if (index > -1) {
            m_listeners.listeners.removeElementAt(index);
/*            if (m_cubeCursors != null && m_cubeCursors.size() > index) {
                ((CubeCursor)m_cubeCursors.elementAt(index)).release();
                m_cubeCursors.removeElementAt(index);
            }
            if (m_oldCursors != null && m_oldCursors.size() > index) {
                ((CubeCursor)m_oldCursors.elementAt(index)).release();
                m_oldCursors.removeElementAt(index);
            }*/
        }
    }

    /**
     * Closes any open <code>Query</code> middle tier references for
     * proper clean up.
     * Note this method may throw a QueryRuntimeException.
     *
     * @status Needs change
     */
    public synchronized void close() {                
        // Clean up and remove from list on client and middle tier or just middle tier
        try
        {
            _close();
        }
        catch (OLAPTransactionException ote)
        {
            throw new QueryRuntimeException(ote.getMessage(), ote);
        }
    }

    /**
     * @hidden
     * Private close routine
     */
    public void _close() throws OLAPTransactionException
    {
        // Just perform local cleanup
        // Clean up listeners
        m_listeners.removeAll();        
        if (m_dataDirectors != null) {
            m_dataDirectors.removeAllElements();
        }

    /*
        if (m_cubeCursors != null)
        {
            Enumeration curs = m_cubeCursors.elements();
            CubeCursor cur = null;
            while (curs.hasMoreElements())
            {
                cur = (CubeCursor)curs.nextElement();
                if (cur != null)
                {
                    cur.release();
                }
                cur = null;
            }
            m_cubeCursors.removeAllElements();
            m_cubeCursors = null;
        }
        if (m_oldCursors != null)
        {
            Enumeration curs = m_oldCursors.elements();
            CubeCursor cur = null;
            while (curs.hasMoreElements())
            {
                cur = (CubeCursor)curs.nextElement();
                if (cur != null)
                {
                    cur.release();
                }
                cur = null;
            }
            m_oldCursors.removeAllElements();
            m_oldCursors = null;
        }
        if (m_ddlCursors != null)
        {
            Enumeration curs = m_ddlCursors.elements();
            CubeCursor cur = null;
            while (curs.hasMoreElements())
            {
                cur = (CubeCursor)curs.nextElement();
                if (cur != null)
                {
                    cur.release();
                }
                cur = null;
            }
            m_ddlCursors.removeAllElements();
            m_ddlCursors = null;
        }
       if (m_oldDDLCursors != null)
        {
            Enumeration curs = m_oldDDLCursors.elements();
            CubeCursor cur = null;
            while (curs.hasMoreElements())
            {
                cur = (CubeCursor)curs.nextElement();
                if (cur != null)
                {
                    cur.release();
                }
                cur = null;
            }
            m_oldDDLCursors.removeAllElements();
            m_oldDDLCursors = null;
        }
*/
        if (m_mdObjectCache != null)
        {
            m_mdObjectCache.clear();
            m_mdObjectCache = null;
        }
        m_accessOperationQueue = null;
        m_queryState = null;
        m_opQueue = null;
        m_attrs = null;
    }
    
    /**
     * @hidden
     */
    public Operation getCurrentOperation()
    {
        return m_currOp;
    }
    
    /**
     * @hidden
     */
    protected BaseOperationQueue getCurrentQueue()
    {
        return m_currQueue;
    }
    
    /**
     * @hidden
     * 
     */
    protected Object getCurrentReturnValue()
    {
        return m_currRetVal;
    }    
    
    /**
     * @hidden
     * Set current op
     */
    protected void setCurrentOperation(Operation op)
    {
        m_currOp = op;
        // Inform callers about polling, but *only* if there's a data changed event waiting in the list, only when the operation
        // is being cleared, and only when we're doing cursor evaluations
        firePollingRequired(null, null);
    }

    // Is polling required now?
    protected boolean firePollingRequired(QueryListener listener, DataDirectorListener ddl)
    {
        if (_getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_ASYNCHRONOUS) &&
            isEvaluateCursor() && 
            m_currOp == null && 
            eventListHasDataEvent())
        {
            // asynch, so fire event
            firePollingRequired(new StatusInfo(StatusInfo.DATASOURCE_EXECUTING), listener, ddl);            
            return true;
        }
        return false;
    }
    
    // Does the event list have a data available or data changed event?
    private boolean eventListHasDataEvent()
    {
        if (m_currQueue == null)
            return false;
            
        // We must blank out any initialization knowledge here, because the object will survive
        // intact in local mode
        EventList list = ((OperationQueue)m_currQueue).m_events;
        
        if (list != null)
        {
            Enumeration events = list.elements();
            while (events.hasMoreElements())
            {
                Object event = events.nextElement();
                if (event instanceof DataChangedEvent || event instanceof DataAvailableEvent)
                    return true;
            }
        }
        return false;
    }
    
    /**
     * @hidden
     * Set current op & queue
     */
    protected void setCurrentOperationAndQueue(Operation op, BaseOperationQueue queue)
    {
        setCurrentOperation(op);
        m_currQueue = queue;
    }
    
    /**
     * @hidden
     * Set current queue
     */
    protected void setCurrentQueue(BaseOperationQueue queue)
    {
        if (m_currQueue == null || queue == null)
            m_currQueue = queue;
    }
    
    /**
     * @hidden
     * 
     */
    protected void setCurrentReturnValue(Object retVal)
    {
        if (retVal == null)
        {
            m_currRetVal = null;
            return;
        }
            
        if (m_currOp != null)
            m_currRetVal = retVal;
    }
        
    /**
     * Adds a property change listener.
     *
     * @param l The listener that is to be added.
     *
     * @status Documented
     */
    public void addPropertyChangeListener(PropertyChangeListener l) {
        _getQueryState().getPropertySupport().addPropertyChangeListener(l);
    }

    /**
     * Removes a property change listener.
     *
     * @param l The listener that is to be removed.
     *
     * @status Documented
     */
    public void removePropertyChangeListener(PropertyChangeListener l) {
        _getQueryState().getPropertySupport().removePropertyChangeListener(l);
    }


    /**
     * @hidden
     * @return 
     */
    protected String assignNewGUID()
    {
        return new java.rmi.server.UID().toString();        
    }         
    
   /**
     * @hidden
     * Fires the <code>CellOverridingEvent</code> to inform listeners that a
     * cell override (edit) operation is requested.
     *
     * @param e Represents the cell overriding event.
     *
     * @status Documented
     */
   public void fireCellOverriding ( CellOverridingEvent e)
   {
        m_listeners.fireCellOverridingEvent(e);
   }

   /**
     * @hidden
     * Fires the <code>CellOverridenEvent</code> to inform listeners that a
     * cell override (edit) operation has occurred.
     *
     * @param e Represents the cell overridden event.
     *
     * @status Documented
     */
   public void fireCellOverridden ( CellOverriddenEvent e)
   {
        m_listeners.fireCellOverriddenEvent(e);
   }

   /**
     * @hidden
     * Fires the <code>CellsSubmittingEvent</code> to inform listeners that a
     * cells submission operation is requested. This event relates to the
     * submission to the database of the QDR overrides in the writeback
     * collection. Each QDR override represents a cell that has been edited.
     *
     * @param e Represents the cells submitting event.
     *
     * @status Documented
     */
   public void fireCellsSubmitting ( CellsSubmittingEvent e)
   {
        m_listeners.fireCellsSubmittingEvent(e);
   }

   /**
     * @hidden
     * Fires the <code>CellsSubmittedEvent</code> to inform listeners that a
     * cells submission operation has occurred. This event relates to the
     * submission to the database of the QDR overrides in the writeback
     * collection. Each QDR override represents a cell that has been edited.
     *
     * @param e Represents the cells submitted event.
     *
     * @status Documented
     */
   public void fireCellsSubmitted ( CellsSubmittedEvent e)
   {
        m_listeners.fireCellsSubmittedEvent(e);
   }


   //////////////////////
   //
   // Properties
   //
   //////////////////////
    /**
     * Controls whether operations should be sent to the middle tier for
     * immediate processing or accumulated in a pending operations queue.
     *
     * @param b <code>true</code> sends each operation for immediate processing;
     *          <code>false</code> lets operations accumulate in a pending
     *          operations queue.
     *
     * @throws All Any of the exceptions that are contained in the operations
     *         that are currently in the queue.
     *
     * @status Documented
     */
    public synchronized void setAutoUpdate(boolean b) throws Exception
    {
        _getQueryState().getPropertySupport().setAutoUpdate(b);
    }
    
    /**
     * Indicates whether all operations are sent to the middle tier for
     * immediate processing or accumulated in a pending operations queue for
     * later update.
     *
     * @return <code>true</code> if operations are sent to the middle tier for
     *         immediate processing;
     *         <code>false</code> if operations are accumulated in a pending
     *         operations queue for later update.
     *
     * @status Documented
     */
    public boolean isAutoUpdate() {
        return _getQueryState().getPropertySupport().isAutoUpdate();
    }
    
    /**
     * @hidden
     */
    public QueryState _getQueryState() 
    {
        if (m_queryState == null)
        {
            try
            {
                m_queryState = new QueryState(this, getMeasureDim());
            }
            catch (InvalidMetadataException ime)
            {
                throw new QueryRuntimeException(ime.getMessage(), ime);
            }
        }
        return m_queryState;
    }
    
    public void setAutoSubmit( boolean bValue)
    {
        getPropertySupport().setProperty(QueryConstants.PROPERTY_AUTO_SUBMIT, new Boolean(bValue));
    }

    public boolean isAutoSubmit()
    {
        return getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_AUTO_SUBMIT);
    }

    /**
     * Indicates whether any operations are pending.
     * Always returns <code>false</code> if the AutoUpdate property is set to
     * <code>true</code>.
     * <p>
     * Note:Pending operations can be sent to the middle tier for processing by
     * calling the <code>update</code> method or by calling the
     * <code>setAutoUpdate</code> method with the parameter <code>true</code>.
     *
     * @return <code>true</code> if operations are pending;
     *         <code>false</code> if there are no operations pending.
     *
     * @status Documented
     */
    public boolean isUpdatePending() {
        return m_opQueue.isUpdatePending();
    }

    /**
     * @hidden
     * Are there any listeners at all? Regular, DD, or InfoBus?
     *
     * @return <code>false</code> if none
     */
    public boolean anyListeners()
    {
        boolean hasDDL = false;
        if (m_dataDirectors != null)
        {
            Enumeration dds = m_dataDirectors.elements();
            while (dds.hasMoreElements())
            {
                Object dd = dds.nextElement();
                if (dd instanceof DataDirectorImpl)
                {
                    if (((DataDirectorImpl)dd).getListenerCount() > 0)
                    {
                        hasDDL = true;
                        break;
                    }
                }
            }
        }
        int listSize = m_listeners == null ? 0 : m_listeners.size();
        return hasDDL || listSize > 0;        
    }
    
    /**
     * @hidden
     * Return the listener lists for this query
     *
     * @return listener list
     * @status hidden
     */
    protected ListenerLists getListenerList()
    {
        return m_listeners;
    }

    /**
     * Construct the dimensional portion of the member ID for total rows or columns.
     *
     * @param dimension dimension of total step
     */
    public static String constructTotalDimensionID(String dimension)
    {
        return "TOTAL " + dimension;
    }

    /**
     * Construct the member ID for total rows or columns.  This may be used by
     * callers wishing to positively identify whether an ID represents a total
     * row or column.
     *
     * @param ts    The total step for which to construct a total ID
     * @param da    The data access context of the total ID
     * @param edge  The edge for which to construct a total ID
     * @param layer The layer for which to construct a total ID
     * @param slice The slice for which to construct a total ID
     *
     * @return The total ID string the Query constructs at this cursor location.
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public String constructTotalMemberID(TotalStep ts, DataAccess da, int edge, int layer, int slice)
    {
        if (ts == null)
            return null;

        if (ts.isLocationDependent())
        {
            return "TOTAL "+edge+" "+layer+" "+slice;
        }
        else
        {
            // Must supply the QDR pairs for layers outside the total's layer
            String retVal = constructTotalDimensionID(ts.getDimension());
            if (da == null)
                return retVal;
                
            for (int l = 0; l < layer; l++)
            {
                try
                {
                    retVal += " " + da.getLayerMetadata(edge, l, LayerMetadataMap.LAYER_METADATA_NAME) + " " + da.getMemberMetadata(edge, l, slice, MetadataMap.METADATA_VALUE);
                }
                catch (Exception e)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
            return retVal;
        }
    }
*/
    /**
     * Specifies a list of measures and creates a default cube for the query.
     *
     * @param measures The list of measures to use to make a default cube.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setItems()}
     *
     * @status Documented
     */
    public void setMeasures(String[] measures)
    {
        _getQueryState().setMeasures(measures);
    }

    /**
     * Retrieves the list of measures that were used to produce the current
     * query.
     *
     * @return The list of measures.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #getDataItems()}
     *
     * @status Documented
     */
    public abstract String[] getMeasures();

    /**
     * @hidden
     * Is this an OLAP query?
     */
    protected abstract boolean isOLAP();


    
    /**
     * Specifies the default number of dimensions to put on a column for
     * default layouts.
     *
     * @param numCol The number of dimensions to put on the column for default
     *               layouts.
     *
     * @deprecated As of 4.0.0.0
     * 
     * @status Documented
     */
    public void setDefaultColumnCount(int numCol)
    {
        _getQueryState().getPropertySupport().setDefaultColumnCount(numCol);
    }
    
    /**
     * Retrieves the default number of dimensions put on a column for
     * default layouts.
     *
     * @return The default number of dimensions.
     *
     * @deprecated As of 4.0.0.0
     *
     * @status Documented
     */
    public int getDefaultColumnCount() {
        return _getQueryState().getPropertySupport().getDefaultColumnCount();
    }

    /**
     * Specifies the default number of dimensions to put on a row for default
     * layouts.
     *
     * @param numRow The number of dimensions to put on the row for default
     *               layouts.
     *
     * @status Documented
     */
    public void setDefaultRowCount(int numRow)
    {
        _getQueryState().getPropertySupport().setDefaultRowCount(numRow);
    }

    /**
     * Retrieves the default number of dimensions to put on a row for
     * default layouts.
     *
     * @return The number of dimensions to put on a row for default layouts.
     *
     * @status Documented
     */
    public int getDefaultRowCount() {
        return _getQueryState().getPropertySupport().getDefaultRowCount();
    }

    /**
     * Indicates whether debug printouts should be produced.
     *
     * @param mode <code>true</code> produces debug printouts on both
     *             client and server;
     *             <code>false</code> does not produce debug printouts.
     */
    public void setDebugMode(boolean mode)
    {
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_DEBUG_MODE, new Boolean(mode));
    }


    /**
     * Indicates whether debug printouts will be produced.
     *
     * @return <code>true</code> indicates that debug printouts will be
     *         produced; <code>false</code> indicates that debug printouts
     *         will not be produced.
     *
     * @status Documented
     */
    public boolean isDebugMode()
    {        
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_DEBUG_MODE);
    }

    
    //javadoc copied from interface
    public void setDrillWithFilteredChildren(boolean filter)
    {
        boolean oldValue = _getQueryState().getPropertySupport().isDrillWithFilteredChildren();
        _getQueryState().getPropertySupport().setDrillWithFilteredChildren(filter);
        if (oldValue != filter)
        {
            // Mark this as needing to clear any drill caches on the next cursor update
            m_mustClearDrillCaches = true;
        }
    }
 

    //javadoc copied from interface
    public boolean isDrillWithFilteredChildren()
    {
        return _getQueryState().getPropertySupport().isDrillWithFilteredChildren();
    }

    /**
     * @hidden
     * Indicates whether OLAP Services SQL should be dumped out with each Query update
     *
     * @param type Value greater than zero indicates that printouts should be produced using
     *             the given OLAP Services getGenerationInfo type.
     */
    public void setSQLDump(long type)
    {
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_SQL_DUMP, new Long(type));
    }

    /**
     * @hidden
     * Indicates whether OLAP Services SQL should be dumped out with each Query update
     *
     * @return A value greater than zero indicates that it will.
     */
    public long getSQLDump()
    {
        return _getQueryState().getPropertySupport().getPropertyAsLong(QueryConstants.PROPERTY_SQL_DUMP);
    }

    /**
     * Registers a custom Olap DML program which will be called before writting back modified QDRs. 
     * The program expects a 'QDR=value' string as the only argument. If the QDR's value is valid, 
     * the program should return the String '0' (zero). Otherwise a short text message explaining the reason 
     * of the validation failure will be returned. This message will be stored in the ErrorText property
     * of the java representation of this QDR, a oracle.dss.dataSource.common.QDRoverride object.
     * @param prgName The name of the Olap DML program.
     */
    public void setWritebackValidator(String SPLPrgName)
    {
        m_wbValidator = SPLPrgName;
    }
   /**
     * Returns the name of a registered SPL program which performs QDR validation before a writeback occures.
     *
     * @return The name of the registered SPL program.
     */
    public String getWritebackValidator()
    {
        return m_wbValidator;
    }
   /**
     * Indicates whether query state printouts should be produced on every query operation.
     *
     * @param mode <code>true</code> produces state printouts on
     *             server;
     *             <code>false</code> does not produce state printouts.
     */
    public void setPrintQueryState(boolean mode)
    {   
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_PRINT_QUERY_STATE, new Boolean(mode));
    }


    /**
     * @hidden
     * Determines whether calculation divide by zero conditions will result
     * in NA values (<code>true</code>) or Exceptions (<code>false</code>, and the default).
     *
     * @param allowed if <code>true</code>, divide by zero calculation errors return an NA value.
     *
     * @status New
     */
    public void setAllowDivideByZero(boolean allowed)
    {        
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_ALLOW_DIVIDE_BY_ZERO, new Boolean(allowed));
    }
    
    /**
     * @hidden
     * Do calc divide by zero errors result in NA or an Exception?
     *
     * @return <code>true</code> if an NA is returned, <code>false</code>
     *         if an Exception is thrown (default).
     *
     * @status New
     */
    public boolean isAllowDivideByZero()
    {
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_ALLOW_DIVIDE_BY_ZERO);
    }

   /**
     * Indicates whether query state printouts should be produced on every query operation.
     *
     * @return <code>true</code> indicates that state printouts will be
     *         produced; <code>false</code> indicates that state printouts
     *         will not be produced.
     */
    public boolean isPrintQueryState()
    {
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_PRINT_QUERY_STATE);
    }

    /**
     * Specifies a table of interface names and interface-implementing Class values for a given Metadata Manager 
     * data source type code.  The Query will use these to determine the proper Query interface implementation objects to 
     * instantiate to handle the data source specific metadata items it is given at initialization or re-initialization.  
     * Examples include the implementation of the Query API-backing interface, the interfaces to implement DataAccess and 
     * DataDirector for the backing interface, and possibly LayoutAccess / QueryEditor implementations.  Note that each 
     * register call is additive: a new metadataType with a new classTable will be registered along with any previous 
     * registrations.  If metadataType was already registered, its classTable will be replaced with the new classTable.  
     * If classTable is null, the metadataType registered will be deleted.Note that any registrations made on the 
     * QueryManager implementation of this API call will be passed to any Queries generated from that QueryManager.
     * 
     * @param metadataType  The metadata type for which to register the given set of interface-implementing classes.
     * @param classTable    A table linking string keys naming specific, pluggable interfaces defined by the Query 
     *                      classes with Class objects from which implementers for those interfaces may be instantiated as needed.
     *                      For example:{�oracle.dss.dataSource.common.QueryInterface�, �oracle.discoverer.query.QueryInterfaceImpl� }
     *                      
     * @throws Exception thrown if an error occurs.
     * 
     * @status New
     */
    public void registerImplementation(String metadataType, Hashtable classTable)
    {
        m_registrationTable.put(metadataType, classTable);
    }
    
    /**
     * @hidden
     * Invoke the pluggable for the given interface and data source type string
     */
    protected Object loadPluggable(String type, String interfaceClass)
    {
        Hashtable intTable = (Hashtable)m_registrationTable.get(type);
        if (intTable == null)
            return null;
        
        // Get the class name for this interface
        String classToInvoke = (String)intTable.get(interfaceClass);
        if (classToInvoke == null)
            return null;
            
        try
        {
            Class classObj = Utility.loadClass(classToInvoke);
            if (classObj != null)
            {
                Constructor cons = classObj.getConstructor(new Class[] {Query.class});
                return cons.newInstance(new Object[] {this});
            }
        }
        catch (Exception e)
        {
            getErrorHandler().error(e, Query.class.getName(), "loadPluggable");
        }
        return null;
    }    
        
    // javadoc from interface
    public void setHierarchicalDrilling(boolean hierDrill)
    {
        _getQueryState().getPropertySupport().setHierarchicalDrilling(hierDrill);
    }    

    // javadoc from interface
    public boolean isHierarchicalDrilling()
    {
        return _getQueryState().getPropertySupport().isHierarchicalDrilling();
    }

    // javadoc from interface
    public void setAsymmetricDrilling(boolean asymmetric)
    {
        _getQueryState().getPropertySupport().setAsymmetricDrilling(asymmetric);
    }    

    // javadoc from interface
    public boolean isAsymmetricDrilling()
    {
        return _getQueryState().getPropertySupport().isAsymmetricDrilling();
    }

    /**
     * Indicates whether pages are fetched as separate cursors
     *
     * @param separate code>true</code> to separate page cursors from the data cursor
     * @new
     */
    public void setSeparatePage(boolean separate)
    {
    }    

    /**
     * Indicates whether page cursors are fetched separately from data cursors
     *
     * @return <code>true</code> if page cursors are separate
     *         <code>false</code> if the entire query is one cursor
     *
     * @status New
     */
    public boolean isSeparatePage()
    {
        return true;
    }

    // javadoc from interface
    public void setFetchSize(int size)
    {
        _getQueryState().getPropertySupport().setFetchSize(size);
    }

    // javadoc from interface
    public int getFetchSize()
    {
        // Don't return all due to OLAPI bugs
        return /*isNASuppressedLocally() ? -1 : */_getQueryState().getPropertySupport().getFetchSize();
    }

    
    // javadoc from interface
    public void setFetchPageEdge(boolean fullfetch)
    {
        _getQueryState().getPropertySupport().setFetchPageEdge(fullfetch);
    }

    // javadoc from interface
    public boolean getFetchPageEdge()
    {
        return _getQueryState().getPropertySupport().getFetchPageEdge();
    }

    /**
     * @hidden
     * Sets whether page dimensions are fetched separately, if possible.
     *
     * @param separate if <code>true</code>, the page dimensions are fetched separately.  If not, they are fetched together.
     */
/*    public void setSeparatePageDimensions(boolean separate)
    {
        _getQueryState().getPropertySupport().setSeparatePageDimensions(separate);
    }*/

    /**
     * @hidden
     * Returns whether page dimensions are fetched separately.
     *
     * @return <code>true</code> if page dimensions are fetched separately.
     *
     * @status New
     */
/*    public boolean getSeparatePageDimensions()
    {
        return _getQueryState().getPropertySupport().getSeparatePageDimensions();
    }*/

   /**
    * Specifies whether page changes are transmitted among listeners.
    * By default, if there are multiple listeners of any kind on a
    * <code>Query</code>, then a change to the page edge of the query by
    * one listener will be transmitted to the cursors of all the other
    * listeners. (Each listener has its own copy of the cursor on the
    * client side.)
    *
    * @param b <code>true</code> indicates that page changes should be shared
    *          among all listeners;
    *          <code>false</code> indicates that a page change by one listener
    *          will not be shared among the other listeners.
    *
    * @status Documented
    */
   public void setSharePage(boolean b) {
        _getQueryState().getPropertySupport().setSharePage(b);
   }

   /**
    * Indicates whether page changes by one listener on the
    * <code>Query</code> should be shared among all listeners.
    *
    * @return <code>true</code> indicates that page changes by one listener
    *         will be shared among all listeners;
    *         <code>false</code> indicates that page changes by one listener
    *         will not be shared among all listeners.
    *
    * @status Documented
    */
   public boolean isSharePage() {
        return _getQueryState().getPropertySupport().isSharePage();
   }

   /**
    * Specifies the current page if pages are shared among listeners.
    *
    * @param page    Page number to share among listeners.
    * @param qdrPage QDR version of the page.
    *
    * @status Documented
    * @deprecated
    */
   public void setCurrentPage(int page, QDR qdrPage)
   {
       _getQueryState().getPropertySupport().setCurrentPage(page, qdrPage);
       setCurrentPage((long)page, qdrPage);
   }

   /**
    * Specifies the current page if pages are shared among listeners.
    *
    * @param page    Page number to share among listeners.
    * @param qdrPage QDR version of the page.
    *
    * @status Documented
    */
   public abstract void setCurrentPage(long page, QDR qdrPage);

  /**
   * @hidden
   * @param page
   * @param qdrPage
   * @param e
   */
   public void setCurrentPageAndFireEvent(long page, QDR qdrPage, DataChangedEvent e) throws QueryException
   {
        if (page != _getQueryState().getPropertySupport().getCurrentPage())
        {
            // Call the subclass which calls back to this class to set the page
            setCurrentPage(page, qdrPage);
        }
/*        // Push the page into each query listener's cube cursor
        for (int i = 0; i < m_listeners.size(); i++)
        {
            CubeCursor cc = m_listeners.getCubeCursor(i);
            try
            {
                cc.setTrueSlice(DataDirector.PAGE_EDGE, page, false);            
            }
            catch (Exception ex)
            {
                throw new QueryRuntimeException(ex.getMessage(), ex);
            }
        }*/
        
        // Fire an event to Query Listeners
        m_listeners._fireDataChangedEvent(e, this);
   }

   /**
    * Retrieves the current page number if pages are shared among listeners.
    *
    * @return Page number that is being shared among listeners.
    *
    * @status Documented
    * @deprecated 
    */
   public int getCurrentPage()
   {
        return (int)_getQueryState().getPropertySupport().getCurrentPage();
   }

    /**
     * Retrieves the current page number if pages are shared among listeners.
     * 
     * @return Page number that is being shared among listeners.
     * 
     * 
     * @status New
     */
    public long getCurrPage()
    {
        return _getQueryState().getPropertySupport().getCurrentPage();        
    }

    /**
     * @hidden
     */
    public boolean fireCellOverriding(long row, long col, long page, Object data, QDR qdr)
    {
        CellOverridingEvent ei =
            new CellOverridingEvent(this, row, col, page, data, qdr);
            fireCellOverriding( ei);   
            
        return ei.isConsumed();
    }
    
    /**
     * @hidden
     */
    public void fireCellOverridden(long row, long col, long page, Object data, QDR qdr)
    {
        CellOverriddenEvent ed =
            new CellOverriddenEvent (this, row, col, page, data, qdr);
        fireCellOverridden( ed);        
    }
    
    /**
     * @hidden
     */
    public boolean fireCellsSubmitting(List qdrOverride)
    {        
        CellsSubmittingEvent ei =
            new CellsSubmittingEvent(this, qdrOverride);

        fireCellsSubmitting(ei);    
        
        return ei.isConsumed();
    }
    
    /**
     * @hidden
     */
    public void fireCellsSubmitted(List qdrOverride, boolean success)
    {        
        CellsSubmittedEvent ed =
            new CellsSubmittedEvent(this, qdrOverride);
        ed.setSubmitSuccess(success);
        fireCellsSubmitted(ed);    
    }
    
    /**
     * @hidden
     */
    public void fireDataChanged(int edge, int type) throws Exception
    {        
        DataChangedEvent dce = new DataChangedEvent(this, type, null);
        fireDataChanged(dce, -1, null, edge, false);              
    }
    
    /**
     * @hidden
     * Set the default mode (that a cube is created by default when
     * a view tries to listen to a cubeless data source)
     *
     * @param b if <code>true</code> (default) create a cube if none
     */
    public void setDefaultQuery(boolean b) {
        m_defaultQuery = b;
    }

    /**
     * @hidden
     * Get the default mode
     *
     * @param if <code>true</code> create a default query if none
     */
    public boolean isDefaultQuery() {
        return m_defaultQuery;
    }

    /**
     * @hidden
     * Set whether annotations should be allowed regardless of their
     * availability
     *
     * @param allow if <code>true</code> allow annotations
     * @status new
     */
    public void setAnnotationsAllowed(boolean allow)
    {
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_ALLOW_ANNOTATIONS, new Boolean(allow));
    }

    /**
     * @hidden
     * Get whether annotations are allowed at all
     *
     * @return <code>true</code> if annotations are allowed
     * @status new
     */
    public boolean areAnnotationsAllowed()
    {   
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_ALLOW_ANNOTATIONS);
    }

    /**
     * @hidden
     *
     * Tells the query to strip the query down to just value columns
     *
     * @param valueOnly strip the query down to just value columns if true (default is false)
     */
    public void setQueryValueOnly(boolean valueOnly)
    {
        try
        {
            if (VersionCheck.is9203(getQueryManager()))
            {
                _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_VALUE_ONLY, new Boolean(valueOnly));
            }
        }
        catch (Exception e)
        {
            // Could be thrown because we're not yet hooked up: take the version on faith then
            try
            {
                _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_VALUE_ONLY, new Boolean(valueOnly));
            }
            catch (Exception e2)
            {
                throw new QueryRuntimeException(e2.getMessage(), e2);
            }
        }
    }

    /**
     * @hidden
     */
    public boolean isQueryValueOnly()
    {
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_VALUE_ONLY);
    }


    /**
     * @hidden
     * Allows caller to turn on OLAP Services debug SQL generation for cursor managers
     *
     * @param type OLAP Services ExpressGenerationInfo type (note a value of zero will turn the generation off, and
     *        is the default)
     */
    public void setQuerySQLType(long type)
    {   
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_SQL_TYPE, new Long(type));
    }

    /**
     * @hidden
     */
    public long getQuerySQLType()
    {
        return _getQueryState().getPropertySupport().getPropertyAsLong(QueryConstants.PROPERTY_SQL_TYPE);
    }

    /**
     * @hidden
     */
    public void setSelfCalcTotals(boolean self) throws Exception
    {
        _getQueryState().getPropertySupport().setProperty(QueryConstants.PROPERTY_IS_SELF_CALC_TOTALS, new Boolean(self));
    }

    /**
     * @hidden
     */
    public boolean isSelfCalcTotals()
    {
        return _getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_IS_SELF_CALC_TOTALS);
    }
    
    public void setSuppressionState(int edge, int suppress) throws ArrayIndexOutOfBoundsException
    {
        _getQueryState().getPropertySupport().setSuppressionState(edge, suppress);
    }

    /**
     * Retrieves the suppression state (none, NA, zero, or both NA and zero) for
     * the column edge of this <code>Query</code> object.
     *
     * @return The current suppression state for the column edge of the query.
     *         Valid values are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public int getSuppressColumns()
    {
        return _getQueryState().getPropertySupport().getSuppressColumns();
    }


    public int getSuppressionState(int edge) throws ArrayIndexOutOfBoundsException
    {
        return _getQueryState().getPropertySupport().getSuppressionState(edge);
    }

    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero)
     * to use for this <code>Query</code> when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid values are in
     *                 <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public void setSuppressionState(int[] suppress)
    {
        _getQueryState().getPropertySupport().setSuppressionState(suppress);
    }

    /**
     * Retrieves the suppression state (none, NA, zero, or both NA and zero) for
     * this <code>Query</code> object.
     *
     * @return The current setting of the SuppressionState property for
     *         this <code>Query</code> object. Valid values are in
     *         <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public int[] getSuppressionState()
    {
        return _getQueryState().getPropertySupport().getSuppressionState();
    }

    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero)
     * on the column edge of the query when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid constants are in
     *                 <code>oracle.dss.util.DataDirector</code>
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public void setSuppressColumns(int suppress)
    {
        _getQueryState().getPropertySupport().setSuppressColumns(suppress);
    }
    
    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero) on
     * the row edge of a query when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid constants are in
     *                 <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public void setSuppressRows(int suppress)
    {
        _getQueryState().getPropertySupport().setSuppressRows(suppress);
    }

    /**
     * Retrieves the suppression state (none, NA, zero, or both NA and zero) for
     * the row edge of this <code>Query</code> object.
     *
     * @return The current suppression state for the row edge of the query.
     *         Valid constants are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
    public int getSuppressRows()
    {
        return _getQueryState().getPropertySupport().getSuppressRows();
    }

    /**
     * Specifies the suppression (none, NA, zero, or both NA and zero) on the
     * page edge of a query when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid constants are in
     *                 <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
/*    public void setSuppressPages(int suppress)
    {
        _getQueryState().getPropertySupport().setSuppressPages(suppress);
    }*/

   public void setProperty(String property, Object value) throws Exception
   {
        _getQueryState().getPropertySupport().setProperty(property, value);
   }

   public Object getProperty(String property)
   {
        return _getQueryState().getPropertySupport().getProperty(property);
   }

   /**
    * @hidden
    */
   public void setProperties(Hashtable properties)
   {
        _getQueryState().getPropertySupport().setProperties(properties);
   }
   
    /**
     * Retrieves the suppression state (none, NA, zero, or both NA and zero) for
     * the page edge of this <code>Query</code> object.
     *
     * @return The current suppression state for the page edge of the query.
     *         Valid constants are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * @status Documented
     */
/*    public int getSuppressPages()
    {
        return _getQueryState().getPropertySupport().getSuppressPages();
    }
  */  
    /**
     * Specifies the name of this data source.
     *
     * @param n The name of this data source.
     *
     * @status Documented
     */
    public void setName(String n) {
        //nameSet = true;
        m_name = n;
    }
    
    /**
     * Retrieves the name of this data source.
     *
     * @return The name of this data source.
     *
     * @status Documented
     */
    public String getName() {
        if (m_name == null)
        {
            return "Query"+getID();
        }
        return m_name;
    }

    /**
     * @hidden
     * Returns the map that determines the allowable set of <code>DataMap</code>
     * values for this query for all clients of this <code>Query</code>.
     *
     * @return The current set of supported map values.
     *
     * @status New
     */
    public DataMap getSupportedDataMap()
    {
        return (DataMap)_getQueryState().getMapSupport().getSupportedDataMap().clone();
    }
    
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    protected Selection getSelectionForEdgeLayer(int edge, int layer, String badEdgeMsg, String badLayerMsg) throws IllegalArgException
    {
        String[][] layout = getLayout();
        if (layout == null || edge >= layout.length)
        {
            throw new IllegalArgException(badEdgeMsg, 1, new Integer(edge));
        }
        if (layer >= layout[edge].length)
        {
            throw new IllegalArgException(badLayerMsg, 2, new Integer(layer));
        }

        // We need to grab the old selection
        return findSelection(layout[edge][layer]);
    }
*/
    ////////////////////////////
    //
    // Interface implementation
    //
    ////////////////////////////
    /**
     * Returns a <code>DataDirector</code> that manipulates the
     * <code>Query</code> in a cube-like or multidimensional way.
     * Used for OLAP views.
     *
     * @return An implementation of a <code>CubeDataDirector</code> interface.
     *
     * @see oracle.dss.util.CubeDataDirector
     *
     * @status Documented
     */
    public CubeDataDirector createCubeDataDirector()
    {
        // Create a new data director and return it
        CubeDataDirector dd = new CubeDataDirectorImpl(this, getCubeDataDirectorFromImpl());
        // Put it in the list
        if (m_dataDirectors == null)
            m_dataDirectors = new Vector();
            
        m_dataDirectors.addElement(dd);
        return dd;
    }
    
    public DataDirector createDataDirector()
    {
        return createCubeDataDirector();
    }
    
    /**
     * @hidden
     */
    protected abstract Delegate getCubeDataDirectorFromImpl();

    /**
     * @hidden
     */
    protected abstract Delegate getRelationalDataDirectorFromImpl();
    
    /**
     * Returns a <code>DataDirector</code> that manipulates the
     * <code>Query</code> in a relational way. Used for relational views.
     *
     * @return An implementation of a <code>RelationalDataDirector</code>
     *         interface.
     *
     * @see oracle.dss.util.RelationalDataDirector
     *
     * @status Documented
     */
    public RelationalDataDirector createRelationalDataDirector()
    {
        // Error if requested from a non tabular query
        Object obj = getProperty(QueryConstants.PROPERTY_TABULAR_QUERY);
        if (obj instanceof Boolean)
        {
            if (((Boolean)obj).booleanValue())
            {
                RelationalDataDirector dd = new RelationalDataDirectorImpl(this, getRelationalDataDirectorFromImpl());
                // Put it in the list
                if (m_dataDirectors == null)
                    m_dataDirectors = new Vector();
                    
                m_dataDirectors.addElement(dd);
                return dd;
            }
        }
        // If this property isn't set, it's an error
        throw new UnsupportedOperationException(getResourceString("Illegal DataDirector type requested."));
    }


    protected DataDirector[] getDataDirectors()
    {
        Object[] dds = null;
        Vector listenerDirectors = (Vector)m_listeners.getDataDirectors().clone();
        if (m_dataDirectors != null)
            listenerDirectors.addAll(m_dataDirectors);
        dds = listenerDirectors.toArray(new DataDirector[]{});
        
        return (DataDirector[])dds;
    }
    
    protected void updateDataDirectors()
    {
        DataDirector[] dds = getDataDirectors();
        
        if (dds == null)
            return;
            
        for (int i = 0; i < dds.length; i++)
        {
            if (dds[i] instanceof DataDirectorImpl)
            {
                ((DataDirectorImpl)dds[i]).setDelegate(this);
            }
        }
    }
    
    /**
     * Creates and returns an object that implements the
     * <code>LayoutAccess</code> interface.
     * This object can make use of the <code>LayoutContext</code> object, which
     * is also implemented by this <code>Query</code>, for state and
     * layout manipulation services.
     *
     * @return A new implementation of the <code>LayoutAccess</code> interface.
     *
     * @status Documented
     */
    public LayoutAccess createLayoutAccess()
    {
        return createCubeLayoutAccess();
    }

    /**
     * Return true if query contains no non-dimensional items
     * 
     * @return true if query is completely dimensional; false if not or if not set up yet
     */
    public boolean isDimensional()
    {
        QueryState qs = _getQueryState();
        if (qs == null)
            return false;
            
        String[] measures = qs.getMeasures();
        if (measures != null)
        {
            try
            {
                for (int i = 0; i < measures.length; i++)
                    if (!(getMDObject(MM.UNIQUE_ID, measures[i], MM.OBJECT) instanceof MDMeasure))
                        return false;
            }
            catch (MetadataManagerException e)
            {                
            }
        }
        
        // Make sure all the layout IDs are dimensions
        String[][] layout = getLayout();
        if (layout != null)
        {
            for (int e = 0; e < layout.length; e++)
            {
                if (layout[e] != null)
                {
                    for (int l = 0; l < layout[e].length; l++)
                        try
                        {
                            if (!(getMDObject(MM.UNIQUE_ID, layout[e][l], MM.OBJECT) instanceof MDDimension))
                                return false;
                        }
                        catch (MetadataManagerException ex)
                        {                            
                        }
                }
            }
        }
        return true;
    }
    
    /**
     * Return the current MetadataManager data source type
     * @return current data source type used to set up this query
     */
    public String getCurrentDataSourceType()
    {
        if (m_currentDataSource != null)
            m_currentDataSource.getDatasourceType();
        
        return null;
    }
    
    /**
     * Return the current MetadataManager data source 
     * @return current data source used to set up this query
     */
    public Connection getCurrentDataSource()
    {
        return m_currentDataSource;
    }
    
    public void removeItems(String[] items) throws QueryException
    {        
        try
        {
            removeCubeMeasures(items);
        }
        catch (MetadataManagerException e)
        {
            throw new QueryException(e.getMessage(), e);
        }
    }
    
    public void refresh(int type) throws QueryException
    {        
    }
    
    public RecoveryInfo recover(boolean fix, boolean nodata, Object specification) throws QueryException
    {        
        return null;
    }

    // blm - Selection code moved to dvt-olap    
/*    public Selection getDefaultSelection(String dimension) throws QueryException
    {
        return null;
    }*/

/*    public String getQuerySQL(int edge) throws QueryException
    {
        return null;
    }*/
    

    public void setCalcDefinitions(Object[] definitions) throws QueryException
    {        
    }

    public Object[] getCalcDefinitions()
    {
        return null;
    }

    public void setCurrentPages(QDR[] pages) throws QueryException
    {        
    }

    public QDR[] getCurrentPages()
    {    
        return null;
    }
    

    /**
     * @hidden
     */
/*    protected void updateAccessOperationQueue() throws Throwable
    {
        if (m_accessOperationQueue != null)
        {
            if (!anyApplySelectionsInQueue(m_accessOperationQueue))
            {
                transferQDROverrides();
            }
            m_accessOperationQueue.setAutoUpdate(true);
        }
        m_accessOperationQueue = null;
    }*/
    
    /**
     * @hidden
     * Return true if there are any apply selection operations in the queue: this means
     * we shouldn't transfer writeback overrides on query/layout access changes
     */
    protected boolean anyApplySelectionsInQueue(BaseOperationQueue queue)
    {
        Vector ops = queue.getOperations();
        Enumeration opsEnum = ops.elements();
        while (opsEnum.hasMoreElements())
        {
            Operation op = (Operation)opsEnum.nextElement();
            if (op != null)
            {
                if (op.getName().equals("initCubeQuery") || op.getName().equals("applySelections"))
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * @hidden
     * Throw the appropriate exception from an API call
     */
    protected void exceptionThrower(Throwable e) throws QueryException, MetadataManagerException
    {
        if (e instanceof QueryException)
            throw (QueryException)e;
        if (e instanceof MetadataManagerException)
            throw (MetadataManagerException)e;
        else
            throw new QueryException(e.getMessage(), e);
    }
    
    /**
     * @hidden
     * Transfer all writeback override qdrs in all cursors
     */
/*    protected void transferQDROverrides()
    {
        // Do regular cursors
        if (m_cubeCursors != null) {
            Enumeration cursors = m_cubeCursors.elements();
            while (cursors.hasMoreElements()) {
                ((CubeCursor)cursors.nextElement()).saveOverrides();
            }
        }
        if (m_ddlCursors != null) {
            // do view cursors
            Enumeration cursors = m_ddlCursors.elements();
            while (cursors.hasMoreElements()) {
                ((CubeCursor)cursors.nextElement()).saveOverrides();
            }
        }        
    }*/
    
    
    /**
     * @hidden
     */
    public MapSupport getMapSupport() {
        return _getQueryState().getMapSupport();
    }
    
    /**
     * @hidden
     */
    public PropertySupport getPropertySupport() {
        return _getQueryState().getPropertySupport();
    }

    /**
     * Controls actual cursor evaluation. The default setting for the
     * EvaluateCursor property is <code>true</code>. If this setting is changed
     * to <code>false</code>, then the clone(boolean) method bypasses cursor
     * evaluation when copying a <code>Query</code>.
     *
     * @param evalCursor Indicates whether cursors should be evaluated for a
     *                   <code>Query</code>.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void setEvaluateCursor(boolean evalCursor) throws QueryException, MetadataManagerException
    {
        _getQueryState().getPropertySupport().setEvaluateCursor(evalCursor);
    }

    /**
     * Indicates whether cursor evaluation should be performed for a
     * <code>Query</code>. If the EvaluateCursor property is set to
     * <code>false</code> before the clone (boolean) method is called,
     * then a newly cloned <code>Query</code> will not have any data or
     * metadata values in its cursors. The cursors will contain only basic
     * edge, layer level wireframe information (such as the dimensions and
     * where they are located in the layout).
     *
     * @return <code>true</code> if cursor evaluation should be performed;
     *         <code>false</code> if cursor evaluation should be bypassed.
     *
     * @status Documented
     */
    public boolean isEvaluateCursor()
    {
        return _getQueryState().getPropertySupport().isEvaluateCursor();
    }
    
    /** @hidden
     * Release any old main query cursor
     */
    public void release() {        
        //releaseCurList(m_oldCursors);
        //releaseCurList(m_oldDDLCursors);
        //m_oldCursors = null;
        //m_oldDDLCursors = null;                
    }
    
    /**
     * Retrieves a <code>DataMap</code> object that represents all data types
     * that have been requested by all current clients of this
     * <code>Query</code>.
     *
     * @return The <code>DataMap</code> that contains all the desired
     *         data map types.
     *
     * @status Documented
     */
    public DataMap getDataMap() {
        return _getQueryState().getMapSupport().getDataMap();
    }
    
    /**
     * Retrieves a <code>MetadataMap</code> object that represents all
     * metadata map types that have been requested by all current clients
     * of this <code>Query</code> for the specified dimension.
     *
     * @param dimension The dimension for which to return the map;
     *                  <code>null</code> if default.
     *
     * @return The <code>MetadataMap</code> object that contains all desired
     *         metadata map types.
     *
     * @status Documented
     */
    public MetadataMap getMetadataMap(String dimension)
    {
        try
        {
            return _getQueryState().getMapSupport().getMetadataMap(dimension, isTimeDimension(dimension));
        }
        catch (MetadataManagerException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    /**
     * @hidden
     */
    public boolean isTimeDimension(String dimension) throws MetadataManagerException
    {
        if (dimension != null)
        {
            MDDimension dim = (MDDimension)getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
            if (dim != null && dim.isTimeDimension())
            {
                return true;
            }
        }
        return false;
    }


    /**
     * Retrieves a <code>MetadataMap</code> object that represents all
     * metadata map types that have been requested by all current clients
     * of this <code>Query</code> for the specified edge.
     *
     * @param edge  A constant that represents the edge for which to return
     *              the <code>MetadataMap</code>. The valid constants
     *              (<code>COLUMN_EDGE</code>, <code>PAGE_EDGE</code>,
     *              <code>ROW_EDGE</code>) are found in
     *              <code>oracle.dss.util.DataDirector</code>.
     *
     * @return The MetadataMap that contains all metadata map types for the
     *         specified edge.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public MetadataMap getMetadataMap(int edge) {
        return _getQueryState().getMapSupport().getMetadataMap(edge);
    }


   // Return a TotalEvent containing TotalSteps that will change due to a pivot


    /**
     * @hidden
     */
//    public abstract String getQuerySQL(int edge, long type) throws QueryException;

    /**
     * @hidden
     */
    protected abstract boolean isDataAvailable();
 
    
    /**
     * @hidden
     */
/*    public void setCursor(CubeCursor cursor) throws QueryException
        {        
        // Rebuild the list of cursors, cloning one for each listener
        // Do the standard data source listeners first
        m_dumped = false;
        m_oldCursors = m_cubeCursors;
        m_cubeCursors = new Vector();

        updateListenerCursors(cursor, m_listeners.listeners, m_cubeCursors, m_oldCursors);

        // Do the data director listeners next
        m_oldDDLCursors = m_ddlCursors;
        m_ddlCursors = new Vector();
        if (m_dataDirectors != null)
        {
            updateListenerCursors(cursor, m_dataDirectors, m_ddlCursors, m_oldDDLCursors);
        }
        m_mustClearDrillCaches = false;
    }

    private void updateListenerCursors(CubeCursor cursor, Vector listeners, Vector cubeCursors, Vector oldCubeCursors) throws QueryException
    {
        CubeCursor newCursor = null;
        CubeCursor oldCursor = null;
        try
        {
            if (cursor != null)
            {
                Hashtable drillCache = null;
                for (int i = 0; i < listeners.size(); i++) {
                    // Must push and pop cursors in source cube for copy (allows reuse of old cursor's cursor, if it
                    // exists
                    // Transfer the old cursor's cursors, if there is an old cursor, for reuse before copying
                    oldCursor = null;
                    if (oldCubeCursors != null && i < oldCubeCursors.size())
                    {
                        oldCursor = (CubeCursor)oldCubeCursors.elementAt(i);
                    }
                    newCursor = cursor.createNewCubeCursorFromOld(oldCursor);
                    cubeCursors.addElement(newCursor);
                    if (oldCursor != null)
                    {
                        if (m_mustClearDrillCaches)
                        {
                            oldCursor.emptyDrillStateCache();
                        }
                        Hashtable temp = newCursor.resetCarryOver(oldCursor);
                        // Hopefully, only one of these should update the cache and return it
                        // for the others
                        if (temp != null)
                        {
                            drillCache = temp;
                        }
                    }
                }
                if (drillCache != null)
                {
                    for (int i = 0; i < cubeCursors.size(); i++)
                    {
                        ((CubeCursor)cubeCursors.elementAt(i)).m_carryOver.setDrillStateCache(drillCache);
                    }
                }
            }
        }
        catch (Exception e) {
            throw new OLAPException(e.getMessage(), OLAPException.CREATE_CURSOR, e);
        }
    }
*/
    /**
     * @hidden
     */
    public void fireDataAvailable(DataAvailableEvent e) throws QueryException
    {
        if (m_dataDirectors == null)
        {
            return;
        }

        for (int index = 0; index < m_dataDirectors.size(); index++)
        {
/*            if (da == null)
                obj = getDDLCursor(index);
            else
                obj = da;*/
            DataDirectorImpl ddi = (DataDirectorImpl)m_dataDirectors.elementAt(index);
            if (ddi != null)            
                ddi.fireDataAvailable(e);
        }
    }


    
    /**
     * @hidden
     * Allow Directors to add their listeners to a common list
     */
    public void addDataDirector(DataDirector d)
    {
 		if (m_dataDirectors == null) 
        {
            m_dataDirectors = new Vector ();
        }
        if (m_dataDirectors.indexOf(d) == -1)
            m_dataDirectors.addElement(d);

   }
   
    /**
     * @hidden
     */
   protected boolean isViewDataAvailable()
   {
        return getMetadataManager() != null;
   }
   
    /**
     * @hidden
     */
    protected MetadataManagerServices getMM()
    {
        return (MetadataManagerServices)getMetadataManager();
    }
       
    /**
     * @hidden
     */
    public MDMeasure[] getMMMeasures() throws InvalidMetadataException
    {
        try
        {
            if (!MDCACHE)
            {
                return getMM().getMeasures();
            }
            StringBuffer key = new StringBuffer("MMMeasures");
            Object obj = m_mdObjectCache.get(key.toString());
            if (obj == null)
            {
                obj = getMM().getMeasures();
                m_mdObjectCache.put(key.toString(), obj);
                return (MDMeasure[])obj;
            }
            return (MDMeasure[])obj;
        }
        catch (MetadataManagerException mme)
        {
            throw new InvalidMetadataException(mme.getMessage(), (String)null, mme);
        }
    }
    
   /**
    * @hidden
    */
   public String getResourceString(String key)
   {
        return getQueryManager().getResourceString(key);
   }
   
   
   /**
    * @hidden 
    * Allow directors to remove their listeners from a common list
    */
    public void removeDataDirector(DataDirector d)
    {
        if (m_dataDirectors != null && m_dataDirectors.indexOf(d) > -1)
            m_dataDirectors.removeElement(d);
            
   }
   
  
    // javadoc from interface
    public String getIDFromName(String dimension, String hierarchy, String name)
    {
        if (hierarchy != null)
        {
            try
            {
                MDHierarchy hier = (MDHierarchy)getMetadataManager().getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
                MDLevel[] levels = hier.getLevels();
                if (levels != null)
                {
                    for (int i = 0; i < levels.length; i++)
                    {
                        if (levels[i].getName().equals(name) || levels[i].getUniqueID().equals(name))
                            return levels[i].getUniqueID();
                    }            
                }
            }
            catch (MetadataManagerException mme)
            {
                return null;
            }            
        }
        return null;
    }
  
    /**
     * @hidden
     * Return <code>true</code> if the given hierarchy has
     * levels, <code>false</code> if not
     */
  // blm - Selection code moved to dvt-olap
/*    public boolean hasLevels(String hierarchy) throws SelectionException
    {
        if (hierarchy == null || getQueryManager().isMetadataManagerNotAvailable())
        {
            return false;
        }
        try
        {
            MDHierarchy hier = (MDHierarchy)getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
            if (hier == null)
            {
                return false;
            }
            return hier.getLevels() != null && hier.getLevels().length > 0;
        }
        catch (MetadataManagerException e)
        {
            throw new SelectionException(e.getMessage(), e);
        }
    }
*/
    /**
     * @hidden
     * Return a level name given a dimension, hierarchy and level depth offset.
     *
     * @param dimension dimension for which to get the level name
     * @param hierarchy hierarchy within dimension for which to get the level name
     * @param levelDepth level depth offset within hierarchy at which to find name
     *
     * @return level name
     */
    public String getLevelNameForOffset(String dimension, String hierarchy, int levelDepth)
    {
        // Get the list of levels
        String[] levelNames = getLevelNames(dimension, hierarchy);

        if (levelNames != null && levelDepth >= 0 && levelDepth < levelNames.length)
        {
            return levelNames[levelDepth];
        }
        return null;
    }

    /**
     * @hidden
     * Return a level depth offset given a dimension, hierarchy, and level name.
     *
     * @param dimension dimension for which to get the level depth
     * @param hierarchy hierarchy within dimension for which to get the level depth
     * @param level level name within hierarchy for which to get the level depth
     *
     * @return level depth offset
     */
    public int getLevelOffsetForName(String dimension, String hierarchy, String level)
    {
        if (level == null)
            return -1;

        // Get the level names
        String[] levelNames = getLevelNames(dimension, hierarchy);
        if (levelNames == null)
            return -1;

        for (int i = 0; i < levelNames.length; i++)
        {
            if (level.equals(levelNames[i]))
                return i;
        }
        return -1;
    }

    /**
     * @hidden
     */
    protected String[] getLevelNames(String dimension, String hierarchy)
    {
        if (dimension == null || hierarchy == null)
            return null;

        // For now, can just look up hierarchy based on unique ID directly
        MDHierarchy hierObj = null;
        try
        {
            hierObj = (MDHierarchy)getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
        }
        catch (MetadataManagerException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (hierObj == null)
            return null;

        MDLevel[] levels = null;
        try
        {
            levels = hierObj.getLevels();
        }
        catch (MetadataManagerException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (levels == null)
            return null;

        String[] levelNames = new String[levels.length];
        for (int l = 0; l < levels.length; l++)
        {
            levelNames[l] = levels[l] != null ? levels[l].getName() : null;
        }
        return levelNames;
    }
   
    /**
     * @hidden
     * Returns the default hierarchy ID, if any
     */
     // blm - Selection code moved to dvt-olap
/*    public String getDefaultHierarchy(String dimension) throws SelectionException
    {
        if (dimension == null || getQueryManager().isMetadataManagerNotAvailable())
        {
            return null;
        }
        try
        {
            MDDimension dim = (MDDimension)getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
            if (dim == null)
            {
                return null;
            }
            MDHierarchy hier = dim.getDefaultHierarchy();
            if (hier != null)
                return hier.getUniqueID();
        }
        catch (MetadataManagerException e)
        {
            throw new SelectionException(e.getMessage(), e);
        }
        return null;
    }
  */ 
    
    /********** Persistable interface ********************/
    
    /**
     *  @hidden
     */
    public void setPersistableEnvironment(Hashtable env)
    {
        // Look for IDResolver
        if (env != null)
        {
            m_idResolver = (IDResolver)env.get(PersistableConstants.IDRESOLVER);
            m_converter = (GUIDConverter)env.get(PersistableConstants.CONVERTER);
        }
    }
    
    
    /**
     * @hidden
     * Retrieves the XML representation of the query.
     * 
     * @return <code>String</code> which represents the XML representaion
     *         of the query. 
     */
    public String getXMLAsString() throws BIPersistenceException
    {
        return getXMLAsString(null);
    }
        
     /**
      * @hidden
      */
    public String getXMLAsString(XMLContext context) throws BIPersistenceException
    {
        String _xml = null;
        try
        {
            XMLObjectWriter _xmlWriter = new XMLObjectWriter();
            if (context == null)
                context = new XMLContext();
            ObjectScope scope = context.getScope();
            
            if (scope == null)
                scope = new ObjectScope();
            
            if (m_converter != null)
            {
                scope.addObject(PersistableConstants.CONVERTER, m_converter);                
            }
            if (m_idResolver != null)
            {
                scope.addObject(PersistableConstants.IDRESOLVER, m_idResolver);
            }
            if (areWeMigrating())
            {
                scope.addObject(PersistableConstants.MIGRATION, m_migrationFlag);
            }
            scope.addObject(oracle.dss.util.parameters.ParameterManager.class.getName(), this);
            scope.addObject(oracle.dss.metadataManager.common.MetadataManagerServices.class.getName(), getMetadataManager());
            try
            {
                if (getMeasureDim() != null)
                    scope.addObject(PersistableConstants.MEASURE_DIM_NAME, getMeasureDim());
            }
            catch (InvalidMetadataException e)
            {
                if (!areWeMigrating() && !getQueryManager().isMetadataManagerNotAvailable())
                {
                    throw e;
                }
            }
            
            context.setScope(scope);
            _xmlWriter.writeObjectNode((ObjectNode)getXML(context));
            _xml = _xmlWriter.toString();
        }
        catch (oracle.dss.util.xml.BIIOException ioe)
        {
            throw new BIPersistenceException(ioe.getMessage(), (Exception)ioe.getPreviousException());
        }
        catch (QueryException ex)
        {
            throw new BIPersistenceException(ex.getMessage(), ex);
        }
        catch (QueryRuntimeException e)
        {
            throw new BIPersistenceException(e.getMessage(), (Exception)e.getPreviousException());
        }
        return _xml;
    }

    /**
     * @hidden
     */
    public void setXML(XMLContext context, Object node)
    {
/*        try
        {
        ObjectNode root = (ObjectNode)node;
        // Can't restore
        //setID(root.getPropertyValueAsInteger("ID"));
//        setDebugMode(root.getPropertyValueAsBoolean("DebugMode"));
        }
        catch (NoSuchPropertyException e) {
            throw new oracle.dss.dataSource.common.NoSuchPropertyException(getResourceString("Could not find property"), e.getMessage(), e);
        }*/
    }    
    
    /**
     *  @hidden
     */
    public boolean areWeMigrating()
    {
        return m_migrationFlag != null;
    }
    
    
    /**
     * @hidden
     * Set the XML representation of the query.
     * 
     * @param xml a <code>String</code> value that represents the 
     *        xml string that we wish to initialize query with.
     */
    public boolean setXMLAsString(String xml) throws BIPersistenceException
        {
        m_persistentStateSet = true;
       try
        {
            XMLObjectReader _xmlReader = new XMLObjectReader(xml);
            
            if (m_validateXML)
            {
                try
                {
                    _xmlReader.setValidationMode(true);
                    _xmlReader.setDTD("/oracle/dss/dataSource/common/Query.dtd", "Query");
                }
                catch (BIParseException bipe)
                {
                    //If there is an exception here, the DTD is incorrect
                    getErrorHandler().log(bipe.toString(), getClass().getName(), "setXMLAsString");
                    getErrorHandler().log("Syntax error in DTD in line number " + bipe.getLineNumber() 
                                                        + ", column number " + bipe.getColumnNumber(), getClass().getName(), "setXMLAsString");
                    throw bipe;                                                                                                                
                }
                catch (oracle.dss.util.xml.BIXMLException xmle)
                {
                    throw new BIPersistenceException(xmle.getMessage(), (Exception)xmle.getPreviousException());
                }
            }
            ObjectNode _node = _xmlReader.readObjectNode();
            XMLContext context = new XMLContext();            
            ObjectScope scope = new ObjectScope();
            if (m_converter != null)
            {
                scope.addObject(PersistableConstants.CONVERTER, m_converter);                
            }
            if (areWeMigrating())
            {
                scope.addObject(PersistableConstants.MIGRATION, m_migrationFlag);
            }            
            if (m_idResolver != null)
            {
                scope.addObject(PersistableConstants.IDRESOLVER, m_idResolver);
            }
            try
            {
                if (getMeasureDim() != null)
                    scope.addObject(PersistableConstants.MEASURE_DIM_NAME, getMeasureDim());
            }
            catch (InvalidMetadataException e)
            {
                // Must mean MM not set: if migrating, OK
                if (!areWeMigrating() && !getQueryManager().isMetadataManagerNotAvailable())
                {
                    throw e;
                }
                else
                {
                    //scope.addObject(PersistableConstants.MEASURE_DIM_NAME, MIGRATION_MEASDIM);
                }
            }
            context.setScope(scope);
            setXML(context, _node);
            return true;
        }
        catch (BIParseException bipe)
        {
            //If there is an exception here, the XML is incorrect
            getErrorHandler().log(bipe.toString(), getClass().getName(), "setXMLAsString");
            getErrorHandler().log("Syntax error in XML in line number " + bipe.getLineNumber()
                                                + ", column number " + bipe.getColumnNumber(), getClass().getName(), "setXMLAsString");
            getErrorHandler().log(xml, getClass().getName(), "setXMLAsString");
            getErrorHandler().log("Error starts at:", getClass().getName(), "setXMLAsString");
            getErrorHandler().log(xml.substring(bipe.getColumnNumber()), getClass().getName(), "setXMLAsString");
        }
        catch (oracle.dss.util.xml.BIXMLException xmle2)
        {
            throw new BIPersistenceException(xmle2.getMessage(), (Exception)xmle2.getPreviousException());
        }
        catch (QueryException ex)
        {
            throw new BIPersistenceException(ex.getMessage(), ex);
        }
        catch (QueryRuntimeException e)
        {
            throw new BIPersistenceException(e.getMessage(), e);
        }
        return false;
    }

    /**
     * @hidden
     * Retrieves the components (e.g. selections) associated 
     * with the query.
     * 
     * @return <code>AggregateInfo[]</code> which represents the components
     *         associated with the query. 
     */
    public AggregateInfo[] getPersistableComponents()
        {
            return null;
        }

    /**
     * @hidden
     * Specifies the components (e.g. selections) associated 
     * with the query.
     *
     * @param aggregates a <code>AggregateInfo[]</code> value that represents the 
     *        components to assign to the query.
     */
    public void setPersistableComponents(AggregateInfo[] infos)
        {
        }

    /**
     * @hidden
     */
    public PersistableAttributes getPersistableAttributes(PersistableAttributes oldAttrs)
        {
        if (m_attrs == null)
            {
            m_attrs = new PersistableAttributes();
            }
            
        if (oldAttrs != null) 
            {
            m_attrs.merge(oldAttrs);
            }
        
        m_attrs.setObjectType(PersistableConstants.QUERY);

        return m_attrs;
        }

    /**
     * @hidden
     */
    public void setPersistableAttributes(PersistableAttributes attrs)
        {
        this.m_attrs = attrs;
        }

    /**
     * @hidden
     */
    public String getTagName()
    {
        return XMLName;
    }

    /**
     * @hidden
     */
    public Object getXML(XMLContext con)
    {
        ObjectNode root = new ObjectNode(PersistableConstants.XMLNS + ":" + XMLName);
        root.addProperty("name", XMLName.toLowerCase());
        root.addProperty("xmlns:"+PersistableConstants.XMLNS, PersistableConstants.XMLNS_URL);
        //root.addProperty("Name", getName());
        //root.addProperty("ID", getID());
        root.addProperty("DebugMode", isDebugMode());
        return root;
    }
    
    /**
     * Specifies whether the <code>Query</code> validates XML against its DTD.
     *
     * @param validate <code>true</code> to have XML validated,
     *                 <code>false</code> to have the <code>Query</code>
     *                 apply the XML without testing for validity.
     *
     * @status Documented
     */
    public void setXMLValidated(boolean validate)
    {
        m_validateXML = validate;
    }
    
    /**
     * Indicates whether the <code>Query</code> validates XML against its DTD.
     *
     * @return <code>true</code> if the <code>Query</code> validates XML,
     *         <code>false</code> if the <code>Query</code> applies XML without
     *         validation.
     *
     * @status Documented
     */
    public boolean isXMLValidated()   
    {
        return m_validateXML;
    }
        
    /**
     * Clones this <code>Query</code> object.
     *
     * @return A newly-created copy of the <code>Query</code>.
     *
     * @throws CloneNotSupportedException If the clone cannot be created
     *
     * @status Documented
     */
    public Object clone() throws CloneNotSupportedException
    {
        return clone(_getQueryState().getPropertySupport().isEvaluateCursor());
    }
    
    /**
     * Clones this <code>Query</code> and provides the performance option
     * of bypassing cursor evaluation. If the EvaluateCursor property is set to
     * false, then the <code>Query</code> does not ask OLAPI to create a
     * cursor based on the user's API calls. The caller of this method still
     * gets the full set of events along with the "cursors" but these cursors
     * will not have any data or metadata values in them. The cursors will
     * contain only basic edge, layer level wireframe information (such as the
     * dimensions and where they are located in the layout).
     *
     * @param evaluateCursor <code>true</code> if this clone should have cursor
     *                       evaluation turned on (this is the default value);
     *                       <code>false</code> if this clone does not require
     *                       cursor evaluation.
     *
     * @return A newly-created copy of the <code>Query</code>.
     *
     * @throws CloneNotSupportedException   If a <code>Query</code>
     *                                      cannot be cloned.
     *
     * @see #isEvaluateCursor
     * @see #setEvaluateCursor
     *
     * @status Documented
     */
    public Object clone(boolean evaluateCursor) throws CloneNotSupportedException {
        try
        {
            Query query = _clone(evaluateCursor);
            //getQueryManager().addQuery(query);
            return query;
        }
        catch (Exception e)
        {
            throw new CloneNotSupportedException(e.getMessage());
        }
    }


    /**
     * @hidden
     * Retrieves an <code>OlapQDR</code> object that represents the value at the specified
     * row and column in the data area of the given DataAccess cursor.
     *
     * @param row    The row in the data cursor for which to return the <code>OlapQDR</code>.
     * @param column The column in the data cursor for which to return the <code>OlapQDR</code>. 
     * @param flags A constant that identifies whether to include page edge 
     *              information if the <code>OlapQDR</code> is not for the page edge. Valid
     *              constants are listed in the See Also section. 
     * @param dataAccess The cursor from which to generate the <code>OlapQDR</code>
     * 
     * @return    <code>OlapQDR</code> object that refers to the data at the 
     *            specified location. 
     * 
     * @throws  RowOutOfRangeException    If the <code>row</code> parameter is 
     *                                    not valid. 
     * @throws  ColumnOutOfRangeException If the <code>column</code> parameter
     *                                    is not valid. 
     * 
     * @see DataAccess#QDR_WITH_PAGE 
     * @see DataAccess#QDR_WITHOUT_PAGE
     *
     * @status New
     */
    /*public OlapQDR getValueOlapQDR(int row, int column, int flags, DataAccess dataAccess) throws RowOutOfRangeException, ColumnOutOfRangeException
    {
        if (dataAccess instanceof DataAccessLong)
            return (OlapQDR)CursorUtils.getValueQDRImpl(this, _getQueryState(), getQueryManager(), (DataAccessLong)dataAccess, (long)row, (long)column, flags, true);
        return null;
    }*/

    /**
     * @hidden
     * Retrieves an <code>OlapQDR</code> object that represents the data value at the specified
     * slice on the edge (that is, across all relevant logical layers of the
     * slice).
     *
     * @param edge  A constant that represents the edge of in which to find the
     *              slice.
     *              The constants end with <code>_EDGE</code> in
     *              <code>DataDirector</code>.
     * @param slice An absolute index (zero-based) that indicates the location
     *              of the slice along the specified edge.
     * @param flags A constant that identifies whether to include page edge
     *      *              information if the <code>OlapQDR</code> is not for the page edge. Valid
     *              constants are listed in the See Also section. 
     * @param dataAccess The cursor from which to generate the <code>OlapQDR</code>
     * 
     * @return    <code>OlapQDR</code> object that refers to the data at the 
     *            specified location. 
     * 
     * @throws EdgeOutOfRangeException  If the <code>edge</code> parameter
     *                                      is not valid. 
     * @throws SliceOutOfRangeException If the <code>slice</code> parameter 
     *                                      is not valid.
     * 
     * @see DataAccess#QDR_WITH_PAGE 
     * @see DataAccess#QDR_WITHOUT_PAGE
     * @see DataDirector#COLUMN_EDGE
     * @see DataDirector#PAGE_EDGE
     * @see DataDirector#ROW_EDGE 
     *
     * @status New
     */
    /*public OlapQDR getSliceOlapQDR(int edge, int slice, int flags, DataAccess dataAccess) throws EdgeOutOfRangeException, SliceOutOfRangeException
    {
        if (dataAccess instanceof DataAccessLong)
            return (OlapQDR)CursorUtils.getSliceQDRImpl(this, _getQueryState(), getQueryManager(), (DataAccessLong)dataAccess, ((DataAccessLong)dataAccess).getEdgeCurrentSliceLong(DataDirector.PAGE_EDGE), edge, (long)slice, flags, true);
        return null;
    }*/

    /**
     * @hidden
     * Retrieves an <code>OlapQDR</code> object that represents the data value for the member at
     * the specified edge, layer, and slice.
     *
     * @param edge  A constant that represents the edge of interest.
     *              The constants end with <code>_EDGE</code> in
     *              <code>DataDirector</code>.
     * @param layer A zero-based index that represents the physical layer of
     *              the member for which the <code>OlapQDR</code> object is requested.
     * @param slice An absolute index (zero-based) that indicates the location,
     *              along the specified edge, of a slice that belongs to the
     *              member for which the <code>OlapQDR</code> object is requested.
     * @param flags A constant that identifies whether to include page edge
     *              information if the <code>OlapQDR</code> is not for the page edge. Valid
     *              constants are listed in the See Also section.
     * @param dataAccess The cursor from which to generate the <code>OlapQDR</code>
     *
     * @return    <code>QDR</code> object that refers to the data at the
     *            specified position.
     *
     * @throws EdgeOutOfRangeException  If <code>edge</code> is not valid.
     * @throws LayerOutOfRangeException If <code>layer</code> is not valid for
     *                                  the specified <code>edge</code>. 
     * @throws SliceOutOfRangeException If <code>slice</code> is not valid for 
     *                                  the specified <code>edge</code> and 
     *                                  <code>layer</code>.
     *
     * @see DataAccess#QDR_WITH_PAGE
     * @see DataAccess#QDR_WITHOUT_PAGE
     * @see DataDirector#COLUMN_EDGE
     * @see DataDirector#PAGE_EDGE
     * @see DataDirector#ROW_EDGE
     *
     * @status New
     */
    /*public OlapQDR getMemberOlapQDR(int edge, int layer, int slice, int flags, DataAccess dataAccess) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException
    {
        if (dataAccess instanceof DataAccessLong)
            return (OlapQDR)CursorUtils.getMemberQDRImpl(this, _getQueryState(), getQueryManager(), (DataAccessLong)dataAccess, edge, layer, (long)slice, flags, true);
        return null;
    }*/

    /** 
     * @hidden
     * Retrieves an <code>OlapQDR</code> object that represents the specified member using
     * hierarchical addressing. 
     * 
     * @param edge        A constant that represents the edge in which to 
     *                    find the member. 
     *                    The constants end with <code>_EDGE</code> in 
     *                    <code>DataDirector</code>. 
     * @param hPos        An array of relative indices that are organized by 
     *                    logical layer. 
     *                    The indices start at layer 0 and extend at least 
     *                    through the layer that is specified in 
     *                    <code>memberLayer</code>. 
     * @param memberLayer The zero-based index into the <code>hpos</code> array 
     *                    that indicates the layer in which to find the member. 
     * @param flags A constant that identifies whether to include page edge 
     *              information if the <code>OlapQDR</code> is not for the page edge. Valid
     *              constants are listed in the See Also section. 
     * @param dataAccess The cursor from which to generate the <code>OlapQDR</code> 
     * 
     * @return    <code>OlapQDR</code> object that refers to the data at the 
     *            specified <code>hpos</code> and <code>memberlayer</code> 
     *            within the <code>hpos</code>. 
     * 
     * @throws EdgeOutOfRangeException  If <code>edge</code> is not valid. 
     * @throws LayerOutOfRangeException If <code>memberLayer</code> is not 
     *                                  valid for the specified edge.
     * @throws SliceOutOfRangeException If the values in the <code>hpos</code>
     *                                  array are not valid relative indices in
     *                                  the specified hierarchy. 
     * 
     * @see DataAccess#QDR_WITH_PAGE 
     * @see DataAccess#QDR_WITHOUT_PAGE 
     * @see DataDirector#COLUMN_EDGE 
     * @see DataDirector#PAGE_EDGE 
     * @see DataDirector#ROW_EDGE 
     *
     * @status New
     */
/*    public OlapQDR getMemberOlapQDR(int edge, int[] hPos, int memberLayer, int flags, DataAccess dataAccess) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException
    {
        if (dataAccess instanceof DataAccessLong)
            return (OlapQDR)CursorUtils.getMemberQDRImpl(this, _getQueryState(), getQueryManager(), (DataAccessLong)dataAccess, edge, CursorUtils.getLongFromIntArray(hPos), memberLayer, flags, true);
        return null;
    }*/

    /**
     * @hidden
     * Retrieves the <code>OlapQDR</code> object that represents the specified logical layer.
     *
     * @param edge  A constant that represents the edge in which to find the
     *              logical layer.
     *              The constants end with <code>_EDGE</code> in
     *              <code>DataDirector</code>.
     * @param layer The zero-based index of the logical layer for which to
     *              return the <code>OlapQDR</code>.
     * @param flags A constant that identifies whether to include page edge
     *              information if the <code>OlapQDR</code> is not for the page edge. Valid
     *              constants are listed in the See Also section.
     * @param dataAccess The cursor from which to generate the <code>OlapQDR</code>
     *
     * @return    <code>OlapQDR</code> object that refers to the data in the
     *            specified layer. 
     * 
     * @throws EdgeOutOfRangeException  If <code>edge</code> is not valid. 
     * @throws LayerOutOfRangeException If the logical <code>layer</code> is 
     *                                  not valid for the specified 
     *                                  <code>edge</code>. 
     * 
     * @see DataAccess#QDR_WITH_PAGE 
     * @see DataAccess#QDR_WITHOUT_PAGE 
     * @see DataDirector#COLUMN_EDGE 
     * @see DataDirector#PAGE_EDGE 
     * @see DataDirector#ROW_EDGE
     *
     * @status New
     */
/*    public OlapQDR getLayerOlapQDR(int edge, int layer, int flags, DataAccess dataAccess) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {
        if (dataAccess instanceof DataAccessLong)
            return (OlapQDR)CursorUtils.getLayerQDRImpl(this, _getQueryState(), getQueryManager(), (DataAccessLong)dataAccess, edge, layer, flags, true);
        return null;
    }*/

    /**
     * @hidden
     */
/*    public Vector getMemberLevel(String hierarchy)
    {
        return null;
    }*/

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public void setMemberLevel(String hierarchy, MemberStep step)
    {
    }
*/
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public Vector convertLevels(String hierarchy, Vector levels)
    {
        return null;
    }
*/
    /**
     * @hidden
     */
    public abstract void eventHelper(QueryEvent e);
    

    // javadoc from interface
    public void fireEvents() throws QueryException
    {
        if (m_currQueue == null)
            return;
            
        // We must blank out any initialization knowledge here, because the object will survive
        // intact in local mode
        EventObject[] list = ((OperationQueue)m_currQueue).getEventList();
        
        try
        {
           getQueryManager().processEventList(list, this);
        }
        catch (QueryRuntimeException qre)
        {
            throw new QueryException(qre.getPreviousException().getMessage(), qre.getPreviousException());
        }
        m_currQueue = null;
    }
        

    
    /**
     * @hidden
     * Throw the appropriate exception from an API call
     */
    public void exceptionThrower2(Throwable e) throws QueryException
    {
        if (e instanceof QueryException)
            throw (QueryException)e;
        else
            throw new QueryException(e.getMessage(), e);
    }
    
    /**
     * @hidden
     * 
     */
    public void addToUndo(BaseOperationQueue queue, Operation op, QueryState before, QueryState after)
    {
        m_beforeState = null;
        QueryEdit edit = getStateAsEdit(op, before, after);
        queue.eventHelper(new UndoAvailableEvent(this, edit));
        //undoMgr.addEdit(edit);
    }
     
    /**
     * @hidden
     */
    protected QueryEdit getStateAsEdit(Operation op, QueryState before, QueryState after)
    {
        return new QueryEdit(this, op, before, after);
    }

   /**
     * @hidden
     * Copy this query's state into the target
     *
     * @param dsc query into which to copy this Query's state
     * @status hidden
     */
    public void copyQueryInto(Query dsc, boolean evaluateCursor) throws CloneNotSupportedException, QueryException, MetadataManagerException
    {
        // Copy properties
        dsc.m_queryState = (QueryState)_getQueryState().clone(dsc);
        if (evaluateCursor != dsc._getQueryState().getPropertySupport().isEvaluateCursor())
        {
            dsc._getQueryState().getPropertySupport().setEvaluateCursor(evaluateCursor);
        }
        // Copy debug mode
        dsc.m_debugMode = m_debugMode;
        // Copy Default query mode
        dsc.m_defaultQuery = m_defaultQuery;
        dsc.m_persistentStateSet = m_persistentStateSet;
        dsc.m_queryManager = m_queryManager;
        dsc.m_defaultQuery = m_defaultQuery;
        if (m_attrs != null)
        {
            dsc.m_attrs = (PersistableAttributes)m_attrs.clone();
        }
        
        //if (m_foundationCursor != null) {
            //dsc.m_foundationCursor = (CubeCursor)m_foundationCursor.clone();
        //}
        //if (m_cubeCursors != null) {
            //dsc.m_cubeCursors = Utility.cloneVector(m_cubeCursors);
        //}
        //if (m_ddlCursors != null) {
            //dsc.m_ddlCursors = Utility.cloneVector(m_ddlCursors);
        //}
 //       dsc.m_id = m_id;
    }
    
    // Private cloner that doesn't insert itself into the manager
    /**
     * @hidden
     */
    protected Query _clone(boolean evaluateCursor) throws CloneNotSupportedException, QueryException, MetadataManagerException
    {
        Query dsc = null;
        try {
            dsc = (Query)getClass().newInstance();
        }
        catch (Exception e) {
            throw new CloneNotSupportedException(getResourceString("Could not create new instance of QueryManager or subclass when cloning"));
        }
        copyQueryInto(dsc, evaluateCursor);
        return dsc;
    }

    /**
     * @hidden
     * Indicates that the parent QueryManager's Database property has been set
     */
    //public abstract void _databaseSet(boolean available) throws Throwable;

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public abstract void replSel(String dimension, Selection sel) throws Exception;*/

    /**
     * @hidden
     */
    protected abstract void _refresh(BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException;

    /**
     * @hidden
     */
    protected abstract void _initCubeQuery(BaseOperationQueue queue, String[] measures, String[] items, String[][] dimensions) throws QueryException, IllegalArgumentException, MetadataManagerException;

    /**
     * @hidden
     */
    protected abstract void _setDataFilters(BaseOperationQueue queue, BaseDataFilter[] filters) throws QueryException;


    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    protected abstract void _applySelections(BaseOperationQueue queue, Selection[] selections, boolean processCompletely) throws QueryException, MetadataManagerException;*/

    /**
     * @hidden
     */
    protected abstract Boolean _layout(BaseOperationQueue queue, String[][] dimensions, boolean processCompletely) throws QueryException, MetadataManagerException;

    /**
     * Return the current metadata manager set on this query
     *
     * @status Documented
     */
    public abstract MetadataManagerServices getMetadataManager();
    
    /**
     * @hidden
     */
    public MDDimension getMeasureDimObj() throws InvalidMetadataException
    {
        if (!MDCACHE)
        {
            try
            {
                return getMetadataManager() == null ? null : getMetadataManager().getMeasureDimension("");
            }
            catch (Exception e)
            {
                throw new InvalidMetadataException(getResourceString("Metadata Manager cannot return the measure dimension"), MEASUREDIM, e);
            }
        }
        MDDimension dim = (MDDimension)m_mdObjectCache.get(MEASUREDIM);
        if (dim == null)
        {
            try
            {
                dim = getMetadataManager().getMeasureDimension("");
            }
            catch (Exception e)
            {
                if (isOLAP())
                    throw new InvalidMetadataException(getResourceString("Metadata Manager cannot return the measure dimension"), MEASUREDIM, e);
                else
                {
                    /*MDDimension dimObj = new MDDimension();
                    dimObj.setDriverType(MM.PERSISTENCE);
                    dimObj.setUniqueID(MM.PERSISTENCE, "DATAPOINT");
                    return dimObj;*/
                    return null;
                }
            }
            if (dim == null)
            {
                if (isOLAP())
                    throw new InvalidMetadataException(getResourceString("Metadata Manager cannot return the measure dimension"), MEASUREDIM, null);
                else
                {
                    /*MDDimension dimObj = new MDDimension();
                    dimObj.setDriverType(MM.PERSISTENCE);
                    dimObj.setUniqueID(MM.PERSISTENCE, "DATAPOINT");
                    return dimObj;*/
                    return null;
                }
            }
            m_mdObjectCache.put(MEASUREDIM, dim);
            return dim;
        }
        return dim;
    }
    
    /**
     * @hidden
     * Return the measure dimension
     */
    public String getMeasureDim() throws InvalidMetadataException
    {
        MDDimension dim = getMeasureDimObj();
        if (dim != null)
            return dim.getUniqueID();
            
        return null;
    }

    /**
     * @hidden
     */
    protected void setupCacheKeyPool()
    {
        // Populate MDObject cache key pool
        for (int i = 0; i < m_mdObjectKeyPool.length; i++)
            m_mdObjectKeyPool[i] = new MDObjectKey();
    }

    /**
     * @hidden
     */
    protected MDObjectKey getMDObjectKeyFromPool(String strID, String strValue, String strType)
    {
        // Check for an available key in the pool
        for (int i = 0; i < m_mdObjectKeyPool.length; i++)
        {
            if (m_mdObjectKeyPool[i] != null)
            {
                // Found one: reserve it
                MDObjectKey key = m_mdObjectKeyPool[i];
                m_mdObjectKeyPool[i] = null;
                key.setKeyValues(strID, strValue, strType);
                return key;
            }
        }
        return new MDObjectKey(strID, strValue, strType);
    }

    /**
     * @hidden
     */
    protected void returnMDObjectKeyToPool(MDObjectKey key)
    {
        if (key == null)
            return;

        for (int i = 0; i < m_mdObjectKeyPool.length; i++)
        {
            if (m_mdObjectKeyPool[i] == null)
            {
                m_mdObjectKeyPool[i] = key;
                return;
            }
        }
    }
    
    /**
     * @hidden
     * 
     * Retrieve an <code>MDObject</code> from the cache or <code>MetadataManager<code>.
     *
     * @param strID a <code>String</code> value that represents the metadata
     *        manager ID.
     * @param strValue a <code>String</code> value that represents the runtime
     *        value of the metadata object we are trying to find.
     * @param strType a <code>String</code> value that represents the
     *        MetadataManager type.
     * @param bAddNull a <code>boolean</code> value that is <code>true</code>
     *        when null values should be added to the cache and <code>false</code>
     *        otherwise.
     * @param obj add the given object to the cache without doing a lookup at all, if not null.
     *
     * @return <code>MDObject</code> which represents the metadata object
     *          associated with the specified values.
     *
     * @throws <code>MetadataManagerException</code> if <code>MDObject</code> 
     *         object cannont be found.
     *
     * @status hidden
     */
    public MDObject getMDObject (String strID, String strValue, String strType,
                            boolean bAddNull, MDObject obj, boolean dontCheckMM) throws MetadataManagerException {

      MDObject mdObject = null;

      // If requesting a null value, simply return
      if (strValue == null) {
        return null;
      }

      // Determine if we are using a MDObject cache
      if (!MDCACHE) {
        // Since we are not using the MDObject cache, attempt to retrieve the
        // MDObject directly from MetadataManager
        mdObject = getMetadataManager().getMDObject (strID, strValue, strType);
        
        // If we haven't found a MDObject, determine if the ID represents a 
        // runtime value
        /*if (mdObject == null) {
          // Determine if we are checking for Runtime IDs
          return getMetadataRuntimeID (strID, strValue, strType);
        }*/
      }

      // Generate the key associated with this value
      MDObjectKey key = getMDObjectKeyFromPool(strID, strValue, strType);

      if (obj != null)
      {
        m_mdObjectCache.put (key.clone(), obj);
        returnMDObjectKeyToPool(key);
        return obj;
      }
      
      // Check to see if this value is already cached
      mdObject = (MDObject)m_mdObjectCache.get (key);
      
      if (mdObject == null && !dontCheckMM)
      {
        try
        {
            if (getMeasureDim() != null && getMeasureDim().equals(strValue))
                mdObject = getMeasureDimObj();
            else
            {
                // Since MDObject is not cached, attempt to retrieve it from 
                // MetadataManager
                mdObject = getMetadataManager().getMDObject (strID, strValue, strType);
            }
        }
        catch (InvalidMetadataException e)
        {
            if (e.getPreviousException() instanceof MetadataManagerException)
                throw (MetadataManagerException)e.getPreviousException();
            throw new QueryRuntimeException(e.getMessage(), e);
        }

        // If we haven't found a MDObject, determine if the ID represents a 
        // runtime value
        /*if (mdObject == null)
        {
          // Determine if we are checking for Runtime IDs
          mdObject = getMetadataRuntimeID (strID, strValue, strType);
        }*/

        // If we have found an MDObject, put it in the cache
        if (mdObject != null)
        {
          m_mdObjectCache.put (key.clone(), mdObject);
        }
        else
        {
          // Determine if we need to put null MDObject values in the cache
          if (bAddNull)
          {
            m_mdObjectCache.put (key.clone(), getNullMDObject());
            mdObject = m_nullMDObject;
          }    
        }
      }

      returnMDObjectKeyToPool(key);
      return mdObject;
    }

    /**
     * @hidden
     * Retrieve an MDObject from the cache or MetadataManager object.
     *
     * @param  strID a <code>String</code> value that represents the metadata
     *         manager ID.
     * @param  strValue a <code>String</code> value that represents the runtime
     *         value of the metadata object we are trying to find.
     * @param  strType a <code>String</code> value that represents the
     *         MetadataManager type.
     *
     * @return <code>MDObject</code> which represents the metadata object
     *          associated with the specified values.
     *
     * @throws <code>MetadataManagerException</code> if metadata object can't
     *         be found.
     *
     * @status hidden
     */
    public MDObject getMDObject (String strID, String strValue, String strType)
                                    throws MetadataManagerException {
      return getMDObject (strID, strValue, strType, false, null, false);                                    
    }


    /**
     * @hidden
     */
/*   protected boolean createDefaultAndNotify(DataDirectorListener l, DataDirector d) throws QueryException, MetadataManagerException
   {
        // To support demos
        if (isDefaultQuery() && getMetadataManager() != null) {
            // Create a default cube using the first measure in the database
            String meas = QueryUtil.getFirstMeasure(getMetadataManager().getMeasures());
            if (meas != null) {
                // Create the cube
               initCubeQuery(new String[] {meas}, null);
                // Trick the data source
                int index = -1;
                try {
                    index = m_dataDirectorListeners.indexOf(l);
                    if (index == -1)
                    {
                        index = addNewDDLCursorCopy();
                    }

                }
                catch (Exception e) {
                }
                fireDataAvailable(l, d, getDDLCursor(index), (index > -1));
                return true;
            }
        }
        return false;
   }*/
    
    
    // Get access operation queue
    /**
     * @hidden
     */
    protected BaseOperationQueue _getAccessOperationQueue() throws Throwable
    {
        if (m_accessOperationQueue == null) {
            // We always want to execute this immediately
            m_accessOperationQueue = new OperationQueue(true, getQueryManager(), this, m_listeners);
            m_accessOperationQueue.setAutoUpdate(false);
        }
        return m_accessOperationQueue;
    }


    /**
     * @hidden
     */
/*    protected void releaseCurList(Vector curList) {
        if (curList == null) {
            return;
        }
        Enumeration curs = curList.elements();
        while (curs.hasMoreElements()) {
            ((CubeCursor)curs.nextElement()).release();
        }        
    }*/
    

    
    /**
     * @hidden
     * Notify about page changes.
     *
     * @param e DataChangedEvent
     * @param curPage current page of firer
     * @status hidden
     */
    public void fireDataChanged(DataChangedEvent e, long curPage, QDR qdrPage, int edge, boolean ownChange) throws Exception
    {
        if (isSharePage() && curPage > -1 && edge == DataDirector.PAGE_EDGE)
        {
            setCurrentPageAndFireEvent(curPage, qdrPage, e);
        }
        
        if (m_dataDirectors == null)
            return;

        DataDirectorImpl d = (DataDirectorImpl)e.getDataDirector();
        
        if (isSharePage())
        {
            Enumeration l = m_dataDirectors.elements();
            DataDirectorImpl dd = null;
            while (l.hasMoreElements())
            {
                dd = (DataDirectorImpl)l.nextElement();
//                _fireChange((CommonDataDirector)dd.getDelegate(), e, ownChange);
                _fireChange(dd, e, ownChange);
            }
        }
        else
        {
            _fireChange(d, e, ownChange);
        }
    }
    
    /**
     * @hidden
     */
    public void fireDataChanged(StatusInfo status)
    {
        // Notify all querylistener2's and datadirectorlistener's
        PollingRequiredEvent event = new PollingRequiredEvent(this, status);
        if (m_listeners != null)
            m_listeners.firePollingRequired(event);
        
        if (m_dataDirectors == null)
            return;
            
        // Now data director listeners
        Enumeration l = m_dataDirectors.elements();
        DataDirectorImpl dd = null;
        while (l.hasMoreElements())
        {
            dd = (DataDirectorImpl)l.nextElement();
            dd.firePollingRequired(event);
        }        
    }
    
    /**
     * @hidden
     */
    public void firePollingRequired(StatusInfo status, QueryListener listener, DataDirectorListener ddl)
    {
        // Notify all querylistener2's and datadirectorlistener's
        PollingRequiredEvent event = new PollingRequiredEvent(this, status);
        // Caller just wants one to a query listener
        if (listener instanceof QueryListener2)
        {
            ((QueryListener2)listener).queryPollingRequired(event);
            return;
        }
        // caller just wants one to a datadirectorlistener
        else if (ddl instanceof DataDirectorListener)
        {
            ddl.pollingRequired(event);
            return;
        }
        else
        {
            if (m_listeners != null)
                m_listeners.firePollingRequired(event);
        }
        
        if (m_dataDirectors == null)
            return;
            
        // Now data director listeners
        Enumeration l = m_dataDirectors.elements();
        DataDirectorImpl dd = null;
        while (l.hasMoreElements())
        {
            dd = (DataDirectorImpl)l.nextElement();
            dd.firePollingRequired(event);
        }        
    }
    

    /**
     * @hidden
     * Drills to specified level of the specified hierarchy.
     *
     * @param dimension The dimension to drill.
     * @param value     The dimension value (also known as member) to drill.
     * @param hierarchy The name of the target hierarchy.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @param data     Extra metadata/data
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * @status New
     */
    public abstract void drill(String dimension, String value, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException, MetadataManagerException;

    
     // Get a measure selection event based on a measure list
    /**
     * @hidden
     */
    protected SelectionChangingEvent getSelectionChangeEvent(String[] measures) throws InvalidMetadataException
    {
        // blm - Selection code moved to dvt-olap
/*        Selection sel = new Selection(getMeasureDim());
        MemberStep vs = new MemberStep(sel.getDimension());
        if (measures != null)
        {
            for (int i = 0; i < measures.length; i++) {
                vs.addMember(measures[i]);
            }
        }
        sel.addStep(vs);*/
        
        return new SelectionChangingEvent(this/*, new Selection[] {sel}*/);
    }
        

    /**
     *  @hidden
     *  Delegate the notification of change
     *
     *  @param e event to fire
     *  @status hidden
     */
    private void _fireChange(DataDirectorImpl d, DataChangedEvent e, boolean ownChange) throws QueryException
        {        
        boolean row = false, column = false, page = false, data = false;

        if (!isViewDataAvailable())
        {
            return;
        }
        // For now just refresh all headers for relational data access
        // unless input parameter e contains change type such as SEL_CHANGE
        if (d instanceof RelationalDataDirector) {
            row = true;
            column = true;
            page = true;
        }
        else {
            BitSet edges = e.getMetadataChanged();
            if (edges != null)
            {
                if (edges.get(DataDirector.ROW_EDGE)) {
                    row = true;
                }
                if (edges.get(DataDirector.COLUMN_EDGE)) {
                    column = true;
                }
                if (edges.get(DataDirector.PAGE_EDGE)) {
                    page = true;
                }
            }
        }
        
        //DataAccess da = generateDataAccess(d, e.getChangeType());
        
        if (e.isDataChanged() && isDataAvailable())
        {
            data = true;
        }
        
        if (isDataAvailable())
        {
            d.fireDataChanged(e.getChangeType(), data, row, column, page, null);
        }
        else
          d.fireDataAvailable(new DataAvailableEvent(this, false, null));
    }

    /**
     * @hidden
     * Return a data director given a data access
     */
    protected abstract DataDirector getDataDirector(DataAccess da);
    
    /**
     * @hidden
     * Generate a DataAccess
     */
    protected abstract DataAccess generateDataAccess(DataDirector dd, int changeType) throws QueryException;

    /**
     * @hidden
     * Generate a DataAccess
     */
    protected abstract DataAccess[] generateDataAccess(DataDirector[] dd, int changeType) throws QueryException;
    
    // Capture current page of each cursor
    /**
     * @hidden
     */
    /*protected void capturePageStatebyCursor(String changedNode) {
        capturePageStatebyCursor(new String[] {changedNode});
    }*/

    // Capture current page of each cursor
    /**
     * @hidden
     */
/*    protected void capturePageStatebyCursor(String[] changedNodes) {
        // Do regular cursors
        if (m_cubeCursors != null) {
            Enumeration cursors = m_cubeCursors.elements();
            while (cursors.hasMoreElements()) {
                try {
                    ((CubeCursor)cursors.nextElement()).captureCurrentPage(changedNodes);
                }
                catch (Exception e) {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }
        if (m_ddlCursors != null) {
            // do view cursors
            Enumeration cursors = m_ddlCursors.elements();
            while (cursors.hasMoreElements()) {
                try {
                    ((CubeCursor)cursors.nextElement()).captureCurrentPage(changedNodes);
                }
                catch (Exception e) {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }
    }*/

    


    /**
     * @hidden
     * Fire an error through the backing QueryManager's handler, if possible
     */
    public ErrorHandler getErrorHandler()
    {
        try {
            if (getQueryManager() != null)
            {
                return getQueryManager().getErrorHandler();
            }
        }
        catch (QueryRuntimeException qmre)
        {
        }
        return m_eh;
    }
    /*
    /**
    * Specifies a name that is used to uniquely identify a
    * <code>ThinBean</code>. An application can have multiple thin beans
    * at the same time.
    * Events that a <code>ThinBean</code> generates include a
    * <code>source</code> event parameter (which is a query parameter on a URL).
    * The <code>source</code> parameter has a value that is a
    * ThinBeanName.
    *
    * @param thinBeanName The name of the <code>ThinBean</code>.
    *
    * @status Documented
    */
  /*  public void setThinBeanName(String thinBeanName)
    {
        m_thinBeanName = thinBeanName;
    }*/

    /**
    * Retrieves a name that is used to uniquely identify a
    * <code>ThinBean</code>. An application can have multiple thin beans
    * at the same time.
    * Events that a <code>ThinBean</code> generates include a
    * <code>source</code> event parameter (which is a query parameter on a URL).
    * The <code>source</code> parameter has a value that is a
    * ThinBeanName.
    *
    * @return The name of a <code>ThinBean</code>.
    *
    * @status Documented
    */
   /* public String getThinBeanName()
    {
        return m_thinBeanName;
    }
*/
    /**
     * @hidden
     * 
     * Determines whether the query supports dimension calculations.
     *
     * @return <code>boolean</code> value which is <code>true</code> if the 
     *         query supports dimension calculations and 
     *         <code>false</code> otherwise.
     *
     * @status hidden
     */
    public boolean isDimensionCalcsSupported () {
      boolean bIsDimensionCalcsSupported = false;

      PropertySupport propertySupport = getPropertySupport();
      if (propertySupport != null) {
        Boolean boolIsDimensionCalcSupported = 
          (Boolean) propertySupport.getProperty (QueryConstants.PROPERTY_DIMENSIONCALCS_SUPPORTED);
          
        bIsDimensionCalcsSupported =
          (boolIsDimensionCalcSupported != null) ? boolIsDimensionCalcSupported.booleanValue(): false;
      }
      
      return bIsDimensionCalcsSupported;
    }

    /**
     * @hidden
     * 
     * Value used to represent null MDObject values that need to be stored
     * within the MDObject cache hashtable.
     * 
     * @return <code>NullMDObject</code> used to represent null MDObject values.
     * 
     * @status hidden
     */
    protected NullMDObject getNullMDObject() {
      return m_nullMDObject;
    }

    /**
     * @hidden
     */
    protected class MDObjectKey extends Object
    {
        protected String m_strID;
        protected String m_strType;
        protected String m_strValue;

        public MDObjectKey()
        {
            super();
        }

        public MDObjectKey(String strID, String strValue, String strType)
        {
            this();
            setKeyValues(strID, strValue, strType);
        }

        public void setKeyValues(String strID, String strValue, String strType)
        {
            m_strID = strID;
            m_strValue = strValue;
            m_strType = strType;
        }

        public Object clone()
        {
            return new MDObjectKey(m_strID, m_strValue, m_strType);
        }

        public boolean equals(Object key)
        {
            if (key instanceof MDObjectKey)
            {
                MDObjectKey ck = (MDObjectKey)key;
                return Utility.compareObj(m_strID, ck.m_strID) && Utility.compareObj(m_strValue, ck.m_strValue) && Utility.compareObj(m_strType, ck.m_strType);
            }
            return false;
        }

        public int hashCode()
        {
            return m_strID != null ? m_strID.hashCode() : 0 + m_strValue != null ? m_strValue.hashCode() : 0 + m_strType != null ? m_strType.hashCode() : 0;
        }
    }
}
