/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.UserObjectBag;
import oracle.dss.metadataUtil.OrderedHashtable;

/**
    @hidden
	MDIndex is a dictionary of a all the MDObjects and other user objects
	cached in a single tier. There will be separate instance of MDIndex
	on client and the server tiers and each of them will be maintained
	separately and only within the tier. This class will not be send
	across the tiers.
*/
public class MDIndex {
    /************************************************************************
    * Private members
    ************************************************************************/
    /*
        This Hashtable contains the MDObjectID (key) and the MDObject itself.
    */
    Hashtable m_MDObjects = null;

    // key is unique-id and value is mdObject
    Hashtable m_MDObjsByUniqueID = null;

    // key is path and value is mdObject
    Hashtable m_MDObjsByPath = null;

    // key is path and value is mdObject
    Hashtable m_MDObjsByRunID = null;
    /*
        This Hashtable contains the MDObjectID (key) and the UserObjectBag
        of that MDObject but not contained in the MDObject. This UserobjectBag
        only exist on a single tier.
        Thsese user object are not supposed to be travelling
        across tiers.
    */
    Hashtable m_UserObjects = null;

    /*
        _uid = Unique ID
        _oid = OlapMetadata ID
        _pid = persistence ID   i.e. PATH
    */
    private final int _uid = 1;
    private final int _oid = 2;
    private final int _pid = 3;

    /************************************************************************
    * Public Methods
    ************************************************************************/
    /**
     * Default Constructor
     *
     * @status New
     */
    public MDIndex() {
        m_MDObjects = new Hashtable();
        m_UserObjects = new Hashtable();
        m_MDObjsByUniqueID = new Hashtable();
        m_MDObjsByPath = new Hashtable();
        m_MDObjsByRunID = new Hashtable();
    }

    /**
     * Retrieve all mdObjects from index
     *
     * @return  Array of mdObjects
     *
     * @status New
     */
	public MDObject[] getMDObjects () {
        MDObject[] objectArray = new MDObject[ m_MDObjects.size() ];
        Enumeration enumer = m_MDObjects.keys();
        int i = 0;
        for( i = 0; enumer.hasMoreElements(); i++ )
            objectArray[i] = (MDObject)m_MDObjects.get( enumer.nextElement() );

        if ( i == 0 )
            return null;

		return objectArray;
	}

    /**
     * Retrieve all userObjects from index
     *
     * @return  Array of userObjects
     *
     * @status New
     */
    public UserObject[] getUserObjects () {
        Enumeration enumer = m_UserObjects.elements();
        Vector userObjectVec = new Vector();
        while( enumer.hasMoreElements() ) {
            UserObjectBag userObjectBag = (UserObjectBag) enumer.nextElement();
            if( userObjectBag.size() != 0 ) {
                UserObject[] tempArray = userObjectBag.getUserObjects();
                for( int i = 0; i < tempArray.length; i++ )
                    userObjectVec.addElement( tempArray[i] );
            }
        }
        if( userObjectVec.size() != 0 ) {
            UserObject[] array = new UserObject[ userObjectVec.size() ];
            userObjectVec.copyInto( array );
            return array;
        }
        return null;
    }

    /**
     * Retrieve a mdObject from index with specified ID
     *
     * @param mdObjectID    ID for mdObject that is to be retrieved
     *
     * @return  mdObject with specified ID
     *
     * @status New
     */
	public MDObject getMDObject ( long mdObjectID ) {
        return (MDObject)m_MDObjects.get( new Long( mdObjectID ) );
	}

    /**
     * Retrieve children of specified mdObject from index till specified depth
     *
     * @param mdObject    mdObject whose children are needed
     * @param depth       depth of tree under mdObject
     *
     * @return  hashtable containing children of mdObject till specified depth
     *
     * @status New
     */
    public OrderedHashtable getChildren( MDObject mdObject, int depth )
                                            throws MetadataManagerException
    {
        if( mdObject == null )
            return null;

        OrderedHashtable mdTable = mdObject.getChildrenBag().getContentTable();

        if ( ( mdTable == null ) || ( mdTable.size() == 0) )
            return null;

        if( (depth != -1) && (depth <= 1) )
            return mdTable;
        else {
            OrderedHashtable table = new OrderedHashtable();
            depth = (depth != -1)? depth - 1 : depth;
            Enumeration enumer = mdTable.keys();
            MDObject obj;
            OrderedHashtable childTable = null;
            while( enumer.hasMoreElements() ) {
                obj = (MDObject) enumer.nextElement();
                table.put( obj, mdTable.get( obj ) );
                if ( !mdObject.isAncestor( obj.getUniqueID() ) )
                    childTable = getChildren( obj, depth );
                if( childTable != null )
                    MDContentBag.mergeHashtables( table, childTable );
                childTable = null;
            }
            if ( table.size() == 0 )
              return null;
            return table;
        }
    }

    /**
     * Retrieve userObjects for specified mdObject
     *
     * @param mdObject    mdObject whose userObject are to be
     *
     * @return  Array of userObjects for specified mdObject
     *
     * @status New
     */
    public UserObject[] getUserObjects ( MDObject mdObject ) {
        Long mdObjectID = new Long( mdObject.getObjectID() );
        UserObjectBag userBag = (UserObjectBag) m_UserObjects.get( mdObjectID );
        if( userBag == null )
            return null;
        UserObject[] userArray = userBag.getUserObjects();
        if( userArray == null || userArray.length == 0 )
            return null;
        return userArray;
    }

    /**
     * Retrieve userObject for specified mdObject with given relation
     *
     * @param mdObjectID    mdObjectID whose userObject is to be retrieved
     * @param relation      String representing relation between userObject and
     *                      mdObject
     *
     * @return              userObject for specified mdObject and relation
     *
     * @status New
     */
    public UserObject getUserObject( long mdObjectID, String relation ) {
        UserObjectBag userBag = (UserObjectBag) m_UserObjects.get( new Long( mdObjectID ) );
        if( userBag == null )
            return null;
        return userBag.getUserObject( relation );
    }

    /**
     * Retrieve object for specified mdObject with given relation
     *
     * @param mdObjectID    mdObjectID whose userObject is to be retrieved
     * @param relation      String representing relation between userObject and
     *                      mdObject
     *
     * @return              object for specified mdObject and relation
     *
     * @status New
     */
    public Object getObject ( long mdObjectID, String relation ) {
        UserObject userObject = getUserObject( mdObjectID, relation );
        if( userObject == null )
            return null;
        return userObject.getObject();
    }

    /**
     * Retrieve mdObject with specified property name and value
     *
     * @param name          property name
     * @param uniqueValue   property value
     *
     * @return              object for specified property name and value
     *
     * @status New
     */
    public MDObject getMDObject ( String name, String uniqueValue ) {
        Property prop = new Property ();
        prop.setStrValue( name, uniqueValue, MDU.UI_NONE );
        return getMDObject ( prop );
    }

    /**
     * Retrieve mdObject with specified property
     *
     * @param uniqueProperty    property through which mdObject will be
     *                          retrieved
     *
     * @return                  mdObject for specified property
     *
     * @status New
     */
    public MDObject getMDObject ( Property uniqueProperty ) {
        if( uniqueProperty == null ) {
            return null;
        }

        String name = uniqueProperty.getName();
        if(name.equals(MM.UNIQUE_ID))
            return getMDObjectByID(_uid, uniqueProperty);
        else if(name.equals(MM.OLAPI_METADATA_ID))
            return getMDObjectByID(_oid, uniqueProperty);
//        else if(name.equals(MM.PATH))
//            return getMDObjectByID(_pid, uniqueProperty);

        Enumeration enumer = m_MDObjects.elements();
        MDObject mdObject = null;
        while( enumer.hasMoreElements() ) {
            mdObject = (MDObject)enumer.nextElement();
            if ( mdObject.contains ( uniqueProperty ) )
            return  mdObject;
        }
        return null;
    }

    /**
     * Retrieve first mdObject with specified propertyBag
     *
     * @param propertyBag       properties which can used to retrieve mdObject
     *
     * @return                  mdObject with specified properties
     *
     * @status New
     */
    public MDObject getFirstMDObject ( PropertyBag propertyBag ) {
        return getMDObject( propertyBag );
    }

    /**
     * Retrieve mdObjects with specified propertyBag
     *
     * @param propertyBag       properties through which mdObjects will be
     *                          retrieved
     *
     * @return                  Array of mdObjects with specified properties
     *
     * @status New
     */
	public MDObject[] getMDObjects ( PropertyBag propertyBag ) {
        if( propertyBag == null )
            return null;

/*
        Property prop = propertyBag.getProperty(MM.UNIQUE_ID);
        MDObject obj = null;

        if(prop != null)
            obj = getMDObjectByID(_uid, prop);
        else {
            prop = propertyBag.getProperty(MM.OLAPI_METADATA_ID);
            if(prop != null)
                obj = getMDObjectByID(_oid, prop);
            else {
                prop = propertyBag.getProperty(MM.PATH);
                if(prop != null)
                    obj = (MDObject)m_MDObjsByPath.get(prop.getStrValue());
            }
        }
*/
        MDObject obj = null;
        boolean _isUidProp = false;
        if(propertyBag.isBitOn(MDU.UID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.UNIQUE_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByUniqueID.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.OLAPI_METADATA_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByUniqueID.get(MMUtilities._makeUniqueID(MDU.MDM, _str));
        }
        else if(propertyBag.isBitOn(MDU.PATH_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.PATH);
            if(_str != null)
                obj = (MDObject)m_MDObjsByPath.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPRUNID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.OLAPI_RUNTIME_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByRunID.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPRUNIDS_BIT))
        {
            _isUidProp = true;
            Vector _vec = propertyBag.getStringVectorPropertyValue(MM.OLAPI_RUNTIME_IDS);
            if(_vec != null)
            {
                for(Enumeration _enum = _vec.elements(); _enum.hasMoreElements();)
                {
                    String _id = (String)_enum.nextElement();
                    if(_id != null)
                        obj = (MDObject)m_MDObjsByRunID.get(_id);
                    if(obj != null)
                        break;
                }
            }
        }

        if(obj != null) {
            MDObject[] objs = new MDObject[1];
            objs[0] = obj;
            return objs;
        }
        else if(_isUidProp)
            return null;

        Vector vec = new Vector();
        Property[] propertyArray = propertyBag.getProperties();
        Enumeration enumer = m_MDObjects.elements();
        MDObject tempMDObject = null;
        while( enumer.hasMoreElements() ) {
            tempMDObject = (MDObject)enumer.nextElement();
            int i;
            for( i = 0; i < propertyArray.length && tempMDObject.contains( propertyArray[i] ); i++ );
            if( i == propertyArray.length )
                vec.addElement( tempMDObject );
        }
        if( vec.size() != 0 ) {
            MDObject[] mdObjects = new MDObject[vec.size()];
            vec.copyInto( mdObjects );
            return mdObjects;
        }
		return null;
	}

    /**
     * Retrieve mdObjects with specified objectIDs
     *
     * @param mdObjectIDs       OrderedHashtable of object IDs
     *
     * @return                  OrderedHashtable of mdObjects
     *
     * @status New
     */
    public OrderedHashtable getMDObjects ( OrderedHashtable mdObjectIDs ) {
        OrderedHashtable onlyIDs = new OrderedHashtable();
        return getMDObjects ( mdObjectIDs, onlyIDs );
    }

    /**
     * Retrieve mdObjects with specified objectIDs
     *
     * @param mdObjectIDs       OrderedHashtable of object IDs
     * @param mdObjectIDs       OrderedHashtable of objectIDs that were not
     *                          found in index
     *
     * @return                  OrderedHashtable of mdObjects
     *
     * @status New
     */
    public OrderedHashtable getMDObjects ( OrderedHashtable mdObjectIDs,
                                           OrderedHashtable onlyIDs )
    {
        if (( mdObjectIDs == null ) || ( onlyIDs == null ) )
            return null;

        OrderedHashtable objectContainer = new OrderedHashtable();

        Enumeration enumIDs = mdObjectIDs.keys();
        for (int i = 0; enumIDs.hasMoreElements(); i++ ) {
            Long indexKey = (Long)enumIDs.nextElement();
            MDObject mdObject = getMDObject ( indexKey.longValue());
            if ( mdObject != null ) {
                objectContainer.put( mdObject, mdObjectIDs.get( indexKey ));
            } else {
                onlyIDs.put ( indexKey, mdObjectIDs.get( indexKey ) );
            }
        }
        if ( objectContainer.size() == 0 )
            return null;
        return objectContainer;
    }

    /**
     * Retrieve mdObjects with specified propertyBag and matchCriteria
     *
     * @param propertyBag       properties that we are looking for in MDObjects
     * @param matchCriteria     String representing union or intersection.
     *                          Possible values are:
     *                          <code>MM.UNION</code>
     *                          <code>MM.INTERSECTION</code>
     *
     * @return                  MDObject array containing mdObject with
     *                          specified propertyBag and matchCriteria.
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status New
     */
    public MDObject[] getMDObjects ( PropertyBag propertyBag, String matchCriteria ) {
        if( propertyBag == null || matchCriteria == null ) {
            return null;
        }
        Property[] property = propertyBag.getProperties();
        if( property == null || property.length == 0 ) {
            return null;
        }

        if( matchCriteria.equals( MM.UNION ) ) {
            Vector vec = new Vector();
            Enumeration enumer = m_MDObjects.elements();
            while( enumer.hasMoreElements() ) {
                MDObject mdObject = (MDObject)enumer.nextElement();
                // if mdObject contains property[i] it will return true; '!' will convert
                // true to false and this will break the for loop.
                int i;
                for( i = 0; i < property.length && !mdObject.contains( property[i] ); i++ );
                // if i < property.length then the for loop ended because property[i] was found
                // in mdObject.
                if( i < property.length ) {
                    vec.addElement( mdObject );
                }
            }
            if( vec.size() != 0 ) {
                MDObject[] mdObjects = new MDObject[ vec.size() ];
                vec.copyInto( mdObjects );
                return mdObjects;
            }
        }
        else if( matchCriteria.equals( MM.INTERSECTION ) ) {
            return getMDObjects( propertyBag );
        }
        return null;
    }

    /**
     * Retrieve userObject for specified mdObject and relation
     *
     * @param mdObject          mdObject whose userObject is to be retrieved
     * @param relation          String representing relation between mdObject
     *                          and userObject
     *
     * @return                  userObject for specified mdObject and relation
     *
     * @status New
     */
    public UserObject getUserObject ( MDObject mdObject, String relation ) {
        if( mdObject == null || relation == null ) {
            return null;
        }
        long mdObjectID = mdObject.getObjectID();
        return getUserObject( mdObjectID, relation );
    }

    /**
     * Retrieve userObjectBag for specified mdObject
     *
     * @param mdObject          mdObject whose userObjectBag is to be retrieved
     *
     * @return                  userObjectBag for specified mdObject.  Null is
     *                          returned is no userObjectBag is set
     *
     * @status New
     */
    public UserObjectBag getUserObjectBag ( MDObject mdObject ) {
        if( mdObject == null ) {
            return null;
        }
        long mdObjectID = mdObject.getObjectID();
        return (UserObjectBag) m_UserObjects.get( new Long( mdObjectID ) );
    }

    /**
     * Retrieve mdRoot in cache
     *
     * @return  mdRoot Object.  Null is returned if no root is set.
     *
     * @status New
     */
    public MDRoot getRoot(){
        Enumeration enumer = m_MDObjects.elements();
        Object obj;
        while( enumer.hasMoreElements() ) {
            obj = enumer.nextElement();
            if( obj instanceof MDRoot )
                return (MDRoot)obj;
        }
        return null;
    }

    /**
     * Retrieve all measures in index
     *
     * @return  Array of MDMeasures existing in index.  Null is returned if
     *          no measure is found
     *
     * @status New
     */
    public MDObject[] getMeasures() {
        Enumeration enumer = m_MDObjects.elements();
        Vector vec = new Vector();
        MDObject obj;
        String objType;
        while( enumer.hasMoreElements() ) {
            obj = (MDObject)enumer.nextElement();
            objType = obj.getObjectType();
            if( objType != null && objType.equals( MM.MEASURE ) )
                vec.addElement( obj );
        }
        if( vec.size() != 0 ) {
            MDObject[] objArray = new MDObject[vec.size()];
            vec.copyInto( objArray );
            return objArray;
        }
        return null;
    }

    /**
     * Retrieve all dimensions in index
     *
     * @return  Array of MDDimensions existing in index.  Null is returned if
     *          no dimension is found
*
     * @status New
     */
    public MDObject[] getDimensions() {
        Enumeration enumer = m_MDObjects.elements();
        Vector vec = new Vector();
        MDObject obj;
        String objType;
        while( enumer.hasMoreElements() ) {
            obj = (MDObject)enumer.nextElement();
            objType = obj.getObjectType();
            if( objType != null && objType.equals( MM.DIMENSION ) )
                vec.addElement( obj );
        }
        if( vec.size() != 0 ) {
            MDObject[] objArray = new MDObject[vec.size()];
            vec.copyInto( objArray );
            return objArray;
        }
        return null;
    }

    /**
     * Set mdObjects from orderedHashtable to index
     *
     * @param table         OrderedHashtable of mdObjects
     * @param mmServices    Instance of either MetadataManager.java or
     *                      MetadataManagerImpl.java
     *
     * @return              MDContentBag containing mdObjects in
     *                      Orderedhashtable
     *
     * @throws              MetadatManagerException
     *
     * @status New
     */
    public MDContentBag setMDObjects( OrderedHashtable        table,
                                      MetadataManagerServices mmServices )
                                                throws MetadataManagerException
    {
        if( table == null )
            return null;
        MDContentBag mdContentBag = new MDContentBag();
        Enumeration enumer = table.keys();
        while( enumer.hasMoreElements() ) {
            MDObject mdObject = (MDObject)enumer.nextElement();
            MDObject mdExistingObject = getMDObject( mdObject.getObjectID());
            if ( mdExistingObject != null ) {
              if ( mdObject.getObjectID() == mdExistingObject.getObjectID()) {
                String relation = (String)table.get(mdObject);
                mdContentBag.setContentItem( (PropertyBag) mdExistingObject, relation );
                mdObject = mdExistingObject;
              }
            }
            else {
                mdContentBag.setContentItem( (PropertyBag) mdObject, (String)table.get( mdObject ) );
            }
            mdObject.setMetadataManagerServices ( mmServices );
            setMDObject( mdObject );
        }
        if ( mdContentBag.size() == 0 )
            return null;
        return mdContentBag;
    }

    /**
     * Set mdObjects from contentBag to index
     *
     * @param contentBag    MDContentBag containing mdObject that are to be set
     *                      in index
     *
     * @throws              MetadatManagerException
     *
     * @status New
     */
    public void setMDObjects( MDContentBag contentBag )
                                                throws MetadataManagerException
    {
        if( contentBag == null )
            return;

        PropertyBag[] propertyBag = contentBag.getContents();
        if( propertyBag == null ) {
            return;
        }
        for( int i = 0; i < propertyBag.length; i++ )
            setMDObject( (MDObject)propertyBag[i] );
    }

    /**
     * Set mdObjects from contentBag to index
     *
     * @param contentBag    MDContentBag containing mdObject that are to be set
     *                      in index
     *
     * @throws              MetadatManagerException
     *
     * @status New
     */
 	public void setMDObject ( MDObject mdObject )
                                                throws MetadataManagerException
    {
        if( mdObject == null )
            return;
        setMDObject ( mdObject.getObjectID(), mdObject );
        return;
 	}

    /**
     * Set mdObject in index
     *
     * @param mdObjectID    Value of type long that represents mdObject ID
     * @param mdObject      Value of type MDObject that represents mdObject
     *
     * @throws              MetadatManagerException
     *
     * @status New
     */
    public void setMDObject ( long mdObjectID, MDObject mdObject)
                                                throws MetadataManagerException
    {
        if( mdObject == null )
            return;
        m_MDObjects.put( new Long( mdObjectID ), mdObject );

        // Set parent in MDIndex
        MDObject mdParent = mdObject.getParent();
        Long parentID;
        while( mdParent != null ) {
            parentID = new Long( mdParent.getObjectID() );
            if( !m_MDObjects.containsKey( parentID ) ) {
                m_MDObjects.put( parentID, mdParent );
                mdParent.setMetadataManagerServices(mdObject.getMetadataManagerServices());
            }
            mdParent = mdParent.getParent();
        }

        // Add mdObject to hashtable with uniqueID as key
        String uniqueID = mdObject.getUniqueID();
        if(uniqueID != null) {
            m_MDObjsByUniqueID.put(uniqueID, mdObject);
        }

        // Add mdObject to hashtable with path as key
        String path = mdObject.getPath();
        if(path != null) {
            m_MDObjsByPath.put(path, mdObject);
        }
        
        String runID = mdObject.getOLAPIRuntimeID();
        if(runID != null) {
            m_MDObjsByRunID.put(runID, mdObject);
        }

        return;
    }

    /**
     * Set userObject in index
     *
     * @param mdObject      MDObject whose userObject needs to be set
     * @param userObject    UserObject that is to be set for specified mdObject
     * @param relation      relation between mdObject and userObject
     *
     * @status New
     */
    public void setUserObject ( MDObject mdObject,
                                UserObject userObject,
                                String relation)
    {
        if( mdObject == null || userObject == null || relation == null )
            return;

        UserObjectBag userBag = (UserObjectBag) m_UserObjects.get( new Long( mdObject.getObjectID() ) );
        if( userBag != null ) {
            userBag.setUserObject( relation, userObject );
        }
        else {
            // mdObjectID is not in m_UserObjects, create a new UserObjectBag
            // and add it to m_UserObjects
            userBag = new UserObjectBag();
            userBag.setUserObject( relation, userObject );
            m_UserObjects.put( new Long( mdObject.getObjectID() ), userBag );
        }
    }

    /**
     * Print mdObjects in mdIndex
     *
     * @status New
     */
    public void print() {
        if ( m_MDObjects == null )
            return;
        System.out.println ( "--------------------------------------" );
        System.out.println ( "********** Contents of MDIndex *******" );
        System.out.println ( "--------------------------------------" );
        Enumeration enumer = m_MDObjects.elements();
        while( enumer.hasMoreElements() ) {
            MDObject mdObject = (MDObject) enumer.nextElement();
            System.out.println ( "   ID[" + mdObject.getObjectID() +
            "] Type(" + mdObject.getObjectType() +
            ") Name(" + mdObject.getName() +
            ") UniqueID(" + mdObject.getUniqueID() + ")");
        }
    }

    /**
     * Remove specified mdObject from mdIndex
     *
     * @param mdObject  mdObject that is to be removed from mdIndex
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status New
     */
    public int removeMDObject ( MDObject mdObject ) throws MetadataManagerException {
        if( mdObject != null )
        {
            MDObject _mdObj = null;
            if((_mdObj = getMDObject(mdObject.getObjectID())) != null)
                removeMDObject ( _mdObj.getObjectID() );
            else if((_mdObj = getMDObject(mdObject.getUniqueID())) != null)
                removeMDObject ( _mdObj.getObjectID() );
            return MDU.SUCCESS;
        }
        return MDU.FAILURE;
    }

    /**
     * Remove mdObject with specified ID from mdIndex
     *
     * @param mdObjectID  mdObject ID that is to be removed from mdIndex
     *
     * @throws MetadataManagerException
     *
     * @status New
     */
    public void removeMDObject ( long mdObjectID ) throws MetadataManagerException {
        MDObject mdObject = getMDObject( mdObjectID );
        if( mdObject == null ) {
            return;
        }
        // remove references from children and relative bags of all MDObjects
        removeReferences( mdObjectID );
        // delete children tree under mdObject
        if( mdObject.hasChildren() ) {
            deleteChildren( mdObject );
        }
        // remove reference from hashtable
        m_MDObjects.remove( new Long( mdObjectID ) );
        m_MDObjsByUniqueID.remove(mdObject.getUniqueID());
        m_MDObjsByPath.remove(mdObject.getPath());
        if(mdObject.isBitOn(MDU.OLAPRUNID_BIT))
        {
            String _str = mdObject.getStrPropertyValue(MM.OLAPI_RUNTIME_ID);
            if(_str != null)
                m_MDObjsByRunID.remove(_str);
        }
        if(mdObject.isBitOn(MDU.OLAPRUNIDS_BIT))
        {
            Vector _vec = mdObject.getStringVectorPropertyValue(MM.OLAPI_RUNTIME_IDS);
            if(_vec != null)
            {
                for(Enumeration _enum = _vec.elements(); _enum.hasMoreElements();)
                {
                    String _id = (String)_enum.nextElement();
                    if(_id != null)
                        m_MDObjsByRunID.remove(_id);
                }
            }
        }
        return;
    }

    public void removeMDObjectOnly(MDObject mdObject) throws MetadataManagerException
    {
        if(mdObject != null)
        {
            Long id = new Long(mdObject.getObjectID());
            m_MDObjects.remove(id);
            m_MDObjsByUniqueID.remove(mdObject.getUniqueID());
            m_UserObjects.remove(id);
            m_MDObjsByPath.remove(mdObject.getPath());
        }
    }

    public void removeUserObjects(MDObject mdObject)
    {
        m_UserObjects.remove(new Long(mdObject.getObjectID()));
    }

    /**
     * Remove referneces from children and relative bags of all mdObjects
     * in m_MDObjects
     *
     * @param mdObjectID  mdObject ID that is to be removed
     *
     * @status New
     */
    private void removeReferences( long mdObjectID ) {
        MDObject mdObject = getMDObject( mdObjectID );
        Enumeration enumer = m_MDObjects.elements();
        MDObject tmpMDObject;
        while( enumer.hasMoreElements() ) {
            tmpMDObject = (MDObject)enumer.nextElement();
            tmpMDObject.removeChild( mdObject );
            tmpMDObject.removeRelative( mdObject );
        }
    }

    /**
     * Recursively delete children
     *
     * @param mdObject  mdObject whose children are to be deleted
     *
     * @status New
     */
    public void deleteChildren( MDObject mdObject ) throws MetadataManagerException {
        if( mdObject == null )
            return;
        if( mdObject.getChildrenCount() != 0 ) {
            try
            {
                MDObject[] children = mdObject.getChildren();
                for( int i = 0; i < children.length; i++ ) {
                    if ( !mdObject.isAncestor( children[i].getUniqueID() ) )
                        deleteChildren( children[i] );
                    m_MDObjects.remove( new Long(children[i].getObjectID()) );
                    //temp fix for the MDObject in multiple children bag.
                    removeReferences( children[i].getObjectID() );
                    // temporary
//                    children[i].free();
                }
            }
            catch (NameNotBoundException mnbe){//ignore if mdobject has been removed
            }
        }
    }

    /**
     * Remove mdObjects with specified propertyBag and criteria from mdIndex
     *
     * @param propertyBag       mdObject with properties in propertyBag that
     *                          we want to remove
     * @param matchCriteria     String representing union or intersection.
     *                          Possible values are:
     *                          <code>MM.UNION</code>
     *                          <code>MM.INTERSECTION</code>
     *
     *
     * @throws MetadataManagerException
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status New
     */
	public void removeMDObjects( PropertyBag propertyBag, String matchCriteria)
                                                throws MetadataManagerException
    {
        if( propertyBag == null || matchCriteria == null ) {
            return;
        }

        MDObject[] mdObjects = getMDObjects( propertyBag, matchCriteria );
        if( mdObjects == null ) {
            return;
        }
        for( int i = 0; i < mdObjects.length; i++ ) {
            Long objectID = new Long( mdObjects[i].getObjectID() );
            // if mdObjects[i] does not exist in index then it has already been
            // deleted due to deleting one of its parents
            if( m_MDObjects.get( objectID ) != null ) {
                removeMDObject( mdObjects[i] );
            }
        }
	}

    /**
     * Remove userObject for specified mdObjectID and relation
     *
     * @param mdObjectID  mdObject ID whose userObject is to be removed
     *                    from mdIndex
     * @param relation    relation between mdObject and userObject
     *
     * @status New
     */
    public void removeUserObject( long mdObjectID, String relation ) {
        UserObjectBag userBag = (UserObjectBag)m_UserObjects.get( new Long( mdObjectID ) );
        if( userBag != null )
            userBag.removeUserObject( relation );
    }

    /**
     * Remove all userObject for specified mdObject
     *
     * @param mdObject    mdObject whose userObjects are to be removed
     *                    from mdIndex
     * @status New
     */
    public void removeAllUserObject( MDObject mdObject ) {
        m_UserObjects.remove( new Long( mdObject.getObjectID() ) );
    }

    /**
     * Remove userObjects for specified mdObjectID and relation
     *
     * @param relation          relation between mdObject and userObject
     * @param propertyBag       properties through which UserObject will be
     *                          retrieved
     * @param matchCriteria     String representing union or intersection.
     *                          Possible values are:
     *                          <code>MM.UNION</code>
     *                          <code>MM.INTERSECTION</code>
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status New
     */
    public void removeUserObjects ( String relation,
                                    PropertyBag propertyBag,
                                    String matchCriteria )
    {
        if( relation == null || propertyBag == null || propertyBag.size() == 0 ) {
            return;
        }
        Property[] property = propertyBag.getProperties();
        Enumeration enumer = m_UserObjects.elements();
        while( enumer.hasMoreElements() ) {
            UserObjectBag userBag = (UserObjectBag)enumer.nextElement();
            UserObject userObject = userBag.getUserObject( relation );
            if( userObject != null ) {
                if( matchCriteria.equals( MM.UNION ) ) {
                    int i;
                    for( i = 0; i < property.length && !userObject.contains( property[i] ); i++ );
                    if( i < property.length ) {
                        userBag.removeUserObject( relation );
                    }
                }
                else if( matchCriteria.equals( MM.INTERSECTION ) ) {
                    int i;
                    for( i = 0; i < property.length && userObject.contains( property[i] ); i++ );
                    if( i == property.length ) {
                        userBag.removeUserObject( relation );
                    }
                }
            }
        }
        return;
    }

    /**
     * Remove all mdObjects and userObjects from mdIndex
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     */
    public int free() {
        Enumeration enumer = m_MDObjects.elements();
        while( enumer.hasMoreElements() )
        {
            MDObject _obj = (MDObject)enumer.nextElement();
            _obj.free();
        }

        m_MDObjects.clear();
        m_MDObjects = null;

        m_MDObjsByUniqueID.clear();
        m_MDObjsByUniqueID = null;
        
        m_MDObjsByPath.clear();
        m_MDObjsByPath = null;
        
        m_MDObjsByRunID.clear();
        m_MDObjsByRunID = null;

        m_UserObjects.clear();
        m_UserObjects = null;
        
        return MDU.SUCCESS;
    }

    private MDObject getMDObjectByID(int id, Property property)
    {
        String value = property.getStrValue();
        if(value == null)
            return null;
        if(id == _uid) {
            return (MDObject)m_MDObjsByUniqueID.get(value);
        }
        else if(id == _oid) {
            String uniqueID = MMUtilities._makeUniqueID(MDU.MDM, value);
            return (MDObject)m_MDObjsByUniqueID.get(uniqueID);
        }
        else if(id == _pid) {
            String uniqueID = MMUtilities._makeUniqueID(MDU.PERSISTENCE, value);
            return (MDObject)m_MDObjsByUniqueID.get(uniqueID);
        }
        return null;
    }
    
    public MDObject getMDObject(String uniqueID)
    {
        return (uniqueID != null)? (MDObject)m_MDObjsByUniqueID.get(uniqueID) : null;
    }
    
    public MDObject getMDObject(PropertyBag propertyBag)
    {
        if( propertyBag == null )
            return null;

        MDObject obj = null;
        boolean _isUidProp = false;
        if(propertyBag.isBitOn(MDU.UID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.UNIQUE_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByUniqueID.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.OLAPI_METADATA_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByUniqueID.get(MMUtilities._makeUniqueID(MDU.MDM, _str));
        }
        else if(propertyBag.isBitOn(MDU.PATH_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.PATH);
            if(_str != null)
                obj = (MDObject)m_MDObjsByPath.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPRUNID_BIT))
        {
            _isUidProp = true;
            String _str = propertyBag.getStrPropertyValue(MM.OLAPI_RUNTIME_ID);
            if(_str != null)
                obj = (MDObject)m_MDObjsByRunID.get(_str);
        }
        else if(propertyBag.isBitOn(MDU.OLAPRUNIDS_BIT))
        {
            _isUidProp = true;
            Vector _vec = propertyBag.getStringVectorPropertyValue(MM.OLAPI_RUNTIME_IDS);
            if(_vec != null)
            {
                for(Enumeration _enum = _vec.elements(); _enum.hasMoreElements();)
                {
                    String _id = (String)_enum.nextElement();
                    if(_id != null)
                        obj = (MDObject)m_MDObjsByRunID.get(_id);
                    if(obj != null)
                        break;
                }
            }
        }

        if(obj != null)
            return obj;
        else if(_isUidProp)
            return null;

        Property[] propertyArray = propertyBag.getProperties();
        Enumeration enumer = m_MDObjects.elements();
        MDObject tempMDObject = null;
        while( enumer.hasMoreElements() ) {
            tempMDObject = (MDObject)enumer.nextElement();
            int i;
            for( i = 0; i < propertyArray.length && tempMDObject.contains( propertyArray[i] ); i++ );
            if( i == propertyArray.length )
                return tempMDObject;
        }
		return null;
    }
    
    public void setMDObjectByOLAPIIDs(MDObject mdObject, Vector idVec)
    {
        if(m_MDObjsByRunID != null && mdObject != null && idVec != null)
        {
            for(Enumeration _enum = idVec.elements(); _enum.hasMoreElements();)
            {
                String _id = (String)_enum.nextElement();
                if(_id != null)
                    m_MDObjsByRunID.put(_id, mdObject);
            }
        }
    }
    
    public void clear()
    {
        if(m_MDObjects != null)
            m_MDObjects.clear();
        if(m_UserObjects != null)
            m_UserObjects.clear();
        if(m_MDObjsByUniqueID != null)
            m_MDObjsByUniqueID.clear();
        if(m_MDObjsByPath != null)
            m_MDObjsByPath.clear();
        if(m_MDObjsByRunID != null)
            m_MDObjsByRunID.clear();
    }
}