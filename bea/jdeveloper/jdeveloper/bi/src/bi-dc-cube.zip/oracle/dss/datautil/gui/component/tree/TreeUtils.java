/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/tree/TreeUtils.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.tree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;


/**
 * <pre>
 * TreeUtils class containing useful tree utility methods. 
 * </pre>
 *
 * @author gkellam 
 * @since   11.0.0.0.10
 * @status  new
 * 
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/03/06 - Remove CalcBuilder and olap from JDEVADF.
 *    gkellam   09/30/05 - Tree utility methods. 
 * 
 */

public class TreeUtils extends Object {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  /////////////////////
  //
  // Constructors
  //
  ///////////////////// 
  
  /**
   * <pre>
   * Default <code>TreeUtils</code> constructor.
   * 
   * </pre>
   *
   * @status new
   */
  public TreeUtils() {
    super();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the currently selected <code>DefaultMutableTreeNode</code>.
   *
   * @param jTree A <code>JTree</code> to retrieve currently selected 
   *        <code>DefaultMutableTreeNode</code> from.
   * 
   * @return <code>DefaultMutableTreeNode</code> which represents the selected node.
   *
   * @status new
   */
  public static DefaultMutableTreeNode getSelectedNode (JTree jTree) {
    // Make sure that we can retrieve JTree
    if (jTree == null) {
      return null;
    }   
      
    // Determine the path to the node selected node selected    
    TreePath treePathNodeSelected = jTree.getSelectionPath();
    if (treePathNodeSelected == null) {
      return null;
    }

    // Return the node selected
    return (DefaultMutableTreeNode) treePathNodeSelected.getLastPathComponent();
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}