/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.client;

import javax.swing.undo.AbstractUndoableEdit;

import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryEdit;

/**
 * Implementation of Swing UndoableEdit for Query
 *
 * @status Documented
 */
public class QueryUndoableEdit extends AbstractUndoableEdit
{
    /**
     * @hidden
     * @serial Internal edit object
     */
    protected QueryEdit m_queryEdit = null;
    
    /**
     * Constructor
     *
     * @param qe    The <code>QueryEdit</code> object to encapsulate.
     *
     * @status Documented
     */
    public QueryUndoableEdit(QueryEdit qe)
    {
        super();
        
        m_queryEdit = qe;
    }
    
    /**
     * Retrieves the presentation name of this undoable edit
     *
     * @return The presentation name string.
     *
     * @status New
     */
    public String getPresentationName()
    {
        return m_queryEdit.getPresentationName();
    }
    
    /**
     * Performs an undo of the edit's operation.
     *
     * @status Documented
     */
    public void undo()
    {
        super.undo();
        m_queryEdit.undo();
    }
    
    /**
     * Performs a redo of the edit's operation.
     *
     * @status Documented.
     */
    public void redo()
    {
        super.redo();
        m_queryEdit.redo();
    }
}