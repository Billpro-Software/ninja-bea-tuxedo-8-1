/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

/**
 * Informs listeners when the layout of the <code>Query</code> object has
 * changed. This event cannot be consumed.
 *
 * @status Documented
 */
public class LayoutChangedEvent extends LayoutEvent
{
    /**
     * Constructor to use if the affected dimension names are available from
     * the original call that changed the layout.
     *
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param edges       A list of the dirty edges, if known. In this list,
     *                    to refer to edges, use the constants
     *                    <code>DataDirector.COLUMN_EDGE</code>,
     *                    <code>DataDirector.PAGE_EDGE</code>, or
     *                    <code>DataDirector.ROW_EDGE</code>.
     * @param dimensions  The names of the dimensions that were affected
     *                    by the call that changed the layout. This is the same
     *                    parameter that is used in the <code>layout</code>
     *                    method call in the <code>Query</code> class.
     *
     * @see  oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see  oracle.dss.util.DataDirector#PAGE_EDGE
     * @see  oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public LayoutChangedEvent(Object source, BitSet edges, String[][] dimensions) {
        super(source, edges, dimensions);
    }    
    
    /**
     * Constructor to use to specify the kind of pivot.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param edges        A list of the dirty edges, if known. In this list,
     *                     to refer to edges, use the constants
     *                     <code>DataDirector.COLUMN_EDGE</code>,
     *                     <code>DataDirector.PAGE_EDGE</code>, or
     *                     <code>DataDirector.ROW_EDGE</code>.
     * @param sourcedim    The name of the source dimension for a pivot or swap.
     * @param targetdim    The name of the target dimension for a pivot or swap.
     * @param dimensions   The names of the dimensions that were affected
     *                     by the call that changed the layout. This is the same
     *                     parameter that is used in the <code>layout</code>
     *                     method call in the <code>Query</code> class.
     * @param flags        A constant that indicates the type of pivot. Use
     *                     either <code>PivotConstants.PIVOT_AFTER</code> or
     *                     <code>PivotConstants.PIVOT_BEFORE</code>.
     *
     * @see PivotConstants#PIVOT_AFTER
     * @see PivotConstants#PIVOT_BEFORE
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutChangedEvent(Object source, BitSet edges, String sourcedim, String targetdim, String[][] dimensions, int flags) {
        super(source, edges, sourcedim, targetdim, dimensions, flags);
    }    

    /**
     * Constructor to use for a swap or pivot of specific dimensions.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param edges        A list of the dirty edges, if known. In this list,
     *                     to refer to edges, use the constants
     *                     <code>DataDirector.COLUMN_EDGE</code>,
     *                     <code>DataDiector.PAGE_EDGE</code>, or
     *                     <code>DataDirector.ROW_EDGE</code>.
     * @param sourcedim    The name of the source dimension for a pivot or swap.
     * @param targetdim    The name of the target dimension for a pivot or swap.
     * @param dimensions   The names of the dimensions that were affected
     *                     by the call that changed the layout. This is the same
     *                     parameter that is used in the <code>layout</code>
     *                     method call in the <code>Query</code> class.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutChangedEvent(Object source, BitSet edges, String sourcedim, String targetdim, String[][] dimensions) {
        super(source, edges, sourcedim, targetdim, dimensions);
    }        

    /**
     * Constructor to use for an edge swap.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param sourceedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the source edge for an edge swap.
     * @param targetedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the target edge for an edge swap.
     * @param dimensions The names of the dimensions that were affected
     *                   by the call that changed the layout. This is the same
     *                   parameter that is used in the <code>layout</code>
     *                   method call in the <code>Query</code> class.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public LayoutChangedEvent(Object source, int sourceedge, int targetedge, String[][] dimensions) {
        super(source, sourceedge, targetedge, dimensions);
    }        
}
