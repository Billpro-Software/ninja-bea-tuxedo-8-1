/*
 * NumberFormatsPanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.panel;

import oracle.bali.ewt.help.HelpProvider;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import oracle.dss.datautil.query.DataUtils;

import oracle.dss.datautil.gui.dialog.NumberFormatsDialog;
import oracle.dss.datautil.gui.resource.DataUtilGUIBundle;
import oracle.dss.datautil.gui.ResourceCache;
import oracle.dss.datautil.gui.StandardButton;
import oracle.dss.datautil.gui.Utils;

import oracle.dss.dataView.managers.ViewFormat;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.Localizable;

/**
 *
 * @hidden
 *
 * Creates a number format panel that allows a number format to be generated
 * based on a ViewFormat.
 *
 * @status hidden
 */

public class NumberFormatsPanel extends JPanel implements ActionListener,
                     ErrorHandlerCallback, Localizable {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * The parent component of the <code>NumberFormatsPanel</code>.
   *
   * @status private
   */
  private transient Component m_componentParent = null;

  /**
   * Determines whether the number format has been edited by the user.
   *
   * @status private
   */
  private transient boolean m_bNumberFormatEdited = false;

  /**
   * The <code>ErrorHandler</code> used to process errors.
   *
   * @status private
   */
  private transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /**
   * The <code>Locale</code> used to properly translate messages.
   *
   * @status private
   */
  private transient Locale m_locale = null;

  /**
   * Stores the resource cache.
   *
   * @status private
   */
  private ResourceCache m_resourceCache = new ResourceCache();

  /**
   * List of <code>ViewFormat</code> objects which each contain a format number
   * type and string which can be used to format numbers.
   *
   * This list of <code>ViewFormat</code> objects is used to format the numbers
   * which appear in the format combo box in the same order.
   *
   * For example the second entry in the format combo box is associated with the
   * second view format.
   *
   * @status private
   */
  private Vector m_vViewFormats = new Vector();

  /**
   * The default number that is formatted within the format combo box.
   *
   * @status private
   */
  private double m_dDefaultNumber = initDefaultNumber();

  /**
   * The default numbers that are formatted within the format combo box.
   *
   * @status private
   */
  private Vector m_vstrDefaultNumbers = initDefaultNumbers();

  /**
   * The format combo box containing a list of formatted numbers.
   *
   * @status private
   */
  private JComboBox m_jComboBoxFormat = null;

  /**
   * The format options button which invokes the <code>NumberFormatsDialog</code>.
   *
   * @status private
   */
  private StandardButton m_standardButtonOptions = null;

  /**
   * The HelpProvider.
   *
   * @status protected
   */
  protected HelpProvider m_helpProvider = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   *
   * Default <code>FormatPanel</code> constructor.
   *
   * @status hidden
   */
  public NumberFormatsPanel() {
  }

  /**
   * @hidden
   * Constructor for FormatPanel.
   *
   * There should generally be a one to one mapping between the vViewFormats
   * and their associated vStrDefaultNumbers.
   *
   * If these values are null, default values are used which are defined in
   * 'oracle.dss.datautil.gui.resource.DataUtilGUIBundle'.
   *
   * @param  locale a <code>Locale</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  errorHandler a <code>ErrorHandler</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  vViewFormats a <code>Vector</code> of <code>ViewFormat</code> objects
   *         to associate with the <code>FormatPanel</code>.
   * @param  vstrDefaultNumbers a <code>Vector</code> of <code>String</code> objects
   *         which represent the default numbers to associate with the <code>FormatPanel</code>.
   * @param  viewFormat a <code>ViewFormat</code> with represents the currently
   *         selected <code>ViewFormat</code>.  If this value is null, the first
   *         <code>ViewFormat</code> is selected.
   *
   * @return <code>FormatPanel</code> which represents a
   *         newly constructed format panel or null.
   *
   * @status hidden
   */
  public NumberFormatsPanel (Locale locale, ErrorHandler errorHandler,
                             Vector vViewFormats, Vector vstrDefaultNumbers,
                             ViewFormat viewFormat) {
    initNumberFormatsPanel (null, locale, errorHandler, vViewFormats, 
      vstrDefaultNumbers, viewFormat);
  }

  /**
   * @hidden
   * Constructor for FormatPanel.
   *
   * There should generally be a one to one mapping between the vViewFormats
   * and their associated vStrDefaultNumbers.
   *
   * If these values are null, default values are used which are defined in
   * 'oracle.dss.datautil.gui.resource.DataUtilGUIBundle'.
   *
   * @param  componentParent a <code>Component</code> value that represents the
   *         parent of the <code>NumberFormatsPanel</code>.
   * @param  locale a <code>Locale</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  errorHandler a <code>ErrorHandler</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  vViewFormats a <code>Vector</code> of <code>ViewFormat</code> objects
   *         to associate with the <code>FormatPanel</code>.
   * @param  vstrDefaultNumbers a <code>Vector</code> of <code>String</code> objects
   *         which represent the default numbers to associate with the <code>FormatPanel</code>.
   * @param  viewFormat a <code>ViewFormat</code> with represents the currently
   *         selected <code>ViewFormat</code>.  If this value is null, the first
   *         <code>ViewFormat</code> is selected.
   *
   * @return <code>FormatPanel</code> which represents a
   *         newly constructed format panel or null.
   *
   * @status hidden
   */
  public NumberFormatsPanel (Component componentParent, Locale locale, ErrorHandler errorHandler,
    Vector vViewFormats, Vector vstrDefaultNumbers, ViewFormat viewFormat) {
    initNumberFormatsPanel (componentParent, locale, errorHandler, vViewFormats, 
      vstrDefaultNumbers, viewFormat);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Initialize the <code>NumberFormatsPanel</code>.
   *
   * @param  componentParent a <code>Component</code> value that represents the
   *         parent of the <code>NumberFormatsPanel</code>.
   * @param  locale a <code>Locale</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  errorHandler a <code>ErrorHandler</code> value to associate with the
   *         <code>FormatPanel</code>.
   * @param  vViewFormats a <code>Vector</code> of <code>ViewFormat</code> objects
   *         to associate with the <code>FormatPanel</code>.
   * @param  vstrDefaultNumbers a <code>Vector</code> of <code>String</code> objects
   *         which represent the default numbers to associate with the <code>FormatPanel</code>.
   * @param  viewFormat a <code>ViewFormat</code> with represents the currently
   *         selected <code>ViewFormat</code>.  If this value is null, the first
   *         <code>ViewFormat</code> is selected.
   *
   * @status hidden
   */
  public void initNumberFormatsPanel (Component componentParent, Locale locale, 
    ErrorHandler errorHandler, Vector vViewFormats, Vector vstrDefaultNumbers,
                                                        ViewFormat viewFormat) {
    JLabel jLabelFormat = null;

    // Update the parent component
    setComponentParent (componentParent);

    // Update the locale
    setLocale (locale);

    // Add the error handler
    addErrorHandler (errorHandler);

    // Create initial panel
    setLayout (new FlowLayout (FlowLayout.LEFT));

    // Create the format label.
    jLabelFormat =
      DataUtils.getLabel(getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_FORMAT));
    jLabelFormat.setHorizontalAlignment (SwingConstants.LEFT);

    // Create the format types combo
    m_jComboBoxFormat = new JComboBox ();
    getComboBoxFormat().setEnabled (true);
    getComboBoxFormat().setEditable (false);

    // Flush the contents of the combo.
    if (m_jComboBoxFormat.getItemCount () > 0)
      getComboBoxFormat().removeAllItems ();

    // Add the default number formats
    initComboBoxFormat (getDefaultViewFormats(), getDefaultNumbers(), getComboBoxFormat());

    // Select the ViewFormat if it has been specified
    setViewFormat (viewFormat, null);

    // Associate this label with the combo box
    DataUtils.setLabelFor (jLabelFormat, getComboBoxFormat());

    // Create the options button
    setButtonOptions (new StandardButton());
    DataUtils.setLabelText (getButtonOptions(),
      getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_OPTIONS));

    // Enable Options button
    getButtonOptions().setEnabled (true);

    // Listen for option button events
    getButtonOptions().addActionListener (this);

    // Listen for combobox selection events
    getComboBoxFormat().addActionListener(this);

    // Add the above components to the Options panel
    add (jLabelFormat);
    add (Box.createRigidArea (new Dimension (5, 0)));
    add (getComboBoxFormat());
    add (Box.createRigidArea (new Dimension (5, 0)));
    add (getButtonOptions());
    add (Box.createHorizontalGlue ());
  }

	/**
   * @hidden
	 * Retrieves the currently selected <code>ViewFormat</code> associated with the
   * <code>NumberFormatsPanel</code>.
	 *
	 * @return <code>ViewFormat</code> value associated with the currently selected
   *         value in the <code>NumberFormatsPanel</code>.
	 *
	 * @status hidden
	 */
	public ViewFormat getViewFormat () {
    ViewFormat viewFormat = null;

    JComboBox jComboBoxFormat = getComboBoxFormat();
    if (jComboBoxFormat != null) {
      int nSelected = jComboBoxFormat.getSelectedIndex();
      if (nSelected != -1) {
        Vector vViewFormats = getViewFormats();
        if ((vViewFormats != null) && (!vViewFormats.isEmpty())) {
          viewFormat = (ViewFormat) vViewFormats.elementAt (nSelected);
        }
      }
    }

	  return viewFormat;
	}

	/**
   * @hidden
	 * Specifies the currently selected <code>ViewFormat</code> associated with the
   * <code>NumberFormatsPanel</code>.
	 *
	 * @param viewFormat A <code>ViewFormat</code> to be associated with the
	 *        currently selected value in the <code>FormatPanel</code>.
	 * @param strNumber a <code>String</code> that represents the number to format.
   *        If this value is null, a default value is used.
	 *
	 * @return <code>ViewFormat</code> value associated with the currently selected
   *         value in the <code>NumberFormatsPanel</code>.
   *
	 * @status hidden
	 */
	public ViewFormat setViewFormat (ViewFormat viewFormat, String strNumber) {
    ViewFormat viewFormatResult = null;

    JComboBox jComboBoxFormat = getComboBoxFormat();

    if ((jComboBoxFormat != null) && (viewFormat != null)) {
      // Update the locale
      viewFormat.setLocale (getLocale());

      // Add the ViewFormat, if it isn't already specified
      String strFormattedNumber = addViewFormat (viewFormat, strNumber);

      // Select the formatted string added
      jComboBoxFormat.setSelectedItem (strFormattedNumber);

      viewFormatResult = getViewFormat();
    }

    return viewFormatResult;
	}

	/**
   * @hidden
	 * Retrieves a default number based on the specified <code>ViewFormat</code>.
   *
	 * @param viewFormat A <code>ViewFormat</code> to be used to determine
   *        the default number returned
   *
   * @return <code>double</code> that represents the default number associated
   *         with the specified <code>ViewFormat</code>.
   *
	 * @status hidden
	 */
  public double getDefaultNumber (ViewFormat viewFormat) {

    double dNumber = getDefaultNumber();

    if (viewFormat != null) {

      // Determine the Number type (e.g. general, currency or percent)
      int nNumberType = DataUtils.getNumberType (viewFormat);

      // Retrieve a default number based on the specified ViewFormat number type
      switch (nNumberType) {
        // case DEFAULT_NUM_TYPE:
        case ViewFormat.NUMTYPE_GENERAL:
          dNumber =
            getNumber (getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_GENERAL));
          break;

        case ViewFormat.NUMTYPE_CURRENCY:
          dNumber =
            getNumber (getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_CURRENCY));
          break;

        case ViewFormat.NUMTYPE_PERCENT:
          dNumber =
            getNumber (getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_PERCENT));
          break;

        default:
          break;
      }
    }

    return dNumber;
  }

  /**
   * @hidden
   * Adds the specified <code>ViewFormat</code> to the <code>JComboBox</code>
   * if it doesn't already exist.
   *
	 * @param viewFormat a <code>ViewFormat</code> used to format the number.
	 * @param strNumber a <code>String</code> that represents the number to format.
   *        If this value is null, a default value is used.
   *
	 * @return <code>String</code> value which represents the formatted value added
   *         to the combo box.
   *
   * @status hidden
   */
  public String addViewFormat (ViewFormat viewFormat, String strNumber) {

    double dNumber = getDefaultNumber();

    if (strNumber != null) {
      dNumber = getNumber (strNumber);
    }
    else {
      dNumber = getDefaultNumber (viewFormat);
    }

    return addViewFormat (viewFormat, dNumber, getComboBoxFormat());
  }

  /**
   * @hidden
   * Adds the specified <code>ViewFormat</code> and number value to the
   * chosen <code>JComboBox</code> if it doesn't already exist.
   *
	 * @param viewFormat a <code>ViewFormat</code> used to format the number.
	 * @param dNumber a <code>double</code> which is to be formatted.
   * @param jComboBox a <code>JComboBox</code> add formatted number to .
   *
	 * @return <code>String</code> value which represents the formatted value added
   *         to the combo box.
   *
   * @status hidden
   */
  public String addViewFormat (ViewFormat viewFormat, double dNumber, JComboBox jComboBox) {
    String strFormattedNumber = null;

    // Make sure that our ViewFormat and JComboBox are non-null
    if ((viewFormat != null) && (jComboBox != null)) {
      // Format the chosen number

      // For now, we will only display the negative representation of the
      // ViewFormat
      strFormattedNumber = viewFormat.DoubleToString (-dNumber);

      // Retrieve the list of current viewFormats
      Vector vViewFormats = getViewFormats();

      if (vViewFormats != null) {
        // Make sure that our formatted number is not null
        if (strFormattedNumber != null) {
          // Iterate over all the formatted numbers in the combobox
          for (int nIndex = 0; nIndex < jComboBox.getItemCount(); nIndex++) {
            // Retrieve the formatted number at the current position
            String strValue = (String) jComboBox.getItemAt (nIndex);

            // gek 05/20/02 Fix Bug 2363127: Number format does not scale above
            //              billions without abbreviation
            //
            // If the formatted number associated with the ViewFormat already exists,
            // replace the previous formatted value/ViewFormat with the new one.
            if (strValue.equals (strFormattedNumber)) {
              // Remove ViewFormat at the current position
              vViewFormats.removeElementAt (nIndex);

              // Remove the formatte number at the current position
              jComboBox.removeItemAt (nIndex);
              break;
            }
          }

          // Add the formatted number to the combo box
          jComboBox.addItem (strFormattedNumber);

          // Add the ViewFormat associated with the formatted number
          vViewFormats.addElement (viewFormat);
        }
      }
    }

    // Return the formatted number
    return strFormattedNumber;
  }

  /**
   * @hidden
   * Initializes the number format strings used for the format combo box.
   *
	 * @param vViewFormats a <code>Vector</code> of <code>ViewFormat</code> objects
   *        used to format the default number.
	 * @param vstrNumbers a <code>Vector</code> values which is formatted by each
   *        <code>ViewFormat</code>.
   * @param jComboBox a <code>JComboBox</code> to initialize.
   *
   * @status hidden
   */
  public void initComboBoxFormat (Vector vViewFormats, Vector vstrNumbers, JComboBox jComboBox) {
    // Check sure that we have some ViewFormats to process
    if ((vViewFormats != null) && (!vViewFormats.isEmpty())) {
      // Check to make sure that ComboBox has been specfied
      if (jComboBox != null) {
        // Iterate over each ViewFormat
        for (int nIndex = 0; nIndex < vViewFormats.size(); nIndex++) {
          // Retrieve the ViewFormat at the current index
          ViewFormat viewFormat = (ViewFormat)vViewFormats.elementAt (nIndex);

          // Only process non-null ViewFormats
          if (viewFormat != null) {
            // Retrieve a default number
            double dNumber = getDefaultNumber(viewFormat);

            // Check to see if a list of numbers is specified, if not use
            // default number
            if ((vstrNumbers != null) && (nIndex < vstrNumbers.size())) {
              // Retrieve the number
              String strDouble = (String) vstrNumbers.elementAt(nIndex);

              // Make sure that the number isn't null
              if (strDouble != null) {
                // Attempt to create a Double out of the String
                Double doubleNumber = new Double (strDouble);

                // Make sure that we could convert the string to a Double object
                if (doubleNumber != null) {
                  // Retrieve the double value associated with the Double object
                  dNumber = doubleNumber.doubleValue();
                }
              }
            }

            // Format the number based on the currently specifed ViewFormat
            addViewFormat (viewFormat, dNumber, jComboBox);
          }
        }
      }
    }
  }

	/**
   * @hidden
	 * Retrieves the parent component.
	 *
	 * @return <code>Component</code> value which represents the parent component.
	 *
	 * @status hidden
	 */
	public Component getComponentParent() {
	  return m_componentParent;
	}

	/**
   * @hidden
	 * Specifies the parent component.
	 *
	 * @param componentParent A <code>Component</code> value which represents the
   *        parent component.
	 *
	 * @status hidden
	 */
	public void setComponentParent (Component componentParent) {
	  m_componentParent = componentParent;
	}

	/**
   * @hidden
	 * Retrieves the format combo box.
	 *
	 * @return <code>JComboBox</code> value which contains a list of formatted numbers.
	 *
	 * @status hidden
	 */
	public JComboBox getComboBoxFormat () {
	  return m_jComboBoxFormat;
	}

	/**
   * @hidden
	 * Specifies the format combo box.
	 *
	 * @param jComboBox A <code>JComboBox</code> value which contains a list of formatted numbers.
	 *
	 * @status hidden
	 */
	public void setComboBoxFormat (JComboBox jComboBox) {
	  m_jComboBoxFormat = jComboBox;
	}

	/**
   * @hidden
	 * Retrieves the format options button which invokes the <code>NumberFormatsDialog</code>.
	 *
	 * @return <code>StandardButton</code> value which represents the format
   *         options button which invokes the <code>NumberFormatsDialog</code>..
	 *
	 * @status hidden
	 */
	public StandardButton getButtonOptions() {
	  return m_standardButtonOptions;
	}

	/**
   * @hidden
	 * Specifies the format options button which invokes the <code>NumberFormatsDialog</code>.
	 *
	 * @param standardButton A <code>StandardButton</code> value which specifies the format
   *        options button which invokes the <code>NumberFormatsDialog</code>.
	 *
	 * @status hidden
	 */
	public void setButtonOptions (StandardButton standardButton) {
	  m_standardButtonOptions = standardButton;
	}

  /**
   * @hidden
   * Retrieves the default number that is formatted within the format combo box.
	 *
	 * @return <code>double</code> value associated with default number that is
   *         formatted within the format combo box.
	 *
	 * @status hidden
	 */
	public double getDefaultNumber() {
	  return m_dDefaultNumber;
	}

	/**
   * @hidden
	 * Specifies the default number that is formatted within the format combo box.
	 *
	 * @param dDefaultNumber A <code>double</code> value that is formatted within the
   *        format combo box.
	 *
	 * @return <code>double</code> value associated with default number that is
   *         formatted within the format combo box.
   *
	 * @status hidden
	 */
	public double setDefaultNumber (double dDefaultNumber) {
	  m_dDefaultNumber = dDefaultNumber;
    return dDefaultNumber;
	}

  /**
   * @hidden
   * Retrieves a list of default numbers that are formatted for each
   * <code>ViewFormat</code> within the format combo box.
	 *
	 * @return <code>Vector</code> value that contains a list of default numbers that
   *         are formatted for each <code>ViewFormat</code> entry in the format combo box.
   *
   * @see #getViewFormats
	 *
	 * @status hidden
	 */
	public Vector getDefaultNumbers() {
	  return m_vstrDefaultNumbers;
	}

	/**
   * @hidden
	 * Specifies a list of default numbers that are formatted for each
   * <code>ViewFormat</code> within the format combo box.
	 *
	 * @param vstrDefaultNumbers A <code>Vector</code> of <code>String</code> values
   *        that are formatted within the format combo box.
	 *
	 * @return <code>Vector</code> value containing the list of <code>String</code>
   *         values formatted within the format combo box.
   *
	 * @status hidden
	 */
	public Vector setDefaultNumbers (Vector vstrDefaultNumbers) {
	  m_vstrDefaultNumbers = vstrDefaultNumbers;
    return vstrDefaultNumbers;
	}

	/**
   * @hidden
	 * Retrieves the list of available <code>ViewFormat</code> objects associated
   * with the <code>NumberFormatsPanel</code>.
	 *
	 * @return <code>Vector</code> of code>ViewFormat</code> objects associated
   *         with the <code>NumberFormatsPanel</code>.
	 *
	 * @status hidden
	 */
	public Vector getViewFormats() {
	  return m_vViewFormats;
	}

	/**
   * @hidden
	 * Specifies the list of available <code>ViewFormat</code> objects associated
   * with the <code>NumberFormatsPanel</code>.
	 *
	 * @param viewFormat A <code>ViewFormat</code> to be associated with the
	 *        currently selected value in the <code>FormatPanel</code>.
	 *
	 * @status hidden
	 */
	public void setViewFormats (Vector vViewFormats) {
	  m_vViewFormats = vViewFormats;
	}

  /**
   * @hidden
   * Retrieves a <code>Vector</code> of default <code>ViewFormat</code> objects
   * based on number format types and strings stored in the
   * <code>DataUtilGUIBundle</code>.
   *
   * The order of the default view formats should be in the same order as found
   * in initDefaultNumbers().
   *
 	 * @return <code>Vector</code> value that contains the list of default
   *         <code>ViewFormat</code> objects.
   *
   * @status hidden
   */
  public Vector getDefaultViewFormats() {
    Vector vViewFormats = new Vector();
 
    // Default Number 1
    // -9,999
    String strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_3);
    String strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_3);

    ViewFormat viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 2
    // (9,999)
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_5);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_5);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 3
    // -9,999.00
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_6);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_6);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 4
    // (9,999.00)
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_10);

    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_10);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 5
    // ($9,999.00)
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_7);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_7);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 6
    // -$9,999.00
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_8);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_8);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 7
    // -99%
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_11);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_11);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    // Default Number 8
    // (99%)
    strNumberType = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_TYPE_12);
    strNumberString = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_STRING_12);

    viewFormat = Utils.getViewFormat (strNumberType, strNumberString, getLocale());
    if (viewFormat != null)
      vViewFormats.add (viewFormat);

    return vViewFormats;
  }

  //-----------------------------------------------------------------------
  // Begin - Implementation of the Localizable interface
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Retrieves the locale associated with a object.
   *
   * @return <code>Locale</code> which represents the locale setting for this
   *         object, or the the system default locale, if not locale has been
   *         explicitly set.
   *
   * @status hidden
   */
  public Locale getLocale() {
    return m_locale;
  }

  /**
   * @hidden
   * Specifies the locale used by this object.
   *
   * @param locale A <code>Locale</code> value that represents the locale to use
   *               for proper translation.
   *
   * @status hidden
   */
  public void setLocale (Locale locale) {
    if (getResourceCache() != null) {
  		getResourceCache().setLocale (locale);
    }
    
    m_locale = locale;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the Localizable interface
  //-----------------------------------------------------------------------

  //-----------------------------------------------------------------------
  // Start- Implementation of the ErrorHandlerCallback interface
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Adds a single error handler to the bean.
   * The bean then calls the error handler with error messages,
   * messages about abnormal situations, and trace messages.
   *
   * @param errorHandler a <code>ErrorHandler</code> value to associate with the
   *        <code>FormatPanel</code>.
   *
   * @status hidden
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * @hidden
   * Removes the error handler from the bean.
   *
   * @status hidden
   */
  public void removeErrorHandler() {
    m_errorHandler = null;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the ErrorHandlerCallback interface
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> value which represents the current error
   *          handler.
   * @status hidden
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  //-------------------------------------------------------------------
  // Start Implementation of Action Listener
  //-------------------------------------------------------------------

	/**
   * @hidden
	 * Listen for events associated with the Options button.
	 *
   * @param actionEvent a <code>ActionEvent</code> value that represents the
   *        event to process.
	 *
	 * @status hidden
	 */
  public void actionPerformed (ActionEvent event) {

    // Display the NumberFormatsDialog when the options button is pressed
    if (event.getSource() == getButtonOptions()) {
      displayNumberFormatsDialog();
    }
    else if (event.getSource() == getComboBoxFormat()) {
      // Remember when the user has selected a number format from the combobox
      setNumberFormatEdited (true);
    }
  }

  //-------------------------------------------------------------------
  // End Implementation of Action Listener
  //-------------------------------------------------------------------

  //-------------------------------------------------------------------
  // Start Implementation of HelpContext interface
  //-------------------------------------------------------------------

  /**
   * @hidden
   *
   * Retrieves the Help context ID for this panel.
   * The default Help context ID is the full class path for this panel.
   * To set a different Help context ID, use the method
   * <code>setHelpContextID(String)</code>.
   *
   * The Help context ID that is used when listening for the user event
   * that requests the display of Help for this panel.
   *
   * @return The Help context ID for this panel
   *
   * @status hidden
   */
  public String getHelpContextID() {
    return this.getClass().getName();
	}

  //-------------------------------------------------------------------
  // End Implementation of HelpContext interface
  //-------------------------------------------------------------------


  /**
   * @hidden
   * Retrieves the HelpProvider for this <code>NumberFormatsPanel</code>.
   *
   * @return <code>HelpProvider</code> value which is used to provide help for
   *         the <code>NumberFormatsPanel</code>.
   *
   * @status hidden
   */
  public HelpProvider getHelpProvider() {
    return m_helpProvider;
  }

  /**
   * @hidden
   * Specifies the HelpProvider for this <code>NumberFormatsPanel</code>.
   *
   * @param helpProvider a <code>HelpProvider</code> value that is used to provide
   *        help for the <code>NumberFormatsPanel</code>.
   *
   * @status hidden
   */
  public void setHelpProvider (HelpProvider helpProvider) {
    m_helpProvider = helpProvider;
  }

  /**
   * @hidden
   *
   * Determines whether the number format has been edited by the user.
   *
   * @return <code>boolean</code> value which is <code>true</code> when the
   *         number format has been edited by the user, and false otherwise.
   *
   * @status private
   */
  public boolean isNumberFormatEdited() {
    return m_bNumberFormatEdited;
  }

  /**
   * @hidden
   *
   * Determines whether the number format has been edited by the user.
   *
   * @param bNumberFormatEdited a <code>boolean</code> value that is
   *        <code>true</code> when the number format has been edited by the user,
   *        and false otherwise.
   *
   * @status private
   */
  public void setNumberFormatEdited (boolean bNumberFormatEdited) {
    m_bNumberFormatEdited = bNumberFormatEdited;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Retrieves the <code>ResourceCache</code> used by the <code>FormatPanel</code>.
   *
   * @return <code>ResourceCache</code> value which is used to retrieve resources.
   *
   * @status protected
   */
  protected ResourceCache getResourceCache() {
    return m_resourceCache;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Display the <code>NumberFormatsDialog</code>.
   *
   * @status private
   */
  private void displayNumberFormatsDialog () {

    NumberFormatsDialog numberFormatsDialog;

    Component componentParent = getComponentParent();
    if (componentParent instanceof Frame) {
      // Create the number format dialog
      numberFormatsDialog =
        new NumberFormatsDialog ((Frame) componentParent,
          getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_DIALOG_TITLE),
            true, getViewFormat());
    }
    else {
      if (componentParent instanceof Dialog) {
        // Create the number format dialog
        numberFormatsDialog =
          new NumberFormatsDialog ((Dialog) componentParent,
            getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_DIALOG_TITLE),
              true, getViewFormat());
      }
      else {        
        // Create the number format dialog
        numberFormatsDialog =
          new NumberFormatsDialog ((Frame) null,
            getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_DIALOG_TITLE),
              true, getViewFormat());
      }
    }

    // gek 05/22/02 Fix Bug 2377713: Need help hookup for Number Format dialog
    //              in CalcBuilder.
    //
    //              Set the NumberFormatsDialog HelpProvider
    numberFormatsDialog.setHelpProvider (getHelpProvider());

    // Specify the locale
    numberFormatsDialog.setLocale(getLocale());

    // Specify the error handler
    numberFormatsDialog.addErrorHandler(getErrorHandler());

    // Display the dialog
    boolean bResult = numberFormatsDialog.runDialog();

    // If the user pressed OK, update the ViewFormat
    if (bResult) {
      // Select the ViewFormat based on value specified in dialog
      setViewFormat (numberFormatsDialog.getViewFormat(), null);
    }
  }

  /**
   * Initializes the <code>Vector</code> of default numbers that are formatted
   * within the format combo box.
   *
   * The order of the default numbers should be in the same order as found
   * in getDefaultViewFormats().
   * 
	 * @return <code>Vector</code> of <code>String</code> values that represents the
   *         default numbers.
   *
   * @see #getDefaultViewFormats
   * 
   * @status private
   */
  private Vector initDefaultNumbers() {
    // Create an empty vector
    Vector vstrDefaultNumbers = new Vector();

    // Attempt to retrieve the default values from the resource bundle
    String strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_3);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_5);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_6);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_10);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_7);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_8);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_11);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    // Attempt to retrieve the default values from the resource bundle
    strDefaultNumber = getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_12);

    // Verify that we have a non-null value
    if (strDefaultNumber != null) {
      vstrDefaultNumbers.addElement (strDefaultNumber);
    }

    return vstrDefaultNumbers;
  }

  /**
   * Retrieves the <code>double</code> value associated with the specified
   * number format string.
   *
   * @param strNumber a <code>String</code> value that represents the
   *        event to process.
   *
	 * @return <code>double</code> value that represents the default number.
   *
   * @status private
   */
  private double getNumber (String strNumber) {
    // Set some reasonable value
    double dNumber = 99999.00;

    // Verify that we have a non-null value
    if (strNumber != null) {
      // Parse the string into a Double
      Double doubleNumber = new Double (strNumber);

      // If we have retrieved a non-null Double, attempt to retrive its value
      if (doubleNumber != null) {
        dNumber = doubleNumber.doubleValue();
      }
    }

    return dNumber;
  }

  /**
   * Initializes the default number that is formatted within the format combo box.
   *
	 * @return <code>double</code> value that represents the default number.
   *
   * @status private
   */
  private double initDefaultNumber() {

    double dNumber =
      getNumber (getIntlString(DataUtilGUIBundle.NUMBER_FORMAT_NUMBER_GENERAL));

    return setDefaultNumber(dNumber);
  }

  /**
   * Retrieves the value associated with the specified key from the appropriate
   * resource file.
   *
	 * @return <code>String</code> value that represents the value.
   *
   * @status private
   */
  private String getIntlString (String strKey) {

    if ((strKey != null) && (getResourceCache() != null))
      return getResourceCache().getIntlString (strKey);

    return strKey;
  }
}
