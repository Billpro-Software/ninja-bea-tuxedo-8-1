/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.bicontext;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import javax.naming.directory.DirContext;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * Utility methods for BIContext package.
 *
 * @hidden
 */
public class BIUtilities
{
    private static final String STAR = "\\2a";
    private static final String BACKSLASH = "\\5c";
    private static ArrayList s_containers = new ArrayList(5);

    static
    {
        s_containers.add(PersistableConstants.FOLDER);
        s_containers.add(PersistableConstants.WORKBOOK);
    }

    /**
     * Checks whether the underlying object is a container (folder or workbook).
     *
     * @param objType a String representing an object type
     * @return <code>true</code> if the underlying object is a container
     *         <code>false</code> otherwise
     */
    public static boolean isContainer(String objType)
    {
        return s_containers.contains(objType);
    }

    /**
     * Checks whether the underlying object is a container (folder or workbook).
     *
     * @param entry a BISearchResult object whose type needs to be checked.
     * @return <code>true</code> if the underlying object is a container
     *         <code>false</code> otherwise
     */
    public static boolean isContainer(BISearchResult entry)
    {
        if (entry != null)
        {
            BISearchResult _entry = (BISearchResult)entry;
    	    String _type = _entry.getObjectType();
            return isContainer(_type);
        }
        else
            return false;
    }

    /**
     * Checks whether the underlying object is a container (folder or workbook).
     * @param ctx a DirCtx object.
     * @param entry a BISearchResult object whose type needs to be checked.
     * @return <code>true</code> if the underlying object is a container
     *         <code>false</code> otherwise
     */
    public static boolean isContainer(DirContext ctx, BISearchResult entry)
    {
        return ((ctx != null) || isContainer(entry));
    }

    /**
     * Register a new container type
     */
    public static void registerContainer(String type)
    {
        s_containers.add(type);
    }

    /**
     * Un-register a new container type
     */
    public static void unregisterContainer(String type)
    {
        s_containers.remove(type);
    }

    /**
     * Filters date precision based on BISearchControls
     */
    public static Object filterDatePrecision(Object object, BISearchControls cons)
    {
        if (!(object instanceof java.util.Date))
        {
            return object;
        }

        GregorianCalendar _calendar = new GregorianCalendar();
        _calendar.setTime((Date)object);

        switch (cons.getTimePrecision())
        {
            case BISearchControls.DATE:
                _calendar.set(Calendar.HOUR, 0);
                _calendar.set(Calendar.AM_PM, Calendar.AM);
            case BISearchControls.HOUR:
                _calendar.set(Calendar.MINUTE, 0);
            case BISearchControls.MINUTE:
                _calendar.set(Calendar.SECOND, 0);
            case BISearchControls.SECOND:
                _calendar.set(Calendar.MILLISECOND, 0);
        }
        return _calendar.getTime();
    }

    /**
     * Checks whether two strings are the name, taken consideration of wildcard
     * and case sensitivity
     */
    public static boolean equals(String exact, String partial, boolean isCaseSensitive)
    {
        if (exact == null || partial == null)
            return false;

        if (!isCaseSensitive)
        {
            exact = exact.toLowerCase();
            partial = partial.toLowerCase();
        }

        if (!partial.startsWith("*"))
        {
            int _index = partial.indexOf("*");
            if (_index > 0)
            {
                String _startsWith = convertEscape(convertEscape(partial.substring(0, _index), STAR), BACKSLASH);
                if (!exact.startsWith(_startsWith))
                    return false;
            }
            else
            {
                return exact.equals(convertEscape(convertEscape(partial, STAR), BACKSLASH));
            }
        }

        if (!partial.endsWith("*"))
        {
            int _index = partial.lastIndexOf("*");
            if (_index > -1)
            {
                String _endsWith = convertEscape(convertEscape(partial.substring(_index+1), STAR), BACKSLASH);
                if (!exact.endsWith(_endsWith))
                    return false;
            }
        }

        return checkMatch(exact, partial);
    }

    public static boolean checkMatch(String exact, String partial)
    {
        String _exact = exact;
        StringTokenizer _tokenizer = new StringTokenizer(partial, "*");
        while (_tokenizer.hasMoreTokens())
        {
            String _token = convertEscape(convertEscape(_tokenizer.nextToken(), STAR), BACKSLASH);
            int _match = _exact.indexOf(_token);
            if (_match < 0)
                return false;
            else
                _exact = _exact.substring(_match+_token.length());
        }
        return true;
    }

    private static String convertEscape(String token, String escape)
    {
        String _token = token;
        int _esc = 0;
        while (_esc > -1)
        {
            _esc = _token.toLowerCase().indexOf(escape.toLowerCase());
            if (_esc >= 0)
                _token = _token.substring(0, _esc)+getEscape(escape)+_token.substring(_esc+escape.length());
        }
        return _token;
    }

    private static String getEscape(String escape)
    {
        if (escape.equals(STAR))
            return "*";
        else if (escape.equals(BACKSLASH))
            return "\\";
        else
            return "";
    }
}