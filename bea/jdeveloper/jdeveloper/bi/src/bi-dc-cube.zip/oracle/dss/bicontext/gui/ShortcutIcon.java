/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.bicontext.gui;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import oracle.bali.ewt.graphics.ImageUtils;

/**
 * @hidden
 */
public class ShortcutIcon extends ImageIcon
{    
    private Icon bottom, top;    

    public ShortcutIcon(ImageIcon orig, ImageIcon modifier)
    {
        super(orig.getImage());
        this.bottom = orig;
        this.top = modifier;
    }

    public int getIconWidth()
    {
        return Math.max(bottom.getIconWidth(), top.getIconWidth());
    }

    public int getIconHeight()
    {
        return Math.max(bottom.getIconHeight(), top.getIconHeight());
    }

    public void paintIcon(Component component, Graphics g, int x, int y)
    {
        bottom.paintIcon(component, g, x, y);
        top.paintIcon(component, g, x, y);
    }
}
