/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

// Imports
import java.util.Locale;
//import oracle.jbo.ComponentObject;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.connection.common.ConnectionException;

/**
 *  @hidden
 *  ConnectionObject. BC4J-centric bundling
 *  of middle-tier methods that must "cross the wire."
 */
public interface ConnectionObject
{

  /************************************************************************
  * Applet Support
  ************************************************************************/

  public int setApplet(java.applet.Applet applet);

  /************************************************************************
  * Connection Support
  ************************************************************************/
	// is connected?
	public boolean isConnected();

	// connect
	public ConnectionObj connect( ConnectionObj connectionObj, PropertyBag properties ) 
																	throws ConnectionException;

	// disconnect
	public ConnectionObj disconnect ( PropertyBag properties )
																	throws ConnectionException;

  /************************************************************************
  * SPL Support.
  ************************************************************************/
	// This can be for hooking up for supporting SPL, SQL etc.
	public String executeCommand ( String command, PropertyBag properties )
																	throws ConnectionException;
  
  // Evaluates an SPL Expression and gets the results back. 
  // The Expression Type is the data type of the expected 
  // result such as string, long, decimal etc.
  public Object evaluateExpression(String expression, PropertyBag properties )
																	throws ConnectionException;

  /************************************************************************
  * Operations on the objects that only exist on the source platform.
  ************************************************************************/
	// get the driver specific objects from the driver
	public Object getDriverSpecificObject( PropertyBag properties )
																	throws ConnectionException;

	// set the driver specific objects from the driver
	public int setDriverSpecificObject( Object object, PropertyBag properties )
																	throws ConnectionException;

	// remove the driver specific objects at the driver
	public int removeDriverSpecificObjects( PropertyBag properties )
																	throws ConnectionException;

	public Property getServerProperty ( String propertyName )
                                throws ConnectionException;

	public int setServerProperty( Property property )
                                throws ConnectionException;

  // Gets the connection structure from the middle tier.
  public ConnectionObj getConnectionObj()
                                throws ConnectionException;

  // Sets the Connection on the middle tier.
  public int setConnectionObj(ConnectionObj connectionObj)
                                 throws ConnectionException;

  public int free() throws ConnectionException;

  public Object getRemoteConnection();
  public void setRemoteConnection(Object proxy);
  public void setLocale(Locale locale);
  public Locale getLocale();
  public boolean isAlive();
  public PropertyBag getVersionInfo();

    public boolean getFeature(String feature);
}