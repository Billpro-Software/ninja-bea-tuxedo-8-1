/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.directory.Attributes;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * The BIShortcutFilter class is a custom <code>BIFilter</code> for filtering
 * types of objects and their shortcuts that are returned by any of the search
 * methods.
 *
 * This object is set on the <code>BISearchControls</code> object using the
 * <code>setResultFilter</code> method.
 *
 * Usage example: To select all graphs and all shortcuts to graphs that were
 * created by a specific user, requires the following steps:
 *
 * <ol>
 * <li>Create the matching attributes in the <code>BIContext.search</code>
 * method to specify the following selections:
 * <ul>
 * <li>For OBJECT_TYPE, select graph objects and shortcut objects.</li>
 * <li>For CREATED_BY, select the specific user.</li>
 * </ul>
 * This selection produces results that include shortcut objects that are
 * created by the specific user but do not link to graphs, if there are such
 * shortcuts in the Catalog.</li>
 * <li>To filter out the non-Graph shortcuts, create a <code>BIShortcutFlter</code>
 * that specifies <code>PSRConstants.Attributes.GRAPH</code>
 * in the <code>types</code> parameter.</li>
 * <li>Use the <code>setResultFilter</code> method of the
 * <code>BIControls</code> object to apply the BIShortcutFilter to the search.</li></ol>
 *
 * @see BIContext
 * @see BISearchControls
 * @see oracle.dss.util.persistence.PersistableConstants.Attributes
 *
 * @status Documented
 */
public class BIShortcutFilter implements BIFilter
{
    private final String[] m_types;

    /**
     * Constructor.
     *
     * @param types The types of objects for which you want to return shortcuts.
     *              For valid values see <code>PSRConstants.Attributes</code>
     *
     * @status documented
     */
    public BIShortcutFilter(String[] types)
    {
        m_types = types;
    }

    /**
     * Implementation of the BIFilter interface.  This method evaluates each
     * result that is returned by the search and determines which objects to
     * keep based on the object types that are specified.
     *
     * Important: An application should never call this method.
     *
     * @param result Search result to evaluate.
     *
     * @return <code>true</code> if the result should be returned;
     *         <code>false</code> if otherwise.
     *
     * @status documented
     */
    public boolean evaluate(BISearchResult result)
    {
        Attributes _attrs = result.getAttributes();
        try
        {
            if (PersistableConstants.SHORTCUT.equals(result.getObjectType()))
            {
                if (_attrs.get(PersistableConstants.Attributes.COMPSUBTYPE1) != null)
                {
                    String _target = (String)_attrs.get(PersistableConstants.Attributes.COMPSUBTYPE1).get();
                    for (int i=0; i<m_types.length; i++)
                    {
                        if (m_types[i].equals(_target))
                            return true;
                    }
                    return false;
                }
                else
                    return false;
            }
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
}