/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.client;

import java.io.Serializable;

import java.util.EventObject;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.ResourceBundle;
import java.util.Locale;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.ModificationItem;

import oracle.dss.bicontext.BINamingException;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.Privilege;

import oracle.dss.connection.common.BISession;

import oracle.dss.metadataUtil.*;

import oracle.dss.connection.common.CB;
import oracle.dss.connection.common.ConnectionObject;
import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.ConnectionListener;
import oracle.dss.connection.common.ConnectionEvent;
import oracle.dss.connection.common.ConnectionException;

import oracle.dss.metadataManager.common.*;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;
import oracle.dss.metadataManager.client.resource.MetadataManagerClientBundle;

import oracle.dss.persistence.PSRConstants;

import oracle.dss.util.persistence.AggregateInfo;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.PersistableConstants;

import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.BIXMLException;
import oracle.dss.util.xml.XMLObjectWriter;
import oracle.dss.util.xml.XMLObjectReader;

import oracle.dss.util.BIException;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.Comparison;

/**
 * The main client-side class of the MetadataManager bean.
 * The MetadataManager consolidates access to metadata from multiple connections.
 * For example, you might have metadata stored in an analytic workspace and in
 * the BI Beans Catalog.
 * The MetadataManager consolidates these sources of metadata to give you
 * unified access to the metadata.
 *
 * @status Reviewed
 */
public class MetadataManager implements MetadataManagerServices, Comparison, Serializable, /*CallbackObject,*/ Persistable, ErrorHandlerCallback, ConnectionListener
{
    private boolean m_DEBUG = false;

    /************************************************************************
    * Private members
    ************************************************************************/
    // Root
    private MDRoot m_MDRoot = null;

    // Cache that contains only the client side cache
    private MDIndex m_MDIndex = null;

    // All Connections
    private  Vector m_Connections = null;

    // Localized resources
    protected static ResourceBundle m_Resources = null;

    // This is the Proxy object that represent the
    // middle tier component oc MetadataManager Bean.
    protected  MetadataManagerObject m_MetadataManagerProxy = null;

    // The instance ID. This is a  static member.
    private static int m_InstanceID = 0;

    // Is Design Time connection is OK?
    private boolean m_IsRemoteOK = true;

    private MDContentBag m_MetadataModifiedEventCache = null;

    // For event handling
    private MetadataManagerEventSupport m_EventSupport;

    private boolean m_IsBatchEventMode = false;

    private int m_Depth = MM.LARGE_DATABASE;

    private Hashtable m_handlers;

    // a hashtable that stores object types and their caching semantics
    private Hashtable m_cachingSemantics;

    private transient Locale m_Locale = Locale.getDefault();

    private static final String s_xmlNameTag = "MetadataManager";
    private static final int s_xmlVersion = 1;

    private ErrorHandler m_eh;

    private boolean m_savePersistenceConnection = true;
    private BISession m_session;
    //    private ObjectFactory m_factoryProxy;
    private Hashtable m_factoryProxies;

    // a hashtable that stores environment properties
    private Hashtable m_envProps = new Hashtable(10);

    // MDInitializer
    private OrderedHashtable m_mdInitializer;

    // driverType is the key and driverImpl is the value
    private Hashtable m_driverImpl;

    // signals whether the ObjectFactory from PersistenceManager have been used
    private boolean m_remoteFactoryUsed = false;

    //private Vector m_runtimeDatasources;

    /************************************************************************
    * Public methods
    ************************************************************************/
    /**
     * Default constructor.
     *
     * @throws MetadataManagerException If a problem occurs during the
     *         initialization of this <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public MetadataManager() throws MetadataManagerException
    {
        m_MDRoot = new MDRoot();
        init();
    }

    /**
     * @hidden
     * Constructor that takes a property bag.
     * A property bag allows you to set properties on this
     * <code>MetadataManager</code>.
     *
     * @param propertyBag   Properties for this <code>MetadataManager</code>.
     *
     * @throws MetadataManagerException If a problem occurs during the
     *         initialization of this <code>MetadataManager</code>.
     *
     * @status hidden; for internal use by JDev integration team
     */
    public MetadataManager ( PropertyBag propertyBag ) throws MetadataManagerException
    {
        m_MDRoot = new MDRoot();
        m_MDRoot.setPropertyBag( propertyBag, MDU.KEEP );
        init();
    }

   	/**
     * Specifies the session to which this <code>MetadataManager</code> object
     * belongs.
     *
     * @param session  The <code>BISession</code> to which this MetadataManager
     *                 object belongs.
     *
     * @status Reviewed
     */
    public synchronized void setSession(BISession session)
    {
        m_session = session;
        if (m_session != null)
        {
            if (m_session.getErrorHandler() != null)
                m_eh = m_session.getErrorHandler();

            if (m_session.getLocale() != null)
                setLocale(m_session.getLocale());
                
            m_envProps.put(MM.BISESSION, m_session);
        }
    }

   	/**
     * Retrieves the session to which this <code>MetadataManager</code> object
     * belongs.
     *
     * @return The <code>BISession</code> to which this MetadataManager
     *         object belongs.
     *
     * @status Reviewed
     */
    public synchronized BISession getSession()
    {
        return m_session;
    }

    /**
     * @hidden
     */
    public void addToEnvironment(Object key, Object value)
    {
        if (key != null && value != null)
            m_envProps.put(key, value);
    }
    
    /**
     * @hidden
     */
    public Hashtable getEnvironment()
    {
        return m_envProps;
    }

   	/**
     * @hidden
     * Initializes instance variables of MetadataManager.
     *
     * @throws MetadataManagerException if initHandlers() method throws MetadataManagerException
     *
     * @status private
     */
    private void init() throws MetadataManagerException
    {
        //        m_factoryProxy = new FactoryProxy();
        m_factoryProxies = new Hashtable(2, 2);
        //m_factoryProxies.put(MDU.PERSISTENCE, new FactoryProxy(MDU.PERSISTENCE));
        //m_factoryProxies.put(MDU.DISCOVERER, new FactoryProxy(MDU.DISCOVERER));
        m_handlers = new Hashtable(5, 5);

        m_MDIndex     = new MDIndex();
        m_Connections = new Vector();
        m_EventSupport = new MetadataManagerEventSupport( this );
        //m_runtimeDatasources = new Vector();
        m_driverImpl = new Hashtable();
        m_driverImpl.put(MDU.MDM, "oracle.dss.metadataManager.server.drivers.mdm.MDMMetadataDriverImpl");
        m_driverImpl.put(MDU.ECM, "oracle.dss.metadataManager.server.drivers.ecm.ECMMetadataDriverImpl");
        m_driverImpl.put(MDU.PERSISTENCE, "oracle.dss.metadataManager.server.drivers.persistence.PersistenceMetadataDriverImpl");
        m_driverImpl.put(MDU.DISCOVERER, "oracle.dss.metadataManager.server.drivers.disco.DiscovererMetadataDriverImpl");
        m_driverImpl.put(MDU.SBA, "oracle.dss.metadataManager.server.drivers.sba.SBAMetadataDriverImpl");
        m_InstanceID++;
        m_MDRoot.setMetadataManagerName( "MetadataManager_" + Integer.toString(getInstanceID() ).trim());
        setAttachStatus(MM.NOT_ATTACHED);
        m_eh = new DefaultErrorHandler();
        
        // Initailize MDInitializer OrderedHashtable and set default MDInitializer
        initMDInitializer();
        
        // fill in the caching semantics hashtable
        // by default, only Selection and Calculation (s) are cached
        m_cachingSemantics = new Hashtable(10, 50);
        m_cachingSemantics.put(PersistableConstants.FOLDER, new Integer(MDU.CLIENT));
        m_cachingSemantics.put(PersistableConstants.SELECTION, new Integer(MDU.BOTH));
        m_cachingSemantics.put(PersistableConstants.CALCULATION, new Integer(MDU.BOTH));
        m_cachingSemantics.put(MM.MEASURE, new Integer(MDU.BOTH));
        m_cachingSemantics.put("Profile", new Integer(MDU.BOTH));
    }

    private void initMDInitializer()
    {
        if(m_mdInitializer == null)
            m_mdInitializer = new OrderedHashtable(5);
    }

    /**
     * @hidden
     * Initializes handler for MetadataManager.
     *
     * @throws MetadataManagerException if m_handlers could not be initialized
     *
     * @status private
     */
    private void initHandlers(String driverType) throws MetadataManagerException
    {
    /*
        try
        {
            if(driverType != null && m_handlers.get(driverType) == null)
            {
                if(driverType.equals(MDU.PERSISTENCE))
                {
                    Class _cls1 = Class.forName("oracle.dss.metadataManager.client.handlers.persistence.PersistenceMetadataHandler");
                    MetadataHandler _psrHandler = (MetadataHandler)_cls1.newInstance();
                    _psrHandler.setErrorHandler(m_eh);
                    m_handlers.put(MDU.PERSISTENCE, _psrHandler);
                }
                else if(driverType.equals(MDU.DISCOVERER))
                {
                    Class _cls2 = Class.forName("oracle.dss.metadataManager.client.handlers.disco.DiscovererMetadataHandler");
                    MetadataHandler _discoHandler = (MetadataHandler)_cls2.newInstance();
                    _discoHandler.setErrorHandler(m_eh);
                    m_handlers.put(MDU.DISCOVERER, _discoHandler);
                }
            }
        }
        catch (InstantiationException ie)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_INSTANTIATION,
                                                null,
                                                m_Locale,
                                                MDU.PERSISTENCE,
                                                ie );
        }
        catch (ClassNotFoundException cne)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_HANDLER_NOT_FOUND,
                                                null,
                                                m_Locale,
                                                MDU.PERSISTENCE,
                                                cne );
        }
        catch (IllegalAccessException iae)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_ILLEAGAL_ACCESS,
                                                null,
                                                m_Locale,
                                                MDU.PERSISTENCE,
                                                iae );
        }
    */
    }

  /************************************************************************
  * Connection and Driver  Support.
  ************************************************************************/
   	/**
     * Adds a connection to this <code>MetadataManager</code>.
     * The <code>MetadataManager</code> uses the connection to connect to
     * the source of metadata.
     * A <code>MetadataManager</code> can have more than one connection.
     * Each connection provides information for connecting to a different
     * source of metadata.
     *
     * @param connection    The connection to add.
     *
     * @throws MetadataManagerException If the connection cannot be set.
     *
     * @return    A constant that represents success or failure.
     *            Possible constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Reviewed
     */
    public synchronized int setConnection( Connection connection ) throws MetadataManagerException
    {
        if ( connection == null )
            return MDU.FAILURE;

        // store a reference resolver from the Connection if it has one 
        // in the local environment properties hashtable
        if (MDU.PERSISTENCE.equals(connection.getDriverType()))
        {
            PropertyBag pb = connection.getPropertyBag();
            Property [] props = pb.getProperties();
            // loop through props and find referenceResolver
            // if it exists then save it to the m_envProps
            for (int i = 0; i < props.length; i++)
            {
                if (PSRConstants.STORAGEMANAGER_DRIVER.equals(props[i].getName()))
                    m_envProps.put(props[i].getName(), props[i].getObjValue());
/*
                else if (props[i].getObjValue() instanceof oracle.dss.util.persistence.ReferenceResolver)
                {
                    m_envProps.put(props[i].getName(), props[i].getObjValue());
                    connection.removeProperty(props[i].getName());
                }
*/
            }
        }

        // Add handlers
        initHandlers(connection.getDriverType());

        m_Connections.addElement( (Object) connection );
        if(connection.getConnectionString() != null)
            m_MDRoot.setStrings( connection.getConnectionString(), "" );
        else if(connection.getOLAPServiceName() != null && !connection.getOLAPServiceName().equals(""))
            m_MDRoot.setStrings( connection.getOLAPServiceName(), "" );
        else if(connection.getService() != null)
            m_MDRoot.setStrings( connection.getService(), "" );
        else if(connection.getSID() != null)
            m_MDRoot.setStrings( connection.getSID(), "" );

        // Listen to connection events
        connection.addListener(this);
        Property prop = new Property();
        prop.setStrValue("SET_ON_MID_TIER", "NO", MDU.UI_NONE);
        connection.setProperty(prop);
/*
        try {
            if ( !connection.isConnected() ) {
                connection.connect();
            }
        } catch ( ConnectionException e ) {
            // Wrap connection exception into MetadataManagerException and throw it

            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_SET_CONNECTION_FAILURE,
                                                new Object[]{ e.getLocalizedMessage() },
                                                m_Locale,
                                                connection.getDriverType(),
                                                e );

        }
*/
        return MDU.SUCCESS;
    }

   	/**
     * @hidden
     * Specifies the size of the schema to which this
     * <code>MetadataManager</code> provides access.
     * If the schema is very large, then this <code>MetadataManager</code>
     * loads less of the schema to the client, to improve performance.
     * Call this method, passing
     * <code>oracle.dss.metadataManager.common.MM.LARGE_DATABASE</code>,
     * if either the BI Beans Catalog or the analytic workspace is very large.
     * You should also call the appropriate deferred-loading method.
     *
     * @param flag    A constant that represents the schema size. Valid
     *                values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @status hidden
     */
    public synchronized void setPerformanceTuning( int flag )
    {
        m_Depth = flag;
    }

   	/**
     * @hidden
     * Retrieves the size of the schema to which this
     * <code>MetadataManager</code> provides access.
     *
     * @return      A constant that represents the size of the schema.
     *              Possible values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @status hidden
     */
    public synchronized int getPerformanceTuning()
    {
        return m_Depth;
    }

   	/**
     * @hidden
     * Specifies the name of the analytic workspace that this
     * <code>MetadataManager</code> represents.
     *
     * @param databaseString  The name of the analytic workspace.
     * @param connection      The connection for the OLAP service for the
     *                         workspace.
     *
     * @return      A constant that represents success or failure.
     *              Possible constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public synchronized int setDatabaseString( String databaseString, Connection connection )
    {
        if ( connection == null )
            return MDU.FAILURE;

        if(connection.getConnectionString() != null) {
            m_MDRoot.setStrings( connection.getConnectionString(), databaseString );
        } else if(connection.getOLAPServiceName() != null && !connection.getOLAPServiceName().equals("")) {
            m_MDRoot.setStrings(connection.getOLAPServiceName(), databaseString );
        } else if(connection.getService() != null && !connection.getService().equals("")) {
            m_MDRoot.setStrings(connection.getService(), databaseString );
        } else if(connection.getSID() != null && !connection.getSID().equals("")) {
            m_MDRoot.setStrings(connection.getSID(), databaseString );
        }
        return MDU.SUCCESS;
    }

   	/**
     * Retrieves the connections that this <code>MetadataManager</code> uses.
     *
     * @return The connections that have been set for this
     *         <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public synchronized Connection[] getConnections() {
        if  ( m_Connections == null )
            return null;

        int count = m_Connections.size();

        if ( count == 0 )
            return null;

        Connection[] connections = new Connection[count];
        for ( int i =0 ; i < count ; i++ ) {
            connections[i] = (Connection) m_Connections.elementAt(i);
        }
        return connections;
    }

   	/**
     * @hidden
     * Retrieves a connection that this <code>MetadataManager</code> uses.
     *
     * @param connectionString    The <code>String</code> that was used in
     *                            the connection.
     *
     * @return  The connection that corresponds to <code>connectionString</code>.
     *
     * @status hidden
     */
    public synchronized Connection getConnection( String connectionString ) {
        Connection[] connections = getConnections();
        if (( connections == null ) || ( connections.length == 0))
            return null;
        for ( int i = 0; i < connections.length ; i ++ ) {
            String connectionStr = connections[i].getConnectionString();
            if(connectionStr == null)
            {
                connectionStr = connections[i].getOLAPServiceName();
                if(connectionStr == null || connectionStr.equals("")) {
                    connectionStr = connections[i].getService();
                    if(connectionStr == null || connectionStr.equals(""))
                        connectionStr = connections[i].getSID();
                }
            }
            if ( connectionStr != null && connectionStr.equals( connectionString ) ) {
                return connections[i];
            }
        }
        return null;
    }

    /**
     * @hidden
     * Retrieves the status of a connection that this
     * <code>MetadataManager</code> uses.
     * This method tells you whether the specified connection is set for this
     * <code>MetadataManager</code>.
     * To find out whether you are connected to server, call the
     * <code>getConnectionStatus</code> of the <code>Connection</code> object.
     *
     * @param connectionString    The <code>String</code> that was used
     *                            in the connection.
     *
     * @return  A constant that represents the status of the connection that
     *          corresponds to <code>connectionString</code>.
     *          Possible values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_SET
     * @see oracle.dss.metadataManager.common.MM#CONNECTIONS_NOT_SET
     * @see oracle.dss.connection.client.Connection#getConnectionStatus
     *
     * @status hidden
     */
    public synchronized int getConnectionStatus( String connectionString ) {
        Connection connection = null;
        connection = getConnection ( connectionString );
        if ( connection != null )
            return connection.getConnectionStatus();
        return MM.CONNECTIONS_NOT_SET ;
    }

   	/**
     * @hidden
     * Retrieves connection strings for the connections that have
     * been set for this <code>MetadataManager</code>.
     *
     * @return  A connection string for each connection that has been set
     *          for this <code>MetadataManager</code>.
     *
     * @status hidden
     */
    public synchronized String[] getConnectionStrings() {
        Connection[] connections = getConnections();
        if (( connections == null ) || ( connections.length == 0) )
            return null;
        String[] connectionStrings = new String[connections.length];
        for ( int i = 0; i < connections.length ; i ++ ) {
            connectionStrings[i] = connections[i].getConnectionString();
        }
        return connectionStrings;
    }

    /************************************************************
     * MDRoot methods
     ***********************************************************/

    /**
     * @hidden
     * Retrieves a connection string for a connection to an OLAP service.
     * This method returns the connection string for the connection to
     * a particular analytic workspace.
     *
     * @param databaseString    The <code>String</code> that identifies the
     *                          analytic workspace whose connection string you
     *                          want.
     *
     * @return  The connection string for the connection to the OLAP service
     *          that has the analytic workspace.
     *
     * @status hidden
     */
	public synchronized String getConnectionString ( String databaseString ) {
        if(m_MDRoot != null)
		    return m_MDRoot.getConnectionString ( databaseString );
        return null;
	}

    /**
     * @hidden
     * Retrieves the <code>String</code> that identifies the analytic
     * workspace that a connection provides access to.
     *
     * @param connectionString    A <code>String</code> that identifies a
     *                            connection to an OLAP service.
     *
     * @return  A <code>String</code> that identifies the analytic workspace
     *          provided by the OLAP service.
     *
     * @status hidden
     */
    public synchronized String getDatabaseString ( String connectionString ) {
        if(m_MDRoot != null)
            return m_MDRoot.getDatabaseString ( connectionString );
        else
            return null;
    }

    /**
     * @hidden
     * Retrieves strings for multiple analytic workspaces for a specified
     * connection.
     *
     * @param connectionString A <code>String</code> that identifies a
     *        connection to an OLAP service.
     *
     * @return  A <code>String</code> for each analytic workspace that is
     *          available through the connection.
     *
     * @status hidden
     */
	public synchronized String[] getDatabaseStrings ( String connectionString ) {
        if(m_MDRoot != null)
            return m_MDRoot.getDatabaseStrings ( connectionString );
        return null;
	}

    /**
     * @hidden
     * Retrieves strings that identify all of the analytic workspaces to
     * which this <code>MetadataManager</code> provides access.
     *
     * @return  A <code>String</code> for each analytic workspace that
     *          this <code>MetadataManager</code> provides access to, through
     *          any of its connections.
     *
     * @status hidden
     */
	public synchronized String[] getDatabaseStrings() {
        if(m_MDRoot != null)
            return m_MDRoot.getDatabaseStrings();
        return null;
	}

   	/**
     * @hidden
     * Retrieves status information for an analytic workspace.
     *
     * @param databaseString  A <code>String</code> that identifies the
     *                        analytic workspace whose status you want.
     *
     * @return  A constant that represents the status of the specified
     *          workspace.
     *          Possible values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public synchronized int getAttachStatus( String databaseString ){
        if(m_MDRoot != null)
            return m_MDRoot.getAttachStatus ( databaseString );
        else
            return MM.NOT_ATTACHED;
    }

   	/**
     * @hidden
     * Specifies status of an analytic workspace.
     *
     * @param databaseString    <code>String</code> that identifies the analytic
     *                          workspace whose status you want to set.
     *
     * @param status            A constant that represents the status of
     *                          the specified workspace.
     *                          Valid values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public synchronized void setAttachStatus( String databaseString, int status ){
        if(m_MDRoot != null)
            m_MDRoot.setAttachStatus ( databaseString, status );
    }

   	/**
     * @hidden
     * Retrieves strings that identify analytic workspaces that have the
     * specifies status.
     * For example, you can find all of the workspaces that are currently
     * open and attached.
     *
     * @param status  A constant that represents the status that you want.
     *                Possible values are listed in the See Also section.
     *
     * @return  A <code>String</code> that identifies each analytic workspace
     *          that has the specified status.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public synchronized String[] getDatabaseStrings( int status ) {
        if(m_MDRoot != null)
            return m_MDRoot.getDatabaseStrings( status );
        return null;
    }

    /**
     * Retrieves information about whether the most recently-attached
     * analytic workspace is open and attached for this
     * <code>MetadataManager</code>.
     *
     * @return     A constant that represents the attach status.
     *             Possible values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status Documented
     */
    public synchronized int getAttachStatus(){
        if(m_MDRoot != null)
            return m_MDRoot.getAttachStatus();
        else
            return MM.NOT_ATTACHED;
    }

   	/**
     * @hidden
     * Specifies the status of the most-recently attached analytic workspace for
     * this <code>MetadataManager</code>.
     *
     * @param status    A constant that represents attach status.
     *                  Valid values are listed in the See Also section.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     *
     * @status hidden
     */
    public synchronized void setAttachStatus( int status ) {
        if(m_MDRoot != null)
            m_MDRoot.setAttachStatus ( status );
    }

   	/**
     * Attaches (opens) all analytic workspaces to which this
     * <code>MetadataManager</code> has connections.
     *
     * @return A constant that represents attach status.
     *         Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the process of attaching
     *                   workspaces fails.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status Reviewed
     */
    public synchronized int attach() throws MetadataManagerException{
        return attach ( (PropertyBag) null ) ;
    }

    /**
     * Detaches (closes) all open analytic workspaces.
     * This method also disconnects all connections that are associated with
     * this <code>MetadataManager</code>.
     *
     * @return A constant that represents detach status.
     *         Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the process of closing the
     *                   workspaces fails.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status Reviewed
     */
    public synchronized int detach() throws MetadataManagerException{
        return detach(true);
    }

   	/**
     * @hidden
     * Attach all. Not fully implemented
     *
     * @param attachParams  PropertyBag containing
     *
     * @return Integer constant representing attach status.
     *                  Possible values are:
     *                  <code>ATTACHED</code> if more than one database is attached.
     *                  <code>NOT_ATTACHED</code> if no database is attached.
     *                  <code>ATTACHING</code> if database is attaching.
     *                  <code>FAILURE</code> if attach failed
     *                  <code>SUCCESS</code> if attach was successful
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @throws MetadataManagerException if attach process failed
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */
    public synchronized int attach( PropertyBag attachParams ) throws MetadataManagerException {
        if ( initMetadataManager() != MDU.SUCCESS )
            return MDU.FAILURE;

        if (!isProxyOK() || !isRemoteOK())
            return MDU.NO_REMOTE;

        // set the performance tuning flag on root
        m_MDRoot.setPerformanceTuning( m_Depth );

        // set driverImpl
        m_MDRoot.setObjPropertyValue(MM.METADATA_DRIVER, m_driverImpl);

        // Set MDInitializer on MDRoot
        m_MDRoot.setObjPropertyValue(MM.INITIALIZER, m_mdInitializer);
        // Run MDInitializer with BEFORE_CONNECT flag
        if(m_mdInitializer.size() > 0)
        {
            Enumeration _enum = m_mdInitializer.keys();
            while(_enum.hasMoreElements())
            {
                MDInitializer _init = (MDInitializer)_enum.nextElement();
                String _flag = (String)m_mdInitializer.get(_init);
                if(_flag.equals(MM.BEFORE_CONNECT))
                {
                    getErrorHandler().trace("Execute BEFORE_CONNECT MDInitializer: " + _init.getClass().getName(), getClass().getName(), "attach");
                    long _bef = System.currentTimeMillis();
                    _init.run(this);
                    long _aft = System.currentTimeMillis();
                    getErrorHandler().trace(_init.getClass().getName() + " executed in " + (_aft-_bef) + "ms", getClass().getName(), "attach");
                }
            }
        }

        setConnectionObjects( m_Connections );
        MetadataManagerEvent event = new MetadataManagerEvent( this, false, attachParams );
        m_EventSupport.fireAttachingEvent( event );

        // Send error-handler to middle-tier through m_MDRoot
        if(m_eh != null)
        {
            m_MDRoot.setObjPropertyValue("ErrorHandler", m_eh);
        }

        if(m_Locale != null)
        {
            m_MDRoot.setObjPropertyValue("locale", m_Locale);
        }

        // set the client side metadataManager
        if(attachParams == null)
            attachParams = new PropertyBag();
        attachParams.setObjPropertyValue("metadatamanager", this);

        // if persistence connection exists, then refresh after attaching olap
        boolean refresh = false;
        if(getAttachStatus() == MM.ATTACHED && isPersistenceDriverAttached())
            refresh = true;
        MDRoot mdRoot = m_MetadataManagerProxy.attach( m_MDRoot, attachParams );
        if(m_eh != null)
        {
            m_MDRoot.removeProperty("ErrorHandler");
        }

        mdRoot.setMetadataManagerServices( (MetadataManagerServices)this );
        setMDRoot(mdRoot);
        if ( mdRoot == null ) {
            setAttachStatus( MM.NOT_ATTACHED );
            return getAttachStatus();
        }
        if ( mdRoot.getAttachStatus() == MM.ATTACHED ) {
            m_MDIndex.setMDObjects ( m_MDRoot.getPrimaryIndex(), (MetadataManagerServices) this );
            m_MDIndex.setMDObject ( mdRoot );
            setMDRoot(mdRoot);
            if ( m_DEBUG ) {
                System.out.println ( "Printing From client - start" );
                m_MDRoot.print(0);
                printChildren ( m_MDRoot, 8, "" );
                m_MDIndex.print();
                System.out.println ( "Printing From client - end" );
            }
            m_EventSupport.fireAttachedEvent( event );
        }
        else {
            return MDU.FAILURE;
        }
        if(refresh)
        {
            m_MDRoot.getChildren();
            refresh(m_MDRoot, 1);
        }
        return getAttachStatus();
    }

    /**
     * @hidden
     * Print children till depth of the specified mdObject
     *
     * @param mdObject  MDObject whose children are to be printed
     * @param depth     Depth of tree under mdObject
     * @param str       Pre-pend the uniqueID of mdObject and it's children
     *                  with str
     *
     * @throws MetadataManagerException if error occured while retriving
     *                                  children.
     * @status hidden
     */
    public synchronized void printChildren ( MDObject mdObject, int depth, String str )
                                                throws MetadataManagerException
    {
        if ( depth == 0)
            return;
        if ( depth == 1 )
            System.out.println ( "Test...." );

        str = str + "\\" + mdObject.getUniqueID();
        System.out.println ( "-Depth<<" + depth + ">> Path=" + str );
        System.out.println ( "-----------------------------------------------------------------" );
        MDObject[] mdObjects = mdObject.getChildren();
        for (int i = 0 ; ((mdObjects != null) && ( i < mdObjects.length ) ); i++ ) {
            mdObjects[i].print ( 0 );
            if ( !mdObject.isAncestor( mdObjects[i].getUniqueID()) ) {
            // recursion
                printChildren ( mdObjects[i], depth -1, str );
            }
        }
    }

    /**
     * @hidden
     * Detach all.  Not fully implemented
     *
     * @return Integer constant representing attach status.
     *                  Possible values are:
     *                  <code>ATTACHED</code> if more than one database is attached.
     *                  <code>NOT_ATTACHED</code> if no database is attached.
     *                  <code>ATTACHING</code> if database is attaching.
     *                  <code>FAILURE</code> if attach failed
     *                  <code>SUCCESS</code> if attach was successful
     *                  <code>NO_REMOTE</code> if proxy is not set
     *
     * @throws MetadataManagerException if attach process failed
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     * @see oracle.dss.metadataManager.common.MM#ATTACHING
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status hidden
     */
    public synchronized int detach(PropertyBag detachParams) throws MetadataManagerException{
        if (!isProxyOK() || !isRemoteOK()) {
            return MDU.NO_REMOTE;
        }
        MetadataManagerEvent detachingEvent = new MetadataManagerEvent( this, true, detachParams );
        if(m_EventSupport.fireDetachingEvent( detachingEvent ) ) {
            m_eh.trace("detaching event is consumed: ", getClass().getName(), "detach");
           return MDU.FAILURE;
        }
        m_eh.trace("-MetadataManagerBean-Client is going to detach ", getClass().getName(), "detach");
        MDRoot  mdRoot = m_MetadataManagerProxy.detach( detachParams );
        mdRoot.setMetadataManagerServices(this);
        if ( mdRoot.getAttachStatus() == MM.NOT_ATTACHED ) {
            m_MDRoot  = mdRoot;
            MetadataManagerEvent detachedEvent = new MetadataManagerEvent( this, false, detachParams );
            m_EventSupport.fireDetachedEvent( detachedEvent );
        }else {
            return MDU.FAILURE;
        }

        if(m_envProps != null)
            m_envProps.clear();
        m_MDIndex.clear();
        return getAttachStatus();
    }

    /**
     * Detaches (closes) all open analytic workspaces.
     * You can specify whether to disconnect all associated connections.
     *
     * @param disconnect <code>true</code> to disconnect all connections,
     *                   <code>false</code> to detach without disconnecting.
     *
     * @return A constant that represents detach status.
     *         Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the process of closing the
     *                   workspaces fails.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#NO_REMOTE
     *
     * @status Reviewed
     */
    public synchronized int detach(boolean disconnect) throws MetadataManagerException
    {
        int _status = 0;
        if(getAttachStatus() == MM.ATTACHED)
            _status = detach(null);

        if(disconnect)
        {
            return disconnect();
        }
        return _status;
    }

    /**
     * @hidden
     * Disconnect all.
     */
    public synchronized int disconnect() throws MetadataManagerException
    {
        Connection[] _cons = getConnections();
        int _status = 0;
        for(int i = 0; _cons != null && i < _cons.length; i++)
        {
            try
            {
                if(_cons[i].isConnected())
                    _status = _cons[i].disconnect();
            }
            catch(ConnectionException e)
            {
                throw new MetadataManagerException(MetadataManagerClientBundle.class,
                                                   MetadataManagerClientBundle.EXC_CANNOT_DISCONNECT,
                                                   null,
                                                   m_Locale,
                                                   _cons[i].getDriverType(),
                                                   e);
            }
        }
        return _status;
    }
  /************************************************************************
  * Properties.
  ************************************************************************/
    /**
     * @hidden
     * Retrieve a property on server side of metadataManager.
     *
     * @param propertyName  Name of property that need to be retrieved from
     *                      server side.
     *
     * @return  Property found on server side for the given propertyName
     *
     * @status hidden
     */
    public synchronized Property getServerProperty( String propertyName ) {
        if (!isProxyOK() || !isRemoteOK())
            return null;

        return m_MetadataManagerProxy.getServerProperty ( propertyName );
    }

    /**
     * @hidden
     * Sets the property on server side of metadataManager
     *
     * @param property      Property that need to be set on server side.
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status hidden
     */
    public synchronized int setServerProperty( Property property ) {
        if (!isProxyOK() || !isRemoteOK())
            return MDU.FAILURE;
        return m_MetadataManagerProxy.setServerProperty( property );
    }

    /**
     * Retrieve the root folder for this <code>MetadataManager</code>.
     *
     * @return  The root folder for this <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public synchronized MDRoot getMDRoot(){
        return m_MDRoot;
    }

    /**
     * @hidden
     * Set mdRoot on this metadataManager
     *
     * @param           MDRoot folder that needs to be set as root
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status hidden
     */
	public synchronized int setMDRoot( MDRoot mdRoot ){
		m_MDRoot  = mdRoot;
  		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Get server side MDRoot instance.
     *
     * @return  MDRoot set on server side of metadataManager
     *
     * @status hidden
     */
    public synchronized MDRoot getServerMDRoot() {
        if (!isProxyOK() || !isRemoteOK())
            return null;
        MDRoot mdRoot = m_MetadataManagerProxy.getServerMDRoot();
        mdRoot.setMetadataManagerServices(this);
        return mdRoot;
    }

    /**
     * @hidden
     * Set MDRoot instance on server side.
     *
     * @param   MDRoot instance that needs to be set on server side
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status hidden
     */
    public synchronized int setServerMDRoot( MDRoot mdRoot ){
        if (!isProxyOK() || !isRemoteOK())
            return MDU.FAILURE;
        return m_MetadataManagerProxy.setServerMDRoot( mdRoot );
    }

	/****************************************************
	 * Generic methods for property Setting from Property Bag
	 ****************************************************/

    /**
     * @hidden
     * Retrieve property set on root
     *
     * @param name  Name of property that we are interested in.
     *
     * @return      Property in MDRoot
     *
     * @status hidden
     */
    public synchronized Property getProperty( String name ){
        if(m_MDRoot != null)
            return m_MDRoot.getProperty( name );
        return null;
    }

    /**
     * @hidden
     * Retrieve properties set on root
     *
     * @return      Array of properties in MDRoot
     *
     * @status hidden
     */
	public synchronized Property[] getProperties() {
        if(m_MDRoot != null)
		    return m_MDRoot.getProperties();
        return null;
	}

    /**
     * @hidden
     * Set property on root
     *
     * @param property  Property that we are interested in.
     *
     * @status hidden
     */
	public synchronized void setProperty ( Property property ) {
        if(m_MDRoot != null)
		    m_MDRoot.setProperty( property );
	}

    /**
     * @hidden
     * Set property on root
     *
     * @param name      Name of property that we want to set.
     * @param object    object that we want to set in property
     * @param dataType  data type of property
     * @param flags     Constant representing visibility of property.  Value for
     *                  the constant can be:
     *                  <code>UI_ALL</code>
     *                  <code>UI_VISIBLE</code>
     *                  <code>UI_DELETE</code>
     *                  <code>UI_ENCRYPT</code>
     *                  <code>UI_WRITE</code>
     *                  <code>UI_NONE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#UI_ALL
     * @see oracle.dss.metadataUtil.MDU#UI_VISIBLE
     * @see oracle.dss.metadataUtil.MDU#UI_DELETE
     * @see oracle.dss.metadataUtil.MDU#UI_ENCRYPT
     * @see oracle.dss.metadataUtil.MDU#UI_WRITE
     * @see oracle.dss.metadataUtil.MDU#UI_NONE
     *
     * @status hidden
     */
	public synchronized void setProperty ( String name, Object object, int dataType, int flags) {
        if(m_MDRoot != null)
		    m_MDRoot.setProperty ( name, object, dataType, flags );
	}

    /**
     * @hidden
     * Remove property name from root
     *
     * @param name      Name of property that we want to remove.
     *
     * @status hidden
     */
    public synchronized void removeProperty(String name) {
        if(m_MDRoot != null)
            m_MDRoot.removeProperty( name );
    }

    /**
     * @hidden
     * Retrieve property bag from root
     *
     * @return  PropertyBag of mdRoot.
     *
     * @status hidden
     */
    public synchronized PropertyBag getPropertyBag() {
        if(m_MDRoot != null)
            return m_MDRoot.getPropertyBag();
        return null;
    }

    /**
     * @hidden
     * Set property bag of root
     *
     * @param propertyBag       propertyBag that needs to be set as propertybag
     *                          of root.
     * @param keepRemoveFlags   Constant representing whether propertyBag should
     *                          be added to the propertyBag of root or replace it
     *                          Possible values can be:
     *                          <code>KEEP</code>
     *                          <code>REMOVE</code>
     *
     * @return          Integer constant representing success or failure.
     *                  Possible values are:
     *                  <code>FAILURE</code>
     *                  <code>SUCCESS</code>
     *
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     *
     * @status hidden
     */
    public synchronized int setPropertyBag( PropertyBag propertyBag, int keepRemoveFlags ) {
        if(m_MDRoot != null)
            return m_MDRoot.setPropertyBag ( propertyBag, keepRemoveFlags );
        return MDU.FAILURE;
    }

    /****************************************************
     * Short cut methods for property setting
     ****************************************************/
    /**
     * Retrieves the name of this <code>MetadataManager</code>.
     *
     * @return The name of this <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public synchronized String getBeanName() {
        if(m_MDRoot != null)
            return m_MDRoot.getMetadataManagerName();
        else
            return null;
    }

  	/**
     * Specifies the name of this <code>MetadataManager</code>.
     *
     * @param name The name of this <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public synchronized void setBeanName(String name) {
        if(m_MDRoot != null)
            m_MDRoot.setMetadataManagerName( name );
    }

    /************************************************************************
    * Event Support.
    ************************************************************************/
    /**
     * Adds a <code>MetadataManagerListener</code> to this
     * <code>MetadataManager</code>.
     *
     * @param listener The listener to add.
     *
     * @status Reviewed
     */
    public synchronized void addListener( MetadataManagerListener listener ) {
        m_EventSupport.addMetadataManagerListener( listener );
    }

    /**
     * Removes a <code>MetadataManagerListener</code> from the list of
     * listeners for this <code>MetadataManager</code>.
     *
     * @param listener  The listener to remove.
     *
     * @status Reviewed
     */
    public synchronized void removeListener( MetadataManagerListener listener ) {
        m_EventSupport.removeMetadataManagerListener( listener );
    }

    /**
     * @hidden
     * This method adds a propertyBag to the event cache so that if caching is
     * enabled, modified mdObject is saved in event-cache instead of firing
     * a metadataModified event.
     *
     * @param propertyBag   propertyBag that needs to be saved in event cache.
     * @param relation      String representing relation
     *
     *
     * @status private
     */
    private void cacheMetadataModified( PropertyBag propertyBag, String relation ) {
        if ( m_MetadataModifiedEventCache == null )
            m_MetadataModifiedEventCache = new MDContentBag();
        m_MetadataModifiedEventCache.setContentItem( propertyBag, relation );
        return;
    }

    /**
     * @hidden
     * This method fires MetadataModified Event that contains all the MDObject
     * that were modified.
     *
     * @status private
     */
    private void fireMetadataModifiedCachedEvent() {
        MetadataModifiedEvent event =
         new MetadataModifiedEvent( this, false, m_MetadataModifiedEventCache );
        m_EventSupport.fireMetadataModifiedEvent( event );
        m_MetadataModifiedEventCache = null;
        return;
    }

    /**
     * @hidden
     *
     * @param isBatchEvent  <code>true</code> to combine events, enables metadataModified event caching
     *                      <code>false</code> to have each event fired as it occurs.
     *
     * @status hidden
     */
    public synchronized void setBatchEventMode( boolean isBatchEvent ) {
        m_IsBatchEventMode = isBatchEvent;
        if( (m_IsBatchEventMode == false) &&
            (m_MetadataModifiedEventCache != null ) &&
            (m_MetadataModifiedEventCache.size() != 0) )
        {
            fireMetadataModifiedCachedEvent();
        }
    }

    /**
     * @hidden
     * Indicates whether events are being cached.
     *
     * @return   <code>true</code> if events are cached,
     *           <code>false</code> if they are sent individually.
     *
     * @status hidden
     */
    public synchronized boolean getBatchEventMode() {
        return m_IsBatchEventMode;
    }

    /**
     * @hidden
     * This method retrieves children of mdObject.
     *
     * @param mdObject      mdObject whose children are to be retrieved.
     * @param mdObjectIDs   OrderedHashtable that contains IDs of children
     * @param depth         Constant representing the depth of tree under
     *                      mdObject.  Possible values are:
     *                      <code>DEMO_DATABASE</code>
     *                      <code>MEDIUM_DATABASE</code>
     *                      <code>LARGE_DATABASE</code>
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @see oracle.dss.metadataManager.common.MM#DEMO_DATABASE
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_DATABASE
     * @see oracle.dss.metadataManager.common.MM#LARGE_DATABASE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized OrderedHashtable getChildrenTable ( MDObject mdObject,
                                               OrderedHashtable mdObjectIDs,
                                               int depth )
                                               throws MetadataManagerException
    {
        depth = m_Depth;
        if( depth == 1 ) {
            return getChildrenTable( mdObject, mdObjectIDs );
        }
        else {
            // Fill local cache
            getChildren( mdObject, depth );
            return setChildrenTree( mdObject, depth );
        }
    }

    /**
     * @hidden
     * Sets the children bag of mdObjects till specified depth.  All
     * children should be in client cache before this method can be called.
     *
     * @param mdObject      mdObject whose children need to be retrieved.
     * @param depth         Constant representing the depth of tree under
     *                      mdObject.
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    private OrderedHashtable setChildrenTree( MDObject mdObject, int depth )
                                                throws MetadataManagerException
    {
        if( mdObject == null || !mdObject.hasChildren() ) {
            return null;
        }

        OrderedHashtable table = setChildrenBag( mdObject );
        if( (depth != -1) && (depth <= 1) ) {
            return table;
        } else {
            depth = (depth != -1)? depth - 1 : depth;
            Enumeration enumer = table.keys();
            while( enumer.hasMoreElements() ) {
                MDObject childMDObject = (MDObject)enumer.nextElement();
                setChildrenTree( childMDObject, depth );
            }
        }
        return table;
    }

    /**
     * @hidden
     * This method sets the children bag of mdObjects. All
     * children should be in client cache before this method is called.
     *
     * @param mdObject      mdObject whose children need to be retrieved.
     *
     * @return              OrderedHashtable containing immediate children of
     *                      mdObject.
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    private OrderedHashtable setChildrenBag( MDObject mdObject )
                                                throws MetadataManagerException
    {
        OrderedHashtable childrenTable = new OrderedHashtable( 11 );
        OrderedHashtable idTable = mdObject.getChildrenID();
        Enumeration enumer = idTable.keys();
        MDObject tempMDObject;
        while( enumer.hasMoreElements() ) {
            Long key = (Long)enumer.nextElement();
            tempMDObject = m_MDIndex.getMDObject( key.longValue() );
            childrenTable.put( tempMDObject, idTable.get( key ) );
        }
        MDContentBag mdContentBag = new MDContentBag();
        mdContentBag.setContentTable( childrenTable );
        mdObject.setChildrenBag ( mdContentBag );
        MDObject mdParent = mdObject.getParent();
        if ( mdParent != null )
            mdParent.resetChild( mdObject );
        return childrenTable;
    }

    /**
     * @hidden
     * Retrieve children from local cache; if not in local cache, get them from
     * server side.  Fill children bag and return an OrderedHashtable containing
     * children.
     *
     * @param mdObject      mdObject whose children bag needs to be filled.
     * @param mdObjectIDs   IDs of children
     *
     * @return              OrderedHashtable containing children.
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized OrderedHashtable getChildrenTable ( MDObject mdObject,
                                               OrderedHashtable mdObjectIDs )
                                               throws MetadataManagerException
    {
        if( mdObject != null && mdObject.getChildrenStatus() == MM.NOT_COMPLETE ) {
            OrderedHashtable table = m_MetadataManagerProxy.getChildrenTillDepth( mdObject, m_Depth );
            m_MDIndex.setMDObjects(table, this);
            return table;
        }

        if (( mdObjectIDs == null ) || ( (mdObjectIDs.size() == 0) && (mdObject.getChildrenStatus() == MM.COMPLETE) ) || ( mdObject == null ))
            return null;
        OrderedHashtable onlyIDs = new OrderedHashtable();
        // Look for children in local cache
        OrderedHashtable mdObjectTable = m_MDIndex.getMDObjects( mdObjectIDs, onlyIDs );
        if ( ( onlyIDs != null ) && ( onlyIDs.size() > 0) ) {
            // Some or all children not found in local cache.  Go to middle-ties
            // and get them from there.
            OrderedHashtable retObjectTable = m_MetadataManagerProxy.getMDObjectTable( onlyIDs );
            mdObjectTable = MDContentBag.mergeHashtables ( mdObjectTable, retObjectTable );
        }
        // Set local cache
        m_MDIndex.setMDObjects( mdObjectTable, this );

        // MDObjects, children, will be extracted from m_MDIndex even though we
        // have them in mdObjectTable.  The reason is that mdObjectIDs has IDs
        // as keys in it and we can get MDObject from m_MDIndex with IDs as key.
        // Other wise, we will have to perform linear searches on mdObjectTable
        // to get children in right order because it has MDObject as keys.
        OrderedHashtable childrenTable = new OrderedHashtable();
        Enumeration enumer = mdObjectIDs.keys();
        MDObject tempMDObject;
        while( enumer.hasMoreElements() ) {
            Long key = (Long)enumer.nextElement();
            tempMDObject = m_MDIndex.getMDObject( key.longValue() );
            childrenTable.put( tempMDObject, mdObjectIDs.get( key ) );
        }
        MDContentBag mdContentBag = new MDContentBag();
        mdContentBag.setContentTable( childrenTable );
        mdObject.setChildrenBag ( mdContentBag );
        MDObject mdParent = mdObject.getParent();
        if ( mdParent != null )
            mdParent.resetChild( mdObject );

        return childrenTable;
    }

    /**
     * @hidden
     * Retrieve relative from local cache; if not in local cache, get them from
     * server side.  Fill relative bag and return an OrderedHashtable containing
     * relative.
     *
     * @param mdObject      mdObject whose relative bag needs to be filled.
     * @param mdObjectIDs   IDs of relative
     *
     * @return              OrderedHashtable containing relative.
     *
     * @throws              MetadataManagerException
     *
     * @status hidden
     */
    public synchronized OrderedHashtable getRelativeTable ( MDObject mdObject,
                                               OrderedHashtable mdObjectIDs )
                                               throws MetadataManagerException
    {
        if( (mdObject != null && mdObject.getRelativeStatus() == MM.NOT_COMPLETE)
            || (mdObject != null && mdObject.getObjectType().equals(MM.LEVEL)) ) {
            MDContentBag contentBag = m_MetadataManagerProxy.getRelatives( mdObject );
            m_MDIndex.setMDObjects( contentBag.getContentTable(), this );
            return contentBag.getContentTable();
        }
        if (( mdObjectIDs == null ) || ( mdObjectIDs.size() == 0 ) || ( mdObject == null ))
            return null;
        OrderedHashtable onlyIDs = new OrderedHashtable();
        // Look for relative in local cache
        OrderedHashtable mdObjectTable = m_MDIndex.getMDObjects( mdObjectIDs, onlyIDs );
        if ( ( onlyIDs != null ) && ( onlyIDs.size() > 0) ) {
            // Some or all relative not found in local cache.  Go to middle-ties
            // and get them from there.
            OrderedHashtable retObjectTable = m_MetadataManagerProxy.getMDObjectTable( onlyIDs );
            mdObjectTable = MDContentBag.mergeHashtables ( mdObjectTable, retObjectTable );
        }
        // Set local cache
        m_MDIndex.setMDObjects( mdObjectTable, this );

        // MDObjects, relatives, will be extracted from m_MDIndex even though we
        // have them in mdObjectTable.  The reason is that mdObjectIDs has IDs
        // as keys in it and we can get MDObject from m_MDIndex with IDs as key.
        // Other wise, we will have to perform linear searches on mdObjectTable
        // to get relative in right order because it has MDObject as keys.
        OrderedHashtable relativesTable = new OrderedHashtable();
        Enumeration enumer = mdObjectIDs.keys();
        MDObject tempMDObject;
        while( enumer.hasMoreElements() ) {
            Long key = (Long)enumer.nextElement();
            tempMDObject = m_MDIndex.getMDObject( key.longValue() );
            relativesTable.put( tempMDObject, mdObjectIDs.get( key ) );
        }

        MDContentBag mdContentBag = new MDContentBag();
        mdContentBag.setContentTable( relativesTable );
        mdObject.setRelativesBag ( mdContentBag );
        MDObject mdParent = mdObject.getParent();
        if ( mdParent != null )
            mdParent.resetChild( mdObject );
        return relativesTable;
    }

    /**
     * @hidden
     * Support for generating ID
     *
     * @return   long value which can be used as a unique id for this session.
     */
    public synchronized long generateMDObjectID() {
        if(isProxyOK())
            return m_MetadataManagerProxy.generateMDObjectID();
        return MDU.ILLEGAL_LONG_VALUE;
    }

    /************************************************************************
    * MetadataProvider interface methods
    *************************************************************************
    /**
     * @hidden
     * Retrieve MDContentBag containing children for the specified mdObject
     *
     * @param mdObject   mdObject whose contentBag is required
     *
     * @return   MDContentBag containing children of mdObject
      *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDContentBag getChildren( MDObject mdObject ) throws MetadataManagerException {
        MDContentBag mdContentBag = mdObject.getChildrenBag();
        // mdObject.getChildrenBag will call fillChildrenBag that calls
        // getChildrenTable which checks the cache and goes to middle-tier
        // if not found in cache.
        if( mdContentBag != null )
            return mdContentBag;
        else
            return null;
    }

    /**
     * @hidden
     * Retrieve OrderedHashtable containing children for the specified mdObject
     *
     * @param mdObject   mdObject whose children are needed
     * @param depth      depth of tree under the mdObject
     *
     * @return   OrderedHashtable containing children
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized OrderedHashtable getChildren( MDObject mdObject, int depth ) throws MetadataManagerException {
/*
        if( mdObject != null && mdObject.getChildrenStatus() == MM.NOT_COMPLETE ) {
            OrderedHashtable table = m_MetadataManagerProxy.getChildrenTillDepth( mdObject, m_Depth );
            m_MDIndex.setMDObjects( table, (MetadataManagerServices)this );
            return table;
        }
*/
        OrderedHashtable childrenHashtable = m_MetadataManagerProxy.getChildrenTillDepth( mdObject, depth );
        if( childrenHashtable == null ) {
            return null;
        }
        Enumeration enumer = childrenHashtable.keys();
        while( enumer.hasMoreElements() ) {
            MDObject tempMDObject = (MDObject) enumer.nextElement();
            // check local cache for mdObject, if not found, add it.
            MDObject mdObjectInCache = m_MDIndex.getMDObject(tempMDObject.getObjectID());
            if( mdObjectInCache == null ) {
                tempMDObject.setMetadataManagerServices( (MetadataManagerServices)this );
                m_MDIndex.setMDObject( tempMDObject );
            } else {
                Object value = childrenHashtable.get( tempMDObject );
                childrenHashtable.put( mdObjectInCache, value );
            }
        }
        return childrenHashtable;
    }

    /**
     * @hidden
     * Retrieve MDContentBag for specified mdObject
     *
     * @param mdObject   mdObject whose relatives are needed
     *
     * @return   MDContentBag containing relatives
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDContentBag getRelatives( MDObject mdObject ) throws MetadataManagerException {
        MDContentBag mdContentBag = mdObject.getRelativesBag();
        // mdObject.getRelativesBag will call fillRelativesBag that calls
        // getRelativesTable which checks the cache and goes to middle-tier
        // if not found in cache.
        if( mdContentBag != null )
            return mdContentBag;
        else
            return null;
    }

	/**
     * @hidden
     * Retrieve mdObject with specified properties.
     *
     * @param properties    properties that should exist in mdObject
     *
     * @return mdObject that has similar properties
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject getMDObject ( PropertyBag properties ) throws MetadataManagerException {
        // check the runtime DS
        String uniqueID = properties.getStrPropertyValue(MM.UNIQUE_ID);
        /*
        if(uniqueID != null && MM.RDS.equals(MMUtilities._getDriverType(uniqueID)))
        {
            for(Enumeration _enum = m_runtimeDatasources.elements(); _enum.hasMoreElements();)
            {
                RuntimeDatasource _rds = (RuntimeDatasource)_enum.nextElement();
                if(_rds != null)
                {
                    MDObject _mdObj = _rds.getMDObjectByUniqueID(uniqueID);
                    if(_mdObj != null)
                    {
                        _mdObj.setMetadataManagerServices(this);
                        return _mdObj;
                    }
                }
            }
            // couldn't find it so return null.  don't look anywhere else.
            return null;
        }
        */
        // if it is not here, we need to call the middle tier
        MDObject[] mdObjects = m_MDIndex.getMDObjects ( properties ) ;
        if ( ( mdObjects != null ) && ( mdObjects.length > 0 ) ) {
            return mdObjects[0];
        }
        else {
            MDObject mdObject = m_MetadataManagerProxy.getMDObject( properties );
            if(mdObject != null)
            {
                mdObject.setMetadataManagerServices(this);
            }
            if(properties.getIntPropertyValue(PersistableConstants.SYSTEM_AGGREGATE) == MM.TRUE)
                properties.removeProperty(PersistableConstants.SYSTEM_AGGREGATE);
            else
                m_MDIndex.setMDObject(mdObject);
            return mdObject;
        }
    }

  	/**
     * @hidden
     * Retrieves the <code>MDObject</code> at the specified path.
     * For objects in an analytic workspace, the path name should look
     * something like the following:
     * <P>
     * <code>machine_name:service_name!Root\folder\parent\child</code>
     * <P>
     * For objects in the BI Beans Catalog, the path name should look something
     * like this:
     * <P>
     * <code>Root_folder/subfolder/object</code>
     * <P>
     * or
     * <p>
     * <code>subfolder/object</code>
     * <P>
     *
     * @param strPath The path of the <code>MDObject</code> that you want
     *                to retrieve.
     *
     * @return The <code>MDObject</code>.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method.
     *
     * @status hidden. If you unhide, please check my path information and
     * fix as necessary. THanks, Kris
     */
    public synchronized MDObject getMDObjectByPath(String strPath) throws MetadataManagerException {
    	return m_MDRoot.getMDObjectByPath(strPath, this, getMDRoot());
    }

	/**
     * @hidden
     * Retrieve multiple objects with specified properties
     *
     * @param properties    properties that we are looking for in MDObject
     *
     * @return  Array of MDObject with properties that match specified properties.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject[] getMDObjects( PropertyBag properties ) throws MetadataManagerException {
        if( properties == null )
            return null;
/*
        MDObject[] mdObjects = m_MDIndex.getMDObjects ( properties ) ;
        if ( ( mdObjects != null ) && ( mdObjects.length > 0 ) )
            return mdObjects;
        else
*/
        MDObject[] mdObjects = m_MetadataManagerProxy.getMDObjects( properties );
        if(mdObjects != null)
        {
            for(int i = 0; i < mdObjects.length; i++)
            {
                mdObjects[i].setMetadataManagerServices(this);
                m_MDIndex.setMDObject(mdObjects[i]);
            }
        }
        return mdObjects;
            //return m_MetadataManagerProxy.getMDObjects( properties );
    }

    /**
     * @hidden
     * Retrieve mdObjects that matches the given properties. (for a specified level)
     * Normally, object will come from the cache. But it can be overriden by
     * some property setting.
     *
     * @param mdObject      mdObject whose children are needed
     * @param properties    properties that we are looking for in MDObject
     *
     * @return  Array of MDObject with properties that match specified properties.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject[] getChildren( MDObject mdObject, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getChildren( properties );
    }


    /**
     * @hidden
     * Retrieve children for a particular level.
     *
     * @param mdObject      mdObject whose children are needed
     * @param properties    properties that we are looking for in MDObject
     * @param depth         depth of tree under the mdObject
     *
     * @return  Array of MDObject with properties that match specified properties.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject[] getChildren( MDObject mdObject,
                                   PropertyBag properties,
                                   int depth )
                                   throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getChildren( properties, depth );
    }

    /**
     * @hidden
     * Retrieve relatives with a particular relation
     *
     * @param mdObject   mdObject whose relatives are needed
     * @param relation   relation that relative has with mdObject
     *
     * @return  Array of MDObject with specified relation.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject[] getRelatives(	MDObject mdObject, String relation )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getRelatives( relation );
    }

    /**
     * @hidden
     * Retrieve relative with a particular properties
     *
     * @param mdObject      mdObject whose relatives are needed
     * @param properties    properties that we are looking for in MDObject
     *
     * @return  Array of relatives with specified relation.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject[] getRelatives(	MDObject mdObject, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (  mdObject == null )
            return null;
        return mdObject.getRelatives( properties );
    }

    /************************************************************************
    * Methods to update the cache and the drivers.
    ************************************************************************/
    /**
     * @hidden
     * deprecated as of 3.0, please use setMDObject(MDObject, Attributes) method instead
     */
    public synchronized MDObject setMDObject(MDObject mdObject, PropertyBag properties) throws MetadataManagerException
    {
        if (properties != null)
        {
            String _relation = properties.getStrPropertyValue(MM.RELATION);
            if (_relation != null)
                mdObject.setStrPropertyValue(MM.RELATION, _relation);
            properties.removeProperty(MM.RELATION);
        }
        return setMDObject(mdObject, MMUtilities.propertyBagToAttributes(properties));
    }
    
    /**
     * @hidden
     * Saves an <code>MDObject</code> that wraps a <code>UserObject</code> in it.
     * Call this method to save an object through the MetadataManager.
     * This method saves the object in the BI Beans Catalog.
     *
     * @param mdObject  The <code>MDObject</code> that wraps the
     *                  <code>UserObject</code> that you are saving.
     * @param properties Properties for <code>mdObject</code>.
     *
     * @return  An <code>MDObject</code> on which the driver has set properties.
     *          such as the unique ID and so on.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. For example, this exception is thrown
     *          if the caller does not have permission to write to the server.
     *
     * @status hidden
     */
    public synchronized MDObject setMDObject(MDObject mdObject, Attributes attributes) throws MetadataManagerException
    {
        if( mdObject == null)
            return null;

        String _path = MMUtilities.composePath(mdObject.getParent(), mdObject.toString());
        checkNameClash(mdObject, _path, mdObject.toString());

        // if mdObject has no id, generate one.
        if( mdObject.getObjectID() == MDU.ILLEGAL_LONG_VALUE ) {
            mdObject.setObjectID( generateMDObjectID() );
        }

        String relation = mdObject.getStrPropertyValue( MM.RELATION );

        UserObject[] userObjects = null;

        String _objType = mdObject.getObjectType();
        int _cacheSem = getCachingSemanticsByObjType(_objType);
        if (_cacheSem == MDU.NONE)
            userObjects = mdObject.getUserObjects();
        else
            userObjects = m_MDIndex.getUserObjects( mdObject );

        // save these, if any, for user after the middle tier call
        UserObject[] _localUserObjects = null;
        if (_cacheSem == MDU.NONE)
            _localUserObjects = mdObject.getUserObjects();

        if(userObjects != null && userObjects.length > 0)
        {
            /*
            for (int i=0; i<userObjects.length; i++)
            {
                try
                {
                    String driverType = userObjects[i].getDriverType();
                    
                    MetadataHandler _handler = (MetadataHandler)m_handlers.get(driverType);
                    if( _handler != null )
                        _handler.getStateBeforeBind(mdObject, userObjects[i].getObject(), null, null, attributes, m_envProps);
                    
                }
                catch ( javax.naming.NamingException ne)
                {
                    throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                        MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                        null,
                                                        m_Locale,
                                                        userObjects[i].getDriverType(),
                                                        ne );
                }
            }
            */
        }

        if (_cacheSem == MDU.NONE)
            mdObject.removeUserObject(MM.PERSISTENCE_OBJECT);

        // call setMDObject on middle-tier.
        mdObject.setMetadataManagerServices( (MetadataManagerServices) null );
        try
        {
            mdObject.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
            mdObject = m_MetadataManagerProxy.setMDObject( mdObject, attributes );
        }
        catch( MetadataManagerException e )
        {
            int status = MM.BOUND;
            try {
                status = mdObject.getBoundStatus();

            }
            catch( NullPointerException npe ) {
                // this will happen only if we are in local mode
            }
            if( status == MM.NOT_BOUND )
            {
                m_MDIndex.removeAllUserObject( mdObject );
//                mdObject.free();
            }
            throw e;
        }
        finally
        {
            if (mdObject != null)
                mdObject.setMetadataManagerServices(this);
        }

        // if caching semantic is none, then we must set back the PersistableAttributes
        // here.  Note that if caching semantic is not none, it would be taken care of
        // by processEventList method (piggyback)
        if (_localUserObjects != null)
        {
            /*
            for (int j=0; j<_localUserObjects.length; j++)
            {
                UserObject _usrObj = _localUserObjects[j];
                if (_usrObj != null)
                {
                    try
                    {
                        String driverType = _usrObj.getDriverType();
                        MetadataHandler _handler = (MetadataHandler)m_handlers.get(driverType);
                        if( _handler != null )
                            _handler.setStateAfterBind(mdObject, _usrObj.getObject(), null);
                    }
                    catch ( javax.naming.NamingException ne)
                    {
                        throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                null,
                                                m_Locale,
                                                _usrObj.getDriverType(),
                                                ne );
                    }
                }
            }
            */
        }
        else
        {
            UserObject _usrObj = m_MDIndex.getUserObject(mdObject.getObjectID(), MM.PERSISTENCE_OBJECT);
            /*
            if (_usrObj != null)
            {
                try
                {
                    String driverType = _usrObj.getDriverType();
                    MetadataHandler _handler = (MetadataHandler)m_handlers.get(driverType);
                    if( _handler != null )
                        _handler.setStateAfterBind(mdObject, _usrObj.getObject(), null);
                }
                catch ( javax.naming.NamingException ne)
                {
                    throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                            MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                            null,
                                            m_Locale,
                                            _usrObj.getDriverType(),
                                            ne );
                }
            }
            */
        }

        // clear the UserObjectBag of mdObject
        if(mdObject.getUserObjectCount() > 0)
        {
            UserObjectBag usrBag = mdObject.getUserObjectBag();
            UserObject[] usrObjs = mdObject.getUserObjects();
            for( int i = 0; i < usrObjs.length; i++ )
            {
                int cacheSemantic = usrObjs[i].getCacheSemantic();
                String _usrObjRelation = usrBag.getRelation( usrObjs[i] );
                // this is not caching the object, should be CLIENT instead of CLIENT_ONLY
                if( cacheSemantic == MDU.CLIENT_ONLY || cacheSemantic == MDU.BOTH )
                    m_MDIndex.setUserObject( mdObject, usrObjs[i], _usrObjRelation );

                mdObject.removeUserObject( _usrObjRelation );
            }
        }

        mdObject.setMetadataManagerServices( (MetadataManagerServices) this );
        MDObject mdParent = m_MDIndex.getMDObject ( mdObject.getParentID() );

        if ( mdParent != null )
        {
            MDObject _oldMDObject = getMDObjectByPath(mdObject.getPath());
            if (_oldMDObject != null && (_oldMDObject.getObjectID() != mdObject.getObjectID()))
            {
                // remove old MDObject first
                mdParent.removeChild(_oldMDObject);
                _oldMDObject.setParent(null);
                m_MDIndex.removeMDObject(_oldMDObject);
            }

            mdParent.setMetadataManagerServices(this);
            mdParent.setChild ( mdObject, relation );
            m_MDIndex.setMDObject( mdParent.getObjectID(), mdParent );
        }

        // add object to local cache
        m_MDIndex.setMDObject( mdObject.getObjectID(), mdObject );

        if( m_IsBatchEventMode )
            cacheMetadataModified( mdObject, relation );
        else 
        {
            MetadataModifiedEvent event = new MetadataModifiedEvent( this, false, mdObject, MetadataModifiedEvent.SET );
            m_EventSupport.fireMetadataModifiedEvent( event );
        }

        return mdObject;
    }
    /**
     * Indicates whether this object is the client-side part of the
     * MetadataManager.
     * Because this <code>MetadataManager</code> is the main client component,
     * this method always returns <code>true</code>.
     *
     * @return  <code>true</code>.
     *
     * @status Reviewed
     */
    public synchronized boolean isBeanClass(){
        return true;
    }

    /**
     * @hidden
     * Adds a userObject to local cache of MetadataManager.
     *
     * @param mdObject      MDObject whose userObject is being added to local cache
     * @param userObject    UserObject that needs to be added to cache.
     * @param relation      relation between userObject and mdObject
     *
     * @status hidden
     */
    public synchronized void _addUserObject( MDObject mdObject, UserObject userObject, String relation ){
        // if mdObject has no id, generate one.
        if( mdObject.getObjectID() == MDU.ILLEGAL_LONG_VALUE ) {
            mdObject.setObjectID( generateMDObjectID() );
        }
        m_MDIndex.setUserObject( mdObject, userObject, relation );
    }

    /**
     * @hidden
     * Removes an <code>MDObject</code>.
     * This method removes the object from the client-side cache, from the
     * server-side cache, and from the underlying driver.
     *
     * @param mdObject  Object to remove.
     *
     * @return A constant that indicates whether the object was successfully
     *         removed. Possible values are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public synchronized int removeMDObject( MDObject mdObject ) throws MetadataManagerException
    {
        if( mdObject == null )
            return MDU.FAILURE;

        int isSuccess;

        // mark this as a client request
        mdObject.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        // remove from middle-tier
        isSuccess = m_MetadataManagerProxy.removeMDObject( mdObject );

        if (isSuccess == MDU.SUCCESS)
        {
            // remove from local cache
            if (!MMUtilities.isMDM(mdObject))
            {
                isSuccess = m_MDIndex.removeMDObject( mdObject );
                MDObject _parent = mdObject.getParent();
                if (_parent != null)
                    _parent.removeChild(mdObject);
            }
            else
                mdObject.getDriverTypes().removeElement(MDU.PERSISTENCE);
        }
        
        MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.REMOVE);
        m_EventSupport.fireMetadataRefreshEvent( event );

        return isSuccess;
    }

    /**
     * @hidden
     * Remove all children from the client, server side cache and the driver.
     *
     * @param mdObject  MDObject whose children need to be removed
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException 
     *
     * @status hidden
     */
    public synchronized int removeAllChildren ( MDObject mdObject ) throws MetadataManagerException
    {
        if( mdObject == null )
            return MDU.FAILURE;
        int isSuccess;
        // remove children from local MDObject
        isSuccess = mdObject.removeAllChildren();

        // mark this as a client request
        mdObject.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        // remove children from MDObject on middle-tier
        isSuccess = m_MetadataManagerProxy.removeAllChildren( mdObject );
        return isSuccess;
    }

	/**
     * @hidden
     * Set a relative of mdObject
     *
     * @param firstObject   MDObject whose relative needs to be set
     * @param secondObject  MDObject that needs to be set as relative
     * @param relation      relation between firstObject and secondObject
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized int setRelatedMDObject( MDObject firstObject,
                                   MDObject secondObject,
                                   String relation )
                                   throws MetadataManagerException
    {
        if( firstObject == null || secondObject == null )
            return MDU.FAILURE;
        int isSuccess = firstObject.setRelative( secondObject, relation );
        isSuccess = m_MetadataManagerProxy.setRelatedMDObject( firstObject, secondObject, relation );
        return isSuccess;
    }

	/**
     * @hidden
     * Remove a relative of mdObject
     *
     * @param firstObject   MDObject whose relative needs to be removed
     * @param secondObject  MDObject that needs to be removed as relative
     * @param relation      relation between firstObject and secondObject
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized int removeRelatedMDObject( MDObject firstObject, MDObject secondObject, String relation ) throws MetadataManagerException {
        if( firstObject == null || secondObject == null )
            return MDU.FAILURE;
        int isSuccess = firstObject.removeRelative( secondObject );
        isSuccess = m_MetadataManagerProxy.removeRelatedMDObject( firstObject, secondObject, relation );
        return isSuccess;
    }

    /**
     * @hidden
     * Refreshes cached metadata objects from the server.
     * This method refreshes a specified object in the cache and all of its
     * cached children.
     * Both the client cache and the middle-tier cache are refreshed from
     * the server, so that they are all synchronized with the source platform.
     * Existing objects in each cache are replaced by the copies from
     * the server.
     *
     * @param mdObject  The object to refresh, along with its children.
     * @param depth     The number of levels under <code>mdObject</code> to
     *                  refresh. To refresh only <code>mdObject</code>,
     *                  pass 0. To refresh <code>mdObject</code> and its
     *                  children, pass 1.
     *
     * @return          <code>mdObject</code> after it has been refreshed.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
    public synchronized MDObject refresh(MDObject mdObject, int depth)
                                                throws MetadataManagerException
    {
        // clean the local cache
        if(mdObject.getObjectType().equals(MM.FOLDER)
           || mdObject.getObjectType().equals(MM.ROOT))
        {
            cleanCache(mdObject, MDU.PERSISTENCE);
        }
        else
        {
            m_MDIndex.removeUserObjects(mdObject);
            mdObject.removeAllUserObjects();
        }

        // refresh server side cache
        mdObject = m_MetadataManagerProxy.refresh(mdObject, depth);

        // set services
        mdObject.setMetadataManagerServices(this);

        // add mdObject to local cache
        m_MDIndex.setMDObject(mdObject);

        MetadataManagerEvent event = new MetadataManagerEvent(this, false, null);
        m_EventSupport.fireMetadataRefreshEvent( event );
        return mdObject;
    }

    /**
     * @hidden
     */
    private void cleanCache(MDObject mdObject, String driverType) throws MetadataManagerException
    {
        if(mdObject != null && driverType != null)
        {
            MDObject[] children = getChildrenFromIndex(mdObject);
            if(children != null)
            {
                for(int i = 0; i < children.length; i++)
                {
                    // Do not remove merged folder... clean the Persistence folder
                    // if and only if it is also not a MDM folder
                    if ((driverType.equals(MDU.PERSISTENCE) && !MMUtilities.isMDM(children[i])) ||
                        (driverType.equals(MDU.MDM) && MMUtilities.isMDM(children[i])))
                    {
                        if(children[i].getObjectType().equals(MM.FOLDER))
                            cleanCache(children[i], driverType);
                        m_MDIndex.removeMDObjectOnly(children[i]);
                    }
                }
            }
        }
    }

    /**
     * @hidden
     * Refreshes a cached user object from the source platform.
     *
     * @param mdObject  The <code>MDObject</code> that wraps the user object
     *                  that you want to refresh.
     * @param relation  The relationship between <code>mdObject</code> and
     *                  the user object that you want to refresh.
     *                  If the user object is stored
     * @param driverType The type of driver that stores the user object on
     *                  the server. You can call the <code>getDriverType</code>
     *                  of <code>mdObject</code> to get this parameter.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status hidden
     */
    public synchronized void refreshUserObject( MDObject mdObject,
                                   String relation,
                                   String driverType )
    throws MetadataManagerException
    {
        if( mdObject == null || relation == null ) {
            return;
        }
        UserObject usrObj = m_MetadataManagerProxy.getUserObject( mdObject, relation, driverType, null );
        /*
        if( usrObj != null ) {
            MetadataHandler handler = (MetadataHandler)m_handlers.get(usrObj.getDriverType());
            if( handler != null || usrObj != null ) {
                try
                {
                    Hashtable _env = new Hashtable(5, 5);
                    _env.put("session", m_session);
                    Object newObj = handler.getObjectInstance(mdObject, usrObj.getObject(), null, null, null, _env);
                    usrObj.setObject(newObj);
                    int cacheSemantic = usrObj.getCacheSemantic();
                    if(cacheSemantic == MDU.CLIENT_ONLY || cacheSemantic == MDU.BOTH) {
                        m_MDIndex.setUserObject( mdObject, usrObj, relation );
                    }
                }
                catch (Exception e)
                {
                    throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                        MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                        null,
                                                        m_Locale,
                                                        usrObj.getDriverType(),
                                                        e );

                }
            }
        }
        */
    }

    /**
     * @hidden
     * Not implemented
     * Support for Copy move operations.
     * Copy one object as another object's dependent.
     */
    public synchronized MDObject copy (MDObject objectToBeCopied, MDObject newParent, PropertyBag properties) throws MetadataManagerException
    {
        if (properties == null)
            properties = new PropertyBag();
        properties.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        String _newName = properties.getStrPropertyValue(MDU.COPY_NAME);
        if (_newName == null)
            _newName = objectToBeCopied.getName();
        String _path = MMUtilities.composePath(newParent, _newName);
        checkNameClash(objectToBeCopied, _path, _newName);

        objectToBeCopied.setMetadataManagerServices(this);
        newParent.setMetadataManagerServices(this);

        MDObject _mdObj = null;
        try
        {
            _mdObj = m_MetadataManagerProxy.copy(objectToBeCopied, newParent, properties);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            objectToBeCopied.setMetadataManagerServices(this);
            newParent.setMetadataManagerServices(this);
        }

        newParent.setMetadataManagerServices(this);
        if (_mdObj != null)
        {
            _mdObj.setParent(newParent);
            _mdObj.setMetadataManagerServices(this);
            newParent.setChild(_mdObj, _mdObj.getObjectType());
            if (_path != null)
                _mdObj.setPath(_path);
        }
        return _mdObj;
    }

    /**
     * @hidden
     * Not implemented
     * Move one object as a dependent of another object.
     */
    public synchronized int move ( MDObject objectToBeMoved,
                      MDObject newParent,
                      PropertyBag properties )
                      throws MetadataManagerException
    {
        String _path = MMUtilities.composePath(newParent, objectToBeMoved.getName());
        checkNameClash(objectToBeMoved, _path, objectToBeMoved.getName());

        if (properties == null)
            properties = new PropertyBag();
        properties.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        long _parentId = objectToBeMoved.getParentID();
        MDObject _oldParent = m_MDIndex.getMDObject(_parentId);
        if (_oldParent == null)
            _oldParent = objectToBeMoved.getParent();
            
        int _flag = MDU.FAILURE;
        try
        {
            m_MetadataManagerProxy.move(objectToBeMoved, newParent, properties);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            objectToBeMoved.setMetadataManagerServices(this);
            newParent.setMetadataManagerServices(this);
        }

        newParent.setChild(objectToBeMoved, objectToBeMoved.getObjectType());
        objectToBeMoved.setParent(newParent);

        if (_oldParent != null)
            _oldParent.removeChild(objectToBeMoved);

        if (_path != null)
            objectToBeMoved.setPath(_path);

        return _flag;
    }

    /**
     * @hidden
     * Not implemented
     * Full search on a folder.
     */
    public synchronized Vector search (MDObject mdObject, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
        Vector _results = m_MetadataManagerProxy.search(mdObject, attributes, controls);
        mdObject.setMetadataManagerServices(this);
        for (int i=0; i<_results.size(); i++)
        {
            MDObject _mdObj = (MDObject)_results.elementAt(i);
            _mdObj.setMetadataManagerServices(this);
        }
        return _results;
    }

    /**
     * @hidden
     */
    public synchronized Vector search (String uniqueID, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
        Vector _result = m_MetadataManagerProxy.search(uniqueID, attributes, controls);
        for(int i=0; _result != null && i < _result.size(); i++)
        {
            MetadataManagerSearchResultImpl _impl = (MetadataManagerSearchResultImpl)_result.elementAt(i);
            _impl.setMetadataManagerServices(this);
            String _str = _impl.getDriverType();
            /*
            ObjectFactory _factory = getObjectFactory(false, _str);
            if(_factory != null)
            {
                String _type = _impl.getObjectType();
                String _className = null;
                if (_type.equals(MM.FOLDER))
                    _className = "oracle.dss.metadataManager.common.MDFolder";
                else
                    _className = _factory.getObjectInstanceClassName(_type);

                if (_className != null)
                    _impl.setClassName(_className);
            }
            */
        }
        return _result;
    }

  /************************************************************************
  * Operations on the objects that only exist on the source platform.
  ************************************************************************/
    /**
     * @hidden
     * Retrieves a driver-specific object from the driver.
     * This method finds, on the server, an object whose properties match
     * those specified in <code>properties</code>.
     * This method returns the first object that matches the properties.
     *
     * @param properties    Properties that the returned object must match.
     * @param object        Object needed to get driver specific object
     *
     * @return              The driver-specific object that matches the
     *                       properties.
     *
     * @throws              MetadataManagerException
     *
     * @status hidden
     */
    public synchronized Object getDriverSpecificObject( PropertyBag properties,
                                           Object object )
                                                throws MetadataManagerException
    {
        if (!isProxyOK() || !isRemoteOK()) {
            return null;
        }
        if ( getAttachStatus() == MM.ATTACHED ) {
            return m_MetadataManagerProxy.getDriverSpecificObject( properties,
                                                                   object );
        }
        return null;
    }


    /**
     * @hidden
     * Set the driver specific objects on the driver
     *
     * @param object        driver specific object that needs to be set
     * @param properties    properties needed to set driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws              MetadataManagerException
     *
     * @status hidden
     */
    public synchronized int setDriverSpecificObject( Object object, PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (!isProxyOK() || !isRemoteOK()) {
            return MDU.FAILURE;
        }
        if ( getAttachStatus() == MM.ATTACHED ) {
            return m_MetadataManagerProxy.setDriverSpecificObject( object, properties );
        }
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Remove the driver specific objects at the driver level
     *
     * @param properties    properties needed to remove driver specific object
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status hidden
     */
	public synchronized int removeDriverSpecificObjects( PropertyBag properties )
                                                throws MetadataManagerException
    {
        if (!isProxyOK() || !isRemoteOK())
            return MDU.FAILURE;

        if ( getAttachStatus() == MM.ATTACHED ) {
            return m_MetadataManagerProxy.removeDriverSpecificObjects( properties );
        }
        return MDU.FAILURE;
    }

  /************************************************************************
  * Support for Security
  ************************************************************************/
    /**
     * @hidden
     */
    public synchronized boolean addEntries(MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        boolean _flag = false;
        try
        {
            _flag = m_MetadataManagerProxy.addEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            folder.setMetadataManagerServices(this);
        }
        return _flag;
    }

    /**
     * @hidden
     */
    public synchronized boolean removeEntries (MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        boolean _flag = false;
        try
        {
            _flag = m_MetadataManagerProxy.removeEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            folder.setMetadataManagerServices(this);
        }
        return _flag;
    }

    /**
     * @hidden
     */
    public synchronized boolean setEntries(MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException
    {
        boolean _flag = false;
        try
        {
            _flag = m_MetadataManagerProxy.setEntries(folder, name, entries, cascadeToSubFolders, cascadeToObjects);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            folder.setMetadataManagerServices(this);
        }
        return _flag;
    }

    /**
     * @hidden
     */
    public synchronized Vector entries (MDFolder folder, Name name) throws MetadataManagerException
    {
        Vector _entries = null;
        try
        {
            _entries = m_MetadataManagerProxy.entries(folder, name);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            folder.setMetadataManagerServices(this);
        }
        return _entries;
    }

    /**
     * @hidden
     * Get All Users
     * Not Implemented
     *
     * @status hidden
     */
    public synchronized Vector getAllUsers () throws MetadataManagerException
    {
        Vector _entries = null;
        try
        {
            _entries = m_MetadataManagerProxy.getAllUsers();
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        return _entries;
    }

    /**
     * @hidden
     */
    public synchronized Privilege getPrivilege (MDFolder folder, Name name) throws MetadataManagerException
    {
        Privilege _priv = null;
        try
        {
            _priv = m_MetadataManagerProxy.getPrivilege(folder, name);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            folder.setMetadataManagerServices(this);
        }
        return _priv;
    }

  /************************************************************************
  * Other
  ************************************************************************/
    /**
     * @hidden
     * Free all the contents and the object itself
     *
     * @param mdObject  MDObject that needs to be freed
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status hidden
     */
    public synchronized int free( MDObject mdObject ) throws MetadataManagerException {
        if(m_MDIndex != null)
            return m_MDIndex.removeMDObject( mdObject );
        return MDU.FAILURE;
    }

    /**
     * Frees resources that the MetadataManager bean uses, including all
     * the connections that are associated with this <code>MetadataManager</code>.
     * Call this method before you close your application.
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status Reviewed
     */
    public synchronized int free() throws MetadataManagerException
    {
        return free(true);
    }

    /**
     * Frees resources that the MetadataManager bean uses.
     * You can specify whether to free all associated connections.
     *
     * @param freeConnection <code>true</code> to free connections,
     *                       <code>false</code> to free resources but not
     *                                         connections.
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @throws MetadataManagerException If the connection fails during the
     *         execution of this method
     *
     * @status Reviewed
     */
    public synchronized int free(boolean freeConnection) throws MetadataManagerException
    {
        int _status = 0;
        if(getAttachStatus() == MM.ATTACHED)
        {
            _status = detach(freeConnection);
        }

        if(m_MDRoot != null)
        {
            m_MDRoot.free();
            m_MDRoot = null;
        }

        // MetadataManager no longer listens to connection events
        Connection[] _cons = getConnections();
        if(_cons != null)
        {
            for(int i = 0; i < _cons.length; i++)
            {
                _cons[i].removeListener(this);
            }
        }

        // Free the connections associated with the MetadataManager
        if(freeConnection && _cons != null)
        {
            for(int i = 0; i < _cons.length; i++)
            {
                try
                {
                    _status = _cons[i].free();
                }
                catch(ConnectionException e)
                {
                    throw new MetadataManagerException(MetadataManagerClientBundle.class,
                                                       MetadataManagerClientBundle.EXC_CANNOT_FREE_CONNECTION,
                                                       null,
                                                       m_Locale,
                                                       _cons[i].getDriverType(),
                                                       e);
                }
            }
        }

        m_Connections = null;
        m_session = null;
        m_MDRoot = null;
        m_EventSupport = null;
        if(m_handlers != null)
        {
            m_handlers.clear();
            m_handlers = null;
        }
        if(m_MetadataModifiedEventCache != null)
        {
            m_MetadataModifiedEventCache.removeAll();
            m_MetadataModifiedEventCache = null;
        }
        if(m_cachingSemantics != null)
        {
            m_cachingSemantics.clear();
            m_cachingSemantics = null;
        }
        if( m_MDIndex != null ) {
            m_MDIndex.free();
            m_MDIndex = null;
        }
        if ( m_MetadataManagerProxy != null ) {
            //m_MetadataManagerProxy.remove();
            m_MetadataManagerProxy = null;
        }

        if(m_envProps != null)
        {
            m_envProps.clear();
            m_envProps = null;
        }

        return _status;
    }

  /************************************************************************
  *											MetadataManagerService interface methods
  *************************************************************************

  /************************************************************************
  * Attach and Detach Drivers
  ************************************************************************/
    /**
     * @hidden
     * Attach a Metadata Driver
     * Not Implemented
     *
     * @status hidden
     */
    public synchronized int attachDriver ( PropertyBag propertyBag )
                                                throws MetadataManagerException
    {
		return 0;
    }

    /**
     * @hidden
     * Detach a Metadata Driver
     * Not Implemented
     *
     * @status hidden
     */
    public synchronized int detachDriver (PropertyBag properties)
                                                throws MetadataManagerException
    {
        return 0;
    }

    /**
     * @hidden
     * Is the Driver Attached?
     *
     * @status hidden
     */
    public synchronized boolean isDriverAttached(PropertyBag propertyBag)
    {
        if(m_MetadataManagerProxy != null && propertyBag != null
                                          && propertyBag.size() > 0)
        {
            return m_MetadataManagerProxy.isDriverAttached(propertyBag);
        }
        return false;
    }

    /**
     * @hidden
     * Indicates whether the persistence driver is attached.
     *
     * @return <code>true</code> if a persistence connection is set on
     *          this <code>MetadataManager</code> and is
     *         attached,
     *         <code>false</code> if no persistence connection is set or if
     *           the connection is not connected.
     *
     * @status hidden
     */
    public synchronized boolean isPersistenceDriverAttached()
    {
        PropertyBag _bag = new PropertyBag();
        _bag.setStrPropertyValue(MDU.DRIVER_TYPE, MDU.PERSISTENCE);
        return isDriverAttached(_bag);
    }

    /************************************************************************
    * Get objects from any tier.
    ************************************************************************/

    /**
     * @hidden
     * Retrieve an mdObject from the server side cache.
     *
     * @param mdObjectID    ID of the mdObject that need to be retrieved
     *
     * @return  MDObject with specified objectID
     *
     * @status hidden
     */
    public synchronized MDObject getMDObjectByID( long mdObjectID ) throws MetadataManagerException {
        // if it is not there we need to call the middle tier.
        MDObject mdObject = m_MDIndex.getMDObject ( mdObjectID );
        if( mdObject == null ) {
            mdObject = m_MetadataManagerProxy.getMDObjectByID( mdObjectID );
            if(mdObject != null){
                mdObject.setMetadataManagerServices(this);
            }
            m_MDIndex.setMDObject( mdObject );
        }
        return mdObject;
    }

    /************************************************************************
     * Support for User Objects ( for example XML object of Graph)
     * from the driver based on an MDObject.
     ************************************************************************/
    /**
     * @hidden
     * Retrieves a <code>UserObject</code>.
     *
     * @param mdObject      The <code>MDObject</code> that aggregates the
     *                      <code>UserObject</code> that you want.
     * @param relation      The relationship between <code>mdObject</code> and
     *                      <code>userObject</code>.
     * @param driverType    The driverType of userObject
     *
     * @return The user object.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status hidden
     */
    public synchronized UserObject getUserObject( MDObject mdObject,
                                     String relation,
                                     String driverType)
                                     throws MetadataManagerException
    {
        return getUserObject(mdObject, relation, driverType, null);
    }

    /**
     * @hidden
     * Retrieves a <code>UserObject</code>.
     *
     * @param mdObject      mdObject that contains the userObject
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     * @param args          hashtable that might contain objects that can help restore
     *                      userObject on client side.
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. 
     *
     * @status hidden
     */
    public synchronized UserObject getUserObject( MDObject mdObject,
                                     String relation,
                                     String driverType,
                                     Hashtable args )                                      
                                     throws MetadataManagerException

    {
        return getUserObject(mdObject, null, relation, driverType, args);
    }

    /**
     * @hidden
     * Retrieves a <code>UserObject</code>.
     *
     * @param mdObject      mdObject that contains the userObject
     * @param persistable   Persistable object that will be passed 
     *                      to a handler when creating a new object
     * @param relation      relation between mdObject and userObject
     * @param driverType    driverType of userObject
     * @param args          hashtable that might contain objects that can help restore
     *                      userObject on client side.
     *
     * @return UserObject
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status hidden
     */
    public synchronized UserObject getUserObject( MDObject mdObject,
                                     Persistable persistable,
                                     String relation,
                                     String driverType,
                                     Hashtable args )
                                     throws MetadataManagerException
    {
        if( mdObject == null || relation == null ) {
            return null;
        }

        // fixing bug#1871639, don't look into cache if Persistable is
        // specified.
        boolean _cacheObject = true;
        if (persistable != null)
            _cacheObject = false;

        UserObject userObject = null;
        if (_cacheObject)
            userObject = m_MDIndex.getUserObject( mdObject, relation );

        // holds the key and value so we can restore when pass to the client
        if( userObject != null )
        {
            return userObject;
        }
        else
        {
            // Clone of m_envProps
            Hashtable _envClone = (Hashtable)m_envProps.clone();
            Hashtable _containers= new Hashtable(10);
            // over-write the m_envProps's clone with passed-in args
            if(args != null)
            {
                Enumeration enumer = args.keys();
                while(enumer.hasMoreElements())
                {
                    Object _key = enumer.nextElement();
                    _envClone.put(_key, args.get(_key));
                }
            }
/*
            Enumeration _keys = _envClone.keys();
            while (_keys.hasMoreElements())
            {
                Object _key = _keys.nextElement();
                Object _val = _envClone.get(_key);

                if (_val instanceof JboContainer)
                {
                    // JBO magic
                    ComponentObject _comp = ((JboContainer)_val).getComponentObject();
                    _envClone.put(_key, _comp);
                    _containers.put(_key, _val);
                }
            }
*/
            // set locale and errorHandler on _argsClone
            if(!_envClone.containsKey(PersistableConstants.PERSISTENCE_ERRORHANDLER)) {
                _envClone.put(PersistableConstants.PERSISTENCE_ERRORHANDLER, getErrorHandler());
            }
            if(!_envClone.containsKey(PersistableConstants.PERSISTENCE_LOCALE)) {
                _envClone.put(PersistableConstants.PERSISTENCE_LOCALE, getLocale());
            }

            UserObject _usrObj = m_MetadataManagerProxy.getUserObject( mdObject, relation, driverType, _envClone );
            if(_usrObj != null && _envClone.get(PersistableConstants.SYSTEM_AGGREGATE) != null)
                return _usrObj;

            if (_usrObj != null)
            {
                if (_containers.size() > 0)
                {
                    Enumeration _enum = _containers.keys();
                    while (_enum.hasMoreElements())
                    {
                        Object _key = _enum.nextElement();
                        _envClone.put(_key, _containers.get(_key));
                    }
                }
                /*
                MetadataHandler _handler = (MetadataHandler)m_handlers.get(_usrObj.getDriverType());
                if(_handler != null)
                {
                    try
                    {
                        Object _newObj = _handler.getObjectInstance(mdObject, _usrObj.getObject(), persistable, null, null, _envClone);
                        _usrObj.setObject(_newObj);

                        // fix for bug #1871639, if Persistable is specified, don't cache
                        // the resulting object also.
                        if (_cacheObject)
                        {
                            int mdObjCachingSemantics = getCachingSemanticsByObjType(mdObject.getObjectType());
                            if (mdObjCachingSemantics != MDU.NONE && mdObjCachingSemantics != MDU.SERVER)
                                m_MDIndex.setUserObject( mdObject, _usrObj, relation );
                        }
                    }
                    catch (Exception e)
                    {
                        throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                            MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                            null,
                                                            m_Locale,
                                                            _usrObj.getDriverType(),
                                                            e );
                    }
                }
                */
            }

            MDObject _mdObj = m_MDIndex.getMDObject(mdObject.getObjectID());
            if (_mdObj != null)
                mdObject = _mdObj;

            mdObject.setMetadataManagerServices(this);
            return _usrObj;
        }
    }

    /**
     * @hidden
     * return the UserObject in MDIndex, needed by the driver
     */
    public synchronized UserObject _getUserObject(MDObject mdObject, String relation)
    {
        if( mdObject == null || relation == null )
            return null;

        return m_MDIndex.getUserObject(mdObject, relation);
    }

    /************************************************************************
     * MetadataManagerObject interface methods
     ************************************************************************/
  /************************************************************************
  * MetadataManager Client methods
  *************************************************************************/

	/**
     * Retrieves the <code>MDFolder</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDFolder</code> objects.
     *
     * @status Reviewed
     */
    public synchronized MDFolder[] getFolders() throws MetadataManagerException {
        return m_MDRoot.getFolders();
    }

	/**
     * Retrieves the <code>MDMeasure</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDMeasure</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     * 
     * @status Reviewed
     */
    public synchronized MDMeasure[] getMeasures() throws MetadataManagerException{
      	PropertyBag propBag = new PropertyBag();
      	propBag.setStrPropertyValue( MDU.OBJECT_TYPE, MM.MEASURE );
      	return MDMeasure.getMeasureArray(getMDObjects(propBag));
  	}

	/**
     * Retrieves the <code>MDDimension</code> objects for
     * the <code>MDRoot</code> object.
     *
     * @return The <code>MDDimension</code> objects.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status Reviewed
     */
  	public synchronized MDDimension[] getDimensions() throws MetadataManagerException{
      	PropertyBag propBag = new PropertyBag();
      	propBag.setStrPropertyValue( MDU.OBJECT_TYPE, MM.DIMENSION );
        MDDimension[] dimensions = MDDimension.getDimensionArray(getMDObjects(propBag));
      	MDDimension measureDimension = getMeasureDimension(null);
      	int intIndex = MMUtilities._indexOf(dimensions, measureDimension);
      	if (intIndex != -1) {
      		MDDimension[] removeMeasureDimension = new MDDimension[dimensions.length-1];
			System.arraycopy(dimensions, 0, removeMeasureDimension, 0, intIndex);
			System.arraycopy(dimensions, intIndex+1, removeMeasureDimension, intIndex, dimensions.length-(intIndex+1));
      		return removeMeasureDimension;
      	}
      	return dimensions;
	}

    /**
     * Retrieves a metadata object that has the specified property values and
     * object type.
     *
     * @param  strPropertyName    The property name to find.
     * @param  vstrPropertyValues A list of property values to find.
     * @param  ObjectType         The type of object to retrieve.
     *
     * @return An object of <code>ObjectType</code> that has all of the
     *         specified property values, or <code>null</code> if the object
     *         could not be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Documented
     */
    public synchronized MDObject getMDObject(String strPropertyName, Vector vstrPropertyValues, String objectType) throws MetadataManagerException {
        PropertyBag propertyBag = new PropertyBag();
        propertyBag.setStringVectorPropertyValue (strPropertyName, vstrPropertyValues, MDU.UI_NONE);
        return getMDObject(propertyBag);
    }

    /**
     * Retrieves a metadata object that has the specified property values and
     * object type.
     *
     * @param  strPropertyName The property name to find.
     * @param  vstrPropertyValues A list of property values to find.
     * @param  ObjectType The type of object to retrieve.
     *
     * @return An object of <code>ObjectType</code> that has all of the
     *         specified property values, or <code>null</code> if the object
     *         could not be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     * @see    oracle.dss.metadataManager.common.MM#UNIQUE_ID
     */
  	public synchronized MDObject getMDObject(String strPropertyName, String strPropertyValue, String objectType) throws MetadataManagerException {
     	PropertyBag propertyBag = new PropertyBag();
    	propertyBag.setStrPropertyValue(strPropertyName, strPropertyValue, MDU.UI_NONE);
    	propertyBag.setStrPropertyValue(MDU.OBJECT_TYPE, objectType, MDU.UI_NONE);
      	return getMDObject(propertyBag);
    }

  	/**
  	 * Retrieves the first <code>MDFolder</code> object that has a specified
     * property value.
     *
     * @param  strPropertyName a <code>String</code> value that
     *         represents the property name to find.
     * @param  strPropertyValue a String value that contains
     *         a property value to find.e.
     *
     * @return The first folder that has the <code>strPropertyValue</code> value
     *         for the <code>strPropertyName</code> property, or <code>null</code>
     *         if no folder can be found that has the property value.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     */
    public synchronized MDFolder getFolder(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.FOLDER );
        if(_mdObj instanceof MDFolder)
            return (MDFolder) _mdObj;
        return null;
    }

  	/**
     * @deprecated
     * Retrieves the first selection that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first selection that has the specified property value, or
     *         <code>null</code> if no selection can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *         execution of this method or if there is a problem retrieving
     *         objects from the server. 
     *
     * @status Reviewed
     */
  	public synchronized MDSelection getSelection(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
    	return (MDSelection) getMDObject ( strPropertyName, strPropertyValue, MM.SELECTION );
  	}

    /**
     * @hidden
     * Retrieves the first <code>MDComponent</code> that has a specified
     * property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return <code>MDComponent</code> that has the specified property value,
     *         or <code>null</code> if no object can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server.
     *
     * @status hidden
     */
  	public synchronized MDComponent getComponent(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
    	return (MDComponent) getMDObject ( strPropertyName, strPropertyValue, MM.COMPONENT );
  	}

  	/**
     * Retrieves the first measure that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first measurethat has the specified property value, or
     *         <code>null</code> if no measure can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     * @see    oracle.dss.metadataManager.common.MM#UNIQUE_ID
     * @see    oracle.dss.metadataManager.common.MM#OLAPI_METADATA_ID
     */
    public synchronized MDMeasure getMeasure(String strPropertyName, String strPropertyValue) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.MEASURE );
        if(_mdObj instanceof MDMeasure)
            return (MDMeasure) _mdObj;
        return null;
    }

  	/**
     * Retrieves the first dimension that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first dimension that has the specified property value, or
     *         <code>null</code> if no dimension can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see    oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     * @see    oracle.dss.metadataManager.common.MM#UNIQUE_ID
     * @see    oracle.dss.metadataManager.common.MM#OLAPI_METADATA_ID
     */
    public synchronized MDDimension getDimension(String strPropertyName, String strPropertyValue) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.DIMENSION );
        if(_mdObj instanceof MDDimension)
            return (MDDimension) _mdObj;
        return null;
    }

  	/**
     * Retrieves the first hierarchy that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     * 
     * @return The first hierarchy that has the specified property value, or
     *         <code>null</code> if no hierarchy can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     * @see oracle.dss.metadataManager.common.MM#UNIQUE_ID
     * @see oracle.dss.metadataManager.common.MM#OLAPI_METADATA_ID
     */
    public synchronized MDHierarchy getHierarchy(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.HIERARCHY );
        if(_mdObj instanceof MDHierarchy)
            return (MDHierarchy) _mdObj;
        return null;
    }

  	/**
     * @hidden
     * Retrieves the first attribute that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first attribute that has the specified property value, or
     *         <code>null</code> if no attribute can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
    public synchronized MDAttribute getAttribute(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.ATTRIBUTE );
        if(_mdObj instanceof MDAttribute)
            return (MDAttribute) _mdObj;
        return null;
    }

  	/**
     * Retrieves the first level that has a specified property value.
     *
     * @param  strPropertyName The name of the property to find.
     * @param  strPropertyValue The property value to find.
     *
     * @return The first level that has the specified property value, or
     *         <code>null</code> if no level can be found.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see oracle.dss.metadataUtil.MDU#OBJECT_NAME
     * @see oracle.dss.metadataUtil.MDU#OBJECT_LABEL
     * @see oracle.dss.metadataManager.common.MM#UNIQUE_ID
     * @see oracle.dss.metadataManager.common.MM#OLAPI_METADATA_ID
     */
    public synchronized MDLevel getLevel(String strPropertyName, String strPropertyValue ) throws MetadataManagerException {
        MDObject _mdObj = getMDObject ( strPropertyName, strPropertyValue, MM.LEVEL );
        if(_mdObj instanceof MDLevel)
            return (MDLevel) _mdObj;
        return null;
    }

    /**
     * Indicates whether two unique IDs for levels refer to the same
     * Level in the database.
     *
     * @param id1   First ID string to compare
     * @param id2   Second ID string to compare
     * @return <code>true</code> if they are equivalent,
     *         <code>false</code> if they are not equivalent.
     *
     * @status Reviewed
     */
    public synchronized boolean areLevelIDsEquivalent(String id1, String id2)
    {
        try
        {
            MDLevel level1 = (MDLevel)getMDObject(MM.UNIQUE_ID, id1, MM.LEVEL);
            if (level1 != null)
            {
                MDLevel level2 = (MDLevel)getMDObject(MM.UNIQUE_ID, id2, MM.LEVEL);
                if (level2 != null)
                {
                    return level1.nameEquals(level2);
                }
            }
        }
        catch (MetadataManagerException e)
        {
            m_eh.error(e, getClass().getName(), "areLevelIDsEquivalent");
        }
        
        return false;
    }

  	/**
     * @hidden
     * Retrieves a folder from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the folder that
     *                 you want.
     *
     * @return The folder that has <code>strUniqueID</code>, or <code>null</code>
     *         if no folder can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDFolder getFolderByUniqueID(String strPropertyValue) throws MetadataManagerException {
  		return getFolder(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a selection from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the selection that
     *                 you want.
     *
     * @return The selection that has <code>strUniqueID</code>, or <code>null</code>
     *         if no selection can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDSelection getSelectionByUniqueID(String strPropertyValue) throws MetadataManagerException {
  		return getSelection(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a component from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the component that
     *                 you want.
     *
     * @return The component that has <code>strUniqueID</code>, or <code>null</code>
     *         if no component can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDComponent getComponentByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getComponent(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a measure from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the measure that
     *                 you want.
     *
     * @return The measure that has <code>strUniqueID</code>, or <code>null</code>
     *         if no measure can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDMeasure getMeasureByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getMeasure(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a dimension from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the dimension that
     *                 you want.
     *
     * @return The dimension that has <code>strUniqueID</code>, or <code>null</code>
     *         if no dimension can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDDimension getDimensionByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getDimension(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a hierarchy from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the hierarchy that
     *                 you want.
     *
     * @return The hierarchy that has <code>strUniqueID</code>, or <code>null</code>
     *         if no hierarchy can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDHierarchy getHierarchyByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getHierarchy(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a attribute from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the attribute that
     *                 you want.
     *
     * @return The attribute that has <code>strUniqueID</code>, or <code>null</code>
     *         if no attribute can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @status hidden
     */
  	public synchronized MDAttribute getAttributeByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getAttribute(MM.UNIQUE_ID, strPropertyValue);
  	}

  	/**
     * @hidden
     * Retrieves a level from a unique identifier.
     *
     * @param  strUniqueID The unique ID that corresponds to the level that
     *                 you want.
     *
     * @return The level that has <code>strUniqueID</code>, or <code>null</code>
     *         if no level can be found with <code>strUniqueID</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public synchronized MDLevel getLevelByUniqueID(String strPropertyValue) throws MetadataManagerException {
	  	return getLevel(MM.UNIQUE_ID, strPropertyValue);
  	}

    /**
     * Retrieves measures that have specified dimensions.
     * To retrieve measures that have any of the specified dimensions,
     * pass <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the measures that have all of the specified dimensions,
     * pass <code>MM.INTERSECTION</code>.
     *
     * @param dimensions The dimensions that the retrieved measures should have.
     * @param flags A constant that indicates whether to retrieve measures
     *              that have any of the <code>dimensions</code> or only the
     *              measures that have all of the <code>dimensions</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server. 
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status Reviewed
     */
  public synchronized MDMeasure[] measuresOfDimensions(MDDimension[] dimensions, String flags)
                                                throws MetadataManagerException
  {
    return m_MDRoot.measuresOfDimensions(dimensions, flags);
  }

    /**
     * Retrieves the dimensions that specified measures have.
     * To retrieve the dimensions that any of the measures has, pass
     * <code>MM.UNION</code> as the <code>flags</code> parameter.
     * To retrieve only the dimensions that all of the measures have, pass
     * <code>MM.INTERSECTION</code>.
     *
     * @param measures The measures whose dimensions you want.
     * @param flags A constant that indicates whether to include the
     *              dimensions that any of the <code>measures</code> has or the
     *              dimensions that are common to all <code>measures</code>.
     *              Valid constants are listed in the See Also section.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @see oracle.dss.metadataManager.common.MM#UNION
     * @see oracle.dss.metadataManager.common.MM#INTERSECTION
     *
     * @status Reviewed
     */
  public synchronized MDDimension[] dimensionalityOfMeasures(MDMeasure[] measures, String flags)
                                                throws MetadataManagerException
  {
    return m_MDRoot.dimensionalityOfMeasures(measures, flags);
  }


    /**
     * Retrieves the measure dimension for this <code>MetadataManager</code>.
     * The measure dimension is the dimension that lists available measures.
     * Currently ignored.
     *
     * @param dbString  The analytic workspace whose measure dimension you want.
     *
     * @return The measure dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     * 
     * @status Documented
     */
    public synchronized MDDimension getMeasureDimension( String dbString )
                                                throws MetadataManagerException
    {
        MDDimension _measDim = (MDDimension) m_MDRoot.getMeasureDimension();
        if(_measDim == null)
        {
            for(Enumeration _enum = m_Connections.elements(); _enum.hasMoreElements();)
            {
                Connection _conn = (Connection)_enum.nextElement();
                if(MM.MDM.equals(_conn.getDriverType()))
                {
                    try
                    {
                        MDFolder _fld = _conn.getRoot();
                        if(_fld != null)
                            return (MDDimension)_fld.getFirstChild(MM.MEASURE_DIMENSION);
                            
                        MDFolder _mdmRoot = (MDFolder)m_MDRoot.getObjPropertyValue("MDM_ROOT");
                        if(_mdmRoot != null)
                        {
                            _mdmRoot.setMetadataManagerServices(this);
                            _conn.setRoot(_mdmRoot);
                            _measDim = (MDDimension)_mdmRoot.getFirstChild(MM.MEASURE_DIMENSION);
                        }
                    }
                    catch(ConnectionException ce) {ce.printStackTrace();}
                }
            }
        }
        return _measDim;
    }

    /**
     * Specifies labels for measure dimension for this <code>MetadataManager</code>.
     *
     * @param propertyBag  <code>PropertyBag</code> that contains labels settings.
     *
     * @throws MetadataManagerException If there is a problem retrieving
     * Measure Dimension object or if <code>propertyBag</code> contains a property that
     * is a nonlabel property, such as <code>MM.OBJECT_NAME</code>.
     *
     * @status NeedsChange  :  Please add the following constants after the 'strPropertyName'
     *                         param (Imran)
     * @see oracle.dss.metadataManager.common.MM#SHORT_LABEL
     * @see oracle.dss.metadataManager.common.MM#SHORT_PLURAL_LABEL
     * @see oracle.dss.metadataManager.common.MM#LONG_LABEL
     * @see oracle.dss.metadataManager.common.MM#LONG_PLURAL_LABEL
     * @see oracle.dss.metadataManager.common.MM#MEDIUM_LABEL
     */
    public synchronized void setMeasureDimensionLabels(PropertyBag propertyBag)
                                                throws MetadataManagerException
    {
        if(propertyBag != null && propertyBag.size() > 0)
        {
            MDObject measDim = getMDRoot().getFirstChild(MM.MEASURE_DIMENSION);
            StringBuffer _strBuff = new StringBuffer();
            if(measDim != null)
            {
                Property[] props = propertyBag.getProperties();
                for(int i = 0; i < props.length; i++)
                {
                    String name = props[i].getName();
                    if(name.equals(MM.SHORT_LABEL) || name.equals(MM.SHORT_PLURAL_LABEL)
                       || name.equals(MM.LONG_LABEL) || name.equals(MM.LONG_PLURAL_LABEL)
                       || name.equals(MM.MEDIUM_LABEL))
                        measDim.setProperty(props[i]);
                    else
                    {
                        _strBuff.append(name + ",");
                        propertyBag.removeProperty(name);
                    }
                }
            }
            else
            {
                getErrorHandler().log("Could not find Measure Dimension under root folder",
                                       getClass().getName(), "setMeasureDimensionLabels");
            }

            if(isProxyOK())
                m_MetadataManagerProxy.setMeasureDimensionLabels(propertyBag);

            if(_strBuff.length() > 0)
            {
                String _str = _strBuff.toString().substring(0, _strBuff.length() - 1);
                throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                    MetadataManagerClientBundle.EXC_ILLEGAL_PROPERTY,
                                                    new String[]{_str},
                                                    m_Locale,
                                                    MDU.MDM);
            }
        }
    }

	/****************************************************
	 * Unpublished public Methods
	 ****************************************************/
	// Is RemoteOK?
    /**
     * @hidden (I assume, since it's under "unpublished")
     */
  public synchronized boolean isRemoteOK() {
		return m_IsRemoteOK;
  }

    /**
     * @hidden (I assume, since it's under "unpublished")
     */
	public synchronized int setRemoteOK( boolean isRemoteOK ) {
		m_IsRemoteOK = 	isRemoteOK;
		return MDU.SUCCESS;
	}

  //	Retrieves metadataManager proxy associated with this metadataManager.
  // 	return MetadataManagerObject proxy.
  /**
   * @hidden (since MetadataManagerObject is hidden)
   */
  public synchronized MetadataManagerObject getProxy() {
  		if (isProxyOK())
      	return m_MetadataManagerProxy;
      return null;
  }

    /**
     * Specifies the locale that this <code>MetadataManager</code> uses.
     *
     * @param locale    The <code>Locale</code> for this
     *                   <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
    public synchronized void setLocale(Locale locale) 
    {
        if (locale != null)
        {
            m_Locale = locale;
            /*
            if (m_handlers != null)
            {
                Enumeration _enum = m_handlers.elements();
                while (_enum.hasMoreElements())
                {
                    MetadataHandler _handler = (MetadataHandler)_enum.nextElement();
                    _handler.setLocale(locale);
                }
            }
            */
            if(m_MetadataManagerProxy != null)
                m_MetadataManagerProxy.setLocale( locale );
        }
    }

    /**
     * Retrieves the locale that this <code>MetadataManager</code> uses.
     *
     * @return The locale for this <code>MetadataManager</code> uses.
     *
     * @status Reviewed
     */
    public synchronized Locale getLocale() {
        return m_Locale;
    }

	/****************************************************
	 * Private Methods
	 ****************************************************/
    /**
     * @hidden
     * Gets the Instance ID.
     *
     * @return The <code>instanceID</code> of MetadataManager.
     *
     * @status private
     */
    private static int getInstanceID() {
        return m_InstanceID;
    }

    /**
     * @hidden
     * Is the proxy OK?
     *
     * @return <code>true</code> if proxy is set.
     *         <code>false</code> if proxy is not set.
     *
     * @status private
     */
    private boolean isProxyOK() {
        if ( m_MetadataManagerProxy == null )
            return false;
        return true;
    }

    /**
     * @hidden
     * Set up the metadataManager with App module.
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status private
     */
    private int initMetadataManager() throws MetadataManagerException
    {
        getBeanName();
        if (!isRemoteOK())
            return MDU.FAILURE;

        // Determine if our proxy object already exists
        if (m_session == null)
            throw new MetadataManagerException(MetadataManagerClientBundle.class, MetadataManagerClientBundle.EXC_NO_BISESSION, null, getLocale(), "");

        if(m_MetadataManagerProxy == null)
        {
            m_MetadataManagerProxy = new oracle.dss.metadataManager.server.MetadataManagerImpl();
            //m_MetadataManagerProxy.setCallbackObject(this);
            setAttachStatus(MM.NOT_ATTACHED);
            m_InstanceID ++;
        }

/*
        if (m_MetadataManagerProxy == null)
        {
            try
            {
                ApplicationModule _am = m_session.getApplicationModule();
                if (_am != null)
                {
                    m_MetadataManagerProxy = (MetadataManagerObject)_am.createComponentObject(null, "oracle.dss.appmodule.MetadataManager");
                    m_MetadataManagerProxy.setCallbackObject(this);
                    setAttachStatus( MM.NOT_ATTACHED );
                }
                
                if (m_MetadataManagerProxy != null)
                {
                    m_InstanceID ++;
       		        return MDU.SUCCESS;
                }
                else
                    return MDU.FAILURE;
            }
            catch (Exception e)
            {
                throw new MetadataManagerException(MetadataManagerClientBundle.class, MetadataManagerClientBundle.EXC_APPMODULE, null, getLocale(), "", e);
            }
        }
        else*/
   		    return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Set Connection objects to this MetadataManager instance
     *
     * @param connections   Vector of connection objects
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws MetadataManagerException
     *
     * @status private
     */
    private int setConnectionObjects( Vector connections ) throws MetadataManagerException
    {
        if ((!isRemoteOK()) || (!isProxyOK()) || ( connections == null ))
            return MDU.FAILURE;

        int count = connections.size();
        
        // re-arrange the vector so that MDM connection is first,
        // so that the jdbc connection can be passed to the file based persistence
        if(count > 1)
        {
            for(int i=0; i<count; i++)
            {
                Connection connection = (Connection)connections.elementAt(i);
                if(MDU.MDM.equals(connection.getDriverType()) && i > 0)
                {
                    connections.removeElementAt(i);
                    connections.insertElementAt(connection, 0);
                    break;
                }
            }
        }

        if ( count == 0 )
            return MDU.FAILURE;

        int _flag = MDU.FAILURE;
        Object _mdmJdbcConnection = null;
        ConnectionObject[] connectionObjects = new ConnectionObject[count];
        for ( int i =0; i < count; i ++ ) {
            Connection connection = (Connection) connections.elementAt(i);
            try {
                if ( connection != null ) {
                    // check if it is a persistence connection.  If it is, then
                    // pass in the mdm jdbc connection
                    if(_mdmJdbcConnection != null && MDU.PERSISTENCE.equals(connection.getDriverType()))
                        connection.setProperty(PersistableConstants.OLAP_JDBC_CONNECTION, _mdmJdbcConnection);
                    
                    if ( !connection.isConnected() ) {
                        connection.connect();
                    }
                    
                    if(_mdmJdbcConnection == null && MDU.MDM.equals(connection.getDriverType()))
                        _mdmJdbcConnection = connection.getConnectionObject();
                    
                    // Did we set the connection's Connection on the middle tier?
                    connection.setConnection();
                    ConnectionObject connectionObject = connection.getProxy();
                    if(connectionObject != null) {
                        connectionObjects[i] = connectionObject;
                        Property prop = connection.getProperty("SET_ON_MID_TIER");
                        if(prop != null)
                        {
                            connection.removeProperty("SET_ON_MID_TIER");
                            _flag = m_MetadataManagerProxy.setConnectionObject(connectionObject);
                        }
                    }
                }
            }
            catch( ConnectionException e ) {
                String _errCode = ((Exception)getRootBIException(e)).getMessage().substring(0, 9);
                Logger.getLogger("oracle.dss.metadataManager.client").log(Level.SEVERE, "connect failed", e);                
                throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                    MetadataManagerClientBundle.EXC_SET_CONNECTION_FAILURE,
                                                    new String[] {_errCode},
                                                    m_Locale,
                                                    connection.getDriverType(),
                                                    e );
            }
        }
        return _flag; //m_MetadataManagerProxy.setConnectionObjects( connectionObjects );
    }

    /**
     * @hidden
     * Retrieve handler for specified driverType
     *
     * @param driverType    driverType for which handler is required
     *
     * @return              MetadataHandler object
     *
     * @status hidden
     */
     /*
    public synchronized MetadataHandler getMetadataHandler(String driverType)
    {
        if (driverType != null)
            return (MetadataHandler)m_handlers.get(driverType);
        else
            return null;
    }
    */

    /**
     * @hidden
     * Set handler with specified driverType
     *
     * @param driverType    driverType for which handler is to be set
     * @param handler       MetadataHandler object that needs to be set
     *
     * @status hidden
     */
     /*
    public synchronized void setMetadataHandler(String driverType, MetadataHandler handler)
    {
        if (driverType != null && handler != null)
            m_handlers.put(driverType, handler);
    }
    */

   	/****************************************************
	 * Persistable Methods
	 ****************************************************/
    /**
     * @hidden
     * Initializes this <code>MetadataManager</code> with the persistence environment.
     * The persistence service calls this method when it loads the
     * <code>MetadataManager</code>, so that the component can use environment
     * properties to initialize itself.
     * Environment properties are defined in the <code>Context</code> interface in
     * JNDI.
     * <P>
     * Application developers do not need to call this method.
     *
     * @param env   Environment properties.
     *
     * @status hidden
     */
    public synchronized void initialize(Hashtable env)
    {
        if(env == null)
            return;
        if(env.containsKey(PersistableConstants.PERSISTENCE_ERRORHANDLER))
            addErrorHandler((ErrorHandler)env.get(PersistableConstants.PERSISTENCE_ERRORHANDLER));
        if(env.containsKey(PersistableConstants.PERSISTENCE_LOCALE))
            setLocale((Locale)env.get(PersistableConstants.PERSISTENCE_LOCALE));
        setSession((BISession)env.get(CB.BISESSION));
    }

    /**
     * @hidden
     * Retrieves a list of <code>Persistable</code> components that this
     * <code>MetadataManager</code> aggregates.
     * The MetadataManager aggregates connections.
     *
     * @return Information about each connection that this
     *            <code>MetadataManager</code> aggregates.
     *
     * @see oracle.dss.connection.client.Connection
     *
     * @status hidden
     */
    public synchronized AggregateInfo[] getPersistableComponents()
    {
        Vector _aggrs = new Vector(m_Connections.size());
        for (int i=0; i<m_Connections.size(); i++)
        {
            Connection _con = (Connection)m_Connections.elementAt(i);
            if (!_con.getDriverType().equals(MDU.PERSISTENCE) || m_savePersistenceConnection)
                _aggrs.addElement(new AggregateInfo((Connection)m_Connections.elementAt(i), i));
        }

        AggregateInfo[] _result = new AggregateInfo[_aggrs.size()];
        _aggrs.copyInto(_result);

        return _result;
    }

    /**
     * @hidden
     * Specifies a list of <code>Persistable</code> components that this
     * <code>MetadataManager</code> aggregates.
     * The MetadataManager bean aggregates connection objects.
     *
     * @param persistables  An <code>AggregateInfo</code> for each connection
     *                      that this <code>MetadataManager</code> has.
     *
     * @see oracle.dss.connection.client.Connection
     *
     * @status hidden
     */
    public synchronized void setPersistableComponents(AggregateInfo[] persistables)
    {
        for (int i=0; i<persistables.length; i++)
        {
            Connection _con = (Connection)persistables[i].getPersistable();
            try
            {
                setConnection(_con);
            }
            catch (MetadataManagerException mme)
            {
                // ignore, should not happen
            }
//            m_Connections.addElement(_con);
/*
            String _conStr = _con.getConnectionString();
            if (_conStr != null)
            {
                String _dbStr = (String)m_dbStrConStrPair.get(_conStr);
                if (_dbStr != null)
                    setDatabaseString(_dbStr, _con);
            }
*/
        }
    }

    /**
     * @hidden
     * Retrieves the attributes of this <code>MetadataManager</code>, for
     * searching.
     * This method adds the attributes that this <code>MetadataManager</code>
     * defines to any attributes that the application has defined.
     * The attributes are used by the persistence service, when users
     * search the BI Beans Catalog for components that have particular attribute
     * values.
     *
     * @param attrs The searchable attributes that the application has
     *              defined for this component.
     *
     * @return The full set of attributes for this connection.
     *
     * @status hidden
     */
    public synchronized PersistableAttributes getPersistableAttributes(PersistableAttributes attrs)
    {
        PersistableAttributes _attrs = null;

        if (attrs != null)
            _attrs = attrs;
        else
            _attrs = new PersistableAttributes();

        _attrs.setObjectType(PersistableConstants.METADATAMANAGER);
        _attrs.setObjectTypeVersion(s_xmlVersion);

        return _attrs;
    }

    /**
     * @hidden
     * Specifies attributes that can be used for searching in the BI Beans Catalog.
     * This implementation does nothing.
     *
     * @param attrs Any <code>PersistableAttributes</code>.
     *
     * @status hidden
     */
    public synchronized void setPersistableAttributes(PersistableAttributes attrs)
    {
        // do nothing
    }

    /**
     * Retrieves the XML representation of this <code>MetadataManager</code>.
     * This method is called by the persistence service when you save the
     * <code>MetadataManager</code> to the BI Beans Catalog.
     * Application developers should not need to call this method.
     *
     * @return The XML representation of this <code>MetadataManager</code>.
     *
     * @throws BIPersistenceException If a problem occurs in getting the
     *          XML.
     *
     * @status Reviewed
     */
    public synchronized String getXMLAsString() throws BIPersistenceException
    {
        ObjectNode _root = new ObjectNode(s_xmlNameTag);
/*
        ContainerNode _dbs = new ContainerNode("DatabaseList");
        for (int i=0; i<m_Connections.size(); i++)
        {
            Connection _con = (Connection)m_Connections.elementAt(i);

            if (_con.getConnectionString() != null)
            {
                ObjectNode _db = new ObjectNode("Database");
                _db.addProperty("ConnectionString", _con.getConnectionString());
                _db.addProperty("DatabaseString", getDatabaseString(_con.getConnectionString()));

                _dbs.addContainedObject(_db);
            }
        }
        _root.addContainer(_dbs);
*/
        String _xml = null;

        try
        {
            XMLObjectWriter _writer = new XMLObjectWriter();
            _writer.setIndentEnabled(true);
            _writer.writeObjectNode(_root);
            _xml = _writer.toString();
        }
        catch (BIXMLException pe)
        {
            getErrorHandler().error(pe, getClass().getName(), "getXMLAsString");
        }

        return _xml;
    }

    /**
     * Specifies the XML representation of this <code>MetadataManager</code>.
     * The persistence service calls this method when the
     * <code>MetadataManager</code> is restored from the BI Beans Catalog.
     * Application developers should not need to call this method.
     *
     * @param name  The XML representation of this <code>MetadataManager</code>.
     * @return <code>true</code> the XML was successfully set,
     *         <code>false</code> if not.
     *
     * @throws BIPersistenceException If a problem occurs in setting the XML.
     *
     * @status Reviewed
     */
    public synchronized boolean setXMLAsString(String xml) throws BIPersistenceException
    {
/*
        try
        {
            XMLObjectReader _reader = new XMLObjectReader(xml);
            ObjectNode _node = _reader.readObjectNode();

            ContainerNode _dbs = _node.getContainer("DatabaseList");
            Enumeration _enum = _dbs.getContainedObject("Database");
            while (_enum.hasMoreElements())
            {
                ObjectNode _db = (ObjectNode)_enum.nextElement();
                String _dbStr = _db.getPropertyValueAsString("DatabaseString");
                String _conStr = _db.getPropertyValueAsString("ConnectionString");
                if (_dbStr != null && _conStr != null)
                    m_dbStrConStrPair.put(_conStr, _dbStr);
            }
        }
        catch (BIXMLException ioe)
        {
            getErrorHandler().error(ioe, getClass().getName(), "setXMLAsString");
        }
        catch (NoSuchPropertyException npe)
        {
            getErrorHandler().error(npe, getClass().getName(), "setXMLAsString");
        }
*/
        return true;
    }

    /**
     * @hidden
     */
    public synchronized int renameMDObject(MDObject mdObject, Name newName) throws MetadataManagerException
    {
        if (mdObject == null || newName == null)
            return MDU.FAILURE;
        
        String _newName = newName.get(newName.size()-1);
        MDObject _parent = mdObject.getParent();
        String _path = MMUtilities.composePath(_parent, _newName);

        checkNameClash(mdObject, _path, _newName);
        
        // _oldUniqueID is kept around so that it can be set as the reason
        // in the MetadataModified event.  _oldUniqueID is needed by
        // jdev/calcBuilder.
        String _oldUniqueID = mdObject.getUniqueID();

        int _flag = MDU.FAILURE;
        try
        {
            mdObject.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
            _flag = m_MetadataManagerProxy.renameMDObject(mdObject, newName);
            mdObject.removeProperty(MM.REQUEST_TYPE);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            mdObject.setMetadataManagerServices(this);
        }

        if (!MMUtilities.isMDM(mdObject))
        {
            // _path is constructed above
            // get atomic name
            mdObject.setName(newName.toString());
            if (_path != null)
                mdObject.setPath(_path);
        }
        else
        {
            // merged object: renaming causes this object to be no longer merged
            if (MMUtilities.isPersistence(mdObject))
                mdObject.getDriverTypes().removeElement(MDU.PERSISTENCE);
            if (MMUtilities.isDiscoverer(mdObject))
                mdObject.getDriverTypes().removeElement(MDU.DISCOVERER);
        }

        MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.RENAME);
        // set the _oldUniqueID as the reason of event.
        event.setReason(_oldUniqueID);

        m_EventSupport.fireMetadataModifiedEvent( event );

        return _flag;
    }
    
    /**
     * @hidden
     * Modifies the properties of an <code>MDObject</code>.
     * This method changes the properties of the object in the BI Beans
     * Catalog.
     *
     * @param mdObject  The <code>MDObject</code> in which the properties
     *                  are updated.
     * @param properties Properties that have changed for <code>mdObject</code>.
     *
     * @return <code>MDU.SUCCESS</code> if the modificatinon is successful,
     *         <code>MDU.FAILURE</code> if it is not.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem modifying
     *          the properties of the object on the server. For example, this
     *          exception is thrown if the caller does not have permission
     *          to write to the server.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public synchronized int modifyMDObject(MDObject mdObject, ModificationItem[] items) throws MetadataManagerException
    {
        if (items != null)
        {
            int _flag = MDU.FAILURE;
            try
            {
                mdObject.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
                _flag = m_MetadataManagerProxy.modifyMDObject(mdObject, items);
                mdObject.removeProperty(MM.REQUEST_TYPE);
            }
            catch (MetadataManagerException mme)
            {
                throw mme;
            }
            finally
            {
                mdObject.setMetadataManagerServices(this);
            }

            mdObject.setMetadataManagerServices(this);
            if (!MMUtilities.isMDM(mdObject))
            {
                // populate MDObject (later)
            }

            MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, mdObject, MetadataModifiedEvent.MODIFY);
            m_EventSupport.fireMetadataModifiedEvent( event );

            return _flag;
        }
        else
            return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Processes a list of events.
     * This method is called i
     */
    public synchronized void processEventList(EventObject[] el)
    {
        try
        {
            for (int i=0; i<el.length; i++)
            {
                m_eh.trace("processing piggyback event: "+el[i], getClass().getName(), "processEventList");
                if (el[i] instanceof MetadataModifiedEvent)
                {
                    MetadataModifiedEvent _evt = (MetadataModifiedEvent)el[i];
                    int _op = _evt.getModOperation();
                    if (_op == MetadataModifiedEvent.SET)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject added/replaced: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            MDObject _mdParent = m_MDIndex.getMDObject(_mdObj.getParentID());
                            if (_mdParent != null)
                            {
                                _mdParent.setChild (_mdObj, _mdObj.getObjectType());
                                m_MDIndex.setMDObject(_mdParent.getObjectID(), _mdParent);
                            }

                            UserObject _usrObj = m_MDIndex.getUserObject(_mdObj.getObjectID(), MM.PERSISTENCE_OBJECT);
                            /*
                            if (_usrObj != null)
                            {
                                try
                                {
                                    String driverType = _usrObj.getDriverType();
                                    MetadataHandler _handler = (MetadataHandler)m_handlers.get(driverType);
                                    if( _handler != null )
                                        _handler.setStateAfterBind(_mdObj, _usrObj.getObject(), null);
                                }
                                catch ( javax.naming.NamingException ne)
                                {
                                    throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                            MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                            null,
                                                            m_Locale,
                                                            _usrObj.getDriverType(),
                                                            ne );
                                }
                            }
                            */

                            // add object to local cache
                            m_MDIndex.setMDObject( _mdObj.getObjectID(), _mdObj);
                        }
                    }
                    else if (_op == MetadataModifiedEvent.REMOVE)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject removed: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            MDObject _mdParent = m_MDIndex.getMDObject(_mdObj.getParentID());
                            if (_mdParent != null)
                                _mdParent.removeChild(_mdObj);
                            m_MDIndex.removeMDObject(_mdObj);
                        }
                    }
                    else if (_op == MetadataModifiedEvent.REMOVEALL)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        MDObject _clientMDObj = m_MDIndex.getMDObject(_mdObj.getObjectID());
                        m_eh.trace("MDObject all children removed: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            if (_clientMDObj != null)
                                _clientMDObj.removeAllChildren();
                        }
                    }
                    else if (_op == MetadataModifiedEvent.COPY)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject copied to another folder: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            MDObject _mdParent = m_MDIndex.getMDObject(_mdObj.getParentID());
                            if (_mdParent != null)
                                _mdParent.setChild (_mdObj, _mdObj.getObjectType());
                        }
                    }
                    else if (_op == MetadataModifiedEvent.MOVE)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject moved to another folder: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            MDObject _old = m_MDIndex.getMDObject(_mdObj.getObjectID());
                            MDObject _oldParent = _old.getParent();

                            MDObject _mdParent = m_MDIndex.getMDObject(_mdObj.getParentID());
                            if (_mdParent != null)
                                _mdParent.setChild (_mdObj, _mdObj.getObjectType());

                            if (_oldParent != null)
                                _oldParent.removeChild(_mdObj);
                        }
                    }
                    else if (_op == MetadataModifiedEvent.MODIFY)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject has been modified: "+_mdObj, getClass().getName(), "processEventList");

                        if (_evt.isPiggybacked())
                        {
                            PropertyBag _bag = _mdObj.getPropertyBag();
                            if (_bag != null)
                            {
                                MDObject _obj = m_MDIndex.getMDObject(_mdObj.getObjectID());
                                if (_obj != null)
                                    _obj.setPropertyBag(_bag, MDU.KEEP);
                            }
                        }
                    }
                    else if (_op == MetadataModifiedEvent.DEPENDENT_LOAD)
                    {
                        MDObject _mdObj = (MDObject)_evt.getObject();
                        m_eh.trace("MDObject dependents are loaded: "+_mdObj, getClass().getName(), "processEventList");

                        MDObject _real = m_MDIndex.getMDObject(_mdObj.getObjectID());
                        // gek 9/25/01 If we don't find the real object, simply
                        //             continue instead of returning so that other
                        //             dependent MDObjects can be processed.
                        if (_real == null)
                            continue;

                        OrderedHashtable _table = _mdObj.getDependentID();
                        if (_table != null)
                        {
                            int nSize =
                                (_real.getDependentID() != null) ?
                                    _real.getDependentID().size() : 0;

                            if (nSize != _table.size())
                            {
                                Enumeration _enum = _table.keys();
                                while (_enum.hasMoreElements())
                                {
                                    Integer _pos = (Integer)_enum.nextElement();
                                    String _uniqueID = (String)_table.get(_pos);
                                    // gek 07/24/01 Fix Bug 1900268: Custom Measures
                                    //              don't properly reconstruct
                                    //              dimensionality in VB mode
                                    //
                                    //              We need to update dependencies for
                                    //              custom measures as well as
                                    //              Olap API MDM based measures.
                                    MDObject _dep = getMeasureByUniqueID(_uniqueID);
                                    if (_dep != null)
                                    {
                                        _real.setDependent(_dep, _pos.intValue());

                                        // gek 08/09/01 Move this processing to MDMeasure
                                        // updateDimensionality (_real);
                                    }
                                }
                            }
                        }
                    }
                    else if (_op == MetadataModifiedEvent.SET_REFERENCE)
                    {
                        String[] _mdObjIDs = (String[])_evt.getObject();
                        if(_mdObjIDs != null && _mdObjIDs.length == 3)
                        {
                            MDObject _referencedByObj = m_MDIndex.getMDObject(MM.UNIQUE_ID, _mdObjIDs[1]);
                            MDObject _referencedObj =  m_MDIndex.getMDObject(MM.UNIQUE_ID, _mdObjIDs[2]);
                            if(_referencedByObj != null && _referencedObj != null)
                                _referencedByObj._setReferencedObject(_mdObjIDs[0], _referencedObj);
                        }
                    }
                    else if (_op == MetadataModifiedEvent.REMOVE_REFERENCE)
                    {
                        String[] _mdObjIDs = (String[])_evt.getObject();
                        if(_mdObjIDs != null && _mdObjIDs.length == 2)
                        {
                            MDObject _referencedByObj = m_MDIndex.getMDObject(MM.UNIQUE_ID, _mdObjIDs[1]);
                            if(_referencedByObj != null)
                                _referencedByObj._removeReferencedObject(_mdObjIDs[0]);
                        }
                    }
                }
            }
        }
        catch (MetadataManagerException mme)
        {
            m_eh.error(mme, getClass().getName(), "processEventList");
        }
    }

    /**
     * @hidden
     * Add mdObject to the cache.  This method will not call the driver and
     * save mdObject.
     *
     * @param mdObject MDObject that is to be added to cache.
     *
     * @status hidden
     */
    public synchronized void setMDObjectInCache( MDObject mdObject ) throws MetadataManagerException {
        mdObject.setMetadataManagerServices(this);
        m_MDIndex.setMDObject( mdObject );
        m_MetadataManagerProxy.setMDObjectInCache( mdObject );
    }

    /**
     * Have the handling driver register the given MDObject provided all the necessary
     * properties have been set on that object
     * @param mdObject  object to register
     * @throws MetadataManagerException
     */
    public synchronized void addMDObject(MDObject mdObject) throws MetadataManagerException
    {
        mdObject.setMetadataManagerServices(this);
        m_MetadataManagerProxy.addMDObject(mdObject);
        m_MDIndex.setMDObject(mdObject);
    }
    
    /**
     * @hidden
     * Specifies whether to save the persistence connection when the
     * <code>MetadataManager</code> is saved.
     *
     * @param doBind  <code>true</code> to save the persistence connection,
     *                <code>false</code> to discard the persistence connection.
     *
     * @status hidden
     */
    public synchronized void bindPersistenceConnection(boolean doBind)
    {
        m_savePersistenceConnection = doBind;
    }

	/**
     * @hidden
     * Retrieve mdObject with specified properties from index.
     *
     * @param properties    properties that should exist in mdObject
     * @param fromIndex     <code>true</code>   return object from index only
     *                      <code>false</code>  return object from index. If
     *                                          not in index, go to server.
     *
     * @return mdObject from index that has similar properties.  Null is
     *         returned if no mdObject found.
     *
     * @throws  MetadataManagerException
     *
     * @status hidden
     */
    public synchronized MDObject getMDObject(PropertyBag properties, boolean fromClientIndex) throws MetadataManagerException
    {
        if(fromClientIndex)
        {
            MDObject[] mdObjects = m_MDIndex.getMDObjects(properties);
            if( (mdObjects != null) && (mdObjects.length > 0) )
                return mdObjects[0];
            return null;
        }
        else
        {
            MDObject[] mdObjects = m_MetadataManagerProxy.getMDObjects(properties);
            if( (mdObjects != null) && (mdObjects.length > 0) ){
                mdObjects[0].setMetadataManagerServices(this);
                m_MDIndex.setMDObject(mdObjects[0]);
                return mdObjects[0];
            }
            return null;
        }
    }

    /**
     * @hidden
     */
    public synchronized MDObject[] getChildrenFromIndex(MDObject mdObject)
    {
        OrderedHashtable childrenID = mdObject.getChildrenID();
        if(childrenID != null && childrenID.size() > 0)
        {
            OrderedHashtable table = m_MDIndex.getMDObjects(childrenID);
            if(table != null && table.size() > 0)
            {
                MDObject[] mdObjects = new MDObject[table.size()];
                Enumeration enumer = table.keys();
                for(int i = 0; enumer.hasMoreElements(); i++)
                {
                    mdObjects[i] = (MDObject)enumer.nextElement();
                }
                return mdObjects;
            }
            else
                return null;
        }
        else
        {
            return null;
        }
    }

    /**
     * Specifies the error for this <code>MetadataManager</code>.
     * The <code>MetadataManager</code> can have one and only one error handler.
     * The default handler prints messages to the console.
     *
     * @param errHandler  The error handler to use.
     *
     * @status Reviewed
     */
    public synchronized void addErrorHandler(ErrorHandler errHandler)
    {
        if (errHandler != null)
        {
            m_eh = errHandler;
            if(isProxyOK())
            {
                PropertyBag propBag = new PropertyBag();
                propBag.setStrPropertyValue("ErrorHandler", "add");
                try{
                    m_MetadataManagerProxy.setDriverSpecificObject(m_eh, propBag);
                }
                catch(MetadataManagerException mme)
                {
                    m_eh.error(mme, getClass().getName(), "addErrorHandler");
                }
            }
            /*
            if (m_handlers != null)
            {
                Enumeration _enum = m_handlers.elements();
                while (_enum.hasMoreElements())
                {
                    MetadataHandler _handler = (MetadataHandler)_enum.nextElement();
                    _handler.setErrorHandler(m_eh);
                }
            }
            */
        }
    }

    /**
     * Removes a customized error handler for this <code>MetadataManager</code>.
     * This method replaces the current error handler with a default error
     * handler.
     * The default error handler prints information to the console.
     *
     * @status Reviewed
     */
    public synchronized void removeErrorHandler()
    {
        m_eh = new DefaultErrorHandler();
        if(isProxyOK())
        {
            PropertyBag propBag = new PropertyBag();
            propBag.setStrPropertyValue("ErrorHandler", "remove");
            try{
                m_MetadataManagerProxy.setDriverSpecificObject("Default", propBag);
            }
            catch(MetadataManagerException mme)
            {
                m_eh.error(mme, getClass().getName(), "removeErrorHandler");
            }
        }
    }

    /**
     * @hidden
     * Retrieve errorhandler from metadataManager
     *
     * @return  errorhandler
     *
     * @status hidden
     */
    public synchronized ErrorHandler getErrorHandler()
    {
        return m_eh;
    }

    /**
     * Retrieves the object factory that this <code>MetadataManager</code> uses
     * to create new objects when loading XML from the BI Beans Catalog.
     *
     * @param remoteFactory <code>true</code> to retrieve the middle-tier object factory,
     *                   <code>false</code> to retrieve an object factory for
     *                    the client.
     *
     * @return The object factory for the <code>MetadataManager</code>.
     *
     * @status Reviewed
     */
     /*
    public synchronized ObjectFactory getObjectFactory(boolean remoteFactory)
    {
        return getObjectFactory(remoteFactory, MDU.PERSISTENCE);
    }
    */

    /**
     * @hidden
     */
     /*
    public synchronized ObjectFactory getObjectFactory(boolean remoteFactory, String driverType)
    {
        if (MDU.MDM.equals(driverType))
            return null;

        // should only do this once
        if (!remoteFactory && !m_remoteFactoryUsed)
        {
            // share the same ObjectFactory as the PersistenceManager
            Connection[] _cons = getConnections();
            for (int i=0; _cons != null && i<_cons.length; i++)
            {
                Connection _con = _cons[i];
                if (_con.getDriverType().equals(driverType))
                {
                    Object _remoteCon = _con.getRemoteConnectionLocal();
                    if (_remoteCon != null && _remoteCon instanceof BIContext)
                    {
                        BIContext _ctx = (BIContext)_remoteCon;
                        try
                        {
                            Object _factory = _ctx.getEnvironment().get("CSObjectFactory");
                            // CHANGE: only replace object factory from PersistenceManager if setRemoteConnection has been called
                            if (_factory != null && _factory instanceof ObjectFactory && _con.isRemoteConnectionUsed())
                            {
                                registerObjectFactory((ObjectFactory)_factory);
                                m_remoteFactoryUsed = true;
                                break;
                            }
                        }
                        catch (NamingException ne) {}
                    }
                }
            }
        }

        if (remoteFactory)
        {
            // depending of the driver type, return the appropriate factory
            if (MDU.PERSISTENCE.equals(driverType))
                return (FactoryProxy)(m_factoryProxies.get(MDU.PERSISTENCE));
            else if (MDU.DISCOVERER.equals(driverType))
                return (FactoryProxy)(m_factoryProxies.get(MDU.DISCOVERER));
            else // shouldn't get here, since MDU.MDM was checked at the very beginning of the method but the compiler wouldn't know that
                return null;
        }
        else
        {
            MetadataHandler _mdh = getMetadataHandler(driverType);
            if (_mdh != null)
                return _mdh.getObjectFactory();
            else
            {
                m_eh.log("No MetadataHandler found. Returning null for ObjectFactory.",
                         this.getClass().getName(),
                         "public ObjectFactory getObjectFactory(boolean remoteFactory)");
                return null;
            }
        }
    }

    // proxy to object factory in the middle-tier
    class FactoryProxy implements ObjectFactory
    {
        private String m_driverType = "";
        
        public FactoryProxy(String driverType)
        {
            if (driverType != null)
                m_driverType = driverType;
        }

        public Persistable getObjectInstance(StateObject agent, Hashtable appEnv) throws Exception
        {
            throw new oracle.dss.metadataManager.common.UnsupportedOperationException("", getLocale());
        }

        public Persistable getObjectInstance(StateAgent agent, Hashtable appEnv) throws Exception
        {
            throw new oracle.dss.metadataManager.common.UnsupportedOperationException("", getLocale());
        }

        public String getObjectInstanceClassName(String objType)
        {
            if (m_MetadataManagerProxy != null)
                return m_MetadataManagerProxy.getObjectInstanceClassName(objType, m_driverType);
            else
            {
                getErrorHandler().log("MetadataManager proxy not found, or not attached", getClass().getName(), "getObjectInstanceClassName");
                return null;
            }
        }

        public void setObjectInstanceClassName(String objType, String instanceClassName)
        {
            if (m_MetadataManagerProxy != null)
                m_MetadataManagerProxy.setObjectInstanceClassName(objType, instanceClassName, m_driverType);
            else
                getErrorHandler().log("MetadataManager proxy not found, or not attached", getClass().getName(), "getObjectInstanceClassName");
        }

        public String getObjectDefName(String objType)
        {
            if (m_MetadataManagerProxy != null)
                return m_MetadataManagerProxy.getObjectDefName(objType, m_driverType);
            else
            {
                getErrorHandler().log("MetadataManager proxy not found, or not attached", getClass().getName(), "getObjectInstanceClassName");
                return null;
            }
        }

        public void setObjectDefName(String objType, String defName)
        {
            if (m_MetadataManagerProxy != null)
                m_MetadataManagerProxy.setObjectDefName(objType, defName, m_driverType);
            else
                getErrorHandler().log("MetadataManager proxy not found, or not attached", getClass().getName(), "getObjectInstanceClassName");
        }

        public void dump()
        {
            if (m_MetadataManagerProxy != null)
                m_MetadataManagerProxy.dump(m_driverType);
            else
                getErrorHandler().log("MetadataManager proxy not found, or not attached", getClass().getName(), "dump");
        }
    }
    */
    /**
     * Registers a custom <code>ObjectFactory</code>.
     *
     * This method replaces any existing object factory with the one that
     * you specify in this method.
     *
     * @param factory  The <code>ObjectFactory</code> that you want to use.
     *
     * @status New
     */
     /*
    public synchronized void registerObjectFactory(ObjectFactory objFactory)
    {
        registerObjectFactory(objFactory, MDU.PERSISTENCE);
    }
    */
    /**
     * @hidden
     * Registers an object factory.
     * This method replaces any existing object factory with the one that
     * you specify in this method.
     *
     * @param factory  The object factory that you want to use.
     * @param remote     <code>true</code> if <code>factory</code> is stored
     *                   on the middle-tier,
     *                   <code>false</code> if <code>factory</code> is the
     *                   on the client.
     *
     * @status hidden
     */
     /*
    public synchronized void registerObjectFactory(ObjectFactory objFactory, String driverType)
    {
        if (objFactory == null)
            m_eh.log("Warning: objFactory passed in is null. Proceeding...",
                     this.getClass().getName(),
                     "public void registerObjectFactory(ObjectFactory objFactory)");
        MetadataHandler _mdh = getMetadataHandler(driverType);
        if (_mdh != null)
            _mdh.registerObjectFactory(objFactory);
        else
            m_eh.log("No MetadataHandler found. Can't register an ObjectFactory: ignoring... ",
                     this.getClass().getName(),
                     "public void registerObjectFactory(ObjectFactory objFactory)");
    }
    */

    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @return  an integer representing cachingSemantics of object of the specified type 
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status hidden
     */
    public synchronized int getCachingSemanticsByObjType(String objType)
    {
        if (objType == null)
            return MDU.NONE;
        Integer _int = (Integer)m_cachingSemantics.get(objType);
        if (_int == null)
            return MDU.NONE;
        else
            return _int.intValue();
    }

    /**
     * @hidden
     *
     * @param   objType a string representing the type of the object
     * @param   cachingSemantics caching semantics constant for the objType object type
     *          (see oracle.dss.metadatautil.MDU)
     *
     * @status hidden
     */
    public synchronized void setCachingSemanticsByObjType(String objType, int cachingSemantics)
    {
        m_cachingSemantics.put(objType, new Integer(cachingSemantics));
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @param referenceResolver a hashtable that gets passed when getting a UserObject
     * @return  a Persistable object
     *
     * @status hidden
     */
    public synchronized Persistable getPersistableObject(MDObject mdObj, Hashtable referenceResolver) throws BINamingException
    {
        Persistable _persistableObj = null;
        UserObject  _usrObj         = null; 
        try
        {
            if (referenceResolver != null)
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE, referenceResolver);
            else
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE);
        }
        catch(MetadataManagerException e)
        {
            // process the exception
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, null, getLocale(), e);
        }

        if (_usrObj == null)
            return null;
        else
            _persistableObj = (Persistable)(_usrObj.getObject());

        return _persistableObj;
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @param referenceResolver a hashtable that gets passed when getting a UserObject
     * @return  a Persistable object
     *
     * @status hidden
     */
    public synchronized Persistable getDiscovererObject(MDObject mdObj, Hashtable referenceResolver) throws BINamingException
    {
        Persistable _persistableObj = null;
        UserObject  _usrObj         = null; 
        try
        {
            if (referenceResolver != null)
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.DISCOVERER, referenceResolver);
            else
                _usrObj = mdObj.getUserObject(MM.PERSISTENCE_OBJECT, MDU.DISCOVERER);
        }
        catch(MetadataManagerException e)
        {
            // process the exception
            throw new BINamingException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_UNKNOWN, null, getLocale(), e);
        }

        if (_usrObj == null)
            return null;
        else
            _persistableObj = (Persistable)(_usrObj.getObject());

        return _persistableObj;
    }

    /**
     * @hidden
     *
     * @param mdObj an MDObject from which a Persistable object will be extracted
     * @return  a Persistable object
     *
     * @status hidden
     */
    public synchronized Persistable getPersistableObject(MDObject mdObj) throws BINamingException
    {
        return getPersistableObject(mdObj, (Hashtable)null);
    }

    /**
     * @hidden
     * Ignore the connecting event
     *
     * @param evt    Information about the connection request.
     *
     * @status hidden
     */
    public synchronized void connecting(ConnectionEvent evt){}

    /**
     * @hidden
     * Ignore the connected event
     *
     * @param evt    Information about the connection request.
     *
     * @status hidden
     */
    public synchronized void connected( ConnectionEvent evt ){}

    /**
     * @hidden
     * Detach if metadataManager is in attahed state
     *
     * @param evt    Information about the connection request.
     *
     * @status hidden
     */
    public synchronized void disconnecting( ConnectionEvent evt )
    {
        if(getAttachStatus() == MM.ATTACHED)
        {
            try
            {
                detach();
            }
            catch(MetadataManagerException mme)
            {
                getErrorHandler().error(mme, getClass().getName(), "disconnting");
            }
        }
    }

    /**
     * @hidden
     * Ignore the disconnected event
     *
     * @param evt    Information about the connection request.
     *
     * @status hidden
     */
    public synchronized void disconnected( ConnectionEvent evt ){}

    /**
     * @hidden
     */
    public synchronized MDObject getMDObjectUsingFullPath(String fullPath) throws MetadataManagerException
    {
        MDObject _mdObj = getMDObjectByPath(fullPath);
        if (_mdObj != null)
            return _mdObj;

        if(isProxyOK())
            return m_MetadataManagerProxy.getMDObjectUsingFullPath(fullPath);
        else
            return null;
    }

    /**
     * @hidden
     */
    public synchronized MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException
    {
        MDObject _mdObj = getMDObjectByPath(fullPath);
        if (_mdObj != null)
        {
            if (_mdObj instanceof MDFolder)
                return (MDFolder)_mdObj;
            else
                return null;
        }

        if(isProxyOK())
            return m_MetadataManagerProxy.getMDFolderUsingFullPath(fullPath);
        else
            return null;
    }

    /**
     * @deprecated As of 3.0, no longer supported 
     * Retrieves the attributes of an object.
     *
     * @param mdObj The object whose attributes you want to get.
     * @param properties An array of properties that you want.
     *
     * @return A PropertyBag that has the properties and their values.
     *
     * @throws MetadataManagerException
     *
     * @status deprecated
     */
    public synchronized PropertyBag getAttributes(MDObject mdObj, String[] properties) throws MetadataManagerException
    {
        Attributes _attrs = getAttributes(mdObj, properties, -1);
        return MMUtilities.attributesToPropertyBag(_attrs);
    }

    /**
     * @hidden
     */
    public synchronized Attributes getAttributes(MDObject mdObj, String[] properties, int flag) throws MetadataManagerException
    {
        if(isProxyOK())
            return m_MetadataManagerProxy.getAttributes(mdObj, properties, flag);
        else
            return null;
    }

    /**
     * @hidden
     */
    public synchronized void setDatabaseType(String databaseType, Connection connection)
    {
        String _str = connection.getConnectionString();
        if(_str == null)
            _str = connection.getOLAPServiceName();

        if(_str == null || _str.equals(""))
            _str = connection.getService();

        if(_str == null || _str.equals(""))
            _str = connection.getSID();
            
        String _dbStr = getDatabaseString(_str);
        if(m_MDRoot != null && _dbStr != null)
            m_MDRoot.setStrings(_dbStr, databaseType);
    }
    /**
     * @hidden
     */
    public synchronized String getDatabaseType(Connection connection)
    {
        String _str = connection.getConnectionString();
        if(_str == null)
            _str = connection.getOLAPServiceName();

        if(_str == null || _str.equals(""))
            _str = connection.getService();

        if(_str == null || _str.equals(""))
            _str = connection.getSID();

        String _dbStr = getDatabaseString(_str);
        if(m_MDRoot != null && _dbStr != null)
            return (String)m_MDRoot.getStringMap().get(_dbStr);

        return null;
    }

    // converts a property bag into attributes
    private Attributes propertyBagToAttributes(PropertyBag properties)
    {
        if (properties != null)
        {
            BasicAttributes _attrs = new BasicAttributes();
            Property[] _props = properties.getProperties();
            if (_props != null) {
              for (int i=0; i<_props.length; i++)
              {
                  String _key = _props[i].getName();
                  Object _val = _props[i].getObjValue();
                  if (_key != null && _val != null)
                      _attrs.put(_key, _val);
              }
            }

            return _attrs;
        }
        else
            return null;
    }

    private BIException getRootBIException(BIException excep)
    {
        if(excep.getPreviousException() == null || !(excep.getPreviousException() instanceof BIException))
            return excep;
        else
            return getRootBIException((BIException)excep.getPreviousException());
    }

    /**
     * @hidden
     */
    public int _setReferencedObject(PropertyBag props)
    {
        if((getAttachStatus() == MM.ATTACHED) && isProxyOK())
        {
            props.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
            return m_MetadataManagerProxy._setReferencedObject(props);
        }
        return MM.FAILURE;
    }

    /**
     * @hidden
     */
    public int _removeReferencedObject(PropertyBag props)
    {
        if((getAttachStatus() == MM.ATTACHED) && isProxyOK())
        {
            props.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
            return m_MetadataManagerProxy._removeReferencedObject(props);
        }
        return MM.FAILURE;
    }

    /**
     * @hidden
     * Register an MDInitializer with the MetadataManager
     *
     * @param init   Implementation of the MDInitializer interface. 
     * @param flag  MM.BEFORE_CONNECT : Before metadataManager calls connect on
     *                                  the connections contained by it.
     *              MM.BEFORE_ATTACH  : Before the metadataManager executes its
     *                                  initialization process.
     *              MM.AFTER_ATTACH   : After the metadataManager executes its
     *                                  initialization process.
     */
    public void addMDInitializer(MDInitializer init, String flag)
    {
        if(init != null && flag != null)
            m_mdInitializer.put(init, flag);
    }

    /**
     * @hidden
     * Remove the MDInitializer from the MetadataManager.
     *
     * @param init   Implementation of the MDInitializer interface. 
     */
    public void removeMDInitializer(MDInitializer init)
    {
        if(init != null)
            m_mdInitializer.remove(init);
    }

    /**
     * @hidden
     * Remove all the MDInitializer from the MetadataManager.
     *
     * @param init   Implementation of the MDInitializer interface. 
     */
    public void removeAllInitializers()
    {
        if(m_mdInitializer != null)
            m_mdInitializer.clear();
    }

    /**
     * @hidden
     * Remove all the MDInitializer from the MetadataManager associated with the specified flag.
     * 
     * @param flag  MM.BEFORE_CONNECT : Before metadataManager calls connect on
     *                                  the connections contained by it.
     *              MM.BEFORE_ATTACH  : Before the metadataManager executes its
     *                                  initialization process.
     *              MM.AFTER_ATTACH   : After the metadataManager executes its
     *                                  initialization process.
     */
    public void removeAllInitializers(String flag)
    {
        if(m_mdInitializer != null && flag != null)
        {
            Enumeration _enum = m_mdInitializer.keys();
            while(_enum.hasMoreElements())
            {
                Object _obj = _enum.nextElement();
                if(m_mdInitializer.get(_obj).equals(flag))
                    m_mdInitializer.remove(_obj);
            }
        }
    }

    /**
     * @hidden
     * Retrieve an array of MDInitializers set on the MetadataManager.
     *
     * @param flag  MM.BEFORE_CONNECT : Before metadataManager calls connect on
     *                                  the connections contained by it.
     *              MM.BEFORE_ATTACH  : Before the metadataManager executes 
     *                                  its initialization process.
     *              MM.AFTER_ATTACH   : After the metadataManager executes its
     *                                  initialization process.
     * @return  An array of MDInitializer.
     */
    public MDInitializer[] getMDInitializers(String flag)
    {
        MDInitializer[] _initArray = null;
        if(m_mdInitializer != null && flag != null)
        {
            Vector _vec = new Vector(5);
            Enumeration _enum = m_mdInitializer.keys();
            while(_enum.hasMoreElements())
            {
                Object _obj = _enum.nextElement();
                if(m_mdInitializer.get(_obj).equals(flag))
                    _vec.addElement(_obj);
            }
            if(_vec.size() > 0)
            {
                _initArray = new MDInitializer[_vec.size()];
                _vec.copyInto(_initArray);
            }
        }
        return _initArray;
    }

    // This method checks whether there is a non-Persistence object exists
    // in the system, if there is, throw NameClashException
    // this is used in:
    // 1) rebind/bind trying to save an object with name the same as an MDM/Discoverer object
    // 2) rename trying to rename an object with name the same as an MDM/Discoverer object
    // 3) move an object to a folder where there is an MDM/Discoverer object with the same name
    // 4) copy an object to a folder where there is an MDM/Discoverer object with the same name
    private void checkNameClash(MDObject mdObject, String path, String name) throws NameClashException
    {
        // we allow merging of folders
        if (mdObject instanceof MDFolder)
            return;
            
        // fixing bug where trying to save an object with the same name
        // as an MDM object
        MDObject _exists = null;
        try {
            _exists = getMDObjectUsingFullPath(path);
        }
        catch (MetadataManagerException mme) { // ignore 
        }

        if (_exists != null)
        {
            if (!MMUtilities.isPersistence(_exists))
            {
                NameClashException _nce = new NameClashException(name, getLocale(), mdObject.getDriverType(), null);
                _nce.setRebindAllowed(false);
                throw _nce;
            }
        }
    }

    /**
     * @hidden
     */
    public boolean getFeature(String feature)
    {
        if (m_MetadataManagerProxy != null)
            return m_MetadataManagerProxy.getFeature(feature);
        else
            return false;
    }

    /**
     * Retrieve java.sql.Connection from the OLAP connection in the MetadataManager.
     * @return java.sql.Connection from the OLAP connection if an OLAP connection
     *         exist in the MetadataManager; null otherwise.
     * @status new
     */
    public java.sql.Connection getConnection() throws MetadataManagerException
    {
        java.sql.Connection _conn = null;
        if(m_Connections != null && m_Connections.size() > 0)
        {
            for(Enumeration _enum = m_Connections.elements(); _enum.hasMoreElements();)
            {
                Connection _tmp = (Connection)_enum.nextElement();
                if(_tmp != null && MDU.MDM.equals(_tmp.getDriverType()))
                {
                    try
                    {
                        _conn = (java.sql.Connection)_tmp.getConnectionObject();
                        break;
                    }
                    catch(ConnectionException ce)
                    {
                        throw new MetadataManagerException(MetadataManagerClientBundle.class,
                                                           MetadataManagerClientBundle.EXC_NO_JDBC_CONNECTION,
                                                           null,
                                                           m_Locale,
                                                           _tmp.getDriverType(),
                                                           ce);
                    }
                }
            }
        }
        return _conn;
    }

    /**
     * @hidden
     * Replaces setMDObject method
     */
    public synchronized Attributes bind(MDFolder folder, Name name, Object object, Attributes attributes, Attributes bindAttrs, Hashtable env) throws MetadataManagerException
    {
        if(object == null)
            return null;

        // keep the object around for firing the event!
        Object _objToSave = object;

        String _path = MMUtilities.composePath(folder, name.toString());

        // keep it so that we can call the handler on the Persistable instead of the StateAgent
        Object _persistable = object;
        
        String _driverType = null;
        if(folder != null)
            _driverType = folder.getDriverType();
        if(MM.MDM.equals(_driverType) || _driverType == null)
            _driverType = MM.PERSISTENCE;
        /*    
        MetadataHandler _handler = null;
        try
        {
            if (bindAttrs != null)
            {
                if (bindAttrs.get(MDU.DRIVER_TYPE) != null)
                    _driverType = (String)bindAttrs.get(MDU.DRIVER_TYPE).get();
            }
            else
                bindAttrs = new BasicAttributes();
            
            _handler = (MetadataHandler)m_handlers.get(_driverType);

            // clone m_envProp and merge it with env; give precedence to env
            Hashtable _clone = (Hashtable)m_envProps.clone();
            if(env != null)
            {
                for(Enumeration _enum = env.keys(); _enum.hasMoreElements();)
                {
                    Object _key = _enum.nextElement();
                    _clone.put(_key, env.get(_key));
                }
            }
            if(!_clone.containsKey(MM.METADATA_MANAGER_SERVICES))
                _clone.put(MM.METADATA_MANAGER_SERVICES, this);
            if( _handler != null )
                object = _handler.getStateBeforeBind(object, name, folder, attributes, _clone);
        }
        catch ( javax.naming.NamingException ne)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                null,
                                                m_Locale,
                                                _driverType,
                                                ne );
        }
        */

        bindAttrs.put(MM.REQUEST_TYPE, MM.REMOTE);

        Attributes _attrs = null;
        try
        {
            _attrs = m_MetadataManagerProxy.bind(folder, name, object, attributes, bindAttrs, env);
        }
        catch (NameClashException nce)
        {
            // fixing bug# 3711513
            // unfortunately, this might cause a getAttribute call to the database
            MDObject _exists = null;
            try {
                _exists = getMDObjectUsingFullPath(_path);
            }
            catch (Exception ex) { // ignore 
            }

            if (_exists != null)
            {
                if (_exists instanceof MDFolder || !MMUtilities.isPersistence(_exists))
                    nce.setRebindAllowed(false);
            }

            throw nce;
        }
        /*
        try
        {
            if( _handler != null && _persistable != null)
                _handler.setStateAfterBind(_persistable, _attrs);
        }
        catch ( javax.naming.NamingException ne)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                    MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                    null,
                                    m_Locale,
                                    _driverType,
                                    ne );
        }
        */

        MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, _objToSave);
        m_EventSupport.fireMetadataModifiedEvent(event);

        if(_persistable instanceof MDObject && !(_persistable instanceof MDFolder))
        {
            MDObject _mdObj = (MDObject)_persistable;
            m_MDIndex.removeMDObject(_mdObj);
            
            if(_mdObj.getParent() != null)
                _mdObj.getParent().removeChild(_mdObj);

            // replace the object in sysagg cache.  If the object is not in the cache,
            // it will not be added to it.
            m_MetadataManagerProxy.updateLookupScopeCache(_mdObj.getUniqueID(), _mdObj.getPath(), _mdObj);
        }

        return _attrs;
    }

    // This method checks whether there is a non-Persistence object exists
    // in the system, if there is, throw NameClashException
    // this is used in:
    // 1) rebind/bind trying to save an object with name the same as an MDM/Discoverer object
    // 2) rename trying to rename an object with name the same as an MDM/Discoverer object
    // 3) move an object to a folder where there is an MDM/Discoverer object with the same name
    // 4) copy an object to a folder where there is an MDM/Discoverer object with the same name
/*
    private void checkNameClash(String driverType, String path, String name) throws NameClashException
    {
        // fixing bug where trying to save an object with the same name
        // as an MDM object
        MDObject _exists = null;
        try {
            _exists = getMDObjectUsingFullPath(path);
        }
        catch (MetadataManagerException mme) { // ignore 
        }

        if (_exists != null && !(_exists instanceof MDFolder))
        {
            if (!MMUtilities.isPersistence(_exists))
            {
                NameClashException _nce = new NameClashException(name, getLocale(), driverType, null);
                _nce.setRebindAllowed(false);
                throw _nce;
            }
        }
    }
*/
    /**
     * @hidden
     */
    public synchronized Object lookup(MDFolder folder, Name name, Persistable persistable, Hashtable args, Attributes options) throws MetadataManagerException
    {
        // Clone of m_envProps
        Hashtable _envClone = (Hashtable)m_envProps.clone();
        Hashtable _containers= new Hashtable(10);
        // over-write the m_envProps's clone with passed-in args
        if(args != null)
        {
            Enumeration enumer = args.keys();
            while(enumer.hasMoreElements())
            {
                Object _key = enumer.nextElement();
                _envClone.put(_key, args.get(_key));
            }
        }
/*
        Enumeration _keys = _envClone.keys();
        while (_keys.hasMoreElements())
        {
            Object _key = _keys.nextElement();
            Object _val = _envClone.get(_key);

            if (_val instanceof JboContainer)
            {
                ComponentObject _comp = ((JboContainer)_val).getComponentObject();
                _envClone.put(_key, _comp);
                _containers.put(_key, _val);
            }
        }
*/
        // set locale and errorHandler on _argsClone
        if(!_envClone.containsKey(PersistableConstants.PERSISTENCE_ERRORHANDLER)) {
            _envClone.put(PersistableConstants.PERSISTENCE_ERRORHANDLER, getErrorHandler());
        }
        if(!_envClone.containsKey(PersistableConstants.PERSISTENCE_LOCALE)) {
            _envClone.put(PersistableConstants.PERSISTENCE_LOCALE, getLocale());
        }

        if (options == null)
            options = new BasicAttributes();
            
        options.put(MM.REQUEST_TYPE, MM.REMOTE);

        try
        {
            Object _parser = m_session.getParser();
            if (_parser != null && XMLObjectReader.s_tls != null)
                XMLObjectReader.s_tls.set(_parser);

            Object _obj = m_MetadataManagerProxy.lookup(folder, name, persistable, _envClone, options);
        
            if (_obj != null)
            {
                if (_obj instanceof MDFolder || (_obj instanceof MDObject && MMUtilities.isMDM((MDObject)_obj)))
                {
                    ((MDObject)_obj).setMetadataManagerServices(this);
                    return _obj;
                }

                if (_containers.size() > 0)
                {
                    Enumeration _enum = _containers.keys();
                    while (_enum.hasMoreElements())
                    {
                        Object _key = _enum.nextElement();
                        _envClone.put(_key, _containers.get(_key));
                    }
                }

                String _driverType = MDU.PERSISTENCE;
                if (options != null)
                {
                    try
                    {
                        if (options.get(MDU.DRIVER_TYPE) != null)
                            _driverType = (String)options.get(MDU.DRIVER_TYPE).get();
                    }
                    catch (javax.naming.NamingException ne){}
                }
                return _obj;//handleStateAgent(_obj, _driverType, persistable, _envClone);
            }
        }
        finally
        {
            if (XMLObjectReader.s_tls != null)
                XMLObjectReader.s_tls.set(null);
        }

        return null;
    }

    /**
     * Register the driver with the MetadataManager bean.  This driver will be used to
     * retrieve the metadata through the connection.  The driverType associate with the
     * connection should be same as the driverType specified here.
     *
     * @param driverType String associated with the MetadataDriver.
     * @param driverImpl String representing the fully qualified class name of the 
     * MetadataDriver implementation.  The MetadataManager bean will instantiate the class at
     * attach time.
     */
    public void setDriverImpl(String driverType, String driverClassName)
    {
        if(m_driverImpl == null)
            m_driverImpl = new Hashtable();
            
        if(driverType != null && driverClassName != null)
            m_driverImpl.put(driverType, driverClassName);
    }

    /**
     * Retrieve the driver associated with the specified drivertype from the MetadataManager
     * bean.  
     *
     * @param driverType String associated with the MetadataDriver.
     * @return String representing the class driver class name
     */
    public String getDriverImpl(String driverType)
    {
        if(m_driverImpl != null && driverType != null)
            return (String)m_driverImpl.get(driverType);
        else
            return null;
    }

    /**
     * List the drivers associated with the metadataManager bean
     *
     * @return Hashtable containing properties where the driverType is the key
     * and driverImpl class name is the value.
     */
    public Hashtable listDriverImpl()
    {
        return (Hashtable)m_driverImpl.clone();
    }

    /**
     * De-register the driver from the metadataManager bean.
     *
     * @param driverType String associated with the MetadataDriver that should be removed.
     */
    public void removeDriverImpl(String driverType)
    {
        if(m_driverImpl != null && driverType != null)
            m_driverImpl.remove(driverType);
    }

    // New Methods
    public void renameMDObject( MDFolder mdFolder, Name oldName, Name newName ) throws MetadataManagerException
    {
        if (mdFolder == null || oldName == null || newName == null)
            return;
        
        String _oldName = oldName.get(oldName.size()-1);
        String _newName = newName.get(newName.size()-1);
        String _path = MMUtilities.composePath(mdFolder, _newName);

//        checkNameClash(_oldName, _path, _newName);

        // _oldUniqueID is kept around so that it can be set as the reason
        // in the MetadataModified event.  _oldUniqueID is needed by
        // jdev/calcBuilder.
        MDObject[] _objs = getChildrenFromIndex(mdFolder);
        String _oldUniqueID = null;
        MDObject _mdObj = null;
        for(int i=0; _objs != null && i < _objs.length; i++)
        {
            if(_objs[i].getName() != null && _objs[i].getName().equals(_oldName))
            {
                _oldUniqueID = _objs[i].getUniqueID();
                _mdObj = _objs[i];
                break;
            }
        }

        int _flag = MDU.FAILURE;
        try
        {
            mdFolder.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
            m_MetadataManagerProxy.renameMDObject(mdFolder, oldName, newName);
            mdFolder.removeProperty(MM.REQUEST_TYPE);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            mdFolder.setMetadataManagerServices(this);
        }

        if(_mdObj != null && !MMUtilities.isMDM(_mdObj))
        {
            // _path is constructed above
            // get atomic name
            _mdObj.setName(newName.toString());
            if (_path != null)
                _mdObj.setPath(_path);
        }
        else if(_mdObj != null)
        {
            // merged object: renaming causes this object to be no longer merged
            if (MMUtilities.isPersistence(_mdObj))
                _mdObj.getDriverTypes().removeElement(MDU.PERSISTENCE);
            if (MMUtilities.isDiscoverer(_mdObj))
                _mdObj.getDriverTypes().removeElement(MDU.DISCOVERER);
        }

        MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, _mdObj, MetadataModifiedEvent.RENAME);
        // set the _oldUniqueID as the reason of event.
        event.setReason(_oldUniqueID);

        m_EventSupport.fireMetadataModifiedEvent( event );
    }
    
    public void modifyMDObject( MDFolder mdFolder, Name name, ModificationItem[] items ) throws MetadataManagerException
    {
        if (items != null)
        {
            try
            {
                mdFolder.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
                m_MetadataManagerProxy.modifyMDObject(mdFolder, name, items);
                mdFolder.removeProperty(MM.REQUEST_TYPE);
            }
            catch (MetadataManagerException mme)
            {
                throw mme;
            }
            finally
            {
                mdFolder.setMetadataManagerServices(this);
            }

            mdFolder.setMetadataManagerServices(this);
            MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, mdFolder, MetadataModifiedEvent.MODIFY);
            m_EventSupport.fireMetadataModifiedEvent( event );
        }
    }
    public void removeMDObject( MDFolder mdFolder, Name name, boolean isFolder ) throws MetadataManagerException
    {
        if( mdFolder == null )
            return;

        // mark this as a client request
        mdFolder.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        // remove from middle-tier
        m_MetadataManagerProxy.removeMDObject( mdFolder, name, isFolder );

        // remove from local cache
        if (MMUtilities.isPersistence(mdFolder) || MMUtilities.isSiebel(mdFolder))
        {
            MDObject[] _objs = getChildrenFromIndex(mdFolder);
            String _name = name.get(name.size()-1);
            for(int i=0; _objs != null && i < _objs.length; i++)
            {
                Vector _drivers = _objs[i].getDriverTypes();
                if(_objs[i].getName() != null && _objs[i].getName().equals(_name)
                   && MMUtilities.isPersistence(_objs[i]) && _drivers != null && _drivers.size() == 1)
                {
                    m_MDIndex.removeMDObject(_objs[i]);
                    mdFolder.removeChild(_objs[i]);
                    break;
                }
            }
        }

        MetadataModifiedEvent event = new MetadataModifiedEvent(this, false, name, MetadataModifiedEvent.REMOVE);
        m_EventSupport.fireMetadataRefreshEvent( event );
    }
    
    public void copy (MDFolder mdFolder, Name objectToBeCopied, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        if (properties == null)
            properties = new PropertyBag();
        properties.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);

        String _newName = properties.getStrPropertyValue(MDU.COPY_NAME);
        if (_newName == null)
            _newName = objectToBeCopied.get(objectToBeCopied.size()-1);
        String _path = MMUtilities.composePath(newParent, _newName);

//        checkNameClash(objectToBeCopied.get(objectToBeCopied.size()-1), _path, _newName);

        mdFolder.setMetadataManagerServices(this);
        newParent.setMetadataManagerServices(this);

        try
        {
            m_MetadataManagerProxy.copy(mdFolder, objectToBeCopied, newParent, properties);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            mdFolder.setMetadataManagerServices(this);
            newParent.setMetadataManagerServices(this);
        }

        newParent.setMetadataManagerServices(this);
/*
        if (_mdObj != null)
        {
            _mdObj.setParent(newParent);
            _mdObj.setMetadataManagerServices(this);
            newParent.setChild(_mdObj, _mdObj.getObjectType());
            if (_path != null)
                _mdObj.setPath(_path);
        }
*/
    }
    
    public void move (MDFolder mdFolder, Name objectToBeMoved, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        String _path = MMUtilities.composePath(newParent, objectToBeMoved.get(objectToBeMoved.size()-1));
        String _objectToBeMoved = objectToBeMoved.get(objectToBeMoved.size()-1);
//        checkNameClash(_objectToBeMoved, _path, _objectToBeMoved);

        if (properties == null)
            properties = new PropertyBag();
        properties.setStrPropertyValue(MM.REQUEST_TYPE, MM.REMOTE);
/*
        long _parentId = mdFolder.getObjectID();
        MDObject _oldParent = m_MDIndex.getMDObject(_parentId);
        if (_oldParent == null)
            _oldParent = mdFolder;
*/            
        try
        {
            m_MetadataManagerProxy.move(mdFolder, objectToBeMoved, newParent, properties);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            mdFolder.setMetadataManagerServices(this);
            newParent.setMetadataManagerServices(this);
        }
/*
        MDObject[] _objs = getChildrenFromIndex(mdFolder);
        for(int i=0; _objs != null && i < _objs.length; i++)
        {
            if(_objs[i].getName() != null && _objs[i].getName().equals(_objectToBeMoved))
            {
                newParent.setChild(_objs[i], _objs[i].getObjectType());
                _objs[i].setParent(newParent);
                if (_oldParent != null)
                    _oldParent.removeChild(_objs[i]);
                if (_path != null)
                    _objs[i].setPath(_path);

                break;
            }
        }
*/
    }

    /**
     * @hidden
     */
    public Vector search (MDFolder mdFolder, Name name, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
        Vector _results = null;

        try
        {
            _results = m_MetadataManagerProxy.search(mdFolder, name, attributes, controls);
        }
        catch (MetadataManagerException mme)
        {
            throw mme;
        }
        finally
        {
            mdFolder.setMetadataManagerServices(this);
        }

        if (_results == null)
            return new Vector(0);

        mdFolder.setMetadataManagerServices(this);
        for(int i=0; _results != null && i < _results.size(); i++)
        {
            MetadataManagerSearchResultImpl _impl = (MetadataManagerSearchResultImpl)_results.elementAt(i);
            _impl.setMetadataManagerServices(this);
            String _str = _impl.getDriverType();
            /*
            ObjectFactory _factory = null;//getObjectFactory(false, _str);
            if(_factory != null)
            {
                String _type = _impl.getObjectType();
                String _className = null;
                if (_type.equals(MM.FOLDER))
                    _className = "oracle.dss.metadataManager.common.MDFolder";
                else
                    _className = _factory.getObjectInstanceClassName(_type);

                if (_className != null)
                    _impl.setClassName(_className);
            }
            */
        }
        return _results;
    }
    
    /**
     * @hidden
     */
    public Attributes getAttributes(MDFolder mdFolder, Name name, String[] attrIds, int flag) throws MetadataManagerException
    {
        if(isProxyOK())
            return m_MetadataManagerProxy.getAttributes(mdFolder, name, attrIds, flag);
        else
            return null;
    }
    
    public void deferredObjectSetUp(MDObject obj)
    {
        if (isProxyOK())
            m_MetadataManagerProxy.deferredObjectSetUp(obj);
    }
    
    /**
     * @hidden
     */
    public Object getObject(String id, String driverType) throws MetadataManagerException
    {
        if(m_MetadataManagerProxy != null)
        {
            Hashtable _env = (Hashtable)m_envProps.clone();
            _env.put(PersistableConstants.PERSISTENCE_ERRORHANDLER, getErrorHandler());
            _env.put(PersistableConstants.PERSISTENCE_LOCALE, getLocale());
            _env.put(MM.METADATA_MANAGER_SERVICES, this);

            Object _obj = m_MetadataManagerProxy.getObject(id, driverType, _env);
            if(_obj instanceof MDFolder)
                return _obj;
            else if(_obj instanceof MDObject)
                return _obj;
            else if(_obj instanceof Connection)
            {
                ((Connection)_obj).setSession(m_session);
                return _obj;
            }
            
            return _obj;//handleStateAgent(_obj, driverType, null, _env);
        }
        return null;
    }
    /*
    private Object handleStateAgent(Object obj, String driverType, Persistable persistable, Hashtable env) throws MetadataManagerException
    {
        if(obj != null && driverType != null)
        {
            MetadataHandler _handler = (MetadataHandler)m_handlers.get(driverType);
            if(_handler != null)
            {
                try
                {
                    return _handler.getObjectInstance(obj, persistable, env);
                }
                catch (Exception e)
                {
                    throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                        MetadataManagerClientBundle.EXC_HANDLER_FAILURE,
                                                        null,
                                                        m_Locale,
                                                        driverType,
                                                        e );
                }
            }
        }
        return obj;
    }
    */
    /**
     * @hidden
     * @return MDObject that represents the OLAP MdmObject 
     */
    public MDObject setOlapObject(MDFolder parent, Object mdmObject) throws MetadataManagerException
    {
        if(m_MetadataManagerProxy != null)
        {
            MDObject _mdObj = m_MetadataManagerProxy.setOlapObject(parent, mdmObject);
            if(_mdObj != null)
            {
                _mdObj.setMetadataManagerServices(this);
                m_MDIndex.setMDObject(_mdObj);
            }
            return _mdObj;
        }
        return null;
    }

    /**
     * @hidden
     */
    public void addToLookupScopeCache(String oid, String path, Object sysAgg)
    {
        if(m_MetadataManagerProxy != null)
            m_MetadataManagerProxy.addToLookupScopeCache(oid, path, sysAgg);
    }

    /**
     * @hidden
     */
    public void clearLookupScopeCache()
    {
        if(m_MetadataManagerProxy != null)
            m_MetadataManagerProxy.clearLookupScopeCache();
    }

    /**
     * @hidden
     */
    public void setMDObjectInCacheByOLAPIRunID(MDObject mdObject, Vector idVec)
    {
        if(m_MDIndex != null)
            m_MDIndex.setMDObjectByOLAPIIDs(mdObject, idVec);
    }
    
    public NamingEnumeration getDatasources() throws MetadataManagerException
    {
        BasicAttributes _attrs = new BasicAttributes(PersistableConstants.Attributes.OBJECT_TYPE, MM.DATASOURCE);
        try
        {
            BISearchControls _controls = new BISearchControls();
            _controls.setSearchScope(_controls.SUBTREE_SCOPE);
            NamingEnumeration _enum = m_MDRoot.search("", _attrs, _controls);
            
            // get MDM connection
            Connection[] _conns = getConnections();
            Connection _mdm = null;
            for(int i=0; _conns != null && i<_conns.length; i++)
            {
                if(_conns[i] != null && MM.MDM.equals(_conns[i].getDriverType()))
                {
                    _mdm = _conns[i];
                    MDFolder _mdmRoot = (MDFolder)m_MDRoot.getObjPropertyValue("MDM_ROOT");
                    if(_mdmRoot != null)
                    {
                        _mdmRoot.setMetadataManagerServices(this);
                        _mdm.setRoot(_mdmRoot);
                    }
                    break;
                }
            }
            
            if(_mdm != null)
            {
                Vector _vec = new Vector();
                while(_enum.hasMoreElements())
                    _vec.addElement(_enum.next());
                MetadataManagerSearchResultImpl _sr = new MetadataManagerSearchResultImpl("MDM" , _mdm, null, MM.MDM, this);
                _vec.addElement(_sr);
                
                return new NamingEnumerationImpl(_vec);
            }
            else
                return _enum;
        }
        catch(NamingException ne)
        {
            throw new MetadataManagerException( MetadataManagerClientBundle.class,
                                                MetadataManagerClientBundle.EXC_SET_CONNECTION_FAILURE,
                                                null,
                                                m_Locale,
                                                MDU.SBA,
                                                ne );
        }
    }

    public Vector listAssociates(MDFolder mdFolder, Name relativeSourceName, String[] attrsToReturn, Attribute identifier) throws MetadataManagerException
    {
        if(m_MetadataManagerProxy != null)
            return m_MetadataManagerProxy.listAssociates(mdFolder, relativeSourceName, attrsToReturn, identifier);
        return null;
    }
    
    public MDObject getMDObjectByUniqueID(String uniqueID) throws MetadataManagerException
    {    
        // check the runtime DS
        /*
        if(uniqueID != null && MM.RDS.equals(MMUtilities._getDriverType(uniqueID)))
        {
            for(Enumeration _enum = m_runtimeDatasources.elements(); _enum.hasMoreElements();)
            {
                RuntimeDatasource _rds = (RuntimeDatasource)_enum.nextElement();
                if(_rds != null)
                {
                    MDObject _mdObj = _rds.getMDObjectByUniqueID(uniqueID);
                    if(_mdObj != null)
                        return _mdObj;
                }
            }
            // couldn't find it so return null.  don't look anywhere else.
            return null;
        }
        */
        MDObject _mdObj = m_MDIndex.getMDObject(uniqueID);
        if(_mdObj == null && m_MetadataManagerProxy != null)
        {
            MDDimension measDim = getMeasureDimension("");
            if (measDim != null && measDim.getUniqueID().equals(uniqueID))
                return measDim;
            
            PropertyBag _bag = new PropertyBag();
            _bag.setStrPropertyValue(MM.UNIQUE_ID, uniqueID);
            _mdObj = m_MetadataManagerProxy.getMDObject(_bag);
        }
        return _mdObj;
    }

    public void setObjectInstanceClassName(String type, String clsName)
    {
        if(m_MetadataManagerProxy != null)
            m_MetadataManagerProxy.setObjectInstanceClassName(type, clsName);
    }
/*
    public void addRuntimeDatasource(RuntimeDatasource ds)
    {
        if(ds != null)
        {
            ds.setMetadataManagerEventSupport(m_EventSupport);
            m_runtimeDatasources.add(ds);
        }
    }

    public void removeRuntimeDatasource(RuntimeDatasource ds)
    {
        if(ds != null)
        {
            ds.removeMetadataManagerEventSupport(m_EventSupport);
            m_runtimeDatasources.remove(ds);
        }
    }
    
    public RuntimeDatasource[] getRuntimeDatasources()
    {
        RuntimeDatasource[] _rds = null;
        if(m_runtimeDatasources != null)
        {
            _rds = new RuntimeDatasource[m_runtimeDatasources.size()];
            m_runtimeDatasources.copyInto(_rds);
        }
        return _rds;
    }
*/
    /**
     * @hidden
     */
    public MDItemFolder[] getJoinableItemFolders(MDFolder folder, MDItemFolder itemFolder, boolean searchSubContext)
    {
        MDItemFolder[] _itemFlds = null;
        if(m_MetadataManagerProxy != null)
            _itemFlds = m_MetadataManagerProxy.getJoinableItemFolders(folder, itemFolder, searchSubContext);
        return _itemFlds;
    }

    public class NamingEnumerationImpl implements NamingEnumeration, java.io.Serializable
    {
      Enumeration m_enum;

      NamingEnumerationImpl(Vector v)
      {
          m_enum = v.elements();
      }

      public boolean hasMoreElements()
      {
          return m_enum.hasMoreElements();
      }

      public boolean hasMore() throws NamingException
      {
          return hasMoreElements();
      }

      public Object nextElement()
      {
          return m_enum.nextElement();
      }

      public Object next() throws NamingException
      {
            return nextElement();
      }

      public void close()
      {
      }
    }
}
