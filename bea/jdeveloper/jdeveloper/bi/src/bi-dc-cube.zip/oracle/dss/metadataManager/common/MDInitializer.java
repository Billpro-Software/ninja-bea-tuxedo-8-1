/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import java.io.Serializable;

/**
 * @hidden
 */

public interface MDInitializer extends Serializable
{
    public void run(MetadataManagerServices metadataManager) throws MDInitializerException;
}