/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/BuilderContext.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.builder;

import java.awt.Component;

import java.util.Locale;

import oracle.bali.ewt.wizard.WizardDialog;

import oracle.dss.datautil.ExceptionListener;
import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.provider.DataProvider;
import oracle.dss.datautil.provider.MetadataProvider;

/**
 * <pre>
 * Defines a <code>BuilderContext</code> which contains common properties and
 * methods used by Builder frameworks. 
 * </pre>
 *
 * @author rbalexan 
 * @since  11.0.0.0.3
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *  gkellam     11/30/05 - Add item calc support to QueryBuilder. 
 *  gkellam     11/15/05 - Extensive calculation infrastructure updates. 
 *  gkellam     11/01/05 - Add Builder to BuilderContext. 
 *  gkellam     10/17/05 - Move some BuilderContext methods down into 
 *                         ComponentContext. 
 *  gkellam     10/11/05 - Work around bug 4616157: Avoid OLAP attribute 
 *                         searching by selecting Relational datasource. 
 *  gkellam     09/07/05 - 
 *  jramanat    09/02/05 - Move BIProvider to ComponentContext 
 *  jramanat    09/01/05 - 
 *  gkellam     08/22/05 - 
 *  rbalexan    08/12/05 - 
 *  rbalexan    07/12/05 - fill in interface methods 
 *  rbalexan    07/08/05 - 
 *  gkellam     06/23/05 - Initial R11 CalcBuilder framework. 
 *  gkellam     06/16/05 - Creation
 */

public class BuilderContext extends ComponentContext {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @status new
   */
  public static String ITEM_SEARCH_PATHS = "ItemsSearchPaths";

  /**
   * @status new
   */
  public static String ITEM_SEARCH_PATH_NAMES = "ItemSearchPathNames";

  /**
   * @status new
   */
  public static String SAVE_PATH = "SavePath";
  
  /**
   * <code>Builder</code> instance.
   * 
   * @status new
   */
  public static String BUILDER = "Builder";

  /**
   * <code>ExceptionListener</code> used to process exceptions.
   * 
   * @status new
   */
  public static String EXCEPTION_LISTENER = "ExceptionListener";

  /**
   * <code>WizardDialog</code> which represents the <code>Builder</code> dialog
   * container.
   * 
   * @status new
   */
  public static String WIZARD_DIALOG = "WizardDialog";

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Empty constructor.
   * 
   * The <code>BuilderContext</code> provides all the properties required
   * by the <code>Builder</code>.
   *
   * @status new
   */
  public BuilderContext() {
    super();
  }

  /**
   * <code>BuilderContext</code> constructor.
   *
   * @param componentParent A <code>Component</code> which represents the
   *        parent of the <code>CalcBuilder</code>.  This is normally a
   *        <code>Dialog</code> or <code>Window</code>, but can be null if there
   *        is no parent.
   * @param queryContext A <code>QueryContext</code> which is used to generate
   *        the underlying <code>BIProvider</code>, <code>DataProvider</code>
   *        and <code>MetadataProvider</code>.
   * @param locale The <code>Locale</code> for the resource values to retrieve.
   * 
   * @throws <code>Exception</code> if <code>BuilderContext</code> cannot be
   *         created.
   * @status new
   */
  public BuilderContext (Component componentParent, 
                    QueryContext queryContext, Locale locale) throws Exception {
    super (componentParent, queryContext, locale);
  }

  /**
   * <code>BuilderContext</code> constructor.
   *
   * @param componentParent A <code>Component</code> which represents the
   *        parent of the <code>CalcBuilder</code>.  This is normally a
   *        <code>Dialog</code> or <code>Window</code>, but can be null if there
   *        is no parent.
   * @param dataProvider A <code>DataProvider</code> which is used retrieve data.
   * @param metadataProvider A <code>MetadataProvider</code> which is used to retrieve
   *        metadata.
   * @param locale The <code>Locale</code> for the resource values to retrieve.
   *        
   * @status new
   */
  public BuilderContext (Component componentParent, DataProvider dataProvider, 
    MetadataProvider metadataProvider, Locale locale) {
    super (componentParent, dataProvider, metadataProvider, locale);
  }
       
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Specifies an array of folders used by the
   * <code>Builder</code> to only show items contained in those folders.
   *
   * @param paths A string array of folder names.
   *
   * @status new
   */
  public void setItemSearchPaths(String[] paths) {
    setProperty (ITEM_SEARCH_PATHS, paths);
  }
  
  /**
   * Retrieves an array of folders used by the
   * <code>Builder</code> to only show items contained in those folders.
   *
   * @return the array of folders.
   *
   * @status new
   */
  public String[] getItemSearchPaths() {
    return (String[])getProperty (ITEM_SEARCH_PATHS);
  }
  
  /**
   * Specifies an array of folder names used by the
   * <code>Builder</code> to rename folders specified in the
   * 'setItemSearchPaths' method.  
   *
   * @param pathNames A string array of folder names.
   *
   * @status new
   */
  public void setItemSearchPathNames (String[] pathNames) {
    setProperty (ITEM_SEARCH_PATH_NAMES, pathNames);
  }

  /**
   * Retrieves an array of folder names used by the
   * <code>Builder</code> to rename folders specified in the
   * 'setItemSearchPaths' method.  
   *
   * @return the array of folder names.
   *
   * @status new
   */    
  public String[] getItemSearchPathNames() {
    return (String[])getProperty (ITEM_SEARCH_PATH_NAMES);
  }
          
  /**
   * Specifies the path used when saving objects in the Builder (i.e.
   * DataFilters, DisplayFilters, Calculations, etc.). The save path is 
   * relative to the root folder (i.e. 'users/scott').
   *
   * @param strSavePath The save path.
   *
   * @status new
   */
  public void setSavePath(String strSavePath) {
    setProperty(SAVE_PATH, strSavePath);
  }
  
  /**
   * Retrieves the path used when saving objects in the Builder (i.e.
   * DataFilters, DisplayFilters, Calculations, etc.). The save path is 
   * relative to the root folder (i.e. 'users/scott').
   *
   * @return A <code>String</code> representing the save path.
   *
   * @status new
   */
  public String getSavePath() {
    return (String)getProperty(SAVE_PATH);
  }

  /**
   * Specifies the <code>Builder</code> instance. 
   *
   * @param builder A <code>Builder</code> instance.
   *
   * @status new
   */
  public void setBuilder (Builder builder) {
    setProperty (BUILDER, builder);
  }

  /**
   * Retrieves the <code>Builder</code> instance. 
   *
   * @return A <code>Builder</code> instance.
   *
   * @status new
   */    
  public Builder getBuilder() {
    return (Builder) getProperty (BUILDER);
  }

  /**
   * Specifies the <code>WizardDialog</code> which represents the 
   * <code>Builder</code> dialog container.
   *
   * @param wizardDialog  A <code>WizardDialog</code> instance.
   *
   * @status new
   */
  public void setWizardDialog (WizardDialog wizardDialog) {
    setProperty (WIZARD_DIALOG, wizardDialog);
  }

  /**
   * Retrieves the <code>WizardDialog</code> which represents the 
   * <code>Builder</code> dialog container.
   *
   * @return A <code>Builder</code> instance.
   *
   * @status new
   */    
  public WizardDialog getWizardDialog() {
    return (WizardDialog) getProperty (WIZARD_DIALOG);
  }

  /**
   * Specifies a <code>ExceptionListener</code> used to process exceptions.
   *
   * @param exceptionListener a <code>ExceptionListener</code> used to process exceptions.
   *
   * @status new
   */
  public void setExceptionListener (ExceptionListener exceptionListener) {
    setProperty (EXCEPTION_LISTENER, exceptionListener);
  }

  /**
   * Retrieves a <code>ExceptionListener</code> used to process exceptions.
   *
   * @return <code>ExceptionListener</code> which represents the current
   *         exception listener.
   *
   * @status new   
   */
  public ExceptionListener getExceptionListener() {
    return (ExceptionListener) getProperty (EXCEPTION_LISTENER);
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
