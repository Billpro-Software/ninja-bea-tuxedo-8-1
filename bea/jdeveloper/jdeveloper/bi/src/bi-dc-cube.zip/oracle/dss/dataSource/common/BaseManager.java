/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * Defines common functionality that is useful
 * in the other Manager interfaces (such as <code>BaseClientManager</code>,
 * and <code>DrillManager</code>) of the <code>Query</code> object.
 *
 * @status Documented
 */ 
public interface BaseManager
{
    /**
     * Adds a listener to the listener list for this <code>Query</code> object.
     *
     * @param l   The <code>QueryListener</code> to be added.
     *
     * @status Documented
     */
    public void addQueryListener(QueryListener l);
    
    /**
     * Removes a listener from the listener list for this
     * <code>Query</code> object.
     *
     * @param l    The <code>QueryListener</code> to be removed.
     *
     * @status Documented
     */
    public void removeQueryListener(QueryListener l);   
    
    /**
     * Clones this Query.
     *
     * @return A newly-created copy of the <code>Query</code>.
     *
     * @throws CloneNotSupportedException If an error occurs
     *
     * @status New
     */
    public Object clone() throws CloneNotSupportedException;
    
    /**
     * Signals this Query to execute pending operations in order.
     *
     * @throws  Exception Any middle tier exception.
     *
     * @status Documented
     */
    public void update() throws Exception;

    /**
     * Specifies whether all operations on the underlying query should be sent
     * to the middle tier for immediate processing. The corresponding
     * <italic>get</italic> method is <code>isAutoUpdate</code>.
     *
     * <p>(Note: Another way to force
     * the immediate execution of pending operations is to invoke the
     * <code>update</code> method.) </p>
     *
     *
     * @param b   <code>true</code> sends all pending operations to the middle
     *            tier for immediate processing,
     *            <code>false</code> adds an operation to the pending queue.
     *
     * @throws  Exception Any of the exceptions that are contained in the
     *          operations that are currently in the pending queue.
     *
     * @status Documented
     */
    public void setAutoUpdate(boolean b) throws Exception;
    
    /**
     * Indicates whether all operations should be sent immediately to the
     * middle tier for execution.
     *
     * @return <code>true</code> if all operations are sent immediately to the
     *         middle tier for execution, <code>false</code> if operations are
     *         to be added to the pending operations queue.
     *
     * @status Documented
     */
    public boolean isAutoUpdate();
    
    /**
     * Indicates whether any operations are pending.
     *
     * @return <code>true</code> if operations are pending;
     *         <code>false</code> if no operations are pending.
     *
     * @status Documented
     */
    public boolean isUpdatePending();

    /**
     * Specifies the suppression (NONE, NA, zero, or both NA and zero) to use
     * when data is fetched.
     *
     * @param edge     A constant that specifies the edge of interest. Valid
     *                 values are in <code>oracle.dss.util.DataDirector</code>.
     * @param suppress A constant that specifies the kind of suppression. Valid
     *                 values are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public void setSuppressionState(int edge, int suppress);

    /**
     * Retrieves the suppression state (NONE, NA, zero, or both NA and zero)
     * that is used when data is fetched.
     *
     * @param edge   A constant that specifies the edge of interest. Valid
     *               values are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @return       A constant that specifies the kind of suppression. Valid
     *               values are in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public int getSuppressionState(int edge);    
    
    /**
     * Restores the <code>Query</code> object to a previous state in this
     * session.
     * Generates a <code>StateChangedEvent</code> marked by the
     * <code>StateChangeEvent.STATE</code> constant.
     *
     * @param state State marker that was retrieved previously from an
     *              <code>UndoAvailableEvent</code>.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see StateChangeEvent#STATE
     *
     * @status Documented
     */
    public void setQueryState(QueryState state) throws QueryException, MetadataManagerException;

    /**
     * Retrieves a state marker (also known as a token or cookie) that
     * represents the current <code>Query</code> object state. Later, in the
     * same session, this state marker can be used as the parameter for
     * <code>setQueryState</code> to restore the state of this
     * <code>Query</code> object.
     *
     * @return The state marker (token or cookie) that represents the current
     *         state of this <code>Query</code> object.
     *
     * @throws CloneException  If the state cannot be duplicated.
     *
     * @status Documented
     */
    public QueryState getQueryState() throws CloneException;
    
    /**
     * Cancels a current operation on the stack.
     *
     * @status Documented
     */
    public void cancel();
    
    /**
     * Specifies whether cursor evaluation will be performed.
     * By default, cursor evaluation is performed.
     *
     * @param evalCursor <code>true</code> indicates that cursors should be
     *                   evaluated;
     *                   <code>false</code> indicates that cursors should not
     *                   be evaluated.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status Documented
     */
    public void setEvaluateCursor(boolean evalCursor) throws QueryException, MetadataManagerException;
    
    /**
     * Indicates whether cursor evaluation will be performed.
     *
     * @return <code>true</code> if cursor evaluation will be performed;
     *         <code>false</code> if cursor evaluation will not be performed.
     * 
     * @status Documented
     */
    public boolean isEvaluateCursor();

    /**
     * Indicates whether hierarchical drilling should be used exclusively.
     *
     * @param hierDrill <code>true</code> uses hierarchical drilling exclusively
     *                  <code>false</code> does not use hierarchical drilling
     *                                     exclusively.
     *                                     
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public void setHierarchicalDrilling(boolean hierDrill);
    
    /**
     * Indicates whether hierarchical drilling is set exclusively.
     *
     * @return <code>true</code> if hierarchical drilling is used exclusively;
     *         <code>false</code> if hierarchical drilling is not set
     *         exclusively.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public boolean isHierarchicalDrilling();

    /**
     * Indicates whether asymmetric drilling should be used.
     *
     * @param asymmetric <code>true</code> allows asymmetric drilling,
     *                   <code>false</code> does not allow asymmetric drilling.
     *                 
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public void setAsymmetricDrilling(boolean asymmetric);

    /**
     * Indicates whether asymmetric drilling is set.
     *
     * @return <code>true</code> if asymmetric drilling is set;
     *         <code>false</code> if asymmetric drilling is not set.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public boolean isAsymmetricDrilling();

    /**
     * Specifies the fetch buffer size.
     *
     * @param size Indicates the number of values to fetch per buffer read
     *             for cursors.  The value <code>-1</code> turns partial 
     *             fetching off and fetches the entire cursor.
     *             
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public void setFetchSize(int size);

    /**
     * Returns the currently-set fetch buffer size.
     *
     * @return The currently set fetch buffer size.  
     *         The value <code>-1</code> indicates that fetch all is set.
     *
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status Documented
     */
    public int getFetchSize();

    /**
     * @hidden
     * Sets whether entire page edges are fetched.  Default is <code>true</code>.
     *
     * @param fullfetch if <code>true</code>, the page edge is fully fetched.  If not, partial fetching applies.
     * 
     * @deprecated As of 4.0.0.0
     */
    public void setFetchPageEdge(boolean fullfetch);

    /**
     * @hidden
     * Returns whether entire page edges are fetched.
     *
     * @return <code>true</code> if entire page edges are fetched.
     *
     * @deprecated As of 4.0.0.0
     * 
     * @status New
     */
    public boolean getFetchPageEdge();

   /**
    * Return the current state in XML of the query.  This does not include
    * persistable components such as selections or calculations.
    *
    * @return String containing the Query's XML, if available.
    * @throws QueryException in case of an error
    * @status New
    */
   public String getXMLString() throws Exception;

   /**
    * Sets the value of the given property on the Query.
    * <code>property</code> should be one of the PROPERTY_
    * constants defined in <code>QueryConstants</code>, and the
    * <code>value</code> should match the description there for
    * the given property.
    *
    * @param property name of the property to set, from <code>QueryConstants</code>
    * @param value value of the property to set
    *
    * @see oracle.dss.dataSource.common.QueryConstants
    * @throws Exception if an error occurs
    * @status New
    */
   public void setProperty(String property, Object value) throws Exception;

   /**
    * Gets the value of the given property from the Query.
    * <code>property</code> should be one of the PROPERTY_
    * constants defined in <code>QueryConstants</code>.  The return
    * value depends on the property requested.
    *
    * @param property name of the property to get, from <code>QueryConstants</code>
    *
    * @return value of the given property, if any
    *
    * @see oracle.dss.dataSource.common.QueryConstants
    * @status New
    */
   public Object getProperty(String property);
   
    /**
     * Set whether or not to filter children when drilling down.
     * 
     * @param all		If <code>true</code>, drill children may be 
     * filtered by the query.  If 
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status New
     */
    public void setDrillWithFilteredChildren(boolean filter);
 
    /**
     * Get whether or not to filter children when drilling down.
     * 
     * @return	If <code>true</code>, drill children may be filtered by
     * the query.  If
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @deprecated As of 4.0.0.0, replaced by {@link #setProperty()}
     * 
     * @status New
     */
    public boolean isDrillWithFilteredChildren();   
}
