/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryRowsetCollection.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $ */

/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/11/09 - XbranchMerge bmoroze_bug-8879459 from main
    bmoroze     11/08/07 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryRowsetCollection.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.client;

import oracle.dss.util.MetadataMap;
import oracle.dss.util.transform.MemberInterface;
import oracle.dss.util.transform.RowProjection;
import oracle.dss.util.transform.RowsetCollection;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.TransformUtils;

/**
 * @hidden
 */
public class QueryRowsetCollection extends RowsetCollection
{
    protected String m_columnType = null;
    protected String[] m_colsForColumnType = null;
    
    public QueryRowsetCollection(RowProjection projection, String columnType)
    {
        super(projection);
        m_cols = ((CloneableRowIterator)m_projection.getRowIterator()).getColumns(columnType);        
        m_columnType = columnType;
    }

    public String[] getColumns()
    {
        if (m_colsForColumnType == null)
            m_colsForColumnType = ((CloneableRowIterator)m_projection.getRowIterator()).getColumns(m_columnType);
        return m_colsForColumnType;
    }    
    
    public void clear() {
        super.clear();
        m_cols = null;
        m_colsForColumnType = null;
    }
    
    public boolean isDataItem(String col) throws TransformException
    {
        MemberInterface[] dataItems = m_projection.getDataItems();
        String columnType = m_columnType == null ? MetadataMap.METADATA_VALUE : m_columnType;
        if (dataItems != null)
        {
            for (int i = 0; i < dataItems.length; i++)
                if (dataItems[i] != null)
                {
                    String name = (String)dataItems[i].getMetadata(TransformUtils.convertMetadataMap(columnType));
                    if (col.equals(name))
                        return true;
                }
        }        
        return false;
    }    
}
