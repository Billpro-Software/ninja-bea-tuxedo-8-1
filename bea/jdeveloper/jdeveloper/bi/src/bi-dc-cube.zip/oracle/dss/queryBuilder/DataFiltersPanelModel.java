/*
 * DataFilterPanelModel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import oracle.dss.datautil.QueryEditor;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.provider.BIProvider;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.SavedDataFilter;
 
public class DataFiltersPanelModel extends DefaultTreeModel {

	/*
	 * Public
	 */
     
    public DataFiltersPanelModel(ComponentContext context) {
        super(new DefaultMutableTreeNode(null, true));
        m_root = (DefaultMutableTreeNode)getRoot();
        m_context = context;
    }
    
    public void refresh() {
        m_root.removeAllChildren();
        BaseDataFilter[] dataFilters = QBUtils.getDataFilters(m_context);
        if (dataFilters != null) {
            for (int i=0; i<dataFilters.length; i++) {
                m_root.add(new DefaultMutableTreeNode(dataFilters[i], false));
            }
        }
        nodeStructureChanged(m_root);
    }

    public void setSelected (BaseDataFilter df, boolean selected) {
      if (selected) {
        if (!m_selectedDataFilters.contains(df)) {
          m_selectedDataFilters.add(df);
        }
      }
      else {
        m_selectedDataFilters.remove(df);
      }      
    }
    
    public boolean isSelected (BaseDataFilter df) {
      return m_selectedDataFilters.contains(df);
    }

    public Vector getSelectedDataFilters() {
      return m_selectedDataFilters;
    }

    public int getFilterCount() {
      return m_root.getChildCount();
    }
    
    /*
     * Private
     */
     
    private ComponentContext m_context = null;
    private DefaultMutableTreeNode m_root = null;
    private Vector m_selectedDataFilters = new Vector();
}