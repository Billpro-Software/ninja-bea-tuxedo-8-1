/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValueDialog.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    11/29/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/ParameterValueDialog.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil.gui.component.parameter;

import java.awt.Dialog;
import java.awt.Frame;

import java.text.MessageFormat;

import oracle.bali.ewt.dialog.JEWTDialog;

import oracle.dss.datautil.gui.component.ComponentContext;

public class ParameterValueDialog extends JEWTDialog {
  private ParameterValuePanel m_panel = null;
  private String m_subtitle = null;

  /**
   * Constructor that takes a parent Dialog.  Note that setModel and initialize
   * must be called on the contained ParameterValuePanel (obtained by calling getParameterValuePanel)
   * before this Dialog is used.
   * 
   * @param parent The parent Dialog
   */
  public ParameterValueDialog(Dialog parent) {
    super(parent, null, JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL);
    m_panel = new ParameterValuePanel();
    setContent(m_panel);
    setResizable(false);
  }

  /**
   * Constructor that takes a parent Frame.  Note that setModel and initialize
   * must be called on the contained ParameterValuePanel (obtained by calling getParameterValuePanel)
   * before this Dialog is used.
   * 
   * @param parent The parent Frame
   */
  public ParameterValueDialog(Frame parent) {
    super(parent, null, JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL);
    m_panel = new ParameterValuePanel();
    setContent(m_panel);
    setResizable(false);
  }
  
  /**
   * Constructor that takes a parent Dialog and ComponentContext.
   * 
   * @param parent The parent Dialog
   * @param context The ComponentContext
   */
  public ParameterValueDialog(Dialog parent, ComponentContext context) {
    super(parent, null, JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL);
    m_panel = new ParameterValuePanel(context);
    setContent(m_panel);
    setResizable(false);
  }


  /**
   * Constructor that takes a parent Frame and ComponentContext.
   * 
   * @param parent The parent Frame
   * @param context The ComponentContext
   */
  public ParameterValueDialog(Frame parent, ComponentContext context) {
    super(parent, null, JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL);
    m_panel = new ParameterValuePanel(context);
    setContent(m_panel);
    setResizable(false);
  }
  
  // javadoc inherited from base class
  public String getTitle() {
    if (getSubtitle() != null) {
      return MessageFormat.format(m_panel.getResourceString("EditParameterValuesSubtitle"), new String[] {getSubtitle()});
    }
    return m_panel.getResourceString("EditParameterValues");
  }

  /**
   * Specifies the subtitle of this dialog
   * 
   * @param subtitle The subtitle
   */
  public void setSubtitle(String subtitle) {
    m_subtitle = subtitle;
  }

  /**
   * Retrieves the subtitle of this dialog
   * 
   * @return The subtitle
   */
  public String getSubtitle() {
    return m_subtitle;
  }
  
  /**
   * Retrieves the ParameterValuePanel contained in this Dialog
   * 
   * @return The ParameterValuePanel
   */
  public ParameterValuePanel getParameterValuePanel() {
    return m_panel;
  }
  
  public void dismissDialog(boolean cancelled) {
    if (!cancelled) {
      m_panel.apply(true);
    }
    super.dismissDialog(cancelled );
  }
}