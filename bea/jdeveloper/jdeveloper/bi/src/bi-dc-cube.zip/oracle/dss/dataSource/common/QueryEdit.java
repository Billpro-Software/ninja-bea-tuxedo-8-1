package oracle.dss.dataSource.common;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.util.Enumeration;
import java.util.Vector;

import oracle.dss.util.Operation;
import oracle.dss.util.Parameter;

import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.PropertyNode;
import oracle.dss.util.xml.NoSuchPropertyException;
import oracle.dss.util.Utility;

/**
 * Edit class for the state of the <code>Query</code> object.
 * This class operates on the undoable edit object that can be retrieved by a
 * listener to the <code>UndoAvailableEvent</code> through the
 * <code>getEdit</code> method of that event.
 *
 * @status Documented
 */
public class QueryEdit extends Object implements java.io.Serializable {
    
    /**
     * Constructs an edit for the state of the <code>Query</code> object for
     * a single operation.
     *
     * @param ds     The <code>Query</code> object that owns this operation.
     * @param op     The operation to store as the undoable op.
     * @param before The <code>Query</code> state before the edit.
     * @param after  The <code>Query</code> state after the edit.
     *
     * @status Documented
     */
    public QueryEdit(Query ds, Operation op, QueryState before, QueryState after) {
        super();
        operation = op;
        query = ds;      
        m_before = before;
        m_after = after;
    }
    
    /**
     * @hidden
     */
    public QueryEdit(Query ds) {
        super();
        query = ds;
    }
    
    /**
     * Retrieves the name of the edit operation.
     *
     * @return The name of the edit operation or <code>null</code>, if there
     *         is no name available.
     *
     * @status Documented
     */
    public String getPresentationName() {
        if (operation != null)
            return operation.getName();
        
        return "";
    }

    /**
     * Restores the <code>Query</code> object state that existed before
     * the edit operation was performed.
     *
     * @status Documented
     */
    public void undo() {
        try {
            // Call DS with state
            query.setQueryState(m_before);
        }
        catch (Exception e) {
            throw new UndoException(query.getResourceString("Could not undo"), e);            
        }
    }

    /**
     * Restores the <code>Query</code> object state that existed after
     * the edit operation was performed.
     *
     * @status Documented
     */
    public void redo() {
        // Call DS with state
        try {
            query.setQueryState(m_after);
        }
        catch (Exception e) {
            throw new RedoException(query.getResourceString("Could not redo"), e);
        }
    }
    
    /**
     * Retrieves the stored edit operation.
     *
     * @return The stored edit operation.
     *
     * @status Documented
     */
    public Operation getOperation() {
        return operation;
    }

    /**
     * @hidden
     * 
     * Return the "after" command state
     *
     * @return after state
     */
    public QueryState getAfterState() {
        return m_after;
    }

    /**
     * @hidden
     * 
     * Return the "after" command state
     *
     * @return after state
     */
    public QueryState getBeforeState() {
        return m_before;
    }

    /**
     * @hidden
     */
    public Object getXML(XMLContext retCons) throws BIPersistenceException
    {
        ObjectNode root = new ObjectNode(XMLName);
        
        root.addProperty((ObjectNode)m_before.getXML("BeforeState", retCons));
        root.addProperty((ObjectNode)m_after.getXML("AfterState", retCons));
        root.addProperty(operationToXML(query, operation));
        return root;
    }
          
    /**
    * @hidden
    */
    public void setXML(XMLContext context, Object node) throws BIPersistenceException
    {
        ObjectNode root = (ObjectNode)node;
        m_before = new QueryState(query, null);
        m_before.setXML(context, root.getPropertyValueAsObjectNode("BeforeState"));
        m_after = new QueryState(query, null);
        m_after.setXML(context, root.getPropertyValueAsObjectNode("AfterState"));
        operation = new Operation(null, null, false);
        XMLToOperation(query, root.getPropertyValueAsObjectNode("Operation"), operation);
    }

     /**
     * @hidden
     */
    public String getTagName()
    {
        return XMLName;
    }    
    

    /**
     * Specifies the <code>Query</code> object that owns this edit operation.
     *
     * @status Documented
     */
    void setQuery(Query ds) {
        query = ds;
    }
    
    /**
     * @hidden
     */
    protected static void XMLToOperation(Query ds, ObjectNode root, Operation op) throws BIPersistenceException
    {
        try
        {
            op.setName(root.getPropertyValueAsString("Name"));
            Vector p = new Vector();
            Enumeration params = root.getContainer("Parameters").getContainedObject();
            while (params.hasMoreElements())
            {
                p.addElement(XMLToParameter(ds, (ObjectNode)params.nextElement()));
            }
            op.setParameters((Parameter[])Utility.copyVectorToArray(p));
            op.setGeneratesCursor(root.getPropertyValueAsBoolean("Cursor"));
        }
        catch (NoSuchPropertyException e)
        {
            throw new oracle.dss.dataSource.common.NoSuchPropertyException(ds.getResourceString("Could not find property"), e.getMessage(), e);
        }
    }
        
    /**
     * @hidden
     * Turn operation object into XML object node
     *
     */
    protected static ObjectNode operationToXML(Query ds, Operation op) throws BIPersistenceException
    {
        ObjectNode root = new ObjectNode("Operation");
        root.addProperty("Name", op.getName());
        Parameter[] parms = op.getParameters();
        ContainerNode param = new ContainerNode("Parameters");
        if (parms != null) {
            for (int i = 0; i < parms.length; i++) {
                param.addContainedObject(parameterToXML(ds, parms[i]));
            }
        }
        root.addContainer(param);
        root.addProperty("Cursor", op.generatesCursor());
        return root;
    }
    
    /**
     * @hidden
     */
    protected static ObjectNode parameterToXML(Query ds, Parameter parm) throws BIPersistenceException
    {
        ObjectNode root = new ObjectNode("Parameter");
        byte[] val = null;
        try
        {
            ByteArrayOutputStream byteStream = new  ByteArrayOutputStream();
            ObjectOutputStream objStream = new ObjectOutputStream(byteStream);
            objStream.writeObject(parm.getValue());
            objStream.flush();
            objStream.close();
            val = byteStream.toByteArray();
            StringBuffer str = new StringBuffer();
            String strval = null;
            int value;
            for (int i = 0; i < val.length; i++) {
                //str.append(new Byte(val[i]).toString());
                value = new Byte(val[i]).intValue();
                strval = Integer.toHexString(value < 0 ? value + 256 : value);
                if (strval.length() < 2) {
                    str.append("0");
                }
                str.append(strval);
            }
            root.addProperty("Value", str.toString());
        }
        catch (Exception e)
        {
            throw new BIPersistenceException(e.getMessage(), e);
        }
        root.addProperty("Type", parm.getType().getName());
        return root;
    }

    /**
     * @hidden
     */
    protected static Parameter XMLToParameter(Query ds, ObjectNode root) throws BIPersistenceException
    {
        Parameter retVal = new Parameter();
        String val = null;
        try {
            val = root.getPropertyValueAsString("Value");
        }
        catch (NoSuchPropertyException nspe) {
            throw new oracle.dss.dataSource.common.NoSuchPropertyException(ds.getResourceString("Could not find property"), nspe.getMessage(), nspe);
        }
        try
        {
            // Parse
            //StringTokenizer tokenizer = new StringTokenizer(val, ",");
            int bytes = val.length() / 2;
            byte[] bytearray = new byte[bytes];
            for (int i = 0; i < val.length(); i+=2) {
                bytearray[i/2] = Integer.valueOf(val.substring(i, i+2), 16).byteValue();
            }
            ByteArrayInputStream bis = new ByteArrayInputStream(bytearray);
            ObjectInputStream ois = new ObjectInputStream(bis);
            Object obj = ois.readObject();
            ois.close();
            bis.close();
            retVal.setValue(obj);
            retVal.setType(Utility.loadClass(root.getPropertyValueAsString("Type")));
        }
        catch (Exception e)
        {
            throw new BIPersistenceException(e.getMessage(), e);
        }
        return retVal;
    }
    
    /**
     * @hidden
     */
    protected static final String XMLName = "QueryEdit";
    
    // Stored states
    /**
     * @hidden
     */
    protected QueryState m_before = null;
    /**
     * @hidden
     */
    protected QueryState m_after = null;

    // Command storage
    /**
     * @hidden
     */
    protected Operation operation   = null;
    
    // Data source owner
    /**
     * @hidden
     */
    protected transient Query query   = null;        
}
