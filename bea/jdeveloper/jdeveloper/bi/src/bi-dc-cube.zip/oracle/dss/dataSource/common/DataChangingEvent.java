/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners that an operation is about to take place that will
 * change their data cursors. This event is not consumable.
 *
 * @status Documented
 */
public class DataChangingEvent extends DataChangeEvent
{
    /**
     * Constructs the event.
     *
     * @param s            The source of the event, that is, the object that
     *                     fired the event.
     * @param dataChanging <code>true</code> if data will be changing,
     *                     <code>false</code> if not.
     * @param  changeType   A constant that indicates the type of operation that
     *                    changed the data. Valid constants are listed in the
     *                    See Also section.
     *
     * @see oracle.dss.util.DataChangedEvent#DRILL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PAGE_CHANGE
     * @see oracle.dss.util.DataChangedEvent#PIVOT_CHANGE
     * @see oracle.dss.util.DataChangedEvent#SEL_CHANGE
     * @see oracle.dss.util.DataChangedEvent#UNKNOWN_CHANGE
     *
     * @status documented
     */
    public DataChangingEvent(Object s, boolean dataChanging, int changeType) {
        super(s, dataChanging, changeType);
    }
    
    /**
     * @hidden
     * Merge another event into this one.
     *
     * @param event change event to merge
     */
    public void merge(MergeEvent event) {
        super.merge(event);
    }    
}
