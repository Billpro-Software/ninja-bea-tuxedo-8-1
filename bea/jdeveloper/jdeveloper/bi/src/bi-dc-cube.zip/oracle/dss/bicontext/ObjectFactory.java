/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Hashtable;
import oracle.dss.util.persistence.Persistable;

/**
 * Methods that are required for instantiating <code>Persistable</code> objects
 * from XML representations in the BI Beans Catalog.
 *
 * @status documented
 */
public abstract interface ObjectFactory
{
   /**
    * @hidden
    * Retrieves an instance of a <code>Persistable</code> object.
    * This method instantiates the <code>Persistable</code> object and sets
    * the XML from the specified <code>StateObject</code> on the newly
    * instantiated <code>Persistable</code> object.
    *
    * @param object  The <code>StateObject</code> that contain information
    *                about the object to construct.
    * @param appEnv The environment settings to set on the object.
    *
    * @return       An instance of the <code>Persistable</code> object of the
    *               type that is specified in <code>object</code>.
    *
    * @throws    Exception if an error occured during the creation of the object.
    *
    */
    public Persistable getObjectInstance(StateObject object, Hashtable appEnv) throws Exception;

   /**
    * Retrieves the class name of an object that would be created with the
    * specified object type.
    *
    * @param objType The type of object whose class name you want.
    *                Pass one of the
    *                values of the <code>OBJECT_TYPE</code> attribute,
    *                as defined in <code>PersistableConstants</code> class.
    *
    * @return The name of the class that is used to instantiate objects of
    *         <code>objType</code>.
    *
    * @see oracle.dss.util.persistence.PersistableConstants
    * @see oracle.dss.util.persistence.PersistableConstants.Attributes#OBJECT_TYPE
    *
    * @status documented
    */
    public String getObjectInstanceClassName(String objType);

   /**
    * Specifies the class to use to instantiate objects of a specified type.
    * Call this method to specify, for example, whether to instantiate
    * a crosstab as a <code>Crosstab</code> or as a <code>ThinCrosstab</code>.
    * Call this method once for each object type that your application will
    * load from the BI Beans Catalog.
    *
    * @param objType  The type of object for which the class will be used.
    *                Pass one of the
    *                values of the <code>OBJECT_TYPE</code> attribute,
    *                as defined in <code>PersistableConstants</code> class.
    *
    * @see oracle.dss.util.persistence.PersistableConstants
    * @see oracle.dss.util.persistence.PersistableConstants.Attributes#OBJECT_TYPE
    *
    * @status documented
    */
    public void setObjectInstanceClassName(String objType, String instanceClassName);

   /**
    * @hidden
    * Retrieves the file name of the DTD for the specified object type.
    * The DTD is a BC4J Document Type Definition.
    *
    * @param objType The object type whose DTD you want. For BI Beans
    *                <code>Persistable</code> objects, pass a constant from
    *                the <code>PersistableConstants</code> interface.
    *
    * @return The file name of the DTD for the object type.
    *
    * @see oracle.dss.util.persistence.PersistableConstants
    * @see oracle.dss.util.persistence.PersistableConstants.Attributes#OBJECT_TYPE
    *
    */
    public String getObjectDefName(String objType);

   /**
    * @hidden
    * Specifies the file name of the DTD for an object type.
    * The DTD must be a BC4J Document Type Definition.
    *
    * @param objType The object type whose DTD you are specifying.
    * @param defName The name of the DTD file.
    *
    */
    public void setObjectDefName(String objType, String defName);

    /**
     * Sends to the console a list of registered object types and their
     * classnames.
     *
     * @status documented
     */
    public void dump();
}
