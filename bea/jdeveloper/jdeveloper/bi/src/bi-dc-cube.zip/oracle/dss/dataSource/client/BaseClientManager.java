/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.client;

import java.beans.PropertyChangeListener;
import oracle.dss.dataSource.common.BaseManager;

/**
 * Defines the client-side bean base manager that has some
 * client-specific functionality.
 *
 * @status Documented
 */
public interface BaseClientManager extends BaseManager
{
    /**
     * Adds a property change listener
     *
     * @param l   Listener to be added.
     *
     * @status Documented
     */
    public void addPropertyChangeListener(PropertyChangeListener l);
    
    /**
     * Removes a property change listener
     *
     * @param l   Listener to be removed
     *
     * @status Documented
     */
    public void removePropertyChangeListener(PropertyChangeListener l);
}
