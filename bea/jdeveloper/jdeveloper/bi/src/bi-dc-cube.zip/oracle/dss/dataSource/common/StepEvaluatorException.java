/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown when the Query fails when trying to instantiate a StepEvaluator
 * @status New
 */
public class StepEvaluatorException extends QueryException
{
    /**
     * @hidden
     * @serial Name of class for step evaluator
     */
    protected String m_className = null;
    
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param c  Class name of evaluator for which invocation was attempted
     * @param e  Previous exception to carry (may be null).
     *
     * @status New
     */
    public StepEvaluatorException(String s, String c, Throwable e)
    {
        super(s, e);
        m_className = c;
    }
    
    /**
     * Return step evaluator name
     *
     * @return step evaluator name
     * @status New
     */
    public String getStepEvaluatorClassName()
    {
        return m_className;
    }
    
}