/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.client;

import java.util.List;
import java.util.ArrayList;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import oracle.dss.dataSource.common.CommonDataAccess.ReleaseHelper;
import oracle.dss.dataSource.common.CommonDataAccess;
import oracle.dss.dataSource.common.DataAvailableEvent;
import oracle.dss.dataSource.common.DataChangedEvent;
import oracle.dss.dataSource.common.InvalidMetadataException;
import oracle.dss.dataSource.common.QueryAdapter;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.dataSource.common.QueryState;
import oracle.dss.dataSource.common.QueryUtil2;
import oracle.dss.datautil.DataFilterChangedEvent;
import oracle.dss.datautil.QueryAccessListener;
import oracle.dss.datautil.QueryEditor;
import oracle.dss.datautil.QueryEditorException;
import oracle.dss.datautil.QueryEditorListener;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;

import oracle.dss.dataSource.common.Query;

import oracle.dss.dataSource.common.QueryUtil;
import oracle.dss.datautil.DimensionsChangedEvent;
import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.DataAccessChangedEvent;

import oracle.dss.selection.dataFilter.BaseDataFilter;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.PollingRequiredEvent;
import oracle.dss.util.WaitDataAvailableEvent;
import oracle.dss.selection.OlapQDR;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.Utility;

/**
 * @hidden
 * Base implementation used to support old QueryAccess and new QueryEditor
 * @status New
 */
public abstract class CommonQueryEditor extends Object implements DataDirectorListener
{
    // Currently executing operation info, in case of asynchronous
    protected CurrentOperation m_currOp = null;
    
    // Standard all list metadata map for QA
    protected MetadataMap m_metaTypes = new MetadataMap(new String[] {
        MetadataMap.METADATA_VALUE,
        MetadataMap.METADATA_DISPLAYNAME,
        MetadataMap.METADATA_LONGLABEL,
        MetadataMap.METADATA_SHORTLABEL,
        MetadataMap.METADATA_DRILLSTATE,
        MetadataMap.METADATA_INDENT,
        MetadataMap.METADATA_POSITION,
        MetadataMap.METADATA_PARENT});

    // List of active dimensions
    protected Vector m_dimList = null;              
    
    /**
     * Data Source reference
     */
    protected transient Query m_query   = null;

    /**
     * Query's original data access, if any
     */
    protected transient DataAccess m_originalDA = null;
    
    /**
     * Listener
     */
    protected transient QAListener m_listener = null;
    
    /**
     * List of one off queries to close
     */
    protected transient Hashtable m_queryList = new Hashtable();

    /**
     * List of dimensions for which a selection has been explicitly set
     */
    protected InstanceList m_setSelList = new InstanceList();

    // reference to a cache of available Selections and cursors
    protected InstanceList m_selcursors = new InstanceList();

    /**
     * Cached QDRs
     */
    protected Hashtable m_QDRs = new Hashtable();

    // List of listeners
    protected transient Vector m_listeners = new Vector();

    // Value cache
    // blm - Selection code moved to dvt-olap
/*    protected CursorValueCache m_valueCache = null;*/

    
    /**
     * Constructor.
     */
    public CommonQueryEditor(Query ds) {
        m_query = ds;

        // Listen to the query to pick up a DA if possible
        m_listener = new QAListener();
        m_query.addQueryListener(m_listener);
        // blm - Selection code moved to dvt-olap
/*        m_valueCache = new CursorValueCache();*/
    }

    /** 
     * Clean up the QueryAccess implementation.  To be called by users
     * when they no longer need the QueryAccess object
     * Note this method may throw a QueryRuntimeException.
     *
     * @status New
     */
    public void release() {
	    // Clear all hashtables.
	    // blm - Selection code moved to dvt-olap
/*        m_valueCache.clear();
        m_valueCache = null;*/
        
	    // reference to a cache of available Query cursors
        m_query.removeQueryListener(m_listener);

	    List queryList = new ArrayList();
        // blm - Selection code moved to dvt-olap
/*	    try {
	        Enumeration curs = m_selcursors.getElements();
	        while (curs.hasMoreElements()) {
        	    queryList.add(((SelCursor)curs.nextElement()).getQuery());
	        }
	    }
	    catch (Exception e) {
            throw new QueryRuntimeException(e.getMessage(), e);
	    }*/
	    Enumeration list = m_queryList.elements();
	    while (list.hasMoreElements())
	    {
	        queryList.add(list.nextElement());
	    }
	    
        m_query.getQueryManager().closeQueries(queryList);
	    m_queryList.clear();
        m_selcursors.clear();
	   	m_QDRs.clear();
        m_setSelList.clear();
        if (m_originalDA != null)
        {
            m_originalDA.release();
            m_originalDA = null;
        }
    }

   	/**
   	 * Set the metadata map to use for all cursor evaluation.
   	 *
   	 * @param map MetadataMap to use
   	 * @status New
   	 */
   	public void setMetadataMap(MetadataMap map) {
   	    m_metaTypes = map;
   	}
    
    /**
     *  Drill to a relative level at the specified position.
     *
     *  @param dimension    dimension to drill
     *  @param value        dimension value to drill
     *  @param delta        relative number of levels to traverse within the
     *                      hierarchy (positive numbers drill down, negative 
     *                      drill up). 
     *  @param optimize     flag allowing optimizations that don't preserve the steps
     *                      in a selection
     *  @return A <code>boolean</code> value that is <code>true</code> when the
     *          drill succeeds and <code>false</code> upon failure.
     *  @status New
     */
    public boolean drill(String item, int instance, String target, int delta, boolean optimize) throws QueryEditorException
    {
        // blm - Selection code moved to dvt-olap
/*        // Make sure that drilling is actually allowed
        if (delta != 0) 
            {
            try
                {                
                // Find the query associated with the specified dimension
                Query query = _getQuery(item);
                Selection sel = query.findSelection(item);
                if (sel == null)
                    sel = getSelection(item, instance);
                    
                SelCursor sc = _getCursor(item, instance);
                sc.m_bwasDrilled = true;
                DataAccess da = getValueCache().getCursorValues(sel);
                if (da == null)
                {
                    da = getDataAccess(item, instance);
                    // Put into cache
                    getValueCache().putCursorValues(sel, da, false);
                }
                else
                {
                        //System.out.println("HIT!!!");
                }

                int[] hPos = new int[1];
                int index = da.findMember(0, hPos, 0, target, MetadataMap.METADATA_VALUE, DataAccess.FIND_EXACT);
		        String parent = _makeString(da.getMemberMetadata(0, 0, index, MetadataMap.METADATA_PARENT));
		        String queryParent = _makeString(da.getMemberMetadata(0, 0, index, MetadataMap.METADATA_QUERYPARENT));
                // Get level number for possible performance hint
                Integer obj = (Integer)da.getMemberMetadata(0, 0, index, MetadataMap.METADATA_INDENT);
                int levelDepth = -1;
                if (obj != null)
                {
                    levelDepth = obj.intValue();
                }
                setCurrentOperation(query, sc);
                query.drill(item, target, sel.getHierarchy(), delta, parent, queryParent, levelDepth, null);
                //sel = m_query.drillSelection(sel, value, sel.getHierarchy(), delta);
//                    setSelection(sel);
                }
            catch (Exception e)
                {
                return false;
                }
        }*/
        
        return true;
    }

    protected void clearCurrentOperation()
    {
        m_currOp = null;
    }
    
    protected void setCurrentOperation(Query query, ReturnValueProvider rvp)
    {
        // Mark the query as currently busy if we're asynch, and reject this if we're already busy
        if (isAsynchronous())
        {
            if (m_currOp == null)
            {
                // OK, we can do this
                m_currOp = new CurrentOperation(query, rvp);
            }
            else
            {
                // Already busy
                throw new QueryRuntimeException("Asynchronous QueryEditor already busy", null);
            }
        }
    }
    
    /**
     * Returns the data access for a given selection.
     * 
     * @return DataAccess cursor object
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection)
    {
        return getDataAccess(selection, m_metaTypes);
    }*/

   /**
     * Retrieves the <code>DataAccess</code> object for a specified selection.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param map the metadata desired in the resulting DataAccess
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @status New
     */
    // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection, MetadataMap map)
    {
        try
        {
            // Check the cache
            DataAccess da = getValueCache().getCursorValues(selection);
            // Must maintain a differentiation between regular data access & closeable, otherwise
            // caller could close a standard DA from the cache and screw things up using this API
            if (da != null && da instanceof CommonDataAccess && ((CommonDataAccess)da).getReleaseHelper() instanceof CloseableReleaseHelper)
                return da;
                
            QueryUtil2.DAQuery daq = _getDataForSelection(selection, map);
            setCurrentOperation(daq.getQuery(), new ReturnValueProviderImpl(daq, selection));
            if (!isAsynchronous())
                return createCloseableDataAccess(daq, selection);
            return null;
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
*/
    protected DataAccess createCloseableDataAccess(QueryUtil2.DAQuery daq /*, Selection selection*/) throws Exception
    {
        CloseableReleaseHelper cda = new CloseableReleaseHelper();
        m_queryList.put(cda, daq.getQuery());
        if (daq.getDataAccess() instanceof CommonDataAccess)
            ((CommonDataAccess)daq.getDataAccess()).setReleaseHelper(cda);
        // blm - Selection code moved to dvt-olap
/*        if (selection != null)
        {
            cda.setInCache(true);
            getValueCache().putCursorValues(selection, daq.getDataAccess(), true);
        }*/
        return daq.getDataAccess();        
    }
        // blm - Selection code moved to dvt-olap
/*
    private QueryUtil2.DAQuery _getDataForSelection(Selection selection, MetadataMap map) throws Exception
    {
        // Performance dump
        dumpQueryInfo("One-off query in QueryAccess._getDataForSelection()",
                      new Throwable(), m_query, selection);
        QueryUtil2.DAQuery daq = QueryUtil2._getDataForSelection(createQuery(), selection, map, this);
        setCurrentOperation(daq.getQuery(), new ReturnValueProviderImpl(daq, selection));
        return daq;
    }

  */  
    /**
     * Returns the data access for a given dimension
     * Note this method may throw a QueryRuntimeException.
     * 
     * @param dimension dimension for which to return the cursor
     * @return DataAccess cursor object
     * @status New
     */
    public DataAccess getDataAccess(String item, int instance)
    {
        // blm - Selection code moved to dvt-olap
/*        try {
            SelCursor sc = _getCursor(item, instance);
            if (sc != null) {
                    return sc.getDataAccess(true);
                }
            }
        catch (Exception e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }*/
        return null;
    }

    /**
     * Returns the Selection for dimension
     * Note this method may throw a QueryRuntimeException
     * 
     * @param dimension dimension for which to return the Selection
     * @return Selection object if found.  <code>null</code> if not
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getSelection(String item, int instance) {
        try
        {
            if (item == null)
                return null;
                
            SelCursor sc = _getCursor(item, instance);
            if (sc != null)
            {
                if (sc.getSelection() != null)
                    return (Selection)sc.getSelection().clone();
                    //return sc.getSelection();
            }
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        return null;
    }

    private SelCursor _setSelection(Selection sel, int instance) throws Exception
    {
            // Delete the old
            String dimname = sel.getDimension();
            SelCursor sc = (SelCursor)m_selcursors.get(dimname, instance);
            Selection tempSel = null;
            if (sc != null)
            {
                if (sel.equals(sc.getSelection()) && !sc.m_bwasDrilled)
                {
                    // Same object: no need to change a thing
                    return null;
                }

                tempSel = (Selection)sel.clone();
                //Selection tempSel = sel;
                tempSel.removeAllPropertyChangeListeners();
                
                //oldsc.getSelection().removePropertyChangeListener(this);
                // Must free the cursor
                //DataAccess da = oldsc.getDataAccess(false);
                //if (da != null) {
                    //da.release();
                //}
            }
            else
            {
                // Add the new
                //tempSel.addPropertyChangeListener(this);
                tempSel = (Selection)sel.clone();
                sc = new SelCursor(tempSel);
                //Selection tempSel = sel;
                tempSel.removeAllPropertyChangeListeners();
                m_selcursors.put(dimname, sc, instance);
            }

            sc.setSelection(tempSel);
            return sc;
    }
*/
    /**
     * Update the chosen selection in the selection collection.
     * Note this method may throw a QueryRuntimeException
     * 
     * @param sel Selection to update
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public void setSelection(Selection sel, int instance)
    {
        SelCursor sc = null;
        try
        {
            sc = _setSelection(sel, instance);
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (sc != null)
        {
            String dimName = sel.getDimension();
            m_setSelList.add(dimName, instance);
        }
    }
*/
    /**
     * Determine if a given dimension has a Selection set for it
     *
     * @param dimension dimension to check
     * @return <code>true</code> if dimension has a Selection set for it, 
     *         <code>false</code> if not
     * @status New
     */
    public boolean isSelectionSet(String item, int instance) {
        // Check for an already-available selection
        if (item == null)
        {
            return false;
        }
        return m_setSelList.find(item, instance);
    }

    /**
     * Determine if a given instance has data filters set for it
     *
     * @param instance instance to check
     * @return <code>true</code> if data filters have been set,
     *         <code>false</code> if not
     * @status New
     */
    public boolean isDataFilterSet(int instance)
    {
        return m_selcursors.isDataFilterSet(instance);
    }

    /**
     * Returns the current dimensionality based on the implementers query
     * or the set of measures chosen in the Selection table.
     * Note this method may throw QueryRuntimeException.
     *
     * @param type Enumerated label type to use in return list (see
     *        LayerMetadataMap types)
     * @return list of dimension name strings
     * @status New
     */
    public Vector getItems(String type, int instance) {
        // blm - Selection code moved to dvt-olap
/*        try
        {
            _initializeDimensionality(instance);
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }*/
        return buildDimList(m_dimList, type);
    }

    /**
     * Update the current dimension list based on a given set of measures
     * Note this method may throw a QueryRuntimeException.
     *
     * @param measures list of measures
     * @status New
     */
    public void updateDimensions(String[] measures) {
        try
        {
            updateDimListFromDatabase(measures);
            // blm - Selection code moved to dvt-olap
/*            pruneSelections();*/
        }
        catch (Exception mme)
        {
            throw new QueryRuntimeException(mme.getMessage(), mme);
        }


        // Update the cube in the layout Query
//        updateLayoutQuery(measures);
        
        // Notify listeners
        fireDimensionsChanged(new DimensionsChangedEvent(this,
            buildDimList(m_dimList, LayerMetadataMap.LAYER_METADATA_NAME)));
    }

    /**
     * Return the current name of the measure dimension
     * Note this method may throw a QueryRuntimeException
     *
     * @param type Enumerated label type to use in return name (see
     *        LayerMetadataMap types)
     * @return Name of the measure dimension
     * @status New
     */
    public String getMeasureDimension(String type) {
        try {
            return getDimName(_getMeasureDimension(), type);
        }
        catch (InvalidMetadataException de) {
            throw new QueryRuntimeException(de.getMessage(), de);
        }
    }


   /**
    * Returns the properly initialized QDR for the given Measure ID and dimension
    * Note this method may throw a QueryRuntimeException.
    *
    * @param measure measure to use in initializing QDR
    * @param dimension dimension representing edge on which other dimensions may vary
    *        within QDR
    * @param type Enumerated label type to use in QDR labels(see
    *        LayerMetadataMap types)
    * @return QDR object initialized with the right values for the given measure
    */
   	public OlapQDR getQDR(String measure, String dimension, String type, int instance) {
       	// gek 02/15/00 
        // Vector dimList = getDimensionList (new String[] {measureID});
        MDMeasure dbMeasure = null;
        try
        {
            dbMeasure = (MDMeasure)m_query.getMDObject(MM.UNIQUE_ID, measure, 
            MM.MEASURE);
        }
        catch (MetadataManagerException mme)
        {
            throw new QueryRuntimeException(mme.getMessage(), mme);
        }


        try
        {
            Vector dimList = getDimensionList (new MDMeasure[] {dbMeasure});
            // blm - Selection code moved to dvt-olap
/*            return _getQDR (dimList, type == LayerMetadataMap.LAYER_METADATA_NAME ? measure : dbMeasure.toString(), type, instance);*/
            return null;
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        }

    /**
     * Is the given ID a dimension (or hierarchy?)
     */    
    protected boolean isDimension(String ID) throws MetadataManagerException
    {
        MDObject obj = m_query.getMDObject(MM.UNIQUE_ID, ID, MM.OBJECT);
        if (obj != null)
            return obj instanceof MDDimension || obj instanceof MDHierarchy;
        return false;
    }
    
    /**
     * Get the default hierarchy for the given dimension
     */
     // blm - Selection code moved to dvt-olap
/*    
    private String _getDefaultHierForDim(String dimension) throws MetadataManagerException
    {
		MDDimension dim = (MDDimension)m_query.getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);

		String strHier = null;
		if (dim != null)
		{
		    MDHierarchy hier = dim.getDefaultHierarchy();
		    if (hier != null)
		    {
		        strHier = hier.getUniqueID();
		    }
		}
		return strHier;
	}

    private String _getLevelID(int edge, int layer, DataAccess da, String hierarchy, int index) throws SliceOutOfRangeException, MetadataManagerException, LayerOutOfRangeException, EdgeOutOfRangeException
    {
        // Find the level, if possible
        Integer ld = (Integer)da.getMemberMetadata(edge, layer, index, MetadataMap.METADATA_INDENT);
        String levelID = null;
        if (ld != null && m_query.getMetadataManager() != null && hierarchy != null)
        {
            int levelDepth = ld.intValue();
            MDHierarchy hierObj = (MDHierarchy)m_query.getMetadataManager().getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
            if (hierObj != null)
            {
                MDLevel[] levels = hierObj.getLevels();
                if (levels != null && levels.length > 0 && levelDepth < levels.length)
                {
                    levelID = levels[levelDepth].getUniqueID();
                }
            }
        }
        return levelID;
    }
  */  
	/**
  * Initializes a QDR value for a given dimension
  */
	 // blm - Selection code moved to dvt-olap
/*	protected DimensionMember initQDRValue(String dimension, String hier, int instance) throws Exception
	{
		  DimensionMember dimValue;

  	  dimValue = getQDRValue(dimension, hier);
  	  String dimID = null, dimLabel = null;
      String level = null;
      String levelName = null;
  	  if (dimValue==null)
		  {
		    //Get the first value from initial
		    //Selection in DS

            DataAccess da = getStraightDataAccess(dimension, hier, instance);
            Selection sel = getSelection(dimension, instance);
            if (da == null)
            {
                da = getValueCache().getCursorValues(sel);
                if (da == null)
                {
                    if (hier != null)
                    {
                        // Must verify hier match 
                        if (sel != null && hier.equals(sel.getHierarchy()))
                        {
                            da = getDataAccess(dimension, instance);
                            getValueCache().putCursorValues(sel, da, false);
                        }
                    }
                    else                    
                    {
                        da = getDataAccess(dimension, instance);
                        getValueCache().putCursorValues(sel, da, false);
                    }
                }
            }
            DimInfo di = findEdgeandLayer(da, dimension);
            int count = 0;
            if (da != null && di != null)
            {
                if (hier == null)
                {
                    hier = sel.getHierarchy();
                }
                    int edge = di.getEdge();
                    int layer = di.getDepth();
		            count = da.getEdgeExtent(edge);
		            if (count > 0) {
		                dimID = _makeString(da.getMemberMetadata(edge, layer, 0, MetadataMap.METADATA_VALUE));
		                dimLabel = _makeString(da.getMemberMetadata(edge, layer, 0, MetadataMap.METADATA_LONGLABEL));
                        level = _getLevelID(edge, layer, da, hier, 0);
                        levelName = _makeString(da.getMemberMetadata(edge, layer, 0, MetadataMap.METADATA_LEVEL_NAME));
		            }
            }
            Selection selToCache = null;
    		    if (count == 0)
            {
		            // Try all
                if (hier == null)
                {
                    hier = _getDefaultHierForDim(dimension);
                }
                QueryUtil2.DAQuery daq = null;
                if (hier != null)
                {
                    // Get the first level
                    MDHierarchy hierObj = (MDHierarchy)m_query.getMetadataManager().getMDObject(MM.UNIQUE_ID, hier, MM.HIERARCHY);
                    Vector vLevels = new Vector();
                    if (hierObj != null)
                    {
                        MDLevel[] levels = hierObj.getLevels();
                        String levelID = null;
                        if (levels != null && levels.length > 0)
                        {
                            levelID = levels[0].getUniqueID();
                        }
                        if (levelID != null)
                        {
                            vLevels.addElement(levelID);
                        }
                    }
                    Selection newSel = new Selection(dimension);
                    newSel.setHierarchy(hier);
                    newSel.addStep(getInitialStep(dimension, hier, vLevels, 1, false, m_query.getMetadataManager()));
                    da = getValueCache().getCursorValues(newSel);
                    if (da == null)
                    {
                        selToCache = newSel;
                        daq = _getDataForSelection(newSel, new MetadataMap(new String[] {MetadataMap.METADATA_VALUE, MetadataMap.METADATA_LONGLABEL}));
                    }
                    else
                    {
                        //System.out.println("HIT!!!");
                    }
                }
                else
                {
                    String measDim = getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME);
                    if (dimension.equals(measDim))
                    {
                        MDMeasure[] measures = m_query.getMetadataManager().getMeasures();
                        if (measures != null && measures.length > 0)
                        {
                            String id = measures[0].getUniqueID();
                            Selection tempSel = new Selection(dimension);
                            MemberStep ms = new MemberStep(dimension);
                            ms.setInitial(true);
                            ms.addMember(id);
                            tempSel.addStep(ms);
                            da = getValueCache().getCursorValues(tempSel);
                            if (da == null)
                            {
                                selToCache = tempSel;
                                daq = _getDataForSelection(tempSel, new MetadataMap(new String[] {MetadataMap.METADATA_VALUE, MetadataMap.METADATA_LONGLABEL}));
                            }
                            else
                            {
                                //System.out.println("HIT!!!");
                            }
                        }
                    }
                    else
                    {
                        // Should do first last
                        Selection tempsel = new Selection(dimension);
                        FirstLastStep fs = new FirstLastStep(dimension);
                        fs.setNumValues(new Integer(1));
                        fs.setFirstLastType(FirstLastStep.FIRST);
                        tempsel.addStep(fs);
                        da = getValueCache().getCursorValues(tempsel);
                        if (da == null)
                        {
                            selToCache = tempsel;
                            daq = _getDataForSelection(tempsel, new MetadataMap(new String[] {MetadataMap.METADATA_VALUE, MetadataMap.METADATA_LONGLABEL}));
                        }
                        else
                        {
                            //System.out.println("HIT!!!");
                        }
                    }
                }
                if (daq == null && da == null)
                {
                    return null;
                }
                if (da == null)
                {                        
                    da = daq.getDataAccess();
                    if (!isAsynchronous())
                        createCloseableDataAccess(daq, selToCache);                    
                }
		            if (da != null)
                {
		                count = da.getEdgeExtent(DataDirector.COLUMN_EDGE);
		                if (count > 0)
                    {
		                    dimID = _makeString(da.getMemberMetadata(0, 0, 0, MetadataMap.METADATA_VALUE));
		                    dimLabel = _makeString(da.getMemberMetadata(0, 0, 0, MetadataMap.METADATA_LONGLABEL));
                            level = _getLevelID(0, 0, da, hier, 0);
                            levelName = _makeString(da.getMemberMetadata(0, 0, 0, MetadataMap.METADATA_LEVEL_NAME));
		                    //daq.getQuery().close();
		                }
		                else
                    {
		                    //daq.getQuery().close();
		                    return null;
		                }
		            }
		            else
		                return null;
            }
		    dimValue = new DimensionMember(dimID, dimLabel, hier, level, levelName);
		    //set this QDR value
		    setQDRValue(dimension, hier, dimValue);
		            
		  }
		  
		  return dimValue;
	}

    protected DataAccess getStraightDataAccess(String dim, int instance) throws Exception
    {
        return getStraightDataAccess(dim, null, instance);
    }
    
    protected DataAccess getStraightDataAccess(String dim, String hier, int instance) throws Exception
    {
        // Check for pre-existing cursor
        SelCursor sc = _getCursor(dim, instance);
        if (sc != null && !sc.m_bDirty)
        {
            if (hier != null)
            {
                // Check for sel/hier match
                Selection sel = sc.getSelection();
                if (hier.equals(sel.getHierarchy()))
                {
                    // Check to see if data access is available
                    DataAccess da = sc.getStraightDataAccess();
                    if (da != null)
                        return da;
                }
            }
            else
            {
                // Check to see if data access is available
                DataAccess da = sc.getStraightDataAccess();
                if (da != null)
                    return da;
            }
        }
        // Check local cursor
        if (m_originalDA != null)
        {
            if (hier != null)
            {
                // User specified a hierarchy:make sure the DA we're giving back meets requirement
                Selection sel = m_query.findSelection(dim);
                if (sel != null && !hier.equals(sel.getHierarchy()))
                    return null;
            }
            // Check that it's not the measure dim
            if (!dim.equals(getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME)) && findEdgeandLayer(m_originalDA, dim) != null)
            {
                return m_originalDA;
            }
        }

        return null;
    }

    protected CursorValueCache getValueCache()
    {
        if (m_valueCache == null)
            m_valueCache = new CursorValueCache();
                
        return m_valueCache;
    }
*/    
    public Vector getValues(String item, int instance, String hierarchy, String type, int max) throws QueryEditorException
    {
        Vector values = null;

  // blm - Selection code moved to dvt-olap
/*        Selection sel = getSelection(item, instance);
                                        
        if (sel != null && sel.getHierarchy() != null && hierarchy != null && !hierarchy.equals(sel.getHierarchy()))
        {
            // Selection no good: hierarchy doesn't match
            sel = null;
        }
        Selection storedSel = sel;
        DataAccess da = null;
        // Check cache
        if (sel != null)
            da = getValueCache().getCursorValues(sel);
            
        boolean fromCache = true;
        if (da == null)
        {
            try
            {
                da = getStraightDataAccess(item, hierarchy, instance);
                fromCache = false;
            }
            catch (Exception e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }
        boolean shouldClose = false;
        if (da == null && sel != null && sel.isAsymmetric())
        {
            // Can't evaluate this for values: do a one-off using firstlast
            Selection tempSel = new Selection(sel.getDimension());
            tempSel.setHierarchy(sel.getHierarchy());
            FirstLastStep fls = new FirstLastStep(tempSel.getDimension());
            fls.setHierarchy(tempSel.getHierarchy());
            fls.setNumValues(new Integer(1));
            try
            {
                fls.setFirstLastType(FirstLastStep.FIRST);
            }
            catch (InvalidStepArgException e)
            {
            }
            tempSel.addStep(fls);
            da = getDataAccess(tempSel);
            fromCache = false;
            storedSel = tempSel;
            shouldClose = true;
        }
        else
        {
            if (da == null)
            {
                // Go ahead and run it
                da = getDataAccess(item, instance);
                fromCache = false;
            }
        }
        //String hierarchy = null;
        if (sel != null)
        {
            hierarchy = sel.getHierarchy();
        }

        if (da != null && storedSel != null && !fromCache)
        {
            try
            {
                getValueCache().putCursorValues(storedSel, da, shouldClose);
                shouldClose = false;
            }
            catch (Exception e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }
        
        try
        {
            DimInfo di = findEdgeandLayer(da, item);
            int edge = di.getEdge();
            int layer = di.getDepth();
            int dimCount = da.getEdgeExtent(edge);
            values = new Vector();
            int intMax = (max == -1) ? dimCount : Math.min(dimCount, max);

            if (type == null)
            {
                // Want DimValue objects
                // String dim = (String)da.getDimensionMetadata(edge,
                //          depth, DimensionMetadataMap.DIM_METADATA_LONGLABEL);
        
                // Keep iterating until we have exhausted all values or
                // have reached our maximum count.
                for (int l=0; l<dimCount; l++)
                {
                    Object valueDesc, value;
                    String labels;
                    String[] levelID = getLevelOfMember(edge, layer, da, hierarchy, l);
                    value = new DimensionMember(
                        _makeString(da.getMemberMetadata(edge, layer, l,
                            MetadataMap.METADATA_VALUE)),
                        _makeString(da.getMemberMetadata(edge, layer, l,
                            type)),
                         hierarchy, levelID[0], levelID[1]);

                    if (values.indexOf(value) == -1)
                        values.addElement(value);
                
                    if ((max != -1) && (values.size() >= max))
                      break;
                }
            }
            else 
            {
                for (int l=0; l<intMax; l++)
                {
                    Object valueDesc, value;
                    String labels;
                    value = da.getMemberMetadata(edge, layer, l, type);
                    if (values.indexOf(value) == -1)
                        values.addElement(value);
                }
            }
         }
        catch (Exception ex)
        {
            throw new QueryRuntimeException(ex.getMessage(), ex);
        }

        if (shouldClose)
        {
            da.release();
        }*/
        return values;
    }

    protected String[] getLevelOfMember(int edge, int layer, DataAccess da, String hierarchy, int index) throws SliceOutOfRangeException, LayerOutOfRangeException, MetadataManagerException, EdgeOutOfRangeException
    {
        // Find the level, if possible
        Integer ld = (Integer)da.getMemberMetadata(edge, layer, index, MetadataMap.METADATA_INDENT);
        String[] levelID = new String[2];
        if (ld != null && hierarchy != null)
        {
            int levelDepth = ld.intValue();
            MDHierarchy hierObj = (MDHierarchy)m_query.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
            if (hierObj != null)
            {
                MDLevel[] levels = hierObj.getLevels();
                if (levels != null && levels.length > 0 && levelDepth < levels.length)
                {
                    levelID[0] = levels[levelDepth].getUniqueID();
                    levelID[1] = levels[levelDepth].getName();
                }
            }
        }
        return levelID;
    }

    /**
     * Generates some reasonable form of an initial, small step regardless of the presence
     * of a hierarchy, levels, etc.
     */
     // blm - Selection code moved to dvt-olap
/*    public Step getInitialStep(String dimension, String hierarchy, Vector vLevels, int maxLevel, boolean allStepForMeasure, MetadataManagerServices metadataManager) throws MetadataManagerException, InvalidStepArgException
    {
        if (dimension == null)
            return null;

        // Get the MDDimension
        MDDimension dim = (MDDimension)metadataManager.getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
        if (dim == null)
            return null;

        MDHierarchy hier = null;
        if (hierarchy == null)
        {
            // If we don't have a hierarchy, can we get the default?
            hier = dim.getDefaultHierarchy();
        }
        else
        {
            hier = (MDHierarchy)metadataManager.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
        }

        if (hier == null)
        {
            // This must be a dimension without a hierarchy.  Is it the measure?
            String measID = metadataManager.getMeasureDimension(null).getUniqueID();
            if (dimension.equals(measID))
            {
                if (allStepForMeasure)
                {
                    return new AllStep(dimension, null, null);
                }

                // Just use the zeroth measure from the metadata manager
                MDMeasure[] measures = metadataManager.getMeasures();
                if (measures != null && measures.length > 0)
                {
                    String id = measures[0].getUniqueID();
                    Selection tempSel = new Selection(dimension);
                    MemberStep ms = new MemberStep(dimension);
                    ms.setInitial(true);
                    ms.addMember(id);
                    return ms;
                }
                return null;
            }
            else
            {
                // Just a regular, hierarchy-less dimension.  Use firstlast step
                FirstLastStep fls = new FirstLastStep(dimension);
                fls.setFirstLastType(FirstLastStep.FIRST);
                fls.setNumValues(new Integer(1));
                return fls;
            }
        }
        else
        {
            // OK we have a hierarchy
            if (vLevels == null || vLevels.size() == 0)
            {
                // Check for levels--no levels specified
                MDLevel[] levels = hier.getLevels();
                if (levels != null && levels.length > 0)
                {
                    vLevels = new Vector();
                    // Just do the first N, if specified, one if not
                    int numLevels = maxLevel > levels.length ? levels.length : maxLevel;
                    for (int i = 0; i < numLevels; i++)
                    {
                        vLevels.addElement(levels[i].getUniqueID());
                    }
                }
            }
            if (vLevels != null && vLevels.size() > 0)
            {
                // And we presumably have levels
                AllStep all = new AllStep(dimension, hierarchy, vLevels);
                return all;
            }
            else
            {
                // No levels specified, and we couldn't find any.  Possibly a value based hierarchy.
                // Use special top ancestor family step
                FamilyStep fs = new FamilyStep(dimension, hierarchy, FamilyStep.OP_FIRSTANCESTORS, null, false);
                return fs;
            }
        }
    }
*/
	
    /**
     *  Generate a selection represented by an All Step.
     *
     *  @param dimension    String uniquely identifying the current Dimension
     *  @param hierarchy    String uniquely identifying the Hierarchy of this Step
     *  @param levels       Vector of Strings uniquely identifying the levels
     *  @return <code> Selection </code> represented by an ALL Step
     *
     */
     // blm - Selection code moved to dvt-olap
/*    private Selection _getAllSelection (String dimension, String hierarchy, 
                                        Vector levels) 
        {
        // Must build an all selection and store it, along with a data access
        AllStep all = new AllStep (dimension, hierarchy, levels);

        Selection sel = new Selection (dimension);
        sel.setHierarchy (hierarchy);
        sel.addStep(all);
        
        return sel;
        }    
*/	
  private String _getKey(String dimension, String hierarchy)
  {
      if (hierarchy != null)
        return dimension + ";" + hierarchy;
        
      return dimension;
  }
  
  
  private DimensionMember getQDRValue(String dimension, String hierarchy)
  {
      String key = _getKey(dimension, hierarchy);
      return (DimensionMember)m_QDRs.get(key);
  }
  
 /**
  * Sets the global QDR setting of a given dimension
  */
  // blm - Selection code moved to dvt-olap
/* 	private void setQDRValue(String dimension, String hierarchy, DimensionMember dimValue)
	{      
		  // add this dimension/dimval combination
		  m_QDRs.put(_getKey(dimension, hierarchy), dimValue);
	}

	        
    private OlapQDR _getQDR(Vector dimList, String measureID, String type, int instance) throws Exception
    {
   		OlapQDR newQDR = null;
   		
        Enumeration dims = dimList.elements();
        String dim;
        DimensionMember dimValue;
        String measDim = getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME);
        newQDR = new OlapQDR(measDim);
        // gek 10/20/99 replace addMeasureDimMember with addDimMemberPair
        newQDR.addDimMemberPair(newQDR.getMeasureDim(), measureID);
        dimValue = initQDRValue(measDim, null, instance);
        while (dims.hasMoreElements())
        {
            dim = getDimName((MDDimension)dims.nextElement(), LayerMetadataMap.LAYER_METADATA_NAME);
            String hier = getHierarchy(dim, instance);
            dimValue = initQDRValue(dim, hier, instance);
            newQDR.addDimMemberPair(dim, (type.equals(LayerMetadataMap.LAYER_METADATA_NAME) ? dimValue.getDimMemberID() : dimValue.toString()), hier, dimValue.getLevelID());
        }
        
        return(newQDR);        
   }


    private String getHierarchy(String dim, int instance)
    {
        // Check our pool for a selection/hier first, then use default if not found
        Selection sel = getSelection(dim, instance);
        String hier = null;
        if (sel != null)
        {
            hier = sel.getHierarchy();
            if (hier != null)
                return hier;
        }
        try
        {
            hier = _getDefaultHierForDim(dim);
        }
        catch (MetadataManagerException e)
        {        
        }
        return hier;
    }
*/

    /**
     * @hidden
     */
    /*public void propertyChange(PropertyChangeEvent evt) {
        Selection sel = (Selection)evt.getSource();                    
        String dimName = sel.getDimension();
        SelCursor sc = (SelCursor)m_selcursors.get(dimName);
        if (sc != null) {
            sc.setChanged(true);
        }
    }*/

   private MDDimension _getMeasureDimension() throws InvalidMetadataException
   {
        return m_query.getMeasureDimObj();
    }

    private Vector getDimensionList(MDMeasure[] measures) throws Exception
        {
         // Use the database to access a list of dimensionality
         // based on measures
            MDDimension[] dimList =
                m_query.getMetadataManager().dimensionalityOfMeasures(measures, MM.UNION);
            return Utility.copyArrayToVector(dimList);
        }

    private void updateDimListFromDatabase(String[] measures) throws Exception
        {
   		m_dimList = new Vector();
   		    
   		if (measures != null)
   		    {
   		    // gek 05/23/00 Synchronize client and server DatabaseObjs after
   		    //              adding new custom measures to the database server.
            //
            //              This is accomplished by calling getDatabaseObj()
            //              on the actual Database.
            //
            //              This is necessary in multi-tier mode so that the
            //              client can see the newly added measures.
            MDMeasure[] dbm = new MDMeasure[measures.length];
   		    for (int i = 0; i < dbm.length; i++)
   		        {
   		        dbm[i] =
   		            (MDMeasure)m_query.getMDObject(
                        MM.UNIQUE_ID, measures[i],
   		                    MM.MEASURE);
   		        }

		    m_dimList = getDimensionList(dbm);
   		    }

        /*
        // Always explicitly add measure
        if (m_measDim == null)
            {
            // Add long/short name: olapi doesn't have yet
            m_measDim = m_query.getDatabaseObj().getMeasureDimension();
            }
            
        m_dimList.addElement(m_measDim);
        */
        }
   

    /**
     * @hidden
     */
    public Enumeration getSelections() {
        return m_selcursors.getElements(0);
    }
   
    // Prune the selected selections based on the current dim list: only
    // selections in the dim list should be left
    // blm - Selection code moved to dvt-olap
/*    protected void pruneSelections() throws Exception
    {
        int count = m_selcursors.getInstanceCount();
        for (int instance = 0; instance < count; instance++)
        {
            Vector removalList = new Vector();
            Enumeration dim = m_selcursors.getKeys();
            String dimName;
        
            int found = 0;
            while (dim.hasMoreElements()) 
            {        
                dimName = (String)dim.nextElement();
                found = findInDimList(dimName, instance);
                
                if (found == -1 && !dimName.equals(getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME))) 
                {
                    // prune it
                    removalList.addElement(dimName);
                }
            }
        
            dim = removalList.elements();
            while (dim.hasMoreElements()) 
            {
                String dimension = (String)dim.nextElement();
                SelCursor sc = (SelCursor)m_selcursors.get(dimension, instance);
                if (sc != null)
                {
                    sc.close();
                    m_selcursors.remove(dimension, instance);
                }
            }
        }
    }
*/

    // blm - Selection code moved to dvt-olap
    public void dumpQueryInfo(String why, Throwable t, Query q/*, Selection sel*/)
    {
        if (q.m_QADebugMode && q.isDebugMode())
        {
            q.getErrorHandler().trace("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%", "", "");
            q.getErrorHandler().trace(why, getClass().getName(), "");
            QueryState state = new QueryState(null, null, null, q.getPropertySupport(), null, this, getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME));
            q.getErrorHandler().trace(QueryUtil.dumpState(getClass().getName(), null,/*sel,*/ state, q), getClass().getName(), "");
            q.getErrorHandler().error(t, getClass().getName(), "");
            q.getErrorHandler().trace("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&", "", "");
        }
    }

    // blm - Selection code moved to dvt-olap
/*    private String _makeString(Object obj)
    {
        return obj == null ? null : obj.toString();
    }
    
    private void _initializeDimensionality(int instance) throws Exception
    {
        if (m_dimList != null) {
            return;
        }
        Selection selection = m_query.findSelection(getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME));
            
        if (selection != null) {
            // Initialize dimension list based on selected set
            String measDim = getMeasureDimension(LayerMetadataMap.LAYER_METADATA_NAME);
            Selection sel = _getCursor(measDim, instance).getSelection();
            DataAccess da = null;
            if (sel != null)
            {
                da = getValueCache().getCursorValues(sel);
                if (da == null)
                {
                    da = _getCursor(measDim, instance).getDataAccess(true);
                    getValueCache().putCursorValues(sel, da, false);
                }
                else
                {
                    //System.out.println("HIT!!!");
                }
            }

            DimInfo di = findEdgeandLayer(da, measDim);
            int edge = 0;
            int layer = 0;
            if (da != null && di != null)
            {
                edge = di.getEdge();
                layer = di.getDepth();
            }
                        
            String[] measures = new String[(int)da.getEdgeExtent(edge)];
                    
                for (int i = 0; i < measures.length; i++) 
                {
                    measures[i] = _makeString(da.getMemberMetadata(edge, layer, i,
                                    MetadataMap.METADATA_VALUE));  
                }
                            
                updateDimListFromDatabase(measures);
        }
    }
  */  
    private Vector buildDimList(Vector dimList, String type)
   	    {
		// Build a list of just dim names
	  	Vector dimNames = new Vector();
	  	
	  	if (dimList != null)
   		    {
	    	Enumeration dims = dimList.elements();
	    	while (dims.hasMoreElements())
	   		    {
	        	dimNames.addElement(getDimName((MDDimension)dims.nextElement(), type));
	   		    }    
   		    }
	    
	    return dimNames;
        }

    // blm - Selection code moved to dvt-olap
/*    private int findInDimList(String dimName, int instance) throws Exception
        {
        _initializeDimensionality(instance);
        for (int i = 0; i < m_dimList.size(); i++)
            {
            if (dimName.equals(getDimName((MDDimension)m_dimList.elementAt(i), 
                LayerMetadataMap.LAYER_METADATA_NAME))) 
                {
                return i;
                }
            }
    
        return -1;
        }
        
    protected abstract oracle.dss.datautil.SelectionChangedEvent getSelectionChanged(Selection sel, int instance) throws CloneNotSupportedException;
*/
    protected abstract DataFilterChangedEvent getDataFilterChanged(int instance, BaseDataFilter[] oldDF, BaseDataFilter[] newDF);
    
    private String getDimName(MDDimension dim, String type) 
        {
        if (type.equals(LayerMetadataMap.LAYER_METADATA_NAME)) {
            return dim.getUniqueID();
        }
        else if (type.equals(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME))
        {
            return dim.getName();
        }
        else if (type.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL)) {            
            return dim.getLongLabel();
        }
        else if (type.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL)) {
            return dim.getShortLabel();
        }
        return null;
        }
            
    
    
    // blm - Selection code moved to dvt-olap
    // Retrieve query reference from table for dimension
/*    private Query _getQuery(String dimension) throws CloneNotSupportedException, QueryException, MetadataManagerException
    {
        SelCursor sc = _getCursor(dimension, 0);
        if (sc != null)
        {
            return sc.getQuery();
        }
        return null;
    }
    
    // Check table and return container for sel and DA
    protected SelCursor _getCursor(String dimension, int instance) throws QueryException
    {
        // Check for an already-available selection
        SelCursor sc = (SelCursor)m_selcursors.get(dimension, instance);
        if (sc != null) 
            {
            return sc;
            }
            
        // Must get the selected selection from the Data source and store 
        // a copy of it, along with a data access
        Selection sel = null;
            Selection tempSel = m_query.findSelection(dimension);
            if (tempSel != null) {
                try
                {
                    sel = (Selection)tempSel.clone();
                }
                catch (CloneNotSupportedException e)
                {
                    throw new CloneException(e.getMessage(), e);
                }
                // We must do the action to the selection that the Query would do on applySelection(),
                // which means erasing the drill step
                if (sel.clearDrillStep())
                {
                    // Erase all drilling: modification of basic selection for dimension
                    sel.setDrillStep(null);
                    sel.removeAllDrillLevelSteps();
                }

                //sel.addPropertyChangeListener(this);
            }

            try
            {
                if (sel == null)
                {
                    // Check if dimension is really a dimension: if so it requires a selection
                    if (isDimension(dimension))
                    {
                        // Create an empty selection: might be a new dimension
                        sel = new Selection(dimension);
                        sel.setHierarchy(_getDefaultHierForDim(dimension));
                    
                        // Create an empty data access and store this
                        sc = new SelCursor(sel);
                    }
                    else
                    {
                        sc = new SelCursor(dimension);
                    }
                }
                else 
                {            
                    sc = new SelCursor(sel);
                }
            }
            catch (Exception e)
            {
                throw new QueryException(e.getMessage(), e);
            }
        
        m_selcursors.put(dimension, sc, instance);
        
        return sc;
    }
*/    
    // Fire a dimension change notice to all listeners
    protected void fireDimensionsChanged(DimensionsChangedEvent dce) 
        {
        Enumeration list = m_listeners.elements();
        QueryAccessListener listener = null;
        while (list.hasMoreElements()) 
            {
            listener = (QueryAccessListener)list.nextElement();
            listener.dimensionsChanged(dce);
            }
        }
    
    // Fire a change notice to all listeners
    protected void fireDataAccessChanged(DataAccessChangedEvent dac)
    {
        Enumeration list = m_listeners.elements();
        QueryAccessListener listener = null;
        while (list.hasMoreElements()) 
            {
            listener = (QueryAccessListener)list.nextElement();
            listener.dataAccessChanged(dac);
            }
    }
    

    // Fire data filter changed event
    protected void fireDataFilterChanged(DataFilterChangedEvent dfce)
    {
        Enumeration list = m_listeners.elements();
        QueryEditorListener listener = null;
        while (list.hasMoreElements()) 
        {
            listener = (QueryEditorListener)list.nextElement();
            listener.dataFilterChanged(dfce);
        }
    }
    
    // Fire a change notice to all listeners
    // blm - Selection code moved to dvt-olap
/*    protected void fireSelectionChanged(oracle.dss.datautil.SelectionChangedEvent sce) 
        {
        Enumeration list = m_listeners.elements();
        QueryAccessListener listener = null;
        while (list.hasMoreElements())
            {
            listener = (QueryAccessListener)list.nextElement();
            listener.selectionChanged(sce);
            }
        }*/
        
    // Fire a polling notice to all listeners
    protected void firePollingRequired(oracle.dss.datautil.PollingRequiredEvent pre)
    {
        Enumeration list = m_listeners.elements();
        QueryEditorListener listener = null;
        while (list.hasMoreElements()) 
            {
            listener = (QueryEditorListener)list.nextElement();
            listener.pollingRequired(pre);
            }
    }
    
        
    // Find this dim's information and cache it
    protected DimInfo findEdgeandLayer(DataAccess da, String dim)
        {
        if (da == null)
            return null;

        int edge, depth;
        try
            {
            int edgeCount = da.getEdgeCount();
            for (edge = 0; edge < edgeCount; edge++)
                {
                int layerCount = da.getLayerCount(edge);
                for (depth = 0; depth < layerCount; depth++)
                    {
                    if (dim.equals(da.getLayerMetadata(edge, depth,
                        LayerMetadataMap.LAYER_METADATA_NAME)))
                        {
                            DimInfo di = new DimInfo(edge, depth);
                            return di;
                        }
                    }
                }
            }

        catch (Exception e)
            {
            // Something is very wrong
            }

        return null;
    }

    protected abstract boolean isAsynchronous();
    
    protected abstract boolean isAutoFireEvents();
    
    
    // DataDirectorListener impl
    public void pollingRequired(PollingRequiredEvent polling)
    {        
        if (this instanceof QueryEditor)
            firePollingRequired(new oracle.dss.datautil.PollingRequiredEvent((QueryEditor)this));
    }

    public void viewDataChanged(oracle.dss.util.DataChangedEvent e)
    {        
    }
    
    public void viewDataAvailable(oracle.dss.util.DataAvailableEvent e)
    {        
    }
    
    public void waitDataAvailable(WaitDataAvailableEvent e)
    {        
    }
    

    protected Query createQuery() throws QueryEditorException
    {
        Query query = m_query.getQueryManager().createQuery();        
        try
        {
            query.setProperty(QueryConstants.PROPERTY_ASYNCHRONOUS, new Boolean(isAsynchronous()));
            if (isAsynchronous())
            {
                query.setProperty(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS, new Boolean(isAutoFireEvents()));
                query.createCubeDataDirector().addDataDirectorListener(this);
            }
        }
        catch (Exception e)
        {
            throw new QueryEditorException(e.getMessage(), e);
        }
        return query;
    }
    
    protected interface ReturnValueProvider
    {
        public Object getReturnValue() throws Exception;
    }

    protected class ReturnValueProviderImpl extends Object implements ReturnValueProvider
    {
        protected QueryUtil2.DAQuery m_daq = null;
        // blm - Selection code moved to dvt-olap
/*        protected Selection m_selection = null;*/
        
        public ReturnValueProviderImpl(QueryUtil2.DAQuery daq /*, Selection selection*/)
        {
            super();
            m_daq = daq;
            // blm - Selection code moved to dvt-olap
/*            m_selection = selection;*/
        }
        
        public Object getReturnValue() throws Exception
        {
            return createCloseableDataAccess(m_daq/*, m_selection*/);
        }        
    }
    

    /**
     *  Class to store item or selection with its cursor together
     */
     // blm - Selection code moved to dvt-olap
/*    protected class SelCursor extends Object implements ReturnValueProvider
    {
        protected Instance m_myInstance = null;
        
        public SelCursor(String item) throws Exception
        {
            super();
            
            m_dimName = item;
            
            // Generate the query
            m_q = createQuery();
            // Make sure LOV property is set just in case
            m_q.setProperty(QueryConstants.PROPERTY_LOV, new Boolean(true));
            m_q.setHierarchicalDrilling(m_query.isHierarchicalDrilling());
            // Copy any universe
            Selection selUniverse = m_query.getUniverseSelection(item);
            if (selUniverse != null)
            {
                m_q.setUniverseSelection(item, selUniverse);
            }
            m_q.setMetadataMap(null, m_metaTypes);
            m_bDirty = true;
            m_bwasDrilled = false;   
        }
        
        // Constructor
        public SelCursor(Selection sel) throws Exception
        {
            this(sel.getDimension());
            
            // Turn off notification when constructing
            m_bNotify = false;
            setSelection(sel);
            m_bNotify = true;
        }

        public void setInstance(Instance instance)
        {
            m_myInstance = instance;
        }
        
        // Clean up
        public void close()
        {
            if (m_da != null)
                m_da.release();
                
            m_q.close();
        }
        
        // Get functions
        public Query getQuery()
        {
            return m_q;
        }
        
        public Selection getSelection()
        {
            return m_selection;
        }
        
        public void setSelection(Selection sel) throws CloneNotSupportedException, InvalidStepArgException, SelectionException, QueryException, MetadataManagerException
        {
            Selection oldSel = getSelection();
            if (oldSel != null && !m_bwasDrilled && oldSel.equals(sel))
            {
                // Nothing changed
                return;
            }
//            m_q.applySelection(sel);
            m_selection = sel;

            m_bwasDrilled = false;
            m_bDirty = true;
            if (m_myInstance != null)
                _fireSelectionChanged(m_myInstance.getInstance());
        }

        private void _fireSelectionChanged(int instance) throws CloneNotSupportedException
        {
            if (!m_bNotify)
            {
                return;
            }
            // Fire the event
            fireSelectionChanged(getSelectionChanged(getSelection(), instance));
        }

        private void _fireDataAccessChanged()
        {
            if (CommonQueryEditor.this instanceof QueryEditor)
            {
                fireDataAccessChanged(new DataAccessChangedEvent((QueryEditor)CommonQueryEditor.this, m_dimName, m_da));
            }
            else
            {
                fireDataAccessChanged(new DataAccessChangedEvent(CommonQueryEditor.this, m_dimName, m_da));
            }
        }

        private BaseDataFilter[] getDataFilters()
        {
            // Get the data filters from the instance
            return m_myInstance.getDataFilters();                
        }

        public void setDataFilters(BaseDataFilter[] dataFilters)
        {
            m_bDirty = true;
            m_myInstance.setDataFilters(dataFilters);            
        }
        
        public Object getReturnValue()
        {
            return m_da;            
        }
        
        // Boolean indicates not to retrieve the cursor if there's none there: only for not-necessarily-necessary
        // clean up, for example
        public DataAccess getDataAccess(boolean noMatterWhat) throws InvalidStepArgException, SelectionException, QueryException, MetadataManagerException
        {
            if (m_da == null && noMatterWhat)
            {
                setCurrentOperation(m_q, this);
                // Never been generated at all
                if (m_selection != null)
                {
                    if (m_selection.isAsymmetric())
                    {
                        m_bDirty = false;
                        m_da = null;
                        return m_da;
                    }
                
                    m_q.applySelection(m_selection);
                }
                BaseDataFilter[] df = getDataFilters();
                if (df != null)
                {
                    m_q.setDataFilters(df);
                }
                m_bDirty = false;
                // Performance dump
                dumpQueryInfo("Initing query in QueryAccess.SelCursor.getDataAccess()",
                              new Throwable(), m_q, m_selection);
                String item = getSelection() == null ? m_dimName : getSelection().getDimension();
                m_q.addQueryListener(new QueryAdapter() {
                                    public void dataChanged(DataChangedEvent e)
                                    {
                                        m_da = e.getDataAccess();
                                        _fireDataAccessChanged();
                                    }
                                    public void dataAvailable(DataAvailableEvent e) {
                                        if (e.isAvailable())
                                        {
                                            m_da = e.getDataAccess();
                                            _fireDataAccessChanged();
                                        }
                                    }
                                    public void selectionChanged(SelectionChangedEvent e)
                                    {
                                        // Fire the event
//                                        _fireSelectionChanged();
                                    }
                    });
                m_q.initQuery(new String[][] {{item}}, null);
            }
            else
            {
                if (m_bDirty)
                {
                    if (m_selection != null && m_selection.isAsymmetric())
                    {
                        m_bDirty = false;
                        m_bwasDrilled = false;
                        m_da = null;
                        return m_da;
                    }
                    m_bDirty = false;
                    m_bwasDrilled = false;
                    // Performance dump
                    dumpQueryInfo("Updating query in QueryAccess.SelCursor.getDataAccess()",
                                  new Throwable(), m_q, m_selection);

                    BaseDataFilter[] df = getDataFilters();
                    if (df != null)
                    {
                        m_q.setDataFilters(df);
                    }
                                  
                    if (m_selection != null)
                        m_q.applySelection(m_selection);
                }
            }
            return m_da;
        }

        public DataAccess getStraightDataAccess()
        {
            if (!m_bDirty)
                return m_da;
            return null;
        }

        // storage
        private DataAccess m_da = null;
        private Query m_q = null;
        private Selection m_selection = null;
        private String m_dimName = null;
        private boolean m_bDirty = false;
        protected boolean m_bwasDrilled = false;
        private boolean m_bNotify = true;
    }
*/
    protected class CloseableReleaseHelper implements ReleaseHelper
    {
        protected boolean m_incache = false;

        
        /**
        * Constructor that uses the methods of a <code>QueryDataAccess</code>
        * object to retrieve a <code>CubeCursor</code> object and to create a new
        * <code>QueryDataDirector</code> object.
        *
        * @status Documented
        */
/*        public CloseableDataAccess(QueryUtil2.DAQuery daq) throws QueryException
        {
            super(daq.getDataAccess() != null ? ((ETDataAccess)daq.getDataAccess()).getQuerySource() : null, daq.getDataAccess() != null ? ((ETDataAccess)daq.getDataAccess()).getDataDirector() : null, daq.getQuery().getQueryState());
        }
        
        public void setDataAccess(ETDataAccess da)
        {
            super.setQuerySource(da.getQuerySource());
            super.setDataDirector(da.getDataDirector());
        }*/
        
        /**
        * Informs the implementor that the caller no
        * longer needs this <code>DataAccess</code> reference.
        * Provides an opportunity for cleaning up the cursor when a caller is
        * finished with it.
        * <p>
        * Views should not call this method for normal
        * DataAccess instances, because calling this method makes the DataAccess
        * reference unavailable to other presentation beans that might be using it.
        * This method is useful only in special cases where a caller has wrapped
        * a DataAccess around a private single-layer cursor.
        * <P>
        * The implementor may or may not
        * implement this method, depending on the underlying cursor.
        *
        * @status Documented
        */
        public void release()
        {
            if (m_incache)
                return;
                
            // Close the query associated with this DA and remove it from the list
            Query q = (Query)m_queryList.get(this);
            if (q != null)
            {
                q.close();
            }
            m_queryList.remove(this);
        }
        
        public void setInCache(boolean incache)
        {
            m_incache = incache;
        }
    }


    
    /**
     *  @hidden
     *  Class to manage a cache of cursor value DataAccesses keyed by the value of selection/steps
     */
     // blm - Selection code moved to dvt-olap
/*    protected class CursorValueCache extends Hashtable
    {
        public void clear()
        {
            Enumeration sels = elements();
            while (sels.hasMoreElements())
            {
                Vector selList = (Vector)sels.nextElement();
                if (selList != null)
                {
                    Enumeration items = selList.elements();
                    while (items.hasMoreElements())
                    {
                        CursorSelectionElement cse = (CursorSelectionElement)items.nextElement();
                        if (cse != null)
                        {
                            cse.release();                            
                        }
                    }
                }
            }
            super.clear();
        }
        
        public DataAccess getCursorValues(Selection selToFind)
        {
            if (selToFind == null)
                return null;
                
            // Look up main cache list by dim
            Vector selectionsForDim = (Vector)get(selToFind.getDimension());
            if (selectionsForDim == null)
                return null;
            
            int pos = getCursorValuesPosition(selToFind, selectionsForDim);
            
            if (pos > -1)
                return ((CursorSelectionElement)selectionsForDim.elementAt(pos)).getDataAccess();
                
            return null;
        }
        
        protected int getCursorValuesPosition(Selection selToFind, Vector selectionsForDim)
        {
            int count = selectionsForDim.size();
            for (int i = 0; i < count; i++)
            {
                CursorSelectionElement cse = (CursorSelectionElement)selectionsForDim.elementAt(i);
                if (cse != null)
                {
                    // Compare
                    if (cse.getSelection().equals(selToFind))
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        public void putCursorValues(Selection selToPut, DataAccess da, boolean shouldClose) throws Exception
        {
            if (selToPut == null)
                return;
                
            selToPut = (Selection)selToPut.clone();
            String dim = selToPut.getDimension();
            Vector selectionsForDim = (Vector)get(dim);
            if (selectionsForDim == null)
                selectionsForDim = new Vector();
        
            CursorSelectionElement cse = new CursorSelectionElement(selToPut, da, shouldClose);
            
            // See if it's already there
            int pos = getCursorValuesPosition(selToPut, selectionsForDim);
            if (pos == -1)
            {
                selectionsForDim.addElement(cse);
            }
            else
            {
                selectionsForDim.setElementAt(cse, pos);
            }
            put(selToPut.getDimension(), selectionsForDim);            
        }
        
        protected class CursorSelectionElement
        {
            protected Selection m_sel = null;
            protected DataAccess m_da = null;
            protected boolean m_shouldClose = true;
            
            public CursorSelectionElement(Selection sel, DataAccess da, boolean shouldClose)
            {
                m_sel = sel;
                m_da = da;
                m_shouldClose = shouldClose;
            }
            
            public void release()
            {
                if (m_shouldClose && m_da != null)
                {
                    if (m_da instanceof CommonDataAccess && ((CommonDataAccess)m_da).getReleaseHelper() instanceof CloseableReleaseHelper)
                    {
                        ((CloseableReleaseHelper)((CommonDataAccess)m_da).getReleaseHelper()).setInCache(false);                        
                    }
                    m_da.release();
                }
            }
            
            public Selection getSelection()
            {
                return m_sel;
            }
            
            public DataAccess getDataAccess()
            {
                return m_da;
            }
        }        
    }
*/

    protected class QAListener extends QueryAdapter
    {
        /**
         * Responds when data, metadata, or both data and metadata are available or
         * revoked.
         * This event cannot be consumed.
         *
         * @param e DataAvailableEvent
         *
         * @status Documented
         */
        public void dataAvailable(DataAvailableEvent e)
        {
            if (e.isAvailable())
                m_originalDA = e.getDataAccess();
        }

        /**
         * Responds when data, metadata, or both data and metadata have changed.
         * This event cannot be consumed.
         *
         * @param e DataChangedEvent
         *
         * @status Documented
         */
        public void dataChanged(DataChangedEvent e)
        {
            m_originalDA = e.getDataAccess();
        }
    }

    protected class InstanceList extends Object
    {
        protected Instance[] m_struct = null;
        protected BaseDataFilter[] m_df = null;
        protected boolean m_dfChanged = false;
        
        public InstanceList()
        {
            super();
            clear();
        }
        
        public boolean isDataFilterSet(int instance)
        {
            if (_instanceOK(instance))
                return m_struct[instance].isDataFilterSet();
            return false;
        }
        
        public BaseDataFilter[] getDataFilters(int instance)
        {
            _expand(instance);
            return m_struct[instance].getDataFilters();
        }
        
        public void setDataFilters(BaseDataFilter[] df, int instance)
        {        
            _expand(instance);
            m_struct[instance].setDataFilters(df);
            m_dfChanged = true;
            m_df = df;
        }

        public int getInstanceCount()
        {
            return m_struct.length;
        }
        
        public void clear()
        {
            m_struct = new Instance[0];
        }
        
        public void add(String name, int instance)
        {
            put(name, name, instance);
        }
        
        // blm - Selection code moved to dvt-olap
    /*        public void put(String key, SelCursor data, int instance)
        {
            put(key, (Object)data, instance);
            data.setInstance(m_struct[instance]);
        }*/
        
        private void put(Object key, Object data, int instance)
        {
            _expand(instance);
            m_struct[instance].getSelCursors().put(key, data);
        }
        
        public void remove(Object key, int instance)
        {
            if (_instanceOK(instance))
            {
                m_struct[instance].getSelCursors().remove(key);
            }
        }
        
        public boolean find(Object name, int instance)
        {
            if (_instanceOK(instance))
            {
                // OK to check
                Hashtable v = m_struct[instance].getSelCursors();
                if (v != null)
                {
                    return v.get(name) != null;
                }
            }
            return false;
        }
        
        private boolean _instanceOK(int instance)
        {
            return (m_struct.length > instance && m_struct[instance] != null);
        }
        
        public Object get(String key, int instance)
        {
            if (_instanceOK(instance))
            {
                return m_struct[instance].getSelCursors().get(key);
            }
            return null;
        }
        
        public Enumeration getElements(int instance)
        {
            return _getElements(instance, false);
        }
        
        private Enumeration _getElements(int instance, boolean keys)
        {
            if (_instanceOK(instance))
            {
                if (keys)
                    return m_struct[instance].getSelCursors().keys();
                else
                    return m_struct[instance].getSelCursors().elements();
            }
            return null;
        }
        
        public Enumeration getKeys()
        {
            return _getElements(true);
        }
        
        public Enumeration getElements()
        {
            return _getElements(false);
        }
        
        private Enumeration _getElements(boolean keys)
        {
            Vector v = new Vector();
            for (int i = 0; i < m_struct.length; i++)
            {
                if (m_struct[i] != null)
                {
                    Enumeration e = keys ? m_struct[i].getSelCursors().keys() : m_struct[i].getSelCursors().elements();
                    while (e.hasMoreElements())
                    {                        
                        v.addElement(e.nextElement());
                    }
                }
            }
            return v.elements();
        }
        
        private void _expand(int newLength)
        {
            if (m_struct.length <= newLength+1)
            {
                Instance[] temp = new Instance[m_struct.length];
                for (int i = 0; i < temp.length; i++)
                    temp[i] = m_struct[i];
                m_struct = new Instance[newLength+1];
                for (int i = 0; i < temp.length; i++)
                    m_struct[i] = temp[i];
                for (int i = temp.length; i < m_struct.length; i++)
                    m_struct[i] = new Instance(i);
            }
        }
    }

    protected class Instance extends Object
    {
        protected Hashtable m_sc = new Hashtable();
        protected BaseDataFilter[] m_df = null;
        protected int m_instance = -1;
        protected boolean m_dfSet = false;
        
        public Instance(int instance, BaseDataFilter[] df)
        {
            super();
            m_instance = instance;
            if (df == null)
                m_df = m_query.getDataFilters();
            else
                m_df = df;
        }
        
        public Instance(int instance)
        {
            this(instance, null);
        }
                
        public int getInstance()
        {
            return m_instance;
        }
        
        public Hashtable getSelCursors()
        {
            return m_sc;
        }
        
        public void setDataFilters(BaseDataFilter[] df)
        {
            if (!Utility.compareVectors(Utility.copyArrayToVector(df), Utility.copyArrayToVector(getDataFilters())))
            {
                DataFilterChangedEvent dfce = getDataFilterChanged(m_instance, m_df, df);
                m_df = df;
                m_dfSet = true;
                fireDataFilterChanged(dfce);                
            }
        }
        
        public BaseDataFilter[] getDataFilters()
        {
            return m_df;
        }
        
        public boolean isDataFilterSet()
        {
            return m_dfSet;
        }        
    }    
    
    protected class CurrentOperation extends Object
    {
        protected Query m_query = null;
        protected ReturnValueProvider m_rvp = null;
        
        public CurrentOperation(Query query, ReturnValueProvider rvp)
        {
            super();
            m_query = query;
            m_rvp = rvp;
        }
        
        public Object getReturnValue() throws Exception
        {
            return m_rvp.getReturnValue();
        }
        
        public Query getQuery()
        {
            return m_query;
        }
    }

    /**
     *  Information about each particular dimension for a given set of data and layout
     *  that we might not want to refind or recalculate.
     *  @status New
     */
    protected class DimInfo extends Object
    {
        public DimInfo(int e, int d)
            {
            super();

            setEdge(e);
            setDepth(d);
            }

        public void setEdge(int e)
            {
            edge = e;
            }

        public int getEdge()
            {
            return edge;
            }        
        
        public void setDepth(int d) 
            {
            depth = d;
            }
        
        public int getDepth() 
            {
            return depth;
            }

        protected int edge  = -1;
        protected int depth = -1;
    }
    
}
