/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if an invalid measure is found.
 *
 * @status Documented
 */
public class InvalidMeasureRuntimeException extends InvalidMetadataRuntimeException
{

    
    /**    
     * Constructor for a single invalid measure.
     *
     * @param s       Message to display.
     * @param measure Invalid measure that is in question.
     * @param e       Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMeasureRuntimeException(String s, String measure, Throwable e)
    {
        super(s, measure, e);
    }
    
    /**    
     * Constructor for multiple invalid measures.
     *
     * @param s       Message to display.
     * @param measure Invalid measures that are in question.
     * @param e       Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public InvalidMeasureRuntimeException(String s, String[] measure, Throwable e)
    {
        super(s, measure, e);
    }    

}