/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.util.ListResourceBundle;

/**
 * List of tokens for the calc parser and the default attributes for each token.
 *
 * @hidden
 */
public class CalcTokenAttributes extends ListResourceBundle
{
    static final Object [ ] [ ] arTokenAttribute =
    {
        { CalcTokenConstants.TOKEN_END,     "token:end#syntax:[END]#"},
        
        { CalcTokenConstants.TOKEN_FLOAT,   "token:float#class:numericClass#underline:true#"},                  
        { CalcTokenConstants.TOKEN_NUMBER,  "token:float#class:numericClass#underline:true#"},

        { CalcTokenConstants.TOKEN_HIERARCHY_KEYWORD,   "token:hierarchyKeyword#class:keywordClass#syntax:HIERARCHY#"},
        { CalcTokenConstants.TOKEN_PARENT,              "token:parent#class:keywordClass#syntax:PARENT#"},
        { CalcTokenConstants.TOKEN_LIST_HIERARCHY,      "token:listHierarchy#class:keywordClass#syntax:LIST#"},
        { CalcTokenConstants.TOKEN_TOTAL,               "token:total#class:keywordClass#syntax:TOTAL#"},
        { CalcTokenConstants.TOKEN_ALL_LEVELS,          "token:allLevels#class:keywordClass#syntax:ALL_LEVELS#"},
        { CalcTokenConstants.TOKEN_DAY,                 "token:day#class:keywordClass#syntax:DAY#"},
        { CalcTokenConstants.TOKEN_WEEK,                "token:week#class:keywordClass#syntax:WEEK#"},
        { CalcTokenConstants.TOKEN_MONTH,               "token:month#class:keywordClass#syntax:MONTH#"},
        { CalcTokenConstants.TOKEN_QUARTER,             "token:quarter#class:keywordClass#syntax:QUARTER#"},
        { CalcTokenConstants.TOKEN_YEAR,                "token:year#class:keywordClass#syntax:YEAR#"},
        { CalcTokenConstants.TOKEN_PERIOD,              "token:period#class:keywordClass#syntax:PERIOD#"},
        { CalcTokenConstants.TOKEN_ASCENDING,           "token:ascending#class:keywordClass#syntax:LOWEST_TO_HIGHEST#"},
        { CalcTokenConstants.TOKEN_DESCENDING,          "token:descending#class:keywordClass#syntax:HIGHEST_TO_LOWEST#"},
        { CalcTokenConstants.TOKEN_LEVEL_KEYWORD,       "token:levelKeyword#class:keywordClass#syntax:LEVEL#"},
        { CalcTokenConstants.TOKEN_SELECTION_KEYWORD,   "token:selectionKeyword#class:keywordClass#syntax:SELECTION#"},
        { CalcTokenConstants.TOKEN_CURRENT,             "token:current#class:keywordClass#syntax:CURRENT#"},
        { CalcTokenConstants.TOKEN_DEFAULTSEL,          "token:defaultSelection#class:keywordClass#syntax:DEFAULT#"},
        
        { CalcTokenConstants.TOKEN_DOUBLE_QUOTES,       "token:doubleQuotes#syntax:\"#"},
        { CalcTokenConstants.TOKEN_ESCAPE_CHAR,         "token:escapeChar#syntax:\\#"},
        
        { CalcTokenConstants.TOKEN_ADD,                 "token:add#class:operatorClass#syntax:+#"},
        { CalcTokenConstants.TOKEN_DIVIDE,              "token:divide#class:operatorClass#syntax:/#"},
        { CalcTokenConstants.TOKEN_MULTIPLY,            "token:multiply#class:operatorClass#syntax:*#"},
        { CalcTokenConstants.TOKEN_SUBTRACT,            "token:subtract#class:operatorClass#syntax:-#"},

        { CalcTokenConstants.TOKEN_LEFT_QUALIFIER,      "token:leftQualifier#syntax:[#"},
        { CalcTokenConstants.TOKEN_NAME_QUALIFIER,      "token:nameQualifier#syntax::#"},
        { CalcTokenConstants.TOKEN_RIGHT_QUALIFIER,     "token:rightQualifier#syntax:]#"},
        { CalcTokenConstants.TOKEN_LPAREN,              "token:leftParentheses#syntax:(#"},
        { CalcTokenConstants.TOKEN_RPAREN,              "token:rightParentheses#syntax:)#"},
        { CalcTokenConstants.TOKEN_SEPARATOR,           "token:separator#syntax:,#"},
        { CalcTokenConstants.TOKEN_QDRSEPARATOR,        "token:qdrSeparator#syntax:;#"},

        { CalcTokenConstants.TOKEN_EXPONENTIAL,         "token:exponential#class:operatorClass#syntax:^#"},
        { CalcTokenConstants.TOKEN_AND,                 "token:and#syntax:&#"},
        { CalcTokenConstants.TOKEN_NOT,                 "token:not#syntax:~#"},
        { CalcTokenConstants.TOKEN_OR,                  "token:or#syntax:|#"},
        { CalcTokenConstants.TOKEN_WHITE_SPACE,         "token:whiteSpace#syntax: #"},
        
        { CalcTokenConstants.TOKEN_AGGREGATE,           "token:aggregate#class:functionClass#syntax:Aggregate#"},
        { CalcTokenConstants.TOKEN_AVERAGE,             "token:average#class:functionClass#syntax:Average#"},
        { CalcTokenConstants.TOKEN_COUNT,               "token:count#class:functionClass#syntax:Count#"},
        { CalcTokenConstants.TOKEN_MAXIMUM,             "token:maximum#class:functionClass#syntax:Maximum#"},
        { CalcTokenConstants.TOKEN_MINIMUM,             "token:minimum#class:functionClass#syntax:Minimum#"},
        { CalcTokenConstants.TOKEN_PERCENTOFTOTAL,      "token:percentOfTotal#class:functionClass#syntax:PercentOfTotal#"},
        { CalcTokenConstants.TOKEN_SUM,                 "token:sum#class:functionClass#syntax:Sum#"},

        { CalcTokenConstants.TOKEN_DIFFERENCE,          "token:difference#class:functionClass#syntax:Difference#"},
        { CalcTokenConstants.TOKEN_INDEX,               "token:index#class:functionClass#syntax:Index#"},
        { CalcTokenConstants.TOKEN_PERCENTDIFFERENCE,   "token:percentDifference#class:functionClass#syntax:PercentDifference#"},
        { CalcTokenConstants.TOKEN_PERCENTMARKUP,       "token:percentMarkup#class:functionClass#syntax:PercentMarkup#"},
        { CalcTokenConstants.TOKEN_PERCENTVARIANCE,     "token:percentVariance#class:functionClass#syntax:PercentVariance#"},
        { CalcTokenConstants.TOKEN_RANK,                "token:rank#class:functionClass#syntax:Rank#"},
        { CalcTokenConstants.TOKEN_RATIO,               "token:ratio#class:functionClass#syntax:Ratio#"},
        { CalcTokenConstants.TOKEN_SHARE,               "token:share#class:functionClass#syntax:Share#"},
        { CalcTokenConstants.TOKEN_VARIANCE,            "token:variance#class:functionClass#syntax:Variance#"},

        { CalcTokenConstants.TOKEN_CALENDARTODATE,      "token:calendarToDate#class:functionClass#syntax:CalendarToDate#"},
        { CalcTokenConstants.TOKEN_CALENDARTOGO,        "token:calendarToGo#class:functionClass#syntax:CalendarToGo#"},
        { CalcTokenConstants.TOKEN_CUMULATIVETOTAL,     "token:cumulativeTotal#class:functionClass#syntax:CumulativeTotal#"},
        { CalcTokenConstants.TOKEN_FISCALTODATE,        "token:fiscalToDate#class:functionClass#syntax:FiscalToDate#"},
        { CalcTokenConstants.TOKEN_FISCALTOGO,          "token:fiscalToGo#class:functionClass#syntax:FiscalToGo#"},
        { CalcTokenConstants.TOKEN_LAG,                 "token:lag#class:functionClass#syntax:Lag#"},
        { CalcTokenConstants.TOKEN_LAGDIFFERENCE,       "token:lagDifference#class:functionClass#syntax:LagDifference#"},
        { CalcTokenConstants.TOKEN_LAGPERCENT,          "token:lagPercent#class:functionClass#syntax:LagPercent#"},
        { CalcTokenConstants.TOKEN_LEAD,                "token:lead#class:functionClass#syntax:Lead#"},
        { CalcTokenConstants.TOKEN_MOVINGAVERAGE,       "token:movingAverage#class:functionClass#syntax:MovingAverage#"},
        { CalcTokenConstants.TOKEN_MOVINGMAXIMUM,       "token:movingMaximum#class:functionClass#syntax:MovingMaximum#"},
        { CalcTokenConstants.TOKEN_MOVINGMINIMUM,       "token:movingMinimum#class:functionClass#syntax:MovingMinimum#"},
        { CalcTokenConstants.TOKEN_MOVINGTOTAL,         "token:movingTotal#class:functionClass#syntax:MovingTotal#"},
        
        { CalcTokenConstants.TOKEN_DIMENSION,           "token:dimension#"},
        { CalcTokenConstants.TOKEN_MEMBER,              "token:member#underline:true#"},
        { CalcTokenConstants.TOKEN_FUNCTION_NAME,       "token:functionName#underline:true#"},
        { CalcTokenConstants.TOKEN_HIERARCHY_NAME,      "token:hierarchyName#underline:true#"},
        { CalcTokenConstants.TOKEN_LEVEL_NAME,          "token:levelName#underline:true#"},
        { CalcTokenConstants.TOKEN_MEASURE_NAME,        "token:measureName#underline:true#"},
        { CalcTokenConstants.TOKEN_QDR,                 "token:qdr#italic:true#"},
        { CalcTokenConstants.TOKEN_SELECTION_NAME,      "token:selection#underline:true#"},
    };

    public Object [ ] [ ] getContents ( )
    {
        return arTokenAttribute;
    }
}


