/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil;

import oracle.dss.util.BIBaseException;

/**
 * Exceptions thrown by QueryEditor implementations.
 *
 * @status New
 */
public class QueryEditorException extends BIBaseException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status New
     */
    public QueryEditorException(String s, Throwable e) {
        super(s, e);
    }    
}