/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/comboBox/impl/DimensionMemberComboModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     03/15/07 - 
    jhyman      01/24/06 - fix packaging 
    jhyman      01/20/06 - Update for changes to TreeListComboModel 
    jramanat    09/28/05 - Creation
 */

package oracle.dss.datautil.gui.component.comboBox.impl;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.ListModel;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

import oracle.dss.datautil.gui.component.ComponentContext;

import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MetadataManagerException;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.gui.component.DimensionMemberComponentNode;
import oracle.dss.util.gui.component.comboBox.DefaultTreeListComboModel;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/comboBox/impl/DimensionMemberComboModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */
public class DimensionMemberComboModelImpl extends DefaultTreeListComboModel {
  private ComponentContext m_context;
  private String m_dimension;
  private String m_hierarchy;
  private TreeModel m_treeModel;

  public DimensionMemberComboModelImpl(String dimension, String hierarchy, ComponentContext context) {
    m_dimension = dimension;
    m_hierarchy = hierarchy;
    m_context = context;
  }
  
  public TreeModel getTreeModel() {
    if (m_treeModel == null) {
      m_treeModel = new DefaultTreeModel(new DimensionMemberTreeNode(null, null, false));
    }
    return m_treeModel;
  }
  
  public ListModel[] getListModels() {
    return new ListModel[0];
  }
  
  public boolean isMultiSelect() {
      return true;
  }
  
  private class DimensionMemberTreeNode implements TreeNode {
    private DimensionMemberComponentNode m_node;
    private Vector m_children = new Vector();
    private boolean m_leaf = false;
    private boolean m_drilled = false;
    private DimensionMemberTreeNode m_parent;
    
    
    public DimensionMemberTreeNode(DimensionMemberComponentNode node, DimensionMemberTreeNode parent, boolean isLeaf) {
      m_node = node;
      m_leaf = isLeaf;
      m_parent = parent;
    }
    
    public boolean getAllowsChildren() {
      return isLeaf();
    }
    
    public Enumeration children() {
      if (!isLeaf() && !m_drilled) {
          // blm - Selection code moved to dvt-olap
/*        drill();*/
      }
      return m_children.elements();
    }
    
    public TreeNode getChildAt(int childIndex) {
      if (!isLeaf() && !m_drilled) {
          // blm - Selection code moved to dvt-olap
/*        drill();*/
      }
      return (DimensionMemberTreeNode)m_children.elementAt(childIndex);
    }
    
    public int getChildCount() {
      if (!isLeaf() && !m_drilled) {
          // blm - Selection code moved to dvt-olap
/*        drill();*/
      }
      return m_children.size();
    }
    
    public int getIndex(TreeNode node) {
      if (!isLeaf() && !m_drilled) {
          // blm - Selection code moved to dvt-olap
/*        drill();*/
      }
      return m_children.indexOf(node);
    }
    
    public TreeNode getParent() {
      return m_parent;
    }
    
    public boolean isLeaf() {
      return m_leaf;
    }
    
      // blm - Selection code moved to dvt-olap
/*    private void drill() {
      Selection selection = new Selection(m_dimension);
      selection.setHierarchy(m_hierarchy);
      if (m_node == null) {
        Step step = null;
        if (m_hierarchy == null) {
          step = new AllStep(m_dimension, m_hierarchy, null);
        }
        else {
          try {
            MDHierarchy hierarchy = m_context.getBIProvider().getMetadataManager().getHierarchyByUniqueID(m_hierarchy);
            MDLevel[] levels = hierarchy.getLevels();
            if (levels == null || levels.length == 0) {
              step = new FamilyStep(m_dimension, m_hierarchy, FamilyStep.OP_FIRSTANCESTORS, null, null, false);
            }
            else {
              Vector level = new Vector();
              level.add(levels[0].getUniqueID());
              step = new AllStep(m_dimension, m_hierarchy, level);
            }
          }
          catch (MetadataManagerException mme) {
            m_context.getErrorHandler().error(mme, getClass().getName(), "drill");
          }
        }
        selection.addStep(step);
      }
      else {
        // Get children of current node
        Vector member = new Vector();
        member.add(m_node.getID());
        Vector level = new Vector();
        level.add(m_node.getLevelName());
        FamilyStep fs = new FamilyStep(m_dimension, m_hierarchy, FamilyStep.OP_CHILDREN, member, level, false);
        selection.addStep(fs);
      }
      try {
        DataAccess da = m_context.getDataProvider().getDataAccess(selection);
        int[] hPos = new int[0];
        int memberCount = da.getMemberSiblingCount(0, hPos, 0);
        for (int i = 0; i < memberCount; i++) {
          String memberID = makeString(da.getMemberMetadata(0, hPos, 0, i, MetadataMap.METADATA_VALUE));
          String memberLabel = makeString(da.getMemberMetadata(0, hPos, 0, i, m_context.getDisplayMemberLabelType()));
          String levelID = makeString(da.getMemberMetadata(0, hPos, 0, i, MetadataMap.METADATA_LEVEL));
          String levelName = makeString(da.getMemberMetadata(0, hPos, 0, i, MetadataMap.METADATA_LEVEL_NAME));
          Integer drillState = (Integer)da.getMemberMetadata(0, hPos, 0, i, MetadataMap.METADATA_DRILLSTATE);
          DimensionMemberComponentNode child = new DimensionMemberComponentNode(m_dimension, m_hierarchy, memberID, memberLabel, levelID, levelName);
          boolean leaf = drillState != null && drillState.intValue() != DataDirector.DRILLSTATE_NOT_DRILLABLE;
          m_children.add(new DimensionMemberTreeNode(child, this, leaf));
        }
      }
      catch (Exception e) {
        m_context.getErrorHandler().error(e, getClass().getName(), "drill");
      }
    }    */
  }
  
      // blm - Selection code moved to dvt-olap
/*  private static String makeString(Object value) {
    return value == null ? null : value.toString();
  }*/
}