/*
 * TabbedPanelComponent.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Image;
import java.awt.Component;

import javax.swing.ImageIcon;

/**
 * @hidden
 * The TabbedPanelComponent interface defines methods which need to be
 * implemented by all the components that are part of the QueryBuilder
 * or CalcBuilder.
 *
 * @status hidden
 */
public interface TabbedPanelComponent
{
    /**
     * @hidden
     * Gets the component for the QueryPanel.
     *
     * @return Component for the QueryPanel.
     *
     * @status hidden
     */
    public Component getComponent ( );
	
    /**
     * @hidden
     * Gets the image icon for the QueryComponent.
     *
     * @return icon to be displayed for this QueryPanel.
     *
     * @status hidden
     */
    public ImageIcon getImageIcon ( );
      
    /**
     * @hidden
     * Gets the image for the QueryPanel. Typically 
     * placed on the left side of a panel within a wizard.
     *
     * @return image to be displayed for this QueryPanel.
     *
     * @status hidden
     */
    public Image getImage ( );

    /**
     * @hidden
     * Gets the QueryPanel title.
     *
     * @return the QueryPanel title.
     *
     * @status hidden
     */
    public String getTitle ( );
    
    /**
     * @hidden
     * Sets the component to be active/inactive.
     *
     * @param bIsActive Flag determining whether the component will 
     * be set to active.
     *
     * @return <code>true<\code> if the operation was successful, 
     *         <code>false<\code> otherwise. 
     *
     * @status hidden
     */
    public boolean setActive ( boolean bIsActive );
    
    /**
    * @hidden
     * Validate the content of the pane.
     *
     * @return <code>true<\code> if the operation was successful, 
     *         <code>false<\code> otherwise. 
     *
     * @status hidden
     */
    public boolean validateContents ( Object hintValidate );
}