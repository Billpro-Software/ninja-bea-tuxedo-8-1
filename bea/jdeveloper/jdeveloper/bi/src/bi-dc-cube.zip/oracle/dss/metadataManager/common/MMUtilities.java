/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 */
public class MMUtilities {
	
    /**
     * Returns the index of the given <code>MDObject</code> object in the 
     * given <code>MDObject</code> object array
     *
     * @param  objects      An array of <code>MDObject</code> objects.
     * @param  object      	The <code>MDObject</code> object.
     *
     * @return the index of the <code>MDObject</code>.
     *
     * @status New
     */
  	public static int _indexOf(MDObject[] objects, MDObject object) {
  		if ( (objects != null) && (object != null) ) {
  			for (int i=0; i<objects.length; i++) {
  				if (objects[i].getUniqueID().equals(object.getUniqueID())) {
  					return i;
  				}
  			}
  		}
  		return -1;
  	}
  	
    /**
     * Returns the index of the given <code>MDObject</code> object in the 
     * given <code>MDObject</code> object array
     *
     * @param  objects      An array of <code>MDObject</code> objects.
     * @param  object      	The <code>MDObject</code> object.
     *
     * @return the index of the <code>MDObject</code>.
     *
     * @status New
     */
  	public static int _indexOfByName(MDObject[] objects, MDObject object) {
  		if ( (objects != null) && (object != null) ) {
  			for (int i=0; i<objects.length; i++) {
  				if (objects[i].nameEquals(object)) {
  					return i;
  				}
  			}
  		}
  		return -1;
  	}
  	
    /**
     * Returns whether the given <code>MDObject</code> object is in the 
     * given <code>MDObject</code> object array
     *
     * @param  objects      An array of <code>MDObject</code> objects.
     * @param  object      	The <code>MDObject</code> object.
     *
     * @return Whether or not the <code>MDObject</code> object is found.
     *
     * @status New
     */
  	public static boolean _contains(MDObject[] objects, MDObject object) {
  		return (_indexOf(objects, object) != -1);
  	}
  	
    /**
     * Returns the ID from the given unique ID.
     *
     * @param  strID      	The unique ID.
     *
     * @return The ID.
     *
     * @status New
     */
    public static String _extractID(String strUniqueID) {
        if (strUniqueID != null) {
            int intIndex = strUniqueID.indexOf("!");
            if (intIndex != -1) {
               return strUniqueID.substring(intIndex+1);
            }
        }  
	    return strUniqueID;
    }
 
        
  	/**
     * Returns the String representing the driver type for the given unique ID.
     * For example, if the given unique ID were "MDM!D_PRODUCT", the returned driver
     * type would be MM.MDM.
   	 *
   	 * @return A string representing the driver type.
     * The valid strings are:
     * <ul>
     * <li><code>MDM</code></li>
     * <li><code>PERSISTENCE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataManager.common.MM#MDM
     * @see oracle.dss.metadataManager.common.MM#PERSISTENCE
   	 *
   	 * @status New
   	 */
    public static String _getDriverType(String strUniqueID) {
    	if (strUniqueID != null) {
			int intIndex = strUniqueID.indexOf("!");
			if (intIndex != -1) {
				return strUniqueID.substring(0, intIndex);
			}
    	}
		return null;
    }
    
  	/**
     * Returns the String representing the unique String for the driver type for the given unique ID.
     * For example, if the given unique ID were "MDM!D_PRODUCT", the returned unique String would
     * be MM.OLAPI_METADATA_ID.
   	 *
   	 * @return A string representing the unique String for the driver type.
     * The valid strings are:
     * <ul>
     * <li><code>OLAPI_METADATA_ID</code></li>
     * <li><code>PATH</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataManager.common.MM#OLAPI_METADATA_ID
     * @see oracle.dss.metadataManager.common.MM#PATH
   	 *
   	 * @status New
   	 */
    public static String _getUniqueDriverConstant(String strUniqueID) {
    	if (strUniqueID != null) {
    		String strDriverType = _getDriverType(strUniqueID);
    		if (strDriverType != null) {
	    		if (strDriverType.equals(MM.MDM)) {
	    			return MM.OLAPI_METADATA_ID;
	    		}
	    		else if (strDriverType.equals(MM.PERSISTENCE)) {
	    			return MM.PATH;	
	    		}
    		}
    	}
    	return MM.OLAPI_METADATA_ID;
    }
    
    /**
     * Constructs an unique ID given the driver type and the ID.
     *
     * @param  strDriverType      	The driver type.
     * @param  strID      			The ID.
     *
     * @return The unique ID.
     *
     * @status New
     */
    public static String _makeUniqueID(String strDriverType, String strID) {
   		if ( (strDriverType != null) && (strID != null) ) {
            return new StringBuffer(50).append(strDriverType).append("!").append(strID).toString();
   		}
        return null;
    }

    /**
     * @hidden
     * Constructs a path using a parent object and a name.
     *
     * @param  parent             	The parent object
     * @param  name      			The name
     *
     * @return The path composed of the parent's path and the name.
     *
     */
    public static String composePath(MDObject parent, String name)
    {
        if (parent != null && name != null)
        {
            String _parentPath = parent.getPath();
            if (_parentPath == null || _parentPath.equals(""))
                return name;
            else
                return new StringBuffer(50).append(_parentPath).append("/").append(name).toString();
        }
        else
            return null;
    }

    /**
     * @hidden
     * Checks whether the MDObject is MDM type
     *
     * @param  mdObject The MDObject to check
     * @return <code>true</code> if the MDObject is for MDM
     *
     */
    public static boolean isMDM(MDObject mdObject)
    {
        return isDriverType(mdObject, MDU.MDM);
    }

    /**
     * @hidden
     * Checks whether the MDObject is Persistence type
     *
     * @param  mdObject The MDObject to check
     * @return <code>true</code> if the MDObject is for Persistence
     *
     */
    public static boolean isPersistence(MDObject mdObject)
    {
        return isDriverType(mdObject, MDU.PERSISTENCE);
    }

    /**
     * @hidden
     * Checks whether the MDObject is Discoverer type
     *
     * @param  mdObject The MDObject to check
     * @return <code>true</code> if the MDObject is for Discoverer
     *
     */
    public static boolean isDiscoverer(MDObject mdObject)
    {
        return isDriverType(mdObject, MDU.DISCOVERER);
    }

    /**
     * @hidden
     * Checks whether the MDObject is Discoverer type
     *
     * @param  mdObject The MDObject to check
     * @return <code>true</code> if the MDObject is for Discoverer
     *
     */
    public static boolean isSiebel(MDObject mdObject)
    {
        return isDriverType(mdObject, MDU.SBA);
    }

    /**
     * @hidden
     * Checks whether the MDObject is of the specified type
     *
     * @param  driverType The String represeting the driver type to check
     * @param  mdObject The MDObject to check
     * @return <code>true</code> if the mdObject is of type driverType
     *
     */
    private static boolean isDriverType(MDObject mdObject, String driverType)
    {
        Vector _v = mdObject.getDriverTypes();
        if (_v != null)
        {
            for (int i=0; i<_v.size(); i++)
            {
                if (_v.elementAt(i).equals(driverType))
                    return true;
            }
        }
        return false;
    }

    /**
     * @hidden
     */
    public static PropertyBag attributesToPropertyBag(Attributes attrs)
    {
        PropertyBag _bag = new PropertyBag();
        if (attrs != null)
        {
            try
            {
                NamingEnumeration _enum = attrs.getIDs();
                while (_enum.hasMoreElements())
                {
                    String _key = (String)_enum.nextElement();
                    Object _value = attrs.get(_key).get();
                    if (_value != null)
                    {
                        if (_value instanceof String)
                            _bag.setStrPropertyValue(_key, (String)_value, MDU.UI_ALL);
                        else
                            _bag.setObjPropertyValue(_key, _value, MDU.UI_ALL);
                    }
                }
            }
            catch (NamingException ne){
                // ignore.  Should not happen
            }
        }
        return _bag;
    }

    /**
     * @hidden
     */
    public static Attributes propertyBagToAttributes(PropertyBag properties)
    {
        if (properties != null)
        {
            BasicAttributes _attrs = new BasicAttributes();

            Property[] _props = properties.getProperties();
            if (_props != null)
            {
                for (int i=0; i<_props.length; i++)
                {
                    String _name = _props[i].getName();
                    Object _val = _props[i].getObjValue();

                    // handles exception cases
                    if(_name.equals(MDU.OBJECT_TYPE) && _val != null && _val.toString().equals(MM.MEASURE))
                        _val = PersistableConstants.CALCULATION;

                    _attrs.put(_name, _val);
                }
            }
            
            return _attrs;
        }
        else
            return null;
    }

    public static String _escapeChar(String id, char[] chars) {
        boolean isEscape = false;
        for(int i = 0; chars != null && i < chars.length; i++) {
            if(id.indexOf(chars[i]) != -1) {
                isEscape = true;
                break;
            }
        }
        if(isEscape) {
            StringBuffer buf = new StringBuffer();
            StringTokenizer tokens = new StringTokenizer(id, ".");
            while(tokens.hasMoreTokens()) {
                String str = tokens.nextToken();
                isEscape = false;
                for(int i = 0; chars != null && i < chars.length; i++) {
                    if(str.indexOf(chars[i]) != -1) {
                        isEscape = true;
                        break;
                    }
                }
                if(isEscape) {
                    buf.append("\"");
                    buf.append(str);
                    buf.append("\"");
                }
                else
                    buf.append(str);
                buf.append('.');
            }
            id = buf.substring(0, buf.length()-1);  // drop the last '.'
        }
        return id;
    }

    /**
     * @hidden
     * Merge all valid Persistable attributes with the attributes specified
     * Useful for user who wants to get all attributes plus Privilege
     * 
     * @param attrs Attributes to merge in
     */
/*    public static String[] getAllReturningAttributes(String[] attrs)
    {
        Vector _attrs = new Vector(20, 10);

        // add all Persistence attributes
        _attrs.add(PSRConstants.Attributes.APPLICATION);
        _attrs.add(PSRConstants.Attributes.APPSUBTYPE1);
        _attrs.add(PSRConstants.Attributes.COMPSUBTYPE1);
        _attrs.add(PSRConstants.Attributes.COMPSUBTYPE2);
        _attrs.add(PSRConstants.Attributes.COMPSUBTYPE3);
        _attrs.add(PSRConstants.Attributes.CREATED_BY);
        _attrs.add(PSRConstants.Attributes.DATABASE);
        _attrs.add(PSRConstants.Attributes.DESCRIPTION);
        _attrs.add(PSRConstants.Attributes.KEYWORDS);
        _attrs.add(PSRConstants.Attributes.MODIFIED_BY);
        _attrs.add(PSRConstants.Attributes.OBJECT_FULLPATH_NAME);
        _attrs.add(PSRConstants.Attributes.OBJECT_LABEL);
        _attrs.add(PSRConstants.Attributes.OBJECT_NAME);
        _attrs.add(PSRConstants.Attributes.OBJECT_TYPE);
        _attrs.add(PSRConstants.Attributes.TIME_DATE_CREATED);
        _attrs.add(PSRConstants.Attributes.TIME_DATE_LAST_ACCESSED);
        _attrs.add(PSRConstants.Attributes.TIME_DATE_MODIFIED);
        _attrs.add(PSRConstants.Attributes.TITLE);
        _attrs.add(PSRConstants.Attributes.USER_VISIBLE);
        _attrs.add(PSRConstants.Attributes.VERSION);

        // and the unique ID as well
        _attrs.add(MM.UNIQUE_ID);
        
        // now add the ones user specified
        for (int i=0; attrs != null && i<attrs.length; i++)
            _attrs.add(attrs[i]);

        String[] _retAttrs = new String[_attrs.size()];
        _attrs.copyInto(_retAttrs);

        return _retAttrs;
    }*/
}
