/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.io.OutputStream;
import java.io.PrintWriter;

import java.text.DateFormat;
import java.util.Date;
import java.util.Stack;

/**
 *  @hidden
 *
 *	Support for timer profiling.
 *
 *  This class allows the user to create timers for nested tasks.
 */
public class StackTimer extends Object {
  // Setting ON to false turns off all timing.
  // This should be the default for release code!
  // Setting ON to true turns on timing.  
  public final static boolean ON = false;
  public final static int INDENT_SPACES = 2;    // Spaces/indent level
 
  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  static private StackTimer m_timer = null;     // Singleton StackTimer object

  private int m_nIndentSpaces = INDENT_SPACES;  // Number spaces per indent  
  private Stack m_taskStack;
  private PrintWriter m_out;
   
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor
   * 
   * Can call this to get a new StackTimer or just call 
   * StackTimer.getTimer() to get the singleton object.
   */
  public StackTimer () {
    m_taskStack = new Stack();
    m_out = new PrintWriter(System.out, true);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Gets the singleton StackTimer object
   * 
   * @returns the StackTimer
   */
  static public StackTimer getTimer() {
    if (m_timer == null) {
      m_timer = new StackTimer();
    }
	  return m_timer;
  }

  /**
   * Sets OutputStream for the StackTimer (e.g. setOutputStream(new FileOutputStream(<filename>)))
   * Default OutputStream is System.out
   * 
   * @param the OutputStream
   */
  public void setOutputStream(OutputStream stream) {
    m_out = new PrintWriter(stream, true);
  }

  /**
   * <pre>
   * getIndentSpaces 
   *   Gets number of spaces per indent.<br>
   *
   * Example:
   *   int nIndentSpaces = getIndentSpaces();
   * </pre>
   *
   * @return <code>int</code> which represents the number of spaces per indent. 
   */
  public int getIndentSpaces() {
    return m_nIndentSpaces;     
  }

  /**
   * <pre>
   * setIndentSpaces 
   *   Sets the number of spaces per indent.<br>
   *
   * Example:
   *   setIndentSpaces (5);
   * </pre>
   *
   * @param nIndentSpaces a <code>int</code> which represents the number of spaces 
   *        per indent. 
   */
  public void setIndentSpaces (int nIndentSpaces) {
    m_nIndentSpaces = nIndentSpaces;    
  }

  /**
   * Starts the timer for a particular task
   * 
   * @param the ID for the task
   */
  public void start(String id) {
    TimedTask task = new TimedTask(id, new Date());
    m_out.println(getIndent() + "Start ID:" + task.taskID);
    m_taskStack.push(task);
	}

  /**
   * Stops the timer for a particular task.  Note that you can only
   * stop the most recently started task.  The id passed in here must
   * match the ID on the top of the stack to insure meaningful timing
   * results.
   * 
   * @param the ID for the task
   */
  public void stop(String id) {
    if (m_taskStack.size() == 0) {
      m_out.println(getIndent() + "Error: Can't stop task '" + id + "'.  No tasks are running");
    }
    else {      
      String currentID = ((TimedTask)m_taskStack.peek()).taskID;
      if (!id.equals(currentID)) {
        m_out.println(getIndent() + "Error: Can't stop task '" + id + "'.  Task '" + currentID + "' must be stopped first.");
      }
      else {        
        TimedTask task = (TimedTask)m_taskStack.pop();
        Date end = new Date();
        long time = end.getTime() - task.start.getTime();
        m_out.println(getIndent() + "Stop Time:" + time + "ms");
      }
    }
  }

  private String formatDate(Date date) {
    return DateFormat.getDateTimeInstance().format(date);
  }

  private String getIndent() {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < (getIndentSpaces() * m_taskStack.size()); i++) {
      sb.append(" ");
    }
    return sb.toString();
  }

  private class TimedTask {
    String taskID;
    Date start;

    TimedTask(String id, Date s) {
      taskID = id;
      start = s;
    }
  }
}