/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/ShuttleListener.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui;

import java.util.EventListener;

/**
 *
 * <pre>
 * Process <code>Shuttle</code> listener events.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/06/07 - Fix Bug 6656686 - Double click on items in the QB
 *                         should shuttle them over to the select.
 */
public interface ShuttleListener extends EventListener {

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Process Shuttle items selected <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing that items 
   *        were selected.
   * 
   * @status new
   */
  public void shuttleItemsSelected (ShuttleEvent shuttleEvent);

  /**
   * Process Shuttle items shuttled <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing that items 
   *        were shuttled.
   * 
   * @status new
   */
  public void shuttleItemsShuttled (ShuttleEvent shuttleEvent);

  /**
   * Process Shuttle items double clicked <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing that items 
   *        were double clicked.
   * 
   * @status new
   */
  public void shuttleItemsDoubleClicked (ShuttleEvent shuttleEvent);
  
}
