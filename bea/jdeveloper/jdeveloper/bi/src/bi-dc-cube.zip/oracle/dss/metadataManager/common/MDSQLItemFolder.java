/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

public class MDSQLItemFolder extends MDItemFolder
{
    public MDSQLItemFolder()
    {
        setObjectType(MM.SQL_ITEMFOLDER);
    }
}
