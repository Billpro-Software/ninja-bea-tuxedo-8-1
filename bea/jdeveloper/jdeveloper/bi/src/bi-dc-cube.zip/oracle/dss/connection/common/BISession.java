/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

import java.applet.Applet;

import java.util.Locale;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.Context;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLElement;

import oracle.dss.bicontext.ManagerFactory;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;


//import oracle.dss.security.BISecurityConstants;
//import oracle.dss.security.BIUser;
//import oracle.dss.security.ConfigEntry;

import org.w3c.dom.Element;
import oracle.dss.util.xml.XMLObjectReader;

/**
 * The <code>BISession</code> bean class.
 * Every BI Beans program must instantiate a <code>BISession</code>.
 * The <code>BISession</code> creates an application module and connects to
 * it.
 * <P>
 * The <code>BISession</code> also keeps track of user information.
 * The <code>BISession</code> can read an XML configuration file that contains
 * information such as deployment information and user information.
 * <P>
 * To use the <code>BISession</code>, you instantiate the <code>BISession</code>
 * and call its <code>connect</code> method.
 * <P>
 * As a Java bean, <code>BISession</code> exposes its properties so that
 * you can see and set them in a Java Development Environment.
 *
 * @status reviewed
 */
public class BISession implements ErrorHandlerCallback
{
   /**
    * @hidden
    * Deployment option: Run the application module and BI Beans application
    * or applet in the same JVM.
    * When you set this deployment option, you do not have to call any other
    * methods before you call <code>connect</code>.
    *
    * @see #setDeploymentOption
    * @see #connect
    *
    * @status reviewed
    */
    //public static final String LOCAL = JboContext.PLATFORM_LOCAL;

   /**
    * @hidden
    * Deployment option: Run the application module as an Enterprise
    * Java Bean in Oracle8i.
    * <P>
    * When you set this deployment option, you must call the following
    * methods before you call the <code>connect</code> method:
    * <P><ul>
    * <li>{@link #setHostName}</li>
    * <li>{@link #setUserName}</li>
    * <li>{@link #setPassword}</li>
    * <li>{@link #setApplicationPath}</li>
    * <li>{@link #setTNSListenerPort} (optional; there is a default)</li>
    * <li>{@link #setOracleSid}</li>
    * </ul><P>
    * In addition, it is a good idea to call {@link #setSessionName}, so
    * that you can have multiple sessions.
    * It is also a good idea to call {@link #setTimeOut} so that the
    * application module can be removed when no one is using it.
    *
    * @see #setDeploymentOption
    * @see #connect
    *
    * @status hidden not supported in this release
    */
    //public static final String EJB = JboContext.PLATFORM_EJB_IAS;

   /**
    * @hidden
    * VisiBroker connection mode: Use the CosNaming service to connect to the
    * VisiBroker server.
    * For more information about the CosNaming service, see the documentation
    * for VisiBroker.
    *
    * @see #setVBConnectionMode
    *
    * @status reviewed
    */
    public static final String COSNAMING = "REMOTE";

   /**
    * @hidden
    * VisiBroker connection mode: Use the BIND mechanism to connect to the
    * VisiBroker server.
    * For more information about the BIND mechanism, see the documentation
    * for VisiBroker.
    *
    * @see #setVBConnectionMode
    *
    * @status reviewed
    */
    public static final String BIND = "BIND";

   /**
    * @hidden
    * VisiBroker connection mode: Connect to the VisiBroker server so that
    * the client and the server are in the same JVM, but they communicate
    * as if they were in different JVMs.
    * <P>
    * This differs from Local mode in that communication goes through
    * the stubs and skeletons of remote communication.
    * This option is good for testing and debugging.
    *
    * @see #setVBConnectionMode
    *
    * @status reviewed
    */
    public static final String COLOCATE = "COLOCATE";

   /**
    * @hidden
    * The name of the default application module.
    */
    private static final String DEFAULT_AM_NAME = "oracle.dss.appmodule.DSSAppModule";
    private static final String MANAGER_FACTORY_IMPL = "oracle.dss.datautil.client.ManagerFactoryImpl";

    // default pluggable drivers
    private static final String DEF_SESSION_AUTH_DRV = "oracle.dss.appmodule.server.DSSApplicationModuleAuthenticationDriver";
    private static final String DEF_SESSION_UC_DRV = "oracle.dss.persistence.storagemanager.bi.mapping.ReposUserCommunity";
    private static final String DEF_OLAP_AUTH_DRV = "oracle.dss.security.MDMAuthenticationDriver";
    private static final String DEF_OLAP_CONN_DRV = "oracle.dss.connection.server.drivers.mdm.MDMPluggableConnectionDriverImpl";
    private static final String DEF_PER_AUTH_DRV = "oracle.dss.security.ReposAuthenticationDriver";
    private static final String DEF_PER_CONN_DRV = "oracle.dss.persistence.storagemanager.bi.mapping.ReposConnectionDriver";
    private static final String DEF_DISCO_AUTH_DRV = "oracle.dss.security.DiscovererAuthenticationDriver";
    private static final String DEF_DISCO_CONN_DRV = "oracle.dss.persistence.storagemanager.bi.discomapping.DiscovererConnectionDriver";

    //private ApplicationModuleHome m_home;
    private Hashtable m_env;
    private String m_amName = DEFAULT_AM_NAME;
    private ErrorHandler m_eh;
    private Locale m_locale;
    private XMLElement m_root;
    private String m_config;
    private ManagerFactory m_factory;
    private Class m_loader;
    private Vector m_entries;
    private String m_appName;
    private Hashtable m_connectProps;

    // this is used by the entire BIBeans system
    private DOMParser m_parser;

   /**
    * Constructor.
    * Call the <code>setConfigFileName</code> to specify a configuration
    * file.
    *
    * @see #setConfigFileName
    * @see #connect
    *
    * @status reviewed
    */
    public BISession()
    {
        m_env = new Hashtable(10, 10);
        m_connectProps = new Hashtable(10);
        m_env.put(Context.INITIAL_CONTEXT_FACTORY, "oracle.jbo.common.JboInitialContextFactory");
    }

   /**
    * Constructor that specifies the name of the configuration file.
    * <P>
    * The configuration file can be used to specify the following information:
    * <P>
    * <ul>
    * <li><code>BIUser</code> -- The application user for the session.</li>
    * <li>Security configurations -- The security configuration such as the
    *         <code>ConnectionProvider</code> to use.</li>
    * <li><code>PersistenceManager</code> -- This <code>BISession</code> can
    *         create an <code>InitialPersistenceManager</code>,
    *         based on the information specified in the
    *         configuration file.</li>
    * <li>Connection -- This <code>BISession</code> can
    *         create <code>Connection</code>, based
    *         on the information specified by the configuration file.</li>
    * <li>MetadataManager -- This <code>BISession</code> can
    *         create <code>MetadataManager</code> objects, based
    *         on the information specified by the configuration file.</li>
    * </ul>
    *
    * @param configXML The configuration file that contains information for
    *          this <code>BISession</code> to use.
    *
    * @see #connect
    *
    * @status reviewed
    */
    public BISession(String configXML)
    {
        this();
        m_config = configXML;
    }

   /**
    * Constructor that specifies the name of the configuration file a class
    * loader to load the configuration file.
    * <P>
    * The configuration file can be used to specify the following information:
    * <P>
    * <ul>
    * <li><code>BIUser</code> -- The application user for the session.</li>
    * <li>Security configurations -- The security configuration such as the
    *         <code>ConnectionProvider</code> to use.</li>
    * <li><code>PersistenceManager</code> -- This <code>BISession</code> can
    *         create an <code>InitialPersistenceManager</code>,
    *         based on the information specified in the
    *         configuration file.</li>
    * <li>Connection -- This <code>BISession</code> can
    *         create <code>Connection</code>, based
    *         on the information specified by the configuration file.</li>
    * <li>MetadataManager -- This <code>BISession</code> can
    *         create <code>MetadataManager</code> objects, based
    *         on the information specified by the configuration file.</li>
    * </ul>
    *
    * @param configXML The configuration file that contains information for
    *          this <code>BISession</code> to use.
    * @param configLoader The class in which its class loader is used to load
    *                     the configuration file.  If you pass <code>null</code>,
    *                     then the default
    *                     class loader is used to load the configuration file.
    *
    * @see #connect
    *
    * @status reviewed
    */
    public BISession(String configXML, Class configLoader)
    {
        this();
        m_config = configXML;
        m_loader = configLoader;
    }


   /**
    * Creates an application module and connects to it.
    *
    * @see #BISession(String)
    *
    * @throws BISessionException If one of the following occurs:
    * <ul>
    *   <li>The configuration file cannot be found or open</li>
    *   <li>An error occurs in parsing the configuration file</li>
    *   <li>An error occurs while locating the ApplicationModuleHome</li>
    * </ul>
    * @status reviewed
    */
/*    public void connect() throws BISessionException
    {
    
        try
        {
            // check whether it is already connected
            if (m_home != null)
                return;

            if (m_config != null && m_root == null)
            {
                m_root = parseManagerConfigFile(m_config);
                NodeList _list = m_root.getChildrenByTagName("BISession");
                if (_list.getLength() > 0)
                {
                    Hashtable _env = parseBISessionElement((XMLElement)_list.item(0));
                    mergeEnvironments(_env);
                }
            }

            if (m_entries != null && m_entries.size() > 0)
            {
                fillRemainEntries(m_entries);
                m_env.put(BISecurityConstants.CONFIG_ENTRIES, m_entries);
            }

            if (getDeploymentOption() == null)
                setDeploymentOption(LOCAL);
            else if (!(getDeploymentOption().equals(LOCAL)))
                throw new UnsupportedOperationException();

            Context _ic = new InitialContext(m_env);
            //m_home = (ApplicationModuleHome) _ic.lookup(m_amName);
        }
        catch (BISessionException bise)
        {
            // set dom node back to null to allow user to
            // modify the XML file without the need to restart
            // the application
            m_root = null;
            throw bise;
        }
        catch (SAXException saxe)
        {
            throw new BISessionException(AppModuleBundle.EXC_XML_PARSE, null, getLocale(), saxe);
        }
        catch (IOException ioe)
        {
            throw new BISessionException(AppModuleBundle.EXC_XML_PARSE, null, getLocale(), ioe);
        }
        catch (Exception e)
        {
            throw new BISessionException(AppModuleBundle.EXC_APPMODULE_CREATE, null, getLocale(), e);
        }
        
    }*/

    /**
     * Disconnects the application module.
     * This method removes the application module, releases all manager objects
     * that the <code>ManagerFactory</code> maintains, and releases all other resources
     * that this session holds.
     *
     * @throws BISessionException If an error occurs while releasing the manager objects held
     *         by the <code>ManagerFactory</code>.
     * @status reviewed
     */
/*    public void disconnect() throws BISessionException
    {
        try
        {
//            if (m_am != null)
                //m_am.remove();

            if (m_factory != null)
            {
                m_factory.cleanup();
                m_factory = null;
            }

            //m_am = null;
            //m_home = null;

            if (m_entries != null)
                m_entries.removeAllElements();
            m_entries = null;

            m_root = null;
            m_parser = null;
        }
        catch (Exception e)
        {
            throw new BISessionException(AppModuleBundle.EXC_APPMODULE_DISCONNECT, new Object[]{e.getLocalizedMessage()}, getLocale(), e);
        }
    }*/

    /**
     * Adds a single error handler to this <code>BISession</code>.
     * The error handler is called whenever this <code>BISession</code> traps an
     * error from another part of the system.
     * <P>
     * This error handler is also used by other beans in this
     * <code>BISession</code>.
     * <P>
     * Use this method to install your own error handler.
     *
     * @param handler The error handler to use.
     *
     * @status reviewed
     */
    public void addErrorHandler(ErrorHandler handler)
    {
        if (handler != null)
        {
            m_eh = handler;
            m_env.put("error_handler", handler);
        }
    }

    /**
     * Removes a customized error handler for this <code>BISession</code>.
     * This method replaces the current error handler with a default error
     * handler.
     * The default error handler prints information to the console.
     *
     * @status reviewed
     */
    public void removeErrorHandler()
    {
        m_eh = null;
    }

    /**
     * Retrieves the error handler from this <code>BISession</code>.
     * This method is called by other beans, so they can use the same
     * error handler.
     *
     * @return The error handler registered with this <code>BISession</code>.
     *         If no custom error handler has been
     *         registered, then this method returns the default error handler.
     *
     * @status reviewed
     */
    public ErrorHandler getErrorHandler()
    {
        if (m_eh == null)
            m_eh = new DefaultErrorHandler();
        return m_eh;
    }

   /**
    * Retrieves the debug mode that is specified in the configuration file.
    * <p>
    * A <code>BISessionRuntimeException</code> is thrown if an error occurs while
    * parsing the configuration file.
    *
    * @return The debug mode specified in the configuration file.
    *         Returns -1 if the debug mode is not available or if the
    *         configuration file is not specified.
    *
    * @status documented
    */
/*    public int getDebugMode()
    {
        try
        {
            if (m_root == null && m_config != null)
            {
                m_root = parseManagerConfigFile(m_config);
                NodeList _list = m_root.getChildrenByTagName("BISession");
                if (_list.getLength() > 0)
                {
                    Hashtable _env = parseBISessionElement((XMLElement)_list.item(0));
                    mergeEnvironments(_env);

                    if (m_eh != null && m_eh instanceof DefaultErrorHandler)
                        return ((DefaultErrorHandler)m_eh).getDebugMode();
                    else
                        return -1;
                }
            }
            else if (m_root != null)
            {
                // this is when the user is connected already and call getDebugMode again
                if (m_eh != null && m_eh instanceof DefaultErrorHandler)
                    return ((DefaultErrorHandler)m_eh).getDebugMode();
                else
                    return -1;
            }
        }
        catch (BISessionException bise)
        {
            throw new BISessionRuntimeException(AppModuleBundle.EXC_XML_PARSE, null, getLocale(), bise);
        }
        catch (SAXException saxe)
        {
            throw new BISessionRuntimeException(AppModuleBundle.EXC_XML_PARSE, null, getLocale(), saxe);
        }
        catch (IOException ioe)
        {
            throw new BISessionRuntimeException(AppModuleBundle.EXC_XML_PARSE, null, getLocale(), ioe);
        }

        // would come to here if configuration file is not specified
        return -1;
    }*/

   /**
    * Specifies the locale to use by this <code>BISession</code>.
    *
    * @locale the locale to use by this <code>BISession</code>.
    * @status reviewed
    */
    public void setLocale(Locale locale)
    {
        if (locale != null)
        {
            m_locale = locale;
            //if (m_am != null)
                //m_am.getSession().setLocale(locale);
        }
    }

   /**
    * Retrieves the locale used by this <code>BISession</code>.
    * Other beans call this method to use the same locale.
    *
    * @return The locale set on this <code>BISession</code>.
    *
    * @status reviewed
    */
    public Locale getLocale()
    {
        if (m_locale == null)
        {
//            if (m_am != null)
                //return m_am.getSession().getLocale();
            //else
                return Locale.getDefault();
        }
        else
            return m_locale;
    }

    /**
     * Specifies the configuration file that contains
     * information about the properties of this session, the
     * application user, and the security configuration entries.
     * The configuration file can also include information about how this
     * <code>BISession</code> should create
     * <code>Connection</code> objects, <code>MetadataManager</code> objects,
     * and the <code>InitialPersistenceManager</code>.
     *
     * @param configFile The full path name of the configuration file.
     *
     * @see oracle.dss.connection.client.Connection
     * @see oracle.dss.metadataManager.client.MetadataManager
     * @see oracle.dss.persistence.persistencemanager.client.InitialPersistenceManager
     *
     * @status reviewed
     */
    public void setConfigFileName(String configFile)
    {
        if (configFile != null)
            m_config = configFile;
    }

    /**
     * Retrieves the name of the configuration file that contains
     * information about the properties of this session, the
     * application user, and the security configuration entries.
     *
     * @return The full path name of the configuration file.
     *
     * @status reviewed
     */
    public String getConfigFileName()
    {
        return m_config;
    }

    /**
     * Indicates whether a configuration file has been specified.
     *
     * @return  <code>true</code> if a configuration file has been specified,
     *          <code>false</code> if no file has been specified.
     *
     * @status reviewed
     */
    public boolean isConfigFileSpecified()
    {
        if (m_config != null)
            return true;
        else
            return false;
    }
    
    /**
     * @hidden
     */
    public Class getConfigFileLoader()
    {
        return m_loader;
    }

    /**
     * Creates and returns a <code>ManagerFactory</code> that
     * uses information from the configuration file.
     * <p>
     * You can use the <code>ManagerFactory</code> to create the
     * <code>InitialPersistenceManager</code>, the <code>QueryManager</code>,
     * and the <code>MetadataManager</code>.
     *
     * @return A <code>ManagerFactory</code> that uses configuration information.
     *
     * @throws BISessionException If an error occurs in
     *         parsing the configuration file, or if an error occurs in
     *         the creation of the <code>ManagerFactory</code>.
     *
     * @see oracle.dss.persistence.persistencemanager.client.InitialPersistenceManager
     * @see oracle.dss.dataSource.common.QueryManager
     * @see oracle.dss.metadataManager.client.MetadataManager
     *
     * @status reviewed
     */
     public ManagerFactory getManagerFactory() throws ConnectionException
         {
             try
             {
                 if (m_factory != null)
                     return m_factory;

//                     connect();


                 Class _cls = Class.forName("oracle.dss.datautil.client.ManagerFactoryImpl");
                 java.lang.reflect.Constructor _con = _cls.getConstructor(new Class[]{BISession.class, Element.class});
                 m_factory = (ManagerFactory)_con.newInstance(new Object[]{this, m_root});
     /*
                 // Code for Jingwu commented out until needed
                 URL _url = null;
                 String _config = m_config;
                 if (_config.startsWith("/"))
                     _config = _config.substring(1);

                 if (m_loader != null)
                     _url = m_loader.getClassLoader().getResource(_config);
                 else
                     _url = Thread.currentThread().getContextClassLoader().getResource(_config);

                 if (_url != null)
                     m_factory.setConfigFilePath(_url.getFile());
     */
                 return m_factory;
             }
             catch (Exception e)
             {
                 throw new ConnectionException(e.getMessage(), e, null);
             }
         }

    /**
     * Retrieves a <code>ManagerFactory</code> that
     * uses information stored from a JNDI source.
     * <p>
     * You can use the <code>ManagerFactory</code> to create the
     * <code>InitialPersistenceManager</code>, the <code>QueryManager</code>,
     * and the <code>MetadataManager</code>.
     *
     * @return A <code>ManagerFactory</code> that uses JNDI information.
     *
     * @throws BISessionException If an error occurs in
     *         the creation of the <code>ManagerFactory</code>.
     *
     * @see oracle.dss.persistence.persistencemanager.client.InitialPersistenceManager
     * @see oracle.dss.dataSource.common.QueryManager
     * @see oracle.dss.metadataManager.client.MetadataManager
     *
     * @status reviewed
     */
/*    public ManagerFactory getManagerFactory(InitialDirContext initPM) throws BISessionException
    {
        try
        {
            //if (m_am == null)
                connect();

            Class _cls = Class.forName(MANAGER_FACTORY_IMPL);
            java.lang.reflect.Constructor _con = _cls.getConstructor(new Class[]{BISession.class, InitialDirContext.class});
            ManagerFactory _factory = (ManagerFactory)_con.newInstance(new Object[]{this, initPM});

            return _factory;
        }
        catch (Exception ex)
        {
            throw new BISessionException(AppModuleBundle.EXC_MANAGERFACTORY_CREATE, new Object[]{ex.getLocalizedMessage()}, getLocale(), ex);
        }
    }
*/
   /**
    * Specifies a name for this application. The BI Beans Catalog uses
    * this name to provide scoping for
    * application extensible attributes. 
    * If an application creates extensible attributes for an object, then the
    * Catalog associates this name with the newly-created attributes.
    * <p>
    * One application is not allowed to 
    * modify extensible attributes that are owned by another application.
    *
    * @param name The name for this application.
    * 
    * @status Documented
    */
    public void setApplicationName(String name)
    {
        m_appName = name;
    }

    /**
     * @hidden
     */
    public String getApplicationName()
    {
        return m_appName;
    }
    
   /**
    * @hidden
    * Specifies the applet that uses this <code>BISession</code>.
    * If this <code>BISession</code> is instantiated in an applet, then you must
    * pass the <code>Applet</code> in this method.
    * This <code>BISession</code> passes the reference to the ORB.
    * <P>
    * This method is required for applets that use the <code>VB</code>
    * deployment option.
    *
    * @param applet The <code>Applet</code> that instantiates this
    *               <code>BISession</code>.
    * @see #setDeploymentOption
    */
    public void setApplet(Applet applet)
    {
        //if (applet != null)
        //    m_env.put(JboContext.USE_APPLET, applet);
    }

   /**
    * @hidden
    * Indicates whether this <code>BISession</code> is used by an applet or by
    * an application.
    *
    * @return   <code>true</code> if the client is an applet,
    *           <code>false</code> if the client is an application.
    */
    public boolean isApplet()
    {
        //return (m_env.get(JboContext.USE_APPLET) != null);
        return false;
    }

   /**
    * @hidden
    * Retrieves the deployment option.
    * The constant that this method returns identifies whether the application
    * module is local or uses VisiBroker.
    *
    * @return A constant that represents the current deployment option.
    *
    * @see #LOCAL
    */
    public String getDeploymentOption()
    {
        return "";//(String)m_env.get(JboContext.DEPLOY_PLATFORM);
    }

   /**
    * @hidden
    * Specifies how the application module is deployed.
    * The application module can be local or remote, using
    * VisiBroker.
    *
    * @param deploymentOption A constant that identifies how the application
    *        module should be created. Valid constants are listed in the
    *        "See Also" section.
    *
    * @see #LOCAL
    */
    public void setDeploymentOption(String deploymentOption)
    {
        //m_env.put(JboContext.DEPLOY_PLATFORM, deploymentOption);
    }

   /**
    * @hidden
    * Retrieves the definition name of a custom application module.
    * The definition name is the name of the XML file that describes the
    * application module that is created by this <code>BISession</code>.
    * <P>
    * This method is useful only to those who implement their own
    * application module.
    * If you use a default BI Beans application module, you should not
    * call this method.
    *
    * @return The name of the file that defines the application module.
    */
    public String getAppModuleDefName()
    {
        return m_amName;
    }

   /**
    * @hidden
    * Specifies the definition name of a custom application module.
    * The definition name is the name of the XML file that describes the
    * application module that is created by this <code>BISession</code>.
    * <P>
    * This method is useful only to those who implement their own
    * application module.
    * If you use a default BI Beans application module, you should not
    * call this method.
    *
    * @param The name of the XML file that defines the application module.
    */
    public void setAppModuleDefName(String appModuleName)
    {
        if (appModuleName != null)
            m_amName = appModuleName;
    }

   /**
    * @hidden
    * Retrieves the connection mode for connecting to the Visibroker
    * server.
    *
    * @return A constant that represents the way to connect to the
    *               VisiBroker server. Valid constants are listed in the
    *               "See Also" section.
    *
    * @see #COSNAMING
    * @see #BIND
    * @see #COLOCATE
    */
    public String getVBConnectionMode()
    {
        /*
        Integer _vbMode = (Integer)m_env.get(JboContext.CONNECTION_MODE);
        if (_vbMode != null)
        {
            int _vb = _vbMode.intValue();
            if (_vb == ConnectionModeConstants.COLOCATE)
                return COLOCATE;
            else if (_vb == ConnectionModeConstants.REMOTE)
                return COSNAMING;
            else if (_vb == ConnectionModeConstants.USE_BIND)
                return BIND;
            else
                return null;
        }
        else
        */
            return null;
    }

   /**
    * @hidden
    * Specifies how to connect to the VisiBroker server.
    * When the deployment option is <code>VB</code>, you must call this method
    * before calling the <code>connect</code> method.
    *
    * @param option A constant that represents the way to connect to the
    *               VisiBroker server. Valid constants are listed in the
    *               "See Also" section.
    *
    * @see #COSNAMING
    * @see #BIND
    * @see #COLOCATE
    * @see #setDeploymentOption
    * @see #connect
    */
    public void setVBConnectionMode(String option)
    {
    /*
        if (option.equals(BIND))
            m_env.put(JboContext.CONNECTION_MODE, new Integer(ConnectionModeConstants.USE_BIND));
        else if (option.equals(COLOCATE))
            m_env.put(JboContext.CONNECTION_MODE, new Integer(ConnectionModeConstants.COLOCATE));
        else if (option.equals(COSNAMING))
            m_env.put(JboContext.CONNECTION_MODE, new Integer(ConnectionModeConstants.REMOTE));
        else
            m_env.put(JboContext.CONNECTION_MODE, new Integer(ConnectionModeConstants.USE_BIND));
    */
    }

   /**
    * @hidden
    * Retrieves the name of the host where the application server
    * resides.
    * This method is useful only when you use an Oracle8i deployment.
    *
    * @return The name of the host machine.
    */
    public String getHostName()
    {
        return "";//(String)m_env.get(JboContext.HOST_NAME);
    }

   /**
    * @hidden
    * Specifies the name of the host where the application server
    * resides.
    * For all remote connections, this <code>BISession</code> requires the
    * host name before you call its <code>connect</code> method.
    * If the configuration file contains this information, then you do not
    * need to call this method.
    *
    * @param hostName   The name of the host machine, where the application
    *                   server resides.
    *
    * @see #setDeploymentOption
    * @see #connect
    */
    public void setHostName(String hostName)
    {
        //if (hostName != null)
        //    m_env.put(JboContext.HOST_NAME, hostName);
    }

    /**
     * Retrieves the application user for this session.
     *
     * @return The application user for this session.
     *
     * @status reviewed
     */
/*
    public BIUser getBIUser()
    {
        return (BIUser)m_env.get(BISecurityConstants.BIUSER);
    }
*/
    /**
     * Specifies the application user for this session.
     * This user will be authenticated by the application system, and
     * would be used by the beans to identify who the user of the current
     * session is.
     *
     * @param user The <code>BIUser</code> for this session.
     *
     * @status reviewed
     */
/* 
    public void setBIUser(BIUser user)
    {
        if (user != null)
            m_env.put(BISecurityConstants.BIUSER, user);
    }
*/

   /**
    * Specifies the security configuration entries that
    * contain information about the <code>ConnectionProvider</code>,
    * <code>AuthenticationProvider</code>, and <code>UserCommunityProvider</code>
    * to use for the session.
    *
    * This method overrides the settings in the
    * <code>setSecurityConfigFileName</code> method.
    * @deprecated As of 2.7
    *
    * @param entries A list of <code>ConfigEntry</code> objects.
    *
    * @see #setSecurityConfigFileName
    * @see oracle.dss.security.AuthenticationProvider
    * @see oracle.dss.security.ConnectionProvider
    * @see oracle.dss.security.UserCommunityProvider
    *
    * @status reviewed
    */
    public void setSecurityConfigEntries(Vector entries)
    {
        if (entries != null)
            m_entries = entries;
    }

    /**
     * Specifies the name of the security configuration file that
     * contains information about the <code>ConnectionProvider</code>,
     * <code>AuthenticationProvider</code>, and <code>UserCommunityProvider</code>
     * to use for this session.
     * <p>
     * This method overrides the default configuration file (<code>config.xml</code>),
     * which is in the <code>oracle.dss.security</code> package.
     * @deprecated As of 2.7
     *
     * @param fileName  The name of the security configuration file to use.
     *
     * @status documented
     */
    /*
    public void setSecurityConfigFileName(String fileName)
    {
        if (fileName != null)
            m_env.put(BISecurityConstants.CONFIGFILENAME, fileName);
    }
*/

    /**
     * Specifies an authentication provider for this <code>BISession</code>.
     * <p>
     * This method overrides the authentication provider information that is
     * specified in the BI Beans configuration file.
     *
     * @param level  The invocation level in which this authentication provider is applied.
     *               Valid values are listed in the See Also section.
     * @param className The class name of the authentication provider.
     * @param required <code>true</code> if the authentication provider should be loaded,
     *                 <code>false</code> if it should not be loaded.
     *
     * @see oracle.dss.security.AuthenticationProvider
     * @see oracle.dss.security.BISecurityConstants#OLAP
     * @see oracle.dss.security.BISecurityConstants#BICATALOG
     * @see oracle.dss.security.BISecurityConstants#DISCOVERER
     *
     * @status reviewed
     */
    /*
    public void setAuthenticationProvider(String level, String className, boolean required)
    {
        if (validArgs(level, className))
        {
            if (m_entries == null)
                m_entries = new Vector(5, 5);

            String _required = "notrequired";
            if (required)
                _required = "required";

            ConfigEntry _entry = new ConfigEntry(BISecurityConstants.AUTHENTICATION_DRIVER, level, _required, className, null);
            m_entries.addElement(_entry);
        }
    }
*/

    /**
     * Specifies a connection provider for this <code>BISession</code>.
     * <p>
     * This method overrides the connection provider information that is
     * specified in the BI Beans configuration file.
     *
     * @param level  The invocation level in which this connection provider is applied.
     *               Valid values are listed in the See Also section.
     * @param className The class name of the connection provider.
     * @param required <code>true</code> if the connection provider should be loaded,
     *                 <code>false</code> if it should not be loaded.
     *
     * @see oracle.dss.security.ConnectionProvider
     * @see oracle.dss.security.BISecurityConstants#OLAP
     * @see oracle.dss.security.BISecurityConstants#BICATALOG
     * @see oracle.dss.security.BISecurityConstants#DISCOVERER
     *
     * @status reviewed
     */
    /*
    public void setConnectionProvider(String level, String className, boolean required)
    {
        if (validArgs(level, className))
        {
            if (m_entries == null)
                m_entries = new Vector(5, 5);

            String _required = "notrequired";
            if (required)
                _required = "required";

            ConfigEntry _entry = new ConfigEntry(BISecurityConstants.CONNECTION_DRIVER, level, _required, className, null);
            m_entries.addElement(_entry);
        }
    }
*/
    /**
     * Specifies a user community provider for this <code>BISession</code>.
     * <p>
     * This method overrides the user community provider information that is
     * specified in the BI Beans configuration file.
     *
     * @param level  The invocation level in which this user community provider is applied.
     *               The valid value is listed in the See Also section.
     * @param className The class name of the user community provider.
     * @param required <code>true</code> if the user community provider should be loaded,
     *                 <code>false</code> if it should not be loaded.
     *
     * @see oracle.dss.security.UserCommunityProvider
     * @see oracle.dss.security.BISecurityConstants#SESSION
     *
     * @status reviewed
     */
    /*
    public void setUserCommunityProvider(String level, String className, boolean required)
    {
        if (validArgs(level, className))
        {
            if (m_entries == null)
                m_entries = new Vector(5, 5);

            String _required = "notrequired";
            if (required)
                _required = "required";

            ConfigEntry _entry = new ConfigEntry(BISecurityConstants.USERCOMMUNITY_DRIVER, level, _required, className, null);
            m_entries.addElement(_entry);
        }
    }
*/
    /*
    private boolean validArgs(String level, String className)
    {
        if (level != null && className != null)
        {
            if (level.equals(BISecurityConstants.SESSION) || level.equals(BISecurityConstants.BICATALOG) || level.equals(BISecurityConstants.OLAP) || level.equals(BISecurityConstants.DISCOVERER))
                return true;
            else
                return false;
        }
        else
            return false;
    }
*/
    /*
    private void fillRemainEntries(Vector entries)
    {
        boolean _hasSessionAuth = false;
        boolean _hasSessionUserCommun = false;
        boolean _hasOLAPAuth = false;
        boolean _hasOLAPConn = false;
        boolean _hasPerAuth = false;
        boolean _hasPerConn = false;
        boolean _hasDiscoAuth = false;
        boolean _hasDiscoConn = false;

        for (int i=0; i<entries.size(); i++)
        {
            ConfigEntry _entry = (ConfigEntry)entries.elementAt(i);
            String _driverType = _entry.getDriverType();
            String _level = _entry.getInvocationLevel();

            if (_driverType.equals(BISecurityConstants.AUTHENTICATION_DRIVER))
            {
                if (_level.equals(BISecurityConstants.SESSION))
                    _hasSessionAuth = true;
                else if (_level.equals(BISecurityConstants.OLAP))
                    _hasOLAPAuth = true;
                else if (_level.equals(BISecurityConstants.BICATALOG))
                    _hasPerAuth = true;
                else if (_level.equals(BISecurityConstants.DISCOVERER))
                    _hasDiscoAuth = true;
            }
            else if (_driverType.equals(BISecurityConstants.CONNECTION_DRIVER))
            {
                if (_level.equals(BISecurityConstants.OLAP))
                    _hasOLAPConn = true;
                else if (_level.equals(BISecurityConstants.BICATALOG))
                    _hasPerConn = true;
                else if (_level.equals(BISecurityConstants.DISCOVERER))
                    _hasDiscoConn = true;
            }
            else if (_driverType.equals(BISecurityConstants.USERCOMMUNITY_DRIVER))
            {
                if (_level.equals(BISecurityConstants.SESSION))
                    _hasSessionUserCommun = true;
            }
        }

        if (!_hasSessionAuth)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.AUTHENTICATION_DRIVER, BISecurityConstants.SESSION, "required", DEF_SESSION_AUTH_DRV, null));

        if (!_hasSessionUserCommun)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.USERCOMMUNITY_DRIVER, BISecurityConstants.SESSION, "required", DEF_SESSION_UC_DRV, null));

        if (!_hasOLAPAuth)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.AUTHENTICATION_DRIVER, BISecurityConstants.OLAP, "notrequired", DEF_OLAP_AUTH_DRV, null));

        if (!_hasOLAPConn)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.CONNECTION_DRIVER, BISecurityConstants.OLAP, "required", DEF_OLAP_CONN_DRV, null));

        if (!_hasPerAuth)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.AUTHENTICATION_DRIVER, BISecurityConstants.BICATALOG, "notrequired", DEF_PER_AUTH_DRV, null));

        if (!_hasPerConn)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.CONNECTION_DRIVER, BISecurityConstants.BICATALOG, "required", DEF_PER_CONN_DRV, null));

        if (!_hasDiscoAuth)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.AUTHENTICATION_DRIVER, BISecurityConstants.DISCOVERER, "notrequired", DEF_DISCO_AUTH_DRV, null));

        if (!_hasDiscoConn)
            m_entries.addElement(new ConfigEntry(BISecurityConstants.CONNECTION_DRIVER, BISecurityConstants.DISCOVERER, "required", DEF_DISCO_CONN_DRV, null));
    }
*/
    /**
     * Specifies additional properties of this session object.
     *
     * @param name  The name of the property.
     * @param value The value of the property.
     *
     * @status documented
     */
    public void setProperty(String name, Object value)
    {
        if (name != null && value != null)
        {
            //if(name.equals(BISecurityConstants.BIUSER))
            //    m_env.put(name, value);
            m_connectProps.put(name, value);
        }
    }
    /**
     * Retrieves the value of a property in the session object.
     *
     * @param name  The name of the property.
     * @return The value of the property.
     *
     * @status reviewed
     */
    public Object getProperty(String name)
    {
        if (name != null)
            return m_connectProps.get(name);
        else
            return null;
    }

    /**
     * Removes a property from the session object.
     *
     * @param name  The name of the property to remove.
     *
     * @status reviewed
     */
    public void removeProperty(String name)
    {
        if (name != null)
            m_connectProps.remove(name);
    }

   /************* the hidden methods due to unsupported deployment option *********/
   /**
    * @hidden
    * Retrieves the user name that is passed to the Oracle8i application
    * server.
    * This method is useful only when you use an Oracle8i deployment.
    *
    * @return The name of the user for the Oracle8i application server to
    *         authenticate.
    *
    * @status documented
    */
    public String getUserName()
    {
        return (String)m_env.get(Context.SECURITY_PRINCIPAL);
    }

   /**
    * @hidden
    * Specifies the user name for the Oracle8i application server.
    * When the deployment option is an Oracle8i application server, then
    * you must call this method before you call the <code>connect</code>
    * method.
    * <P>
    * For more information about user names, see the documentation for
    * Oracle8i authentication.
    *
    * @param userName  The user name to pass to the application server for
    *                  authentication.
    *
    * @see #setDeploymentOption
    * @see #connect
    *
    * @status documented
    */
    public void setUserName(String userName)
    {
        if (userName != null)
            m_env.put(Context.SECURITY_PRINCIPAL, userName);
    }

   /**
    * @hidden
    * Retrieves the password that is passed to the Oracle8i application server
    * for authentication.
    * This method is useful only when you use an Oracle8i deployment.
    *
    * @return The password that is used to authenticate the user.
    *
    * @status documented
    */
    public String getPassword()
    {
        return (String)m_env.get(Context.SECURITY_CREDENTIALS);
    }

   /**
    * @hidden
    * Specifies the password that is passed to the Oracle8i application server
    * for authentication.
    * When the deployment option is an Oracle8i application server, then
    * you must call this method before you call the <code>connect</code>
    * method.
    * <P>
    * For more information about passwords, see the documentation for
    * Oracle8i authentication.
    *
    * @param password   The password to pass to the application server for
    *                   authentication.
    *
    * @see #setDeploymentOption
    * @see #setUserName
    * @see #connect
    *
    * @status documented
    */
    public void setPassword(String password)
    {
        if (password != null)
            m_env.put(Context.SECURITY_CREDENTIALS, password);
    }

   /**
    * @hidden
    * Retrieves the application path where the application module
    * resides in the Oracle8i namespace.
    * This method is useful only when you use an Oracle8i deployment.
    *
    * @return   The application path in Oracle8i namespace.
    *
    * @status documented
    */
    public String getApplicationPath()
    {
        return "";//(String)m_env.get(JboContext.APPLICATION_PATH);
    }

   /**
    * @hidden
    * Specifies the application path for the application module in the Oracle8i
    * namespace.
    * When the deployment option is an Oracle8i application server, then
    * you must call this method before you call the <code>connect</code>
    * method.
    * <P>
    * For more information about application paths, see the documentation for
    * Oracle8i authentication.
    *
    * @param path   The application path for the application module in the
    *               Oracle8i namespace.
    *
    * @see #setDeploymentOption
    * @see #connect
    *
    * @status documented
    */
    public void setApplicationPath(String path)
    {
        //if (path != null)
        //    m_env.put(JboContext.APPLICATION_PATH, path);
    }

    /************************ Helper methods ************************************/
    /**
     * @hidden
     */
    protected XMLElement getRootNode()
    {
        return m_root;
    }

    /**
     * @hidden
     * potentially used by other module, to parse a config file
     */
/*    private XMLElement parseManagerConfigFile(String configXML) throws BISessionException, IOException, SAXException
    {
        InputStream _is = null;

        if (configXML.startsWith("/"))
            configXML = configXML.substring(1);

        if (m_loader != null)
            _is = m_loader.getClassLoader().getResourceAsStream(configXML);
        else
            _is = Thread.currentThread().getContextClassLoader().getResourceAsStream(configXML);

        if (_is == null)
        {
            File _file = new File(configXML);
            if (_file.exists())
                _is = new FileInputStream(_file);
            else
                throw new BISessionException(AppModuleBundle.EXC_NO_CONFIG, null, getLocale(), null);
        }

        InputStreamReader _reader = new InputStreamReader(_is, "UTF8");

        m_parser = getParser();
        m_parser.parse(_reader);
        
        _is.close();
        _reader.close();
        
        XMLDocument _doc = (XMLDocument)m_parser.getDocument();
        return (XMLElement)_doc.removeChild(_doc.getDocumentElement());
    }

    private Hashtable parseBISessionElement(XMLElement elem) throws BISessionException
    {
        Hashtable _env = new Hashtable(10);
        NamedNodeMap _map = elem.getAttributes();

        NodeList _list = elem.getChildrenByTagName("BIUser");
        if (_list.getLength() > 0)
        {
            Element _userElem = (Element)_list.item(0);
            String _userName = _userElem.getAttribute("Username");
            if (_userName != null)
                _env.put(BISecurityConstants.BIUSER, new BIUser(_userName));
        }

        _list = elem.getChildrenByTagName("Debug");
        if (_list.getLength() > 0)
        {
            Element _userElem = (Element)_list.item(0);
            String _mode = _userElem.getAttribute("Mode");
            if (_mode != null && _mode != "")
            {
                DefaultErrorHandler _handler = new DefaultErrorHandler();
                StringTokenizer _tokenizer = new StringTokenizer(_mode, ",");
                int _debug = 0;
                while (_tokenizer.hasMoreTokens())
                {
                    String _token = _tokenizer.nextToken();
                    if (_token.equals("LOG"))
                        _debug = _debug + DefaultErrorHandler.SHOW_LOG;
                    else if (_token.equals("TRACE"))
                        _debug = _debug + DefaultErrorHandler.SHOW_TRACE;
                    else if (_token.equals("ERROR"))
                        _debug = _debug + DefaultErrorHandler.SHOW_ERROR;
                    else if (_token.equals("NONE"))
                    {
                        _debug = DefaultErrorHandler.SHOW_NONE;
                        break;
                    }
                    else if (_token.equals("ALL"))
                    {
                        _debug = DefaultErrorHandler.SHOW_ALL;
                        break;
                    }
                }
                _handler.setDebugMode(_debug);
                addErrorHandler(_handler);
            }

            String _handlerClass = _userElem.getAttribute("ErrorHandlerClass");
            if (_handlerClass != null && _handlerClass.length() > 0 && _handlerClass != "")
            {
                Class _cls = null;
                try
                {
                  _cls = Utility.loadClass(_handlerClass);
                  addErrorHandler((ErrorHandler)_cls.newInstance());
                }
                catch (Exception e)                
                {
                    throw new BISessionException(AppModuleBundle.EXC_ERRHANDLER_CREATE, new Object[]{e.getLocalizedMessage()}, getLocale(), e);
                }
            }
        }

        Vector _entries = null;
        _list = elem.getChildrenByTagName("PluggableDriver");
        if (_list.getLength() > 0)
            _entries = new Vector(_list.getLength());

        for (int i=0; i<_list.getLength(); i++)
        {
            Element _driverElem = (Element)_list.item(i);
            String _driverType = _driverElem.getAttribute("DriverType");
            String _invLevel = _driverElem.getAttribute("InvocationLevel");
            String _required = _driverElem.getAttribute("Required");
            String _driverClass = _driverElem.getAttribute("DriverClass");

            if (_required.equals("true"))
                _required = "required";
            else
                _required = "notrequired";
            ConfigEntry _entry = new ConfigEntry(_driverType, _invLevel, _required, _driverClass, null);
            _entries.addElement(_entry);
        }

        if (_entries != null)
            _env.put(BISecurityConstants.CONFIG_ENTRIES, _entries);

        return _env;
    }

    private void mergeEnvironments(Hashtable cfgEnv)
    {
        Enumeration _keys = cfgEnv.keys();
        while (_keys.hasMoreElements())
        {
            Object _key = _keys.nextElement();
            if (m_env.get(_key) == null)
                m_env.put(_key, cfgEnv.get(_key));
        }
    }
    */
    /**
     * @hidden
     */
    public Hashtable getProperties()
    {
        return m_connectProps;
    }

    /**
     * @hidden
     */
    public DOMParser getParser()
    {
        if (m_parser == null)
        {
            if (XMLObjectReader.s_tls == null)
                XMLObjectReader.s_tls = new ThreadLocal();

            m_parser = new DOMParser();
            m_parser.setPreserveWhitespace(false);
        }

        return m_parser;
    }
}
