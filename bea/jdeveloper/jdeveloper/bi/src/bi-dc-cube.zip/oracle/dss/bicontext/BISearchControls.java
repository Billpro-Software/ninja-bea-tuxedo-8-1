/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.directory.SearchControls;

/**
 * Encapsulates factors that control the behavior of a search.
 * This class allows you to specify:
 * <P>
 * <ul>
 * <li>The scope of the search</li>
 * <li>What the search returns in the search results</li>
 * <li>The maximum size of the search result set</li>
 * <li>The time limit for the search</li>
 * <li>Whether to include a subfolder as the returned result</li>
 * <li>Whether the search should be case-sensitive</li>
 * <li>The sorting criteria, if any</li>
 * <li>Custom filter for limiting the search results</li>
 * </ul>
 *
 * <p>You can also use the <code>setReturningAttributes</code> method of a
 * <code>BISearchControl</code> object to identify specific attributes that you
 * want to have returned for the objects that are selected in a search.
 * By default, all predefined attributes are returned and no extensible
 * attributes are returned. See <code>oracle.dss.util.persistence.PersistableConstants</code>
 * for the constants that represent predefined attributes and for constants
 * that represent extensible attributes.
 *
 * <p>Example -- Returning specific attributes<br>
 * The following code creates a <code>BISearchControl</code> object that
 * requests the return of the following attributes for the objects that are
 * selected by a search:
 * <ul>
 * <li>The object name, which is a predefined attribute.</li>
 * <li>An Author attribute, which is an extensible application attribute that
 * is owned by the current application.</li>
 * <li>All extensible component attributes.</li>
 * </ul>
 * This example uses the variable <code>_matchingAttributes</code>
 * which is a <code>BasicAttributes</code> object in which the selection
 * criteria for the search has been stored. It also uses the variable
 * <code>_context</code> to represent the BIContext for the search.
 * <pre>
 * BISearchControls sControls = new BISearchControls ();
 * //Search only in the specified BIContext (that is, folder)
 * sControls.setSearchScope (SearchControls.ONELEVEL_SCOPE);
 * sControls.setReturningAttributes (
 *     new String [] {
 *         PersistableConstants.Attributes.OBJECT_NAME,
 *         PersistableConstants.ExtensibleAttributes.CURRENT_APPLICATION + "/Author",
 *         PersistableConstants.ExtensibleAttributes.COMPONENT
 *      }
 *  );
 *  vector myResults = _context.search ("", _matchingAttributes, sControls);
 *  </pre>
 *
 * @see BIContext#search
 * @see oracle.dss.util.persistence.PersistableConstants
 * @see javax.naming.directory.BasicAttributes
 *
 * @status documented
 */
public class BISearchControls extends SearchControls
{
    private boolean m_partial = false;
    private boolean m_exceeded = false;
    private boolean m_caseSensitive = true;
    private int m_precision = DATE;
    private BIFilter m_filter;
    private boolean m_sortingOn = false;
    private BIComparator m_comp = null;
    // Flag that indicates whether search will include unnamed objects
    // (the default is false for backward compatibility).
    private boolean m_searchUnnamedObjects = false;
    // Indicates whether we look "through" the shortcut to the target object to
    // search the attributes and return its attributes.
    private boolean m_searchShortcutsOn = false;
    private String m_PLSQLFilter = null;

   /**
    * Find the subfolders of the named folder that contain objects that meet
    * the search criteria, as well as objects in the named folder that meet
    * the search criteria.
    * Besides the objects that meet the search criteria in the named context,
    * the <code>SearchResults</code> will contain subfolders in which objects
    * that meet the search criteria are found.
    *
    * @status documented
    */
    public static final int SELECTIVE_ONELEVEL_SCOPE   = 100;

   /**
    * Find the objects in the named folder that contain objects that meet
    * the search criteria, as well as all of the subfolders of the named
    * folder.
    * This scope differs from <code>SELECTIVE_ONE_LEVEL_SCOPE</code> in that,
    * with this scope, all subfolders are included in the results.
    * With <code>SELECTIVE_ONELEVEL_SCOPE</code>, only the subfolders that
    * contain searched-for objects are included in the results.
    *
    * @see #SELECTIVE_ONELEVEL_SCOPE
    *
    * @status documented
    */
    public static final int ONELEVEL_SCOPE_WITH_FOLDERS = 101;

   /**
    * Compare the time to date precision.
    *
    * @status documented
    */
    public static final int DATE = 200;

   /**
    * Compare the time to hours precision.
    *
    * @status documented
    */
    public static final int HOUR = 201;

   /**
    * Compare the time to minutes precision.
    *
    * @status documented
    */
    public static final int MINUTE = 202;

   /**
    * Compare the time to seconds precision.
    *
    * @status documented
    */
    public static final int SECOND = 203;

    /**
     * Construct a default search controls,
     */
    public BISearchControls()
    {

    }

    /**
     * Search for matching attributes.
     * @since 11
     */
    public BISearchControls(String[] attributesToReturn )
    {
        setCountLimit(0);
        setTimeLimit(0);

        setSearchScope(SearchControls.ONELEVEL_SCOPE);
        setReturningAttributes(attributesToReturn);
    }


    /**
     * @hidden
     * Set by StorageManager to indicate that result is partial
     */
    public void setPartialReturned(boolean partial)
    {
        m_partial = partial;
    }

    /**
     * @hidden
     * Set by StorageManager to indicate that search limit has exceeded
     */
    public void setLimitExceeded(boolean exceeded)
    {
        m_exceeded = exceeded;
    }

    /**
     * Specifies the precision to use when the search compares time values.
     * For example, if you are searching by the <code>TIME_DATE_MODIFIED</code>
     * attribute, then this method specifies whether you want to find
     * objects that were modified on a particular day, or at a particular
     * hour, or at a particular minute, or at a particular second.
     *
     * @param precision A constant that represents the precision to use when
     *                  the search is performed. Valid values are listed in
     *                  the See Also section.
     *
     * @see #DATE
     * @see #HOUR
     * @see #MINUTE
     * @see #SECOND
     *
     * @status documented
     */
    public void setTimePrecision(int precision)
    {
        m_precision = precision;
    }

    /**
     * Retrieves the precision that the search uses in comparing time values.
     *
     * @return  A constant that represents the precision used when the search is
     *          performed. Possible values are listed in the See Also section.
     *
     * @see #DATE
     * @see #HOUR
     * @see #MINUTE
     * @see #SECOND
     *
     * @status documented
     */
    public int getTimePrecision()
    {
        return m_precision;
    }

    /**
     * Specifies the search result filter to use after the main search is
     * finished.
     * This filter allows the application to further customize
     * what the search method is to return.
     *
     * @param  filter A <code>BIFilter</code> object that is used to filter
     *         the search results from the search.
     *
     * @status Documented
     */
    public void setResultFilter(BIFilter filter)
    {
        m_filter = filter;
    }

    /**
     * Retrieves the search result filter that is applied after the
     * main search is finished.
     * This filter allows the application to further customize
     * what the search method is to return.
     *
     * @return  A <code>BIFilter</code> object that is used to filter
     *          the search results from the search.
     *
     * @status Documented
     */
    public BIFilter getResultFilter()
    {
        return m_filter;
    }

    /**
     * Specifies whether the search on attribute values is case sensitive.
     * This setting applies to the following attributes:
     * <ul>
     * <li> OBJECT_NAME
     * <li> DESCRIPTION
     * <li> KEYWORDS
     * <li> APPLICATION
     * <li> DATABASE
     * <li> APPSUBTYPE1
     * <li> TITLE
     * <li> COMPSUBTYPE1
     * <li> COMPSUBTYPE2
     * <li> COMPSUBTYPE3
     * </ul>

     * @param caseSensitive A boolean that indicates whether the search is
     *                      case sensitive.
     *
     * @see #isCaseSensitive
     * @see oracle.dss.util.persistence.PersistableConstants
     *
     * @status Documented
     */
    public void setCaseSensitive(boolean caseSensitive)
    {
        m_caseSensitive = caseSensitive;
    }

    /**
     * Retrieves the case sensitive setting that the search uses in
     * comparing String values.
     *
     * @return  A boolean that represents whether the search is case sensitive.
     *
     * @see #setCaseSensitive
     * @see oracle.dss.util.persistence.PersistableConstants
     *
     * @status Documented
     */
    public boolean isCaseSensitive()
    {
        return m_caseSensitive;
    }

    /**
     * Specifies a comparator that is used for comparing
     * <code>BISearchResult</code> elements during sorting. If sorting is set
     * on and a comparator is not specified, then search results are sorted
     * by object name.
     *
     * @param comp An implementation of the <code>BIComparator</code> interface.
     *             Do not pass <code>null</code>. You can use an
     *             <code>oracle.dss.bicontext.BISearchResultsComparator</code>
     *             object.
     *
     * @see BISearchResultsComparator
     *
     * @status Documented
     */
    public void setSortingComparator(BIComparator comp)
    {
         m_comp = comp;
    }

    /**
     * Returns a comparator that is used for comparing
     * <code>BISearchResult</code> elements during sorting. If sorting is set on
     * and a comparator is not specified, then search results are sorted by
     * object name.
     *
     * @return An implementation of <code>BIComparator</code> interface;
     *         null if none is set
     *
     * @see BISearchResultsComparator
     *
     * @status Documented
     */
    public BIComparator getSortingComparator()
    {
        return m_comp;
    }

    /**
     * Queries <code>BISearchControls</code> to find out whether the
     * sorting option is on. When the sorting option is on, then, by default,
     * search results are sorted by object name. To specify different sort
     * criteria, you must also use the <code>setSortingComparator</code> method.
     *
     * @return boolean <code>true</code> if the sorting option is on,
     *                 <code>false</code> if the sorting option is off.
     *
     * @see BISearchResultsComparator
     *
     * @status Documented
     */
    public boolean isSortingOn()
    {
        return m_sortingOn;
    }

    /**
     * Specifies the sorting option for a search.
     * If the sorting option is on, then, by default, search results are
     * returned sorted by object name. However, if the
     * <code>setSortingComparator</code> method
     * is also set, then the sort is controlled by the specified
     * <code>oracle.dss.bicontext.BISearchResultsComparator</code>.
     *
     * @param flag <code>true</code> sets the sorting option on,
     *             <code>false</code> sets the sorting option off.
     *
     * @see BISearchResultsComparator
     *
     * @status Documented
     */
    public void setSortingOn(boolean flag)
    {
        m_sortingOn = flag;
    }

    /**
     * Specifies whether a search includes dependent objects (that is,
     * unnamed objects) in addition to named objects.
     * This flag that allows the searching of dependent objects is mutually
     * exclusive with the flag that allows shortcut searching.
     * Therefore, if you call <code>setIncludeUnnamedObjects (true)</code>,
     * then the flag that allows the searching of shortcuts is set to false.
     * If, at a later time, you call <code>setIncludeShortcutTarget(true)</code>,
     * then shortcut searching is allowed and dependent object searching is
     * not allowed.
     *
     * @param flag <code> true </code> includes unnamed objects when searching
     *             <code> false </code> ignores unnamed objects when searching.
     *
     * @status Documented
     */
    public void setIncludeUnnamedObjects(boolean flag)
    {
        m_searchUnnamedObjects = flag;
        if (flag)
            m_searchShortcutsOn = false;
    }

    /**
     * Determimes whether dependent objects (that is, unnamed
     * objects) are included in a search.
     *
     * @return boolean <code>true</code> indicates that unnamed objects are
     *                                   included when searching,
     *                 <code>false</code> indicates that unnamed objects are
     *                                   ignored when searching.
     *
     * @status Documented
     */
    public boolean isIncludeUnnamedObjects()
    {
        return m_searchUnnamedObjects;
    }

    /**
     * Specifies whether search criteria applies to the attributes of the
     * shortcut's target object and whether the search returns
     * attributes from the target object.
     * The following attributes are exceptions to this rule and are attributes
     * of the shortcut object itself:
     * <ul>
     * <li><code>OBJECT_NAME</code></li>
     * <li><code>OBJECT_FULLPATHNAME</code></li>
     * </ul>
     * Note that searching on a
     * target object occurs only when an object is a shortcut. For any other
     * object type, the search applies to the object at hand, regardless of
     * the setting of the <code>SearchShortcutsOn</code> flag.
     * <p>
     * The attribute <code>IS_SHORTCUT</code> is available in the returned
     * attributes.
     * When a search result is based on a SHORTCUT, <code>IS_SHORTCUT</code>
     * contains the String <code>TRUE</code>, otherwise it contains
     * <code>FALSE</code>.
     * <p>
     * The flag that allows the searching of shortcuts is mutually exclusive
     * with the flag that allows the searching of dependent (that is,
     * unnamed) objects.
     * Therefore, if you call <code>setIncludeShortcutTarget(true)</code> then
     * the flag that allows the searching of dependent (unnamed) objects is
     * set to <code>false</code>.
     * If, at a later time, you call <code>setIncludeUnnamedObjects(true)</code>
     * then searching dependent objects is allowed and
     * <code>SearchShortcutsOn</code> is set to <code>false</code>.
     *
     * @param flag <code> true </code> allows shortcuts to be searched
     *             <code> false </code> ignores shortcuts when searching.
     *
     * @status Documented
     */
    public void setIncludeShortcutTarget(boolean flag)
    {
        m_searchShortcutsOn = flag;
        if (flag)
            m_searchUnnamedObjects = false;
    }

    /**
     * Determines whether a search is based on the attributes of a shortcut's
     * target object.
     *
     * @return boolean <code>true</code> indicates that the search is based on
     *                  the attributes of the shortcut's target object,
     *                 <code>false</code> indicates that the search is based on
     *                 the attributes of the shortcut.
     *
     * @status Documented
     */
    public boolean isIncludeShortcutTarget()
    {
        return m_searchShortcutsOn;
    }

    public Object clone()
    {
        BISearchControls _controls = new BISearchControls();
        _controls.setCaseSensitive(isCaseSensitive());
        _controls.setCountLimit(getCountLimit());
        _controls.setResultFilter(getResultFilter());
        _controls.setIncludeUnnamedObjects(isIncludeUnnamedObjects());
        _controls.setReturningAttributes(getReturningAttributes());
        _controls.setReturningObjFlag(getReturningObjFlag());
        _controls.setSearchScope(getSearchScope());
        _controls.setIncludeShortcutTarget(isIncludeShortcutTarget());
        _controls.setSortingComparator(getSortingComparator());
        _controls.setSortingOn(isSortingOn());
        _controls.setTimeLimit(getTimeLimit());
        _controls.setTimePrecision(getTimePrecision());
        _controls.setPLSQLFilter(getPLSQLFilter());
        return _controls;
    }

    /**
     * @hidden
     * @param plsql The annonymous
     */
    public void setPLSQLFilter(String plsql)
    {
        m_PLSQLFilter = plsql;
    }

    /**
     * @hidden
     */
    public String getPLSQLFilter()
    {
        return m_PLSQLFilter;
    }
}
