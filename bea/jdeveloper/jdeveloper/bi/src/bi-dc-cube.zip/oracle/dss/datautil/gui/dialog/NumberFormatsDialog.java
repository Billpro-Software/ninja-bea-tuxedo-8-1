/**
 * NumberFormatsDialog.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.dialog;

import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Window;

import java.util.Locale;

import oracle.dss.datautil.gui.StandardDialog;

import oracle.dss.dataView.managers.ViewFormat;

import oracle.dss.gridView.gui.NumberFormatPanel;

import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.Localizable;

/**
 * @hidden
 *
 * Creates a number format dialog that allows a number format to be generated
 * based on a ViewFormat.
 *
 * @status hidden
 */

 public class NumberFormatsDialog extends StandardDialog
                                implements Localizable, ErrorHandlerCallback {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * The <code>Locale</code> used to properly translate messages.
   *
   * @status private
   */
  private transient Locale m_locale = null;

  /**
   * The <code>ErrorHandler</code> used to process errors.
   *
   * @status private
   */
  private transient ErrorHandler m_errorHandler = new DefaultErrorHandler();

  /**
   * The <code>ViewFormat</code> associated with the <code>NumberFormatsDialog</code>.
   *
   * @status private
   */
  private transient ViewFormat m_viewFormat = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   * Constructor for NumberFormatsDialog.
   *
   * @param  dialogParent a <code>Dialog</code> value that represents the
   *         parent of the <code>NumberFormatsDialog</code>.
   * @param  strTitle a <code>String</code> value that represents the
   *         title of the dialog.
   * @param  bModal a <code>boolean</code> value that is <code>true</code> when
   *         the dialog is modal and <code>false</code> otherwise.
   * @param  viewFormat a <code>ViewFormat</code> value that contains the number
   *         format.
   * @return <code>NumberFormatsDialog</code> which represents a
   *         newly constructed number format dialog object, or null.
   * @status hidden
   */
  public NumberFormatsDialog (Dialog dialogParent, String strTitle, boolean bModal,
                             ViewFormat viewFormat) {
    super (dialogParent, strTitle, bModal, null);
    initDialog (dialogParent, strTitle, bModal, viewFormat);
    setSize (StandardDialog.LARGE_SIZE);
  }

  /**
   * Constructor for NumberFormatsDialog.
   * @hidden
   *
   * @param  frameParent a <code>Frame</code> value that represents the
   *         parent of the <code>NumberFormatsDialog</code>.
   * @param  strTitle a <code>String</code> value that represents the
   *         title of the dialog.
   * @param  bModal a <code>boolean</code> value that is <code>true</code> when
   *         the dialog is modal and <code>false</code> otherwise.
   * @param  viewFormat a <code>ViewFormat</code> value that contains the number
   *         format.
   * @return <code>NumberFormatsDialog</code> which represents a
   *         newly constructed number format dialog object, or null.
   * @status hidden
   */
  public NumberFormatsDialog (Frame frameParent, String strTitle, boolean bModal,
                             ViewFormat viewFormat) {
    super (frameParent, strTitle, bModal, null);
    initDialog (frameParent, strTitle, bModal, viewFormat);
    setSize (StandardDialog.LARGE_SIZE);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  //-----------------------------------------------------------------------
  // Start- Implementation of the ErrorHandlerCallback interface
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Adds a single error handler to the bean.
   * The bean then calls the error handler with error messages,
   * messages about abnormal situations, and trace messages.
   *
   * @param errorHandler The error handler to add.
   *
   * @status hidden
   */
  public void addErrorHandler (ErrorHandler errorHandler) {
    m_errorHandler = errorHandler;
  }

  /**
   * @hidden
   * Removes the error handler from the bean.
   *
   * @status hidden
   */
  public void removeErrorHandler() {
    m_errorHandler = null;
  }

  //-----------------------------------------------------------------------
  // End - Implementation of the ErrorHandlerCallback interface
  //-----------------------------------------------------------------------

  /**
   * @hidden
   * Retrieves the current error handler.
   *
   * @return <code>ErrorHandler</code> value which represents the current error
   *          handler.
   * @status hidden
   */
  public ErrorHandler getErrorHandler() {
    return m_errorHandler;
  }

  /**
   * @hidden
   * Specifies the <code>ViewFormat</code> associated with the <code>NumberFormatsDialog</code>.
   *
   * @param viewFormat a <code>ViewFormat</code> value associated with the
   *        <code>NumberFormatsDialog</code>.
   *
   * @status hidden
   */
  public void setViewFormat (ViewFormat viewFormat) {
    m_viewFormat = viewFormat;
  }

  /**
   * @hidden
   * Retrieves the <code>ViewFormat</code> associated with the <code>NumberFormatsDialog</code>.
   *
   * @return <code>ViewFormat</code> value which contains the number format.
   *
   * @status hidden
   */
  public ViewFormat getViewFormat () {
    return m_viewFormat;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Handles the user pressing the "OK" button.
   *
   * @status protected
   */
  protected void doOK() {
    ViewFormat viewFormat = null;

    // Retrieve the number format panel
    NumberFormatPanel numberFormatPanel = (NumberFormatPanel)getContent();
    if (numberFormatPanel != null) {
      // Retrieve the updated view format
      viewFormat = numberFormatPanel.apply();
    }

    // Update the view format
    setViewFormat (viewFormat);

    // Release the dialog resources
    dispose();
  }

  /**
   * Handles the user pressing the "Cancel" button.
   *
   * @status protected
   */
  protected void doCancel() {
    // Release the dialog resources
    dispose();
  }

  /**
   * @hidden
   * 
   * Initializes the <code>NumberFormatPanel</code> to the number 
   * format type associated with the underlying <code>ViewFormat</code>.
   *
   * @param numberFormatPanel a <code>NumberFormatPanel</code> whose format
   *        type is to be initialized based on the underlying<code>ViewFormat</code>.
   *         
   * @status hidden
   */
  protected void setFormatType (NumberFormatPanel numberFormatPanel) {
    if (numberFormatPanel == null) {
      return;
    }

    // Retrieve the number format string associated with the current ViewFormat 
    ViewFormat viewFormat = numberFormatPanel.getViewFormat();
    if (viewFormat == null) {
      return;
    }
    
    // Retrieve the number format string based on the current ViewFormat
    String strNumberFormatString = 
      viewFormat.getNumberFormatString (ViewFormat.BIBEANS_PATTERN_STR);
      
    // Add the number format string to the list of custom number formats    
    numberFormatPanel.setCurrentCustomPatternString (strNumberFormatString);

    // Default the format type
    int nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_NOT_SPECIFIED;

    String strDefaultNumberFormatString;    
    
    // Determine which category that the ViewFormat is associated with based
    // on the default number format string generated for each category
    if (strNumberFormatString != null) {
      // NUMBER_FORMAT_TYPE_NONE
      strDefaultNumberFormatString = 
        getDefaultNumberFormatString (numberFormatPanel, 
          NumberFormatPanel.NUMBER_FORMAT_TYPE_NONE);

      if (strNumberFormatString.equals (strDefaultNumberFormatString)) {
        nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_NONE;  
      }
      else {
        // NUMBER_FORMAT_TYPE_DEFAULT
        strDefaultNumberFormatString = 
          getDefaultNumberFormatString (numberFormatPanel, 
            NumberFormatPanel.NUMBER_FORMAT_TYPE_DEFAULT);
    
        if (strNumberFormatString.equals (strDefaultNumberFormatString)) {
          nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_DEFAULT;
        }      
        else {
          // NUMBER_FORMAT_TYPE_CURRENCY
          strDefaultNumberFormatString = 
            getDefaultNumberFormatString (numberFormatPanel, 
              NumberFormatPanel.NUMBER_FORMAT_TYPE_CURRENCY);
      
          if (strNumberFormatString.equals (strDefaultNumberFormatString)) {
            nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_CURRENCY;
          }
          else {
            // NUMBER_FORMAT_TYPE_NUMBER
            strDefaultNumberFormatString = 
              getDefaultNumberFormatString (numberFormatPanel, 
                NumberFormatPanel.NUMBER_FORMAT_TYPE_NUMBER);

            if (strNumberFormatString.equals (strDefaultNumberFormatString)) {
              nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_NUMBER;
            }
            else {
              // NUMBER_FORMAT_TYPE_PERCENT
              strDefaultNumberFormatString = 
                getDefaultNumberFormatString (numberFormatPanel, 
                  NumberFormatPanel.NUMBER_FORMAT_TYPE_PERCENT);

              if (strNumberFormatString.equals (strDefaultNumberFormatString)) {
                nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_PERCENT;
              }
              else {
                // NUMBER_FORMAT_TYPE_CUSTOM
                nFormatType = NumberFormatPanel.NUMBER_FORMAT_TYPE_CUSTOM;
              }
            }
          }
        }
      }
    }

    // Update the NumberFormatPanel based on the number format type
    numberFormatPanel.setFormatType (nFormatType);
  }    

  /**
   * @hidden
   * 
   * Retrieves the default number format string associated with the specified
   * <code>NumberFormatPanel</code> and number format type.
   *
   * @param numberFormatPanel A <code>NumberFormatPanel</code> to retrieve
   *        default number format string from.
   * @param nFormatType A <code>int</code> constant that represents the category 
   *        of the default number format string to retrieve. Valid constants are 
   *        listed in the See Also section.
   *
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_NONE
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_DEFAULT
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_NUMBER
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_CURRENCY
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_PERCENT
   * @see oracle.dss.gridView.gui.NumberFormatPanel#NUMBER_FORMAT_TYPE_CUSTOM
   *
   * @return <code>String</code> representing the default number format string.
   *
   * @status hidden
   */
  protected String getDefaultNumberFormatString (NumberFormatPanel numberFormatPanel, int nFormatType) {
    String strDefaultNumberFormatString = null;
    
    if (numberFormatPanel != null) {
      ViewFormat viewFormat = numberFormatPanel.getViewFormat();
      if (viewFormat != null) {
        
        // Specify the FormatType
        numberFormatPanel.setFormatType (nFormatType);
 
        // Retrieve the ViewFormat associated with the NumberFormatPanel
        ViewFormat viewFormatNew = numberFormatPanel.apply();
      
        if (viewFormatNew != null) {
          // Update the new ViewFormat with "missing" use bits so that proper
          // number format string is generated
          viewFormatNew.setThousandSeparatorUsed (viewFormat.isThousandSeparatorUsed());
          viewFormatNew.setCurrencySymbolUsed (viewFormat.isCurrencySymbolUsed());
         
          // Retrieve the default number format string
          strDefaultNumberFormatString = 
            viewFormatNew.getNumberFormatString (ViewFormat.BIBEANS_PATTERN_STR); 
        }
      }    
    }
 
    return strDefaultNumberFormatString;
  }    

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * Initializes the <code>NumberFormatsDialog</code>.
   *
   * @param  windowParent a <code>Window</code> value that represents the
   *         parent of the <code>NumberFormatsDialog</code>.
   * @param  strTitle a <code>String</code> value that represents the
   *         title of the dialog.
   * @param  bModal a <code>boolean</code> value that is <code>true</code> when
   *         the dialog is modal and <code>false</code> otherwise.
   * @param  viewFormat a <code>ViewFormat</code> value that contains the number
   *         format.
   * @status private
   */
  private void initDialog (Window windowParent, String strTitle, boolean bModal,
                           ViewFormat viewFormat) {
    // Initialize the title
    if (strTitle == null  || strTitle.length() == 0)
      setTitle (strTitle);

    // gek 03/12/04 For now at least, we need to associate a locale with the 
    //              ViewFormat so that the NumberFormatPanel does not generate
    //              a NullPointerException because of 'Bug 1988353 - NLS: Currency
    //              formatting needs to support same symbol used in multiple
    //              locales'.
    
    // bug 1988353/3467160 : in JDK1.3 you get an IllegalStateException while
    // trying to get the default locale of the NumberFormatPanel. To obviate this,
    // set the locale on the ViewFormat and pass it into the NumberFormatPanel
    if (viewFormat == null) {
      viewFormat = new ViewFormat();
    }
    
    // Update the locale of the NumberFormatsDialog based on the ViewFormat
    setLocale (viewFormat.getLocale());
    
    // Initialize our number format panel

    // gek 05/02/02 Let the NumberFormatPanel know that we want custom
    //              number formats to use the BIBeans number format
    NumberFormatPanel numberFormatPanel =
      new NumberFormatPanel (viewFormat, ViewFormat.BIBEANS_PATTERN_STR);

    // Specify the locale
    numberFormatPanel.setLocale (getLocale());

    // Specify the error handler
    numberFormatPanel.setErrorHandler(getErrorHandler());

    // gek 04/12/04 Fix Bug 3426299 - D4O: Calculation wizard format options 
    //              behave incorrectly and Bug 3406429 - D4O: Previously selected 
    //              number format not highlighted when edit calc.

    // Update the NumberFormatPanel format type based on the previously specified 
    // ViewFormat.
    setFormatType (numberFormatPanel);

    // Make the number format panel the dialog's content 
    setContent (numberFormatPanel);
  }
}

