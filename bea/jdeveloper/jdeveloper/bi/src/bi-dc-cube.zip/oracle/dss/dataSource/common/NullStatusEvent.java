/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

/**
 * Informs listeners when a query evaluation results in one or more null
 * (empty) edges.
 *
 * @status Documented
 */
public class NullStatusEvent extends QueryEvent
{
    /**
     * @serial
     */
    private BitSet m_edges = null;
    
    /**
     * Constructor for this event.
     *
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param edges       A list of the null edges. In this list,
     *                    to refer to edges, use the constants
     *                    <code>DataDirector.COLUMN_EDGE</code>,
     *                    <code>DataDirector.PAGE_EDGE</code>, or
     *                    <code>DataDirector.ROW_EDGE</code>.
     *
     * @see  oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see  oracle.dss.util.DataDirector#PAGE_EDGE
     * @see  oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public NullStatusEvent(Object source, BitSet edges) {
        super(source);
        
        m_edges = edges;
    }    
    
    /**
     * Indicates whether a specified edge is null.
     *
     * @return <code>true</code> if the specified edge is null;
     *         <code>false</code> if the specified edge is not null.
     *
     * @status Documented
     */
    public boolean isEdgeNull(int edge)
    {
        if (m_edges != null)
        {
            return m_edges.get(edge);
        }
        return false;
    }
}
