/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.client;

import java.text.MessageFormat;
import java.util.ResourceBundle;

import oracle.dss.util.BIBaseException;
import oracle.dss.util.BIException;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;
/**
 * Provides non-runtime exceptions that are thrown specifically by the DataUtil class.
 *
 * @status Documented
 */
public class DataUtilException extends BIBaseException {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * The <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @status private
   */
  private transient Object[] m_objMergeArray = null;

  private ResourceBundle m_bundle;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that specifies all arguments.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *                     that is the key used to look up the associated
   *                     error string in the resource bundle.
   *
   *                     If the error associated with the error code is not found,
   *                     getMessage() will return the original error code.
   *
   * @param throwable  A <code>Throwable</code> exception that represents the
   *                   previous exception to carry (may be null).
   *
   * @status hidden
   * @hidden
   */
  public DataUtilException (String strErrorCode, Throwable throwable) {
    super (strErrorCode, throwable);
    m_bundle = ResourceBundle.getBundle("oracle.dss.datautil.client.resource.DataUtilClientBundle");
  }

  /**
   * @hidden
   *
   * Constructor that specifies all arguments.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *                     that is the key used to look up the associated
   *                     error string in the resource bundle.
   *
   *                     If the error associated with the error code is not found,
   *                     then the <code>getMessage</code> method retrieves the original error code.
   *
   * @param throwable  A <code>Throwable</code> exception that represents the
   *                   previous exception to carry (may be null).
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the error message.
   *
   * @status hidden
   */
  public DataUtilException (String strErrorCode, Throwable throwable, Object[] objMergeArray) {
    super (strErrorCode, throwable);
    setMergeArray (objMergeArray);
    m_bundle = ResourceBundle.getBundle("oracle.dss.datautil.client.resource.DataUtilClientBundle");
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Returns the error message.
   *
   * If the error associated with the original error code is not found,
   * this routine will return the original error code.
   *
   * The message is formatted as follows:
   * ErrorCode <space> ErrorString
   *
   * Example:
   *  DVT-1500 MetadataManager not set
   *
   * @return <code>String</code> which represents the formatted error message.
   *
   * @status hidden
   * @hidden
   */
  public String getMessage() {
    // Retrieve the initial Error code
    String strMessage = super.getMessage();

    if (strMessage != null) {
      // Retrieve our error string
      String strError = m_bundle.getString (strMessage);

      if (strError != null) {
        // Create our new error message
        //  ErrorCode <space> ErrorString
        //  DVT-1500 MetadataManager not set
        StringBuffer strBuffer = new StringBuffer (strMessage);
        strBuffer.append (" ");

        // Determine if any objects needs to be merged
        Object[] objMergeArray  = getMergeArray();
        if (objMergeArray != null) {
          strError = MessageFormat.format (strError, objMergeArray);
        }

        return strBuffer.append(strError).toString();
      }
    }

    return strMessage;
  }

  /**
   * Determines if this DataUtilException was caused by an overwrite exception. 
   *
   * @return true, if it is an overwrite exception and false if not
   *
   * @status hidden
   * @hidden
   */
  public boolean isOverwriteException()
  {
      BIException biException = (BIException)getException(MetadataManagerCommonBundle.EXC_NAME_ALREADY_BOUND);
      if(biException!=null)
        return true;
      else
        return false;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////


  /**
   * Retrieves the <code>BIException</code> associated with the specified
   * error stack and error code.
   *
   * @param  throwable a <code>Throwable</code> value that represents the exception
   *         to check.
   * @param  strErrorCode a <code>String</code> value that represents the error
   *         code to check.
   *
   * @return <code>BIException</code> if the appropriate exception is found, and
   *         null otherwise.
   *
   * @status private
   */
  private BIException getException (Throwable throwable, String strErrorCode) {

    BIException biException = null;

    // Determine if this represents a BIException
    if ((throwable != null) && (throwable instanceof BIException)) {
      biException = (BIBaseException)((BIBaseException) throwable).getException (strErrorCode);
    }

    return biException;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @hidden
   *
   * Specifies the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the exception's error message.
   *
   * @status protected
   */
  protected void setMergeArray (Object[] objMergeArray) {
    m_objMergeArray = objMergeArray;
  }

  /**
   * @hidden
   *
   * Retrieves the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @return <code>Object[]</code> which is to be merged with the exception's
   *         error message.
   * @status protected   
   */

  protected Object[] getMergeArray() {
    return m_objMergeArray;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}