/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Base class to distinguish selection sequence events.
 *
 * @status Documented
 */
public abstract class SelectionEvent extends QueryEvent
{
    /**
     * Constructs the event.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param selections An array of changed <code>Selection</code> objects.
     * @param removed    <code>true</code> if the <code>Selection</code> objects
     *                   were removed, <code>false</code> if they were not.
     *
     * @status documented
     */
     // blm - Selection code moved to dvt-olap
    public SelectionEvent(Object source/*, Selection[] selections*/, boolean removed) {
        super(source);
        
        // blm - Selection code moved to dvt-olap
/*        sels = selections;*/
        m_removed = removed;
    }    
    
    /**
     * Retrieves the list of changed <code>Selection</code> objects.
     *
     * @return An array of changed <code>Selection</code> objects.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection[] getSelections() {
        return sels;
    }*/
    
    // Fields
    /**
     * @hidden
     * @serial list of selections
     * @status protected
     */
     // blm - Selection code moved to dvt-olap
/*    protected Selection[]  sels;*/

    /**
     * @hidden
     * @serial were these selections removed?
     * @status protected
     */
    protected boolean m_removed = false;
}
