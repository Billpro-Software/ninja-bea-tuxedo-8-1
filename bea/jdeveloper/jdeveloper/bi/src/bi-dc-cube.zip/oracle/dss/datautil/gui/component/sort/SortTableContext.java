/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/SortTableContext.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.sort;

import java.lang.Boolean;

import oracle.dss.datautil.gui.component.ComponentContext;

/**
 * <pre>
 * SortTable context.
 * </pre>
 *
 * @author gkellam
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   10/16/06 - Provide SortTableContext for SortTable.
 */
public class SortTableContext extends ComponentContext {

  /////////////////////
  //
  // Constants
  //
  /////////////////////
  
  /**
   * Property used to determine whether the Group Duplicates option is available
   * within the <code>SortTable</code>.
   * 
   * @status new
   */
  public static String PROPERTY_GROUP_DUPLICATES_AVAILABLE = "GroupDuplicatesAvailable";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
  
  /**
   * Default <code>SortTableContext</code> constructor.
   * 
   * @throws Exception
   */ 
  public SortTableContext() throws Exception{
    super();
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  /**
   * Specifies whether the GroupDuplicates description panel is available.
   * 
   * @param bAvailable A <code>boolean</code> which is <code>true</code> when the 
   *        <code>ItemsPanel</code> description panel is visible and <code>false</code>
   *        otherwise.
   *         
   * @status new        
   */
  public void setGroupDuplicatesAvailable (boolean bAvailable) {
    setGroupDuplicatesAvailable (this, bAvailable);
  }

  /**
   * Determines whether the <code>ItemsPanel</code> description panel is available.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the 
   *         <code>ItemsPanel</code> description panel is available and 
   *         <code>false</code> otherwise.
   *         
   * @status new        
   */
  public boolean isGroupDuplicatesAvailable() {
    return isGroupDuplicatesAvailable (this);
  }

  /**
   * Specifies whether the GroupDuplicates description panel is available.
   * 
   * @param bAvailable A <code>boolean</code> which is <code>true</code> when the 
   *        <code>ItemsPanel</code> description panel is visible and <code>false</code>
   *        otherwise.
   *         
   * @status new        
   */
  public static void setGroupDuplicatesAvailable (ComponentContext componentContext, boolean bAvailable) {
    if (componentContext != null) {
      componentContext.setProperty (PROPERTY_GROUP_DUPLICATES_AVAILABLE, new Boolean (bAvailable));
    }
  }

  /**
   * Determines whether the <code>ItemsPanel</code> description panel is available.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the 
   *         <code>ItemsPanel</code> description panel is available and 
   *         <code>false</code> otherwise.
   *         
   * @status new        
   */
  public static boolean isGroupDuplicatesAvailable (ComponentContext componentContext) {
    boolean bIsGroupDuplicatesAvailable = true;

    if (componentContext != null) {
      Boolean booleanProperty = 
        (Boolean) componentContext.getProperty (PROPERTY_GROUP_DUPLICATES_AVAILABLE);
      
      bIsGroupDuplicatesAvailable = 
        (booleanProperty != null) ?  booleanProperty.booleanValue() : true;
    }

    return bIsGroupDuplicatesAvailable;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
  
}