/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.MetadataPrinter;
import oracle.dss.util.DefaultMetadataPrinter;
import oracle.dss.util.transform.BaseNode;

/**
 * @hidden
 */

/*
 * Represents a node within an edge in a query.
 * This node has a name, an index to distinguish it from other identically-named nodes within
 * the same query, and children if the node has other nodes that could repeat for each value of the node.
 * Nodes also have a flag to indicate if they have an asymmetric relationship with any of their children.
 * @status hidden
 */
public class Node extends BaseNode implements oracle.dss.util.VectorClone, Cloneable, java.io.Serializable
{    
    protected transient MetadataPrinter m_metadataPrinter = new DefaultMetadataPrinter();
    
    /*
     * Construct a node
     */
    public Node() {
      super();
    }

    /*
     * Construct a node
     *
     * @param name the name of the node
     */
    public Node(String name) {
        super(name);
    }

    /*
     * Construct a node
     *
     * @param name the name of the node
     * @param index index to distinguish node
     * @status hidden
     */
    public Node(String name, int index) {
      super(name, index);
    }
    
    /**
     * @hidden
     */
    public void setMetadataPrinter(MetadataPrinter metadataPrinter)
    {
        if (metadataPrinter != null)
        {
            m_metadataPrinter = metadataPrinter;
        }
        else
        {
            m_metadataPrinter = new DefaultMetadataPrinter();
        }
    }
    
    /**
     * Determine if this node has dependent dimension asymmetry
     *
     * @return true if it does
     */
/*    public boolean isAsymmetric(SelectionList list)
    {
        Selection sel = list.find(getName());
        if (sel != null)
        {
            return sel.isAsymmetric();
        }
        return false;
    }*/
    
    /**
     * @hidden
     */
    public String toString() {
        String name = m_metadataPrinter.getMetadataName(getName(), m_metadataPrinter.getDimensionType());
        return getIndex() == -1 ? name : name + ":" + getIndex();
    }
    
    protected static BaseNode createNodeObject() {
      return new Node();
    }
}
