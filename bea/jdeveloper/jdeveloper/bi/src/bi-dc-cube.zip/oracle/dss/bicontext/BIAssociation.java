/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

/**
 * The BIAssociation class is a structure that contains
 * the name of an associated object, the class name of the object, a reference 
 * to the object, and the attributes that were requested for the object.  
 * The 'real' object can be loaded on demand using the getObject() method.
 *
 * A vector of <code>BIAssociation</code> objects is returned when any of 
 * the <code>listAssociates</code> or <code>listReferringAssociates</code> 
 * methods is called on a directory. 
 *
 * @status Documented
 */
public class BIAssociation extends BISearchResult
{
    /**
     * Identity of the association (association name and index).  
     */
    private final Attribute m_associateID;
    
    

    /**
     * @hidden
     */
    public BIAssociation(String name, String className, Object obj, Attributes attrs, boolean isRelative, String type, Attribute id)
    {
        super(name, className, obj, attrs, isRelative, type);
        m_associateID = id;
    }

    /**
     * Returns the identifier for this association.
     *
     * @return the identifier for this association.
     *
     * @status Documented
     */
    public Attribute getAssociateID()
    {
        return m_associateID;
    }
}
