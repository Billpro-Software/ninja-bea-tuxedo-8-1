/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

/**
 *
 * Provides access to a <code>Persistable</code>
 * object.
 * The persistence service uses <code>StateObject</code> objects to manage
 * persisted objects.
 *
 * @see oracle.dss.util.persistence.Persistable
 * @hidden
 */
public abstract interface StateObject
{
   /**
    * Retrieves the type of <code>Persistable</code> object that this
    * <code>StateObject</code> represents.
    *
    * @return A constant that identifies the type of object that a
    *          <code>Persistable</code object is.
    *          Valid constants are defined in the
    *          <code>PersistableConstants</code> interface.
    *
    * @see oracle.dss.util.persistence.PersistableConstants
    * @see oracle.dss.util.persistence.PersistableConstants.Attributes#OBJECT_TYPE
    *
    * @status documented
    */
    public String getObjectType();

   /**
    * Retrieves the <code>Persistable</code> object that this
    * <code>StateObject</code> represents.
    *
    * @return The <code>Persistable</code> object.
    *
    * @status documented
    */
    public Object getObject();


}
