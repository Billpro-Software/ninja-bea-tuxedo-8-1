/*
 * DimensionMember.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */
package oracle.dss.datautil;

import oracle.dss.util.xml.*;
import oracle.dss.util.persistence.StringXMLizable;
import oracle.dss.util.persistence.BIPersistenceException;

/**
 * @hidden
 * The class used for representing a dimension member
 */
 public class DimensionMember extends ObjectCache
 {

    protected String m_hierID = null;
    protected String m_levelID = null;
    protected String m_levelName = null;
    
    static final protected String HIER_ID_PROP = "h";
    static final protected String LEVEL_ID_PROP = "l";
    static final protected String LEVEL_NAME_PROP = "ln";
    static final protected String MEMBER_ID_PROP = "m";
    static final protected String MEMBER_NAME_PROP = "mn";

 	/**
     * Constructor.
     *
     * @param dimMemberID   the unique String identifying the dimension member
     * @param dimMemberName the display name of the dimension member
     *
     * @status New
     */
  	public DimensionMember(String dimMemberID, String dimMemberName)
 	{
   		super(dimMemberID, dimMemberName);
   	}

	/**
     * Constructor.
     *
     * @param dimMemberID   the unique String identifying the dimension member
     * @param dimMemberName the display name of the dimension member
     * @param hierarchyID   the name of the hierarchy from which the member comes
     * @param levelID       the name of the level from which the member comes
     *
     * @status New
     */
  	public DimensionMember(String dimMemberID, String dimMemberName, String hierarchyID, String levelID)
 	{
   		super(dimMemberID, dimMemberName);
        m_hierID = hierarchyID;
        m_levelID = levelID;
   	}

	/**
     * Constructor.
     *
     * @param dimMemberID   the unique String identifying the dimension member
     * @param dimMemberName the display name of the dimension member
     * @param hierarchyID   the name of the hierarchy from which the member comes
     * @param levelID       the name of the level from which the member comes
     * @param levelName     the display name of the level from which the member comes
     *
     * @status New
     */
  	public DimensionMember(String dimMemberID, String dimMemberName, String hierarchyID, String levelID, String levelName)
 	{
   		super(dimMemberID, dimMemberName);
        m_hierID = hierarchyID;
        m_levelID = levelID;
        m_levelName = levelName;
   	}

   	/**
     * Retrieves the unique String identifier of the dimension member.
     *
     * @return dimMemberID   the unique String identifying the dimension member
     *
     * @status New
     */
   	public String getDimMemberID()
   	{
    	return (String)getObject();
   	}

    /**
     * Retrieves the hierarchy ID of the member
     */
    public String getHierarchyID()
    {
        return m_hierID;
    }

    /**
     * Retrieves the level ID of the member
     */
    public String getLevelID()
    {
        return m_levelID;
    }

    /**
     * Retrieves the level name of the member
     */
    public String getLevelName()
    {
        return m_levelName;
    }

    static public DimensionMember getDimensionMember(String xml) throws BIIOException, BIParseException, BISAXException, NoSuchPropertyException
    {
        XMLObjectReader xmlReader = new XMLObjectReader(xml);
        ObjectNode node = xmlReader.readObjectNode();

        String hierID = null;
        PropertyNode prop = node.getProperty(HIER_ID_PROP);
        if(prop!=null)
          hierID = prop.getValueAsString();
        
        String levelID = null;
        prop = node.getProperty(LEVEL_ID_PROP);
        if(prop!=null)
          levelID = prop.getValueAsString();

        String levelName = null;
        prop = node.getProperty(LEVEL_NAME_PROP);
        if(prop!=null)
          levelName = prop.getValueAsString();

        String object = null;
        prop = node.getProperty(MEMBER_ID_PROP);
        if(prop!=null)
          object = prop.getValueAsString();

        String strObject = null;
        prop = node.getProperty(MEMBER_NAME_PROP);
        if(prop!=null)
          strObject = prop.getValueAsString();

        return new DimensionMember(object,strObject,hierID,levelID,levelName);
    }

    static public String getXML(DimensionMember dimMember) throws BIIOException
    {
        ObjectNode node = new ObjectNode("DM");
        String value = dimMember.getHierarchyID();
        if(value!=null)
          node.addProperty(HIER_ID_PROP,value);
          
        value = dimMember.getLevelID();
        if(value!=null)
          node.addProperty(LEVEL_ID_PROP,value);

        value = dimMember.getLevelName();
        if(value!=null)
          node.addProperty(LEVEL_NAME_PROP,value);

        value = dimMember.getDimMemberID();
        if(value!=null)
          node.addProperty(MEMBER_ID_PROP,value);

        value = dimMember.toString();
        if(value!=null)
          node.addProperty(MEMBER_NAME_PROP,value);

        XMLObjectWriter xmlWriter = new XMLObjectWriter();
        xmlWriter.writeObjectNode(node);
        return xmlWriter.toString();
    }

}