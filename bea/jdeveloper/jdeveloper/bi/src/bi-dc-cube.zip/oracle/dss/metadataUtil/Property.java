/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

import java.io.Serializable;
import java.lang.Long;
import java.util.Enumeration;
import java.util.Vector;
import oracle.dss.bicontext.BIUtilities;

/**
 * @hidden
 * Represents a property of a metadata object.
 * The property can be a <code>String</code> property, an <code>int</code>
 * property, or an <code>Object</code> property.
 *
 * @status hidden
 */
public class Property implements Serializable
    {
    /////////////////////
    //
    // Private Members
    //
    /////////////////////

    // The name of the property
    private String m_Name = null;

    // The data type of the property. String, long, int or Object
    private int m_DataType = 0;

    // Properties of his property.
    private int m_Flags = 0;

    // The value of the property always store as Object type.
    private Object m_Value = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    /**
     * Constructor.
     *
     * @status documented
     */
    public Property()
        {
        }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Retrieves the name of this property.
     *
     * @return The property name, or <code>null</code> if no name has been set.
     *
     * @status documented
     */
    public String getName()
        {
        return m_Name;
        }

    /**
     * Specifies a name for this property.
     * Before you call this method, the name is <code>null</code>.
     *
     * @param name  The name that you want to give this property.
     *
     * @status documented
     */
    public void setName(String name)
        {
        m_Name = name;
        }

    /**
     * Retrieves the data type of this property.
     *
     * @return  A constant that represents the data type of this property.
     *          Possible values are listed in the See Also section.
     *          <code>STRING</code>
     *          <code>LONG</code>
     *          <code>INTEGER</code>
     *          <code>OBJ</code>
     *          <code>STRING_VECTOR</code>
     *          <code>ALL_DATATYPES</code>
     *
     * @see oracle.dss.metadataUtil.MDU#STRING
     * @see oracle.dss.metadataUtil.MDU#LONG
     * @see oracle.dss.metadataUtil.MDU#INTEGER
     * @see oracle.dss.metadataUtil.MDU#OBJ
     * @see oracle.dss.metadataUtil.MDU#STRING_VECTOR
     * @see oracle.dss.metadataUtil.MDU#ALL_DATATYPES
     *
     * @status New
     */
    public int getDataType()
        {
        return m_DataType;
        }

    /**
     * Set data type of this property
     *
     * @param  dataType     Interger representing dataType of this property.
     *                      Possible values are:
     *                      <code>STRING</code>
     *                      <code>LONG</code>
     *                      <code>INTEGER</code>
     *                      <code>OBJ</code>
     *                      <code>STRING_VECTOR</code>
     *                      <code>ALL_DATATYPES</code>
     *
     * @see oracle.dss.metadataUtil.MDU#STRING
     * @see oracle.dss.metadataUtil.MDU#LONG
     * @see oracle.dss.metadataUtil.MDU#INTEGER
     * @see oracle.dss.metadataUtil.MDU#OBJ
     * @see oracle.dss.metadataUtil.MDU#STRING_VECTOR
     * @see oracle.dss.metadataUtil.MDU#ALL_DATATYPES
     *
     * @status New
     */
    public void setDataType(int dataType)
        {
        m_DataType = dataType;
        return;
        }

    /**
     * Retrieve UI flag of this property
     *
     * @return  Interger representing UI flag of this property.
     *          Possible values are:
     *          <code>UI_VISIBLE</code>
     *          <code>UI_WRITE</code>
     *          <code>UI_DELETE</code>
     *          <code>UI_ENCRYPT</code>
     *          <code>UI_ALL</code>
     *          <code>UI_NONE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#UI_VISIBLE
     * @see oracle.dss.metadataUtil.MDU#UI_WRITE
     * @see oracle.dss.metadataUtil.MDU#UI_DELETE
     * @see oracle.dss.metadataUtil.MDU#UI_ENCRYPT
     * @see oracle.dss.metadataUtil.MDU#UI_ALL
     * @see oracle.dss.metadataUtil.MDU#UI_NONE
     *
     * @status New
     */
    public int getFlags()
        {
        return m_Flags;
        }

    /**
     * Set UI flag of this property
     *
     * @param flags Interger representing UI flag of this property.
     *              Possible values are:
     *              <code>UI_VISIBLE</code>
     *              <code>UI_WRITE</code>
     *              <code>UI_DELETE</code>
     *              <code>UI_ENCRYPT</code>
     *              <code>UI_ALL</code>
     *              <code>UI_NONE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#UI_VISIBLE
     * @see oracle.dss.metadataUtil.MDU#UI_WRITE
     * @see oracle.dss.metadataUtil.MDU#UI_DELETE
     * @see oracle.dss.metadataUtil.MDU#UI_ENCRYPT
     * @see oracle.dss.metadataUtil.MDU#UI_ALL
     * @see oracle.dss.metadataUtil.MDU#UI_NONE
     *
     * @status New
     */
    public void setFlags(int flags)
        {
        m_Flags = flags;
        return;
        }

    /**
     * Determines IDE visibility of this property
     *
     * @return  Boolean value representing IDE visibility of this property
     *          <code>true</code> if property is IDE visible
     *          <code>false</code> if property is not IDE visible
     *
     * @status New
     */
    public boolean isIDEVisible()
        {
        if (m_Flags == MDU.UI_NONE)
            return false;

        if (m_Flags == MDU.UI_ALL)
            return true;

        if ((m_Flags & MDU.UI_VISIBLE) != 0)
            {
            return true;
            }

        return false;
        }

    /**
     * Determines if IDE will display encrypted value of this property
     *
     * @return  <code>true</code>  if property is displayed in encrypted form
     *          <code>false</code> if property is displayed in non-encrypted
     *                             form
     *
     * @status New
     */
    public boolean isIDEEncrypt()
        {
        if (m_Flags == MDU.UI_NONE)
            return false;

        if (m_Flags == MDU.UI_ALL)
            return true;

        if ((m_Flags & MDU.UI_ENCRYPT) != 0)
            return true;

        return false;
        }

    /**
     * Determines if IDE has write permission to this property
     *
     * @return  <code>true</code>  if IDE has write permission to this property
     *          <code>false</code> if IDE does not have write permission to
     *                             this property form
     *
     * @status New
     */
    public boolean isIDEWrite()
        {
        if (m_Flags == MDU.UI_NONE)
            return false;

        if (m_Flags == MDU.UI_ALL)
            return true;

        if ((m_Flags & MDU.UI_VISIBLE) != 0)
            {
            if ((m_Flags & MDU.UI_WRITE) != 0)
                {
                return true;
                }
            }

        return false;
        }

    /**
     * Determines if IDE has delete permission to this property
     *
     * @return  <code>true</code>  if IDE has delete permission to this property
     *          <code>false</code> if IDE does not have delete permission to
     *                             this property form
     *
     * @status New
     */
    public boolean isIDEDelete()
        {
        if (m_Flags == MDU.UI_NONE)
            return false;

        if (m_Flags == MDU.UI_ALL)
            return true;

        if ((m_Flags & MDU.UI_VISIBLE) != 0)
            {
            if ((m_Flags & MDU.UI_DELETE) != 0)
                {
                return true;
                }
            }
        return false;
        }

    /**
     * Compares the given flag with UI fag of this property
     *
     * @return  <code>true</code>  if UI flag of this property is
     *                             same as given flag
     *          <code>false</code> if UI flag of this property is not
     *                             same as given flag
     *
     * @status New
     */
    public boolean is (int flags)
        {
        if (m_Flags == flags)
            return true;

        if (m_Flags == MDU.UI_NONE)
            return false;

        if ((m_Flags & flags) != 0)
            {
            return true;
            }

        return false;
        }

    /**
     * Retrieve string value of this property
     *
     * @return  string representing value of this property
     *
     * @status New
     */
    public String getStrValue()
        {
        if (m_Value != null)
            return m_Value.toString();

        return null;
        }

    /**
     * Retrieve long value of this property
     *
     * @return  long representing value of this property.
     *
     * @status New
     */
    public long getLongValue()
        {
        if (m_Value != null)
            {
            if (m_DataType == MDU.LONG)
                {
                Long longval = (Long) m_Value;
                if (longval != null)
                    {
                    return longval.longValue();
                    }
                }
            }

        return 0;
        }

    /**
     * Retrieve integer value of this property
     *
     * @return  Integer representing value of this property.
     *
     * @status New
     */
    public int getIntValue()
        {
        if (m_Value != null)
            {
            if (m_DataType == MDU.INTEGER)
                {
                Integer intval = (Integer) m_Value;
                if (intval != null)
                    {
                    return intval.intValue();
                    }
                }
            }
        return 0;
        }

    /**
     * Retrieve object stored in this property
     *
     * @return  Object representing value of this property.
     *
     * @status New
     */
    public Object getObjValue()
        {
        return m_Value;
        }

    /**
     * Set string value of this property
     *
     * @param name  Property name.
     * @param value String value of this property
     * @param flags UI flag of this property
     *
     * @status New
     */
    public void setStrValue (String name, String value, int flags)
        {
        setProperty (name, (Object) value, MDU.STRING, flags);
        return;
        }

    /**
     * Set long value of this property
     *
     * @param name  Property name.
     * @param value long value of this property
     * @param flags UI flag of this property
     *
     * @status New
     */
    public void setLongValue (String name, long value, int flags)
        {
        setProperty (name, (Object) new Long (value), MDU.LONG, flags);
        return;
        }

    /**
     * Set interger value of this property
     *
     * @param name  Property name.
     * @param value int value of this property
     * @param flags UI flag of this property
     *
     * @status New
     */
    public void setIntValue (String name, int value, int flags)
        {
        setProperty (name, (Object) new Integer (value), MDU.INTEGER, flags);
        return;
        }

    /**
     * Set object value of this property
     *
     * @param name  Property name.
     * @param value object value of this property
     * @param flags UI flag of this property
     *
     * @status New
     */
    public void setObjValue (String name, Object value, int flags)
        {
        setProperty (name, value, MDU.OBJ, flags);
        return;
        }

    /**
     * gek 12/04/00
     * Set a vector as value of this property
     *
     * @param name  Property name.
     * @param value vector value of this property
     * @param flags UI flag of this property
     *
     * @status New
     */
    public void setStringVectorValue (String name, Vector value, int flags)
        {
        setProperty (name, (Object) value, MDU.STRING_VECTOR, flags);
        return;
        }

    /**
     * gek 12/04/00
     * Retrieve string vector as value of this property
     *
     * @return string vector stored as value of this property
     *
     * @status New
     */
    public Vector getStringVectorValue()
        {
        if (m_Value != null)
            return (Vector) m_Value;

        return null;
        }

    /**
     * Set parameters of this property.
     *
     * @param name      Property name.
     * @param object    Object containing value of this property
     * @param dataType  Data type of this proeperty
     * @param flags     UI flag of this property
     *
     * @status New
     */
    public void setProperty (String name, Object object, int dataType, int flags)
        {
        m_Name = name;
        m_DataType = dataType;
        m_Value = object;
        m_Flags = flags;
        return;
        }

    /**
     * Retrieve string representing value of this property
     *
     * @return  String representation of this property
     *
     * @status New
     */
    public String toString()
        {
        return getStrValue();
        }

    /**
     *  gek 1/04/01
     *
     *  Determines if the specified property values can be found in this
     *  object's property list.
     *
     *  @param  property a <code>Property</code> value which represents property
     *          that we are searching for.
     *  @return <code>boolean</code> which is <code>true</code> when we have
     *          found the specified properties and <code>false</code>
     *          otherwise.
     *  @status New
     */
/*
    public boolean contains (Property property)
        {
        // Check for bad input parameters
        if (property == null)
            return false;

        // If we are performing a non-string based comparison, defer to
        // equals
        if (!isStringAndStringVector(getDataType(), property.getDataType()))
            return equals (property);
        else
            {
            // Verify that the names are the same
            if (getName().equals (property.getName()))
                {
                String strValue = null;
                Vector vValues = null;

                // Check this object
                switch (getDataType())
                    {
                    case MDU.STRING:
                        strValue = getStrValue();
                        break;

                    case MDU.STRING_VECTOR:
                        vValues = getStringVectorValue();
                        break;

                    default:
                        break;
                    }

                // Check the passed in property object
                switch (property.getDataType())
                    {
                    case MDU.STRING:
                        strValue = property.getStrValue();
                        break;

                    case MDU.STRING_VECTOR:
                        vValues = property.getStringVectorValue();
                        break;

                    default:
                        break;
                    }

                // Determine if the string can be found in the string vector
                return containsString (strValue, vValues);
                }
            }

        return false;
        }
*/
    /**
     *  gek 1/04/01
     *
     *  Determines if the specified property values can be found in this
     *  object's property list.  This routine will only return <code>true</code>
     *  if ALL values in the property can be found.
     *
     *  @param  property a <code>Property</code> value which represents property
     *          that we are searching for.
     *  @return <code>boolean</code> which is <code>true</code> when we have
     *          found the specified properties and <code>false</code>
     *          otherwise.
     *  @status New
     */
    public boolean equals (Property property)
        {
        if(property == null)
        {
            return false;
        }
        if ((getName().equals (property.getName())) &&
            (getDataType() == property.getDataType()))
            {
            if ((getDataType() == MDU.LONG) &&
                (getLongValue() == property.getLongValue()))
                return true;
            else if ((getDataType() == MDU.INTEGER) &&
                     (getIntValue() == property.getIntValue()))
                return true;
            else if ((getDataType() == MDU.STRING) &&
                     (getStrValue() != null &&
                      getStrValue().equals (property.getStrValue())))
                return true;
            else if ((getDataType() == MDU.OBJ) &&
                     (getObjValue() == property.getObjValue()))
                return true;
/*
            else if (equalStringVector (property))
                return true;
*/
            else if (getDataType() == MDU.STRING_VECTOR)
                return equalStringVector(property);
            }

        return false;
        }

    /**
     * Clear this property and any references it is holding
     *
     * @status New
     */
    public void free()
        {
        m_Name  = null;
        m_Value = null;
        return;
        }

    /////////////////////
    //
    // Protected Methods
    //
    /////////////////////

    /////////////////////
    //
    // Private Methods
    //
    /////////////////////

    /**
     *  gek 1/04/01
     *
     *  Determines if the specified string value can be found in the specified
     *  string vector.  The strings are case sensitive.
     *
     *  @param  strValue a <code>String</code> value which represents string
     *          that we are searching for.
     *  @param  vValues <code>Vector</code> value which represents the vector
     *          of strings to search.
     *  @return <code>boolean</code> which is <code>true</code> when we have
     *          found the specified string and <code>false</code> otherwise.
     *  @status New
     */
    public boolean containsString (String strValue, Vector vValues)
        {
        if ((strValue != null) &&
            (vValues != null) && !vValues.isEmpty())
            {
            // Check the value against each value in the string vector
            Enumeration enumeration = vValues.elements();
            while (enumeration.hasMoreElements())
                {
                // Check to see if the string value is present in the vector
                // list.

                // gek 03/07/01 Fix problem of custom measures always retrieving
                //              the label of the first custom measure added.
                    
                // For some strange reason, I need to put the result of the
                // enumeration into a string varible before comparison or the
                // result will always be true!
                String strEnum = (String)enumeration.nextElement();
                if (strValue.equals (strEnum))
                    {

                    // Found it
                    return true;
                    }
                }
            }

        return false;
        }
    /**
     *  gek 12/04/00
     *
     *  Determines if the specified property values can be found in this
     *  object's string vector.  This routine will only return <code>true</code>
     *  if ALL values in the property vector can be found.
     *
     *  @param  property a <code>Property</code> value which represents property
     *          that we are searching for.
     *  @return <code>boolean</code> which is <code>true</code> when we have
     *          found the specified properties and <code>false</code>
     *          otherwise.
     *  @status New
     */
    private boolean equalStringVector (Property property)
        {
        // Retrieve vector of strings
        Vector vectorProperty = property.getStringVectorValue();

        // Verify that the string vector is not empty
        if (vectorProperty != null && !vectorProperty.isEmpty())
            {
            // Iterate over each string
            Enumeration enumerationProperty = vectorProperty.elements();
            while (enumerationProperty.hasMoreElements())
                {
                boolean bFound = false;

                String strProperty =
                    (String)enumerationProperty.nextElement();

                // Retrieve vector of strings
                Vector vector = getStringVectorValue();

                // Verify that the string vector is not empty
                if (vector != null && !vector.isEmpty())
                    {
                    bFound = (containsString (strProperty, vector));
                    }

                if (!bFound)
                    return false;
                }

            return true;
            }
        return false;
        }

    /**
     * @hidden
     * Checks for equality that considers wild card and case sensitivity
     */
    public boolean equalsString(Property property, boolean isCaseSensitive)
    {
        if (property == null)
            return false;
        else
            return BIUtilities.equals(getStrValue(), property.getStrValue(), isCaseSensitive);
    }

    /**
     *  gek 1/04/01
     *
     *  Determines if the specified datatypes represent a <code>MDU.STRING</code>
     *  and a <code>MDU.STRING_VECTOR</code>.
     *
     *  @param  nDataType1 a <code>int</code> value which represents the first
     *          data type to check.
     *  @param  nDataType2 a <code>int</code> value which represents the second
     *          data type to check.
     *  @return <code>boolean</code> which is <code>true</code> when we have
     *          found the specified properties and <code>false</code>
     *          otherwise.
     *  @status New
     */
/*
    private boolean isStringAndStringVector (int nDataType1, int nDataType2)
        {
        return (nDataType1 == MDU.STRING && nDataType2 == MDU.STRING_VECTOR) ||
               (nDataType1 == MDU.STRING_VECTOR && nDataType2 == MDU.STRING);
        }
    }
*/
}
