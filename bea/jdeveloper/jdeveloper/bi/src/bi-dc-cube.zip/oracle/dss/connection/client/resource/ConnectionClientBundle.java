/*
** Copyright (c) 2006, 2010, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.client.resource;

// Imports
import java.util.ListResourceBundle;

/**
 * @hidden
 * Resources for Connection bean.
 * @status hidden
 */
public class ConnectionClientBundle extends ListResourceBundle
{
    // Connection messages have been assigned a range
    // from DVT-16000 to DVT-16999.
    // Connection Client messages start at DVT-16000
    public static final String EXC_NO_BISESSION             = "16001";
    public static final String EXC_CONNECT_NOT_INITIALIZED  = "16002";
    public static final String EXC_SET_CONN_OBJ_FAILED      = "16003";
    public static final String EXC_NON_SERIALIZABLE_OBJ     = "16004";

    static final Object[][] sMessages =  {
        /**
         * @error DVT-16001 <code>BISession</code> is not specified.
         * @cause An instance of <code>BISession</code> was not set on the <code>Connection</code> object.
         * @action Set a <code>BISession</code> on the <code>Connection</code> object using the <code>setSession</code> method.
         * @status documented
         */
        { EXC_NO_BISESSION, "BISession is not specified." },

        /**
         * @error DVT-16002 Operation is incomplete because there is no database connection.
         * @cause The connection was not initialized.
         * @action Invoke the <code>connect</code> method before performing this operation.
         * @status documented
         */
        { EXC_CONNECT_NOT_INITIALIZED, "Operation is incomplete because there is no database connection." },

        /**
         * @error DVT-16003 cannot set the connection object because a connection already exists
         * @cause Could not set the connection object because a connection already exists.
         * @action Disconnect and set the connection object again.
         * @status documented
         */
        { EXC_SET_CONN_OBJ_FAILED, "cannot set the connection object because a connection already exists" },

        /**
         * @error DVT-16004 The operation cannot complete because the object retrieved is a nonserializable object.
         * @cause The operation was not completed because the retrieved object was not serializable.
         * @action Retrieve an object only if it does not require serialization.
         * @status documented
         */
        { EXC_NON_SERIALIZABLE_OBJ, "The operation cannot complete because the object retrieved is a nonserializable object." }
    };

   /**
    * Return the string resource table.
    *
    * @status protected
    */
    protected Object[][] getContents() {
        return sMessages;
    }
}
