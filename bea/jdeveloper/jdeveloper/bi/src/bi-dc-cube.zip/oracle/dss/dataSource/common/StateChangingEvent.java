/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.Operation;
import oracle.dss.util.AbstractMap;

/**
 * Informs listeners that the state of a <code>Query</code> object is about to
 * be changed.
 * A listener can veto this change by calling the <code>consume</code> method
 * of this class.
 *
 * @status Documented
 */
public class StateChangingEvent extends StateChangeEvent implements Consumable
{
    /**
     * Constructs the event.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param type   A constant (<code>StateChangeEvent.STATE</code>) that represents the
     *               type of state change that is proposed for the
     *               <code>Query</code> object.
     *
     * @see StateChangeEvent#STATE
     *
     * @status Documented
     */
    public StateChangingEvent(Object source, int type) {
        super(source, (Operation)null, type);
    }

    /**
     * Constructs the event with maps for a change in one or more dimensions.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of the dimension of the map that is involved;
     *               <code>null</code indicates all dimensions.
     * @param m      The <code>Map</code> object that will be applied or set.
     * @param t      A constant <<code>StateChangeEvent.DATA_MAP</code> or
     *               <code>StateChangeEvent.METADATA_MAP</code>) that
     *               represents the type of map state change for the
     *               <code>Query</code> object.
     *
     * @see StateChangeEvent#DATA_MAP
     * @see StateChangeEvent#METADATA_MAP
     *
     * @status Documented
     */
    public StateChangingEvent(Object source, String d, AbstractMap m, int t) {
        super(source, d, m, t);
    }

    /**
     * Constructs the event with maps for a change on a specific edge of the
     * <code>Query</code> object.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param e      A constant (such as <code>DataDirector.ROW_EDGE</code>)
     *               that represents the edge of the map that has changed.
     * @param m      The <code>Map</code> object that will be applied or set.
     * @param t      A constant (<code>StateChangeEvent.DATA_MAP</code>, or
     *               <code>StateChangeEvent.METADATA_MAP</code>) that indicates
     *               the type of map state change to the
     *               <code>Query</code> object.
     *
     * @see StateChangeEvent#DATA_MAP
     * @see StateChangeEvent#METADATA_MAP
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public StateChangingEvent(Object source, int e, AbstractMap m, int t) {
        super(source, e, m, t);
    }

    /**
     * Constructs the event with a selection.
     *
     * @param source Source of the event, that is, a reference to the object
     *               that fired the event.
     * @param d      The name of a dimension of the universe selection that is
     *               involved in the query change.
     * @param s      The new selection to which the query is changing.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public StateChangingEvent(Object source, String d, Selection s) {
        super(source, d, s);        
    }*/

    /**
     * Consumes this event.
     *
     * @status Documented
     */
    public void consume() {
        super.consume();
    }
    
    /**
     * Indicates whether this event was consumed.
     *
     * @return <code>true</code> if the event was consumed,
     *         <code>false</code> if not.
     *
     * @status Documented
     */
    public boolean isConsumed() {
        return super.isConsumed();
    }        
}
