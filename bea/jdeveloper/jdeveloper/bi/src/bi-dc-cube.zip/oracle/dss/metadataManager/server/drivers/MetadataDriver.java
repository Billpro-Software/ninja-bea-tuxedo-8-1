/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.server.drivers;

// Imports
import java.util.Hashtable;

import javax.naming.directory.Attributes;
import javax.naming.Name;

import oracle.dss.util.persistence.Persistable;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDRoot;
import oracle.dss.metadataManager.common.MetadataProvider;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.connection.server.drivers.ConnectionDriver;

// Interface that needs to be implemented by all metadata drivers.
/**
 * @hidden
 */
public interface MetadataDriver extends MetadataProvider
{
   /************************************************************************
    * ConnectionDriver related Operations
    ************************************************************************/
	// Set a connection Driver to this metadata driver
    // High Priority
    public int setConnectionDriver( ConnectionDriver connectionDriver) throws MetadataManagerException;

	// Get the Connection Driver
    // High Priority
    public ConnectionDriver getConnectionDriver() throws MetadataManagerException;

    // High Priority
    public String getConnectionString() throws MetadataManagerException;

    // High Priority
    public String getDriverType() throws MetadataManagerException;

   /************************************************************************
    * Attach and Detach Operations
    ************************************************************************/
	// Attach the Driver
    // High Priority
    public int attach() throws MetadataManagerException;

    // High Priority
    public PropertyBag attach ( PropertyBag propertyBag ) throws MetadataManagerException;

	// Detach the Driver
    // High Priority
    public int detach() throws MetadataManagerException;

    // High Priority
	public PropertyBag detach (PropertyBag properties) throws MetadataManagerException;

	// Is this Driver Attached?
    // High Priority
    public boolean isAttached();

    // High Priority
    public String getDatabaseString();

    // High Priority
    public int setDatabaseString( String databaseString) throws MetadataManagerException;

	// Get the root object. usually an MDFolder.
    // High Priority
	public MDObject getRoot();

	// This method is used for re-setting th root at the driver level.
    // Medium Priority
	public int setRoot( MDObject mdObject );

  /************************************************************************
  * Support for User Objects ( for example XML object of Graph)
  * from the driver based on an MDObject.
  ************************************************************************/

    public UserObject getUserObject( MDObject mdObject, String relation, Hashtable args ) throws MetadataManagerException;

    public int setUserObject( MDObject mdObject, UserObject userObject ) throws MetadataManagerException;

    public int removeUserObject( MDObject mdObject ) throws MetadataManagerException;

   /************************************************************************
    * Set MetadataManager Services
    ************************************************************************/
    public int setMetadataManagerServices( MetadataManagerServices metadataManagerServices ) ;

    public MetadataManagerServices getMetadataManagerServices();

    /**
     * @hidden
     */
    public void setLoadParameter(String loadType);

    /**
     * @hidden
     */
    public boolean isDeferredLoad();

    /**
     * @hidden
     */
    public boolean isAsynchronousLoad();

    /**
     * @hidden
     */
    public MDRoot addToObjectModel(MDRoot mdRoot) throws MetadataManagerException;

    public boolean isAsyncLoadComplete() throws MetadataManagerException;

    public MDObject addChildren(MDObject parent, boolean isRecursive)
                                                throws MetadataManagerException;
    public MDObject addRelatives(MDObject parent, boolean isRecursive, boolean isCalledFromDriver)
                                                throws MetadataManagerException;
    public MDObject getMDObject(String uniqueID) throws MetadataManagerException;

    public MDObject getMDObject(Persistable persistable) throws MetadataManagerException;

    //public ObjectFactory getObjectFactory();


    // New methods
    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException;
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attributes, String bindOption, Hashtable env) throws MetadataManagerException;
    public Object lookup(MDFolder folder, Name name, Hashtable args, Attributes options) throws MetadataManagerException;
    public Object getObject(String id, Hashtable env) throws MetadataManagerException;
    public void refresh(MDObject mdObject) throws MetadataManagerException;
    
    public void deferredObjectSetUp(MDObject obj) throws MetadataManagerException;
    public void addMDObject(MDObject mdObject) throws MetadataManagerException;
}
