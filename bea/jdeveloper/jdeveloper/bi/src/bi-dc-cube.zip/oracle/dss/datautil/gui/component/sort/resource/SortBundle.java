/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/resource/SortBundle.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui.component.sort.resource;

import java.util.ListResourceBundle;

/**
 * @hidden
 *
 * <pre>
 * Sort dialog resources.
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   09/11/07 - Remove sort mnemonics.
 *    gkellam   07/16/07 - More DataFilter GUI bug fixes.
 *    gkellam   04/24/07 - Additional Sort Dialog updates.
 *
 */
public class SortBundle extends ListResourceBundle {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  //................................
  // <code>SortPanel</code> resources
  //................................

  public static final String SORTPANEL_TABLE_DESCRIPTION = "SORTPANEL_TABLE_DESCRIPTION";
  public static final String SORTPANEL_CROSSTAB_DESCRIPTION = "SORTPANEL_CROSSTAB_DESCRIPTION";
  
  //................................
  // <code>SortDialog</code> resources
  //................................
  public static final String SORTDIALOG_TITLE = "SORTDIALOG_TITLE";

  //................................
  // <code>SortTable</code> resources
  //................................
  public static final String SORTTABLE_SORT_BY = "SORTTABLE_SORTBY";
  public static final String SORTTABLE_THEN_BY = "SORTTABLE_THENBY";
  public static final String SORTTABLE_TABLE_ITEM = "SORTTABLE_TABLE_ITEM";
  public static final String SORTTABLE_TABLE_DIRECTION = "SORTTABLE_TABLE_DIRECTION";
  public static final String SORTTABLE_TABLE_GROUP = "SORTTABLE_TABLE_GROUP";
  public static final String SORTTABLE_CROSSTAB_ITEM = "SORTTABLE_CROSSTAB_ITEM";
  public static final String SORTTABLE_CROSSTAB_DIRECTION = "SORTTABLE_CROSSTAB_DIRECTION";
  public static final String SORTTABLE_PANEL_ADD = "SORTTABLE_PANEL_ADD";
  public static final String SORTTABLE_PANEL_DELETE = "SORTTABLE_PANEL_DELETE";
  public static final String SORTTABLE_PANEL_CLEAR = "SORTTABLE_PANEL_CLEAR";
  public static final String SORTTABLE_MOVE_UP = "SORTTABLE_MOVE_UP";
  public static final String SORTTABLE_MOVE_DOWN = "SORTTABLE_MOVE_DOWN";
  public static final String SORTTABLE_CRITERIA = "CRITERIA";

  //................................
  // <code>SortModel</code> resources
  //................................

  public static final String SORTPANEL_MODEL_TABLE_ASCENDING = "SORTPANEL_MODEL_TABLE_ASCENDING";
  public static final String SORTPANEL_MODEL_TABLE_DESCENDING = "SORTPANEL_MODEL_TABLE_DESCENDING";
  public static final String SORTPANEL_MODEL_CROSSTAB_ASCENDING = "SORTPANEL_MODEL_CROSSTAB_ASCENDING";
  public static final String SORTPANEL_MODEL_CROSSTAB_DESCENDING = "SORTPANEL_MODEL_CROSSTAB_DESCENDING"; 

  /////////////////////
  //
  // Members
  //
  /////////////////////

  static final Object[][] m_strResources = {
    // Sort Dialog
    {SORTDIALOG_TITLE, "Sort"},
    
    // Sort Panel
    {SORTPANEL_TABLE_DESCRIPTION, "Specify the sort criteria for the columns in your table."},
    {SORTPANEL_CROSSTAB_DESCRIPTION, "Specify an item and sort criteria for that item."},
    
    // Sort Table
    {SORTTABLE_SORT_BY, "Sort By"},
    {SORTTABLE_THEN_BY, "Then By"},
    {SORTTABLE_TABLE_ITEM, "Sort"},
    {SORTTABLE_TABLE_DIRECTION, "Direction"},
    {SORTTABLE_TABLE_GROUP, "Group Duplicates"},
    {SORTTABLE_CROSSTAB_ITEM, "Sort"},
    {SORTTABLE_CROSSTAB_DIRECTION, "Direction"},
    {SORTTABLE_PANEL_ADD, "&Add"},
    {SORTTABLE_PANEL_DELETE, "&Delete"},
    {SORTTABLE_PANEL_CLEAR, "&Clear All"},

    {SORTTABLE_MOVE_UP, "Move Sort &Up"},
    {SORTTABLE_MOVE_DOWN, "Move Sort Do&wn"},

    {SORTTABLE_CRITERIA, "C&riteria:"},

    // Model
    {SORTPANEL_MODEL_TABLE_ASCENDING, "Ascending"},
    {SORTPANEL_MODEL_TABLE_DESCENDING, "Descending"},

    {SORTPANEL_MODEL_CROSSTAB_ASCENDING, "Ascending"},
    {SORTPANEL_MODEL_CROSSTAB_DESCENDING, "Descending"}

  };
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////
  
  public Object[][] getContents() {
    return m_strResources;
  }  
}