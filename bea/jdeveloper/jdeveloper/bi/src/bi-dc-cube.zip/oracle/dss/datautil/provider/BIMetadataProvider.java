/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/provider/BIMetadataProvider.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.provider;

import java.util.Enumeration;
import java.util.Vector;

import javax.naming.directory.DirContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BISearchResult;

import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.ConnectionException;

import oracle.dss.dataSource.client.QueryClient;

import oracle.dss.datautil.QueryContext;
import oracle.dss.datautil.QueryEditor;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MetadataManagerException;

import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.Utility;

/**
 * <pre>
 * Default <code>MetadataProvider</code> implementation for BI Beans.
 * </pre>
 *
 * @see oracle.dss.datautil.provider.DataProvider
 * 
 * @author gkellam 
 * @since  11.0.0.0.3
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *  bmoroze     01/05/06 - 
 *  dbajpai     12/15/05 - basic infrastructure for function DnD and loading 
 *                         function metadata 
 *  dbajpai     12/15/05 - 
 *  rbalexan    10/24/05 - Filter out measure dimension
 *  gkellam     10/11/05 - Work around bug 4616157: Avoid OLAP attribute 
 *                         searching by selecting Relational datasource. 
 *  jramanat    09/29/05 - 
 *  dbajpai     09/26/05 - initial cut at adding split panes to the expression 
 *                         panel ui 
 *  dbajpai     09/26/05 - Change runtime datasource root to BIContext 
 *  dbajpai     09/21/05 - add methods to track current datasource, 
 *                         runtimedatasource and catalog root 
 *  dbajpai     09/21/05 - add methods to track current datasource, 
 *                         runtimedatasource 
 *  jramanat    09/02/05 - Allow retrieval of items from QueryContext 
 *  jramanat    09/01/05 - 
 *  gkellam     08/22/05 - 
 *  rbalexan    08/12/05 - 
 *  rbalexan    07/12/05 - fill in interface methods 
 *  rbalexan    07/07/05 - 
 *  gkellam     06/23/05 - Initial R11 CalcBuilder framework. 
 *  gkellam     06/17/05 - Creation  
 */

public class BIMetadataProvider implements MetadataProvider {

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  /**
   * @hidden
   * @status hidden
   */
  private BIProvider m_biProvider = null;

  /**
   * @hidden
   * @status hidden
   */
  protected MDFolder m_currentDatasourceRootFolder;

  /**
   * @hidden
   * @status hidden
   */
  protected BIContext m_currentRuntimeDatasourceRootFolder;

  /**
   * @hidden
   */
  protected MDFolder m_functionsRootFolder = null;
  
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default constructor.
   *
   * @status new
   */
  public BIMetadataProvider () {
  }

  /**
   * Constructor.
   *
   * @param biProvider A <code>BIProvider</code> used to retrieve data. 
   *
   * @status new
   */
  public BIMetadataProvider (BIProvider biProvider) {
		setBIProvider (biProvider);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the available data sources.
   *
   * @return A <code>Vector</code> which represents the list of available data sources.
   *
   * @status new
   */
   public Vector getDatasources() {
    Vector datasources = new Vector();
    
    if (getBIProvider() != null) {
        MetadataManager metadataManager = 
          (MetadataManager)getBIProvider().getProperty (BIProvider.METADATA_MANAGER);
        
        if (metadataManager != null) {
          try {
            NamingEnumeration namingEnumeration = metadataManager.getDatasources();
            if (namingEnumeration != null) {
              Object object;

              while (namingEnumeration.hasMoreElements()) {
                object = namingEnumeration.next();
                if ((object != null) && (object instanceof BISearchResult)) {
                  datasources.addElement((BISearchResult)object);
                }
              }
            }
          } 
          catch (Exception e) {
            e.printStackTrace();
          }
      }
    }
    return datasources;
  }
    
  public Object getObjectByUniqueId(String strUniqueId) {
    if (getBIProvider() != null) {
      MetadataManager metadataManager = 
        (MetadataManager)getBIProvider().getProperty (BIProvider.METADATA_MANAGER);
      
      if (metadataManager != null) {
        try {
            return metadataManager.getMDObjectByUniqueID (strUniqueId);
        }
        
        catch (Exception e) {
          e.printStackTrace();
        }
      }
    }   

    return null;
  }
        
  public DirContext getRoot() {
    if (getBIProvider() != null) {
      
      MetadataManager metadataManager = 
        (MetadataManager)getBIProvider().getProperty (BIProvider.METADATA_MANAGER);
      
      if (metadataManager != null) {
        return metadataManager.getMDRoot();
      }
    }

    return null;
  }
    
  public Object getDimensionByUniqueId(String strUniqueId) {
    if (getBIProvider() != null) {
      MetadataManager metadataManager= 
        (MetadataManager)getBIProvider().getProperty (BIProvider.METADATA_MANAGER);
      
      if (metadataManager != null) {
        try {
          return metadataManager.getDimensionByUniqueID (strUniqueId);
        }
        
        catch (Exception e) {
          e.printStackTrace();
        }
      }
    }
    
    return null;
  }
    
    public Vector getItemIds(boolean data, boolean nondata) {
        if (getBIProvider() != null) {
            String[] strItemIds = null;
            QueryEditor queryEditor = (QueryEditor)getBIProvider().getProperty(BIProvider.QUERY_EDITOR);
            if (queryEditor != null) {
                String[] strDataItems = data ? queryEditor.getDataItems(LayerMetadataMap.LAYER_METADATA_NAME) : null;
                String[] strItems = nondata ? queryEditor.getItems(LayerMetadataMap.LAYER_METADATA_NAME) : null;
                strItemIds = Utility.combineArrays(strDataItems, strItems);
            }
            else {
                QueryContext queryContext = getBIProvider().getQueryContext();
                if (queryContext != null && queryContext instanceof QueryClient) {
                    QueryClient queryClient = (QueryClient)queryContext;
                    String[] strDataItems = data ? queryClient.getDataItems() : null;
                    String[] strItems = nondata ? queryClient.getItems() : null;
                    strItemIds = Utility.combineArrays(strDataItems, strItems);
                }
            }
            if (strItemIds != null) {
                Vector itemIds = Utility.copyArrayToVector(strItemIds);
                MetadataManager metadataManager = (MetadataManager)getBIProvider().getProperty(BIProvider.METADATA_MANAGER); 
                if (metadataManager != null) {
                    try {
                        MDDimension mdMeasureDimension = metadataManager.getMeasureDimension(null);
                        if (mdMeasureDimension != null) {
                            itemIds.remove(mdMeasureDimension.getUniqueID());
                        }
                    }
                    catch (MetadataManagerException mme) {
                        mme.printStackTrace();
                    }
                }
                return itemIds;
            }
        }   
        return null;
    }
    
  public Vector getItemObjects(boolean data, boolean nondata) {
    if (getBIProvider() != null) {
      Vector vItemIDs = getItemIds(data, nondata);
      
      if (vItemIDs != null) {
        Vector mdItems = new Vector();
        Object object;
        
        MetadataProvider metadataProvider = 
          (MetadataProvider)getBIProvider().makeMetadataProvider();
        
        if (metadataProvider != null) {
          for (Enumeration enumeration = vItemIDs.elements(); enumeration.hasMoreElements(); ) {
            object = enumeration.nextElement();
            
            if (object != null) {
              object = metadataProvider.getObjectByUniqueId (object.toString());
              if (object != null) {
                  mdItems.addElement (object);
              }
            }
          }
          
          return mdItems;
        }
      }
    }
    return null;
  }

  /**
   * Specfies the <code>BIProvider</code>.
   * 
   * @param biProvider A <code>BIProvider</code> that provides data.
   * 
   * @status new 
   */
  public void setBIProvider (BIProvider biProvider) { 
    m_biProvider = biProvider; 
  }

  /**
   * Retrieves the <code>BIProvider</code>.
   * 
   * @return A <code>BIProvider</code> that provides data.
   * 
   * @status new 
   */
  public BIProvider getBIProvider() { 
    return m_biProvider; 
  }

  // javadoc from interface
  public MDFolder getCurrentDatasourceRootFolder() {
    // return the first connection root if nothing is specified here...
    if (null == m_currentDatasourceRootFolder) {
      if (null == getBIProvider() || null == getBIProvider().getMetadataManager())
        return null;
    
      try {
        NamingEnumeration eDatasources = getBIProvider().getMetadataManager().getDatasources();
        if (!eDatasources.hasMore())
          return null;
        
        Object firstDsObject = eDatasources.next();
        if (null == firstDsObject || 
            !BISearchResult.class.isAssignableFrom(firstDsObject.getClass())) {
            return null;
        }
        
        Object firstConnObject = ((BISearchResult)firstDsObject).getObject();
        if (null == firstConnObject || 
            !Connection.class.isAssignableFrom(firstConnObject.getClass())) {
            return null;
        }
        
        return ((Connection)firstConnObject).getRoot();
      }
      catch (MetadataManagerException mme) {
        // TODO - error reporting... there is no ErrorHandler on BIProvider
      }
      catch (NamingException ne) {
        // TODO - error reporting... there is no ErrorHandler on BIProvider
      }
      catch (ConnectionException e) {
        // TODO - error reporting... there is no ErrorHandler on BIProvider
      }
      return null;
    }

    return m_currentDatasourceRootFolder;
  }

  /**
   * Sets the root folder of the current runtime datasource based on its name.
   * 
   * @param strDataSourceName A <code>String</code> which represents the case 
   *        insensitive name of the DataSource.
   *        
   * @throws <code>ConnectionException</code> or <code>MetadataManagerException</code>
   *         if root folder cannot be set.       
   *        
   */
  public void setCurrentRuntimeDatasourceRootFolderByName (String strDataSourceName) 
                          throws ConnectionException, MetadataManagerException {
    
    // Attempt to retrieve the DataSource Connection by name
    Connection connection = getDataSourceByName (strDataSourceName);

    // Attempt to specify the current DataSource root folder based on the 
    // Connection root.
    if (connection != null) {
      setCurrentDatasourceRootFolder (connection.getRoot());
    }
  }

  // javadoc from interface
  public void setCurrentDatasourceRootFolder (MDFolder folder) {
    m_currentDatasourceRootFolder = folder;
  }

  public BIContext getCurrentRuntimeDatasourceRootFolder() {
    return m_currentRuntimeDatasourceRootFolder;
  }

  public MDFolder getBICatalogRootFolder() {
    if (null == getBIProvider() || null == getBIProvider().getMetadataManager())
      return null;
      
    return getBIProvider().getMetadataManager().getMDRoot();
  }

  public void setCurrentRuntimeDatasourceRootFolder(BIContext folder) {
    m_currentRuntimeDatasourceRootFolder = folder;
  }
  
  public String getHierarchy(String dimension) {
    if (getBIProvider() != null && getBIProvider().getQueryEditor() != null) {
          // blm - Selection code moved to dvt-olap
/*      try {
        Selection sel = getBIProvider().getQueryEditor().getSelection(dimension, 0);
        if (sel != null) {
          return sel.getHierarchy();
        }
      }
      catch (QueryEditorException e) {
        
      }
    }
    if (getBIProvider() != null && getBIProvider().getQueryContext() != null && getBIProvider().getQueryContext() instanceof QueryClient) {
      QueryClient query = (QueryClient)getBIProvider().getQueryContext();
      Selection sel = query.findSelection(dimension);
      if (sel != null) {
        return sel.getHierarchy();
      }
    }
    if (getBIProvider() != null && getBIProvider().getMetadataManager() != null) {
      try {
        MDDimension mdDim = getBIProvider().getMetadataManager().getDimensionByUniqueID(dimension);
        if (mdDim != null) {
          MDHierarchy hierarchy = mdDim.getDefaultHierarchy();
          if (hierarchy != null) {
            return hierarchy.getUniqueID();
          }
        }
      }
      catch (MetadataManagerException mme) {
        
      }*/
    }
    return null;
  }

  /**
   * <pre>
   * Retrieves the <code>Connection</code> associated with the specified 
   * DataSource name.
   * 
   * The root of the DataSource can be set by using the following API:
   *  
   * setCurrentDatasourceRootFolder (connection.getRoot());
   *
   * </pre>
   * 
   * @param strName A <code>String</code> which represents the case insensitive 
   *        name of the DataSource to retrieve.
   * 
   * @return <code>Connnection</code> associated with the specified 
   *         DataSource name or null.
   *
   * @throws <code>MetadataManagerException</code> if DataSource cannot be retrieved.
   * 
   * @see #setCurrentDatasourceRootFolder(BIContext)
   * 
   * @status new        
   */
  public Connection getDataSourceByName (String strName) throws MetadataManagerException {
    Connection connectionDataSource = null;
    MetadataManager metadataManager = null;
    
    // Attempt to retrieve MetadataManager 
    if (getBIProvider() != null) {
      metadataManager = getBIProvider().getMetadataManager();  
    }

    // Validate parameters        
    if ((metadataManager != null) && (strName != null)) {
      Object objDataSource = null;
      Object objConnection = null;
      
      // Iterate over all datasource until name is found or we have reached 
      // the end.
      NamingEnumeration enumDataSources = metadataManager.getDatasources();

      while (enumDataSources.hasMoreElements ()) {
        objDataSource = enumDataSources.nextElement();

        if ((objDataSource != null) && (objDataSource instanceof BISearchResult)) {
          
          // Determine if the name matches
          if (strName.equalsIgnoreCase(((BISearchResult)objDataSource).getName())) {
            if (BISearchResult.class.isAssignableFrom (objDataSource.getClass())) {
              objConnection = ((BISearchResult)objDataSource).getObject();

              // Determine if found object represents a valid Connection
              if ((objConnection != null) && 
                Connection.class.isAssignableFrom (objConnection.getClass())) {
                connectionDataSource = (Connection)objConnection;
                break;
              }
            }
          }
        }
      }
    }

    return connectionDataSource;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  public MDFolder getFunctionsRootFolder() {
    return m_functionsRootFolder;
  }

  public void setFunctionsRootFolder(MDFolder folder) {
    m_functionsRootFolder = folder;
  }
}
