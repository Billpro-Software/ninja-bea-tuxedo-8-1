/*
 * TabbedPanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.BorderLayout;
import java.awt.Component;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import oracle.dss.datautil.client.DataUtilException;
import oracle.dss.datautil.client.DataUtilRuntimeException;
import oracle.dss.datautil.client.resource.DataUtilClientBundle;

import oracle.dss.datautil.gui.TabbedPanelComponent;

import oracle.dss.datautil.gui.panel.StandardPanel;

import oracle.dss.datautil.Timer;


/**
 * @hidden
 * The TabbedPanel class extends JPanel. In its constructor, it takes an array
 * of components. If this array contains more than a single component, then each
 * one is added to a JTabbedPane, which is then added to the main panel. If this
 * array contains only one component, it is simply added to the main panel.
 *
 * @status hidden
 *
 */
public class TabbedPanel extends JPanel
{
    private int m_nCurIndex     = -1;

    private JTabbedPane m_tabbedPane = null;
    // Components displayed on the JTabbedPane
    private Vector m_vComponents = null;
    
    public TabbedPanel(Vector comps)
    {
        setLayout(new BorderLayout());

        if (comps != null)
        {
        	m_vComponents = comps;
        	
            if (comps.size() == 1)
            {
                if (comps.elementAt(0) instanceof StandardPanel ||
                    comps.elementAt(0) instanceof TabbedPanelComponent )
                {
                    add((Component)comps.elementAt(0), BorderLayout.CENTER);
                }
            }
            else if (comps.size() > 1)
            {
                // There is more than one component, so create a JTabbedPane.
                m_tabbedPane = new JTabbedPane();
                for (Enumeration e = comps.elements(); e.hasMoreElements(); )
                {
                    try
                    {
                        Object comp = e.nextElement ( );
                        if ( comp instanceof StandardPanel )
                        {
                            StandardPanel panel = ( StandardPanel ) comp;
                            m_tabbedPane.addTab ( panel.getTitle ( ), 
                                                  panel.getImageIcon ( ), 
                                                  ( Component ) comp, 
                                                  panel.getTitle ( ) );
                        }                            
                        else if ( comp instanceof TabbedPanelComponent )
                        {
                            TabbedPanelComponent panel = ( TabbedPanelComponent ) comp;
                            m_tabbedPane.addTab ( panel.getTitle ( ), 
                                                  panel.getImageIcon ( ), 
                                                  ( Component ) comp, 
                                                  panel.getTitle ( ) );
                        }
                        
                    	if (comp instanceof JComponent)
		        		{
		                	((JComponent)comp).setBorder(new StandardBorder());
		        		}
                    }
                    catch (ClassCastException ex)
                    {
                        System.out.println("Object must implement StandardPanel: " + ex);
                    }
                }
                // Listen for the tab selection changes
				m_tabbedPane.addChangeListener(new TabsListener());

                add(m_tabbedPane, BorderLayout.CENTER);
            }
            m_nCurIndex = 0;
        }
    }

    public TabbedPanel( Object [ ] comps)
    {
        setLayout(new BorderLayout());

        if (comps.length == 1)
        {
            add((Component)comps[0], BorderLayout.CENTER);
            m_vComponents.addElement(comps[0]);
        }
        else
        {
            // There is more than one component, so create a JTabbedPane.
            m_tabbedPane = new JTabbedPane();

            // Add all the components to the JTabbedPane.
            for (int i=0; i<comps.length; i++)
            {
            	Object comp = comps[i];
                if ( comp instanceof StandardPanel )
                {
                    StandardPanel panel = ( StandardPanel ) comp;
                    m_tabbedPane.addTab ( panel.getTitle ( ), 
                                            panel.getImageIcon ( ), 
                                            ( Component ) comp, 
                                            panel.getTitle ( ) );
                }                            
                else if ( comp instanceof TabbedPanelComponent )
                {
                    TabbedPanelComponent panel = ( TabbedPanelComponent ) comp;
                    m_tabbedPane.addTab ( panel.getTitle ( ), 
                                            panel.getImageIcon ( ), 
                                            ( Component ) comp, 
                                            panel.getTitle ( ) );
                }
            	m_vComponents.addElement(comp);
            	if (comp instanceof JComponent)
        		{
                	((JComponent)comp).setBorder(new StandardBorder());
        		}
            }
            // Listen for the tab selection changes
			m_tabbedPane.addChangeListener(new TabsListener());

            add(m_tabbedPane, BorderLayout.CENTER);
        }
        m_nCurIndex = 0;
    }

    /**
    * @hidden
    * Returns the tabbed pane used by the TabbedPanel.
    * @return JTabbedPane 
    * @status hidden
    */
    public JTabbedPane getTabbedPane()
    {
        return (m_tabbedPane);
    }
    
    /**
    * @hidden
    * Returns the currently selected component on this TabbedPanel.
    * @return the selected component implementing the StandardPanel interface
    * @status hidden
    */
    public StandardPanel getSelectedComponent()
	{
		if (m_vComponents != null)
		{
			if (m_vComponents.size() == 1)
			{
				return (StandardPanel)m_vComponents.elementAt(0);
			}
			else if (m_tabbedPane != null)
			{
				return ((StandardPanel)m_tabbedPane.getSelectedComponent());
			}
		}
		return null;
	}
	
    /**
    * @hidden
    * Returns the currently selected component on this TabbedPanel.
    * @return the selected component implementing the StandardPanel interface
    * @status hidden
    */
    public TabbedPanelComponent getSelectedComponentEx ()
	{
		if (m_vComponents != null)
		{
			if (m_vComponents.size() == 1)
			{
				return (TabbedPanelComponent)m_vComponents.elementAt(0);
			}
			else if (m_tabbedPane != null)
			{
				return ((TabbedPanelComponent)m_tabbedPane.getSelectedComponent());
			}
		}
		return null;
	}
	
	/**
    * @hidden
    * Sets the index of the selected component on this TabbedPanel.
    *
    * @param int index of the component to be selected
    * @throws <code>DataUtilException</code> If an error occurs.    
    * @status hidden
    */
	public void setSelectedIndex(int index) throws DataUtilException
	{
		int size = m_vComponents.size();
		
		if (index < size)
		{
            if ((size > 1) && (m_tabbedPane != null))
			{
				int oldSelIndex = m_tabbedPane.getSelectedIndex();
				m_tabbedPane.setSelectedIndex(index);
				updateTabsState();	
				
				// Now update the current index into our member variable.
				m_nCurIndex = index;
			}
			else if (index == 0)
			{
				Object comp = m_vComponents.elementAt(index);
				if ( comp instanceof StandardPanel )
				{
				    ( ( StandardPanel ) comp ).setActive ( true );
                }		
                else if ( comp instanceof TabbedPanelComponent )
                {                				     
				    ( ( TabbedPanelComponent ) comp ).setActive(true);
                }				    
			}
		}
	}

	
    // Listener for the changes in the selected tabs
    private class TabsListener implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
        try {
            if (Timer.ON) {
                Timer.getTimer().start("Change panel");
            }
            
          updateTabsState();
          m_nCurIndex = m_tabbedPane.getSelectedIndex();
          TabbedPanel.this.m_tabbedPane.requestFocus();
          
            if (Timer.ON) {
                Timer.getTimer().stop("Change panel");
            }
        }

        catch (Exception exception) {
          throw new DataUtilRuntimeException (
            DataUtilClientBundle.EXC_UNEXPECTED_ERROR, exception);
        }
      }
    }
    
    // Sets the each tabs state to active/inactive, based on the state of the JTabbedPane
    private void updateTabsState() throws DataUtilException
	{
		int activeTabIndex = m_tabbedPane.getSelectedIndex();

		Object tabOld  = null, tabNew = null;

/*
        for (int i=0; i<m_vComponents.size(); i++)
    	{
        	StandardPanel tab = (StandardPanel)m_vComponents.elementAt(i);
        	tab.setActive(i == activeTabIndex);
        }
*/
        // Tell the old index we are losing activation.
        if ( m_nCurIndex >= 0 &&
             m_nCurIndex != activeTabIndex &&
             m_nCurIndex < m_vComponents.size ( ) )
        {
            tabOld = m_vComponents.elementAt ( m_nCurIndex );
            if ( tabOld != null )
            {
				if ( tabOld instanceof StandardPanel )
				{
				    ( ( StandardPanel ) tabOld ).setActive ( false );
                }
                else if ( tabOld instanceof TabbedPanelComponent )
                {
				    ( ( TabbedPanelComponent ) tabOld ).setActive ( false );
                }
            }
        }

        // Tell the new index it is gaining activation.
        if ( activeTabIndex >= 0 &&
             activeTabIndex < m_vComponents.size ( ) )
        {
            tabNew = m_vComponents.elementAt ( activeTabIndex );
            if ( tabNew != null )
            {
				if ( tabNew instanceof StandardPanel )
				{
				    ( ( StandardPanel ) tabNew ).setActive ( true );
                }		
                else if ( tabNew instanceof TabbedPanelComponent )
                {                				     
				    ( ( TabbedPanelComponent ) tabNew ).setActive ( true );
                }				    
            }                
        }
	}
}