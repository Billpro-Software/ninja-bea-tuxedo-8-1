/*
 * DatabaseObjectRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import java.awt.Component;

import java.text.MessageFormat;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.DefaultTreeCellRenderer;

import oracle.dss.datautil.gui.ComponentContext;
import oracle.dss.datautil.gui.Utils;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;

/**
* @hidden
* DatabaseObjectRenderer class is used to render the database objects in the JTree.
*/
public class DatabaseObjectRenderer extends DefaultTreeCellRenderer {
    // Icons for open/closed folder
    private ImageIcon m_imgMeasure;
    private ImageIcon m_imgCustomMeasure;
    private ImageIcon m_imgDimension;
    private ImageIcon m_imgSavedSelection;
    private ImageIcon m_imgHierarchy;

    // Icons for open/closed folder
    private ImageIcon m_imgClosed;
    private ImageIcon m_imgOpen;

    // I18N formats for accessible names
    private MessageFormat m_measureFormat;
    private MessageFormat m_customMeasureFormat;
    private MessageFormat m_dimensionFormat;
    private MessageFormat m_savedSelectionFormat;
    private MessageFormat m_hierarchyFormat;
    private MessageFormat m_folderFormat;

    // Holds the current display label type.
    private String m_strDisplayLabelType;

    // Holds the current ComponentContext.
    //private ComponentContext m_componentContext;

	// The ErrorHandler used to handle exceptions that aren't simply thrown.
	private transient ErrorHandler m_errorHandler;
      
    private IconManager m_iconManager = new IconManager();  

    /**
     * @hidden
     * Constructor that takes the desired display label type.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     */
    public DatabaseObjectRenderer(String strDisplayLabelType) {
        super();
        // Create the database object images
        getIcons();
        // Set the current display label type.
        setDisplayLabelType(strDisplayLabelType);
    }

    /**
     * @hidden
     * Constructor that takes the ComponentContext.
     * @param componentContext  A ComponentContext that identifies the type of label
     *                             that you want.
     */
    //public DatabaseObjectRenderer(ComponentContext componentContext) {
        //super();
        // Create the database object images
        //getIcons();
        // Set the current display label type.
        //setComponentContext(componentContext);
    //}

    /**
     * @hidden
     * Default constructor
     */
    public DatabaseObjectRenderer() {
        this((String)null);
    }

    /**
     * @hidden
     * Sets the desired ComponentContext.
     * @param componentContext  The ComponentContext that identifies the type of label
     *                             that you want.
     */
    //public void setComponentContext(ComponentContext componentContext) {
        //m_componentContext = componentContext;
    //}
    
    /**
     * @hidden
     * Sets the desired display label type.
     * @param strDisplayLabelType  A constant that identifies the type of label
     *                             that you want.
     *                             Valid constants are listed in the See Also section.
     *
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     */
    public void setDisplayLabelType(String strDisplayLabelType) {
        m_strDisplayLabelType = strDisplayLabelType;
    }

    // Try to load the open/closed folder icons from the UIManager,
    // create our own images if the icons are not found
    private void getIcons() {
    	// Get database object icons.
        m_imgMeasure = new ImageIcon(Utils.getImageResource(this, "images/measure.gif"));
        m_imgCustomMeasure = new ImageIcon(Utils.getImageResource(this, "images/custommeasure.gif"));
        m_imgDimension = new ImageIcon(Utils.getImageResource(this, "images/dimension.gif"));
        m_imgSavedSelection = new ImageIcon(Utils.getImageResource(this, "images/savedselection.gif"));
        m_imgHierarchy = new ImageIcon(Utils.getImageResource(this, "images/hierarchy.gif"));

        // Try to retrieve the open icon from the UIManager
        try {
            // If the icon does not exist, load our own image
            if ((Icon)UIManager.get("Tree.closedIcon") == null) {
                m_imgClosed = new ImageIcon(Utils.getImageResource(this, "images/folder-c.gif"));
            }
        }
        catch (Exception e) {
            getErrorHandler().error(e, this.getClass().getName(), "getIcons");
        }

        // Try to retrieve the closed icon from the UIManager
        try {
            // If the icon does not exist, load our own image
            if ((Icon)UIManager.get("Tree.openIcon") == null) {
                m_imgOpen = new ImageIcon(Utils.getImageResource(this, "images/folder-o.gif"));
            }
        }
        catch (Exception e) {
			getErrorHandler().error(e, this.getClass().getName(), "getIcons");
        }

        // Get format strings for Accessible names
        m_measureFormat = new MessageFormat(QueryBuilder.getIntlString("measureFormat"));
        m_customMeasureFormat = new MessageFormat(QueryBuilder.getIntlString("customMeasureFormat"));
        m_dimensionFormat = new MessageFormat(QueryBuilder.getIntlString("dimensionFormat"));
        m_savedSelectionFormat = new MessageFormat(QueryBuilder.getIntlString("savedSelectionFormat"));
        m_hierarchyFormat = new MessageFormat(QueryBuilder.getIntlString("hierarchyFormat"));
        m_folderFormat = new MessageFormat(QueryBuilder.getIntlString("folderFormat"));
    }

    // Overriding the getTreeCellRendererComponent call to set the right icon
    public Component getTreeCellRendererComponent(JTree tree, Object value,
          boolean isSelected, boolean isExpanded, boolean isLeaf, int row,
          boolean hasFocus) {
        MessageFormat accessibleFormat = m_measureFormat;

        String strObjectType = Utils.getObjectType(value);
        if (MM.MEASURE.equals(strObjectType)) {
            this.setLeafIcon(m_iconManager.getModifiedIcon(value, m_imgMeasure));
            accessibleFormat = m_measureFormat;
        }
        else if (MM.CALCULATION.equals(strObjectType)) {
            this.setLeafIcon(m_iconManager.getModifiedIcon(value, m_imgCustomMeasure));
            accessibleFormat = m_customMeasureFormat;            
        }
        else if (MM.DIMENSION.equals(strObjectType)) {
            // Set the dimension icon.
            Icon icon = m_iconManager.getModifiedIcon(value, m_imgDimension);
        	this.setClosedIcon(icon);
        	this.setOpenIcon(icon);
        	this.setLeafIcon(icon);
            accessibleFormat = m_dimensionFormat;            
        }
        else if (MM.SELECTION.equals(strObjectType)) {
            // Set the saved selection icon.
            this.setLeafIcon(m_iconManager.getModifiedIcon(value, m_imgSavedSelection));
            accessibleFormat = m_savedSelectionFormat;            
        }
        else if (MM.HIERARCHY.equals(strObjectType)) {
        	// Set the hierarchy icon.
        	this.setLeafIcon(m_iconManager.getModifiedIcon(value, m_imgHierarchy));
        	accessibleFormat = m_hierarchyFormat;            
        }
		else {
            accessibleFormat = m_folderFormat;
            // Set the open/closed icons to the folder icons
            if (m_imgClosed != null) {
                setClosedIcon(m_imgClosed);
            }
            if (m_imgOpen != null) {
                setOpenIcon(m_imgOpen);
            }
		}
        Component renderer = super.getTreeCellRendererComponent(tree, value, isSelected, isExpanded, isLeaf, row, hasFocus);                       
        // Customize display label according to QueryBuilder's settings.
        String strText = null;
        //if (m_strDisplayLabelType != null) {
            strText = Utils.toString(value, m_strDisplayLabelType);    
        //}
        //else {
            //strText = Utils.toString(value, m_componentContext);
        //}
        if (strText != null) {
            setText(strText);
        }
        // Set the accessible name                        
        if (value != null) {
            String[] formatArgs = new String[] {value.toString()};   
            if (getAccessibleContext() != null) {
                tree.getAccessibleContext().setAccessibleName(accessibleFormat.format(formatArgs));  
            }
        }        
        return renderer;
    }
      
    /**
     * @hidden
     * Sets the error handler.
     *
     * @param errorHandler The error handler.
     */
    public void setErrorHandler(ErrorHandler errorHandler) {
    	m_errorHandler = errorHandler;
    }
    
    private ErrorHandler getErrorHandler() {
        if (m_errorHandler == null) {
            m_errorHandler = new DefaultErrorHandler();
        }
        return m_errorHandler;
    }
}