/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/CalculationItemTreeNode.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.queryBuilder;

import javax.naming.directory.SearchResult;

import javax.swing.Icon;
import javax.swing.JTree;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MM;

public class CalculationItemTreeNode extends ItemsTreeNodeImpl {

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private static Icon m_iconCalcItem = QBUtils.getIcon (QBUtils.CALCULATION_ICON);
  private static Icon m_iconDataItem = QBUtils.getIcon (QBUtils.DATA_POINT_ICON);

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public CalculationItemTreeNode (JTree jTree, SearchResult searchResult, 
                                  ComponentContext componentContext) {
    super (jTree, QBUtils.makeComponentNode (searchResult, componentContext), componentContext);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  public Icon getOpenIcon() {
    Object object = QBUtils.getObject (this, getContext());

    if (object instanceof MDItem) {
      String string = ((MDItem)object).getDefaultPlacement();
      
      if ((MM.AXIS.equals (string)) || (MM.X_AXIS.equals (string)) || 
          (MM.Y_AXIS.equals (string)) || (MM.PAGE.equals (string))) {
        return m_iconCalcItem;
      }
      else if (MM.MEASURE.equals (string)) {
        return m_iconDataItem;
      }
    }

    return null;
  }

  public Icon getClosedIcon() {
    return getOpenIcon();
  }
}
