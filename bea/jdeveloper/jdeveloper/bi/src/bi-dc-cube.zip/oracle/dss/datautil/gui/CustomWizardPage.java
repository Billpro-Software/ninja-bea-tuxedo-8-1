/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.Component;

import oracle.bali.ewt.wizard.WizardPage;

/**
 * @hidden
 * Extends the BALI <code>WizardPage</code> class.
 *
 * @status hidden
 */
public class CustomWizardPage extends WizardPage
{
    private static boolean m_first;

    //---------------------------------------------------------
    // CONSTRUCTOR
    //---------------------------------------------------------
    
    /**
     * Constructs a wizard page with no label.
     *
     * @param content The component to be used for this page.
     */
    public CustomWizardPage ( Component content )
    {
        this ( content, null );
    }

    /**
     * Constructs a wizard page with a label.
     *
     * @param content  The component used for this page.
     * @param label    The label on this page. The label is user-visible
     *                 only for ReentrantWizards.
     */
    public CustomWizardPage ( Component content, String label )
    {
        super ( content, label );
    }

  /**
   * @hidden
   * Returns the component that will receive focus initially.
   *
   * @status hidden
   */
    public Component getInitialFocus()
    {
      if (m_first)
      {
        m_first = false;
        return Utils.getFirstFocusableComponent(getContent());
      }
      else
        return super.getInitialFocus();
    }

    /**
     * @hidden
     * Sets a flag indicating the first time a wizard page is viewed
     *
     * @status hidden
     */
    public static void setFirst(boolean first)
    {
      m_first = first;
    }
    
    //---------------------------------------------------------
    // PUBLIC METHODS
    //---------------------------------------------------------
    
    /**
     * Sends a validate event, and checks whether any listeners cancelled.
     *
     * @return   <code>true</code> if the validation succeeded;
     *           </code>false</code> if a listener cancelled.
     *
     * @status protected
     */
    protected boolean validatePage ( )
    {
        return super.validatePage ( );
    }        
}