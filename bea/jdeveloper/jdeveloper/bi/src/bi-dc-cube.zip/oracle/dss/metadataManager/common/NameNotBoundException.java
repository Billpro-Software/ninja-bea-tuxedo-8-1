/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * Indicates that an object cannot be found because the specified name is
 * not bound to any object.
 *
 * @status Reviewed
 */
public class NameNotBoundException extends MetadataManagerException
{
    /**
     * @hidden
     * Constructor.
     *
     * @param name The name that was attempted.
     * @param driverType The type of driver that initiates this exception.
     *
     * @status hidden
     */
    public NameNotBoundException(String name, String driverType)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new Object[]{name}, driverType, null);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param name The name that was attempted.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public NameNotBoundException(String name, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new Object[]{name}, driverType, prevException);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param name The name that was attempted.
     * @param locale The locale to use for the message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public NameNotBoundException(String name, Locale locale, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NAME_NOT_FOUND, new Object[]{name}, locale, driverType, prevException);
    }
}
