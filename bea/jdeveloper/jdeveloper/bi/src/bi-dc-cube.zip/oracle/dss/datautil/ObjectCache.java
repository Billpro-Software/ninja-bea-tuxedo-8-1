/*
 * ObjectCache.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

 package oracle.dss.datautil;

 /**
 * @hidden
 * The class used for representing a dimension member
 */
 public class ObjectCache extends Object
 {
 	private Object m_object;
  	private String m_strObject;
        
  	/**
     * Constructor.
     *
     * @param object the object
     * @param strObject the display string of the object
     *
     * @status New
     */
	public ObjectCache(Object object, String strObject)
  	{
   		m_object = object;
      	m_strObject = strObject;
   	}
        
  	/**
  	 * Retrieves the object.
     *
     * @return Object the object
     *
     * @status New
     */
  	public Object getObject()
  	{
     	return m_object;
   	}
        
  	/**
   	 * Retrieves the display name of the object
   	 *
   	 * @return the display name
   	 *
   	 * @status New
   	 */
  	public String toString()
   	{
    	return m_strObject;
   	}

    public boolean equals(Object o) {
      if (!(o instanceof ObjectCache))
        return false;
      if (m_object == null || m_strObject == null)
        return false;
      ObjectCache oc = (ObjectCache)o;
      return m_object.equals(oc.m_object) && m_strObject.equals(oc.m_strObject);
    }
}