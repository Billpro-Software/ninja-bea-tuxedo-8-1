/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.builder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import oracle.bali.ewt.wizard.BaseWizard;

public class WizardTrain extends JPanel {

    /*
     * Public
     */

    public WizardTrain(String[] ss, BaseWizard wizard) {
        m_ss = ss;
        m_wizard = wizard;
        GridBagLayout l = new GridBagLayout();
        setLayout(l);
        if (ss != null) {
            GridBagConstraints c = new GridBagConstraints();
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 1.0;
            c.weighty = 0.0;
            c.anchor = GridBagConstraints.NORTH;
            javax.swing.JLabel label;
            c.insets = new Insets(8, 8, 8, 8);
            c.gridwidth = GridBagConstraints.REMAINDER;
            for (int m_i=0; m_i<ss.length; m_i++) {
                javax.swing.JPanel pnlNumber = new javax.swing.JPanel(new BorderLayout());
                pnlNumber.setBorder(BorderFactory.createLineBorder(Color.black));
                pnlNumber.setBackground(Color.white);
                pnlNumber.setPreferredSize(new Dimension(20, 20));
                pnlNumber.setSize(new Dimension(20, 20));
                pnlNumber.setMinimumSize(new Dimension(20, 20));
                label = new javax.swing.JLabel(Integer.toString(m_i+1));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                pnlNumber.add(label, BorderLayout.CENTER);          
                final javax.swing.JLabel lblTitle = new JLabel();
                lblTitle.putClientProperty("TEXT", ss[m_i]);
                lblTitle.putClientProperty("INDEX", new Integer(m_i));
                lblTitle.setText(makeText(lblTitle, false)); 
                javax.swing.JPanel pnlStation = new javax.swing.JPanel(new BorderLayout());
                pnlStation.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent e) {
                        int i = ((Integer)lblTitle.getClientProperty("INDEX")).intValue();
                        if (m_wizard != null) {
                            m_wizard.setCurrentPageIndex(i); 
                        }
                    }
                    public void mouseEntered(java.awt.event.MouseEvent e) { 
                        lblTitle.setText(makeText(lblTitle, true));
                    }
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        lblTitle.setText(makeText(lblTitle, false));
                    }
                });
                pnlStation.add(pnlNumber, BorderLayout.WEST);
                pnlStation.add(lblTitle, BorderLayout.CENTER);
                l.setConstraints(pnlStation, c);
                add(pnlStation);
            }
            c.fill = GridBagConstraints.BOTH;
            c.weighty = 1.0;
            javax.swing.JPanel p = new javax.swing.JPanel();
            l.setConstraints(p, c);
            add(p);
        }
    }
    
    /*
     * Private
     */
    
    private String[] m_ss = null;   
    private int m_i = 0;
    private BaseWizard m_wizard = null;
    
    private String makeText(JLabel l, boolean blnLink) {
        if (l != null) {
            if (blnLink) {
                return "<html><a href=\"#nolink\">" + l.getClientProperty("TEXT").toString() + "</a>";
            }
            return "<html>" + l.getClientProperty("TEXT").toString();
        }
        return null;
    }
}