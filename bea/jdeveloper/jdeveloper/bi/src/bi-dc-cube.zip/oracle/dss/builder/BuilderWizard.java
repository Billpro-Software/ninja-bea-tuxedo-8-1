/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/builder/BuilderWizard.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.builder;

import oracle.bali.ewt.wizard.Wizard;
import oracle.bali.ewt.wizard.WizardPage;
import oracle.bali.ewt.wizard.WizardValidateListener;

/**
 * <pre>
 * Extends the BALI <code>Wizard</code> class to provide custom BI Beans 
 * functionality.
 * 
 *  Examples:
 *  1) Validate event when the "Previous" button is pressed.
 * 
 * </pre>
 *
 * @author gkellam 
 * @since  11.0.0.0.12
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   11/15/05 - Extensive calculation infrastructure updates. 
 *    gkellam   11/10/05 - Add BuilderWizard to provide BI Beans specific 
 *                         functionality not available in Wizard. 
 *    gkellam   11/10/05 - Add BuilderWizard to provide BI Beans specific 
 *                         functionality not available in Wizard. 
 *
 */

public class BuilderWizard extends Wizard {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  /**
   * Specifies whether a Validate event is sent when the Previous button is 
   * pressed.
   *
   * @status proteced
   */ 
  protected boolean m_bAllowPreviousValidateEvent  = true;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Default <code>BuilderWizard</code> constructor.
   *
   * @status new
   */
  public BuilderWizard() {
    super ();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies whether a Validate event is sent when the Previous button is 
   * pressed.
   *
   * @param bAllowPreviousValidateEvent A <code>boolean</code> which is 
   *        <code>true</code> when a Validate event should be sent when the
   *        Previous button is pressed, and <code>false</code> otherwise.
   *
   * @status new
   */ 
  public void setAllowPreviousValidateEvent (boolean bAllowPreviousValidateEvent) {
    m_bAllowPreviousValidateEvent = bAllowPreviousValidateEvent;
  }

  /**
   * Determines whether a Validate event is sent when the Previous button is 
   * pressed.
   * 
   * @return <code>boolean</code> hich is <code>true</code> when a Validate 
   *         event should be sent when the Previous button is pressed, and 
   *         <code>false</code> otherwise..
   *
   * @status new
   */ 
  public boolean isAllowPreviousValidateEvent() {
    return m_bAllowPreviousValidateEvent;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
  
  /**
   * <pre>
   * Overrides handling of the <code>Wizard</code> previous button.
   * 
   * In particular, it allows the option of sending a Validate event when the 
   * "Previous" button is pressed.
   * </pre>
   * 
   *
   * @status protected
   */
  protected void doPrevious() {
    WizardPage  wizardPagePrevious = null;

    // Validate the page up front, so that clients can adjust which
    // page is next in response to the validate event.
    if (validateSelectedPage()) {
      wizardPagePrevious = getPreviousPage (getSelectedPage());
      
      // Determine whether validation event is allowed.
      if ((wizardPagePrevious != null) && (isAllowPreviousValidateEvent())) {
        // Don't bother validating _again_
        selectPage (wizardPagePrevious, false);
      }
    }
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
  
}