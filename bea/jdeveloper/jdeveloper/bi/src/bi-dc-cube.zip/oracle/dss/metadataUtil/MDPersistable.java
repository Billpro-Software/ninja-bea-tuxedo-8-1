/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

import oracle.dss.util.persistence.Persistable;

/**
 * Methods for retrieving and restoring the state of a component.
 * Also methods for retrieving and restoring relationships between components.
 * Any component that needs to be persisted in the BI Beans Catalog 
 * must implement this interface.
 *
 * @status Reviewed
 */
public interface MDPersistable extends Persistable
{

    /**
     * Retrieves an array of MDAggregateInfo objects.
     *
     * @status Documented
     */
    public abstract MDAggregateInfo[] getMDComponents();

    /**
     * Specifies an array of  MDAggregateInfo objects.
     * 
     * @param aggrs MDAggregateInfo object
     *
     * @status Documented
     */
    public abstract void setMDComponents(MDAggregateInfo[] aggrs);
}
