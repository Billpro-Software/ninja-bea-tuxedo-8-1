/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import java.util.ResourceBundle;
import java.text.MessageFormat;

import javax.naming.directory.SearchResult;

import oracle.dss.bicontext.BIBinding;
import oracle.dss.bicontext.BINamingException;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * @hidden
 *
 * @see oracle.dss.bicontext.BIBinding 
 * @status New
 */
public class MetadataManagerBindingImpl extends BIBinding
{
    MetadataManagerServices m_mms = null;

    public MetadataManagerBindingImpl(String name, Object obj, String type, MetadataManagerServices mms)
    {
        super(name, obj, type);
        m_mms = mms;
    }

    public MetadataManagerBindingImpl(String name, Object obj, boolean isRelative, String type, MetadataManagerServices mms)
    {
        super(name, obj, type);
        m_mms = mms;
    }

    public MetadataManagerBindingImpl(String name, String className, Object obj, String type, MetadataManagerServices mms)
    {
        super(name, className, obj, type);
        m_mms = mms;
    }

    public MetadataManagerBindingImpl(String name, String className, Object obj, boolean isRelative, String type, MetadataManagerServices mms)
    {
        super(name, className, obj, type);
        m_mms = mms;
    }

    public Object getObject()
    {
        Object _obj = super.getObject();
        if (_obj instanceof SearchResult)
            return ((SearchResult)_obj).getObject();
        else
            return _obj;
    }

    // this is to prevent the super class toString method
    // to call toString on whatever returned from getObject()
    // all we need is just a name for rendering
    public String toString()
    {
        return getName();
    }

    public Object getObjectDefinition()
    {
        Object _obj = super.getObject();
        if (_obj instanceof MetadataManagerSearchResultImpl)
            return ((MetadataManagerSearchResultImpl)_obj).getObjectDefinition();
        else
            return _obj;
    }

    private String getExceptionMessage()
    {
        Locale _locale = null;
        if (m_mms != null)
            _locale = m_mms.getLocale();

        if (_locale == null)
            _locale = Locale.getDefault();

        ResourceBundle _bundle = ResourceBundle.getBundle("oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle", _locale);
        if (_bundle != null)
        {
            String _msg = _bundle.getString(MetadataManagerCommonBundle.EXC_UNKNOWN);
            String _exMsg = MessageFormat.format("{0}-{1} {2}", new Object[] { "DVT", MetadataManagerCommonBundle.EXC_UNKNOWN, _msg });
            return _exMsg;
        }
        else
            return null;
    }
}
