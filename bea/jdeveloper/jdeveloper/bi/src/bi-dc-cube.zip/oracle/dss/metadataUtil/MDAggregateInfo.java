/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

/**
 * An MDAggregateInfo contains information about the aggregating
 * object. It's a data structur that contains an OLAP id and
 * a position.
 *
 * @status New
 */
public final class MDAggregateInfo 
{
    protected String m_id;
    protected int m_position;

    /**
     * Constructor for MDAggregateInfo
     * @param id   The OLAP id
     * @param pos  The position 
     *
     * @status New
     */
    public MDAggregateInfo(String id, int pos)
    {
        m_id = id;
        m_position = pos;
    }

    /**
     * Retrieves the id
     * @return  The OLAP id.
     *
     * @status New
     */
    public String getOLAPid()
    {
        return m_id;
    }

    /**
     * Retrieves the position
     * @return  position.
     *
     * @status New
     */
    public int getPosition()
    {
        return m_position;
    }

    /**
     * Sets the id
     *
     * @param id OLAP id
     * 
     * @status New
     */
    public void setOLAPid(String id)
    {
        m_id = id;
    }

    /**
     * Sets the position
     * @param pos position.
     *
     * @status New
     */
    public void setPosition(int pos)
    {
        m_position = pos;
    }
}
