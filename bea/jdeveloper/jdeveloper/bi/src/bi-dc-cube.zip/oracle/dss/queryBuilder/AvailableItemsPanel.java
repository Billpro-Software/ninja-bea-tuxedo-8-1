/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/AvailableItemsPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Component;

import java.util.Vector;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

import oracle.dss.bicontext.BISearchResult;
import oracle.dss.datautil.filter.ItemFilter;
import oracle.dss.datautil.filter.MetadataFilter;
import oracle.dss.datautil.gui.ShuttleComponent;
import oracle.dss.datautil.gui.ShuttleEvent;
import oracle.dss.datautil.gui.ShuttleListener;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.SetUtils;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.tree.VirtualTreeNode;

/**
 * @hidden
 *
 * <pre>
 * <code>AvailableItemsPanel</code>
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/06/07 - Fix Bug 6656686 - Double click on items in the QB
 *                         should shuttle them over to the select.
 *    gkellam   07/24/07 - Continue DataFilter updates.
 *    gkellam   07/23/07 - Select Values updates.
 *    gkellam   07/21/07 - More DataFilter updates.
 *    gkellam   06/13/07 - Fix Bug 6068019 - QueryBuilder: 'Available' in
 *                         available side of shuttle should have mnemonic.
 *    gkellam   09/25/06 - Simplify ItemFilter specification.
 *    gkellam   09/20/06 - Enable the ability to filter the AvailableItemsPanel
 *                         content.
 */
public class AvailableItemsPanel extends ShuttlePanel implements ShuttleListener {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Members
  //
  /////////////////////

  protected CollapsiblePane m_collapsiblePane = null;
  private AvailableDataPanel m_availableDataPanel = null;

  private MetadataFilter m_metadataFilter = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public AvailableItemsPanel (ComponentContext context) {
    this (context, null, null);
  }

  public AvailableItemsPanel (ComponentContext context, Component componentAvailableToolbar, 
                              Component componentSelectedToolbar) {
    this (context, QueryBuilderBundle.AVAILABLEITEMSPANEL_AVAILABLE, 
      componentAvailableToolbar, componentSelectedToolbar);
  }

  public AvailableItemsPanel (ComponentContext context, String strLabelID, Component componentAvailableToolbar, 
                              Component componentSelectedToolbar) {
    this (context, QueryBuilderBundle.AVAILABLEITEMSPANEL_AVAILABLE, null, 
      componentAvailableToolbar, componentSelectedToolbar);
  }

  public AvailableItemsPanel (ComponentContext context, String strLabelID, ShuttlePanel shuttlePanelAvailable, 
      Component componentAvailableToolbar, Component componentSelectedToolbar) {
    super (context);
    
    if (shuttlePanelAvailable != null) {
      setShuttlePanel (shuttlePanelAvailable);
    }
    else {
      m_availableDataPanel = new AvailableDataPanel (getContext());
      setShuttlePanel (m_availableDataPanel);
    }

    setShuttleComponent (((ShuttlePanel)getShuttlePanel()).getShuttleComponent());
    
    add (makeHeader (strLabelID, componentAvailableToolbar, 
      componentSelectedToolbar), BorderLayout.NORTH);
    
    add (new JScrollPane ((Component)getShuttleComponent()), BorderLayout.CENTER);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies a <code>MetadataFilter</code> to apply to the 
   * <code>AvailableItemsPanel</code>.
   * 
   * @param metadataFilter A <code>MetadataFilter</code>
   * 
   * @status new
   */
  public void setMetadataFilter (MetadataFilter metadataFilter) {
    m_metadataFilter = metadataFilter;  
  }

  /**
   * Retrieves a <code>MetadataFilter</code> to apply to the 
   * <code>AvailableItemsPanel</code>.
   * 
   * @return <code>MetadataFilter</code>
   * 
   * @status new
   */
  public MetadataFilter getMetadataFilter() {
    return m_metadataFilter;
  }

  public Component add (String strTitle, Component component, boolean blnExpanded) {
    return m_collapsiblePane.add (strTitle, component, blnExpanded);
  }

  public Component add (String strTitle, Component component) {
    return add (strTitle, component, true);
  }

  public AvailableDataPanel getAvailableDataPanel() {
    return m_availableDataPanel;
  }

  /**
   * @hidden
   * @status hidden
   */
  public static void main (String[] args) {
    QBUtils.makeFrame (new AvailableItemsPanel (null));
  }

  public AvailableItemsTree getAvailableItemsTree() {
    AvailableDataPanel availableDataPanel = getAvailableDataPanel();
    return (availableDataPanel == null) ? null : 
      availableDataPanel.getDatasourceTree();
  }

  public void refresh() {
    // Refresh tree if MetadataFilter has been specfied
    applyMetadataFilter();
  }

  /**
   * Clear the <code>AvailableItemsPanel</code>.
   * 
   * @status hidden       
   */
  public void clear() {
    AvailableDataPanel availableDataPanel = getAvailableDataPanel();
    
    if (availableDataPanel != null) { 
      availableDataPanel.clear();  
    }
  } 

  /**
   * @status hidden
   */
  protected void applyMetadataFilter() { 
    AvailableDataPanel availableDataPanel = getAvailableDataPanel();
    MetadataFilter metadataFilter = getMetadataFilter();

    if ((metadataFilter != null) && (availableDataPanel != null)) {

      FolderItemsTreeNode folderItemsTreeNode = 
        availableDataPanel.getFolderItemsTreeNode (
          AvailableDataPanel.AVAILABLEITEMSTREE_DATASOURCE);
      
      applyMetadataFilter (folderItemsTreeNode, metadataFilter);

      // Clear the virtual tree
      folderItemsTreeNode.refresh();
      
      // Update the AvailableItemsPanel node
      availableDataPanel.getDatasourceTree().setRoot (folderItemsTreeNode);  
      
      TreeModel treeModel = 
        availableDataPanel.getDatasourceTree().getModel();  
  
      ((DefaultTreeModel)treeModel).nodeStructureChanged (folderItemsTreeNode);
    }
  }

  /**
   * Perform some <code>FolderItemsTreeNode</code> metadata filtering.
   * 
   * @param folderItemsTreeNode A <code>FolderItemsTreeNode</code> to apply
   *        metadata filtering to.  
   * @param metadataFilter A <code>MetadataFilter</code> to apply.  
   *        
   * @status hidden       
   */
  protected void applyMetadataFilter (FolderItemsTreeNode folderItemsTreeNode, 
                                      MetadataFilter metadataFilter) {
    if (folderItemsTreeNode != null) {
      folderItemsTreeNode.setMetadataFilter (metadataFilter);      
    }
  }  

  // ..........................................
  // ShuttleListener implementation - Start
  // ..........................................

  /**
   * Process Shuttle items selected <code>ShuttleEvent</code>.
   *
   * @param shuttleEvent A <code>ShuttleEvent</code> representing that items
   *        were selected.
   *
   * @status new
   */
  public void shuttleItemsSelected(ShuttleEvent shuttleEvent) {
    Object[] objAllItemsSelected = null;

    if (shuttleEvent != null) {
      // Trace the event
      trace (shuttleEvent);

      Object objSource = shuttleEvent.getSource();

      if (objSource instanceof ShuttleComponent) {
        if (objSource instanceof SelectedItemsTree) {
          // gek 01/31/06 Disable Item Filter Processing
          /*
          objAllItemsSelected = ((ShuttleComponent)objSource).getAllItems();
          updateDependentIDs (getContext(), objAllItemsSelected);
          */
        }
      }
    }
  }

  /**
   * Process Shuttle items shuttled <code>ShuttleEvent</code>.
   *
   * @param shuttleEvent A <code>ShuttleEvent</code> representing that items
   *        were shuttled.
   *
   * @status hidden
   */
  public void shuttleItemsShuttled (ShuttleEvent shuttleEvent) {
    if (shuttleEvent != null) {
      // Trace the event
      trace (shuttleEvent);
    }
  }

  /**
   * Process Shuttle items double clicked <code>ShuttleEvent</code>.
   * 
   * @param shuttleEvent A <code>ShuttleEvent</code> representing the items 
   *        double clicked.
   * 
   * @status new
   */
  public void shuttleItemsDoubleClicked (ShuttleEvent shuttleEvent) {
  }

  // ..........................................
  // ShuttleListener implementation - End
  // ..........................................

  /**
   * Updates the <code>ComponentContext</code> list of dependent IDs based on
   * the specified items.
   *
   * @param componentContext A <code>componentContext</code> to update.
   * @param objItems A <code>Object</code> array of objects to retrieve IDs for.
   *
   * @status new
   */
  public void updateDependentIDs (ComponentContext componentContext, 
                                  Object[] objItems) {
    Vector vstrIDs = null;
    Vector vstrIDsNew = null;

    if (componentContext != null) {
      vstrIDs = componentContext.getDependentIDs();
      vstrIDsNew = getItemIDs(objItems);

      int nCompare = SetUtils.compareSets(vstrIDs, vstrIDsNew, null);
      if (nCompare != SetUtils.COMPARE_EQUAL) {
        // Update the ComponentContext with the new list of Selected IDs
        componentContext.setDependentIDs(vstrIDsNew);

        // Retrieve a list of all Available nodes
        Object[] objNodes = getAvailableItemsTree().getAllVisibleItems();

        // Retrieve the underlying AvailableItemsPanel TreeModel
        // TreeModel treeModel = getAvailableDataPanel().getDatasourceTree().getModel();
        TreeModel treeModel = getAvailableItemsTree().getModel();

        // Determine if the underlying TreeModel is a DefaultTreeModel
        DefaultTreeModel defaultTreeModel = null;
        if (treeModel instanceof DefaultTreeModel) {
          defaultTreeModel = (DefaultTreeModel)treeModel;
        }

        // Update the nodes in the AvailableItemsPanel based on their state
        if ((defaultTreeModel != null) && (objNodes != null)) {
          boolean bInclude = true;
          BISearchResult biSearchResult;
          ComponentNode componentNode;
          TreeNode treeNode;

          // Retrieve the ItemFilter
          ItemFilter itemFilter = getItemFilter(defaultTreeModel, vstrIDsNew);
          if (itemFilter != null) {

            // Iterate over each node and update it
            for (int nIndex = 0; nIndex < objNodes.length; nIndex++) {
              treeNode = (TreeNode)objNodes[nIndex];

              // Retrieve the node.            
              componentNode = 
                  (ComponentNode)((DefaultMutableTreeNode)treeNode).getUserObject();

              // Update the ItemFilter based on the selectec items
              itemFilter.setItems(vstrIDsNew);

              // Generate a SearchResult that can be used by the filter based
              // on the Component's ID
              biSearchResult = 
                  itemFilter.getSearchResult(componentNode.getID());

              // Run the SearchResult through the filter
              bInclude = itemFilter.evaluate(biSearchResult);

              // Update the state of the component node
              QBUtils.updateComponentNode(componentNode, biSearchResult, null);

              // Make sure the node gets updated based on the new state
              defaultTreeModel.nodeChanged((TreeNode)objNodes[nIndex]);
            }
          }
        }

        // Update the tree to reflect the updated nodes        
        getAvailableItemsTree().refresh();
      }
    }
  }

  /**
   * Retrieves a list of IDs associated with the specified items.
   *
   * @param objItems A <code>Object</code> array of objects to convert.
   *
   * @return <code>Vector</code> of IDs associated with the specified items.
   */
  public Vector getItemIDs(Object[] objItems) {
    Vector vIDs = null;
    Object object;
    String strID;

    if ((objItems != null) && (objItems.length > 0)) {
      vIDs = new Vector();

      // Iterate over all the nodes
      for (int nIndex = 0; nIndex < objItems.length; nIndex++) {
        if (objItems[nIndex] instanceof VirtualTreeNode) {
          // Retrieve the underlying UserObject
          object = ((VirtualTreeNode)objItems[nIndex]).getUserObject();

          // Determine if the object represents a component node.
          if (object instanceof ComponentNode) {
            strID = ((ComponentNode)object).getID();

            if (strID != null) {
              vIDs.add(strID);
            }
          }
        }
      }
    }

    return vIDs;
  }

  /**
   * Retrieves a <code>ItemFilter</code> from the specified <code>DefaultTreeModel</code>.
   *
   * @param defaultTreeModel A <code>DefaultTreeModel</code> to interrogate.
   * @param vstrIDsNew A <code>Vector</code> of <code>MetadataManager</code> IDs to
   *        compare to.
   *
   * @return <code>ItemFilter</code> associated with the specified <code>DefaultTreeModel</code>.
   */
  protected ItemFilter getItemFilter(DefaultTreeModel defaultTreeModel, 
                                     Vector vstrIDsNew) {
    ItemFilter itemFilter = null;

    if (defaultTreeModel != null) {
      // Retrieve the ItemFilter
      Object objRoot = defaultTreeModel.getRoot();

      if (objRoot instanceof FolderItemsTreeNode) {
        FolderItemsTreeNode folderItemsTreeNode = (FolderItemsTreeNode)objRoot;

        if (folderItemsTreeNode != null) {
          itemFilter = (ItemFilter)folderItemsTreeNode.getMetadataFilter();

          if (itemFilter != null) {
            // Update the ItemFilter based on the selected items
            itemFilter.setItems(vstrIDsNew);
          }
        }
      }
    }

    return itemFilter;
  }

  protected JPanel makeHeader (String strLabelID, Component componentAvailableToolbar, Component componentSelectedToolbar) {
    JPanel jPanel = new JPanel (new BorderLayout());
    
    if (strLabelID != null) {
      JLabel jLabelAvailable = makeLabel (getResourceString (strLabelID));
    
      if ((componentAvailableToolbar != null) || (componentSelectedToolbar != null)){
        jLabelAvailable.setVerticalAlignment (SwingConstants.CENTER);
     }
      else {
        jLabelAvailable.setVerticalAlignment (SwingConstants.BOTTOM);
      }
      
      jPanel.add (jLabelAvailable, BorderLayout.WEST);
    }
    
    if (componentAvailableToolbar != null) {
      String strBorderLayout = 
        (strLabelID != null) ? BorderLayout.EAST : BorderLayout.WEST; 

      jPanel.add (componentAvailableToolbar, strBorderLayout);
    }

    if ((componentAvailableToolbar == null) && (componentSelectedToolbar != null)) {
      int nHeight = (int) componentSelectedToolbar.getPreferredSize().getHeight();
      jPanel.add (Box.createVerticalStrut (nHeight), BorderLayout.EAST);
    }

    return jPanel;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private JLabel makeLabel (String strLabel) {
    return (strLabel != null) ? DataUtils.getLabel (strLabel, SwingConstants.RIGHT) : null;
  }
}
