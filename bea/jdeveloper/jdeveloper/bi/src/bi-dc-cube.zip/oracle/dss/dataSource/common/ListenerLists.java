/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
 package oracle.dss.dataSource.common;
 

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.PollingRequiredEvent;
import java.util.Vector;

/**
 * @hidden
 * Class designed to store and fire events to listeners.
 */
public class ListenerLists extends Object implements Cloneable
{
    protected Vector m_directors = new Vector();
    
    /** 
     * @hidden
     * List of references to listener objects
     */
    public Vector    listeners   = new Vector();
    
    
    /**
     * @hidden
     * Constructor.
     */
    public ListenerLists() {
        super();
    }
    
    // Return data directors
    protected Vector getDataDirectors()
    {
        return m_directors;
    }
    
    /**
     * @hidden
     * Add a listener to the list
     *
     * @param listener the listener to add
     */
    public void add(QueryListener listener, DataDirector dd) {
        listeners.addElement(listener);
        m_directors.addElement(dd);
    }
    
    /**
     * @hidden
     * Remove a listener from the list
     *
     * @param listener the listener to remove
     */
    public void remove(QueryListener listener) {
        int index = listeners.indexOf(listener);
        if (index > -1)
        {
            listeners.removeElementAt(index);
            m_directors.removeElementAt(index);
        }
    }
    
    /**
     * @hidden
     * Remove all listeners
     */
    public void removeAll() {
        listeners.removeAllElements();
        m_directors.removeAllElements();
    }
    
    /**
     * @hidden
     * How many listeners?
     */
    public int size()
    {
        return listeners.size();
    }
    
    /**
     * @hidden
     * Fire the dataAvailable event to all listeners.
     *
     * @param e event
     */
    public void fireDataAvailableEvent(DataAvailableEvent e) throws QueryException
    {
        Query dsc = null;
        if (e.getSource() instanceof Query) {
            dsc = (Query)e.getSource();
            // Notify data director listeners
            dsc.fireDataAvailable(e);
        }
        DataAvailableEvent newEvent = null;
        for (int i = 0; i < listeners.size(); i++) {
            DataDirector dd = (DataDirector)m_directors.elementAt(i);
            newEvent = new DataAvailableEvent(dsc, e.isAvailable(), e.isAvailable() ? dsc.generateDataAccess(dd, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE) : null);
            if (dd == null)
                dd = dsc.getDataDirector((DataAccess)newEvent.getDataAccess());
            m_directors.setElementAt(dd, i);
            getListener(i).dataAvailable(newEvent);            
        }
    }

    /**
     * @hidden
     * Fire the dataChanging event to all listeners.
     *
     * @param e event
     */
    public void fireDataChangingEvent(DataChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).dataChanging(e);
        }
    }
     
    /**
     * @hidden
     * Fire the dataChanged event to all listeners.
     *
     * @param e event
     */
    public void fireDataChangedEvent(DataChangedEvent e) throws Exception
    {
        // Special handling for client-side data changed events
        Query dsc = null;
        if (e.getSource() instanceof Query) {
            dsc = (Query)e.getSource();
            //dsc.flipState();
            // Notify data director listeners
            dsc.fireDataChanged(e, -1, null, -1, false);
        }
        _fireDataChangedEvent(e, dsc);
    }

    /**
     * @hidden
     */
    public void firePollingRequired(PollingRequiredEvent e)
    {
        for (int i = 0; i < listeners.size(); i++)
        {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.queryPollingRequired(e);        
        }
    }
    
    protected void _fireDataChangedEvent(DataChangedEvent e, Query dsc) throws QueryException
    {
       DataChangedEvent newEvent = null;
        for (int i = 0; i < listeners.size(); i++) {
            DataDirector dd = (DataDirector)m_directors.elementAt(i);        
            newEvent = new DataChangedEvent(dsc, e.isDataChanged(), e.getMetadataChanged(), e.getChangeType(), dsc.generateDataAccess(dd, e.getChangeType()));
            getListener(i).dataChanged(newEvent);
        }
    }

    /**
     * @hidden
     * Fire the dimensionalityChanged event to all listeners.
     *
     * @param e event
     */
    public void fireDimensionalityChangedEvent(DimensionalityChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).dimensionalityChanged(e);
        }
    }

    /**
     * @hidden
     * Fire the drillRequested event to all listeners.
     *
     * @param e event
     */
    public void fireDrillRequestedEvent(DrillRequestedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).drillRequested(e);
        }
    }
    
    /**
     * @hidden
     * Fire the drillRequesting event to all listeners.
     *
     * @param e event
     */
    public void fireDrillRequestingEvent(DrillRequestingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).drillRequesting(e);
        }
    }

    /**
     * @hidden
     * Fire the drillRequested event to all listeners.
     *
     * @param e event
     */
    public void fireItemDrillRequestedEvent(ItemDrillRequestedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener2(i).itemDrillRequested(e);
        }
    }
    
    /**
     * @hidden
     * Fire the drillRequesting event to all listeners.
     *
     * @param e event
     */
    public void fireItemDrillRequestingEvent(ItemDrillRequestingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener2(i).itemDrillRequesting(e);
        }
    }

    /**
     * @hidden
     * Fire the layoutChanged event to all listeners.
     *
     * @param e event
     */
    public void fireLayoutChangedEvent(LayoutChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).layoutChanged(e);
        }
    }

    /**
     * @hidden
     * Fire the DataFilterChanging event to all listeners.
     *
     * @param e event
     */
    public void fireDataFilterChangingEvent(DataFilterChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.dataFilterChanging(e);
        }
    }
    
    /**
     * @hidden
     * Fire the DataFilterChanged event to all listeners.
     *
     * @param e event
     */
    public void fireDataFilterChangedEvent(DataFilterChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.dataFilterChanged(e);
        }
    }


    /**
     * @hidden
     * Fire the layoutChanging event to all listeners.
     *
     * @param e event
     */
    public void fireLayoutChangingEvent(LayoutChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).layoutChanging(e);
        }
    }    
    
    /**
     * @hidden
     * Fire the undoAvailable event to all listeners.
     *
     * @param e event
     */
    public void fireUndoAvailableEvent(UndoAvailableEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).undoAvailable(e);
        }
    }
    
    /**
     * @hidden
     * Fire the nullStatus event to all listeners.
     *
     * @param e event
     */
    public void fireNullStatusEvent(NullStatusEvent e)
    {
        for (int i = 0; i < listeners.size(); i++)
        {
            getListener(i).nullStatus(e);
        }
    }
    
    /**
     * @hidden
     * Fire the selectionChanged event to all listeners.
     *
     * @param e event
     */
    public void fireSelectionChangedEvent(SelectionChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).selectionChanged(e);
        }
    }
    
    /**
     * @hidden
     * Fire the selectionChanging event to all listeners.
     *
     * @param e event
     */
    public void fireSelectionChangingEvent(SelectionChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).selectionChanging(e);
        }
    }

    /**
     * @hidden
     * Fire the totalChanged event to all listeners.
     *
     * @param e event
     */
     // blm - Selection code moved to dvt-olap
/*    public void fireTotalChangedEvent(TotalChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).totalChanged(e);
        }
    }*/
    
    /**
     * @hidden
     * Fire the totalChanging event to all listeners.
     *
     * @param e event
     */
     // blm - Selection code moved to dvt-olap
/*public void fireTotalChangingEvent(TotalChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).totalChanging(e);
        }
    }*/

     /**
     * @hidden
     * Fire the stateChanged event to all listeners.
     *
     * @param e event
     */
    public void fireStateChangedEvent(StateChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).stateChanged(e);
        }
    }
    
    /**
     * @hidden
     * Fire the StateChanging event to all listeners.
     *
     * @param e event
     */
    public void fireStateChangingEvent(StateChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).stateChanging(e);
        }
    }

    /**
     * @hidden
     * Fire the CellOverriding event to all listeners.
     *
     * @param e event
     */

    public void fireCellOverridingEvent( CellOverridingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).cellOverriding(e);
        }
    }

    /**
     * @hidden
     * Fire the CellOverriden event to all listeners.
     *
     * @param e event
     */


    public void fireCellOverriddenEvent( CellOverriddenEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).cellOverridden(e);
        }
    }

    /**
     * @hidden
     * Fire the CellsSubmitting event to all listeners.
     *
     * @param e event
     */

    public void fireCellsSubmittingEvent( CellsSubmittingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).cellsSubmitting(e);
        }
    }


    /**
     * @hidden
     * Fire the CellsSubmitted event to all listeners.
     *
     * @param e event
     */

    public void fireCellsSubmittedEvent( CellsSubmittedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            getListener(i).cellsSubmitted(e);
        }
    }

    /**
     * @hidden
     * Fire the ColumnSortChanging event to all listeners.
     *
     * @param e event
     */
    public void fireColumnSortChangingEvent(ColumnSortChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.columnSortChanging(e);
        }
    }
        
    /**
     * @hidden
     * Fire the ColumnSortChanged event to all listeners.
     *
     * @param e event
     */
    public void fireColumnSortChangedEvent(ColumnSortChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.columnSortChanged(e);
        }
    }

    /**
     * @hidden
     * Fire the ItemSortChanging event to all listeners.
     *
     * @param e event
     */
    public void fireItemSortChangingEvent(ItemSortChangingEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.itemSortChanging(e);
        }
    }
        
    /**
     * @hidden
     * Fire the ItemSortChanged event to all listeners.
     *
     * @param e event
     */
    public void fireItemSortChangedEvent(ItemSortChangedEvent e) {
        for (int i = 0; i < listeners.size(); i++) {
            QueryListener2 listener = getListener2(i);
            if (listener != null)
                listener.itemSortChanged(e);
        }
    }

    /**
     * @hidden
     * Clone this object.
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    // Return the element as a listener
    private QueryListener getListener(int i) {
        return (QueryListener)listeners.elementAt(i);
    }
    
    private QueryListener2 getListener2(int i)
    {
        Object obj = listeners.elementAt(i);
        if (obj instanceof QueryListener2)
        {
            return (QueryListener2)obj;
        }
        return null;
    }
    
/*    public CubeCursor getCubeCursor(int i)
    {
        DataDirectorImpl dd = (DataDirectorImpl)m_directors.elementAt(i);
        return ((QueryDataDirector)dd.m_delegate).m_cc;
    }*/
}
