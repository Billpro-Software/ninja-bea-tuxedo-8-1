/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/TableSortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    01/17/06 - Creation
 */

package oracle.dss.datautil.gui.component.sort;

import java.util.Vector;

import oracle.dss.util.ColumnSortInfo;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/TableSortPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public interface TableSortPanelModel extends SortPanelModel {
  /**
   * Retrieves the column sorts
   *
   * @return An array of <code>ColumnSortInfo</code>s.
   */
  public ColumnSortInfo[] getColumnSorts();
  
  /**
   * Specifies the column sorts
   *
   * @param sorts An array of <code>ColumnSortInfo</code>s.
   */
  public void setColumnSorts(ColumnSortInfo[] sorts);
  
  /**
   * Retrieves a list of columns that can be sorted
   * 
   * @return The list of columns;
   */
  public Vector getSortColumns();

  /**
   * Retrieves a list of sort directions
   * 
   * @param sortItem The item for which to retrieve sort directions
   *  
   * @return The sort directions
   */
  public Vector getDirections(String sortItem);
}