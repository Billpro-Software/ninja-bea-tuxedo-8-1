/*
 * OLAPDimensionModel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

import java.util.Vector;

import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.EdgeOutOfRangeException;

import oracle.dss.util.dimensionList.DimListDataModel;
import oracle.dss.util.dimensionList.DefaultListDataItem;

import oracle.dss.datautil.query.DataUtils;

/**
 * Superclass for DimListDataModel implementations
 *              
 */
public abstract class OLAPDimensionModel extends Object
                                implements DimListDataModel, java.io.Serializable
    {
    private transient DataAccess    m_dataAccess    = null;
    private boolean                 m_isDragable    = true;
    private boolean                 m_isDropTarget  = true;
    private transient Vector        m_listeners     = null;
    private transient Object        m_selItem       = null;
    private String                  m_labelType     = MetadataMap.METADATA_LONGLABEL;
    private transient boolean       m_initOK        = false;
    private String                  m_dimensionName = "";
    private boolean                 m_verbose       = false;
  
    // The ErrorHandler used to handle exceptions that aren't simply thrown.
    private transient ErrorHandler m_errorHandler;
    
    /**
     * Specifies the type of labels to display for the items in the dimension list.
     *
     * @param  value  A MetadataMap constant that represents the type of labels to display for
     * the items in the dimension list.
     *
     * @status Needs change
     * @hidden
     */
    public void setLabelType(String value) {
        m_labelType = value;
    }

    /**
     * Retrieves the type of labels to display for the items in the dimension list.
     *
     * @return  A MetadataMap constant that represents the type of labels to display for
     * the items in the dimension list.
     *
     * @status Needs change
     * @hidden
     */
    public String getLabelType()
        {
        return m_labelType;
        }
  
    /**
     * Specifies whether print lines will be displayed during runtime.
     * Application developers will view print lines for debugging purposes.
     *
     * @param  <code>true</code> if print lines will be displayed,
     * <code>false</code> if they will not.
     *
     * @status documented
     * @hidden
     */
    public void setVerbose(boolean verbose)
        {
        m_verbose = verbose;
        }

    /**
     * Indicates whether print lines will be displayed during runtime.
     * Application developers will view print lines for debugging purposes.
     *
     * @return  <code>true</code> if print lines will be displayed,
     * <code>false</code> if they will not.
     *
     * @status documented
     * @hidden
     */
    public boolean getVerbose()
        {
        return m_verbose;
        }
  
    /**
     * @hidden
     * 
     * Specifies the name of the dimension that you want to use, such as Geography.
     *
     * @param  dimensionName  The name of the dimension that you want to use.
     *
     * @status documented
     */
    protected void setDimensionName(String dimensionName)
        {
        m_dimensionName = dimensionName;    
        }
    
    /**
     * @hidden
     * 
     * Retrieves the name of the dimension that you want to use, such as Geography.
     *
     * @return The name of the dimension that you want to use.
     *
     * @status documented
     */
    protected String getDimensionName()
        {
        return m_dimensionName;
        }

    /**
     * @hidden
     */
    public DataAccess getDataAccess()
        {
        return m_dataAccess;
        }
   
    /**
     * @hidden
     */
    protected void setDataAccess(DataAccess dataAccess)
        {
        m_dataAccess  = dataAccess;
        initDataAccess();
        }
    
    private void initDataAccess()
        {
        m_initOK = true;
        }

    /**
     * Refreshes the dimension list to reflect the current selections.
     *
     * @status documented
     */
    public void refresh ()
        {
        // DGM
        // setDataAccess(getDataAccess());
        long nowCount = (long) size();
        
        notifyListDataListeners (new ListDataEvent(this, 
            ListDataEvent.CONTENTS_CHANGED, 0, (int) nowCount));
        }    

  
    /**
     * Removes all elements in the data source.
     * Currently not supported in this implementation.
     *
     * @hidden
     *
     * @status hidden
     */
    public void removeAllElements()
        {
        }    
  
    /**
     * Specifies an object to be inserted at the specified
     * position in the data source. Currently not supported in
     * this implementation.
     *
     * @hidden
     *
     * @status hidden
     */
    public void setElementAt(Object o, int index)
        {
        }  

    /**
     * Removes an element in the data source at the specified position.
     * Currently not supported in this implementation.
     *
     * @param index the position of the data item to be removed.
     *
     * @hidden
     *
     * @status hidden
     */
    public void removeElementAt(int index)
        {
        }

    /**
     * Specifies an object to be inserted at the specified
     * position in the data source. Currently not supported in
     * this implementation.
     *
     * @hidden
     *
     * @status hidden
     */
    public void insertElementAt(Object o, int index)
        {
        }

    /**
     * Specifies an object to be added to the data source. Currently
     * not supported in this implementation.
     *
     * @hidden
     *
     * @status hidden
     */
    public void addElement(Object o)
        {
        }

    /**
     * Moves an element in the data source from the specified
     * position to the target position.
     * <p>
     * Currently not supported in this implementation.
     *
     * @param indexFrom the source index item.
     * @param indexTo the target index position.
     *
     * @hidden
     *
     * @status hidden
     */
    public void  moveElement(int indexFrom, int indexTo)
        {
        }

    private int _find(String search, int flags, int startPos) {
        // make this interface into a long!?
        //
        boolean bInStatus = true;  // in status vs. universe?
        int result    = -1;

        int [] hpos = new int [1];
        hpos[0] = startPos;

        if (m_initOK) {
            /* ************ DataAccess find method may be changing **************/
            /* ************ DataAccess find method may be changing **************/
            /* ************ DataAccess find method may be changing **************/
            try {
                // dgm 4-26-00  Changed to use findMember().
                //              Sixth parameter ('flags' param) not supported
                //              yet.  Will be added later.
                //              Also NOTE - UI for this will probably 
                //              have to change (see DimensionListPanel).
                //
                //for (int i = 0; i < m_dataAccess.getEdgeExtent(m_dimEdge); i++) {
                //    if (search.equals(m_dataAccess.getMemberMetadata(m_dimEdge, m_dimDepth, i, type))) {
                //        result = i;
                //        break;
                //    }
                result = 
                    m_dataAccess.findMember(DataDirector.COLUMN_EDGE, hpos,
                        0, search, m_labelType, flags);
            }
            catch (Exception e) {
                getErrorHandler().error(e, this.getClass().getName(), "find");
            }
        }
        return  result;
    }

    /**
     * Searches for a value in the model according to the specified criterea.
     * Constants for <code>flags</code> are FIND_CASE_INSENSITIVE_, FIND_CONTAINS,
     * FIND_ENDS_WITH, FIND_EXACT, FIND_PRIOR, FIND_STARTS_WITH, and are defined
     * by <code>DataAccess</code>.
     *
     * @param  search  The <code>String</code> that you want to search for.
     *
     * @param  flags  Costants that represent the type of search that you want
     * to perform.
     *
     * @param  startPos  The index of the position in the model from which you
     * want to start the search.
     *
     * @return The index of the matching item in the model, or <code>-1</code> if
     * a match is not found.
     *
     * @see oracle.dss.util.DataAccess#FIND_CASE_INSENSITIVE
     * @see oracle.dss.util.DataAccess#FIND_CONTAINS
     * @see oracle.dss.util.DataAccess#FIND_ENDS_WITH
     * @see oracle.dss.util.DataAccess#FIND_EXACT
     * @see oracle.dss.util.DataAccess#FIND_PRIOR
     * @see oracle.dss.util.DataAccess#FIND_STARTS_WITH
     *
     * @status documented
     */
    public int find(String search, int flags, int startPos) {
        int intFind = _find(search, flags, startPos);
        if ( (intFind < 0) && (startPos > 0) ) {
            intFind = _find(search, flags, 0);
        }
        return intFind;
    }

    /**
     * Retrieves the item that is currently selected in the model.
     *
     * @return The item that is currently selected in the model.
     *
     * @status documented
     */
    public Object getSelectedItem()
        {
        return m_selItem;
        }

    /**
     * Specifies the item that you want to select in the model.
     *
     * @param  item The item that you want to select in the model.
     *
     * @status documented
     */
    public void setSelectedItem(Object item)
        {
        m_selItem = item;
        }
  
    /**
     * @hidden
     */
    public Object elementAt(int index)
        {
        return getElementAt(index);
        }

    /**
     * Retrieves the total number of items in the model.
     *
     * @return The total number of items in the model.
     *
     * @status documented
     */
    public int getSize()
        {
        // make this interface into a long!?
        //
        long ret = 0;

        if (m_initOK)
        {
        // last test 06/12/1999
        //
        // ret = (m_dimEdge == 0 ? m_dataAccess.getColumnCount() : m_dataAccess.getRowCount());

        int [] depthIndex = new int[0];

        try
            {
            if (m_dataAccess == null)
            {
                return 0;
            }
            ret = m_dataAccess.getMemberSiblingCount(DataDirector.COLUMN_EDGE, depthIndex, 0);
            }
      
        catch (SliceOutOfRangeException e1)
            {
            //System.out.println("! DataDirectorDimensionModel.size() - slice out of range !");
            getErrorHandler().error(e1, this.getClass().getName(), "getSize");
            }
            
        catch (LayerOutOfRangeException e2)
            {
            //System.out.println("! DataDirectorDimensionModel.size() - layer out of range !");
            getErrorHandler().error(e2, this.getClass().getName(), "getSize");
            }
      
        catch (EdgeOutOfRangeException e3)
            {
            //System.out.println("! DataDirectorDimensionModel.size() - edge out of range !");
            getErrorHandler().error(e3, this.getClass().getName(), "getSize");
            }

        catch (Exception e)
            {
            getErrorHandler().error(e, this.getClass().getName(), "getSize");
            }
        }

    return (int) ret;
    }
  
    /**
     * @hidden
     */
    public int size()
    {
      return getSize();
    }

    /**
     * @hidden
     *
     * Process the ListDataListeners, do those events.
     *
     * @param  e  the <code>ListDataEvent</code> object.
     *
     * @status hidden
     */
    protected void notifyListDataListeners (ListDataEvent e)
        {
        if (m_listeners != null && m_listeners.size() > 0)
            {
            Vector    v;

            synchronized(this)
                {
                v = (Vector) m_listeners.clone();
                }

            int   count = v.size();

            for (int i = 0; i < count; i++)
                {
                ListDataListener client = (ListDataListener) v.elementAt(i);

                if (client != null)
                    {
                    if (e.getType() == ListDataEvent.INTERVAL_ADDED)
                        client.intervalAdded(e);
                    else if (e.getType() == ListDataEvent.INTERVAL_REMOVED)
                        client.intervalRemoved(e);
                    else
                        client.contentsChanged( e );
                    }
            else
            ; //System.out.println("notifyListDataListeners() - client is null!?");
            }
        }
    }
  
    /**
     * Adds a <code>Swing</code> <code>ListDataListener</code> to this object.
     *
     * @param  l  The <code>Swing</code> <code>ListDataListener</code> that you
     * want to add.
     *
     * @status documented
     */
    public void addListDataListener(ListDataListener l)
        {
        if (m_listeners == null)
            m_listeners = new Vector();

        if (!m_listeners.contains(l))
            {
            m_listeners.addElement(l);
            long nowCount = (long) size();
            ListDataEvent e = 
                new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, (int) nowCount);
            l.contentsChanged( e );
            }
        }

    /**
     * Removes a <code>Swing</code> <code>ListDataListener</code> from this object.
     *
     * @param The <code>Swing</code> <code>ListDataListener</code> that you want
     * to remove.
     *
     * @status documented
     */
    public void removeListDataListener(ListDataListener l)
        {
        if (m_listeners != null)
            {
            if (m_listeners.contains(l))
                m_listeners.removeElement(l);
            }
        }

    /**
     * Indicates whether you can drag the specified item.
     *
     * @param  index  The index of the item that you want to drag.
     * The index is the position of the item in the model.
     *
     * @return <code>true</code> if drag you can drag the specified item,
     * <code>false</code> otherwise.
     *
     * @status documented
     * @hidden
     */
    public boolean isDragable(long index)
        {
        return m_isDragable;
        }

    /**
     * Specifies whether you can drag this item.
     *
     * @return <code>true</code> if drag you can drag this item,
     * <code>false</code> otherwise.
     *
     * @status documented
     * @hidden
     */
    public void setIsDragable(boolean draggable)
        {
        m_isDragable = draggable;
        }
    
    /**
     * Indicates whether you can drop this item in the specified position in the
     * model.
     *
     * @param  index  The index of the position in which you want to drop this
     * item.
     *
     * @param  o  The item that you want to drop.
     *
     * @return  <code>true</code> if you can drop this item in the specified
     * position, <code>false</code> if you cannot.
     *
     * @status documented
     * @hidden
     */
    public boolean isDropTarget(long index, Object o)
        {
        return m_isDropTarget;
        }

    /**
     * Specifies whether you can drop items in the specified position in the
     * model.
     *
     * @return  <code>true</code> if you can drop this item in the specified
     * position, <code>false</code> if you cannot.
     *
     * @status documented
     * @hidden
     */
    public void setIsDropTarget(boolean dropTarget)
        {
        m_isDropTarget = dropTarget;
        }

    /**
     * Retrieves the item at the specified position in the model.
     *
     * @param  index   The index of the item in the model.
     *
     * @return  The item at the specified index in the model,
     * or <code>null</code> if there is an error.
     *
     * @status documented
     */
    public Object getElementAt(int index)
        {
        DefaultListDataItem di = null;
        String name         = "";
        String value        = "";
        String hierLevel    = "";
        int    indentLevel  = -1;
        int    drillState   = 0;

        if ((m_initOK) && (index != -1))
            {
            String s = null;

            int [] depthIndex = new int[0];

            if (!(index < getSize()))
              return null;

            //
            // we should actually validate what we are looking for using the m_metaTypes!
            //

            try
                {
                name =
                    DataUtils._makeString( m_dataAccess.getMemberMetadata(DataDirector.COLUMN_EDGE,
                         depthIndex, 0, index, m_labelType));

                value =
                    DataUtils._makeString( m_dataAccess.getMemberMetadata(DataDirector.COLUMN_EDGE,
                        depthIndex, 0, index, MetadataMap.METADATA_VALUE));

                if (value == null)
                  return null;

                // gek 04/05/00 If we couldn't find a name, default it to value
                if (name == null)
                    name = value;

                try
                    {
                    hierLevel = DataUtils._makeString(
                        m_dataAccess.getMemberMetadata(DataDirector.COLUMN_EDGE,
                            depthIndex, 0, index,
                                MetadataMap.METADATA_RELHIERINFO));

                    // quick test for fake data
                    if (hierLevel == null || hierLevel.equals(value) || hierLevel.equals(name))   
                        hierLevel = "";

                    try
                        {
                        indentLevel = 
                            ((Integer)(m_dataAccess.getMemberMetadata(DataDirector.COLUMN_EDGE, 
                                depthIndex, 0, index, 
                                    MetadataMap.METADATA_INDENT))).intValue();
                        
                    drillState  = 
                        ((Integer)(m_dataAccess.getMemberMetadata(DataDirector.COLUMN_EDGE, 
                            depthIndex, 0, index, 
                            MetadataMap.METADATA_DRILLSTATE))).intValue();
                        }
                
                    catch (Exception ex2)
                        {
                        // gek 04/07/00    
                        // If we are attempting to retrieve drill state or indent
                        // information and we don't find any, simply specify 0 like
                        // we do in the QueryManager's EdgeCursor getValue() method.
                        indentLevel = 0;
                        drillState = 0;
                        }
                    }

                catch (Exception ePlus)
                    {
                    getErrorHandler().error(ePlus, this.getClass().getName(), "getElementAt");
                    //System.out.println("DataDirectorDimensionModel: elementAt() - Exceptions accessing metadata - DataAccess problem?");
                    }

                di = new DefaultListDataItem(name, indentLevel, drillState,
                     name, value, hierLevel);
                }
        
            catch (SliceOutOfRangeException e1)
                {
                //System.out.println("! DataDirectorDimensionModel.elementAt(" + 
                //    index + ") - slice out of range !");
                getErrorHandler().error(e1, this.getClass().getName(), "getElementAt");
                }
        
            catch (LayerOutOfRangeException e2)
                {
                //System.out.println("! DataDirectorDimensionModel.elementAt(" + 
                //  0 + ") - layer out of range !");
                getErrorHandler().error(e2, this.getClass().getName(), "getElementAt");
                }

            catch (EdgeOutOfRangeException e3)
                {
                //System.out.println("! DataDirectorDimensionModel.drill(" +
                //     DataDirector.COLUMN_EDGE + ", ...) - edge out of range !");
                getErrorHandler().error(e3, this.getClass().getName(), "getElementAt");
                }
            }

        return di;
        }

    /**
     * Sets the error handler.
     *
     * @param errorHandler The error handler.
     *
     * @status hidden
     */
    public void setErrorHandler(ErrorHandler errorHandler)
        {
        m_errorHandler = errorHandler;
        }

    private ErrorHandler getErrorHandler()
        {
        if (m_errorHandler == null)
            {
            m_errorHandler = new DefaultErrorHandler();
            }

        return m_errorHandler;
        }
    }