
package oracle.dss.dataSource.client;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */


import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.Enumeration;
import java.util.EventObject;
import java.util.Vector;

import oracle.dss.connection.common.BISession;

import oracle.dss.connection.server.ConnectionImpl;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryManagerObject;
import oracle.dss.dataSource.common.EventList;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.dataSource.common.MMListener;
import oracle.dss.dataSource.common.QueryConstants;

import oracle.dss.metadataManager.server.MetadataManagerImpl;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.connection.common.CB;
import oracle.dss.connection.client.Connection;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.MM;


import oracle.dss.util.ErrorHandlerCallback;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.parameters.ParameterValueManager;
import oracle.dss.util.persistence.PersistableAttributes;


/**
 *      Main QueryManager bean. This bean performs services for all the
 *      Query beans that it tracks. These services include
 *      providing database support and providing methods to add, create,
 *      remove, or close <code>Query</code> objects.
 *
 * @status Documented
 */
public class QueryManager extends Object implements ErrorHandlerCallback, oracle.dss.dataSource.common.QueryManager
    {

    /////////////////////
    //
    // Constants
    //
    /////////////////////

    // Debug flags

    // Setting DEBUG to false turns off all debugging 'System.out.println'
    // statements.  This should be the default for release code!

    // Setting DEBUG to true turns on lots of debugging 'System.out.println'
    // statements.  This is helpful for debugging!

    /**
     * @hidden
     * Indicates whether debugging statements should be produced.
     *
     * @status Documented
     */
    public final static boolean DEBUG = false;

    /////////////////////
    //
    // Member Variables
    //
    /////////////////////

    // Bundle
    protected ResourceBundle rBundle = null;
    
    // Listener for MM events
    private transient MMListener m_MMListener = new MMListener(this);

    /**
     * @hidden
     */
    protected transient Hashtable m_implementationObjectTable = new Hashtable();

    /**
     * @hidden
     */
    protected transient QueryManagerObject qmProxy = null;
    
    /**
     * @hidden
     */
    protected Hashtable m_queryTable = new Hashtable();

    /**
     * @hidden
     * @serial Data source name
     */
    protected String    m_name    = null;
    
    // BISession setting
    /**
     * @hidden
     */
    protected transient BISession m_biSession = null;

    // Has the error handler been set by a user?
    /**
     * @hidden
     */
    protected boolean m_ehHasBeenSet = false;

    // Locale setting
    private transient Locale m_locale = null;    
    
    // Temporary pending client-side event list
    /**
     * @hidden
     */
    protected transient EventList   events = new EventList();
    
    // Debug mode
    private transient boolean   m_debugMode = false;

    // Divide by zero allowed
    private transient boolean m_allowDivideByZero = QueryConstants.DEFAULT_ALLOW_DIVIDE_BY_ZERO;

    // Property bundle
    private transient Hashtable m_properties = new Hashtable();
    
    // SQL printing?
    private transient long    m_dumpSQLType = 0;

    // Totals self calced?
    private transient boolean   m_selfCalcTotals = true;

    // SQL generation type
    private transient long      m_querySQLType = 0;

    // Query only
    private transient boolean   m_queryValueOnly = false;

    // QueryAccess Debug mode
    private transient boolean   m_QADebugMode = false;

    // Hierarchical drilling mode
    private transient boolean   m_hierDrill = false;

    // Query state print mode
    private transient boolean m_printQueryState = false;

    // Asymmetric drilling allowed?
    private transient boolean m_asymDrill = true;

    // Expose all drill children?
    private transient boolean m_drillWithFilteredChildren = true;

    /**
     * @hidden
     * @serial Should annotations be allowed?
     */
    protected boolean m_allowAnnotations = false;
    
    // Fetch size
    private transient int m_fetchSize = 1000;

    // Full page fetch
    private transient boolean m_fullFetch = true;
    
    // Should query pages be separately fetched?
    private transient boolean m_separatePage = true;
    
    // Flag indicating persistent state has been just set
    /**
     * @hidden
     */
    protected transient boolean m_persistentStateSet = false;    

    /**
     * @hidden
     */
    protected transient MetadataManager m_database = null;
    

    // Error handler reference
    /**
     * @hidden
     */
    protected transient ErrorHandler m_eh = new DefaultErrorHandler();
    
    // Persistence name
    /**
     * @hidden
     */
    protected static final String XMLName = "QueryManager";
    
    // Persistance info
    /**
     * @hidden
     */
    protected transient PersistableAttributes m_attrs = null;

    /**
     * @hidden
     */
    protected boolean m_MMNotAvailable = false;

    // Database connection version
    private transient String m_connectionVersion = null;

    // Pluggable table
    /**
     * @hidden
     */
    protected Hashtable m_pluggableClasses = new Hashtable();

    // Parameter values (across all queries)
    private ParameterValueManager m_pvm = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    /**
     *  <pre>
     *      Constructor for the <code>QueryManager</code>.<br>
     *
     *  Example:
     *      QueryManager queryManager = new QueryManager ();
     *  </pre>
     *
     * @return     Newly constructed <code>QueryManager</code> object, or null.
     *
     * @status Documented
     */

    public QueryManager()
        {      
        // _setupProxy();
        _createQueryManager();

//        _setupCancelSupport();
    }

/*    private void _setupCancelSupport()
    {
        // Instantiate a pluggable cursor interface, if any
        Class pluggableClass = getPluggableClass("oracle.dss.dataSource.client.CancelSupportClientInterface");
        if (pluggableClass == null)
        {
            m_cancelSupport = new CancelSupportClient(this);
        }
        else
        {
            try
            {
                // Do the app's version
                Constructor cons = pluggableClass.getConstructor(new Class[] {QueryManager.class});

                m_cancelSupport = (CancelSupportClientInterface)cons.newInstance(new Object[] {this});
            }
            catch (Exception e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }
    }
*/

    /**
     * Alternate constructor that creates a client-side <code>QueryManager</code>
     * using an existing middle tier (server-side) proxy as a parameter.
     * This constructor is used when cloning.
     * For example, use this class when you have created a middle tier
     * <code>QueryManager</code> clone first and you want to connect it to a
     * clone on the client-side.
     *
     * @param dso An existing <code>QueryManager</code> proxy for cloning.
     *            For example, the proxy obtained through cloning a middle tier
     *            <code>QueryManager</code>.
     *            Subclasses of <code>QueryManager</code>
     *            must override this proxy and pass the argument to the
     *            <code>QueryManager</code> superclass.
     *
     * @return New <code>QueryManager</code>.
     *
     * @status Documented
     */
/*    public QueryManager(QueryManagerServer qms) {
        if (qms == null) {
            //_setupProxy();
        }
        else {
            // Set proxy
            qmProxy = (QueryManagerObject)qms;
            // Use the JBO-generated name
//            setName(qmProxy.getName());
            //qmProxy.setCallbackObject(this);
        }
        
        // Call for rest of setup
        _createQueryManager();
    }*/

    /////////////////////
    //
    // Methods
    //
    /////////////////////

    /**
     * Specifies the BISession object.
     *
     * @param session User's BISession object
     *
     * @status Documented
     */
    public void setSession(BISession session)
    {
        m_biSession = session;
        if (session == null)
        {
            return;
        }
        // Set up the proxy
        /** gek 11/03/06
        try
        {
            _setupProxy();
        }
        catch (BCJException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        */
   
        if (!m_ehHasBeenSet && session.getErrorHandler() != null)
        {
            addErrorHandler(session.getErrorHandler());
            m_ehHasBeenSet = false;
        }
    }
    
    /**
     * Retrieves the BISession object. 
     *
     * @return BISession object
     *
     * @status Documented
     */
    public BISession getSession() 
    {
        return m_biSession;
    }

    /**
     * @hidden
     * 
     */
/*    public void flushDataAccessCache()
    {
        if (getProxy() != null)
            getProxy().flushDataAccessCache();
    }*/

    /**
     * @hidden
     */
    public String getDatabaseString()
    {        
        MetadataManager mm = getMetadataManager();        
        if (mm != null && mm.getDatabaseStrings() != null && mm.getDatabaseStrings().length > 0)
        {
            // Find the MDM connection
            String[] connStrs = getMetadataManager().getConnectionStrings();
            if (connStrs != null && connStrs.length == 1 && connStrs[0] == null)
            {
                // This may indicate an ONS connection
                Connection[] conns = getMetadataManager().getConnections();
                for (int i = 0; i < conns.length; i++)
                {
                    if (conns[i] != null && conns[i].getOLAPServiceName() != null)
                    {
                        connStrs[0] = conns[i].getOLAPServiceName();
                        break;
                    }
                }
            }
            if (connStrs != null)
            {
                Connection ci = null;
                for (int i = 0; i < connStrs.length; i++)
                {
                    ci = null;
                    try
                    {
                        ci = mm.getConnection(connStrs[i]);                    
                    }
                    catch (NullPointerException npe)
                    {
                    }                        
                    if (ci != null && ci.getDriverType() != null && ci.getDriverType().equals(MM.MDM))
                    {
                        // Found the MDM
                        return mm.getDatabaseString(connStrs[i]);                        
                    }
                }
            }
        }
        return null;
    }

    public void setLocale(Locale loc)
    {
        m_locale = loc;
        updateResourceBundle(loc);
    }

    public Locale getLocale()
    {
        if (m_locale != null)
        {
            return m_locale;
        }
        return m_biSession != null ? m_biSession.getLocale() : null;
    }

    /**
     * @hidden
     */
    protected void updateResourceBundle(Locale loc)
    {
        if (loc != null)
        {
            rBundle = ResourceBundle.getBundle("oracle.dss.dataSource.common.resource.QueryCommonBundle", loc);
        }
        else
        {
            rBundle = ResourceBundle.getBundle("oracle.dss.dataSource.common.resource.QueryCommonBundle");
        }
    }
    
    /**
     * @hidden
     * Access client-side common resources
     */
    public String getResourceString(String key) {
        // Set up resources
        if (rBundle == null)
        {
            Locale loc = getLocale();
            updateResourceBundle(loc);
        }
        if (rBundle != null)
        {
            return rBundle.getString(key);
        }
        return key;
    }

    // Set up the proxy if not there
    /**
     * @hidden
     */

    /** gek 11/03/06
    protected void _setupProxy() throws BCJException
    {
//        Resources.setUpResources(this.getErrorHandler());
        
        // Try not to use JBO during design time for now
        if (!isDesignTime()) {
            //if (DEBUG)
                //getErrorHandler().trace("Retrieving appmodule...", getClass().getName(), "_setupProxy");    
            if (qmProxy == null){
                qmProxy = new QueryManagerServer();

                //if (qmProxy != null) {
                    // Use the JBO-generated name
                    //setName(qmProxy.getName());
                //}
            }

            //qmProxy.setCallbackObject(this);
            if (DEBUG)
                getErrorHandler().trace("Done.", getClass().getName(), "_setupProxy");

            // Send current option settings across the wire
        }
    }
    */
    
    /**
     * @hidden
     * @return 
     */
    public ConnectionImpl getConnectionImpl(MetadataManagerImpl mm)
    {
        try
        {
            // Find the MDM driver connection
            ConnectionImpl connections[] = mm.getConnectionImpls();
            for (int i = 0; i < connections.length; i++)
            {
                if (connections[i].getDriverType().equals(MM.MDM))
                {
                    return connections[i];
                }
            }
        }
        catch (MetadataManagerException e)
        {
        }
        return null;
    }
        
    // Do common piece of setup for both constructors
    /**
     * @hidden
     */
    protected void _createQueryManager() {
        // Set up operation queue
    }
    
    
    // Determine if the proxy is the query manager server
    /**
     * @hidden
     */
/*    protected Class getLocalProxyClass()
    {
        try
        {
            return Class.forName("oracle.dss.dataSource.QueryManagerServer");
        }
        catch (ClassNotFoundException cnfe)
        {
        }
        return null;
    }*/
    
    /**
     * Adds the specified <code>Query</code> object to the list of Queries
     * that are tracked by this <code>QueryManager</code>. This addition lets
     * the newly added <code>Query</code> object have state and evaluate.
     *
     * @param query The <code>Query</code> object to affiliate with the middle
     *              tier state.
     *
     * @return The query ID that is assigned to this <code>Query</code> object.
     *
     * @status Documented
     */
    public String addQuery(Query query)
    {
        String id = query.getID();
        if (id != null)
        {
            return _addQuery(id, query);
        }
/*        if (getProxy() != null)
        {
            id = getProxy().addQuery(null);
            query.setID(id);
        }*/
        return null;
    }
    
    /**
     * @hidden
     */
    protected String _addQuery(String id, Query query)
    {
        m_queryTable.put(id, query);
        return id;
    }
    
    /**
     * Removes the specified <code>Query</code> object from the list of
     * <code>Query</code> objects that are tracked by this
     * <code>QueryManager</code>. Also releases the storage
     * that was associated with the removed <code>Query</code> object.
     *
     * @param query The <code>Query</code> object to remove.
     *
     * @status Documented
     */
    public void removeQuery(Query query)
    {
        _removeQuery(query);
    }    

    /**
     * @hidden
     */
    protected void _removeQuery(Query query)
    {
        if (query != null)
        {
            m_queryTable.remove(query.getID());
        }
    }
    
    /**
     * @hidden
     * Get the query from the table
     */
    public Query getQuery(String id)
    {
        return (Query)m_queryTable.get(id);
    }

    /**
     * Retrieves a list of all of the <code>Query</code> objects that are being
     * tracked by this <code>QueryManager</code> object.
     *
     * @return An enumeration of <code>Query</code> objects.
     *
     * @status Documented
     */
    public Enumeration getQueries()
    {
        return m_queryTable.elements();
    }

    /**
     * Creates an empty <code>Query</code> object.
     *
     * @return The uninitialized <code>Query</code> object.  
     *         Returns <code>null</code> if the call failed.
     *
     * @status Documented
     */
    public Query createQuery()
    {
        try
        {
            Query query = new QueryClient(this);
            return query;        
        }
        catch (Exception e)
        {
            getErrorHandler().log(e.toString(), getClass().getName(), "createQuery");
        }
        return null;
    }

    
    /**
     * @hidden
     */
/*    public ReturnObject executeQuery(String queryID, QueryState state) throws Exception
    {
        return getDataService().executeQuery(queryID, state);
    }*/
    
    /**
     * @hidden
     */
/*    public QueryManagerObject.ReturnObject executeProperties(String queryID, QueryState state, Object data) throws Exception
    {
        return getDataService().executeProperties(queryID, state, data);
    }*/

    /**
     * @hidden
     */
    /*public QueryManagerObject.ReturnObject executeRefresh(String queryID, QueryState state, int type) throws Exception
    {
        return getDataService().executeRefresh(queryID, state, type);
    }*/
    
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public QueryManagerObject.ReturnObject executePivot(String queryID, QueryState state, String source, String target, int flags, Selection[] selsChanged) throws Exception
    {
        return getDataService().executePivot(queryID, state, source, target, flags, selsChanged);
    }*/

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public QueryManagerObject.ReturnObject executeApplySelections(String queryID, QueryState state, Selection[] selections, Selection oldSel) throws Exception
    {
        return getDataService().executeApplySelections(queryID, state, selections, oldSel);
    }*/
    
    /**
     * @hidden
     */
/*    protected QueryManagerObject getDataService()
    {
        return getProxy();
    }*/
    
    /********** Persistable interface ********************/
    /**
     * @hidden
     */
    public void initialize(Hashtable env)
    {
    }

    /**
     * @hidden
     * Retrieves the XML representation of the query.
     * 
     * @return <code>String</code> which represents the XML representaion 
     *         of the query. 
     */
    public String getXMLAsString()
        {
        return null;
        }


    /**
     * @hidden
     * Set the XML representation of the query.
     * 
     * @param xml a <code>String</code> value that represents the 
     *        xml string that we wish to initialize query with.
     */
/*    public boolean setXMLAsString(String xml) throws BIPersistenceException
        {
        m_persistentStateSet = true;
        if (getProxy() != null) {
            // Must produce a QueryClient for each query server
            java.util.List idList = getProxy().getQueryIDs();
            java.util.Iterator iter = idList.iterator();
            while (iter.hasNext())
            {
                QueryClient qc = new QueryClient();
                try
                {
                    qc._setQueryManager(this, false, true);
                }
                catch (Throwable e)
                {
                    throw new BIPersistenceException(e.getMessage(), (Exception)e);
                }
                
                int id = ((Integer)iter.next()).intValue();
                qc.setID(id);
                try
                {
                    qc.syncQuery();
                }
                catch (CloneNotSupportedException e)
                {
                    throw new BIPersistenceException(e.getMessage(), e);
                }
                m_queryTable.put(new Integer(id), qc);                
            }
            //propSupport.setUpBoundSupport(this);
        }
        return true;
        }
*/
    /**
     * @hidden
     * Retrieves the components (e.g. selections) associated 
     * with the query.
     * 
     * @return <code>AggregateInfo[]</code> which represents the components
     *         associated with the query.
     */
/*    public AggregateInfo[] getPersistableComponents()
        {
            return null;
        }
*/
    /**
     * @hidden
     * Specifies the components (e.g. selections) associated 
     * with the query.
     *
     * @param aggregates a <code>AggregateInfo[]</code> value that represents the 
     *        components to assign to the query.
     */
/*    public void setPersistableComponents(AggregateInfo[] infos)
        {
        }
*/
    /**
     * @hidden
     */
/*    public PersistableAttributes getPersistableAttributes(PersistableAttributes oldAttrs)
        {
        if (m_attrs == null)
            {
            m_attrs = new PersistableAttributes();
            }
            
        if (oldAttrs != null) 
            {
            m_attrs.merge(oldAttrs);
            }
        
        m_attrs.setObjectType(PersistableConstants.QUERYMANAGER);

        return m_attrs;
        }
*/
    /**
     * @hidden
     */
/*    public void setPersistableAttributes(PersistableAttributes attrs)
        {
        this.m_attrs = m_attrs;
        }
*/
    /**
     * @hidden
     */
/*    public String getTagName()
    {
        return XMLName;
    }
    */
    /**
     * @hidden
     */
/*    public Object getXML(XMLContext con)
    {
        return null;
    }
*/
    
    /**
     * @hidden
     */
/*    public void setXML(XMLContext context, Object node)
    {
    }    
*/
    /********* JboContainer ***********/


    /**
     * @hidden
     */
/*    public QueryManagerObject getProxy() 
    {
        if (qmProxy == null)
        {
            try
            {
                // do this to get the exception immediately to the error handler
                throw new BCJException(getResourceString("Middle tier proxy not set"),null);
            }
            catch (Exception e)
            {
            }
        }
        return qmProxy;
    }
*/
    /**
     * @hidden
     */
/*    public void setProxy(Object proxy)
    {
        qmProxy = (QueryManagerObject)proxy;
    }*/
        
    /////////////////////
    //
    // Get/Set Methods
    //
    /////////////////////

    /**
     * Retrieves the <code>MetadataManager</code> object that is currently
     * associated with this <code>QueryManager</code> object.
     *
     *  @return A <code>MetadataManager</code> object or null.
     *
     *  @status Documented
     */
    public MetadataManager getMetadataManager()
        {
        return m_database;
        }

    /**
     * Specifies the <code>MetadataManager</code> object that is to be
     * associated with this <code>QueryManager</code>.
     * In order to function properly, the <code>QueryManager</code> requires
     * that this property be set.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param  manager    A reference to the <code>MetadataManager</code>
     *                     that provides access to the logical database that
     *                     the QueryManager will use when supplying data to its
     *                     <code>Query</code> objects.
     *
     * @status Documented
     */
    public void setMetadataManager(MetadataManager manager)
        {
        if (m_database != null)
        {
            // Remove listener from old MM
            m_database.removeListener(m_MMListener);
        }
        
        m_database = manager;

        m_connectionVersion = null;

        if (m_database != null)
        {
            // Add listener to MM
            m_database.addListener(m_MMListener);
            // Reverse no MM required
            m_MMNotAvailable = false;
        }

        //MetadataManagerImpl mm = (MetadataManagerImpl)getMetadataManager().getProxy();
        //ConnectionImpl conn = getConnectionImpl(mm);
        /** gek 11/03/06
        ((QueryManagerServer)qmProxy).setOLAPServices(new OLAPServicesImpl(conn, mm));
        */  

        // Must communicate this back to the middle tier via JBO, and hook up
        // corresponding middle tier bean
     
        //if (!isDesignTime())
        //   {
        //       String IOR = null;
        //       IOR = getProxy().setMetadataManager(manager.getProxy());
        //       m_cancelSupport.setup(manager, IOR);
        //   }


        if (m_persistentStateSet )
        {
            try
            {
                informQueriesOfMetadataManager(isDatabaseAvailable());
            }
            catch (Exception e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }
        
        // Register with mm
        manager.addToEnvironment(Query.QUERY_MANAGER, this);
        m_persistentStateSet = false;
      }

    /**
     * @hidden
     * Register a pluggable interface or definition implementation table specifying
     * a Query interface name String (such as "oracle.dss.dataSource.common.CursorInterface") keying
     * a value giving an application's class name String that implements that interface, and that the
     * Query should instantiate instead of its default.  All of the keys found in the given
     * table will be processed and either added to or deleted from a master table that applies to all queries generated
     * from this QueryManager, depending on the add parameter.
     *
     * @param table a Hashtable specifying a key String of a pluggable Query class or interface name, with a corresponding
     *        value specifying an application's implementation of that pluggable class or interface.
     * @param add <code>true</code> to add the keys in table to the master table, <code>false</code> to delete them
     *
     * @status hidden
     */
    public void registerPluggableClasses(Hashtable table, boolean add)
    {
        // Walk through the entire table
        Enumeration keys = table.keys();
        while (keys.hasMoreElements())
        {
            String pluggable = (String)keys.nextElement();
            if (pluggable != null)
            {
                Class className = (Class)table.get(pluggable);
                if (className != null)
                {
                    if (add)
                    {
                        m_pluggableClasses.put(pluggable, className);
                    }
                    else
                    {
                        m_pluggableClasses.remove(pluggable);
                    }
                }
            }
        }

        // Now do the same thing on the server
//        qmProxy.registerPluggableClasses(table, add);
    }

    /**
     * @hidden
     * Get the plugged in application class name for a given pluggable class or interface name, if any
     */
    public Class getPluggableClass(String pluggable)
    {
        return (Class)m_pluggableClasses.get(pluggable);
    }


    // Is a database currently attached and available
    /**
     * @hidden
     */
    protected boolean isDatabaseAvailable()
    {
        return m_database != null && m_database.getAttachStatus() == MM.ATTACHED;
    }

    /**    
     * @hidden
     * Inform all queries of metadata manager database connection
     */
    public String informQueriesOfMetadataManager(boolean available) throws Exception
    {
/*        Enumeration queries = getQueries();
        while (queries.hasMoreElements())
        {
            Query query = (Query)queries.nextElement();
            try
            {
                query._databaseSet(available);
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                    throw (Exception)e;
            }
        }*/
        return null;
    }

    /**
     * Adds a single error handler to this <code>QueryManager</code> bean.
     * The error handler will be called when the visual component traps an
     * error from other parts of the system.
     *
     * @param eh Error handler object.
     *
     * @status Documented
     */
    public void addErrorHandler(ErrorHandler eh) {
        if (eh != null) {
            m_ehHasBeenSet = true;
            m_eh = eh;
/*            if (getSession() != null && getSession().getDeploymentOption() != null && getSession().getDeploymentOption().equals(BISession.LOCAL))
            {
                // Now test for local proxy and put eh there too
                Class proxyClass = getLocalProxyClass();
                if (proxyClass != null)
                {
                    Method aeh = null;
                    try
                    {
                        aeh = proxyClass.getMethod("addErrorHandler", new Class[] {ErrorHandler.class});                    
                    }
                    catch (NoSuchMethodException nsme)
                    {            
                        return;
                    }    
                    try
                    {
                        aeh.invoke(getProxy(), new Object[] {eh});
                    }
                    catch (IllegalAccessException iae)
                    {
                    }
                    catch (InvocationTargetException ite)
                    {
                    }
                }
            }
  */      }
    }
    
    /**
     * Removes the error handler from this <code>QueryManager</code> bean.
     *
     * @status Documented
     */
    public void removeErrorHandler() {
        addErrorHandler(new DefaultErrorHandler());
        m_ehHasBeenSet = false;
    }
    
    /**
     * @hidden
     * Get the current error handler.
     * 
     * @return current error handler
     */
    public ErrorHandler getErrorHandler() {
        return m_eh;
    }    
   
    /**
     * Clones this <code>QueryManager</code> object.
     *
     * @return A newly-created copy of this <code>QueryManager</code>.
     *
     * @throws CloneNotSupportedException If a <code>QueryManager</code> cannot
     *                                    be cloned.
     *
     * @status Documented
     */
    public Object clone() throws CloneNotSupportedException
    {
       // Must clone the JBO side, then this client side
        // Create a new middle tier copy of the middle tier query Manager
            QueryManager qm = null;
            // Find the constructor that takes the elevated interface as an argument
            try {
                qm = new QueryManager();
            }
            catch (Exception e) {
                throw new CloneNotSupportedException(getResourceString("Could not create new instance of QueryManager or subclass when cloning"));
            }
            
            // Copy properties
            qm.m_database = m_database;
            // Copy debug mode
            qm.m_debugMode = m_debugMode;
            
            Hashtable queries = m_queryTable;
            Enumeration iter = queries.keys();
            while (iter.hasMoreElements())
            {
                String oldID = (String)iter.nextElement();
                String newID = (String)queries.get(oldID);
                // Create a client query and put it in the new QM's list
                //QueryClient qc = new QueryClient(qm);
                QueryClient query = (QueryClient)getQuery(oldID);
                QueryClient qc = null;
                try
                {
                    qc = (QueryClient)query._clone(query.isEvaluateCursor());
                    qc._setQueryManager(qm, false, true);
                }
                catch (Throwable e)
                {
                    throw new CloneNotSupportedException(e.getMessage());
                }
                qc.setID(newID);
                qm.m_queryTable.put(newID, qc);
                if (query.isEvaluateCursor())
                {
                    try
                    {
                        qc.refresh(true);
                    }
                    catch (Exception e)
                    {
                        throw new CloneNotSupportedException(e.getMessage());
                    }
                }

        }
        return qm;        
    }
    
    
    /**
     * Specifies the name of this <code>QueryManager</code> object.
     *
     * @param n The name of this <code>QueryManager</code> object.
     *
     * @status Documented
     */
    public void setName(String n) {
        //nameSet = true;
        m_name = n;
    }
    
    /**
     * Retrieves the name of this <code>QueryManager</code> object.
     *
     * @return The name of this <code>QueryManager</code> object.
     *
     * @status Documented
     */
    public String getName() {
        //if (nameSet)
            //return name;
            
        //nameCount++;
        //name = "query" + Integer.toString(nameCount).trim();
        //nameSet = true;
        return m_name;
    }
    

    /**
     * Indicates whether debug printouts should be produced.
     *
     * @param mode <code>true</code> produces debug printouts on both
     *             client and server;
     *             <code>false</code> does not produce debug printouts.
     */
    public synchronized void setDebugMode(boolean mode) {
        m_debugMode = mode;

    }

    /**
     * Indicates whether debug printouts will be produced.
     *
     * @return <code>true</code> indicates that debug printouts will be
     *         produced; <code>false</code> indicates that debug printouts
     *         will not be produced.
     *
     * @status Documented
     */
    public boolean isDebugMode() {
        return m_debugMode;
    }

    /**
     * @hidden
     * Determines whether calculation divide by zero conditions will result
     * in NA values (<code>true</code>) or Exceptions (<code>false</code>, and the default).
     *
     * @param allowed if <code>true</code>, divide by zero calculation errors return an NA value.
     *
     * @status New
     */
    public void setAllowDivideByZero(boolean allowed)
    {
        m_allowDivideByZero = allowed;
    }

   /**
    * Sets the value of the given property on the Query.
    * <code>property</code> should be one of the PROPERTY_
    * constants defined in <code>QueryConstants</code>, and the
    * <code>value</code> should match the description there for
    * the given property.
    *
    * @param property name of the property to set, from <code>QueryConstants</code>
    * @param value value of the property to set
    *
    * @see oracle.dss.dataSource.common.QueryConstants
    * @throws Exception if an error occurs
    * @status New
    */
   public void setProperty(String property, Object value) throws Exception
   {
        m_properties.put(property, value);
//        if (getProxy() != null)
            //getProxy().setProperty(property, value);

   }

    /**
     * Gets the value of the given property on the QueryManager.
     * 
     * @return Value of the property, or null if the property doesn't exist or hasn't
     * been set
     */
    public Object getProperty(String property)
    {
        if (property == null)
            return null;
            
        return m_properties.get(property);
    }

    /**
     * @hidden
     */
   public Hashtable getProperties()
   {
        return m_properties;
   }

    /**
     * @hidden
     * Do calc divide by zero errors result in NA or an Exception?
     *
     * @return <code>true</code> if an NA is returned, <code>false</code>
     *         if an Exception is thrown (default).
     *
     * @status New
     */
    public boolean isAllowDivideByZero()
    {
        return m_allowDivideByZero;
    }
    
    /**
     * @hidden
     * Indicates whether QueryAccess debug printouts should be produced.
     *
     * @param mode <code>true</code> produces QA debug printouts on both
     *             client and server;
     *             <code>false</code> does not produce QA debug printouts.
     */
    public synchronized void setQADebugMode(boolean mode) {
        m_QADebugMode = mode;
        Enumeration queries = getQueries();
        while (queries.hasMoreElements())
        {
            ((Query)queries.nextElement()).m_QADebugMode = mode;
        }
    }

    /**
     * @hidden
     * Indicates whether QueryAccess debug printouts will be produced.
     *
     * @return <code>true</code> indicates that QA debug printouts will be
     *         produced; <code>false</code> indicates that QA debug printouts
     *         will not be produced.
     *
     * @status hidden
     */
    public boolean isQADebugMode() {
        return m_QADebugMode;
    }

   /**
     * Indicates whether query state printouts should be produced on every query operation.
     *
     * @param mode <code>true</code> produces state printouts on
     *             server;
     *             <code>false</code> does not produce state printouts.
     */
    public synchronized void setPrintQueryState(boolean mode) {
        m_printQueryState = mode;

    }


   /**
     * Indicates whether query state printouts should be produced on every query operation.
     *
     * @return <code>true</code> indicates that state printouts will be
     *         produced; <code>false</code> indicates that state printouts
     *         will not be produced.
     */
    public boolean isPrintQueryState()
    {
        return m_printQueryState;
    }

    /**
     * @hidden
     * Indicates whether OLAP Services SQL should be dumped out with each Query update
     *
     * @param type Value greater than zero indicates that printouts should be produced using
     *             the given OLAP Services getGenerationInfo type.
     */
    public void setSQLDump(long type)
    {
        m_dumpSQLType = type;

    }


    /**
     * @hidden
     * Indicates whether OLAP Services SQL should be dumped out with each Query update
     *
     * @return A value greater than zero indicates that it will.
     */
    public long getSQLDump()
    {
        return m_dumpSQLType;
    }

    /**
     * @hidden
     * Allows caller to turn on OLAP Services debug SQL generation for cursor managers
     *
     * @param type OLAP Services ExpressGenerationInfo type (note a value of zero will turn the generation off, and
     *        is the default)
     */
    public void setQuerySQLType(long type)
    {
        m_querySQLType = type;
    }

    /**
     * @hidden
     * Returns the type of SQL OLAP Services should generate.
     *
     * @return A value greater than zero indicates the type of SQL generated.
     */
    public long getQuerySQLType()
    {
        return m_querySQLType;
    }

    /**
     * @hidden
     *
     * Tells the query to strip the query down to just value columns
     *
     * @param valueOnly strip the query down to just value columns if true (default is false)
     */
    public void setQueryValueOnly(boolean valueOnly)
    {
        m_queryValueOnly = valueOnly;
    }

    /**
     * @hidden
     * Returns whether the query operates only on the value columns.
     *
     * @return <code>true</code> if only value is part of query
     */
    public boolean isQueryValueOnly()
    {
        return m_queryValueOnly;
    }

    /**
     * @hidden
     * Set whether row/col totals should be calculated from the cursor
     * without using extra queries.
     *
     * @param self <code>true</code> if all row/col calculations should be
     *             self-calculated
     * @throws Exception if there is a problem setting the self calc.
     */
    public void setSelfCalcTotals(boolean self) throws Exception
    {
        m_selfCalcTotals = self;
/*        if (qmProxy != null)
        {
            getProxy().setSelfCalcTotals(null, self);
        }*/
    }

    /**
     * @hidden
     * Retrieves the self calc total setting
     *
     * @return whether totals are self calculated or not
     */
    public boolean isSelfCalcTotals()
    {
        return m_selfCalcTotals;
    }

    /**
     * Specifies the fetch buffer size.
     *
     * @param size The number of values to fetch per buffer read
     *             for cursors.  A setting of -1 turns partial fetching off 
     *             and fetches the entire cursor.
     *             
     * @status Documented
     */
    public void setFetchSize(int size)
    {
        m_fetchSize = size;

    }

    /**
     * Retrieves the currently-set fetch buffer size.
     *
     * @return The currently-set fetch buffer size. 
     *         The value -1 indicates that fetch all is set.
     *
     * @status Documented
     */
    public int getFetchSize()
    {
        return m_fetchSize;
    }

   /**
     * @hidden
     * Sets whether entire page edges are fetched.  Default is <code>true</code>.
     *
     * @param fullfetch if <code>true</code>, the page edge is fully fetched.  If not, partial fetching applies.
     */
    public void setFetchPageEdge(boolean fullfetch)
    {
        m_fullFetch = fullfetch;
 
    }

    /**
     * @hidden
     * Returns whether entire page edges are fetched.
     *
     * @return <code>true</code> if entire page edges are fetched.
     *
     * @status New
     */
    public boolean getFetchPageEdge()
    {
        return m_fullFetch;
    }
    
    /**
     * Specifies whether pages are fetched as separate cursors.
     *
     * @param separate <code>true</code> separates page cursors from the data 
     *                 cursor,
     *                 <code>false</code> does not fetch separate cursors for
     *                 pages.
     *                 
     * @status Documented
     */
    public void setSeparatePage(boolean separate)
    {
        m_separatePage = separate;

    }

    /**
     * Indicates whether page cursors are fetched separately from data cursors.
     *
     * @return <code>true</code> indicates that page cursors are fetched 
     *                           separately from data cursors,
     *         <code>false</code> indicates that the entire query is fetched
     *                            as one cursor.
     *
     * @status Documented
     */
    public boolean isSeparatePage()
    {
        return m_separatePage;
    }

   /**
     * @hidden
     * Indicates whether Queries in this QueryManager should expect
     * the MetadataManager to exist
     *
     * @param metadataManager set to true if limited API without the MetadataManager/Connection
     *                        should be enabled (default is false)
     * @status hidden
     */
    public void setMetadataManagerNotAvailable(boolean metadataManager)
    {
        m_MMNotAvailable = metadataManager;
    }

    /**
     * @hidden
     * Does this QueryManager require the MetadataManager to do certain 
     * storage operations?
     *
     * @return true if no, false if not (default)
     * 
     * @status hidden
     */
    public boolean isMetadataManagerNotAvailable()
    {
        return m_MMNotAvailable;
    }

    /**
     * @hidden
     * Dump a list of currently open queries, by ID, to the error handler
     */
    public void listOpenQueries()
    {
        Enumeration ids = m_queryTable.keys();
        ErrorHandler eh = getErrorHandler();
        int total = 0;
        while (ids.hasMoreElements())
        {
            String id = (String)ids.nextElement();
            total++;
            if (eh != null)
            {
                eh.trace("Query ID = " + id, getClass().getName(), "listOpenQueries");
            }
            else
            {
                System.out.println("Query ID = " + id);              
            }
        }
        if (eh != null)
            eh.trace("Total of " + total + " open queries.", getClass().getName(), "listOpenQueries");
        else
            System.out.println("Total of " + total + " open queries.");
    }

    /**
     * Indicates whether asymmetric drilling should be used
     *
     * @param asymmetric <code>true</code> to use asymmetric drilling
     */
    public void setAsymmetricDrilling(boolean asymmetric)
    {
        m_asymDrill = asymmetric;

    }

    /**
     * Indicates whether asymmetric drilling is set.
     *
     * @return <code>true</code> if asymmetric drilling is set;
     *         <code>false</code> if asymmetric drilling is not set.
     *
     * @status Documented
     */
    public boolean isAsymmetricDrilling()
    {
        return m_asymDrill;
    }

    /**
     * @hidden
     * Set whether or not to filter children when drilling down.
     * 
     * @param all		If <code>true</code>, drill children may be 
     * filtered by the query.  If 
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @status New
     */
    public void setDrillWithFilteredChildren(boolean filter)
    {
        m_drillWithFilteredChildren = filter;

    }
 
    /**
     * @hidden
     * Get whether or not to filter children when drilling down.
     * 
     * @return	If <code>true</code>, drill children may be filtered by
     * the query.  If
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @status New
     */
    public boolean isDrillWithFilteredChildren()
    {
        return m_drillWithFilteredChildren;
    }

    /**
     * Specifies whether hierarchical drilling should be used exclusively.
     *
     * @param hierDrill <code>true</code> indicates always use hierarchical
     *                  drilling; <code>false</code> indicates drilling is
     *                  not restricted exclusively to hierarchical.
     *
     * @status Documented
     */
    public synchronized void setHierarchicalDrilling(boolean mode) {
        m_hierDrill = mode;

    }

   /**
     * Indicates whether hierarchical drilling is set exclusively.
     *
     * @return <code>true</code> if hierarchical drilling is used exclusively;
     *         <code>false</code> if hierarchical drilling is not set
     *         exclusively.
     *
     * @status Documented
     */
    public boolean isHierarchicalDrilling() {
        return m_hierDrill;
    }

    /**
     * @hidden
     * Specifies whether annotations should be allowed regardless of their
     * availability.
     *
     * @param allow  <code>true</code> allows annotations,
     *               <code>false</code> does not allow annotations.
     *               
     * @status Documented
     */
    public void setAnnotationsAllowed(boolean allow)
    {
        m_allowAnnotations = allow;

    }

    /**
     * @hidden
     * Retrieves whether annotations are allowed at all.
     *
     * @return <code>true</code> indicates that annotations are allowed,
     *         <code>false</code> indicates that annotations are not allowed.
     *
     * @status Documented
     */
    public boolean areAnnotationsAllowed()
    {
        return m_allowAnnotations;
    }

    /**
     * @hidden
     * Return the version number we're connected to
     */
    public String getConnectionVersionInfo(String type)
    {
        if (m_connectionVersion == null)
        {
            Connection conn = getConnection(type);
            if (conn != null)
            {
                PropertyBag bag = conn.getVersionInfo();
                m_connectionVersion = bag.getStrPropertyValue(CB.DATABASE_VERSION);
            }
        }

        return m_connectionVersion;
    }
    
    /**
     * @hidden
     * @return
     */
    protected Connection getConnection(String type)
    {
        // Find the MDM driver connection
        Connection connections[] = getMetadataManager().getConnections();
        if (connections == null)
        {
            return null;
        }
        for (int i = 0; i < connections.length; i++)
        {
            if (connections[i].getDriverType().equals(type))
            {
                return connections[i];
            }
        }
        return null;
    }


    /**
     * Cancels current processes on this connection, if possible.
     *
     * @return <code>true</code> if the code was found to send an interrupt;
     *         <code>false</code> if the code did not send an interrupt.
     *
     * @status Documented
     */
    public boolean cancel()
    {
        return false;
    }

    

    /**
     * Closes a specified list of <code>Query</code> objects.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param queryList List of the query objects to close.
     *
     * @status Documented
     */
    public void closeQueries(java.util.List queryList)
    {
        // Create a list of ids to close
        if (queryList == null)
            return;

        String[] idList = new String[queryList.size()];
        Query query = null;
        for (int i = 0; i < idList.length; i++)
        {
            query = (Query)queryList.get(i);
            if (query != null)
            {
                idList[i] = query.getID();
                query.close();
                _removeQuery(query);
            }
        }

    }

    /**
     * Closes any open <code>Query</code> objects, releases the storage
     * that is associated with those objects, and shuts down the
     * <code>QueryManager</code>.
     * Note this method may throw a QueryRuntimeException.
     *
     * @status Documented
     */
    public synchronized void close()
    {

        // Clean up locally
        Enumeration queries = getQueries();
        while (queries.hasMoreElements())
        {
            Query query = (Query)queries.nextElement();
            query.close();
            // Remove from list
            _removeQuery(query);
        }
        
        //getProxy().remove();
        qmProxy = null;
    }

    /**
     * @hidden
     */
    protected int getQueryCount()
    {
        // Get the number of queries known to the query manager, for reference counting
        return m_queryTable.size();
    }

    /**
     * @hidden
     */
    public Vector getMemberLevel(String hierarchy)
    {
        return (Vector)getEvaluatorImplementationObject(QueryConstants.ALL_STEP_MEMBERS_PREFIX + hierarchy);
    }

    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public void setMemberLevel(String hierarchy, MemberStep step)
    {
        Vector membersAndLevels = new Vector();
        membersAndLevels.addElement(step.getMembers());
        membersAndLevels.addElement(step.getLevels());
        setEvaluatorImplementationObject(QueryConstants.ALL_STEP_MEMBERS_PREFIX + hierarchy, membersAndLevels);
    }*/
    
    /**
     * @hidden
     */
    protected void setEvaluatorImplementationObject(String strID, Object obj)
    {
        if (obj == null)
            m_implementationObjectTable.remove(strID);
        else
            m_implementationObjectTable.put(strID, obj);
    }

    /**
     * @hidden
     */
    protected Object getEvaluatorImplementationObject(String strID)
    {
        return m_implementationObjectTable.get(strID);
    }
    
    /**
     * @hidden 
     * Process an event list from the piggyback manager.
     *
     * @param el list of events to process
     */
// TODO
    public void processEventList(EventObject[] elist, Query query) {
//        EventList el = (EventList)elisttemp;
	EventList el = new EventList();
	for (int i=0; i<elist.length; i++)
	    el.addElement(elist[i]);

        // Merge in the client-side event list with the given one and fire
        events.merge(el);

        // Swap in cursors if necessary
        // Need to obtain the new OLAPI cursor here!
        //events.setCursor(m_cubeCursor);
        
        // Copy local merged list and clean out actual list before firing, in case of
        // recursive client calls
        EventList newlist = (EventList)events.clone();
        events = new EventList();

        // Grab the cursor out of the event list after firing events, if any
        try
        {
            newlist.fire(this, query, null, false);
        }
        catch (Throwable e)
        {
            // Must throw this as a runtime exception now and catch it on the other side
            // because CallbackObject interface does not allow for an exception
            throw new QueryRuntimeException(e.getMessage(), e);
        }

    }

    /**
     * @hidden
     *
     * Retrieves the <code>MetadataManagerServices</code> object that is currently
     * associated with this <code>QueryManager</code> object.
     *
     * @return A <code>MetadataManagerServices</code> object or null.
     *
     * @status hidden
     */
    public MetadataManagerServices getMetadataManagerServices() {
      return getMetadataManager();
    }

    public void setParameterValueManager(ParameterValueManager pvm)
    {
        m_pvm = pvm;
    }
    
    public ParameterValueManager getParameterValueManager()
    {
        return m_pvm;
    }
    
    // ParameterValueMappingManager interface (all delegated to impl)
/*    public void clearValue(Parameter parameter) {
      m_parameterValue.clearValue(parameter);
    }
    
    public void setValue(Parameter parameter, Hashtable value, ParameterMap map) {      
      m_parameterValue.setValue(parameter, value, map);
    }

    public void setValue(Parameter parameter, Object value) {
      m_parameterValue.setValue(parameter, value);
    }
    
    public Hashtable getValue(Parameter parameter, ParameterMap map) {
      return m_parameterValue.getValue(parameter, map);
    }
    
    public Object getValue(Parameter parameter) {
      return m_parameterValue.getValue(parameter);
    }
    
    public void setParentParameterValueManager(ParameterValueManager parent) {
      m_parameterValue.setParentParameterValueManager(parent);
    }
    
    public ParameterValueManager getParentParameterValueManager() {
      return m_parameterValue.getParentParameterValueManager();
    }

    public void setOverridePrompt(Parameter parameter, String prompt) {      
      m_parameterValue.setOverridePrompt(parameter, prompt);
    }
    
    public String getOverridePrompt(Parameter parameter) {
      return m_parameterValue.getOverridePrompt(parameter);
    }

    public void removeMappedParameter(Parameter parameter) {
      m_parameterValue.removeMappedParameter(parameter);
    }

    public Parameter[] getMappedParameters() {
      return m_parameterValue.getMappedParameters();
    }

    public boolean isMappedParameter(Parameter parameter) {
      return m_parameterValue.isMappedParameter(parameter);
    }

    public void addMappedParameter(Parameter parameter) {
      m_parameterValue.addMappedParameter(parameter);
    }*/
}
