/*
 * HierLevelListener.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import java.awt.event.*;

/**
 * @hidden
 * The HierLevelListener interface defines methods which need to be
 * implemented by all the classes which need to ne notified when the
 * Hierarchy/Level setting has been changed.
 * @status hidden
 *
 */
public interface HierLevelListener
{
    /**
     * @hidden
     * Called when the hierarchy/level setting has been changed
     *
     * @param e - the HierLevelEvent describing the change
     * @hidden  
     */
     public abstract void hierLevelChanged(HierLevelEvent e);

}