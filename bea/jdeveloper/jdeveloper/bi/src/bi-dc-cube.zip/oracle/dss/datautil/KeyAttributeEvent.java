/*
 * KeyAttributeEvent.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil;

import java.util.Hashtable;

/**
 * @hidden
 * KeyAttributeEvent
 * 		
 */

public class KeyAttributeEvent extends Object
{
    //-------------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-------------------------------------------------------------------------

    /**
     * The attribute set created.
     *
     * @status New
     */
    protected Hashtable m_attributeSet = null;

    /**
     * The key being parsed
     *
     * @status New
     */
    protected String m_attributeKey = null;

    /**
     * The value being parsed
     *
     * @status New
     */
    protected String m_attributeValue = null;
    
    //-------------------------------------------------------------------------
    // CONSTRUCTOR
    //-------------------------------------------------------------------------

    /**
     * Constructs a default KeyAttributeEvent object.
     *
     * @status New
     */
    public KeyAttributeEvent ( Hashtable attributeSet, 
                               String attributeKey, String attributeValue )
    {
        m_attributeSet = attributeSet;
        m_attributeKey = attributeKey;
        m_attributeValue = attributeValue;
    }

    //-------------------------------------------------------------------------
    // PUBLIC MEMBERS
    //-------------------------------------------------------------------------
    
    /**
     * Retrieves the attribute set the attribute key and value is being added to.
     *
     * @status New
     */
    public Hashtable getAttributeSet ( )
    {
        return m_attributeSet;
    }        
    
    /**
     * Retireves the attribute key
     *
     * @status New
     */
    public String getAttributeKey ( )
    {
        return m_attributeKey;
    }        
    
    /**
     * Retireves the attribute value
     *
     * @status New
     */
    public String getAttributeValue ( )
    {
        return m_attributeValue;
    }        
}