/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Locale;
import oracle.dss.bicontext.BIRemoteException;

/**
 * Indicates a problem with a <code>MetadataManager</code> operation.
 * Subclasses of this class provide specific information about the
 * type of problem that occurred.
 *
 * @status Reviewed
 */
public class MetadataManagerException extends BIRemoteException
{
    private String m_driverType;

   /**
    * @hidden
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale  The locale to use for the message.
    * @param driverType The type of driver that initiates this exception.
    * @param prevException  The exception that underlies this exception.
    *
    * @status hidden
    */
    public MetadataManagerException(Class resBundleClass, String errorCode, Object[] params, Locale locale, String driverType, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, locale, prevException);
        m_driverType = driverType;
    }

   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale  The locale to use for the message.
    * @param driverType The type of driver that initiates this exception.
    *
    * @status hidden
    */
    public MetadataManagerException(Class resBundleClass, String errorCode, Object[] params, Locale locale, String driverType)
    {
        super(resBundleClass, errorCode, params, locale, null);
        m_driverType = driverType;
    }

   /**
    * @hidden
    * Constructor for a formattable, localizable exception that passes on a
    * previous exception.
    * This constructor uses the default locale.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param driverType The type of driver that initiates this exception.
    * @param prevException  The exception that underlies this exception.
    *
    * @status hidden
    */
    public MetadataManagerException(Class resBundleClass, String errorCode, Object[] params, String driverType, Throwable prevException)
    {
        super(resBundleClass, errorCode, params, Locale.getDefault(), prevException);
        m_driverType = driverType;
    }

   /**
    * @hidden
    * Constructor for a formattable exception that can be localized.
    * This constructor uses the default locale.
    *
    * @param resBundleClass The base resource bundle; that is, the resource
    *                       bundle that does not have a language extension in its
    *                       name.
    * @param errorCode The error code. This is the key in the resource bundle.
    * @param params    A replacement for each token in the <code>String</code>
    *                  that will be retrieved from the resource bundle.
    * @param locale  The locale to use for the message.
    * @param driverType The type of driver that initiates this exception.
    *
    * @status hidden
    */
    public MetadataManagerException(Class resBundleClass, String errorCode, Object[] params, String driverType)
    {
        super(resBundleClass, errorCode, params, Locale.getDefault(), null);
        m_driverType = driverType;
    }

    /**
     * @hidden
     * Constructor for an exception that has no parameter, cannot be localized,
     * and that passes on an underlying exception.
     *
     * @param message  The text of the error message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public MetadataManagerException(String message, String driverType, Throwable prevException)
    {
        super(message, prevException);
        m_driverType = driverType;
    }

    public String toString()
    {
        return getClass().getName() + ": " + getMessage();
    }
}
