/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.io.Serializable;
import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;

/**
 * @hidden
 */
public class HiddenFilter implements BIFilter, Serializable {
	public HiddenFilter() {
  }

  /**
   * Determines whether to include a particular search result in the
   * final search outcome.
   *
   * @param   result The result to evaluate.
   * @return  <code>true</code> if <code>result</code> should be included,
   *          <code>false</code> otherwise
   * @status New
   */
  public boolean evaluate (BISearchResult searchResult) {
    // Check for null search results
    if (searchResult == null)
      return false;

    if (MM.CALCULATION.equals(searchResult.getObjectType())) {
      return true;
    }
    // Convert result to an MDObject.
    if (searchResult instanceof MetadataManagerSearchResultImpl) {
 
      if (MM.MEASURE.equals(searchResult.getObjectType())) {
        Object objResult = searchResult.getObject();
        if ((objResult != null) && (objResult instanceof MDObject)) {
          MDObject mdObject = (MDObject)objResult;
          return !MM.HIDE_ALWAYS.equals(mdObject.getStrPropertyValue(MM.HIDDEN));
        }
      } 
    }
    return true;
  }
}