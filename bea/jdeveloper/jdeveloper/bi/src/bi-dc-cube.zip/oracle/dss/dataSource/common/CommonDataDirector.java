/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.text.MessageFormat;
import java.util.BitSet;
import java.util.Vector;


import oracle.dss.dataSource.client.QueryCapabilities;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.OlapQDR;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataDirectorException;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.DataMap;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.SliceOutOfRangeException;
import oracle.dss.util.StatusInfo;
import oracle.dss.util.transform.DataAccessLong;

/**
 * @hidden
 * Common Relational/OLAP DataDirector implementation
 */
public abstract class CommonDataDirector implements Delegate
{
    /**
     * @hidden
     */
    protected Query m_query = null;
    
    /**
     * @hidden
     */
    protected DataDirectorImpl m_wrapper = null;
    
    /**
     * Constructor
     * @param querySource  Central location for the query
     * @param viewType  A <code>Dataview.VIEW_TYPE_</code>* constant
     */
    public CommonDataDirector(Query query)
    {
        super();
  
        m_query = query;    
    }
    
    /**
     * @hidden
     * @return DataAccess for this data director
     */
    public abstract DataAccess getDataAccess();
    
    /**
     * @hidden
     */
    public abstract DataAccess getCurrentDataAccess();
    
    /**
     * @hidden
     * 
     * @return
     */
    protected abstract DataAccessLong getDataAccessLong();
    
    // Return true if the page edge extents, hPos, etc., is subject to math because it's OLAP and symmetric
    // Ultimately, shouldn't need to calculate page if OLAP, so we'll need a different check/code to successfully
    // get results for asym page edges in OLAP
    public boolean canCalculatePage()
    {
        // blm - Selection code moved to dvt-olap
/*        if (m_query.isDimensional())
        {
            // Is the page edge asym?
            return !isEdgeAsymmetric(DataDirector.PAGE_EDGE);
        }
        else
        {*/
            // Not dimensional: can only do calculations if single layer, really
            DimTree dt = m_query._getQueryState().getDimTree();
            return dt != null && dt.getNodeCount(DataDirector.PAGE_EDGE) <= 1;            
//        }
    }
    
    // blm - Selection code moved to dvt-olap
/*    public boolean isEdgeAsymmetric(int edge)
    {
        QueryState qs = m_query._getQueryState();
        try
        {
            return QueryUtil2.isEdgeAsymmetric(edge, qs.getDimTree(), qs.getSelections());
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }*/

    // javadoc from interface
    public void setOutline(boolean outline) throws DataDirectorException
    {
        try
        {
            m_query.setProperty(QueryConstants.PROPERTY_OUTLINE, new Boolean(outline));
        }
        catch (Exception e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
    }
    
    // javadoc from interface
    public boolean isOutline()
    {
        Boolean bool = (Boolean)m_query.getProperty(QueryConstants.PROPERTY_OUTLINE);
        return bool == null ? false : bool.booleanValue();
    }

    // javadoc from interface        
    public boolean drill(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        DataAccess dp = getCurrentDataAccess();
        if (dp == null)
            return false;
            
        if (layer >= dp.getLayerCount(edge))
        {
            throw new LayerOutOfRangeException(MessageFormat.format(
                m_query.getQueryManager().getResourceString(
                "Dimension out of range in metadata cursor for edge, dimension: "), new String[] {
                    Integer.toString(edge), Integer.toString(layer)}));
        }

        String dim = getDimName(edge, layer, true, false)[0];
        try {
            if ((flags & DataDirector.DRILL_REPLACE) != 0 || (flags & DataDirector.DRILL_BACK) != 0)
            {
                // Replace the selection with the children of the target element
                // blm - Selection code moved to dvt-olap
/*                Selection sel = m_query._getQueryState().getSelections().find(dim);
                Selection newSel = new Selection(sel.getDimension());
                newSel.setHierarchy(sel.getHierarchy());
                //Vector famVal = new Vector();
                String famVal = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_VALUE));
                String famValLevel = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_LEVEL_NAME));
                String level = null;

                BitSet bs = new BitSet(4);
                Vector labelVector = null;
                if ((flags & DataDirector.DRILL_BACK) != 0)
                {
                    bs.set(DrillConstants.DRILL_BACK);
                }
                else
                {
                    // Gather label information
                    labelVector = new Vector();
                    // Add longlabel
                    labelVector.addElement(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_LONGLABEL));
                    // Add medium label
                    labelVector.addElement(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_MEDIUMLABEL));
                    // Add short label
                    labelVector.addElement(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_SHORTLABEL));
                    // Add date
                    labelVector.addElement(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DATE));
                    // Add datespan
                    labelVector.addElement(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DATESPAN));

                    if (sel.getHierarchy() == null)
                        return false;

                    level = _getNextLevel(dp, edge, layer, slice, dim, sel.getHierarchy());
                }
                bs.set(DrillConstants.DRILL_EXCLUDE_SELF);
                bs.set(DrillConstants.DRILL_EXCLUDE_SIBLINGS);
                bs.set(DrillConstants.DRILL_EXCLUDE_RANGE);
                // Save off any qdr overrides
                m_query.drill(dim, famVal, famValLevel, sel.getHierarchy(), level, 0, bs, labelVector);*/
                return true;
            }

            int drillState = ((Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DRILLSTATE)).intValue();
            int direction = ((drillState & DataDirector.DRILLSTATE_IS_DRILLED) > 0) ? -1 : 0;
            direction = ((drillState & DataDirector.DRILLSTATE_DRILLABLE) > 0) ? 1 : direction;
            if (direction != 0)
            {
                // blm - Selection code moved to dvt-olap
/*                Selection sel = m_query._getQueryState().getSelections().find(dim);
                // Get level number for possible performance hint
                Integer obj = (Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_INDENT);
                int levelDepth = -1;
                if (obj != null)
                {
                    levelDepth = obj.intValue();
                }
                OlapQDR qdr = null;
                if (m_query.isAsymmetricDrilling())
                {
                    // Determine the QDR for layers "outside" this layer, if any
                    qdr = _getOutsideLayerQDR(edge, layer, slice, dim);
                }
                // Store drill command in case we want to cancel it out later because it
                // had no effect
                String target = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_VALUE));
                String parent = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_PARENT));
                String queryParent = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_QUERYPARENT));
                //m_cc.storeDrill(edge, m_cc.getEdgeExtent(edge), slice, dim, target, direction, parent, queryParent, levelDepth, qdr);
                m_query.drill(dim, target, sel.getHierarchy(), direction, parent, queryParent, levelDepth, qdr);*/
                return true;
            }                
        }
        // blm - Selection code moved to dvt-olap
/*        catch (QueryException dse) {
            throw new DataDirectorException(dse.getMessage(), dse);
        }*/
        catch (LayerOutOfRangeException dore) {
            throw dore;
        }
        catch (SliceOutOfRangeException iore) {
            throw iore;
        }
        // blm - Selection code moved to dvt-olap
/*        catch (MetadataManagerException de) {
            throw new DataDirectorException(de.getMessage(), de);
        }*/
        return false;
    }
       
    public boolean drillOK(int edge, int layer, int slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {            
        DataAccess dp = getCurrentDataAccess();
        if (dp == null)
            return false;
            
        String dimArray[] = getDimName(edge, layer, true, false);
        if (dimArray == null || dimArray.length == 0)
        {
            // Probably a layer problem
            throw new LayerOutOfRangeException(layer, dp.getLayerCount(edge));
        }
        String dim = dimArray[0];
        if ((flags & DataDirector.DRILL_REPLACE) != 0)
        {
            // Replace the selection with the children of the target element
            // blm - Selection code moved to dvt-olap
/*            Selection sel = m_query._getQueryState().getSelections().find(dim);
            try
            {
                if (sel == null || sel.getHierarchy() == null)
                    return false;
                    
                // Check for levels
                String hier = sel.getHierarchy();
                MDHierarchy hierObj = (MDHierarchy)m_query.getMDObject(MM.UNIQUE_ID, hier, MM.HIERARCHY);
                if (hierObj != null && hierObj.getLevels() != null && hierObj.getLevels().length > 0)
                {
                    String level = _getNextLevel(dp, edge, layer, slice, dim, sel.getHierarchy());
                    return (level != null);
                }
                else
                {
                    // Value based: we can't know
                    return true;
                }
            }
            catch (MetadataManagerException mme)
            {
                return false;
            }*/
        }
        if ((flags & DataDirector.DRILL_BACK) != 0)
        {
            // Check the selection for any drill level steps
            // blm - Selection code moved to dvt-olap
/*            Selection sel = m_query._getQueryState().getSelections().find(dim);
            if (sel != null && sel.getDrillLevelStepCount() > 0)
            {
                return true;
            }
            return false;
        }
        int drillState = ((Integer)dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_DRILLSTATE)).intValue();
        int direction = ((drillState & DataDirector.DRILLSTATE_IS_DRILLED) > 0) ? -1 : 0;
        direction = ((drillState & DataDirector.DRILLSTATE_DRILLABLE) > 0) ? 1 : direction;
        if (direction != 0) {
            try {
                Selection sel = m_query._getQueryState().getSelections().find(dim);
                String value = CursorUtils._makeString(dp.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_VALUE));
                if (sel != null && sel.getHierarchy() != null && !sel.getHierarchy().equals("") && value != null && !value.equals("")) {
                    return true;
                }
            }                
            catch (LayerOutOfRangeException dore) {
                throw dore;
            }
            catch (SliceOutOfRangeException iore) {
                throw iore;
            }*/
        }
        return false;
    }
       
    // javadoc from interface
    public boolean drill(int edge, int layer, int[] slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (slice == null)
            return false;
            
        boolean retVal = true;
        for (int i = 0; i < slice.length; i++)
        {
            if (!drill(edge, layer, slice[i], flags))
                retVal = false;
        }
        return retVal;
    }
    
    // javadoc from interface
    public boolean drillOK(int edge, int layer, int[] slice, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, DataDirectorException
    {
        if (slice == null)
            return false;
            
        for (int i = 0; i < slice.length; i++)
        {
            if (!drillOK(edge, layer, slice[i], flags))
                return false;
        }
        return true;
    }
        
    /**
     * @hidden
     * @throws oracle.dss.util.SliceOutOfRangeException
     * @throws oracle.dss.util.LayerOutOfRangeException
     * @throws oracle.dss.util.EdgeOutOfRangeException
     * @return 
     * @param dimension
     * @param slice
     * @param layer
     * @param edge
     */
    protected OlapQDR _getOutsideLayerQDR(int edge, int layer, int slice, String dimension) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException
    {
        return CursorUtils.getOutsideLayerQDR(m_query._getQueryState(), getDataAccessLong(), edge, layer, slice, dimension);
        /*// Are there any layers on this edge slower-varying than this target?
        if (layer > 0)
        {
            // Yes
            OlapQDR qdr = new OlapQDR();
            for (int l = 0; l < layer; l++)
            {
                // Look up the selection for this layer
                String layerDim = getDimName(edge, l, true, false)[0];
                if (layerDim != null)
                {
                    Selection sel = m_query._getQueryState().getSelections().find(layerDim);
                    if (sel != null)
                    {
                        String member =  CursorUtils._makeString(getDataAccess().getMemberMetadata(edge, l, slice, MetadataMap.METADATA_VALUE));
                        String level = CursorUtils._makeString(getDataAccess().getMemberMetadata(edge, l, slice, MetadataMap.METADATA_LEVEL_NAME));
                        if (member != null)
                        {
                            String strHier = sel.getHierarchy();
                            // Put the dim/hier/member combination in to the qdr
                            qdr.addDimMemberPair(layerDim, member, strHier, level);
                        }
                    }
                }
            }
            return qdr;
        }
        return null;*/
    }        
    
    /**
     * @hidden
     */
    protected String _getNextLevel(DataAccess da, int edge, int layer, int slice, String dim, String hier) throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException, MetadataManagerException
    {
        // Determine the "next" level
        String level = null;
        Object obj = da.getMemberMetadata(edge, layer, slice, MetadataMap.METADATA_INDENT);
        if (obj == null || !(obj instanceof Integer))
        {
            return null;
        }
        int indent = ((Integer)obj).intValue();
        // Find the level this represents in the metadata manaager
        MDDimension mddim = (MDDimension)m_query.getMDObject(MM.UNIQUE_ID, dim, MM.DIMENSION);
        if (mddim != null)
        {
            MDHierarchy[] hiers = mddim.getHierarchies();
            if (hiers != null)
            {
                for (int h = 0; h < hiers.length; h++)
                {
                    if (hiers[h].getUniqueID().equals(hier))
                    {
                        // Found it: get level list
                        MDLevel[] levels = hiers[h].getLevels();
                        if (levels != null && indent < levels.length-1)
                        {
                            level = levels[indent+1].getUniqueID();
                            return level;
                        }
                    }
                }
            }
        }
        return level;
    }        
    
    /**
     * @hidden
     */
    protected void fireDataChanged(int changeType, boolean data, boolean row, boolean column, boolean page, DataAccess da) throws QueryException
    {
        m_wrapper.fireDataChanged(changeType, data, row, column, page, da);
    }
    
    /**
     * @hidden
     */
    public void setWrapper(DataDirectorImpl wrapper)
    {
        m_wrapper = wrapper;
    }
    
    /**
     * @hidden
     */
    public DataDirectorImpl getWrapper()
    {
        return m_wrapper;
    }
    
    // javadoc from interface
    public boolean isCancelable()
    {
        return true;
    }
    
    // javadoc from interface
    public boolean cancel() throws DataDirectorException
    {
        m_query.cancel();
        return true;
    }
    
    /**
     * @hidden
     * 
     */
    public Query getQuery()
    {
        return m_query;
    }
    
    /**
     * @hidden
     */
    protected boolean isTabular()
    {
        return m_query._getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_TABULAR_QUERY);
    }
    
    // javadoc from interface
    public Object[][] getCompatibleDataItemMetadata(String[] types, String[] idList) throws DataDirectorException
    {    
        return null;
    }
    
    // javadoc from interface
    public String[] setExpressions(Object[] expressions) throws DataDirectorException
    {
        return null;
    }
    
    // javadoc from interface
    public Object[] getExpressions()
    {
        return null;
    }
    

    // javadoc from interface
    public void setProperty(String name, Object value) throws DataDirectorException
    {
    }

    // javadoc from interface
    public Object getProperty(String name) throws DataDirectorException
    {
        if (name == null)
            return null;
            
        if (name.equals(DataDirector.PROP_ASYNCHRONOUS))
            return m_query.getProperty(QueryConstants.PROPERTY_ASYNCHRONOUS);
        else if (name.equals(DataDirector.PROP_AUTO_FIRE_EVENTS))
            return m_query.getProperty(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS);
        else if (name.equals(DataDirector.PROP_TABULAR))
            return m_query.getProperty(QueryConstants.PROPERTY_TABULAR_QUERY);
        else if (name.equals(DataDirector.PROP_IS_OUTLINE_SUPPORTED))
        {
            try
            {
                Boolean answer = (Boolean)m_query.isSupported(QueryCapabilities.OUTLINE_MODE, null);
                return answer == null ? new Boolean(false) : answer;
            }
            catch (QueryException e)
            {
                throw new DataDirectorException(e.getMessage(), e);
            }
        }
            
        return null;
    }    
    
    // javadoc from interface    
    public void setLayerMetadata(int edge, int layer, String type, Object value) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {        
    }        

    // javadoc from interface
    public void fireEvents() throws DataDirectorException
    {        
        try
        {
            m_query.fireEvents();
        }
        catch (QueryException e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
    }

    /**
     * Return a LayerMetadataMap containing all of the types the implementor
     * can support.  This is not meant to guarantee views that they can
     * get the types they want in every query.
     *
     * @return LayerMetadataMap containing all of the possibly supported types
     * @status New
     */
    public LayerMetadataMap getSupportedLayerMetadataMap() {
        return new LayerMetadataMap(new String[] {LayerMetadataMap.LAYER_METADATA_NAME,
                                                  LayerMetadataMap.LAYER_METADATA_DISPLAYNAME,
                                                  LayerMetadataMap.LAYER_METADATA_SHORTLABEL,
                                                  LayerMetadataMap.LAYER_METADATA_LONGLABEL,
                                                  LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL,
                                                  LayerMetadataMap.LAYER_METADATA_LONGLABEL_PLURAL,
                                                  LayerMetadataMap.LAYER_METADATA_SHORTLABEL_PLURAL,
                                                  LayerMetadataMap.LAYER_METADATA_CANPIVOT,
                                                  LayerMetadataMap.LAYER_METADATA_HIERARCHICAL,
                                                  LayerMetadataMap.LAYER_METADATA_MEASURE});
    }

   /**
     * Return a MetadataMap containing all of the types the implementor
     * can support.  This is not meant to guarantee views that they can
     * get the types they want in every query.
     *
     * @return MetadataMap containing all of the possibly supported types
     * @status New
     */
    public MetadataMap getSupportedMetadataMap()
    {
        return new MapSupport(m_query.areAnnotationsAllowed()).getMetadataMap(null, true);
    }

    // javadoc from interface
    public MetadataMap getMetadataMap(int edge, int layer) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {
        return QueryUtil2.getMetadataMap(m_query, getDimName(edge, layer, true, true), edge, layer);
    }    

    // javadoc from interface
    public DataMap getDataMap ()
    {
        return m_query.getDataMap();
    }    


    /**
     * Return a Datamap containing all of the types the implementor
     * can support.  This is not meant to guarantee views that they can
     * get the types they want in every query.
     *
     * @return DataMap containing all of the possibly supported types
     * @status New
     */
    public DataMap getSupportedDataMap()
    {
        // gek 03/12/02 Specify DataMap.DATA_VIEWFORMAT to support
        //              number formatting of custom measures.
        DataMap dataMap = new MapSupport(m_query.areAnnotationsAllowed()).getSupportedDataMap();
        return dataMap;
        
        // return new MapSupport().getDataMap();
    }
    
    // javadoc from interface
    public void setMetadataMap(int edge, int layer, MetadataMap map, int size) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        if (edge == -1) {
            // Set a default map for all
            try {
                if (!m_query.getMetadataMap(null).isSuperset(map)) {
                    m_query.applyMetadataMap(null, map);
                }
            }
            catch (Exception e) {
                throw new DataDirectorException(e.getMessage(), e);
            }
            return;
        }
        if (layer == -1) {
            // Set a default map for the edge
            try {
                MetadataMap mapAlready = m_query.getMetadataMap(edge);                   
                if (mapAlready == null) {
                    // Test using time types, because caller probably includes them no matter what
                    if (!m_query.getMapSupport().getMetadataMap(null, true).isSuperset(map)) {
                        m_query.applyMetadataMap(edge, map);
                    }
                    return;
                }
                if (!mapAlready.isSuperset(map)) {
                    m_query.applyMetadataMap(edge, map);
                }
                
            }
            catch (Exception e) {
                throw new DataDirectorException(e.getMessage(), e);
            }
            return;
        }
        String[] dimList = getDimName(edge, layer, true, true);
        if (dimList != null) {
            try {                
                for (int i = 0; i < dimList.length; i++) {
                    MetadataMap mapAlready = m_query.getMetadataMap(dimList[i]);
                    if (mapAlready == null) {
                        if (!m_query.getMetadataMap(null).isSuperset(map)) {
                            m_query.applyMetadataMap(dimList[i], map);                                
                        }
                        return;
                    }
                    if (!mapAlready.isSuperset(map)) {
                        m_query.applyMetadataMap(dimList[i], map);
                    }
                }
            }
            catch (Exception e) {
                throw new DataDirectorException(e.getMessage(), e);
            }
        }
    }    

    // javadoc from interface
    public void setDataMap(DataMap map, int sizeRow, int sizeColumn) throws DataDirectorException
    {
            if (map != null)
            {
                m_query.applyDataMap(map);
            }
    }    
    
      /**
       * Checks whether a pivot is allowed.
       */
    public boolean pivotOK(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        return pivotCheck(fromEdge, toEdge, fromLayer, toLayer, flags) == DataDirector.PIVOT_CHECK_OK;
    }

    public void release()
    {
    }
    
    /**
     * @hidden
     * Check if no data on any edge
     */
    protected abstract boolean isNoData() throws EdgeOutOfRangeException, LayerOutOfRangeException, SliceOutOfRangeException;
    
    // javadoc from interface    
    public int pivotCheck(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException
    {
        try
        {
            if (m_query.isEvaluateCursor() && isNoData())
                return DataDirector.PIVOT_CHECK_UNKNOWN;
        }
        catch (SliceOutOfRangeException e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
    
        if (flags == DataDirector.PIVOT_SWAP)
        {
            String source = getDimName(fromEdge, fromLayer, true, false)[0];
            String target = getDimName(toEdge, toLayer, true, false)[0];
            try
            {
                return m_query.swapCheck(source, target);
            }
            catch (QueryException e)
            {
                throw new DataDirectorException(e.getMessage(), e);
            }
            //return m_cc.swapOK(source, target);
        }
        else if (flags == DataDirector.PIVOT_EDGES) {
            if (toEdge > -1 && fromEdge > -1)
            {
                return DataDirector.PIVOT_CHECK_OK;
            }
        }
            else if (flags == DataDirector.PIVOT_MOVE_AFTER || flags == DataDirector.PIVOT_MOVE_BEFORE || flags == DataDirector.PIVOT_MOVE_TO) 
            {
                String[] from = getDimName(fromEdge, fromLayer, true, false);
                String fromDim = from == null || from.length == 0 ? null : from[0];
                String[] to = getDimName(toEdge, toLayer, false, false);
                String toDim = to == null || to.length == 0 || to[0] == null ? Integer.toString(toEdge) : to[0];
                try
                {
                    return m_query.pivotCheck(fromDim, toDim, getQueryPivotFlags(flags));
                }
                catch (QueryException e)
                {
                    throw new DataDirectorException(e.getMessage(), e);
                }
                //return m_cc.pivotOK(fromDim, toDim, flags == DataDirector.PIVOT_MOVE_AFTER ? PivotConstants.PIVOT_AFTER : PivotConstants.PIVOT_BEFORE, true);
            }
        return DataDirector.PIVOT_CHECK_UNKNOWN;
    }
    
    // Convert flags
    protected int getQueryPivotFlags(int flags)
    {
        switch (flags)
        {
            case DataDirector.PIVOT_MOVE_BEFORE:
                flags = PivotConstants.PIVOT_BEFORE;
            break;
            case DataDirector.PIVOT_MOVE_AFTER:
                flags = PivotConstants.PIVOT_AFTER;
            break;
            case DataDirector.PIVOT_MOVE_TO:
                flags = PivotConstants.PIVOT_BEFORE;
            break;
        }
        return flags;
    }
    
    // javadoc from interface
    public StatusInfo getStatus() throws DataDirectorException
    {   
        try
        {
            return m_query.getStatus();
        }
        catch (QueryException e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
    }    
     
    // javadoc from interface
    public StatusInfo startExecution() throws DataDirectorException
    {   
        try
        {
            return m_query.startExecution();
        }
        catch (QueryException e)
        {
            throw new DataDirectorException(e.getMessage(), e);
        }
    }    
    
    // javadoc from interface
    public void addDataDirectorListener(DataDirectorListener l)
    {        
    }
    
    // javadoc from interface
    public void removeDataDirectorListener(DataDirectorListener l)
    {    
    }
    
    public boolean pivot(int fromEdge, int toEdge, int fromLayer, int toLayer, int flags) throws EdgeOutOfRangeException, LayerOutOfRangeException, DataDirectorException {
        try {
            if (flags == DataDirector.PIVOT_SWAP) {
                // Save off any qdr overrides
                //m_query.transferQDROverrides();
                m_query.swap(getDimName(fromEdge, fromLayer, true, false)[0], getDimName(toEdge, toLayer, true, false)[0]);
            }
            else if (flags == DataDirector.PIVOT_EDGES) {
                // Save off any qdr overrides
                //m_query.transferQDROverrides();
                m_query.swapEdges(fromEdge, toEdge);
            }
            else {
                flags = getQueryPivotFlags(flags);                
                String[] from = getDimName(fromEdge, fromLayer, true, false);
                String fromDim = from == null || from.length == 0 ? null : from[0];
                String[] to = getDimName(toEdge, toLayer, false, false);
                String toDim = to == null || to.length == 0 || to[0] == null ? Integer.toString(toEdge) : to[0];
                // Save off any qdr overrides
                //m_query.transferQDROverrides();
                m_query.pivot(fromDim, toDim, flags);
            }
        }
        catch (Exception e) {
            throw new DataDirectorException(e.getMessage(), e);
        }
        return true;           
    }

    // Return the list of possible dimensions (generally one) at this location currently
    protected String[] getDimName(int edge, int dimension, boolean throwExceptions, boolean acceptBadLayer) throws EdgeOutOfRangeException, LayerOutOfRangeException {
        String[][] layout = m_query.getLayout();
        if (layout != null) {
            if (dimension == -1 && acceptBadLayer) {
                // List all dimensions
                try {
                    String[] retval = new String[layout[edge].length];
                    for (int i = 0; i < retval.length; i++) {
                        retval[i] = layout[edge][i];
                    }
                    return retval;
                }
                catch (Exception e) {
                    if (throwExceptions) {
                        if (e instanceof EdgeOutOfRangeException) {
                            throw (EdgeOutOfRangeException)e;
                        }
                        else if (e instanceof LayerOutOfRangeException) {
                            throw (LayerOutOfRangeException)e;
                        }
                    }
                    return null;
                }
            }
            else {
                try {
                    return new String[] {layout[edge][dimension]};        
                }
                catch (Exception e) {
                    if (throwExceptions) {
                        if (e instanceof EdgeOutOfRangeException) {
                            throw (EdgeOutOfRangeException)e;
                        }
                        else if (e instanceof LayerOutOfRangeException) {
                            return null;
                        }
                    }
                    return null;
                }
            }
        }
            
        return null;
    }
    
    
}
