/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Hashtable;
import java.util.Vector;

import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;

/**
 * The directory service interface for the BI Beans.
 * This interface is used by both the <code>PersistenceManager</code>
 * interface and the <code>MDFolder</code> class
 * of the Metadata Manager.
 * <P>
 * This interface adds maintenance methods, such as <code>move</code>
 * and <code>copy</code>, to the
 * <code>javax.naming.directory.DirContext</code> interface.
 * The interface also includes methods for access control and searching.
 * <p>
 * For convenience when defining read only sources of metadata,
 * the interface is split into a read only part, {@link ReadOnlyBIContext}
 * leaving write methods declared here and in the base DirContext.
 * @status documented
 */
public interface BIContext extends DirContext, ReadOnlyBIContext
{

    /**
     * Moves an existing context or object.
     *
     * @param name  The name of the object to move. The path in
     *              <code>name</code> is relative to this context.
     * @param context The context into which to move <code>name</code>.
     *
     * @throws    NameAlreadyBoundException If another object in <code>context</code>
     *               is already bound to <code>name</code>.
     * @throws    NameNotFoundException If the object to be moved cannot be found.
     * @throws    BICircularReferenceException If circular reference is detected.
     * @throws    NamingException If any other naming error occurs.
     *
     * @status documented
     */
    void move(Name name, DirContext context) throws NamingException;

    /**
     * Moves an existing context or object.
     *
     * @param name  The name of the object to move. Use a slash (/) to separate
     *              folder names. The path is relative to this context.
     * @param context The context into which to move <code>name</code>.
     *
     * @throws    NameAlreadyBoundException If another object in <code>context</code>
     *               is already bound to <code>name</code>.
     * @throws    NameNotFoundException If the object to be moved cannot be found.
     * @throws    BICircularReferenceException If circular reference is detected.
     * @throws    NamingException If any other naming error occurs.
     *
     * @status documented
     */
    void move(String name, DirContext context) throws NamingException;

    /**
     * Copies an existing context or object.
     *
     * @param name  The name of the object to copy.
     *              The path in <code>name</code> is relative to this
     *              context.
     * @param context The context into which to copy <code>name</code>.
     * @param newName The new name for the copy of the original object.
     *                If you pass <code>null</code>,
     *                then the new name will be the same as the old name.
     * @param mode  A constant that identifies whether to copy related objects
     *              or only <code>name</code>.
     *
     * @throws    NameAlreadyBoundException If another object in <code>context</code>
     *               is already bound to <code>name</code>.
     * @throws    NameNotFoundException If the object to be copied cannot be found.
     * @throws    BICircularReferenceException If circular reference is detected.
     * @throws    NamingException If any other naming error occurs.
     *
     * @status documented
     */
    void copy(Name name, DirContext context, Name newName, int mode) throws NamingException;

    /**
     * Copies an existing context or object.
     *
     * @param name  The name of the object to copy. Use a slash (/) to separate
     *              folder names.
     *              The path in <code>name</code> is relative to this
     *              context.
     * @param context The context into which to copy <code>name</code>.
     * @param newName The new name for the copy of the original object.
     *                If you pass <code>null</code>,
     *                then the new name will be the same as the old name.
     * @param mode  A constant that identifies whether to copy related objects
     *              or only <code>name</code>.
     *
     * @throws    NameAlreadyBoundException If another object in <code>context</code>
     *               is already bound to <code>name</code>.
     * @throws    NameNotFoundException If the object to be copied cannot be found.
     * @throws    BICircularReferenceException If circular reference is detected.
     * @throws    NamingException If any other naming error occurs.
     *
     * @status documented
     */
    void copy(String name, DirContext context, String newName, int mode) throws NamingException;


    /**
     * Adds a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to add to the access control list of the
     *                specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> adds the entries to the
     *                            access control list of all subfolders,
     *                            if the specified object is a folder.
     *                            <code>false</code> adds the entries to
     *                            the specified object only.
     *                            This flag is ignored if the specified object is
     *                            not a folder
     * @param cascadeToObjects <code>true</code> adds the entries to the access
     *                         control list of all the objects within the folder,
     *                         if the specified object is a folder.
     *                         <code>false</code> adds the entries only to the
     *                         specified object.
     *                         This flag is ignored if the specified object is
     *                         not a folder
     * @return <code>true</code> if <code>entries</code> are successfully added.
     *         <code>false</code> if all the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add entries
     *            to the access control list of the specified object.
     *
     * @status Documented
     */
    boolean addEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;

    /**
     * Adds a <code>Vector</code> of entries to the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid users or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to add to the access control list of the
     *                specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> adds the to all subfolders,
     *                            if the specified object is a folder.
     *                            <code>false</code> adds the entries to
     *                            the specified object only.
     *                            This flag is ignored if the specified object
     *                            is not a folder
     * @param cascadeToObjects <code>true</code> adds the entries to all objects
     *                         within the folder, if the specified object
     *                         is a folder.
     *                         <code>false</code> adds the entries to
     *                         the specified object only.
     *                         This flag is ignored if the specified object is
     *                         not a folder
     * @return <code>true</code> if any entry in
     *                           <code>entries</code> is successfully added.
     *         <code>false</code> if all entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add entries
     *            to the access control list of the specified object.
     *
     * @status Documented
     */
    boolean addEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;

    /**
     * Removes a <code>Vector</code> of entries from the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to remove from the access control list of the
     *                specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> removes the entries from
     *                            all the subfolders, if the specified object
     *                            is a folder.
     *                            <code>false</code> removes the entries from
     *                            the specified object only.
     *                            This flag is ignored if the specified object
     *                            is not a folder
     * @param cascadeToObjects <code>true</code> removes the entries from all
     *                         objects within the folder, if the specified object
     *                         is a folder.
     *                         <code>false</code> removes the entries from
     *                         the specified object only.
     *                         This flag is ignored if the specified object is
     *                         not a folder.
     *
     * @return <code>true</code> if any entry in <code>entries</code>
     *                           is successfully removed
     *                           from the access control list of the object.
     *         <code>false</code> if all entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to remove
     *            entries from the access control list of the specified object.
     *
     * @status Documented
     */
    boolean removeEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;

    /**
     * Removes a <code>Vector</code> of entries from the access control list
     * of an object.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to remove from the access control list of the
     *                specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> removes the entries from
     *                            all subfolders, if the specified object
     *                            is a folder.
     *                            <code>false</code> removes the entries from
     *                            the specified object only.
     *                            This flag is ignored if the specified object
     *                            is not a folder
     * @param cascadeToObjects <code>true</code> removes the entries from all
     *                         objects within the folder, if the specified object
     *                         is a folder.
     *                         <code>false</code> removes the entries from
     *                         this object only.
     *                         This flag is ignored if the specified object is
     *                         not a folder.
     *
     * @return <code>true</code> if any entry in <code>entries</code> is
     *                           successfully removed
     *                           from the access control list of the object.
     *         <code>false</code> if all entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to remove entries
     *            from the access control list of the specified object.
     *
     * @status Documented
     */
    boolean removeEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;

    /**
     * Specifies a <code>Vector</code> of entries for the access control list
     * of an object.
     *
     * This method replaces all existing entries in the access control list
     * with the specified entries.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries that are to replace the access control list
     *                of the specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> specifies entries for
     *                            all subfolders, if the specified object
     *                            is a folder.
     *                            <code>false</code> specifies entries for
     *                            this object only.
     *                            This flag is ignored if the specified object
     *                            is not a folder.
     * @param cascadeToObjects <code>true</code> specifies entries for all
     *                         objects within the folder, if the specified object
     *                         is a folder.
     *                         <code>false</code> specifies entries for
     *                         this object only.
     *                         This flag is ignored if the specified object is
     *                         not a folder.
     * @return <code>true</code> if any entry in <code>entries</code>
     *                           is successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if all of the entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add or remove
     *            entries to or from the access control list of the specified
     *            object.
     *
     * @status Documented
     */
    boolean setEntries(Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;

    /**
     * Specifies a <code>Vector</code> of entries for the access control list
     * of an object.
     *
     * This method replaces all existing entries in the access control list
     * with the specified entries.
     *
     * Invalid entries and entries that have invalid user or privileges are
     * ignored.
     *
     * @param name The name of the object.
     * @param entries The entries to be set as the access control list of the
     *                specified object. For each entry, use
     *                <code>oracle.dss.persistence.security.common.AclEntryImpl</code>.
     * @param cascadeToSubFolders <code>true</code> specifies entries for
     *                            all subfolders, if the specified object
     *                            is a folder.
     *                            <code>false</code> specifies entries for
     *                            this object only.
     *                            This flag is ignored if the specified object
     *                            is not a folder
     * @param cascadeToObjects <code>true</code> specifies entries for all
     *                         objects within the folder, if the specified object
     *                         is a folder.
     *                         <code>false</code> specifies entries for
     *                         this object only.
     *                         This flag is ignored if the specified object is
     *                         not a folder
     * @return <code>true</code> if <code>entries</code> are successfully added
     *                           to the access control list of the object.
     *         <code>false</code> if entries in <code>entries</code>
     *                           are invalid.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to add/remove
     *            entries to/from the access control list of the specified object.
     *
     * @status documented
     */
    boolean setEntries(String name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws NamingException;


    // new methods

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status hidden
     */
    void bind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException;

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(String, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status hidden
     */
    void bind(Name name, Object object, Attributes attrs, Hashtable env) throws NamingException;

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status hidden
     */
    void rebind(String name, Object object, Attributes attrs, Hashtable env) throws NamingException;

    /**
     * @hidden
     * Saves an object through the MetadataManager.
     * This method binds <code>name</code> to <code>object</code>, so that
     * <code>object</code> can be found later.
     * This method is useful only for <code>Persistable</code> objects that
     * are being stored in the BI Beans Catalog.
     * Calling this method on a metadata object is not useful.
     * <P>
     * This method binds an object to a name that might be already bound, if that
     * is the case, the old object is replaced.
     * If the name is not already bound, then this method binds the object
     * to the name, just as the <code>bind</code> method does.
     *
     * @param name   The path name of the object that this method saves.
     *               Do not pass <code>null</code> or an empty <code>Name</code>.
     *               The path that you specify must exist. This method
     *               does not create intermediate subcontexts.
     * @param object    The object to save. The object must implement the
     *               the <code>Persistable</code> interface.
     * @param attrs  Attributes for <code>object</code>.
     * @param env    The environment used to initialize the Persistable
     *               component.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameAlreadyBoundException If another object is already bound to
     *               <code>name</code>. Call <code>rebind</code> to replace
     *               a binding.
     * @throws BIInvalidAttributesException If any of the attributes in
     *               <code>attrs</code> is invalid.
     * @throws BINoPermissionException If the caller does not have permission to
     *               save objects to this context.
     * @throws BICircularReferenceException If circular reference is detected.
     * @throws BINamingException If another naming error occurs, such as when
     *                  <code>object</code> is <code>null</code> or when
     *                  <code>object</code> does not implement the
     *                  <code>Persistable</code> interface. Also throws
     *                  <code>BINamingException</code> if you try to use
     *                  this method to create a folder. Call
     *                  <code>createSubcontext</code> instead.
     *
     * @see #bind(Name, Object, Attributes)
     * @see #createSubcontext
     * @see #rebind
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status hidden
     */
    void rebind(Name name, Object object, Attributes attrs, Hashtable env)
      throws NamingException;

    /**
     * Delete an object, returning summary of any cascade deletes.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual unbind.
     * @see javax.naming.Context#unbind(Name)
     * @status new
     */
    ImpactReport unbindImpact(Name name, boolean dryRun)
      throws NamingException;

    /**
     * Delete an object, returning summary of any cascade deletes.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual unbind.
     * @see javax.naming.Context#unbind(String)
     * @status new
     */
    ImpactReport unbindImpact(String name, boolean dryRun)
      throws NamingException;

     /**
     * Replace an object.  Since this may result in deletion of the
     * replaced object, return the an impact report.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual unbind.
     * @see javax.naming.directory.DirContext#rebind(Name, Object, Attributes)
     * @status new
     */
    ImpactReport rebindImpact(Name name, Object obj, Attributes attrs, boolean dryRun)
     throws NamingException;

    /**
     * Replace an object.  Since this may result in deletion of the
     * replaced object, return the an impact report.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual re-bind.
     * @see javax.naming.directory.DirContext#rebind(String, Object, Attributes)
     * @status new
     */
    ImpactReport rebindImpact(String name, Object obj, Attributes attrs, boolean dryRun)
     throws NamingException;

    /**
     * Replace an object.  Since this may result in deletion of the
     * replaced object, return the an impact report.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual rebind.
     * @see javax.naming.Context#rebind(Name, Object)
     * @status new
     */
    ImpactReport rebindImpact(Name name, Object obj, boolean dryRun)
      throws NamingException;
    /**
     * Replace an object.  Since this may result in deletion of the
     * replaced object, return the an impact report.
     * @param dryRun if true, return the usual impact report but
     * do not perform the actual rebind.
     * @see javax.naming.Context#rebind(String, Object)
     * @status new
     */
    ImpactReport rebindImpact(String name,
                                     Object obj,
                                     boolean dryRun)
      throws NamingException;

    // Redeclare to allow extra javadoc.
    /**
     * @see javax.naming.directory.DirContext#destroySubcontext(Name)
     * <p>
     * Since the context must be empty
     * there is no need to return an ImpactReport.
     */
    void destroySubcontext(Name name) throws NamingException;

    // Redeclare to allow extra javadoc.
    /**
     * @see javax.naming.directory.DirContext#destroySubcontext(String)
     * <p>
     * Since the context must be empty
     * there is no need to return an ImpactReport.
     */
    void destroySubcontext(String name) throws NamingException;
}
