/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;

import oracle.dss.util.BIException;

/**
 * @hidden
 * Interface defining all the convenience methods on exceptions.  
 * Note that due to the lack of multiple inheritance ExtendedBIExcetion is 
 * NOT an Exception, and therefore cannot be used in a catch clause.  
 * @status new
 */
public interface ExtendedBIException extends BIException
{
    
   /**
    * @hidden
    * Retrieves a message that is localized for a specified <code>Locale</code>.
    *
    * @param l The locale whose translation to retrieve.
    *
    * @return The localized message.
    */
    String getLocalizedMessage(Locale l);

   /**
    * @hidden
    * Retrieves the parameters for the error message.
    *
    * @return An array that contains an object for each token in the
    *         error message.
    */
    Object[] getErrorParameters();

   /**
    * @hidden
    * Retrieves the error code for this exception.
    * The error code is the key into the resource bundle for the message.
    *
    * @return The error code for this exception.
    *
    * @status documented
    */
    String getErrorCode();

   /**
    * @hidden
    * Retrieves the product code for this exception.
    * Because this exception is caused by an exception from Java Business
    * Objects, the product code is the constant <code>JBO_PRODUCT_CODE</code>.
    *
    * @return The product code for this exception.
    */
    String getProductCode();

   /**
    * @hidden
    * Indicates whether the message for this exception can be localized.
    *
    * @return <code>true</code> if the message can be localized,
    *         <code>false</code> if it cannot.
    */
    boolean isLocalizable();

    
}
