/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/resource/DataUtilGUIBundle.java /main/40 2009/07/14 18:59:04 srkalyan Exp $
 *
 * Copyright (c) 2005, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.resource;

import java.util.ListResourceBundle;


/**
 * @hidden
 * 
 * Contains locale-specific information for the DataUtil package.
 *
 *  @status hidden
 */

public class DataUtilGUIBundle extends ListResourceBundle	{

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  //................................
  // <code>TreeListComboBoxModelMembers</code> resources
  //................................
  public static final String TREELISTCOMBOBOXMODELMEMBERS_PARAMETER_OPTION = 
    "TREELISTCOMBOBOXMODELMEMBERS_PARAMETER_OPTION";
  
  public static final String TREELISTCOMBOBOXMODELMEMBERS_SELECT_ITEM_OPTION = 
    "TREELISTCOMBOBOXMODELMEMBERS_SELECT_ITEM_OPTOIN";

  //................................
  // <code>Shuttle</code> resources
  //................................

  public static final String SHUTTLE_ADD = "SHUTTLE_ADD";
  public static final String SHUTTLE_ADD_ALL = "SHUTTLE_ADD_ALL";
  public static final String SHUTTLE_REMOVE = "SHUTTLE_REMOVE";
  public static final String SHUTTLE_REMOVE_ALL = "SHUTTLE_REMOVE_ALL";
  public static final String SHUTTLE_AVAILABLE = "SHUTTLE_AVAILABLE";
  public static final String SHUTTLE_SELECTED = "SHUTTLE_SELECTED";

  /**
   * @status hidden
   * The Oracle Express Objects (OEO) number format type.
   *
   * The number format <code>String</code> represents an OEO number format mask
   * in the following format:
   *
   * "number format; positive format; negative format; scale; chars-to-use",
   *
   * For example, <code>"0; $1; -1; /3; $=$; .=.;,=,"</code> would format seven
   * million dollars as <code>$7,000</code>.
   *
   * @status hidden
   */
  public final static String NUMBER_FORMAT_TYPE_OEO     = "OEO";

  /**
   * @status hidden
   * The Oracle number format type.
   *
   * The number format <code>String</code> represents an Oracle number format mask,
   * as described in the <code>Oracle9i SQL Reference Release 1 (9.0.1), Format Models</code>
   * specification.
   *
   * @status hidden
   */
  public final static String NUMBER_FORMAT_TYPE_ORACLE  = "Oracle";

  /**
   * @status hidden
   * The BIBeans number format type.
   *
   * The number format <code>String</code> represents a BIBeans number format mask,
   * which is an extension of the <code>Oracle9i SQL Reference Release 1 (9.0.1), Format Model</code>.
   *
   * @status hidden
   */
  public final static String NUMBER_FORMAT_TYPE_BIBEANS  = "BIBeans";

  // Number format resource values
  // Combo box label 'Format:'
  public static final String NUMBER_FORMAT_FORMAT   = "NumFmtFmt";

  // 'Options...' button label
  public static final String NUMBER_FORMAT_OPTIONS  = "NumFmtOpt";

  // Format dialog title
  public static final String NUMBER_FORMAT_DIALOG_TITLE = "NumFmtDlgTitle";

  // Number, type and string keys used to look up values used to format each
  // default combo box number
  public static final String NUMBER_FORMAT_NUMBER_GENERAL = "NumFmtNumGeneral";
  public static final String NUMBER_FORMAT_NUMBER_CURRENCY = "NumFmtNumCurrency";
  public static final String NUMBER_FORMAT_NUMBER_PERCENT = "NumFmtNumPercent";

  public static final String NUMBER_FORMAT_NUMBER_1 = "NumFmtNum1";
  public static final String NUMBER_FORMAT_TYPE_1   = "NumFmtType1";
  public static final String NUMBER_FORMAT_STRING_1 = "NumFmtString1";

  public static final String NUMBER_FORMAT_NUMBER_2 = "NumFmtNum2";
  public static final String NUMBER_FORMAT_TYPE_2   = "NumFmtType2";
  public static final String NUMBER_FORMAT_STRING_2 = "NumFmtString2";

  public static final String NUMBER_FORMAT_NUMBER_3 = "NumFmtNum3";
  public static final String NUMBER_FORMAT_TYPE_3   = "NumFmtType3";
  public static final String NUMBER_FORMAT_STRING_3 = "NumFmtString3";

  public static final String NUMBER_FORMAT_NUMBER_4 = "NumFmtNum4";
  public static final String NUMBER_FORMAT_TYPE_4   = "NumFmtType4";
  public static final String NUMBER_FORMAT_STRING_4 = "NumFmtString4";

  public static final String NUMBER_FORMAT_NUMBER_5 = "NumFmtNum5";
  public static final String NUMBER_FORMAT_TYPE_5   = "NumFmtType5";
  public static final String NUMBER_FORMAT_STRING_5 = "NumFmtString5";

  public static final String NUMBER_FORMAT_NUMBER_6 = "NumFmtNum6";
  public static final String NUMBER_FORMAT_TYPE_6   = "NumFmtType6";
  public static final String NUMBER_FORMAT_STRING_6 = "NumFmtString6";

  public static final String NUMBER_FORMAT_NUMBER_7 = "NumFmtNum7";
  public static final String NUMBER_FORMAT_TYPE_7   = "NumFmtType7";
  public static final String NUMBER_FORMAT_STRING_7 = "NumFmtString7";

  public static final String NUMBER_FORMAT_NUMBER_8 = "NumFmtNum8";
  public static final String NUMBER_FORMAT_TYPE_8   = "NumFmtType8";
  public static final String NUMBER_FORMAT_STRING_8 = "NumFmtString8";

  public static final String NUMBER_FORMAT_NUMBER_9 = "NumFmtNum9";
  public static final String NUMBER_FORMAT_TYPE_9   = "NumFmtType9";
  public static final String NUMBER_FORMAT_STRING_9 = "NumFmtString9";

  public static final String NUMBER_FORMAT_NUMBER_10 = "NumFmtNum10";
  public static final String NUMBER_FORMAT_TYPE_10   = "NumFmtType10";
  public static final String NUMBER_FORMAT_STRING_10 = "NumFmtString10";

  public static final String NUMBER_FORMAT_NUMBER_11 = "NumFmtNum11";
  public static final String NUMBER_FORMAT_TYPE_11   = "NumFmtType11";
  public static final String NUMBER_FORMAT_STRING_11 = "NumFmtString11";

  public static final String NUMBER_FORMAT_NUMBER_12 = "NumFmtNum12";
  public static final String NUMBER_FORMAT_TYPE_12   = "NumFmtType12";
  public static final String NUMBER_FORMAT_STRING_12 = "NumFmtString12";

  // Private values used to initialize default numbers
  private static final String NUMBER_GENERAL            = "9999.00";
  private static final String NUMBER_CURRENCY           = "9999.00";
  private static final String NUMBER_PERCENT            = "0.99";

	static final Object[][] resources =	 {
  	{"moreItem",        "More..."},
    {"qualifyItem",     "Qualify..."},

      // Common words
    {"OK",              "OK"},
    {"Apply",     			"&Apply"},
    {"Cancel",          "Cancel"},
    {"Help",            "&Help"},
    {"Next",        		"Next"},
    {"Back",        		"Back"},
    {"Finish",      		"Finish"},
    {"Rename",          "Rename..."},
    {"Edit",            "Edit..."},
    {"Move",            "Move..."},
    {"Copy",            "Copy..."},
    {"Delete",          "Delete"},
    {"Close",           "Close"},
    {"Yes",             "Yes"},
    {"No",              "No"},
    {"Sort",      			"So&rt"},
    {"Save",      			"&Save"},
    {"Move Up",         "Move Up"},
    {"Move Down",       "Move Down"},      
  
    // AggregateCalcStepView strings.
    {"aggregateMethodAverage",      "Average"},
    {"aggregateMethodCount",        "Count"},
    {"aggregateMethodMaximum",      "Maximum"},
    {"aggregateMethodMinimum",      "Minimum"},
    {"aggregateMethodPercentTotal", "Percent Of Total"},
    {"aggregateMethodSum",          "Sum"},
      
    {"aggregateDefault",        "Use default aggregation method for measures"},
    {"aggregateMethod",         "Aggregate to:"},
    {"aggregateItems",          "Add and Subtract Items"},

    // AggregateCalcStepView dialog strings.
    {"AggregateDialogItems",    "Select the items to include in your aggregate:"},
    {"AggregateDialogRule",     "Select how you want to aggregate these items:"},
        
    // Welcome panel strings
    {"WELCOMEDONTSHOW",     "&Do not show this page again"},
      
    // Qualify QDR panel resources
    {"qdrDimensionColumn",  "Dimension"},
    {"qdrMemberColumn",     "Member"},
    {"qdrEachMember",       "Each {0}"},
      
    // The builder title formats for step and non step mode
    {"builderStepTitle",            "{0}, Step {1} of {2}: {3}"},
    {"builderStepNonTotalTitle",    "{0}, Step {1}: {2}"},
    {"builderNonStepTitle",         "{0}: {1}"},

    // MeasureListDialog
    {"selectMeasure",        "Select Measure"},
    {"measuresLabel",        "&Measures:"},
    {"defaultMeasuresCount", "# measures"},
    {"measuresCount",        "{0} of {1} Selected"},

    // Toolbar resources
    {"expand",    	"Expand all items in tree"},
    {"collapse",    "Collapse all items in tree"},
    {"find",        "Search for item in tree"},
    
    // StepManager resources
    {"sampleStartText",             "abc"},
    {"sampleEndText",               "xyz"},

    // gek 03/01/02 Number format panel resources
    // CalcStep Number Format Types and Strings

    // Note: The NUMBER_FORMAT_STRING_X values are used to determine the  
    //       default number formats that are available and may vary between 
    //       languages.

    {NUMBER_FORMAT_FORMAT,        "N&umber Format:"},
    {NUMBER_FORMAT_OPTIONS,       "Option&s..."},
    {NUMBER_FORMAT_DIALOG_TITLE,  "Number Format"},

    {NUMBER_FORMAT_NUMBER_GENERAL,  NUMBER_GENERAL},
    {NUMBER_FORMAT_NUMBER_CURRENCY, NUMBER_CURRENCY},
    {NUMBER_FORMAT_NUMBER_PERCENT,  NUMBER_PERCENT},

    // -9999     
    {NUMBER_FORMAT_NUMBER_1,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_1,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_1,      "999999990"},

    // -9999.00     
    {NUMBER_FORMAT_NUMBER_2,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_2,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_2,      "999990D99"},

    // -9,999    
    {NUMBER_FORMAT_NUMBER_3,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_3,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_3,      "999G990"},

    // <9,999>    
    {NUMBER_FORMAT_NUMBER_4,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_4,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_4,      "999G990PR"},

    // (9,999)    
    {NUMBER_FORMAT_NUMBER_5,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_5,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_5,      "(999G990)"},

    // Default for General Number Types

    // -9,999.00    
    {NUMBER_FORMAT_NUMBER_6,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_6,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_6,      "999G990D99"},

    // ($9,999.00)
    {NUMBER_FORMAT_NUMBER_7,      NUMBER_CURRENCY},
    {NUMBER_FORMAT_TYPE_7,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_7,      "(L999G990D99)"},

    // Default for Currency Number Types

    // -$9,999.00
    {NUMBER_FORMAT_NUMBER_8,      NUMBER_CURRENCY},
    {NUMBER_FORMAT_TYPE_8,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_8,      "L999G990D99"},

    // Default for Percent Number Types

    // -99.99%
    {NUMBER_FORMAT_NUMBER_9,      NUMBER_PERCENT},
    {NUMBER_FORMAT_TYPE_9,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_9,      "9990D99V99%"},

    // New default number types for BI Beans 3.x
    
    // (9,999.00)
    {NUMBER_FORMAT_NUMBER_10,      NUMBER_GENERAL},
    {NUMBER_FORMAT_TYPE_10,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_10,      "(999G990D99)"},

    // -99%
    {NUMBER_FORMAT_NUMBER_11,      NUMBER_PERCENT},
    {NUMBER_FORMAT_TYPE_11,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_11,      "999G990V99%"},

    // (99%)
    {NUMBER_FORMAT_NUMBER_12,      NUMBER_PERCENT},
    {NUMBER_FORMAT_TYPE_12,        NUMBER_FORMAT_TYPE_BIBEANS},
    {NUMBER_FORMAT_STRING_12,      "(999G990V99%)"},

    {TREELISTCOMBOBOXMODELMEMBERS_PARAMETER_OPTION, "Parameter..."},
    {TREELISTCOMBOBOXMODELMEMBERS_SELECT_ITEM_OPTION, "Select Item..."},
    
  	// Shuttle resources.
    {SHUTTLE_ADD,    	   "Add Selected Items"},
  	{SHUTTLE_ADD_ALL, 	 "Add All Items"},
    {SHUTTLE_REMOVE, 	   "Remove Selected Items"},
  	{SHUTTLE_REMOVE_ALL, "Remove All Items"},
    {SHUTTLE_AVAILABLE,  "Available:"},
    {SHUTTLE_SELECTED,   "Selected:"},
  };

	/**
   * Retrieves the locale-specific information contained in
	 * this <code>DataUtilGUIBundle</code> object.
	 * Each item in the array is a key/value pair.
	 * The key element (such as, "btnOK") is the string that is used in code;
	 * the value element (such as, "OK") is the actual information that is
	 * returned.
	 *
	 * @status hidden
	 */
  public Object[][] getContents() {
	  return resources;
  }
}
