
/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.bicontext;

import java.io.Serializable;

import java.util.Comparator;
import java.util.Locale;

import oracle.dss.util.ErrorHandler;

/**
 * Adds error handling and locale support to Comparator. Adds four methods to <code>Comparator</code>: set/getLocale, set/getErrorHandler.
 * <code>Locale</code> information allows comparisons to be language-dependent.  
 * 
 */
public interface BIComparator extends Comparator, Serializable {

    /**
     * Sets <code>Locale</code> to detemine the language used for comparisons.
     * This method has to be explicitly called when creating a <code>BIComparator</code>
     * instance to ensure that sorting is performed in the correct <code>Locale</code>.
     *   
     * @param l a <code>Locale</code> object.
     * 
     * @status new
     */
    void setLocale(Locale l);

    /**
     * Returns <code>Locale</code> that detemines the language used for comparisons.
     *
     * @return a <code>Locale</code> object.
     * @status new
     */
    Locale getLocale();

    /**
     * Sets an <code>ErrorHandler</code> object.
     *
     * @param eh <code>ErrorHandler</code>
     * 
     * @status new
     */
    void setErrorHandler(ErrorHandler eh);

    /**
     * Returns and <code>ErrorHandler</code> object.
     *
     * @return <code>ErrorHandler</code>
     *
     * @status new
     */
    ErrorHandler getErrorHandler();

}

