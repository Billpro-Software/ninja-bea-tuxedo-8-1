/*
 * AvailableItemsTreeTransferHandler.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import java.util.Vector;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import oracle.dss.queryBuilder.dnd.DefaultTreeTransferHandler;

public class AvailableItemsTreeTransferHandler extends DefaultTreeTransferHandler {

    public AvailableItemsTreeTransferHandler(AvailableItemsTree availableItemsTree, int action) {
        super(availableItemsTree, action);
    }
    
    public boolean executeDrop(JTree target, Vector draggedNodes, DefaultMutableTreeNode newParentNode, int action) { 
        //Vector currentItemIDs = QBUtils.getSelectedItemIDs(getQueryBuilderContext());
        //Vector selectedItemIDs = getSelectedItemIDs(draggedNodes);
        //Vector itemIDs = QBUtils.remove(currentItemIDs, selectedItemIDs);
        //setItems(itemIDs, getQueryBuilderContext());
        //refresh();
        return true;
    }
}

