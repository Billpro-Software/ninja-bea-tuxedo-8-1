/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Flags that specify the kind of pivot for the
 * <code>LayoutManager.pivot</code> method.
 *
 * @status Documented
 */
public interface PivotConstants
{
    /**
     * Specifies that the source dimension is moved
     * before the target dimension during a pivot.
     *
     * @status Documented
     */
    public static final int PIVOT_BEFORE = 0;

    /**
     * Specifies that the source dimension is moved
     * after the target dimension during a pivot.
     *
     * @status Documented
     */
    public static final int PIVOT_AFTER = 1;        
}
