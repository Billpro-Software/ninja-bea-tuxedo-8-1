/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;

import oracle.dss.selection.OlapQDR;

/**
 * Base class to distinguish drill sequence events.
 * @status Documented
 */
public abstract class DrillEvent extends QueryEvent
{
    /**
     * Constructor to use for a drill to a relative level of the specified
     * hierarchy.
     *
     * @param source     The source of the event, that is, the object that
     *                   fired the event.
     * @param dimension  The dimension to drill.
     * @param value      The dimension values, also known as dimension member,
     *                   that were drilled.
     * @param hierarchy  The target hierarchies that define the drill semantics.
     * @param delta      The relative number of levels to traverse within the
     *                   specified hierarchy. Positive numbers drill down,
     *                   negative numbers drill up.
     * @param above        If true, insert the targets' drill results above the targets rather
     *                     than below, which is the default.
     * @param valueParent  Values' parent dimension value; used for
     *                     optimizing later potential drill up requests.
     * @param queryParent  The items from the original query members under
     *                     which this drill occurs.
     * @param levelDepth   Optional performance hint that indicates the numeric 
     *                     levels at which the
     *                     drill targets sit within their hierarchy.
     * @param parentQDR    Optional OlapQDRs that specify dimension/member 
     *                     pairs that limit where these drill (downs) should take 
     *                     place (parents of the target).
     *
     * @status documented
     */
    public DrillEvent(Object source, String dimension, String[] value, String[] hierarchy, int[] delta, boolean[] above, String[] valueParent, String[] queryParent, int[] levelDepth, OlapQDR[] parentQDR) {
        super(source);
        
        dim = dimension;
        
        val = value;
        
        hier = hierarchy;
        
        chg = delta;
        m_above = above;
        
        m_valueParent = valueParent;
        m_queryParent = queryParent;
        m_levelDepth = levelDepth;
        m_parentQDR = parentQDR;
    }

    /**
     * Constructor to use to drill to a specific level of the specified
     * hierarchy.
     *
     * @param source      The source of the event, that is, the object that
     *                    fired the event.
     * @param dimension   The dimension to drill
     * @param value       The dimension value, also known as dimension member,
     *                    to be drilled.
     * @param hierarchy   The target hierarchy that defines the drill semantics.
     * @param level       The name of the target level to traverse to.
     * @param action      A constant (<code>Step.ADD</code>,
     *                    <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                    <code>Step.SELECT</code>) that represents the
     *                    selection step action.
     * @param flags       A list of optional flags. These flags are drill
     *                    constants that begin with the prefix DRILL_EXCLUDE_.
     *
     * @see  DrillConstants#DRILL_EXCLUDE_RANGE
     * @see  DrillConstants#DRILL_EXCLUDE_SELF
     * @see  DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see  oracle.dss.selection.step.Step#ADD
     * @see  oracle.dss.selection.step.Step#KEEP
     * @see  oracle.dss.selection.step.Step#REMOVE
     * @see  oracle.dss.selection.step.Step#SELECT
     *
     * @status Documented
     */
    public DrillEvent(Object source, String dimension, String value, String hierarchy, String level, int action, BitSet flags) {
        this(source, dimension, new String[] {value}, new String[] {hierarchy}, null, null, null, null, null, null);
        
        lvl = new String[] {level};
        act = new int[] {action};
        fl = new BitSet[] {flags};
    }
    
    /**
     * Retrieves the dimension to drill.
     *
     * @return  The dimension to drill.
     *
     * @status Documented
     */
    public String getDimension() {
        return dim;
    }
    
    /**
     * Retrieves whether or not drills are above or below the target
     * 
     * @return <code>true</code> if above, <code>false</code> if not
     * 
     * @status New
     */
    public boolean getAbove()
    {
        if (m_above != null && m_above.length > 0)
            return m_above[0];
        return false;
    }
    
    /**
     * Retrieves the dimension value (also known as the dimension
     * member) that is being drilled.
     *
     * @return The dimension member that is being drilled.
     *
     * @status Documented
     */
    public String getValue() {
        if (val != null && val.length > 0)
            return val[0];
        return null;
    }

    /**
     * Retrieves the query parent parameter from the drill call.
     *
     * @return The query parent parameter.
     *
     * @status Documented
     */
    public String getQueryParent() {
        if (m_queryParent != null && m_queryParent.length > 0)
            return m_queryParent[0];
        return null;
    }

    /**
     * Retrieves the parent parameter from the drill call.
     *
     * @return The parent parameter.
     *
     * @status Documented
     */
    public String getValueParent() {
        if (m_valueParent != null && m_valueParent.length > 0)
            return m_valueParent[0];
        return null;
    }

    /**
     * Retrieves the parent QDR parameter of the drill call.
     *
     * @return The parent QDR of the drill call
     *
     * @status Documented
     */
    public OlapQDR getParentQDR() {
        if (m_parentQDR != null && m_parentQDR.length > 0)
            return m_parentQDR[0];
        return null;
    }

    /**
     * Retrieves the leveldepth of the target from the drill call.
     *
     * @return The target's leveldepth.
     *
     * @status Documented
     */
    public int getLevelDepth() {
        if (m_levelDepth != null && m_levelDepth.length > 0)
            return m_levelDepth[0];
        return -1;
    }


    /**
     * Retrieves the target hierarchy that defines the drill semantics.
     *
     * @return The target hierarchy.
     *
     * @status Documented
     */
    public String getHierarchy() {
        if (hier != null && hier.length > 0)
            return hier[0];
        return null;
    }
    
    /**
     * Retrieves the name of the target level to traverse to.
     *
     * @return The target level to traverse to, if a specific level is
     *         identified; <code>null</code> if the drill is to a relative
     *         level.
     *
     * @status Documented
     */
    public String getLevel() {
        if (lvl != null && lvl.length > 0)
            return lvl[0];
        return null;
    }
    
    /**
     * Retrieves the relative number of levels to traverse within the specified
     * hierarchy.
     *
     * @return  The relative number of levels. Positive numbers indicate drill
     *          down; negative numbers indicate drill up.
     *
     * @status Documented
     */
    public int getDelta() {
        if (chg != null && chg.length > 0)
            return chg[0];
        return 0;
    }
    
    /**
     * Retrieves a list of optional flags that are drill constants.
     *
     * @return   The list of flags. These flags are drill constants that begin
     *           with the prefix DRILL_EXCLUDE_.
     *
     * @see  DrillConstants#DRILL_EXCLUDE_RANGE
     * @see  DrillConstants#DRILL_EXCLUDE_SELF
     * @see  DrillConstants#DRILL_EXCLUDE_SIBLINGS
     *
     * @status Documented
     */
    public BitSet getFlags() {
        if (fl != null && fl.length > 0)
            return fl[0];
        return null;
    }
    
    /**
     * Retrieves the selection step action flag.
     *
     * @return A constant that represents the selection step action, such as
     *         <code>Step.ADD</CODE>, or -1, if there is no selection
     *         step action.
     *
     * @see  oracle.dss.selection.step.Step#ADD
     * @see  oracle.dss.selection.step.Step#KEEP
     * @see  oracle.dss.selection.step.Step#REMOVE
     * @see  oracle.dss.selection.step.Step#SELECT
     * 
     * @status Documented
     */
    public int getAction() {
        if (act != null && act.length > 0)
            return act[0];
        return -1;
    }
    
    // Members
    /**
     * @hidden
     * @serial dimension being drilled
     */
    protected String dim;
    /**
     * @hidden
     * @serial dimension value being drilled
     */
    protected String[] val;
    /**
     * @hidden
     * @serial hierarchy of dimension being drilled
     */
    protected String[] hier;
    /**
     * @hidden
     * @serial size of change
     */
    protected int[] chg = null;
    /**
     * @hidden
     * @serial drilled-to level
     */
    protected String[] lvl;
    /**
     * @hidden
     * @serial drill action
     */
    protected int[] act = null;
    /**
     * @hidden
     * @serial special drill flags
     */
    protected BitSet[] fl;
    /**
     * @hidden
     * @serial Parent QDR
     */
    protected OlapQDR[] m_parentQDR = null;
    /**
     * @hidden
     * @serial Parent in Query
     */
    protected String[] m_queryParent = null;
    /**
     * @hidden
     * @serial True hierarchical parent
     */
    protected String[] m_valueParent = null;
    /**
     * @hidden
     * @serial Level at which target occurs
     */
    protected int[] m_levelDepth = null;
    
    /**
     * @hidden
     */
    protected boolean[] m_above = null;
}
