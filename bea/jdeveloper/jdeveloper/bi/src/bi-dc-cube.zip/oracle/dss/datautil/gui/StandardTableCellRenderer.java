/**
 * StandardTableCellRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * @hidden
 * 
 * Label renderer used for the Dimension and Member columns.
 * 
 * This class is primarily used by BI Beans to fix tabbing and ADA issues 
 * associated with the <code>JTable</code>.
 * 
 * @status hidden
 */
public class StandardTableCellRenderer extends DefaultTableCellRenderer {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Dimension Members
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  private JComboBox m_comboBox;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   * 
   * @status hidden
   */
  public StandardTableCellRenderer (JComboBox comboBox) {
    m_comboBox = comboBox;
  }

  /**
   * @hidden
   * 
   * Overriding to set the background and foreground color. Also turn the editor 
   * on when the cell has focus and is selected. 
   * 
   * @status hidden
   */
  public Component getTableCellRendererComponent (JTable table, Object value, 
    boolean isSelected, boolean hasFocus, int row, int column) {

    Component renderer = 
      super.getTableCellRendererComponent (table, value, isSelected, hasFocus, 
        row, column);

    renderer.setBackground (Color.white);
    renderer.setForeground (Color.black);

    if (hasFocus && isSelected) {
      table.editCellAt(row, column);
      m_comboBox.requestFocus();
    }

    return renderer;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
}
