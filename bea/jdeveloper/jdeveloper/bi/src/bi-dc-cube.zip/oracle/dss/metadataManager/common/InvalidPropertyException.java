/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * Indicates a problem with a property.
 * The property name is not recognized as a valid property.
 *
 * @status Reviewed
 */
public class InvalidPropertyException extends MetadataManagerException
{
    /**
     * @hidden
     * Constructor.
     *
     * @param propName The <code>String</code> that was passed as a property.
     * @param driverType The type of driver that initiates this exception.
     *
     * @status hidden
     */
    public InvalidPropertyException(String propName, String driverType)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_ATTRS, new Object[]{propName}, driverType, null);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param propName The <code>String</code> that was passed as a property.
     * @param locale The locale to use in the message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public InvalidPropertyException(String propName, Locale locale, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_ATTRS, new Object[]{propName}, locale, driverType, prevException);
    }
}