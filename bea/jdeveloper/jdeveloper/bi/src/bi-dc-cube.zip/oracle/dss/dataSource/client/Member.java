/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/Member.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/11/09 - XbranchMerge bmoroze_bug-8879459 from main
    bmoroze     05/17/06 - 
    jramanat    04/21/06 - SBA-style drilling 
    bmoroze     02/27/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/Member.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.client;

import java.util.BitSet;
import java.util.Hashtable;

import java.util.Map;
import java.util.Vector;

import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.CursorUtils;
import oracle.dss.dataSource.common.Query;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.drill.ItemDrill;
import oracle.dss.util.DataDirector;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.transform.MemberInterface;
import oracle.dss.util.transform.MemberMetadata;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.TransformUtils;

/**
 * @hidden
 * Metadata member
 */
public class Member extends Hashtable implements MemberInterface
{
    protected Object m_value = null;
    protected String m_item = null;
    protected String m_layerColumn = null;
    protected Query m_query = null;
    protected Map<String, Object> m_valMap = null;
    
    public Member(Object value, String item, String layerColumn, Query query)
    {
        super();
        m_value = value;
        m_item = item;
        m_query = query;
        // Only store this if they're not equal
	if (item != null && !item.equals(layerColumn))
        	m_layerColumn = layerColumn;
    }

    public Member(Object value, String item, String layerColumn, Map<String, Object> valMap, Query query)
    {
        this(value, item, layerColumn, query);
        m_valMap = valMap;
    }
    
    public boolean isCollapsed()
    {
        return false;
    }

    public AggregatePosition getAggregatePosition()
    {
        return AggregatePosition.NONE;
    }
    
    
    public String getValue() throws TransformException
    {
        try
        {
            Object obj = getMetadata(MemberMetadata.KEY);
            if (obj != null)
                return obj.toString();
            return null;
        }
        catch (TransformException e)
        {
            return null;
        }
    }
    
    // Handle possible LayerMetadataMap inputs
    protected boolean isLabelType(String type)
    {
        return type.equals(MetadataMap.METADATA_LONGLABEL) || type.equals(MetadataMap.METADATA_SHORTLABEL) || type.equals(MetadataMap.METADATA_MEDIUMLABEL);
    }
    
    protected boolean isLevelType(String type)
    {
        return type.equals(MetadataMap.METADATA_LEVEL) || type.equals(MetadataMap.METADATA_LEVEL_LABEL) || type.equals(MetadataMap.METADATA_LEVEL_NAME);
    }

    // Check the given QDR against the node at which we're stored
/*    private boolean _qdrMatchesNode(OlapQDR qdr) throws TransformException
    {
        if (m_edgeNode != null)
        {
            EdgeTreeNode node = m_edgeNode;
            String column = null;
            OlapQDRMember qdrMember = null;
            // Don't want to start right on this node: drill QDRs describe the outer slices, the parents
            node = m_edgeNode.getParent();
            while (node != null && !node.isRoot())
            {
                column = node.getLayerName();
                qdrMember = (OlapQDRMember)qdr.getDimMember(column);
                if (qdrMember != null)
                {
                    if (!node.getMember().getValue().equals(qdrMember.getData()))
                        return false;
                }
                //  Next--move to the parent
                node = node.getParent();
            }
        }
        return true;
    }*/
    
    protected String getLayerColumn()
    {
    	return m_layerColumn == null ? m_item : m_layerColumn;
    }

    public Object getMetadata(String type) throws TransformException
    {
        if (type == null)
            return null;
        
        if (type.equals(MemberMetadata.COLLAPSED) || type.equals(MemberMetadata.TOTAL))
            return Boolean.valueOf(false);
        if (type.equals(MemberMetadata.AGGREGATE_POSITION))
            return AggregatePosition.NONE;
        if (type.equals(MemberMetadata.NULL))
            return m_value == null;
        
        // Check the valmap, if any
        String metadataMapType = TransformUtils.convertMemberMetadata(type);
        if (m_valMap != null && m_valMap.containsKey(metadataMapType))
        {
            Object obj = m_valMap.get(metadataMapType);
            return obj;
        }
        
        if (type.equals(MemberMetadata.KEY) || type.equals(MemberMetadata.LABEL))
            return m_value;
        //if (type.equals(MetadataMap.METADATA_INDENT) || type.equals(MetadataMap.METADATA_REL_INDENT))
        if (type.equals(MemberMetadata.INDENT))
        {
            // Find the m_item in the drill paths of m_layerColumn
            if (m_item.equals(getLayerColumn()))
                return new Integer(0);
                
            int level = CursorUtils.getLevelFromDrillItem(m_query, m_layerColumn, m_item);
            return level;
        }
        if (type.equals(MemberMetadata.DRILLSTATE))
        {
            return _getDrillState();
        }
        if (type.equals(MetadataMap.METADATA_VALUE_RAW))
            return m_value;
        
        if (isLevelType(type))
        {
            // Try to get some metadata here and check the drill paths
            // m_item is the actual level column this member came from, not the overall layer name
            return m_item;
        }
        if (type.equals(MetadataMap.METADATA_HIERARCHY))
        {
            // blm - Selection code moved to dvt-olap
        /*            Selection sel = m_query.findSelection(m_layerColumn);
            if (sel != null)
            {
                return sel.getHierarchy();
            }*/
            return null;
        }        
        if (type.equals(MemberMetadata.DRILL_PARENT_LABEL))
        {
            // These are the parent targets from which replace drills came
            // Look up any drill for this member's item, and return its target
            try
            {
                MDItem item = getMDItem();
                if (item == null)
                    return null;
                
                String itemID = item.getUniqueID();
                
                ItemDrill[] drills = m_query.getQueryState().getItemDrills();
                if (drills != null)
                {
                    BitSet replaceBitSet = new BitSet();
                    replaceBitSet.set(DataDirector.DRILL_REPLACE);
                    for (int i = 0; i < drills.length; i++)
                    {
                        if (drills[i].getFlags(0).equals(replaceBitSet) && itemID.equals(drills[i].getDrillPath(0)))
                        {
                            // here's our replace drill
                            return drills[i].getDrillTarget(0);
                        }
                    }
                }
            }                
            catch (MetadataManagerException e)
            {
                throw new TransformException(e.getMessage(), e);
            }
        }        
        return null;
    }

    
    private Integer _getDrillState() throws TransformException
    {
        // Determine if we are drilled either within ourselves or as a drill level step            
        // If so, can drill up.  If not, check if we're at the bottom level or not
        // Get selection for this item        
/*        Selection sel = m_query.findSelection(m_layerColumn);
        if (sel != null)
        {
            // Check for drills
            DrillStep ds = sel.getDrillStep();
            if (ds != null)
            {
                // Note that this will have to be expanded to check the qdr, etc.  Just check target for
                // now
                Vector drillDowns = ds.getDrillDownTargets();
                Vector drillQDRs = ds.getParentQDRs();
                int size = drillDowns.size();
                String target = null;
                OlapQDR drillQDR = null;
                for (int i = 0; i < size; i++)
                {
                    target = (String)drillDowns.elementAt(i);
                    if (target.equals(m_value))
                    {
                        try
                        {
                            // Now make sure QDR here matches                            
                            if (drillQDRs != null && drillQDRs.size() > i)
                                drillQDR = (OlapQDR)drillQDRs.elementAt(i);
                            if (drillQDR != null)
                            {
                                // Check it vs. our position
                                if (_qdrMatchesNode(drillQDR))
                                    return new Integer(DataDirector3.DRILLSTATE_IS_DRILLED);
                                else
                                    continue;
                            }
                        }
                        catch (Exception e)
                        {
                            throw new TransformException(e.getMessage(), e);
                        }
                        
                        return new Integer(DataDirector3.DRILLSTATE_IS_DRILLED);
                    }
                }
            }
            // Look for drill level steps
            int count = sel.getDrillLevelStepCount();
            DrillLevelStep dls = null;
            for (int i = 0; i < count; i++)
            {
                dls = sel.getDrillLevelStep(i);
                if (dls != null)
                {
                    // Does target match?
                    if (dls.getFamilyValues() != null && dls.getFamilyValues().size() > 0)
                    {
                        String target = (String)dls.getFamilyValues().elementAt(i);
                        if (target != null && target.equals(getValue()))
                        {
                            // This has been drilled
                            return new Integer(DataDirector3.DRILLSTATE_IS_DRILLED);
                        }
                    }
                }
            }
        }*/
        // Get our MDObject
        try
        {
            MDItem item = getMDItem();
            if (item == null)
                return new Integer(0);

            // Are there any pure drill replaces whose targets match this item?
            ItemDrill[] drills = m_query.getQueryState().getItemDrills();
            if (drills != null)
            {
/*                BitSet replaceBitSet = new BitSet();
                replaceBitSet.set(DataDirector3.DRILL_REPLACE);
                Integer state = null;
                for (int i = 0; i < drills.length; i++)
                {
                    if (drills[i].getFlags(0).equals(replaceBitSet) && item.getUniqueID().equals(drills[i].getDrillPath(0)))
                    {
                        state = getReplaceDrillState(drills[i]);
                        if (state != null)
                            return state;
                    }
                }*/
            
                for (int i = 0; i < drills.length; i++)
                {
                    if (item.getUniqueID().equals(drills[i].getItem()))
                    {
                        // Item is already drilled
                        return new Integer(DataDirector.DRILLSTATE_IS_DRILLED);
                    }
                }
            }
            
            // No drill down paths and no current drills?  Not drillable
            Vector downPaths = item.getDrillDownPaths();            
            if (downPaths == null || downPaths.size() == 0)
            {
                return new Integer(DataDirector.DRILLSTATE_NOT_DRILLABLE);                
            }
            // There is somewhere to go
            return new Integer(DataDirector.DRILLSTATE_DRILLABLE);
        }
        catch (MetadataManagerException e)
        {
            throw new TransformException(e.getMessage(), e);
        }
        catch (CloneException ce)
        {
            throw new TransformException(ce.getMessage(), ce);
        }
    }

    private Integer getReplaceDrillState(ItemDrill drill) throws MetadataManagerException
    {
        // if this drill is a pure replace drill, then we have
        // to check to see if the drill's item's path is equal
        // to our current item--then it's drilled
        MDObject mdDrillObj = m_query.getMDObject(MM.UNIQUE_ID, drill.getItem(), MM.OBJECT);
        if (mdDrillObj instanceof MDItem)
        {
            Vector drillDownPaths = ((MDItem)mdDrillObj).getDrillDownPaths();
            if (drillDownPaths != null && drillDownPaths.size() > 0)
            {
                String drillPathItem = ((MDItem)drillDownPaths.elementAt(0)).getUniqueID();
                if (drillPathItem != null && drillPathItem.equals(m_item))
                    return new Integer(DataDirector.DRILLSTATE_IS_DRILLED);                                                                                
            }
        }
        return null;
    }
    
    private MDItem getMDItem() throws MetadataManagerException
    {
        MDObject mdObj = m_query.getMDObject(MM.UNIQUE_ID, m_item, MM.OBJECT);
        if (mdObj instanceof MDItem)
        {
            return (MDItem)mdObj;
        }
        return null;
    }
}
