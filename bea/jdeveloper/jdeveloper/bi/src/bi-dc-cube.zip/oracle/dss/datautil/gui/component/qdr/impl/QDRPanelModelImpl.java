/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/qdr/impl/QDRPanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jhyman      01/24/06 - fix packaging for DimensionMemberComboModelImpl 
    gkellam     01/12/06 - Update component context to remove awt references. 
    jramanat    09/21/05 - Creation
 */

package oracle.dss.datautil.gui.component.qdr.impl;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;

import java.util.Vector;

import oracle.bali.ewt.dialog.JEWTDialog;

import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.QueryEditorException;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.queryBuilder.AvailableItemsPanel;
import oracle.dss.selection.OlapQDR;
import oracle.dss.datautil.gui.component.comboBox.impl.DimensionMemberComboModelImpl;
import oracle.dss.util.gui.component.comboBox.TreeListComboModel;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.HierarchicalQDR;
import oracle.dss.util.gui.component.qdr.QDRPanelModel;

/**
 *  Implementation of QDRPanelModel based on MetadataProvider/DataProvider
 * 
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/qdr/impl/QDRPanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */
public class QDRPanelModelImpl implements QDRPanelModel {

  private ComponentContext m_context;
  private OlapQDR m_qdr;

  public QDRPanelModelImpl(OlapQDR qdr, ComponentContext context) {
    m_qdr = qdr;
    m_context = context;
  }
  
  // javadoc inherited from interface
  public String getLabel(String item) {
    try {
      MDObject object = m_context.getBIProvider().getMetadataManager().getMDObjectByUniqueID(item);
      return object.toString(m_context.getDisplayLabelType());
    }
    catch (MetadataManagerException mme) {
      m_context.getErrorHandler().error(mme, getClass().getName(), "getLabel");
    }
    return item;
  }
  
  // javadoc inherited from interface
  public boolean isAddRemoveSupported() {
    return true;
  }

  // javadoc inherited from interface
  public String getNewItem() {
    AvailableItemsPanel panel = new AvailableItemsPanel(m_context);
    Component c = (Component) m_context.getParent();
    JEWTDialog dlg = null;
    if (c instanceof Dialog) {
      dlg = new JEWTDialog((Dialog)c, "Select Item");
    }
    else if (c instanceof Frame) {
      dlg = new JEWTDialog((Frame)c, "Select Item");
    }
    else {
      dlg = new JEWTDialog((Dialog)null, "Select Item");
    }
    dlg.setContent(panel);
    dlg.setButtonMask(JEWTDialog.BUTTON_OK | JEWTDialog.BUTTON_CANCEL);
    dlg.runDialog();
    if (!dlg.isCancelled()) {
      Object[] items = panel.getSelectedItems();
      if (items != null && items.length > 0) {
        return ((ComponentNode)items[0]).getID();
      }
    }
    return null;
  }
  
  // javadoc inherited from interface
  public TreeListComboModel getMembers(String item) {    
    return new DimensionMemberComboModelImpl(item, m_context.getMetadataProvider().getHierarchy(item), m_context);
  }
  
  // javadoc inherited from interface
  public HierarchicalQDR getQDR() {
    return m_qdr;
  }

  /**
   * Retrieves the OlapQDR being modified
   * 
   * @return the OlapQDR
   */
  public OlapQDR getOlapQDR() {
    return m_qdr;
  }
}
