/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataFilterEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/10/05 - bmoroze_datafilters_3
    bmoroze     06/09/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/DataFilterEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import oracle.dss.selection.dataFilter.BaseDataFilter;

/**
 * Base class to distinguish data filter sequence events.
 *
 * @status New
 */
public abstract class DataFilterEvent extends QueryEvent
{
    // Fields
    /**
     * @hidden
     * @serial list of data filters
     * @status protected
     */
    protected BaseDataFilter[] m_filters;

    /**
     * @hidden
     * @serial were these data filters removed?
     * @status protected
     */
    protected boolean m_removed = false;

    /**
     * Constructs the event.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param filters An array of changed <code>BaseDataFilter</code> objects.
     * @param removed    <code>true</code> if the <code>BaseDataFilter</code> objects
     *                   were removed, <code>false</code> if they were not.
     *
     * @status documented
     */
    public DataFilterEvent(Object source, BaseDataFilter[] filters, boolean removed) {
        super(source);
        
        m_filters = filters;
        m_removed = removed;
    }    
    
    /**
     * Retrieves the list of changed <code>BaseDataFilter</code> objects.
     *
     * @return An array of changed <code>BaseDataFilter</code> objects.
     *
     * @status New
     */
    public BaseDataFilter[] getDataFilters() {
        return m_filters;
    }
    
}

