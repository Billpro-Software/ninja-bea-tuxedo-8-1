/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/VersionCheck.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/15/05 - 
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     05/18/05 - bmoroze_r11_refactoring
    bmoroze     05/05/05 - Creation
 */
package oracle.dss.dataSource.common;

import oracle.dss.metadataManager.common.MM;
import oracle.dss.util.Utility;
/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/VersionCheck.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */

public class VersionCheck extends Object
{
    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.1.1 (although database will only report
     * 9.2.0.1.0) server or beyond for special performant handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is92(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "9.2.0.1");
    }    
    
    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.3
     * server or beyond for special handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is9203(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "9.2.0.3");
    }    

    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.4
     * server or beyond for special handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is9204(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "9.2.0.4");
    }

    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.5
     * server or beyond for special handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is9205(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "9.2.0.5");
    }

    /**
     * @hidden
     * Determines if we're connected to a 9.2.0.6
     * server or beyond for special handling of certain
     * OLAP API queries
     * @status hidden
     */
    public static boolean is9206(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "9.2.0.6");
    }    
    
    /**
     * @hidden
     * Determines if we're connected to a 10g
     * server or beyond
     */
    public static boolean is10(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "10.1.0.2");
    }
    
    /**
     * @hidden
     * Determines if we're connected to a 10.1.0.3 server or beyond
     */
    public static boolean is10103(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "10.1.0.3");        
    }        
    
    
    /**
     * @hidden
     * Determines if we're connected to a 10.2
     * server or beyond 
     * @status hidden
     */
    public static boolean is102(QueryManagerInterface qm)
    {
        return Utility.compareVersionStrings(qm.getConnectionVersionInfo(MM.MDM), "10.2");
    }
    
}