/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/DatasourceComboBoxModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.queryBuilder;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;

import oracle.dss.bicontext.BIContext;
import oracle.dss.bicontext.BISearchResult;

import oracle.dss.connection.client.Connection;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.provider.MetadataProvider;

/**
 * <pre>
 * DataSource <code>ComboBoxModel</code>.
 * </pre>
 *
 * @author rbalexan 
 * @since  11.0.0.0.11
 * @status new
 *
 * MODIFIED    (MM/DD/YY)
 * 
 */
public class DatasourceComboBoxModel extends DefaultComboBoxModel {
    
  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * @hidden
   * Contains properties used to initialize the <code>DatasourceComboBoxModel</code>.
   *
   * @status hidden
   */
  private ComponentContext m_componentContext = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <code>DatasourceComboBoxModel</code> constructor.
   * 
   * @param componentContext A <code>ComponentContext</code> containing properties
   *        useful for initializing the <code>DatasourceComboBoxModel</code>.
   *        
   * @status new       
   */
  public DatasourceComboBoxModel (ComponentContext componentContext) {
    super();
    setComponentContext (componentContext);

    refresh();
    
    // Initialize the ComboBox to the current DataSource, if any
    if ((componentContext != null) && (componentContext.getMetadataProvider() != null)) {
      setSelectedItem (componentContext.getMetadataProvider().getCurrentDatasourceRootFolder());
    }
  }
        
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * <pre>
   * Set the value of the selected item, which may be null.
   * 
   * A <code>BIContext</code> value which represents a Datasource root may
   * be specifed.
   * 
   * For example:
   * setSelectedItem (componentContext.getMetadataProvider().getCurrentDatasourceRootFolder());  
   * </pre>
   * 
   * @param objSelectItem A <code>Object</code> to select or or null for 
   *        no selection.
   *        
   * @status new 
   */
  public void setSelectedItem (Object objSelectItem) {
    // Determine if we are selecting an item based in a BIContext
    if (objSelectItem instanceof BIContext) {

      Object objBISearchResult = null;
      Object objElement = null;
      Object objBIContext = null;
      
      // Iterate over all of the current elements
      for (int nIndex = 0; nIndex < getSize(); nIndex++) {
        objElement = getElementAt (nIndex);  
        
        // Determine if the item is a BISearchResult
        if (objElement instanceof BISearchResult) {
          objBISearchResult = ((BISearchResult) objElement).getObject();     
          
          // Determine if the item is a Connection
          if (objBISearchResult instanceof Connection) {
            try {
              // Determine the root folder of the connection
              objBIContext = ((Connection) objBISearchResult).getRoot();
              
              // If the folders match, we have a winner.....
              if (objBIContext.equals (objSelectItem)) {
                // Map the objSelectItem to the appropriate value which is in 
                // the ComboBox
                objSelectItem = objElement;
                break;
              }
            }
            
            // For now, do not update selection if we get an exception
            catch (Exception exception) {
              return;
            }
          }
        }
      }
    }

    super.setSelectedItem (objSelectItem);  
  }
        
  /**
   * Specifies the <code>ComponentContext</code>.
   * 
   * @param componentContext A <code>ComponentContext</code> containing 
   *        properties used to initialize the <code>DatasourceComboBoxModel</code>.
   *        
   * @status new       
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;  
  }      

  /**
   * Retrieves the <code>ComponentContext</code>.
   * 
   * @return <code>ComponentContext</code> containing properties used to  
   *         initialize the <code>DatasourceComboBoxModel</code>.
   *        
   * @status new       
   */
  public ComponentContext getComponentContext () {
    return m_componentContext;  
  }      
        
  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
    
  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
    
  /**
   * @hidden
   */
  private void refresh() {
    removeAllElements();
    Vector v = getDatasources (getComponentContext());

    if (v != null) {
      Object o;
      for (Enumeration e=v.elements(); e.hasMoreElements(); ) {
        o = e.nextElement();
        if (o != null) {
          addElement(o);
        }
      }
    }
  }
             
  /**
   * @hidden
   */
  private Vector getDatasources (ComponentContext context) {
    if (context != null) {
      MetadataProvider mp = context.getMetadataProvider();

      if (mp != null) {
        return mp.getDatasources();
      }
    }

    return null;
  }
}
    
