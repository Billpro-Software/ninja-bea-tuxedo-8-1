/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.queryBuilder;

import oracle.dss.bicontext.*;
import oracle.dss.bicontext.gui.*;
import oracle.dss.datautil.*;
import javax.naming.directory.*;

public class BIDirTreeModel extends DefaultDirTreeModel {
    //public BIDirTreeModel(BIContext biContext, QueryAccess qa) {
    public BIDirTreeModel(DirContext con, Attributes filters, SearchControls controls, TreeSorter sorter, String rootName, String rootIcon, QueryAccess qa) {
        super(con, filters, controls, sorter, rootName, rootIcon);
        //super(biContext, "Root Name", "rootIconKey");
        //super();
        
        //setInitialContext(con);
        //setSearchFilters(filters);
        //setSearchControls(controls);
        //setSorter(sorter);
        //initialize(null, rootName, rootIcon);
    }
}