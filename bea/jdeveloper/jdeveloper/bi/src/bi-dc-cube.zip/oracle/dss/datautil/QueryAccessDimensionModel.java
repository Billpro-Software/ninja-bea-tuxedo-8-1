/*
 * QueryAccessDimensionModel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 *
 * Implementation of DimListDataModel interface for use with 
 * DimensionList objects.
 *
 */

package oracle.dss.datautil;

import java.util.Vector;

import javax.swing.event.ListDataEvent;

import oracle.dss.util.dimensionList.DimListDataItem;

import oracle.dss.util.LayoutAccess;
import oracle.dss.util.ErrorHandler;

import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.query.QueryAccessUtilities;
import oracle.dss.metadataManager.client.MetadataManager;

/**
 * QueryAccessDimensionModel provides an interface between the
 * DataSource/DataAccess implementation via the
 * DimensionList Data Model (DimListDataModel).
 *
 * @see oracle.dss.dataSource.common.SelectionManager
 * @see oracle.dss.util.DataSource
 * @see oracle.dss.util.dimensionList.DimensionList
 * @see oracle.dss.util.dimensionList.DimListDataModel
 *
 * @status new
 */
public class QueryAccessDimensionModel extends OLAPDimensionModel
                                       implements QueryAccessListener
    {
    private transient long m_beforeCount = 0;
    private transient QueryAccessUtilities m_queryAccessUtils;
        // blm - Selection code moved to dvt-olap
/*    private transient Selection m_seedSelection = null;*/
    private transient MetadataManager m_metadataManager = null;

    /*
     * A list of Level IDs that should be retrieved.
     */
    private transient Vector m_vLevels = null;

    /**
     * @hidden
     *
     * <code>QueryAccessDimensionModel</code> Constructor.
     *
     * @param  queryAccessUtilities a <code>QueryAccessUtilities</code> value
     *         that represents <code>QueryAccess</code> utilities useful
     *         for <code>CalcBuilder</code> and <code>QueryBuilder</code>.
     *         the dimension.
     * @param  strDimension a <code>String</code> value that represents
     *         the dimension.
     * @param  strHierarchy a <code>String</code> value that represents
     *         the hierarchy associated with the dimension.
     * @param  vLevels a <code>Vector</code> value that represents
     *         a list of level strings.
     * @param  metadataManager a <code>MetadataManager</code> value that is used
     *         to retrieve metadata information.
     *
     */
    public QueryAccessDimensionModel (QueryAccessUtilities queryAccessUtilities,
      String strDimension, String strHierarchy, Vector vLevels,
        MetadataManager metadataManager) {
        m_metadataManager = metadataManager;
        m_queryAccessUtils = queryAccessUtilities;

        // gek 12/04/01 Specify the levels to retrieve, with null retrieving all levels
        setLevels (vLevels);

        // Listen to selection manager for changes
        m_queryAccessUtils.getQueryAccess().addQueryAccessListener(this);

        // Update the selection associated with the model
        updateSelection (strDimension, strHierarchy, vLevels);
        }

    /**
     * @hidden
     *
     * <code>QueryAccessDimensionModel</code> Constructor.
     *
     * @param  queryAccessUtilities a <code>QueryAccessUtilities</code> value
     *         that represents <code>QueryAccess</code> utilities useful
     *         for <code>CalcBuilder</code> and <code>QueryBuilder</code>.
     *         the dimension.
     * @param  strDimension a <code>String</code> value that represents
     *         the dimension.
     * @param  strHierarchy a <code>String</code> value that represents
     *         the hierarchy associated with the dimension.
     * @param  metadataManager a <code>MetadataManager</code> value that is used
     *         to retrieve metadata information.
     *
     */
    public QueryAccessDimensionModel (QueryAccessUtilities queryAccessUtilities,
                                      String strDimension, String strHierarchy,
                                      MetadataManager metadataManager) {
      this (queryAccessUtilities, strDimension, strHierarchy, null, metadataManager);
    }

    /**
     * Constructor.
     *
     * @param qa  The QueryAccess for this model.
     * @param la  The LayoutAccess for this model.
     * @param eh  The ErrorHandler for this model.
     * @param dimension  The unique ID for the dimension.
     * @param hierarchy  The unique ID for the hierarchy.
     * @param mm  The MetadataManager for this model.
     *
     * @status new
     */
    public QueryAccessDimensionModel (QueryAccess qa, LayoutAccess la,
                ErrorHandler eh, String dimension, String hierarchy,
                MetadataManager mm)
    {
      this(new QueryAccessUtilities(qa, la, eh), dimension, hierarchy, mm);
    }

    /**
     * Updates the selection associated with the model.
     *
     * The user should call the refresh method to update the model based
     * on the new selection.
     *
     * @param  strDimension a <code>String</code> value that represents
     *         the dimension.
     * @param  strHierarchy a <code>String</code> value that represents
     *         the hierarchy associated with the dimension.
     * @param  vLevels a <code>Vector</code> value that represents
     *         a list of level strings.
     *
     * @status New
     */
    public void updateSelection (String strDimension, String strHierarchy,
                                    Vector vLevels)
        {
        // If we don't have a non-null dimension , simply return
        if (strDimension == null)
            return;

            // blm - Selection code moved to dvt-olap
/*
        // Create our all step based on the specified dimension, hierarchy and level
        ConditionStep allStep = new AllStep (strDimension);
        allStep.setHierarchy (strHierarchy);

        // gek 12/04/01 Specify the levels to retrieve, with null retrieving all levels
        if ( (vLevels == null) || (vLevels.isEmpty()) ) {
            vLevels = (new Utils()).getAdjustedLevels(m_metadataManager, strHierarchy);
        }
        if (vLevels == null || vLevels.isEmpty())
        {
            // Still null?  Use the family step variant if hierarchy is non null
            if (strHierarchy != null)
            {
                allStep = new FamilyStep(strDimension, strHierarchy, FamilyStep.OP_FIRSTANCESTORS, null, false);
            }
        }
        else
        {
            allStep.setLevels (vLevels);
        }

        // Create our selection based on the AllStep
        Selection selection = new Selection (strDimension);
        selection.setHierarchy(strHierarchy);
        selection.addStep (allStep);

        // Update the global selection
        m_seedSelection = selection;

        // Update the selection
        m_queryAccessUtils.getQueryAccess().setSelection(selection);
        setDimensionName (selection.getDimension());*/
        }

    /**
     * Retrieve the metadata manager
     * @hidden
     */
    public MetadataManager getMetadataManager()
        {
        return m_metadataManager;
        }

    /**
     * Retrieve this model's dimension name
     * @hidden
     */
    public String getDimensionName()
        {
        return super.getDimensionName();
        }

    /**
     * Retrieve this model's hierarchy
     * @hidden
     */
    public String getHierarchy() {
        String strDimensionName = getDimensionName();
        // blm - Selection code moved to dvt-olap
/*        if ( (strDimensionName != null) && (strDimensionName.length() > 0) ) {
            Selection selection = m_queryAccessUtils.getQueryAccess().getSelection(strDimensionName);
            if (selection != null) {
                return selection.getHierarchy();
            }
        }*/
        return null;
    }

    /**
     * @hidden
     *
     * Retrieve this model's list of hierarchy level IDs.
     *
     * @return A <code>Vector</code> that represents the level IDs used by the
     *         model.
     */
    public Vector getLevels() {
      return m_vLevels;
    }

    /**
     * @hidden
     *
     * Specifies model's list of hierarchy level IDs.
     *
     * @param vLevels The <code>Vector</code> if hierarchy level IDs associated
     *                with this model.
     *
     */
    public void setLevels (Vector vLevels) {
      m_vLevels = vLevels;
    }

    /**
     * Retrieve this model's QueryAccessUtilities
     * @hidden
     */
    public QueryAccessUtilities getQueryAccessUtilities()
    {
      return m_queryAccessUtils;
    }
    
    /**
     * Retrieves the hierarchical state of the data.
     *
     * @return boolean  The current state of the hierarchial model.
     *                  <code>true</code> if data is hierarchical.
     *
     * @hidden
     */
    public boolean isHierarchical() {
        String strDimensionName = getDimensionName();
        // blm - Selection code moved to dvt-olap
/*        if ( (strDimensionName != null) && (strDimensionName.length() > 0) ) {
            Selection selection = m_queryAccessUtils.getQueryAccess().getSelection(strDimensionName);
            if (selection != null) {
                String hierarchy = selection.getHierarchy();
                if (hierarchy != null && !hierarchy.equals("")) {
                    return true;
                }
            }
        }*/
        return false;
    }

    /**
     * Specifies the dimensional data source by name.
     *
     * @param dimensionName The name of the dimension source within the
     *                      <code>DataDirector</code>.
     *
     * @hidden
     */
    public synchronized void setDimensionName(String strDimension)
        {
        super.setDimensionName(strDimension);

        setDataAccess(m_queryAccessUtils.getQueryAccess().getDataAccess(strDimension));
        }

    /**
     * Forces the model to refresh itself based on current selections.
     *
     * @status new
     */
    public void refresh()
        {
        if (getVerbose())
            System.out.println("QueryAccessDimensionModel.refreshDimensionList()");

        setDataAccess (m_queryAccessUtils.getQueryAccess().getDataAccess(getDimensionName()));

        long nowCount = (long) size();

        notifyListDataListeners (new ListDataEvent(this,
            ListDataEvent.CONTENTS_CHANGED, 0, (int) nowCount));

        m_beforeCount = nowCount;
        }

    /**
     *  Performs a 'drill' operation on a specific element in the data source.
     *
     *  @param  index   the data source index position.
     *  @param  delta   relative number of levels to traverse within the
     *                  hierarchy (positive numbers drill down, negative drill up)
     *                  This value is currently ignored.
     *  @return boolean <code>true</code> if successful, otherwise failure.
     *
     *  @status new
     */
    
    public boolean drill (int index, int delta)
        {
/*        // Defer to collapse all when appropriate
        if (index == 0 && delta < 0)
            {
            return collapseAll();
            }
        else
            {*/
            // Retrive the value at the specified position
            DimListDataItem dsItem = (DimListDataItem) elementAt (index);

            // Perform the actual drill on the selection manager
            boolean bResult =
                m_queryAccessUtils.getQueryAccess().drillList(getDimensionName(),
                    dsItem.getValue(), delta, true);

            // Update our dimension list if we are successful
            if (bResult)
                refresh();

            // Return drill result
            return bResult;
            //}
        }

    /**
     * Performs a collapse of all levels up to the highest level (0). All
     * children are hidden up to the root.
     *
     * @return boolean  A <code>true</code> if successful, otherwise failure.
     *
     * @status new
     */
    public boolean collapseAll()
        {
        if (getVerbose())
            System.out.println("DataDirectorDimensionModel.collapseAll()");

        // Perform the collapse all on the selection manager
        // blm - Selection code moved to dvt-olap
        String strHierarchy = /*(m_seedSelection != null) ? m_seedSelection.getHierarchy() : */null;
        boolean bResult = 
            m_queryAccessUtils.collapseAllList (this, getDimensionName(), 
                strHierarchy, true, m_metadataManager);

        // Update our dimension list if we are successful    
        if (bResult)
            refresh();

        // Return drill result
        return bResult;
        }

    /**
     * Performs a expand on all levels down to the lowest level. All
     * children are expanded.
     *
     * @return boolean  A <code>true</code> if successful, otherwise failure.
     *
     * @status new
     */
    public boolean expandAll()
        {
        if (getVerbose())
            System.out.println("DataDirectorDimensionModel.expandAll()");

        // Perform the collapse all on the selection manager
        // blm - Selection code moved to dvt-olap
        String strHierarchy = /*(m_seedSelection != null) ? m_seedSelection.getHierarchy() : */null;
        boolean bResult = 
            m_queryAccessUtils.expandAllList (this, getDimensionName(),
                strHierarchy, true, m_metadataManager);

        // Update our dimension list if we are successful    
        if (bResult)
            refresh();

        // Return drill result
        return bResult;
        }

    /**
     * @hidden
     */
    public void cleanUp()
        {
        m_queryAccessUtils.getQueryAccess().removeQueryAccessListener(this);

        // gek 12/05/01 Remove levels
        Vector vLevels = getLevels();
        if (vLevels != null) {
          vLevels.removeAllElements();
          setLevels(null);
        }

        }
    
    private void _applyDA(DataAccessChangedEvent dac)
        {
        String dimName = dac.getDimension();
        
        // We care about available selections that match our dimension
        if (getDimensionName().equals(dimName))
            {
            setDataAccess(dac.getDataAccess());
            int nowCount =  size();
            notifyListDataListeners (new ListDataEvent (this, ListDataEvent.CONTENTS_CHANGED, 
                0, (int) nowCount));
            m_beforeCount = nowCount;
            }
        }

    /**
     * @hidden
     */
    public void dimensionsChanged(DimensionsChangedEvent e) 
        {
        }
    
    // Cursor changed
    /**
     * @hidden
     */
    public void dataAccessChanged(DataAccessChangedEvent dac)
        {
        _applyDA(dac);
        }
    
    // Cursor for our selection may have changed
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public void selectionChanged(SelectionChangedEvent sce)
        {
        }*/
    }