/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui.panel.event;

import java.util.EventListener;
import java.util.EventObject;

/**
 * The listener interface for receiving panels events. Objects that implement 
 * this interface must register the <code>PanelEventListener</code> with the 
 * object that implements the <code>StandardPanel</code> interface.
 *
 * @status documented
 */

public interface PanelEventListener extends EventListener
{
    /**
     * Signals that a panel event occurred.
     *
     * @param event The <code>EventObject</code> that describes the event.
     *
     * @status documented
     */
    public void panelActionPerformed ( EventObject event );
}

    
