/*
 * AccessibleUtils.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.accessible;

import java.awt.Component;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.accessibility.AccessibleContext;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTree;
import javax.swing.SwingConstants;

import java.util.Hashtable;

import oracle.bali.share.nls.StringUtils;

/**
 *  Utility class for accessibility that contains methods that relate to the
 *  data beans.
 *  <p>Application developers should not use this class. It is for internal
 *  use only.</p> 
 *
 *  @see oracle.dss.datautil.gui.accessible.AccessibleLabel
 *  @see oracle.dss.datautil.gui.accessible.AccessiblePanel 
 *  @status documented
 */

public class AccessibleUtils {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Constuctors
  //
  /////////////////////

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   *  Specifies to prepend the accessibility name from the "from" component to 
   *  the accessibility name from the "to" component.
   *
   *  The "first time only" argument causes the accessibility name of the "to" 
   *  component to revert back to its original text after losing focus.
   *  Otherwise, it stays the same every time.
   *
   *  @param  componentFrom The "from" <code>Component</code> from which to retrieve the
   *          accessibility name to prepend in front of the "to" <code>Component</code>.
   *  @param  componentTo The "to" <code>Component</code> to which the
   *          accessibility name from the "from" <code>Component</code> is prepended.
   *  @param  blnFirstTimeOnly <code>true</code> if the accessibility name of 
   *          the "to" component reverts to its original text after losing focus,
   *          <code>false</code> otherwise.
   *
   *  @status documented
   */
  static public void setLabelFor(Component componentFrom, Component componentTo, boolean blnFirstTimeOnly) {
    if ( (componentFrom != null) && (componentTo != null) ) {
      final AccessibleContext contextFrom = componentFrom.getAccessibleContext();
      final AccessibleContext contextTo = componentTo.getAccessibleContext();
      if ( (contextFrom != null) && (contextTo != null) ) {
        final Component c = componentTo;
        if ( (blnFirstTimeOnly) && (c instanceof JComponent) ) {
          // Prepend an empty string in case the accessible name is null.
          String strAccessibleName = "" + contextTo.getAccessibleName();
          ((JComponent)c).putClientProperty("ORIGINAL_ACCESSIBLE_NAME", strAccessibleName);
        }
        // Prepend the "from" text to the "to" text.
        contextTo.setAccessibleName(contextFrom.getAccessibleName() + " " + contextTo.getAccessibleName());
        if ( (blnFirstTimeOnly) && (c instanceof JComponent) ) {
          c.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
              // Revert back to the original text.
              Object o = ((JComponent)c).getClientProperty("ORIGINAL_ACCESSIBLE_NAME");
              if (o != null) {
                String strOldAccessibleName = o.toString();
                if (!contextTo.getAccessibleName().equals(strOldAccessibleName)) {
                  contextTo.setAccessibleName(strOldAccessibleName);
                }
              }
            }
          });
        }
      }
    }
  }
    
  /**
   *  Specifies to associate a label with a combo box to simplify focus control.
   *
   *  When the combo box is editable, this method associates the label with
   *  the combo box's editor component instead of with the combo box itself.
   *
   *  @param  jLabel A <code>JLabel</code> value to associate with a combo box.
   *  @param  jComboBox A <code>JComboBox</code> value to associate with the 
   *          label.
   *
   *  @status documented
   */
  static public void setLabelFor (JLabel jLabel, JComboBox jComboBox) {
    if ((jLabel != null) && (jComboBox != null)) {
      // Associate this label with the combo box

      // If the combo box is editable, we must set the focus on the Editor
      // Component instead of the Combo box
      if (jComboBox.isEditable())
        jLabel.setLabelFor (jComboBox.getEditor().getEditorComponent());
      else
        jLabel.setLabelFor (jComboBox);
    }
  }

  /**
   *  Retrieves a <code>JButton</code> that is based on the specified text
   *  value that is processed for mnemonics.
   *
   *  @param  strText A <code>string</code> that represents the
   *          button's text that is processed for mnemonics.
   *  @return <code>JButton</code> that represents the newly constructed
   *          button.
   *  @status documented
   */
    static public JButton getButton (String strText) {
      JButton jButton = new JButton (strText);
      setLabelText (jButton, strText);
      return jButton;
    }

  /**
   *  Retrieves a <code>JRadioButton</code> that is based on the specified text
   *  value that is processed for mnemonics.
   *
   *  @param  strText A <code>string</code> that represents the
   *          button's text that is processed for mnemonics.
   *  @param  alignmentY A <code>float</code> that represents the button's
   *          Y alignment.
   *  @return <code>JRadioButton</code> that represents the newly constructed
   *          button.
   *  @status documented
   */
  static public JRadioButton getRadioButton (String strText, float alignmentY) {
    JRadioButton jRadioButton = new JRadioButton (strText);
    jRadioButton.setAlignmentY (alignmentY);
    jRadioButton.setMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jRadioButton.setText(StringUtils.stripMnemonic(strText));
    return jRadioButton;
  }

  /**
   *  Retrieves a <code>JLabel</code> that is based on the specified text
   *  value that is processed for mnemonics.
   *
   *  @param  strText A <code>string</code> that represents the
   *          label's text that is processed for mnemonics.
   *  @param  horizontalAlignmentY An <code>integer</code> that represents
   *          the label's horizontal alignment.
   *  @return <code>JLabel</code> that represents the newly constructed
   *          label.
   *  @status documented
   */
  static public JLabel getLabel (String strText, int horizontalAlignment) {
    JLabel jLabel = new JLabel (strText, horizontalAlignment);
    jLabel.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jLabel.setText(StringUtils.stripMnemonic(strText));
    return jLabel;
  }

  /**
   *  Retrieves a <code>JLabel</code> that is based on the specified text
   *  value that is processed for mnemonics. The alignment defaults to
   *  <code>SwingConstants.LEFT</code>.
   *
   *  @param  strText A <code>string</code> that represents the
   *          label's text that is processed for mnemonics.
   *  @return <code>JLabel</code> that represents the newly constructed
   *          label.
   *  @status documented
   */
  static public JLabel getLabel (String strText) {
    return getLabel (strText, SwingConstants.LEFT);
  }

  /**
   *  Specifies the text value that associated with the specified <code>JLabel</code>
   *  that is processed for mnemonics.
   *
   *  @param  jLabel A <code>JLabel</code> that represents the
   *          label to process.
   *  @param  strText A <code>string</code> that represents the
   *          label's text that is processed for mnemonics.
   *  @status documented
   */
  static public void setLabelText (JLabel jLabel, String strText) {
    jLabel.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jLabel.setText(StringUtils.stripMnemonic(strText));
  }

  /**
   *  Initializes the specified <code>JLabel</code> with text that is processed 
   *  for mnemonics and associates the label with the specified component.
   *
   *  @param  lblTarget A <code>JLabel</code> that represents the
   *          label to process.
   *  @param  strText A <code>string</code> that represents the
   *          label's text that is processed for mnemonics.
   *  @param compLabelFor the <code>Component</code> to assciate with the label.
   */
  public static void initializeLabel(JLabel lblTarget, String strText, Component compLabelFor) {
    lblTarget.setText(StringUtils.stripMnemonic(strText));
    lblTarget.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(strText));
    if (compLabelFor != null)
      lblTarget.setLabelFor(compLabelFor); 
  }

  /**
   *  Specifies the text value that associated with the specified <code>JLabel</code>
   *  that is processed for mnemonics.
   *
   *  @param  jButton A <code>JButton</code> that represents the
   *          button to process.
   *  @param  strText A <code>string</code> that represents the
   *          button's text that is processed for mnemonics.
   *  @status documented
   */
  static public void setLabelText (JButton jButton, String strText) {
    jButton.setMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jButton.setText(StringUtils.stripMnemonic(strText));
  }

  /**
   *  Specifies to change focus to the first selected row in the 
   *  <code>JTree</code>.
   *
   *  If no rows are selected, then it defaults to the first available row.
   *
   *  @param  jTree A <code>JTree</code> that represents the
   *          component whose focus you are trying to set.
   *  @param  focusEvent A <code>FocusEvent</code> that is used
   *          to determine if the focus is being set on the <code>JTree</code>.
   *
   *  @status documented
   */
  static public void setFocusToFirstSelectedRow (JTree jTree, FocusEvent focusEvent) {
    // Make sure our parameters are non-null
    if ((jTree != null) && (focusEvent != null)) {
      // Check to see if we are gaining focus
      if (focusEvent.getID() == FocusEvent.FOCUS_GAINED) {
        // Determine if any rows are currently selected
        int[] nRows = jTree.getSelectionRows();
        if (nRows != null) {
          // Go to the first selected row
          jTree.setSelectionRow (nRows[0]);
        }
        else {
          // Default to the first row
          jTree.setSelectionRow (0);
        }
      }
    }
  }
}