/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAResultTable.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/24/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/SBAResultTable.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.bi.client;

import oracle.dss.util.transform.ResultTable;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.total.AggSpec;

/**
 * @hidden
 * Instantiates SBADataTable
 */
public class SBAResultTable extends ResultTable
{
    protected SBAResultTable()
    {
        super();
    }
    
    public SBAResultTable(RowIteratorProjection projection) throws TransformException {
      this();
      m_projection = projection;
      
      m_dt = new SBADataTable(projection);
        projection.setDataTable((SBADataTable)m_dt);
    }

      public SBAResultTable(RowIteratorProjection projection, AggSpec[] aggs) throws TransformException {
        this();
        m_projection = projection;
        
        m_dt = new SBADataTable(projection, new AggSpec[][] {aggs});      
        projection.setDataTable((SBADataTable)m_dt);
      }    
}