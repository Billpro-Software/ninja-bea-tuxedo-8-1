/*
 * MMListener.java
 *
 * Listener for changes to metadata.
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.dataSource.common;

import oracle.dss.dataSource.common.QueryManagerInterface;
import oracle.dss.metadataManager.common.MetadataManagerAdapter;
import oracle.dss.metadataManager.common.MetadataManagerEvent;
import oracle.dss.util.ErrorHandler;

/**
 * @hidden
 * 
 * Listener for MetadataManager events
 */
public class MMListener extends MetadataManagerAdapter {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  private QueryManagerInterface m_queryManager = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////
        
  /**
   * Constructor.
   *
   * @param queryManager a <code>QueryManager</code> associated with the 
   *        <code>MMListener</code> that allows call backs in response to 
   *        <code>MetadataManager</code> events.
   *
   * @status New
   */
  public MMListener (QueryManagerInterface queryManager) {
    setQueryManager (queryManager);
  }    
    
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  //-----------------------------------------------------------------------
  // Start - Overridden MetadataManagerAdapter methods
  //-----------------------------------------------------------------------

  /**
   * Responds to the attaching of an analytic workspace.
   * This method is called after the workspace is attached.
   * 
   * @param metadataManagerEvent a <code>MetadataManagerEvent</code> that contains
   *        information about the attach operation.
   *
   * @status New
   */
  public void attached (MetadataManagerEvent metadataManagerEvent) {
    try {
      if (getQueryManager() != null) {
        getQueryManager().informQueriesOfMetadataManager (true);
      }
    }

    catch (Exception exception) {
      throw new QueryRuntimeException (exception.getMessage(), exception);
    }
  }
   
  /**
   * Responds to the detaching of an analytic workspace.
   * This method is called after the workspace is detached.
   *
   * @param metadataManagerEvent a <code>MetadataManagerEvent</code> that contains
   *        information about the attach operation.
   *
   * @status New
   */
  public void detached (MetadataManagerEvent metadataManagerEvent) {
    try {
      if (getQueryManager() != null) {
        getQueryManager().informQueriesOfMetadataManager (false);
      }
    }

    catch (Exception exception) {
      throw new QueryRuntimeException (exception.getMessage(), exception);
    }
  }
  
  /**
   * Responds to a change in the metadata.
   * 
   * This method is called after metadata has been modified.
   *
   * @param metadataManagerEvent a <code>MetadataManagerEvent</code> that contains
   *        information about the metadata modified operation.
   *
   * @status New
   */
  public void metadataModified (MetadataManagerEvent metadataManagerEvent) {
  }

  /**
   * Responds to the refreshing of the metadata cache.
   *
   * This method is called after metadata has been refreshed from the server
   * to the middle-tier cache, the client-tier cache, or both.
   * 
   * Normally, this method should repaint any user interface that displays
   * representations of metadata objects.
   *
   * @param metadataManagerEvent a <code>MetadataManagerEvent</code> that contains
   *        information about the metadata modified operation.
   *
   * @status New
   */
  public void metadataRefresh (MetadataManagerEvent metadataManagerEvent) {
    // Make sure that we have an non-null event
    if (metadataManagerEvent != null) {

      // Delete the Analytic Workspace object associated with the 
      // MetadataManagerEvent, if any.
      try {
        //deleteAW (metadataManagerEvent);    
      }

      // Ignore and generated exceptions
      catch (Exception exception) {
        // Retrieve the QueryManager
        QueryManagerInterface queryManager = getQueryManager();

        if (queryManager != null) {
          // Attempt to retrieve an ErrorHandler
          ErrorHandler errorHandler = queryManager.getErrorHandler();

          if (errorHandler != null) {
            // Let the ErrorHandler know about the exception
            errorHandler.error (exception, getClass().getName(), "metadataModified");
          }
        }
      }
    }
  }

  //-----------------------------------------------------------------------
  // End - Overridden MetadataManagerAdapter methods
  //-----------------------------------------------------------------------

  /**
   * Retrieves the <code>QueryManager</code> associated with the <code>MMListener</code>.
   *
   * @return <code>QueryManager</code> associated with the <code>MMListener</code>.
   */
  public QueryManagerInterface getQueryManager () {
    return m_queryManager;
  }

  /**
   * Specifies the <code>QueryManager</code> associated with the <code>MMListener</code>.
   *
   * @param queryManager a <code>QueryManager</code> to associate with the <code>MMListener</code>.
   */
  public void setQueryManager (QueryManagerInterface queryManager) {
    m_queryManager = queryManager;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Deletes the Analytic Workspace object associated with the 
   * <code>MetadataManagerEvent</code>, if any.
   * 
   * @param metadataManagerEvent a <code>MetadataManagerEvent</code> that contains
   *        information about the metadata modified operation.
   *
   * @throws <code>IOException</code>, <code>MetadataManagerException</code> or
   *         <code>SQLException</code> if Analytic Workspace object could not be
   *         deleted.
   * 
   * @status New
   */
/*  protected void deleteAW (MetadataManagerEvent metadataManagerEvent) 
                    throws IOException, MetadataManagerException, SQLException {

    // Make sure that we have an non-null event
    if (metadataManagerEvent != null) {
    
      // Determine if this is a MetadataModifiedEvent 
      if (metadataManagerEvent instanceof MetadataModifiedEvent) {
        MetadataModifiedEvent metadataModifiedEvent = 
          (MetadataModifiedEvent) metadataManagerEvent;

        // Check to see if we are deleting a MetadataManager object
        if (metadataModifiedEvent.getModOperation() == MetadataModifiedEvent.REMOVE) {
          // Check to see if this is a calculated Dimension Member
          Object object = metadataModifiedEvent.getObject();
          
          if (object != null) {
            // Determine if this is a calculated dimension member
            if (object instanceof MDDimensionCalc) {
              MDDimensionCalc mdDimensionCalc = (MDDimensionCalc) object;  

              // Retrieve the Analytic Workspace ID associated with the MDDimensionCalc
              String strAWID = mdDimensionCalc.getAWObjectName();

              if (strAWID != null) {
                // Retrieve OlapDmlUtil which allows us to execute
                // OLAP DML command
                OlapDmlUtil olapDmlUtil = null; //getOlapDmlUtil();
                // CAN'T DO THIS MULTI TIER ANYMORE
                if (olapDmlUtil != null) {

                  // Retrieve the CalcStep dimension associated with the MDDimensionCalc
                  String strDimension = olapDmlUtil.getDimension (mdDimensionCalc); 

                  // Generate the OLAP DML command required to delete the calculation
                  String strOlapCommand = 
                    olapDmlUtil.getOlapDmlDelete (strDimension, strAWID);

                  // Execute the OLAP DML command to remove the Analytic Workspace
                  // object
                  olapDmlUtil.executeCommand (strOlapCommand);
                }
              }
            }
          }
        }
      }
    }
  }*/

  /**
   * Retrieves a <code>String</code> representing the OLAP DML command required 
   * to delete an object from the AnalyticWorkspace.
   *
   * @param strDimension a <code>String</code> value that represents the Analytic
   *        Workspace dimension of the object to delete.
   * @param strAWid a <code>String</code> value that represents the Analytic
   *        Workspace ID of the object to delete.
   *
   * @return <code>String</code> which represents the OLAP DML command.
   *
   * @status New
   */
/*  protected OlapDmlUtil getOlapDmlUtil () {
    OlapDmlUtil olapDmlUtil = null;

    MetadataManagerServices metadataManagerServices = 
      getMetadataManagerServices();
      
    if (metadataManagerServices != null) {
      olapDmlUtil = new OlapDmlUtil (metadataManagerServices);              
    }

    return olapDmlUtil;
  }*/

  /**
   * Retrieves a <code>MetadataManagerServices</code> from the <code>QueryManager</code>.
   *
   * @return <code>MetadataManagerServices</code> object or null.
   *
   * @status New
   */
/*  protected MetadataManagerServices getMetadataManagerServices() {
    MetadataManagerServices metadataManagerServices = null;

    QueryManager queryManager = getQueryManager();
    if (queryManager != null) {
        metadataManagerServices = queryManager.getMetadataManagerServices();
    }

    return metadataManagerServices;
  }*/

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
}