/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if an operation requires a database to be set on the
 * <code>QueryManager</code> but no database is specified.
 *
 * @status Documented
 */
public class NoDatabaseException extends QueryRuntimeException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public NoDatabaseException(String s, Throwable e)
    {
        super(s, e);
    }
}