/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Base class for cell submit events.
 * These events are related to the submission to the database of the QDR
 * overrides in the writeback collection. Each QDR override represents a cell
 * that has been edited.
 *
 * @status Documented
 */
public abstract class CellsSubmitEvent extends QueryEvent
{

/**
 * Constructor.
 *
 * @param  source                The source of the event, that is, the object
 *                               that fired the event.
 * @param  qdrOverrideCollection A writeback collection that contains a QDR
 *                               override for each cell that was edited.
 *
 * @status Documented
 */
    public CellsSubmitEvent(Object source, java.util.List qdrOverrideCollection ) {
        super(source);
        m_qdrOverrideCollection = qdrOverrideCollection;
    }


/**
 * Retrieves a list of the QDR overrides in the writeback collection.
 *
 * @status Documented
 */
    public java.util.List getQDROverrides()
    {
        return m_qdrOverrideCollection;
    }



    /**
     * @hidden
     */
    protected java.util.List m_qdrOverrideCollection;
}