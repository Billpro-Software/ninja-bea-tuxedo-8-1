/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.util.BIBaseException;

/**
 * Methods that QueryBuilder and CalcBuilder beans require from a Query bean to
 * get <code>QueryAccess</code> objects for use during a QueryBuilder or
 * CalcBuilder session. For example, the <code>QueryAccess</code> object lets
 * the QueryBuilder bean work with available selections and selected selections.
 * Eventually the changes that are made in the selected selections of the
 * <code>QueryAccess</code> object are applied to the original
 * <code>Query</code> object.
 *
 * @status Documented
 */
public interface QueryContext
{    
    /**
     * Creates and returns an object that implements the
     * <code>QueryEditor</code> interface. This <code>QueryEditor</code> object
     * can make use of the QueryContext implementor (such as a
     * <code>Query</code> object) for Selection state and Selection evaluation
     * services.
     *
     * @return An object that implements the <code>QueryEditor</code> interface.
     *
     * @status New
     */
    public QueryEditor createQueryEditor();

    /**
     * Updates the implementing <code>Query</code> object with the changed
     * selection information in the specified <code>QueryAccess</code> object.
     *
     * @param qa     The <code>QueryAccess</code> object that contains the
     *               state changes (selections) to apply to the QueryContext
     *               implementor, assuming that it has been initialized.
     * @param update <code>true</code> if the <code>QueryAccess</code> object
     *               is finished with the QueryContext and the implementor may
     *               run a query based on the new state, if desired;
     *               <code>false</code> if the <code>QueryAccess</code> object
     *               is not finished with the QueryContext.
     *
     * @return <code>true</code> if the update is successful;
     *                           <code>false</code> if the update is not
     *                           successful.
     * @deprecated As of 4.0.0.0, replaced by {@link #applyQueryEditor()}
     *
     * @status Documented
     */
    public boolean applyQueryAccess(QueryAccess qa, boolean update);    
    
    /**
     * Updates the implementing <code>Query</code> object with the changed
     * selection and/or layout information in the specified <code>QueryEditor</code> object.
     *
     * @param qa     The <code>QueryEditor</code> object that contains the
     *               state changes to apply to the QueryContext
     *               implementor, assuming that it has been initialized.
     * @param update <code>true</code> if the <code>QueryEditor</code> object
     *               is finished with the QueryContext and the implementor may
     *               run a query based on the new state, if desired;
     *               <code>false</code> if the <code>QueryEditor</code> object
     *               is not finished with the QueryContext.
     *
     * @return <code>true</code> if the update is successful;
     *                           <code>false</code> if the update is not
     *                           successful.
     *                           
     * @throws BIBaseException if an error occurs
     *
     * @status New
     */
    public boolean applyQueryEditor(QueryEditor qe, boolean update) throws BIBaseException;       
    
    /**
     * Returns the current implementer's MetadataManager instance.
     * 
     * @return current MetadataManager instance.
     * 
     * @status New
     */
    public MetadataManagerServices getMetadataManager();
}
