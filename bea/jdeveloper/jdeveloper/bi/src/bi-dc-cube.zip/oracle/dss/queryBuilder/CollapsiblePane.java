/*
 * CollapsiblePanel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class CollapsiblePane extends JPanel {

    /*
     * Public
     */
     
    public CollapsiblePane() {
        super();
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        //setLayout(new VerticalLayout(5));
    }
    
    public void setResizable(boolean blnResizable) {
        m_blnResizable = blnResizable;
        if (m_blnResizable) {
            addSplitters();
        }
        else {
            removeSplitters();
        }
    }
    
    public boolean isResizable() {
        return m_blnResizable;
    }

    public Component add(String strTitle, Component component, boolean blnExpanded) {
        SelectionHeader header = new SelectionHeader(strTitle, component);
        header.setContentVisible(blnExpanded);
        add(header);
        if (m_blnResizable) {
            addSplitters();
        }
        return null;
    }
     
    public Component add(String strTitle, Component component) {
        return add(strTitle, component, true);
    }
    
    public Component add(String title, Component component, int index) { return null; }
    public void remove(int index) {}
    public Component getComponentAt(int index) {return null; }
    public void setSelectedComponent(Component c) {}
    public Component getSelectedComponent() { return null; }
    public void setCollapsed(boolean collapsed, int index) {}
    public boolean isCollapsed(int index) { return false; }
    public void setIconPosition(int position) {}
    public void setIcon(Icon icon) {}
    
    /*
     * Private
     */
     
    private boolean m_blnResizable = true;
     
    private SelectionHeader[] getSelectionHeaders() {
        Vector v = getSelectionHeaders(this, null);
        if (v.size() > 0) {
            SelectionHeader[] headers = new SelectionHeader[v.size()];
            v.copyInto(headers);
            return headers;
        }
        return null;
    }

    private Vector getSelectionHeaders(Container container, Vector v) {
        if (container != null) {
            if (v == null) {
                v = new Vector();
            }
            if (container instanceof SelectionHeader) {
                v.add((SelectionHeader)container);
            }
            else {
                Component[] components = container.getComponents();    
                if (components != null) {
                    for (int i=0; i<components.length; i++) {
                        if (components[i] instanceof Container) {
                            getSelectionHeaders((Container)components[i], v);
                        }
                    }
                }
            }
        }
        return v;
    }
    
    private void addSplitters() {
        SelectionHeader[] headers = getSelectionHeaders();
        removeAll();
        if ( (headers != null) && (headers.length > 0) ) {
            if (headers.length == 1) {
                add(headers[0]);
            }
            else {
                CustomSplitPane splitPane = new CustomSplitPane(CustomSplitPane.VERTICAL_SPLIT, headers[0], headers[1]);
                if (headers.length > 2) {
                    for (int i=2; i<headers.length; i++) {
                        splitPane = new CustomSplitPane(CustomSplitPane.VERTICAL_SPLIT, splitPane, headers[i]);
                        splitPane.setDividerLocation(1.0/headers.length);
                    }
                }
                add(splitPane);
            }
        }
    }
    
    private void removeSplitters() {
        SelectionHeader[] headers = getSelectionHeaders();
        removeAll();
        if ( (headers != null) && (headers.length > 0) ) {
            for (int i=0; i<headers.length; i++) {
                add(headers[i]);
            }
        }
    }
    
    private class CustomSplitPane extends JSplitPane {
    
        /*
         * Public
         */
    
        public CustomSplitPane()  {
            super();
            init();
        }
        
        public CustomSplitPane(int newOrientation) {
            super(newOrientation);
            init();
        }
         
        public CustomSplitPane(int newOrientation, boolean newContinuousLayout) {
            super(newOrientation, newContinuousLayout);
            init();
        }
        
        public CustomSplitPane(int newOrientation, boolean newContinuousLayout, Component newLeftComponent, Component newRightComponent) {
            super(newOrientation, newContinuousLayout, newLeftComponent, newRightComponent);
            init();
        } 
        public CustomSplitPane(int newOrientation, Component newLeftComponent, Component newRightComponent) {
            super(newOrientation, newLeftComponent, newRightComponent);
            init();
        }
        
        /*
         * Private
         */
         
        private int m_intWidth = -1;
         
        private void init() {
            addComponentListener(new ComponentAdapter() {
                public void componentResized(ComponentEvent e) {     
                    int intNewWidth = getWidth();
                    if ( (m_intWidth == -1) || ((m_intWidth != -1) && (m_intWidth != intNewWidth)) ) {
                        setDividerLocation(.5);
                    }
                    m_intWidth = intNewWidth;
                }
            }); 
        }
    }
}