/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.NameClassPair;

/**
 * @hidden
 * The BINameClassPair class is an extension to the JNDI NameClassPair class, with an
 * additional field for retrieving and setting the object type
 *
 * @see javax.naming.NameClassPair
 * @status New
 */
public class BINameClassPair extends NameClassPair
{
    private final String m_type;

    public BINameClassPair(String name, String className, String type)
    {
        super(name, className);
        m_type = type;
    }

   

    public String getObjectType()
    {
        return m_type;
    }

    
}