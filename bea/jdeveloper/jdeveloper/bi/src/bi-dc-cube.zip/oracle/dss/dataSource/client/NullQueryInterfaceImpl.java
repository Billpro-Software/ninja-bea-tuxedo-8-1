/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.client;

import java.util.List;
import java.util.BitSet;

import oracle.dss.dataSource.common.Delegate;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.RecoveryInfo;
import oracle.dss.datautil.QueryEditor;

import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;

import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;

import oracle.dss.util.BIBaseException;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.StatusInfo;
import oracle.dss.util.transform.BaseProjection;

/**
 * @hidden
 * 
 * Empty query implementation of pluggable interface 
 * 
 * @status New
 */
public class NullQueryInterfaceImpl extends Object implements QueryInterface
{    
    public NullQueryInterfaceImpl(Query query)
    {
        super();
    }
    
    // javadoc from interface
    public BitSet addItems(String[] dataItems, String[] items) throws QueryException
    {        
        return null;
    }
    
    // javadoc from interface
    public void applyDataMap(DataMap map) throws QueryException
    {        
    }
    
    // javadoc from interface
    public void applyMetadataMap(String item, MetadataMap map) throws QueryException
    {
    }

    // javadoc from interface
    public void applyMetadataMap(int edge, MetadataMap map) throws QueryException
    {
    }
    
    // javadoc from interface
    public boolean applyQueryEditor(QueryEditor qe, boolean update) throws BIBaseException
    {        
        return false;
    }
    
    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public BitSet applySelections(Selection[] selections) throws QueryException
    {        
        return null;
    }*/
    
    // javadoc from interface
    public void cancel() throws QueryException
    {
    }
    
    // javadoc from interface
    public Object clone() throws CloneNotSupportedException
    {        
        return null;
    }

    // javadoc from interface
    public Delegate createCubeDataDirector()
    {    
        return null;
    }

    // javadoc from interface
    public Delegate createRelationalDataDirector()
    {    
        return null;
    }
    
    // javadoc from interface
    public DataDirector getDataDirector(DataAccess da)
    {
        return null;
    }
    
    // javadoc from interface
    public void drill(String dimension, String[] target, String[] hierarchy, Integer[] delta, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {    
    }

    // javadoc from interface
    public void drill(String dimension, String[] target, String[] hierarchy, String[] level, Boolean[] above, String[] valueParent, String[] queryAncestor, Integer[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {    
    }
    
    // javadoc from interface
    public void drill(String item, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException
    {    
    }
    
    // javadoc from interface
    public void drill(String item, int onEdge, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException
    {    
    }
    
     // javadoc from interface
     public String[][] getDefaultLayout(String[] dataItems, String[] items) throws QueryException
     {
         return null;
     }
     
     // javadoc from interface
     public Object getQueryObject()
     {
         return null;
     }
     
    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String dimension) throws QueryException
    {    
        return null;
    }*/
    
    // javadoc from interface
    public BaseProjection getProjection(String layerMetadataType) throws QueryException
    {
        return null;
    }
    
    // javadoc from interface
    public DataAccess[] generateDataAccess(DataDirector[] dd, int changeType) throws QueryException
    {    
        return null;
    }

    // javadoc from interface
    public String getQuerySQL(int edge) throws QueryException    
    {    
        return null;
    }
    
    // javadoc from interface
    public void setCalcDefinitions(Object[] definitions) throws QueryException
    {    
    }

    // javadoc from interface
    public Object[] getCalcDefinitions()
    {    
        return null;
    }

    // javadoc from interface
    public Boolean isDependentOn(MDObject object)
    {    
        return new Boolean(false);
    }

    // javadoc from interface
    public Object isSupported(int capability, Object data) throws QueryException
    {    
        return null;    
    }

    // javadoc from interface
    public BitSet layout(String[][] items) throws QueryException, MetadataManagerException
    {    
        return null;
    }

    // javadoc from interface
    public boolean loadQuery() throws QueryException
    {    
        return false;
    }
    
    // javadoc from interface
   public BitSet pivot(String source, String target, int flags) throws QueryException
    {    
        return null;
    }

    // javadoc from interface
    public int swapCheck(String source, String target) throws QueryException
    {
        return DataDirector.PIVOT_CHECK_UNKNOWN;        
    }
   
    // javadoc from interface
    public int pivotCheck(String source, String target, int flags) throws QueryException
    {    
        return DataDirector.PIVOT_CHECK_UNKNOWN;
    }

    // javadoc from interface
   public BitSet swap(String source, String target) throws QueryException
    {    
        return null;
    }

    // javadoc from interface
   public boolean swapOK(String source, String target) throws QueryException
    {    
        return false;
    }

    // javadoc from interface
   public void swapEdges(int source, int target)  throws QueryException
    {    
    }
    
    // javadoc from interface
    public RecoveryInfo recover(boolean fix, boolean nodata, Object specification) throws QueryException    
    {    
        return null;
    }
    
    // javadoc from interface
    public void refresh(int type) throws QueryException
    {    
    }
    
    // javadoc from interface
    public void release() throws QueryException
    {    
    }
    
    // javadoc from interface
    public BitSet removeItems(String[] items) throws QueryException
    {    
        return null;
    }

    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public BitSet removeSelection(Selection selection) throws QueryException
    {    
        return null;
    }*/

    // javadoc from interface
    public boolean rollback() throws QueryException
    {    
        return false;
    }
    
    // javadoc from interface
    public BitSet setDataFilters(BaseDataFilter[] filters) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public BitSet setColumnSorts(ColumnSortWrapper[] sorts) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public BitSet setItemSorts(ItemSortWrapper[] sorts) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public BitSet setItems(String[] dataItems, String[] items, String[][] layout) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public void setDataMap(DataMap map) throws QueryException
    {    
    }

    // javadoc from interface
    public void setMetadataMap(String dimension, MetadataMap map) throws QueryException
    {    
    }

    // javadoc from interface
    public boolean submit(List list) throws QueryException
    {    
        return false;
    }
    
    // javadoc from interface
    public void update() throws Exception    
    {    
    }
    
    // javadoc from interface
/*    public ValidationObject validate(int validationType, Object object) throws QueryException
    {    
        return null;
    }*/
    
    // javadoc from interface
    public StatusInfo getStatus(boolean startExecution) throws QueryException
    {    
        return null;
    }
    
    // javadoc from interface
    public void setCurrentPage(long page, QDR qdrPage) throws QueryException
    {       
    }    
    
    // javadoc from interface
    public boolean isDataAvailable()
    {
        return false;
    }
    
    // javadoc from interface
    public void setProperty(String property, Object value) throws QueryException
    {
    }
}
