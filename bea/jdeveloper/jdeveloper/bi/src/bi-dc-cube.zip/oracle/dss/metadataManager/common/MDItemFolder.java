/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

public class MDItemFolder extends MDObject
{
    public MDItemFolder()
    {
        setObjectType(MM.ITEMFOLDER);
    }
    
    public MDItem[] getItems() throws MetadataManagerException
    {
        MDObject[] _mdObjs = getChildren(MM.ITEM);
        
        if(_mdObjs != null && _mdObjs.length > 0)
        {
            MDItem[] _items = new MDItem[_mdObjs.length];
            for(int i=0; i<_mdObjs.length; i++)
                _items[i] = (MDItem)_mdObjs[i];
                
            return _items;
        }
        return null;
    }

    public MDItemFolder[] getItemFolders() throws MetadataManagerException
    {
        MDObject[] _mdObjs = getChildren(MM.ITEMFOLDER);
        
        if(_mdObjs != null && _mdObjs.length > 0)
        {
            MDItemFolder[] _itemFlds = new MDItemFolder[_mdObjs.length];
            for(int i=0; i<_mdObjs.length; i++)
                _itemFlds[i] = (MDItemFolder)_mdObjs[i];
                
            return _itemFlds;
        }
        return null;
    }

    public MDItemFolder[] getJoinableItemFolders(MDFolder folder, boolean searchSubContext)
    {
        MDItemFolder[] _itemFolders = null;
        if(getMetadataManagerServices() != null)
            _itemFolders = getMetadataManagerServices().getJoinableItemFolders(folder, this, searchSubContext);
        return _itemFolders;
    }
}
