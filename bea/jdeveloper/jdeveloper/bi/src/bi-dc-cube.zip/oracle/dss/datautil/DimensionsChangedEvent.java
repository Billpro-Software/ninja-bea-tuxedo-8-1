/**
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil;

import java.util.EventObject;
import java.util.Vector;

/**
 * Describes the event that carries dimension information to
 * <code>QueryAccess</code> clients.
 *
 * @status Documented
 */
public class DimensionsChangedEvent extends java.util.EventObject implements java.io.Serializable
{
    /**
     * Constructs the event.
     *
     * @param source  The <code>QueryAccess</code> object that fired this event.
     * @param dimlist The changed list of dimensions.
     *
     * @status Documented
     */
    public DimensionsChangedEvent(Object source, Vector dimlist) {
        super(source);
        
        m_dimList = (Vector)dimlist.clone();
    }
    
    /**
     * Retrieves the changed list of dimensions.
     * 
     * @return The changed dimension list vector.
     *
     * @status Documented
     */
    public Vector getDimensionList() {
        return m_dimList;
    }
    /**
     * @hidden
     * @serial
     * @status hidden
     */
    protected Vector m_dimList = null;
}