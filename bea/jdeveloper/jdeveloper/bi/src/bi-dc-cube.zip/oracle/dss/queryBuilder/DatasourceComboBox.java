/*
 * DatasourceComboBox.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.queryBuilder;

import javax.swing.JComboBox;

import oracle.dss.datautil.gui.component.ComponentContext;

public class DatasourceComboBox extends JComboBox {
    
    /*
     * Public
     */
     
    public DatasourceComboBox(ComponentContext context) {
        //super(getDatasources(bc));
        super();
        //setModel(new DefaultComboBoxModel(getDatasources(bc)));
        setModel(new DatasourceComboBoxModel(context));
        
        /*
        addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                Utils.setParentWindowCursor(this, Cursor.WAIT_CURSOR);    
                if ( (e != null) && (e.getStateChange() == ItemEvent.SELECTED) ) {
                    refresh(e.getItem());
                }
                Utils.setParentWindowCursor(this, Cursor.DEFAULT_CURSOR);
            }
        });
        */
    }
    
    /*
     * Private
     */

    /*
    private Vector getDatasources(BuilderContext bc) {    
        Vector datasources = new Vector();
        if (bc != null) {
            MetadataManager mm = bc.getMetadataManager();
            if (mm != null) {
                try {
                    NamingEnumeration ne = mm.getDatasources();
                    if (ne != null) {
                        BISearchResult sr;
                        Object o;
                        while(ne.hasMoreElements()) {
                            o = ne.next();
                            if ( (o != null) && (o instanceof BISearchResult) ) {
                                //sr = (BISearchResult)o;
                                //datasources.addElement(sr);
                                datasources.addElement((BISearchResult)o);
                            }
                        }
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return datasources;
    }
    */
        
        /*
    private Vector getDatasources(BuilderContext bc) {
        Vector datasources = new Vector();
        if (bc != null) {
            MetadataManager mm = bc.getMetadataManager();
            if (mm != null) {
                try {
                    NamingEnumeration ne = mm.getDatasources();
                    if (ne != null) {
                        BISearchResult sr;
                        Object o;
                        while(ne.hasMoreElements()) {
                            o = ne.next();
                            if ( (o != null) && (o instanceof BISearchResult) ) {
                                //sr = (BISearchResult)o;
                                //datasources.addElement(sr);
                                datasources.addElement((BISearchResult)o);
                            }
                        }
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return datasources;
    }
    */
}
    