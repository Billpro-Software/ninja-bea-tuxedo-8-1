/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * @hidden
 * Marker interface for events that should be merged with other similar events.
 */
public interface MergeEvent
{
    /**
     * @hidden
     * Merge another event into this one
     *
     * @param event change event to merge
     */
    public void merge(MergeEvent event);
}
