/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.common;

    
/**
 * @hidden
 * Cache key class for hPos
 */
public class hPosKey extends Object
{
    protected long[] m_hPos = null;

    public hPosKey()
    {
        super();
    }

    public hPosKey(long[] hPos, int layer)
    {
        this();
        m_hPos = new long[layer];
        for (int i = 0; i < m_hPos.length; i++)
        {
            m_hPos[i] = hPos[i];
        }
    }

    private boolean _compareArrays(long[] arr1, long[] arr2)
    {
        if (arr1 == null && arr2 == null)
            return true;

        if (arr1 == null || arr2 == null)
            return false;

        if (arr1.length != arr2.length)
            return false;

        for (int i = 0; i < arr1.length; i++)
        {
            if (arr1[i] != arr2[i])
                return false;
        }
        return true;
    }

    public boolean equals(Object key)
    {
        if (key instanceof hPosKey)
        {
            hPosKey ck = (hPosKey)key;
            return _compareArrays(m_hPos, ck.m_hPos);
        }
        return false;
    }

    public int hashCode()
    {
        int hPosCode = 0;
        for (int i = 0; i < m_hPos.length; i++)
        {
            hPosCode += ((m_hPos.length-i)*(int)m_hPos[i]);
        }
        return hPosCode;
    }
    
    public String toString()
    {
        String retVal = "[";
        for (int i = 0; i < m_hPos.length-1; i++)
            retVal += m_hPos[i] + ",";
        if (m_hPos.length-1 >= 0)
            retVal += m_hPos[m_hPos.length-1] + "]";
        else
            retVal += "]";
        return retVal;
    }
}                
