/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

import java.util.Locale;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

/**
 * Indicates that the user does not have a high enough level of privilege
 * to perform the requested operation.
 *
 * @status Reviewed
 */
public class InsufficientPrivilegeException extends MetadataManagerException
{
    /**
     * @hidden
     * Constructor.
     *
     * @param driverType The type of driver that initiates this exception.
     *
     * @status hidden
     */
    public InsufficientPrivilegeException(String driverType)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, driverType, null);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public InsufficientPrivilegeException(String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, driverType, prevException);
    }

    /**
     * @hidden
     * Constructor for an exception that passes on a previous exception.
     *
     * @param locale The locale to use in the message.
     * @param driverType The type of driver that initiates this exception.
     * @param prevException The exception that underlies this exception.
     *
     * @status hidden
     */
    public InsufficientPrivilegeException(Locale locale, String driverType, Throwable prevException)
    {
        super(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_NO_PERMISSION, null, locale, driverType, prevException);
    }
}
