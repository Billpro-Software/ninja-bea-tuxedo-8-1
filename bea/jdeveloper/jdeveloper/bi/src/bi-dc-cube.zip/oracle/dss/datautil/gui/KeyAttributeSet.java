/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.util.Vector;

import javax.swing.text.AttributeSet;

import oracle.dss.datautil.KeyAttributeSetHashtableImpl;

/**
 * @hidden
 * Methods that are used to set atttributes for specified values.
 *
 * @status hidden
 */

public interface KeyAttributeSet 
{
    //-------------------------------------------------------------------------
    // PUBLIC CONSTANTS
    //-------------------------------------------------------------------------

    /**
     * Action that adds one or more attributes to a key object.
     *
     * @status hidden
     */
    public static final int KEYATTRIBUTESET_ATTRIBADD =
                            KeyAttributeSetHashtableImpl.KEYATTRIBUTESET_ATTRIBADD;
    
    /**
     * Action that removes one or more attributes from a key object.
     *
     * @status hidden
     */
    public static final int KEYATTRIBUTESET_ATTRIBREMOVE =
                            KeyAttributeSetHashtableImpl.KEYATTRIBUTESET_ATTRIBREMOVE;
    
    /**
     * Action that modifies one or more existing attributes of a key object.
     *
     * @status hidden
     */
    public static final int KEYATTRIBUTESET_ATTRIBSET =
                            KeyAttributeSetHashtableImpl.KEYATTRIBUTESET_ATTRIBSET;
    
    /**
     * The character delimiting key value pairs. The character :
     *
     * @status hidden
     */
    public static final String KEYATTRIBUTESET_PAIRDELIMITER = 
                               KeyAttributeSetHashtableImpl.KEYATTRIBUTESET_PAIRDELIMITER;
    
    /**
     * The character separating key value pairs. The character #
     *
     * @status hidden
     */
    public static final String KEYATTRIBUTESET_PAIRSEPARATOR = 
                               KeyAttributeSetHashtableImpl.KEYATTRIBUTESET_PAIRSEPARATOR;
    
    //-------------------------------------------------------------------------
    // INTERFACE METHODS
    //-------------------------------------------------------------------------
    
    /**
     * @hidden
     * Retrieves the list of key objects that contain the specified attribute name
     * and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     *
     * @return The list of key objects
     *
     * @status hidden
     */
    public Vector getAttributeNameList ( Object attribFind, Object attribValue );
    
    /**
     * @hidden
     * Retrieves the attributes of the specified key object
     * The attributes of key that have null names cannot be retrieved.
     *
     * @param key  The name of the key.
     *
     * @return The <code>MutableAttributeSet</code> object.
     *                   
     * @status hidden
     */
    public AttributeSet getKeyAttributes ( String key );

    /**
     * @hidden
     * Retrieves the value of an attribute for the specified key object
     *
     * @param key The name of the key.
     * @param attribute The attribute for the specified key.
     *
     * @return The value for the specified attribute.
     *                   
     * @status hidden
     */
    public Object getKeyAttributeValue ( String key, Object attribute );

    /**
     * @hidden
     * Retrieves the immutable list of key objects.
     *
     * @return The <code>AttributeSet</code> object.
     *                   
     * @status hidden
     */
    public AttributeSet getKeyList ( );

    /**
     * @hidden
     * Adds, modifies, or removes an attribute for any key object that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *                   
     * @status hidden
     */
    public boolean updateAttribute ( Object attribFind, Object attribValue, 
                                     Object name, Object value, int actionType );

    /**
     * @hidden
     * Adds, modifies, or removes a set of attributes for any key that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param attribSet The <code>AttributeSet</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateAttributeSet ( Object attribFind, Object attribValue, 
                                        AttributeSet attribSet, int actionType );
                                     
    /**
     * @hidden
     * Adds, modifies, or removes an attribute for a specified key.
     *
     * @param key The name of the key.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateKeyAttribute ( String key, Object name, 
                                        Object value, int actionType );

    /**
     * @hidden
     * Adds, modifies, or removes a set of attributes for a specified key. 
     *
     * @param key The name of the key.
     * @param attribSet The <code>AttributeSet</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateKeyAttributeSet ( String key, AttributeSet attribs, int actionType );
}