/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports

import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;

/**
 * A client-side representation of an attribute in an analytic workspace.
 * An <code>MDAttribute</code> provides, to a java client, information about
 * an attribute in the workspace.
 * <P>
 * An attribute is a characteristic of a dimension.
 * For example, a Product dimension might have a Color attribute.
 * This would allow a search for blue products, for example.
 *
 * @status Reviewed
 */
public class MDAttribute extends MDObject {

    /**
     * Constructor.
     * Application developers should never construct an <code>MDAttribute</code>.
     * Attributes are actually defined in the analytic workspace on the
     * server.
     * You cannot use the MetadataManager to create attributes in the
     * workspace.
     * <P>
     * To find the <code>MDAttribute</code> that you want, call the
     * <code>getAttribute</code> or <code>getAttributes</code> method of another
     * object.
     * For example, to retrieve the attributes of a dimension,
     * call the <code>Dimension.getAttributes</code> method.
     * To find the attributes that have a particular property value,
     * <code>MetadataManagerServices.getAttribute</code>.
     *
     * @see MDDimension#getAttributes
     *
     * @status Reviewed
     */
	public MDAttribute() {
    	setObjectType(MM.ATTRIBUTE);
	}

     /**
     *
     * @hidden
     *
     */
    public MDAttribute( MetadataManagerServices mmServices, String attributeName, MDObject parent ) {
        super( mmServices, attributeName, parent );
        setObjectType(MM.ATTRIBUTE);
    }

  	/**
     * Retrieves the domain dimension of this attribute.
     * The domain dimension is the dimension that this attribute describes.
     * For example, if this attribute is a color attribute for products,
     * Then the domain dimension is the Product dimension.
     *
     * @return The domain dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDDimension getDomainDimension() throws MetadataManagerException {
  		return (MDDimension)getFirstRelative(MM.DOMAIN_DIMENSION);
  	}
  	
     /**
     *
     * @hidden
     *
     */
  	public int setDomainDimension(MDDimension domainDimension) {
  		if (domainDimension == null) {
  			return (MDU.FAILURE);
  		}
  		return setRelative(domainDimension, MM.DOMAIN_DIMENSION);
  	}
  	
  	/**
     * Retrieves the range dimension for this attribute.
     * The range dimension is the dimension that defines the values for
     * this attribute.
     * For example, if this attribute defines color, the range dimension
     * defines the possible color values. 
     *
     * @return The range dimension.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDDimension getRangeDimension() throws MetadataManagerException {
  		return (MDDimension)getFirstRelative(MM.RANGE_DIMENSION);
  	}
  
     /**
     *
     * @hidden
     *
     */
  	public int setRangeDimension( MDDimension rangeDimension ) {
  		if (rangeDimension == null) {
  			return (MDU.FAILURE);
  		}
  		return setRelative(rangeDimension, MM.RANGE_DIMENSION);
  	}

  	/**
     * Retrieves the qualifying dimensions for this attribute.
     * Qualifying dimensions are dimensions that the attribute uses, other
     * than the range and domain dimensions.
     * For example, if this attribute defines territories for salespersons,
     * and those territories vary over time, then the Time dimension would
     * be a qualifying dimension.
     *
     * @return The qualifying dimensions for this attribute.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDDimension[] getQualifyingDimensions() throws MetadataManagerException {
  		return MDDimension.getDimensionArray(getRelatives(MM.QUALIFYING_DIMENSION));
  	}

     /**
     *
     * @hidden
     *
     */
  	public int setQualifyingDimensions(MDDimension[] qualifyingDimensions) {
  		if ( (qualifyingDimensions == null) || (qualifyingDimensions.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<qualifyingDimensions.length; i++) {
  			setRelative(qualifyingDimensions[i], MM.QUALIFYING_DIMENSION);
  		}
  		return MDU.SUCCESS;
  	}
  
  	/**
     * Retrieves the levels to which this attribute applies.
     * Attributes can apply to all levels of a hierarchy or only to some
     * levels.
     * For example, an attribute might describe the day of the week, with values
     * of Sunday, Monday, Tuesday, and so on.
     * In a Time dimension, this attribute would apply only to the Day level.
     *
     * @return The levels of this attribute.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDLevel[] getLevels() throws MetadataManagerException {
  		return MDLevel.getLevelArray(getRelatives(MM.LEVEL));
  	}
  
     /**
     *
     * @hidden
     *
     */
  	public int setLevels(MDLevel[] levels) {
  		if ( (levels == null) || (levels.length == 0) ) {
  			return MDU.FAILURE;
  		}
  		for (int i=0; i<levels.length; i++) {
  			setRelative(levels[i], MM.LEVEL);
  		}
		return MDU.SUCCESS;
  	}
  
  	/**
     * Retrieves the short labels for the members of this attribute.
     *
     * @return The short labels.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDMemberMetadata getMemberShortLabelMetadata() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.MEMBER_SHORT_LABEL_METADATA);
  	}
  
     /**
     *
     * @hidden
     *
     */
  	public int setMemberShortLabelMetadata(MDMemberMetadata memberShortLabelMetadata) {
  		if (memberShortLabelMetadata == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(memberShortLabelMetadata, MM.MEMBER_SHORT_LABEL_METADATA);
  	}

    /**
     * Retrieves long labels for the members of this attribute.
     *
     * @return The long labels.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status Reviewed
     */
  	public MDMemberMetadata getMemberLongLabelMetadata() throws MetadataManagerException {
  		return (MDMemberMetadata)getFirstChild(MM.MEMBER_LONG_LABEL_METADATA);
  	}

     /**
     *
     * @hidden
     *
     */
  	public int setMemberLongLabelMetadata(MDMemberMetadata memberLongLabelMetadata) {
  		if (memberLongLabelMetadata == null) {
  			return MDU.FAILURE;
  		}
  		return setChild(memberLongLabelMetadata, MM.MEMBER_LONG_LABEL_METADATA);
  	}
  
    /**
     * @hidden
     * Retrieves the type of this attribute.
     * The type describes how this attribute is used in the schema.
     *
     * @return The type of this attribute.
     *
     * @see oracle.dss.metadataManager.common.MM#DIMENSIONAL_ATTRIBUTE
     * @see oracle.dss.metadataManager.common.MM#PROPERTY_ATTRIBUTE
     *
     * @status hidden
     */
	public String getAttributeType() {
		return getStrPropertyValue(MM.ATTRIBUTE_TYPE);		
	}
	
     /**
     *
     * @hidden
     *
     */
	public int setAttributeType(String strAttributeType) {
  		if (strAttributeType == null) {
  			return MDU.FAILURE;
  		}
  		setStrPropertyValue(MM.ATTRIBUTE_TYPE, strAttributeType, MDU.UI_ALL);
  		return MDU.SUCCESS;
	}

     /**
     *
     * @hidden
     *
     */
  	public static MDAttribute[] getAttributeArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDAttribute[] attributes = new MDAttribute[objects.length];
		for (int i=0; i<objects.length ; i++) {
			attributes[i] = (MDAttribute)objects[i];
		}
		return attributes;		
	}
  
     /**
     *
     * @hidden
     *
     */
  	public static MDAttribute[] getAttributeArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDAttribute[] attributes = new MDAttribute[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			attributes[i] = (MDAttribute)propertyBag[i];
		}
		return attributes;		
	}
}