/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.dataSource.common;

import java.util.Vector;
    
/**
 * @hidden
 */
public class IndexRanges extends Vector
{
    public IndexRanges()
    {
        super();
    }
    
    // This method assumes that we're building from zero-->the end, so that new info always is either merged with the last
    // element or added on
    public void addIndex(long index)
    {
        // Find where this one goes
        int size = super.size();
        
        IndexInfo last = null;
        if (size > 0)
            last = (IndexInfo)super.lastElement();
        if (last == null)
        {
            // Add a new one, and it's the first one
            IndexInfo newSR = new IndexInfo(index, 1, 1);
            super.addElement(newSR);
        }
        else
        {
            // We have a last
            // Determine if it can be merged as a "run" of suppressed slices or if we need a new entry
            if (index == last.getStartSlice() + last.getSuppressedCount())
            {
                // This slice follows on a run of suppressed slices: merge it
                last.addToRun();
            }
            else
            {
                // Need a new range to start, but some info will be transferred
                long cumulative = last.getCumulativeSlicesSuppressedForOriginal(-1, false);
                IndexInfo newSR = new IndexInfo(index, 1, cumulative+1);
                super.addElement(newSR);
            }
        }
    }
    
    public String toString()
    {
        // Dump this structure
        String retVal = null;
        int size = super.size();
        for (int i = 0; i < size; i++)
        {
            Object obj = super.elementAt(i);
            retVal = retVal == null ? obj.toString() : retVal + "\n" + obj.toString();
        }
        return retVal;
    }
    
    // Looks up the object representing how to modify the given slice obtained under suppression
    // to map it to the "real" unsuppressed cursor
    public IndexInfo findRange(long slice, boolean searchSuppressed)
    {
        int size = super.size();
        if (size == 0)
        {
            // nothing here
            return null;
        }
        
        int lower = 0;
        int upper = size;
        
        while (lower < upper)
        {
            int middle = (lower + upper) / 2;
            // Determine if slice we're seeking is >= middle, but less than the next value (if it exists)
            IndexInfo sr = (IndexInfo)super.elementAt(middle);
            if (slice >= sr.getSliceToSearch(searchSuppressed))
            {
                // Is there a next element?
                if (middle+1 < size)
                {
                    // Yes, determine if our slice is less than that one's starting slice
                    IndexInfo nextSR = (IndexInfo)super.elementAt(middle+1);
                    if (slice < nextSR.getSliceToSearch(searchSuppressed))
                    {
                        // sr is the one
                        return sr;
                    }
                    else
                    {
                        // Not there yet
                        lower = middle+1;
                    }
                }
                else
                {
                    // This is the one
                    return sr;
                }
            }                
            else
            {
                // Less than
                upper = middle;
            }
        }
        return null;
    }
}
    
