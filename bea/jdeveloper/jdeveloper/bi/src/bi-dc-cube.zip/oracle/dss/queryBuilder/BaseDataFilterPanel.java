/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/BaseDataFilterPanel.java /main/48 2009/01/04 22:26:48 gkellam Exp $
 *
 * Copyright (c) 2007, 2008, Oracle and/or its affiliates.All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.util.Enumeration;
import java.util.EventObject;
import java.util.Locale;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeSelectionModel;

import oracle.bali.ewt.help.HelpUtils;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.connection.client.Connection;
import oracle.dss.datautil.filter.MetadataFilter;
import oracle.dss.datautil.gui.OperatorDisplay;
import oracle.dss.datautil.gui.StandardDialog;
import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.parameter.CreateParameterDialog;
import oracle.dss.datautil.gui.component.parameter.impl.CreateParameterPanelModelImpl;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.queryBuilder.SelectShuttlePanel;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.selection.parameter.BaseParameter;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.gui.component.ComponentNode;
import oracle.dss.util.gui.component.list.DefaultListCellEditor;
import oracle.dss.util.gui.component.list.DefaultMutableListModel;
import oracle.dss.util.gui.component.list.JListMutable;
import oracle.dss.util.gui.component.tree.Checkable;
import oracle.dss.util.parameters.Parameter;

import oracle.javatools.icons.OracleIcons;
import oracle.javatools.ui.ComponentWithTitlebar;
import oracle.javatools.ui.ControlBar;
import oracle.javatools.ui.search.SearchField;

/**
 * <pre>
 * <code>BaseFilterPanel</code> used for common DataFilter code.
 * </pre>
 *
 * @author gkellam
 * @since  11.1.1.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   12/24/08 - Fix BUG 7667096 - CANNOT SPECIFY 'PARAMETER ACCEPTS
 *                         MULTIPLE VALUES' FOR COMPOUND DATA FILTERS.
 *    gkellam   06/11/08 - Add support for multiple parameter values.
 *    bmoroze   05/27/08 -
 *    gkellam   04/28/08 - Fix incorrect setting of operator when editing
 *                         DataFilter.
 *    gkellam   04/25/08 - Fix Bug 6741981 - DataFilter w/param on rowset query
 *                         with all numeric items does not work.
 *    hdharmaw  04/21/08 - List of operators is updated according to data type.
 *    gkellam   04/01/08 - Fix Date processing.
 *    gkellam   03/23/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   03/22/08 - Fix Bug 6656590 - List of operators should be
 *                         filtered based on data type.
 *    gkellam   03/22/08 - Fix Bug 6656590 - List of operators should be
 *                         filtered based on data type.
 *    gkellam   03/21/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   03/18/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   11/28/07 - Clean up resources better when changing condition
 *                         panels.
 *    gkellam   11/28/07 - Fix Bug 6650630 - QUERYBUILDER: ARROW KEYS NOT
 *                         FUNCTIONING CORRECTLY IN OPERATOR FIELD.
 *    gkellam   11/15/07 - Fix Bug 6624235 - QueryBuilder: Compound Data Filter
 *                         does not preview or run.
 *    gkellam   11/14/07 - Disable browse button for TopBottomDataFilter.
 *    gkellam   11/13/07 - Allow RangeDataFilter values to be directly edited.
 *    gkellam   11/05/07 - Update TopBottomDataFilter parameter handling.
 *    gkellam   11/02/07 - Add missing TopBottomDataFilter and RangeDataFilter
 *                         parameter support.
 *    gkellam   10/31/07 - Tweak top/bottom value handling.
 *    gkellam   10/30/07 - Fix Bug 6599381 - INABILITY TO PROPERLY CREATE
 *                         NON-NUMERIC 'IS IN TOP' DATA FILTER.
 *    gkellam   10/29/07 - Fix value panel editing issues.
 *    gkellam   10/25/07 - Tweak value sizing.
 *    gkellam   10/19/07 - Fix Bug 6505446 - Beta3: QueryBuilder: Delete button
 *                         enabled in 'Values' with no value present.
 *    gkellam   10/18/07 - Fix Bug 6502436 - Beta3: QueryBuilder: Selected
 *                         values dialog, selected value goes to row 2.
 *    gkellam   10/09/07 - Tweak numeric item Data Filter value handling.
 *    gkellam   10/02/07 - Fix ignore case enabling/disabling for
 *                         RangeDataFilter.
 *    gkellam   09/30/07 - Tweak operator handling.
 *    gkellam   09/27/07 - Generate correct object type for start and end
 *                         values.
 *    gkellam   09/27/07 - Fix Bug 6452059 - Selected values not shown for
 *                         browse 'in between'/'is not between' data filters.
 *    gkellam   09/26/07 - Update RangeDataFilter after invoking Select
 *                         Items/Values dialog.
 *    gkellam   09/26/07 - Fix browse issues with RangeDataFilter.
 *    gkellam   09/25/07 - Fix some between/not between DataFilter issues.
 *    gkellam   09/25/07 - Fix Bug 6418310 - QueryBuilder: Value field in
 *                         Compound Data Filter not reflecting changed value.
 *    gkellam   09/07/07 - Update the DataFilter prior to invoking Select
 *                         Values Dialog.
 *    gkellam   09/03/07 - Generate ComponentNodes out of MDObjects.
 *    gkellam   08/31/07 - Remove unneeded import.
 *    gkellam   08/30/07 - Continue adding new SelectItems support.
 *    gkellam   08/30/07 - Add new SelectItems support.
 *    gkellam   08/29/07 - When processing members, if we find an MDItem,
 *                         return label instead of ID.
 *    gkellam   08/28/07 - Bug 6364090 - Inability to create a DataFilter
 *                         involving numeric items.
 *    gkellam   08/24/07 - Fix Bug 6238876 - QueryBuilder: 'Delete' icon in
 *                         'Value' fld of Create Data Filter always enabled.
 *    gkellam   08/24/07 - QueryBuilder: 'Parameter name' fields enabled when
 *                         they shouldn't be.
 *    gkellam   08/23/07 - Bug 6311941 cleanup.
 *    gkellam   08/21/07 - Fix Bug 6059474 - Add Data Filter doesn't pick up
 *                         the selected item in the list.
 *    gkellam   08/17/07 - setItem for proper updates.
 *    gkellam   08/16/07 - Fix DataFilter bugs.
 *    jwtang    08/17/07 -
 *    gkellam   08/09/07 - Add ability exclude member values.
 *    gkellam   08/07/07 - Implement DataFilter search functionality.
 *    gkellam   08/06/07 - Implement DataFilter search functionality.
 *    gkellam   08/02/07 - Fix numeric item parsing.
 *    gkellam   08/01/07 - Clear out item values when changing items.
 *    gkellam   07/30/07 - Add Select Values support for numeric items.
 *    gkellam   07/29/07 - Fix null pointer.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/26/07 - Fix Bug 6051430 - DataFilter GUI: Missing support
 *                         for between and not between RangeDataFilter.
 *    gkellam   07/25/07 - Continue Select Values implementation.
 *    gkellam   07/23/07 - Select Values updates.
 *    gkellam   07/20/07 - Work on Select Item and Select Values dialog boxes.
 *    gkellam   07/19/07 - Change TreeListCombo to JTextField.
 *    gkellam   07/18/07 - Remove TreeListCombo from compound datafilter.
 *    gkellam   07/16/07 - More DataFilter GUI bug fixes.
 *    gkellam   07/15/07 - Put strings in resource files.
 *    gkellam   07/14/07 - Fix Ignore case bugs.
 *    gkellam   07/13/07 - Continue working in DataFilter plumbing....
 *    gkellam   07/12/07 - Update JList members model processing.
 *    gkellam   07/08/07 - Implement new BI Model UI for DataFilters.
 *    gkellam   07/04/07 - Continue updating DataFilter GUI.
 *    gkellam   07/02/07 - Continue updating DataFilter GUI.
 *    gkellam   06/12/07 - Fix Bug 5990797 - QueryBuilder: Edit/Add data filter
 *                         dialogs have no mnemonics.
 *    gkellam   05/29/07 - Fix Bug 6051440 - DataFilter GUI: Missing support
 *                         for NULL and NOT NULL Datafilters.
 *    gkellam   05/15/07 - Fix Bug 6045750 - SelectItems sub-dialog should
 *                         provide vertical scrollbar as needed.
 *    gkellam   05/13/07 - Add TopBottomDataFilter error checking.
 *    gkellam   05/12/07 - Tweak parameter handling.
 *    gkellam   05/10/07 - Fix Bug 5901482 - Missing Top/Bottom filters in the
 *                         QB add filter GUI.
 *    gkellam   05/09/07 - Fix Bug 5901482 - Missing Top/Bottom filters in the
 *                         QB add filter GUI.
 *    gkellam   05/08/07 - Fix Bug 6039525 - QueryBuilder: Clicking 'Select
 *                         Item...' from 'Add Data Filter' nothing happens.
 *    gkellam   05/08/07 - Fix Bug 6037092 - QueryBuilder: Add data filter
 *                         dialog should display warning message.
 *    gkellam   05/04/07 - Fix Bug 5939342 - QueryBuilder: 'Operator Parameter
 *                         Name' should be initially disabled.
 *    gkellam   05/03/07 - Fix TreeListComboItems refresh problem after More
 *                         Items... is chosen.
 *    gkellam   05/03/07 - Fix Bug 6025584 - QueryBuilder: 'More Items...' gets
 *                         selected instead of dialog coming up.
 *    gkellam   05/03/07 - Fix Bug 6025401 - QueryBuilder: Able to get an
 *                         erroneous filter to be displayed.
 *    gkellam   05/01/07 - Fix various TreeListCombo issues.
 *    gkellam   04/23/07 - APPS3:QB: Compound AND in Edit data filter defaults
 *                         incorrectly.
 *    gkellam   04/21/07 - Remove JTabbedPanes.
 *    gkellam   04/20/07 - Modify TreeListComboMembers handling.
 *    gkellam   04/18/07 - Set default TreeListComboMembers value.
 *    gkellam   04/16/07 - Fix Bug 5985624 - QueryBuilder: New parameter dialog
 *                         missing help button.
 *    gkellam   04/09/07 - Only invoke Select Item... dialog once.
 *    gkellam   04/09/07 - Update member TreeListCombo when Select Item... is
 *                         chosen.
 *    gkellam   04/04/07 - Add DataFilter itemItemsTreeNodeRoot back in as
 *                         needed.
 *    gkellam   04/04/07 - Modify ComponentContext retrieval.
 *    gkellam   04/03/07 - Tweak ComponentContext passing.
 *    gkellam   03/18/07 - Simplify TreeListComboMembers handling.
 *    gkellam   03/16/07 - Fix Bug 5918743 - QueryBuilder: 'Edit DataFilter'
 *                         dialog, 3rd drop down not initialized.
 */
public class BaseDataFilterPanel extends JPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  final static int VALUES_UNDEFINED = -1;

  /**
   * Used for getDataFilterPanelTwoValues JTabbedPane.
   */
  final static int VALUES_FROM = 0;
  final static int VALUES_TO = 1;

  /**
   * Used when creating a condition panel.
   */
  final static int VALUES_NONE = 0;
  final static int VALUES_ONE = 1;
  final static int VALUES_TWO = 2;

  /**
   * <code>invokeItemDialog</code> options, which include all, numeric and string
   * based items.
   */
  final static int ITEMS_DIALOG_ALL = 0;
  final static int ITEMS_DIALOG_NUMERIC = 1;
  final static int ITEMS_DIALOG_STRING = 2;

  /**
   * The default value used when the + button is pressed.
   * 
   */
  final static String DEFAULT_VALUE = "";

  /**
   * <code>int</code> value that represents and invalid value.
   */
  final static int INVALID_VALUE = -1;

  /**
   * The default number of items to show.
   * 
   */
  final static int ITEMS_DIALOG_DEFAULT_COUNT = 20;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  protected static OperatorDisplay[] m_operatorDisplays;

  protected MDItem m_mdItem = null;

  protected DataFilterPanelModel m_dataFilterPanelModel = null;
  protected ComponentContext m_componentContext = null;

  protected JComboBox m_jComboBoxItems = null;
  protected JComboBox m_jComboBoxOperators = null;
  protected JListMutable m_jListMembers = null;

  protected JCheckBox m_jCheckBoxOperatorAsParam = null;
  protected JTextField m_jTextFieldOperatorAsParam = null;

  protected JCheckBox m_jCheckBoxValueAsParam = null;
  protected JTextField m_jTextFieldValueAsParam = null;

  protected JCheckBox m_jCheckBoxAccepMultipleValues = null;

  protected JScrollPane m_jScrollPaneAvailableItemsTree = null;

  protected SearchField m_searchField = null;

  /**
   * Condition panel.
   * 
   */
  protected JPanel m_jPanelCondition = null;

  protected boolean m_bUpdateOperatorCombo = false;

  protected JTabbedPane m_jTabbedPane = null;

  protected DataFilterPanelValue m_dataFilterPanelValue = null;

  private DataFilterControlBar m_dataFilterControlBar = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public BaseDataFilterPanel (JPanel jPanel, ComponentContext componentContext) {
    super (new BorderLayout());
    setContext (componentContext);
  }

  public BaseDataFilterPanel (LayoutManager layoutManager) {
    super (layoutManager);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specify the <code>DataFilterControlBar</code>.
   * 
   * @param dataFilterControlBar A <code>DataFilterControlBar</code>.
   * 
   */
  public void setDataFilterControlBar (DataFilterControlBar dataFilterControlBar) {
    m_dataFilterControlBar = dataFilterControlBar;
  }

  /**
   * Retrievers the <code>DataFilterControlBar</code>.
   * 
   * @return <code>DataFilterControlBar</code>.
   * 
   */
  public DataFilterControlBar getDataFilterControlBar() {
    return m_dataFilterControlBar;
  }

  /**
   * Retrieves a DataFilter based on the state of this panel.
   * 
   * @return <code>BaseDataFilter</code>.
   * 
   */
  public BaseDataFilter getDataFilter() {
    return (getDataFilterPanelModel() != null) ? 
      getDataFilterPanelModel().getDataFilter() : null;
  }

  public void setDataFilterPanelModel (DataFilterPanelModel dataFilterPanelModel) {
    m_dataFilterPanelModel = dataFilterPanelModel;
    
    if (dataFilterPanelModel != null) {
      setContext (dataFilterPanelModel.getContext());
      
      // updateOperator (dataFilterPanelModel.getDataFilter());      
      updateMembers (dataFilterPanelModel.getDataFilter());
    }
  }

  public DataFilterPanelModel getDataFilterPanelModel() {
    return m_dataFilterPanelModel;
  }

  public void setContext (ComponentContext context) {
    m_componentContext = context;
    refresh();
  }

  public ComponentContext getContext() {
    return m_componentContext;
  }

  public void setAvailableItemsTree (JScrollPane jScrollPaneAvailableItemsTree) {
    m_jScrollPaneAvailableItemsTree = jScrollPaneAvailableItemsTree;
  }

  public JScrollPane getAvailableItemsTree() {
    return m_jScrollPaneAvailableItemsTree;
  }

  public void setSearchField (SearchField searchField) {
    m_searchField = searchField;
  }

  public SearchField getSearchField() {
    return m_searchField;
  }

  public void setConditionPanel (JPanel jPanelCondition) {
    m_jPanelCondition = jPanelCondition;
  }

  public JPanel getConditionPanel() {
    return m_jPanelCondition;
  }

  /**
   * Refresh <code>JListMutable</code> members component from <code>DataFilter</code>.
   * 
   * 
   * @return <code>Vector</code> containing the members associated with the
   *         <code>DataFilter</code>.
   * 
   */
  public Vector refreshMembers() {
    DataFilterPanelModel dataFilterPanelModel = getDataFilterPanelModel();
    BaseDataFilter baseDataFilter = 
      (dataFilterPanelModel != null) ? dataFilterPanelModel.getDataFilter() : null;

    return refreshMembers (baseDataFilter);
  }

  /**
   * Refresh <code>JListMutable</code> members component from <code>DataFilter</code>.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> used to update 
   *        <code>JListMutable</code> members.
   * @param jListMutableMembers A <code>JListMutable</code> to update
   * 
   * @return <code>Vector</code> containing the members associated with the
   *         <code>DataFilter</code>.
   * 
   */
  public Vector refreshMembers (BaseDataFilter baseDataFilter, JListMutable jListMutableMembers) {
    Vector vValues = null;

    if ((baseDataFilter != null) && (jListMutableMembers != null)) {

      DefaultListModel defaultListModel = null;

      if (jListMutableMembers != null) {
        defaultListModel = 
          ((DefaultListModel)jListMutableMembers.getModel());
      }

      if (defaultListModel != null) {
        if (baseDataFilter instanceof DataFilter) {
          vValues = ((DataFilter)baseDataFilter).getCmpValues();
      
          if ((vValues != null) && (!vValues.isEmpty())) {
            if (defaultListModel != null) {
  
              // Clear out any existing entries
              defaultListModel.removeAllElements();
  
              // Do not add in values if the item has changed
              boolean bAddValues = false;
              
              if (getMDItem() != null) {
                if (getMDItem().getUniqueID().equals (getItemID (baseDataFilter))) {
                  bAddValues = true;
                }
              }
  
              if (bAddValues) {
                String strValue = null;

                // Add in new ones  
                for (int nIndex = 0; nIndex < vValues.size(); nIndex++) {
                  strValue = DataUtils.format (getContext(), vValues.elementAt (nIndex), Locale.getDefault());                  
                  defaultListModel.addElement (strValue);
                }
              }
            }
          }
          else {
            // Clear out any existing entries
            defaultListModel.removeAllElements();
          }
        }
        else if (baseDataFilter instanceof TopBottomDataFilter) {
          int nValue = ((TopBottomDataFilter)baseDataFilter).getValue();
      
          if (defaultListModel != null) {

            // Clear out any existing entries
            defaultListModel.removeAllElements();

            // Add in new one  
            defaultListModel.addElement (new Long (nValue));
          }
        }
        else {
          // Clear out any existing entries
          defaultListModel.removeAllElements();
        }    
      }
    }

    return vValues;
  }

  /**
   * Refresh <code>JListMutable</code> members component from <code>DataFilter</code>.
   * 
   * @param object A <code>Object</code> to set.
   * @param jListMutableMembers A <code>JListMutable</code> to update
   * 
   * @return <code>Object</code> containing the member added.
   * 
   */
  public Object refreshMember (Object object, JListMutable jListMutableMembers) {
    if (jListMutableMembers != null) {

      DefaultListModel defaultListModel = getModel (jListMutableMembers);

      if (defaultListModel != null) {

        // Clear out any existing entries
        defaultListModel.removeAllElements();

        if (object != null) {
          defaultListModel.addElement (object);
        }
      }
    }

    return object;
  }

  /**
   * Refresh <code>JListMutable</code> members component from <code>DataFilter</code>.
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code> to update.
   * 
   * @return <code>Vector</code> containing the members associated with the
   *         <code>DataFilter</code>.
   * 
   */
  public Vector refreshMembers (BaseDataFilter baseDataFilter) {
    Vector vMembers = null;
    
    if (baseDataFilter instanceof RangeDataFilter) {
      vMembers = refreshMembers ((RangeDataFilter)baseDataFilter);
    }
    else {
      vMembers = refreshMembers (baseDataFilter, getJListMembers());
    }
  
    return vMembers;
  }

  /**
   * Refresh <code>JListMutable</code> members component from <code>DataFilter</code>.
   * 
   * @param rangeDataFilter A <code>RangeDatafilter</code> to update.
   * 
   * @return <code>Vector</code> containing the members associated with the
   *         <code>DataFilter</code>.
   * 
   */
  public Vector refreshMembers (RangeDataFilter rangeDataFilter) {
    
    if (rangeDataFilter != null) {

      JListMutable jListMutableMembersFrom = null;
      JListMutable jListMutableMembersTo = null;
      
      // Clear out any existing entries
      DataFilterPanelValue dataFilterPanelValueFrom = getTabbedPaneFromValue (VALUES_FROM);
      if (dataFilterPanelValueFrom != null) {
        jListMutableMembersFrom = dataFilterPanelValueFrom.getJListMembers();
        refreshMember (null, jListMutableMembersFrom);
      }

      DataFilterPanelValue dataFilterPanelValueTo = getTabbedPaneFromValue (VALUES_TO);
      if (dataFilterPanelValueTo != null) {
        jListMutableMembersTo = dataFilterPanelValueTo.getJListMembers();
        refreshMember (null, jListMutableMembersTo);
      }

      // Do not add in values if the item has changed
      boolean bAddValues = false;
      
      if (getMDItem() != null) {
        if (getMDItem().getUniqueID().equals (getItemID (rangeDataFilter))) {
          bAddValues = true;
        }
      }

      if (bAddValues) {
        refreshMember (rangeDataFilter.getStartValue(), jListMutableMembersFrom);
        refreshMember (rangeDataFilter.getEndValue(), jListMutableMembersTo);
      }
    }
    
    return null;
  }

  /**
   * Retreive the <code>JListMutable</code> members component from 
   * <code>DataFilter</code>.
   * 
   * @return <code>Vector</code> containing the members associated with the
   *         <code>DataFilter</code>.
   * 
   */
  public Vector getMembers() {
    // Refresh the JListMutableMembers

    Vector vValues = null;

    DataFilterPanelModel dataFilterPanelModel =
      getDataFilterPanelModel();
    
    if (dataFilterPanelModel != null) {
      BaseDataFilter baseDataFilter = 
        dataFilterPanelModel.getDataFilter();

      if (baseDataFilter instanceof DataFilter) {
        vValues = ((DataFilter)baseDataFilter).getCmpValues();
      }
    }

    return vValues;
  }

  public void refresh() {

    // Process Operator Parameters
    if (getComboOperators() != null) {
      getComboOperators().setModel (new DefaultComboBoxModel (getOperatorDisplays()));
      
      OperatorDisplay operatorDisplay = 
        getCurrentOperator (getOperatorDisplays(), getDataFilterPanelModel());
      
      DataFilterUtils.setSelectedItem (getComboOperators(), operatorDisplay);
  
      // Check for operator Parameters
      if (getDataFilterPanelModel() != null){
        BaseDataFilter baseDataFilter = getDataFilterPanelModel().getDataFilter();
        
        if (baseDataFilter != null) {
          String strParameterOperatorName = 
            baseDataFilter.getAssociatedParameterName (DataFilter.PARAMETER_OPERATOR_VALUE);
      
          if (strParameterOperatorName != null) {
            getJCheckBoxOperatorAsParam().setSelected (true);
            getJTextFieldOperatorAsParam().setText (strParameterOperatorName);       
          }
        }
      }
    }

    if (getJComboBoxItems() != null) {
      
      Vector vMDItems = QBUtils.getSelectedMDItems (getContext());

      MDItem mdItem = 
        getCurrentItem (getDataFilterPanelModel(), getContext());

      updateComboBox (getJComboBoxItems(), vMDItems, mdItem, true);
    }

    // Refresh the Members
    Vector vstrMembers = refreshMembers();

    // Process Value Parameters
    if (getDataFilterPanelModel() != null){
      BaseDataFilter baseDataFilter = getDataFilterPanelModel().getDataFilter();
      
      if (baseDataFilter != null) {
        if (baseDataFilter instanceof RangeDataFilter) {
          RangeDataFilter rangeDataFilter = (RangeDataFilter) baseDataFilter;
         
          String strParameterValuesNameFrom = 
            rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_START_VALUE);

          if (strParameterValuesNameFrom != null) {
            DataFilterPanelValue dataFilterPanelValueFrom = getTabbedPaneFromValue (VALUES_FROM);
            
            if (dataFilterPanelValueFrom != null) {
              if (dataFilterPanelValueFrom.getJCheckBoxValueAsParam() != null) {
                dataFilterPanelValueFrom.getJCheckBoxValueAsParam().setSelected (true);
              }
              
              if (dataFilterPanelValueFrom.getJTextFieldValueAsParam() != null) {
                dataFilterPanelValueFrom.getJTextFieldValueAsParam().setText (strParameterValuesNameFrom);       
              }
            }           
          }
         
          String strParameterValuesNameTo =
            rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_END_VALUE);

          if (strParameterValuesNameTo != null) {
            DataFilterPanelValue dataFilterPanelValueTo = getTabbedPaneFromValue (VALUES_TO);
            
            if (dataFilterPanelValueTo != null) {
              if (dataFilterPanelValueTo.getJCheckBoxValueAsParam() != null) {
                dataFilterPanelValueTo.getJCheckBoxValueAsParam().setSelected (true);
              }
              
              if (dataFilterPanelValueTo.getJTextFieldValueAsParam() != null) {
                dataFilterPanelValueTo.getJTextFieldValueAsParam().setText (strParameterValuesNameTo);       
              }
            }           
          }
        }
        else {
          String strParameterValuesName = null;
  
          if (baseDataFilter instanceof TopBottomDataFilter) {
            strParameterValuesName = 
              baseDataFilter.getAssociatedParameterName (TopBottomDataFilter.PARAMETER_COMPARISON_VALUE);
          }
          else {
            strParameterValuesName = 
              baseDataFilter.getAssociatedParameterName (DataFilter.PARAMETER_COMPARISON_VALUES);
          }
      
          if (strParameterValuesName != null) {
            if (getJCheckBoxValueAsParam() != null) {
              getJCheckBoxValueAsParam().setSelected (true);
            }
            
            if (getJTextFieldValueAsParam() != null) {
              getJTextFieldValueAsParam().setText (strParameterValuesName);       
            }

            if (getJCheckBoxAcceptMultipleValues() != null) {
              getJCheckBoxAcceptMultipleValues().setSelected (DataUtils.canAcceptMultipleValues (baseDataFilter));
            }
          }
        }
  
        // Update Ignore Case checkbox   
        updateIgnoreCaseState();
      }
    }
  }

  /**
   * Make a <code>BaseDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   * 
   * @return <code>BaseDataFilter</code>
   * 
   */
  public BaseDataFilter makeBaseDataFilter (String strItemID, int nCmpOperator) throws Exception {

    BaseDataFilter baseDataFilter = null;

    switch (nCmpOperator) {
      case TopBottomDataFilter.OP_BOTTOM:
      case TopBottomDataFilter.OP_TOP:
        baseDataFilter = makeTopBottomDataFilter (strItemID, nCmpOperator);
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        baseDataFilter = makeRangeDataFilter (strItemID, nCmpOperator);
        break;
      
      default:
        baseDataFilter = makeDataFilter (strItemID, nCmpOperator);
        break;
    }

    return baseDataFilter;
  }

  /**
   * Make a <code>BaseDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison opeartor.
   * 
   * @return <code>BaseDataFilter</code>
   * 
   */
  public BaseDataFilter makeBaseDataFilter (int nCmpOperator) throws Exception {
    return makeBaseDataFilter (null, nCmpOperator);
  }

  public BaseDataFilter makeBaseDataFilter (String strItemID) throws Exception {
    int nCmpOperator = DataFilterUtils.getOperatorId (getComboOperators());
    return makeBaseDataFilter (strItemID, nCmpOperator);
  }

  public BaseDataFilter makeBaseDataFilter() throws Exception {
    int nCmpOperator = DataFilterUtils.getOperatorId (getComboOperators());
    return makeBaseDataFilter (nCmpOperator);
  }

  public void updateModel() throws Exception {
    if (getDataFilterPanelModel() != null) {

      BaseDataFilter baseDataFilter = getDataFilterPanelModel().getDataFilter();
      
      if (!(baseDataFilter instanceof CompoundDataFilter)) {
        // Update the DataFilter
        getDataFilterPanelModel().setDataFilter (makeBaseDataFilter());
  
        // Update members
        updateMembers (getDataFilterPanelModel().getDataFilter());
      }
    }
  }

  public Vector getMembers (JList jListMembers, JComboBox jComboBoxItems, 
      ComponentContext componentContext, BaseDataFilter baseDataFilter) throws Exception {
    return getMembers (jListMembers, jComboBoxItems, componentContext, baseDataFilter, -1);
  }

  public Vector getMembers (JList jListMembers, JComboBox jComboBoxItems, 
      ComponentContext componentContext, BaseDataFilter baseDataFilter, int nMaxMembers) throws Exception {

    Vector vMembers = new Vector();
    
    if (jListMembers != null) {
      // Retrieve the DataType          
      String strDataType = DataFilterUtils.getItemDatatype (jComboBoxItems);
      
      // For both numeric and non-numeric items, the values are expected to be
      // integer for top/bottom data filters
      if (baseDataFilter instanceof TopBottomDataFilter) {
        strDataType = MM.INTEGER;
      }

      ListModel listModel = jListMembers.getModel();

      // Check to see if we have a numeric item
      if (!MM.STRING.equals (strDataType) || (baseDataFilter instanceof TopBottomDataFilter)) {
        // gek 04/17/07 Check to see if the user selected a number item or
        //              numeric value.
        if ((listModel != null) && (listModel.getSize() > 0)) {
          Object objItem = null;

          int nListCount = listModel.getSize();   

          // Determine maximum number of members to process       
          if ((nMaxMembers != -1) && (nListCount > nMaxMembers)) {
            //// nListCount = nMaxMembers;  
          }

          for (int nIndex = 0; nIndex < nListCount; nIndex++) {
  
            objItem = listModel.getElementAt (nIndex);

            // If we have a numeric item, override the data type      
            if (objItem instanceof MDItem) {
              strDataType = MM.STRING;  
            }
            else if (objItem instanceof ComponentNode) {
              // Attempt to retrieve the MDObject ID from the ComponentNode
              /*
              String strItem = (String)((ComponentNode)objItem).getValue();  
              MDObject mdObject = getMDObject (strItem);
              */
              vMembers = applyValues (jListMembers, baseDataFilter);
              return vMembers;
            }
            else if (objItem instanceof String) {
              Object object = null;
              
              try {
                object = 
                  DataUtils.parseMemberString ((String)objItem, strDataType, 
                    DataFilterUtils.getItemFormatMask (jComboBoxItems), false, 
                      componentContext.getLocale(), componentContext.getErrorHandler());
              }
              
              catch (Exception exception) {
                strDataType = MM.STRING;  
              }
            
              if (object instanceof String) {
                strDataType = MM.STRING;  
              }
              else {
                if (object != null) {
                  vMembers.add (object);
                }
              }
            }
            else if (objItem != null) {
              vMembers.add (objItem);
            }
          }

          applyValues (vMembers, baseDataFilter);
        }
      }
                
      if (MM.STRING.equals (strDataType)) {             
        
        vMembers = getValues (jListMembers);
        applyValues (vMembers, baseDataFilter);        
        
        /*
        String strMembers = getMembers (jListMembers);                
        
        vMembers = DataUtils.parseMembersString (strMembers, 
          strDataType, DataFilterUtils.getItemFormatMask (jComboBoxItems), 
            componentContext.getLocale(), componentContext.getErrorHandler(), dataFilter);
        */
      }
    }

    return vMembers;
  }

  /**
   * Apply the <code>JList</code> values to the <code>BaseDataFilter</code>.
   * 
   * @param jListValues A <code>JList</code> to process.
   * @param baseDataFilter A <code>BaseDataFilter</code> to add values to.
   * 
   * @return <code>Vector</code> of <code>JList</code> values.
   * 
   */
  protected Vector applyValues (JList jListValues, BaseDataFilter baseDataFilter) { 
    Vector vValues = null;
    
    if ((jListValues != null) && (baseDataFilter != null)) {
      ListModel listModel = jListValues.getModel();
    
      if ((listModel != null) && (listModel.getSize() > 0)) {
    
        vValues = new Vector();
        for (int nIndex = 0; nIndex < listModel.getSize(); nIndex++) {
          vValues.add (listModel.getElementAt (nIndex));
        }  

        if (baseDataFilter instanceof DataFilter) {
          ((DataFilter)baseDataFilter).setCmpValues (vValues);
        }
        else if (baseDataFilter instanceof TopBottomDataFilter) {
          if (vValues.size() > 0) {  
            if (vValues.get(0) instanceof Long) {
              Long longValue = (Long) (vValues.get(0));
              ((TopBottomDataFilter)baseDataFilter).setValue (longValue.intValue());
            }
          }
        }  
      } 
    }    
  
    return vValues;
  }

  /**
   * Apply the <code>Vector</code> of values to the <code>BaseDataFilter</code>.
   * 
   * @param vValues A <code>Vector</code> of values to process.
   * @param baseDataFilter A <code>BaseDataFilter</code> to add values to.
   * 
   * @return <code>Vector</code> values.
   * 
   */
  protected Vector applyValues (Vector vValues, BaseDataFilter baseDataFilter) { 
    
    if ((vValues != null) && (baseDataFilter != null)) {
      if (baseDataFilter instanceof DataFilter) {
        ((DataFilter)baseDataFilter).setCmpValues (vValues);
      }
      else if (baseDataFilter instanceof TopBottomDataFilter) {

        if (vValues.size() > 0) {  
          if (vValues.get(0) instanceof Long) {
            Long longValue = (Long) (vValues.get(0));
            ((TopBottomDataFilter)baseDataFilter).setValue (longValue.intValue());
          }
        }
      }
    } 
  
    return vValues;
  }

  /**
   * Generate a delimited list of members associated with the <code>JList</code>
   * 
   * For now, this is just needed to help reuse the old code path which 
   * processed delimited lists of member strings
   * 
   * @param jListMembers A <code>JList</code> to process.
   * 
   * @return <code>String</code> representing the delimited list of members.
   */
  public String getMembers (JList jListMembers) { 
    // For now, just reuse the old code path which precessed delimited
    // lists of strings
    StringBuffer stringBuffer = new StringBuffer();
    
    if (jListMembers != null) {
      ListModel listModel = jListMembers.getModel();
    
      if ((listModel != null) && (listModel.getSize() > 0)) {
        String strValue= null;
        
        for (int nIndex = 0; nIndex < listModel.getSize(); nIndex++) {
          
          strValue = listModel.getElementAt (nIndex).toString();  
          
          // If we have an MDObject, use the name instead of the ID
          MDObject mdObject = DataUtils.getMDObject (getContext(), strValue);
          if (mdObject != null) {
            strValue = mdObject.getName();
          }
        
          stringBuffer.append (strValue);
          
          if (nIndex < (listModel.getSize() - 1)) {
            stringBuffer.append (DataUtils.DATAFILTER_TOKEN_DELIMETER);
          }
        }  
      } 
    }    

    return stringBuffer.toString();
  }

  /**
   * <pre>
   * Generate a <code>Vector</code> of values associated with the <code>JList</code>.
   * 
   * Note: <code>MDObject</code>s are returned a <code>ComponentNode</code>s
   * </pre>
   * 
   * @param jListMembers A <code>JList</code> to process.
   * 
   * @return <code>Vector</code> of values associated with the <code>JList</code>.
   */
  public Vector getValues (JList jListMembers) { 
    Vector vValues = new Vector();
    
    if (jListMembers != null) {
      ListModel listModel = jListMembers.getModel();
    
      if ((listModel != null) && (listModel.getSize() > 0)) {
        String strValue = null;
        
        for (int nIndex = 0; nIndex < listModel.getSize(); nIndex++) {
          
          strValue = listModel.getElementAt (nIndex).toString();  
          
          // If we have an MDObject, create a ComponentNode
          MDObject mdObject = DataUtils.getMDObject (getContext(), strValue);
          if (mdObject != null) {
            vValues.add (QBUtils.makeComponentNode (mdObject, getContext()));
          }
          else {
            vValues.add (strValue);
          }
        }  
      } 
    }    

    return vValues;
  }

  public Vector getMembers (JTextField jTextFieldMembers, JComboBox jComboBoxItems, 
                           ComponentContext componentContext, BaseDataFilter baseDataFilter) throws Exception {
    
    Vector vMembers = null;
    
    if (jTextFieldMembers != null) {
      String strText = jTextFieldMembers.getText();

      // Retrieve the DataType          
      String strDataType = DataFilterUtils.getItemDatatype (jComboBoxItems);

      // For both numeric and non-numeric items, the values are expected to be
      // integer for top/bottom data filters
      if (baseDataFilter instanceof TopBottomDataFilter) {
        strDataType = MM.INTEGER;
      }

      if (baseDataFilter instanceof TopBottomDataFilter) {
        vMembers = DataUtils.parseMembersString (strText, 
          strDataType, DataFilterUtils.getItemFormatMask (jComboBoxItems), 
          componentContext.getLocale(), 
          componentContext.getErrorHandler(), (TopBottomDataFilter)baseDataFilter);
      }
      else if (baseDataFilter instanceof RangeDataFilter) {
        vMembers = DataUtils.parseMembersString (strText, 
          strDataType, DataFilterUtils.getItemFormatMask (jComboBoxItems), 
          componentContext.getLocale(), 
          componentContext.getErrorHandler(), (RangeDataFilter)baseDataFilter);
      }
      else if (baseDataFilter instanceof DataFilter) {     
        vMembers = DataUtils.parseMembersString (strText, 
          strDataType, DataFilterUtils.getItemFormatMask (jComboBoxItems), 
          componentContext.getLocale(), 
          componentContext.getErrorHandler(), (DataFilter)baseDataFilter);
      }
    }

    return vMembers;
  }

  public Vector getMembers (JList jListMembers, JComboBox jComboBoxItems, 
                           ComponentContext componentContext, RangeDataFilter rangeDatafilter) {
    
    Vector vMembers= null;
    if (jListMembers != null) {

      // Retrieve the DataType          
      String strDataType = DataFilterUtils.getItemDatatype (jComboBoxItems);

      String strMembers = getMembers (jListMembers);
      vMembers = DataUtils.parseMembersString (strMembers, 
        strDataType, DataFilterUtils.getItemFormatMask (jComboBoxItems), 
          componentContext.getLocale(), componentContext.getErrorHandler(), rangeDatafilter);
    }

    return vMembers;
  }

  public Vector getMembers (JTextField jTextFieldMembers, JComboBox jComboBoxItems, 
                           ComponentContext componentContext, TopBottomDataFilter topBottomDataFilter) {
    
    if (jTextFieldMembers != null) {
      String strText = jTextFieldMembers.getText();

      return DataUtils.parseMembersString (strText, 
        MM.INTEGER, 
        DataFilterUtils.getItemFormatMask (jComboBoxItems), 
        componentContext.getLocale(), 
        componentContext.getErrorHandler(), topBottomDataFilter);
    }

    return null;
  }

  public Vector getMembers (JTextField jTextFieldMembers, JComboBox jComboBoxItems, 
                           ComponentContext componentContext, RangeDataFilter rangeDataFilter) {
    
    if (jTextFieldMembers != null) {
      String strText = jTextFieldMembers.getText();

      return DataUtils.parseMembersString (strText, 
        MM.INTEGER, 
        DataFilterUtils.getItemFormatMask (jComboBoxItems), 
        componentContext.getLocale(), 
        componentContext.getErrorHandler(), rangeDataFilter);
    }

    return null;
  }

  public class MoreItems extends Object {
    JComboBox m_jComboBox = null;
  
    public MoreItems (JComboBox jComboBox) {
      setComboBox (jComboBox);      
    }
  
    public String toString() {
      return getResourceString (QueryBuilderBundle.BASEDATAFILTERPANEL_MORE_ITEMS);
    }

    public JComboBox getComboBox() {
      return m_jComboBox;
    }

    public void setComboBox (JComboBox jComboBox) {
      m_jComboBox = jComboBox;
    }
  }

  /**
   * @internal
   */
  public static void main (String[] strArguments) {
    BaseDataFilterPanel dataFilterPanel = new BaseDataFilterPanel (null, null);
    dataFilterPanel.refresh();
    QBUtils.makeFrame (dataFilterPanel);
  }

  /**
   * Create space around the <code>BaseDataFilterPanel</code>.
   * 
   * This directly affects how the DataFilter panel is resized within the
   * <code>oracle.ide.controls.JComboCardPanel</code>.
   * 
   * @return <code>Insets</code> representing the space around the 
   *         <code>BaseDataFilterPanel</code>. 
   */
  public Insets getInsets() { 
    return new Insets (0, 10, 0, 10); 
  } 

  /**
   * Make a <code>ControlBar</code> used to display Value buttons.
   * 
   * @param jListMembers A <code>JListMutable</code> 
   * @param nValueLimit A <code>int</code>
   * 
   * @return <code>ControlBar</code> containing the <code>ControlBar</code>. 
   */
  public DataFilterControlBar makeControlBar (JListMutable jListMembers, int nValueLimit) {
  
    ControlBar controlBar = new ControlBar();
    
    DataFilterControlBar dataFilterControlBar = 
      new DataFilterControlBar (controlBar);
    
    // Add Button
    dataFilterControlBar.setButtonAdd (new DataFilterPanelButton (dataFilterControlBar));

    Utils.initializeIconButton (dataFilterControlBar.getButtonAdd(), 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_TOOLTIP_ADD), 
        OracleIcons.getIcon (OracleIcons.ADD));

    dataFilterControlBar.getButtonAdd().setJListMembers (jListMembers);;
    dataFilterControlBar.getButtonAdd().setValueLimit (nValueLimit);
    controlBar.add (dataFilterControlBar.getButtonAdd());

    dataFilterControlBar.getButtonAdd().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        JListMutable jListMutableMembers = null;
        DataFilterPanelButton dataFilterPanelButton = null; 

        if (actionEvent.getSource() instanceof DataFilterPanelButton) {
          dataFilterPanelButton = 
            (DataFilterPanelButton) actionEvent.getSource();
            
          jListMutableMembers = dataFilterPanelButton.getJListMembers();
        }
        
        if (jListMutableMembers != null) {

          int nIndex = jListMutableMembers.getSelectedIndex();
          int nSize = jListMutableMembers.getModel().getSize();

          // If no selection or if item in last position is selected,
          // add the new one to end of list, and select new one.
          if (nIndex == -1 || (nIndex + 1 == nSize)) {
            ((DefaultListModel)jListMutableMembers.getModel()).addElement (DEFAULT_VALUE);
            jListMutableMembers.setPrototypeCellValue (" ");
            jListMutableMembers.setSelectedIndex (nSize);
            jListMutableMembers.editCellAt (nSize, actionEvent);
          } 
          else {
            // Otherwise insert the new one after the current selection,
            // and select new one.
            ((DefaultListModel)jListMutableMembers.getModel()).insertElementAt (DEFAULT_VALUE, ++nIndex);
            jListMutableMembers.setPrototypeCellValue (" ");
            jListMutableMembers.setSelectedIndex (nIndex);
            jListMutableMembers.editCellAt (nIndex, actionEvent);
          }
       
          jListMutableMembers.ensureIndexIsVisible (nIndex + 1);
        }
      }
    });

    // Browse Button
    dataFilterControlBar.setButtonBrowse (new DataFilterPanelButton (dataFilterControlBar));
    Utils.initializeIconButton (dataFilterControlBar.getButtonBrowse(), 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_TOOLTIP_BROWSE), 
        new ImageIcon (Utils.getImageResource (QueryBuilder.class, "images/search_ena.png")));

    controlBar.add (dataFilterControlBar.getButtonBrowse());

    dataFilterControlBar.getButtonBrowse().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        try {
          Object[] objectsSelected = null;
      
          // Update the DataFilter prior to invoking Select Values Dialog
          updateModel();

          BaseDataFilter baseDataFilter = getDataFilter();
          
          if (baseDataFilter != null) {
            MDItem mdItem = getItem (baseDataFilter);
            
            if (DataUtils.isNumeric (mdItem) && DataUtils.hasAggRule (mdItem)) {
              objectsSelected = invokeSelectItemsDialog (baseDataFilter);
            }
            else {
              objectsSelected = invokeSelectValuesDialog (baseDataFilter);
            }

            if (objectsSelected != null) {
              // Update DataFilter with selected items
              updateMembers (baseDataFilter, objectsSelected);
              
              // Update jListMutableMembers with DataFilter
              refreshMembers (baseDataFilter);
            }
          }
        }   
          
        catch (Exception exception) {
          Logger.getLogger ("oracle.dss.queryBuilder.BaseDataFilterPanel").log (Level.INFO, 
            "invokeSelectValuesDialog failed", exception);
        }
      }
    });

    // Delete Button
    dataFilterControlBar.setButtonDelete (new DataFilterPanelButton (dataFilterControlBar));

    Utils.initializeIconButton (dataFilterControlBar.getButtonDelete(), 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_TOOLTIP_DELETE), 
        OracleIcons.getIcon (OracleIcons.DELETE));

    dataFilterControlBar.getButtonDelete().setJListMembers (jListMembers);;
    dataFilterControlBar.getButtonDelete().setValueLimit (nValueLimit);
    controlBar.add (dataFilterControlBar.getButtonDelete());

    dataFilterControlBar.getButtonDelete().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {

        JListMutable jListMutableMembers = null;
        DataFilterPanelButton dataFilterPanelButton = null; 

        if (actionEvent.getSource() instanceof DataFilterPanelButton) {
          dataFilterPanelButton = 
            (DataFilterPanelButton) actionEvent.getSource();
            
          jListMutableMembers = dataFilterPanelButton.getJListMembers();
        }

        if (jListMutableMembers != null) {
          int[] nSelectedIndices = jListMutableMembers.getSelectedIndices();

          if (nSelectedIndices.length > 0) {
            // Move backwards through list
            for (int nIndex = nSelectedIndices.length - 1; nIndex > -1; nIndex--) {
              ((DefaultListModel)jListMutableMembers.getModel()).remove (nSelectedIndices [nIndex]);    
            }
          
            jListMutableMembers.setSelectedIndex (Math.min (nSelectedIndices[0], 
              jListMutableMembers.getModel().getSize() - 1));
          }
        }
      
        if (dataFilterPanelButton != null) {
          if (!dataFilterPanelButton.getLimitReached()) {
            DataFilterControlBar dataFilterControlBar = 
              dataFilterPanelButton.getDataFilterControlBar();
          
            if (dataFilterControlBar != null) {   
              dataFilterControlBar.getButtonAdd().setEnabled (true);
            }
          }
        }
      
        updateDeleteButtonState();
      }
    });

    updateDeleteButtonState (dataFilterControlBar);

    return dataFilterControlBar;
  }

  public DataFilterPanelValue makeValuePanel (int nInitialValueCount) {
    return makeValuePanel (-1, VALUES_ONE, VALUES_UNDEFINED, nInitialValueCount);
  }

  public DataFilterPanelValue makeValuePanel (int nValueLimit, int nValueType, int nValueSubType, int nInitialCount) {
    DataFilterPanelValue dataFilterPanelValue = new DataFilterPanelValue();
    dataFilterPanelValue.setValueType (nValueType);
    dataFilterPanelValue.setValueSubType (nValueSubType);
    dataFilterPanelValue.setInitialCount (nInitialCount);
    
    dataFilterPanelValue.setLayout (new GridBagLayout());

    // DataFilter used for initialization
    BaseDataFilter baseDataFilter = getDataFilter();

    GridBagConstraints gridBagConstraints = getDefaultGridBagConstraints();

    // Create the Value list and put it in a scroll pane.
    setJListMembers (new DataFilterPanelJListMutable (new DefaultMutableListModel()));
    
    JTextField jTextField = new JTextField();
    Dimension dimensionSize = jTextField.getPreferredSize();
    jTextField.setMinimumSize (dimensionSize);
    jTextField.setPreferredSize (dimensionSize);
    
    getJListMembers().setListCellEditor (new DefaultListCellEditor (jTextField));
    getJListMembers().setSelectionMode (ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    getJListMembers().setSelectedIndex (0);
    dataFilterPanelValue.setJListMembers (getJListMembers());

    getJListMembers().addListSelectionListener (new ListSelectionListener() {
      public void valueChanged (ListSelectionEvent ListSelectionEvent) {
        updateDeleteButtonState();        
      }
    });

    // Limit the number of entries in table
    if (nInitialCount == -1) {
      nInitialCount = 5;
    }

    getJListMembers().setVisibleRowCount (nInitialCount);

    JScrollPane jScrollPaneList = new JScrollPane (getJListMembers());
    
    Dimension dimension = 
      new Dimension (200, (nInitialCount * getJListMembers().getFixedCellHeight()) + 4);
    
    getJListMembers().setMinimumSize (dimension);

    // Add the Control Bar which has the button options to the Members JList
    JLabel jLabel = 
      makeLabel (getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE));

    jLabel.setLabelFor (getJListMembers());

    dataFilterPanelValue.setDataFilterControlBar (
      makeControlBar (getJListMembers(), nValueLimit));
    
    ComponentWithTitlebar componentWithTitlebar = 
      new ComponentWithTitlebar (jScrollPaneList, jLabel, 
        dataFilterPanelValue.getDataFilterControlBar().getControlBar());
 
    // Add the Members JList
    dataFilterPanelValue.add (componentWithTitlebar, gridBagConstraints);

    // Ignore Case
    dataFilterPanelValue.setJCheckBoxIgnoreCase (
      makeCheckBox (getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_IGNORE_CASE), false, dataFilterPanelValue));

    gridBagConstraints.fill = GridBagConstraints.NONE;
    dataFilterPanelValue.add (dataFilterPanelValue.getJCheckBoxIgnoreCase(), gridBagConstraints);

    // Pass Value as Parameter
    setJCheckBoxValueAsParam (
      makeCheckBox (getResourceString (
        QueryBuilderBundle.DATAFILTERPANEL_VALUE_PASS_AS_PARAMETER), false, dataFilterPanelValue));

    dataFilterPanelValue.setJCheckBoxValueAsParam (getJCheckBoxValueAsParam());
    
    dataFilterPanelValue.add (getJCheckBoxValueAsParam(), gridBagConstraints);
    
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;

    // Parameter name
    JPanel jPanelValueParameterName = new JPanel();
    ((FlowLayout)jPanelValueParameterName.getLayout()).setAlignment (FlowLayout.LEFT);

    jPanelValueParameterName.add (Box.createHorizontalStrut (10), gridBagConstraints);
    
    JLabel jLabelParameterName = 
      DataUtils.getLabel (
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_PARAMETER_NAME), 
          SwingConstants.LEADING);
    
    jPanelValueParameterName.add (jLabelParameterName);

    setJTextFieldValueAsParam (new JTextField (20));

    dataFilterPanelValue.setJTextFieldValueAsParam (getJTextFieldValueAsParam());

    jLabelParameterName.setLabelFor (getJTextFieldValueAsParam());

    jPanelValueParameterName.add (getJTextFieldValueAsParam());
    
    dataFilterPanelValue.add (jPanelValueParameterName, gridBagConstraints);

    getJCheckBoxValueAsParam().addItemListener (new ItemListener() {
      public void itemStateChanged (ItemEvent itemEvent) {
        if (itemEvent != null) {
          Object objSource = itemEvent.getSource();
          
          if (objSource instanceof DataFilterPanelCheckBox) {
            DataFilterPanelCheckBox dataFilterPanelCheckBox = 
              (DataFilterPanelCheckBox) objSource;
          
            DataFilterPanelValue dataFilterPanelValue = 
              ((DataFilterPanelCheckBox) objSource).getDataFilterPanelValue();
          
            if (dataFilterPanelValue != null) {
              dataFilterPanelValue.getJTextFieldValueAsParam().setEnabled (dataFilterPanelCheckBox.isSelected());
              dataFilterPanelValue.getJCheckBoxAcceptMultipleValues().setEnabled (dataFilterPanelCheckBox.isSelected());
            }
          }
        }
      }
    });

    // Accept Multiple Values
    setJCheckBoxAcceptMultipleValues (
      makeCheckBox (getResourceString (
        QueryBuilderBundle.DATAFILTERPANEL_VALUE_ACCEPT_MULTIPLE_VALUES), false, dataFilterPanelValue));

    JPanel jPanelAcceptMultipleValues = new JPanel();
    ((FlowLayout)jPanelAcceptMultipleValues.getLayout()).setAlignment (FlowLayout.LEFT);

    gridBagConstraints = getDefaultGridBagConstraints();
    jPanelAcceptMultipleValues.add (Box.createHorizontalStrut (10), gridBagConstraints);
    jPanelAcceptMultipleValues.add (getJCheckBoxAcceptMultipleValues());
    
    dataFilterPanelValue.setJCheckBoxAcceptMultipleValues (getJCheckBoxAcceptMultipleValues());

    dataFilterPanelValue.add (jPanelAcceptMultipleValues, gridBagConstraints);

    // Initialize based on DataFilter

    // Initialize the member
    Object objValue = getValue (baseDataFilter, getDataFilterPanelValue());

    if (objValue != null) {
      ((DefaultMutableListModel)dataFilterPanelValue.getJListMembers().getModel()).addElement (objValue);  
      dataFilterPanelValue.getJListMembers().setSelectedValue (objValue, true);  
    }

    // Initialize the Ignore Case
    if (baseDataFilter != null) {
      dataFilterPanelValue.getJCheckBoxIgnoreCase().setSelected (baseDataFilter.isIgnoreCase());
    }

    // Initialize Accept Multiple Values
    dataFilterPanelValue.getJCheckBoxAcceptMultipleValues().setSelected (
      DataUtils.canAcceptMultipleValues (baseDataFilter));

    // Initialize the Pass Value as Parameter and Parameter Name
    String strParameterComparisonValues =  null;
    if (baseDataFilter != null) {

      if (baseDataFilter instanceof RangeDataFilter) {
        RangeDataFilter rangeDataFilter = (RangeDataFilter) baseDataFilter;
       
        switch (nValueSubType) {
          case VALUES_FROM:
            String strParameterValuesNameFrom = 
              rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_START_VALUE);
    
            if (strParameterValuesNameFrom != null) {
              getJCheckBoxValueAsParam().setSelected (strParameterValuesNameFrom != null);
              getJTextFieldValueAsParam().setText (strParameterValuesNameFrom);       
            }
            break;

          case VALUES_TO:
            String strParameterValuesNameTo = 
              rangeDataFilter.getAssociatedParameterName (RangeDataFilter.PARAMETER_END_VALUE);
    
            if (strParameterValuesNameTo != null) {
              getJCheckBoxValueAsParam().setSelected (strParameterValuesNameTo != null);
              getJTextFieldValueAsParam().setText (strParameterValuesNameTo);       
            }
            break;

          default:
            break;
        }
      }   
      else {
        if (baseDataFilter instanceof TopBottomDataFilter) {
          strParameterComparisonValues = 
            baseDataFilter.getAssociatedParameterName (TopBottomDataFilter.PARAMETER_COMPARISON_VALUE);
        }
        else {    
          strParameterComparisonValues = 
            baseDataFilter.getAssociatedParameterName (DataFilter.PARAMETER_COMPARISON_VALUES);
        }
    
        if (strParameterComparisonValues != null) {
          getJCheckBoxValueAsParam().setSelected (strParameterComparisonValues != null);
          getJTextFieldValueAsParam().setText (strParameterComparisonValues);       
          getJCheckBoxAcceptMultipleValues().setSelected (DataUtils.canAcceptMultipleValues (baseDataFilter));     
        }
      }
    }

    updateDeleteButtonState();        

    return dataFilterPanelValue;
  }

  public MDItem getItem (BaseDataFilter baseDataFilter) {
  
    MDItem mdItem = null;
   
    String strID = getItemID (baseDataFilter);
    if (strID != null) {
      MDObject mdObject = DataUtils.getMDObject (getContext(), strID);
      
      if (mdObject instanceof MDItem) {
        mdItem = (MDItem) mdObject;
      }
    }
    
    return mdItem;
  }

  public void setItem (MDItem mdItem) {
    setClass (DataFilterUtils.getClass (mdItem), mdItem);
 
    // Update Ignore Case checkbox
    updateIgnoreCaseState();
  }

  /**
   * Retrieves the maximum number of members that the specified comparison
   * operator can have. A value of -1 implies that there is no limit.
   * 
   * @param nCmpOperator A <code>int</code> representing the comparison operator.
   * 
   */
  public int getMaxMembers (int nCmpOperator) {
    int nMaxMembers = -1;

    /* No Limit
    DataFilter.OP_EQUAL
    DataFilter.OP_NOT_EQUAL
    DataFilter.OP_CONTAINS_ALL
    DataFilter.OP_BEGINS_WITH
    DataFilter.OP_ENDS_WITH
    DataFilter.OP_CONTAINS_ANY
    DataFilter.OP_DOES_NOT_CONTAIN
    DataFilter.OP_LIKE
    DataFilter.OP_NOT_LIKE
    */

    switch (nCmpOperator) {
      case DataFilter.OP_IS_NULL:
      case DataFilter.OP_IS_NOT_NULL:
        nMaxMembers = 0;
        break;

      case DataFilter.OP_GREATER:
      case DataFilter.OP_LESS:
      case DataFilter.OP_GREATER_EQUAL:
      case DataFilter.OP_LESS_EQUAL:
      case TopBottomDataFilter.OP_TOP:
      case TopBottomDataFilter.OP_BOTTOM:
        nMaxMembers = 1;
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        nMaxMembers = 2;
        break;
    }

    return nMaxMembers;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  protected Object getMember (Object object) {
    
    Object objMember = null;
    JComboBox jComboBoxItems = getJComboBoxItems();
    ComponentContext componentContext = getContext();
    
    if ((object != null) && (componentContext != null)) {
      // Retrieve the DataType          
      String strDataType = DataFilterUtils.getItemDatatype (jComboBoxItems);
      String strFormatMask = DataFilterUtils.getItemFormatMask (jComboBoxItems);
      Locale locale = componentContext.getLocale();
      ErrorHandler errorHandler = componentContext.getErrorHandler();

      // Check to see if we have a numeric item
      if (!MM.STRING.equals (strDataType)) {
        // If we have a numeric item, override the data type      
        if (object instanceof MDItem) {
          strDataType = MM.STRING;  
        }
        else if (object instanceof ComponentNode) {
          objMember = (ComponentNode)object;
        }
        else if (object instanceof String) {
          try {
            objMember = 
              DataUtils.parseMemberString ((String)object, strDataType, 
                strFormatMask, true, locale, errorHandler);
          }

          catch (Exception exception) {
            strDataType = MM.STRING;  
          }
        
          if (object instanceof String) {
            strDataType = MM.STRING;  
          }
        }
      }
    
      if (objMember == null) {             
        objMember = 
          DataUtils.parseMemberString (object.toString(), strDataType, 
            strFormatMask, true, locale, errorHandler);
      }
    }

    return objMember;
  }

  protected DefaultListModel getModel (JListMutable jListMutable) {
 
    DefaultListModel defaultListModel = null;       

    if (jListMutable != null) {
      defaultListModel = 
        ((DefaultListModel)jListMutable.getModel());
    }
 
    return defaultListModel;
  }

  protected Object getValue (BaseDataFilter baseDataFilter, DataFilterPanelValue dataFilterPanelValue) {
    Object objValue = null;
    
    if (baseDataFilter instanceof RangeDataFilter) {
      objValue = getValue ((RangeDataFilter) baseDataFilter, dataFilterPanelValue); 
    }

    return objValue;
  }

  protected Object getValue (RangeDataFilter rangeDataFilter, DataFilterPanelValue dataFilterPanelValue) {
    // Initialize the member
    Object objValue = null;
    
    if ((rangeDataFilter != null) && (dataFilterPanelValue != null)) {
      int nValueSubType = dataFilterPanelValue.getValueSubType();
    
      switch (nValueSubType) {
        case VALUES_FROM:
          objValue = rangeDataFilter.getStartValue();            
          break;
          
        case VALUES_TO:
          objValue = rangeDataFilter.getEndValue();            
          break;
          
        default:
          break;
      }
    }
  
    return objValue;
  }
  
  protected void updateDeleteButtonState (DataFilterControlBar dataFilterControlBar) {  
    boolean bEnabled = false;
  
    if (dataFilterControlBar != null) {
  
      if (dataFilterControlBar.getButtonDelete() != null) {
        JListMutable jListMutableMembers = 
          dataFilterControlBar.getButtonDelete().getJListMembers();
  
        if (jListMutableMembers != null) {
          int[] nSelectedIndices = jListMutableMembers.getSelectedIndices();
  
          if (nSelectedIndices.length > 0) {
            bEnabled = true;
          }
        }
      
        dataFilterControlBar.getButtonDelete().setEnabled (bEnabled);
      }
    }
  }

  protected void updateDeleteButtonState() {
  
    DataFilterControlBar dataFilterControlBar =
      getDataFilterPanelValue() != null ? 
        getDataFilterPanelValue().getDataFilterControlBar() : getDataFilterControlBar();  

    updateDeleteButtonState (dataFilterControlBar);
  }

  protected void updateParameterState() {  
    
    if ((getJTextFieldOperatorAsParam() != null) && (getJCheckBoxOperatorAsParam() != null)) {
      getJTextFieldOperatorAsParam().setEnabled (getJCheckBoxOperatorAsParam().isSelected());
    }

    if ((getJTextFieldValueAsParam() != null) && (getJCheckBoxValueAsParam() != null)) {
      getJTextFieldValueAsParam().setEnabled (getJCheckBoxValueAsParam().isSelected());
      getJCheckBoxAcceptMultipleValues().setEnabled (getJCheckBoxValueAsParam().isSelected());
    }
  }

  protected void updateMembers (BaseDataFilter baseDataFilter, Object[] objects) {  

    if (baseDataFilter instanceof DataFilter) {
      DataFilter dataFilter = (DataFilter)baseDataFilter;
      
      if ((objects != null) && (objects.length > 0)) {
        Vector vValues = new Vector();
  
        for (int nIndex = 0; nIndex < objects.length; nIndex++) {              
          vValues.add (objects [nIndex]);
        }
        
        dataFilter.setCmpValues (vValues);
      }
      else {
        dataFilter.setCmpValues (null);
      }
    }
    else if (baseDataFilter instanceof RangeDataFilter) {
      RangeDataFilter rangeDataFilter = (RangeDataFilter) baseDataFilter;
      
      DataFilterPanelValue dataFilterPanelValue = getDataFilterPanelValue();
      
      if (dataFilterPanelValue != null) {
  
        Object objSelected = null;
        if ((objects != null) && (objects.length > 0)) {
          objSelected = objects[0];
        }
      
        switch (dataFilterPanelValue.getValueSubType()) {
          case VALUES_FROM:
            rangeDataFilter.setStartValue (objSelected);
            refreshMember (objSelected, dataFilterPanelValue.getJListMembers());
            break;

          case VALUES_TO:
            rangeDataFilter.setEndValue (objSelected);
            refreshMember (objSelected, dataFilterPanelValue.getJListMembers());
            break;

          default:
            break;
        }
      }
      else {
        // Iterate over the list
        if ((objects != null) && (objects.length > 0)) {
          for (int nIndex = 0; nIndex < objects.length; nIndex++) {              
            switch (nIndex) {
              case 0:
                rangeDataFilter.setStartValue (objects [nIndex]);
                break;
                
              case 1:
                rangeDataFilter.setEndValue (objects [nIndex]);
                break;

              // Ignore any extra values                
              default:
                break;
            }
          }
        }
      }
    }
  }

  protected void updateOperator (BaseDataFilter baseDataFilter) {  

    OperatorDisplay operatorDisplay = 
      getCurrentOperator (getOperatorDisplays(), getDataFilterPanelModel());
      
    DataFilterUtils.setSelectedItem (getComboOperators(), operatorDisplay);
  }

  protected void updateMembers (BaseDataFilter baseDataFilter) {  
  
    try {   
      if (baseDataFilter instanceof DataFilter) {
        // Update the DataFilter members 
        getMembers (getJListMembers(), getJComboBoxItems(), 
          getDataFilterPanelModel().getContext(), (DataFilter)baseDataFilter);
      }
      else if (baseDataFilter instanceof TopBottomDataFilter)  {
        // Update the DataFilter members 
        getMembers (getJListMembers(), getJComboBoxItems(), 
          getDataFilterPanelModel().getContext(), (TopBottomDataFilter)baseDataFilter);
      }
      else if (baseDataFilter instanceof RangeDataFilter)  {
        // Update the DataFilter members 
        getMembers (getJListMembers(), getJComboBoxItems(), 
          getDataFilterPanelModel().getContext(), (RangeDataFilter)baseDataFilter);
      }
    }
    
    catch (Exception exception) {
      
    }
  }

  protected String getItemID (BaseDataFilter baseDataFilter) {
  
    String strID = null;
   
    if (baseDataFilter != null) {
      if (baseDataFilter instanceof DataFilter) {
        strID = ((DataFilter) baseDataFilter).getItem();
      }
      else if (baseDataFilter instanceof TopBottomDataFilter) {
        strID = ((TopBottomDataFilter) baseDataFilter).getItem();
      }
      else if (baseDataFilter instanceof RangeDataFilter) {
        strID = ((RangeDataFilter) baseDataFilter).getItem();
      }
    }
    
    return strID;
  }

  /**
   * Determines if the currently chosen item is a <code>MM.STRING</code> datatype.
   * 
   * @param jComboBoxItems
   * 
   * @return <code>boolean</code> which is <code>true</code> if the currently 
   *         chosen item is a <code>MM.STRING</code> datatype and <code>false</code>
   *         otherwise.
   *       
   */
  protected boolean isStringDataType (JComboBox jComboBoxItems) {

    // Retrieve the DataType          
    String strDataType = DataFilterUtils.getItemDatatype (jComboBoxItems);

    // Check to see if we have a numeric item
    return (MM.STRING.equals (strDataType));
  }

  /**
   * Makes a set of default operators.
   * 
   * @return <code>OperatorDisplay[]</code>.
   * 
   */
  protected OperatorDisplay[] makeOperatorDisplays() {
    OperatorDisplay[] operatorDisplays = null;
      
    OperatorDisplay operatorDisplay0 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_EQUAL));
    OperatorDisplay operatorDisplay1 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_NOT_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_EQUAL));
    OperatorDisplay operatorDisplay2 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER));
    OperatorDisplay operatorDisplay3 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS));
    OperatorDisplay operatorDisplay4 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS_EQUAL));
    OperatorDisplay operatorDisplay5 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER_EQUAL));
    OperatorDisplay operatorDisplay6 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_CONTAINS_ALL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ALL));
    OperatorDisplay operatorDisplay7 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_BEGINS_WITH), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BEGINS_WITH));
    OperatorDisplay operatorDisplay8 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_ENDS_WITH), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_ENDS_WITH));
    OperatorDisplay operatorDisplay9 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_CONTAINS_ANY), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_CONTAINS_ANY));
    OperatorDisplay operatorDisplay10 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_DOES_NOT_CONTAIN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_DOES_NOT_CONTAIN));
    OperatorDisplay operatorDisplay11 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LIKE), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LIKE));
    OperatorDisplay operatorDisplay12 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_NOT_LIKE), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_LIKE));
    OperatorDisplay operatorDisplay13 = 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_TOP), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_TOP));
    OperatorDisplay operatorDisplay14 = 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_BOTTOM), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BOTTOM));
    OperatorDisplay operatorDisplay15 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NULL));
    OperatorDisplay operatorDisplay16 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NOT_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_NULL));
    OperatorDisplay operatorDisplay17 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN));
    OperatorDisplay operatorDisplay18 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_NOT_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN));
    operatorDisplays = 
      new OperatorDisplay[] { 
        operatorDisplay0, operatorDisplay1, operatorDisplay2, operatorDisplay3, 
        operatorDisplay4, operatorDisplay5, operatorDisplay6, operatorDisplay7, operatorDisplay8, 
        operatorDisplay9, operatorDisplay10, operatorDisplay11, operatorDisplay12, 
        operatorDisplay13, operatorDisplay14, operatorDisplay15, operatorDisplay16,
        operatorDisplay17, operatorDisplay18};

    return operatorDisplays;
  }

  /**
   * Makes a set of default operators for numbers.
   * 
   * @return <code>OperatorDisplay[]</code>.
   * 
   */
  protected OperatorDisplay[] makeOperatorDisplaysNumber() {
    OperatorDisplay[] operatorDisplays = null;
      
    OperatorDisplay operatorDisplay0 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_EQUAL));
    OperatorDisplay operatorDisplay1 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_NOT_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_EQUAL));
    OperatorDisplay operatorDisplay2 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER));
    OperatorDisplay operatorDisplay3 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS));
    OperatorDisplay operatorDisplay4 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS_EQUAL));
    OperatorDisplay operatorDisplay5 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER_EQUAL));
    OperatorDisplay operatorDisplay6 = 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_TOP), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_TOP));
    OperatorDisplay operatorDisplay7 = 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_BOTTOM), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BOTTOM));
    OperatorDisplay operatorDisplay8 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NULL));
    OperatorDisplay operatorDisplay9 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NOT_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_NULL));
    OperatorDisplay operatorDisplay10 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN));
    OperatorDisplay operatorDisplay11 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_NOT_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN));
    operatorDisplays = 
      new OperatorDisplay[] { 
        operatorDisplay0, operatorDisplay1, operatorDisplay2, operatorDisplay3, 
        operatorDisplay4, operatorDisplay5, operatorDisplay6, operatorDisplay7, operatorDisplay8, 
        operatorDisplay9, operatorDisplay10, operatorDisplay11};

    return operatorDisplays;
  }

  /**
   * Makes a set of default operators for dates.
   * 
   * @return <code>OperatorDisplay[]</code>.
   * 
   */
  protected OperatorDisplay[] makeOperatorDisplaysDate() {
    OperatorDisplay[] operatorDisplays = null;
      
    OperatorDisplay operatorDisplay0 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_EQUAL));
    OperatorDisplay operatorDisplay1 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_NOT_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_NOT_EQUAL));
    OperatorDisplay operatorDisplay2 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER));
    OperatorDisplay operatorDisplay3 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS));
    OperatorDisplay operatorDisplay4 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_LESS_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_LESS_EQUAL));
    OperatorDisplay operatorDisplay5 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_GREATER_EQUAL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_GREATER_EQUAL));
    OperatorDisplay operatorDisplay6 = 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_TOP), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_TOP));
    OperatorDisplay operatorDisplay7= 
      new OperatorDisplay (Integer.toString (TopBottomDataFilter.OP_BOTTOM), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_BOTTOM));
    OperatorDisplay operatorDisplay8 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NULL));
    OperatorDisplay operatorDisplay9 = 
      new OperatorDisplay (Integer.toString (DataFilter.OP_IS_NOT_NULL), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_NULL));
    OperatorDisplay operatorDisplay10 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_BETWEEN));
    OperatorDisplay operatorDisplay11 = 
      new OperatorDisplay (Integer.toString (RangeDataFilter.OP_NOT_BETWEEN), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OP_IS_NOT_BETWEEN));
    operatorDisplays = 
      new OperatorDisplay[] { 
        operatorDisplay0, operatorDisplay1, operatorDisplay2, operatorDisplay3, 
        operatorDisplay4, operatorDisplay5, operatorDisplay6, operatorDisplay7, operatorDisplay8, 
        operatorDisplay9, operatorDisplay10, operatorDisplay11};

    return operatorDisplays;
  }

  /**
   * Make a <code>TopBottomDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   */
  protected BaseDataFilter makeTopBottomDataFilter (String strItemID, int nCmpOperator) throws Exception {

    // If an item ID has not been specified, use the default
    if (strItemID == null) {
      strItemID = DataFilterUtils.getItemId (getJComboBoxItems());
    }

    TopBottomDataFilter topBottomDataFilter = new TopBottomDataFilter();
    topBottomDataFilter.setItem (strItemID);
    topBottomDataFilter.setOperator (nCmpOperator);
    
    // Update the DataFilter operator parameter
    if (getJCheckBoxOperatorAsParam().isSelected()) {
     DataUtils.updateParametersOperator (topBottomDataFilter, 
       getJTextFieldOperatorAsParam().getText(), topBottomDataFilter.getOperator());
    }

    // Ignore Case checkbox   
    topBottomDataFilter.setIgnoreCase (
      getDataFilterPanelValue().getJCheckBoxIgnoreCase().isSelected());

    // Update the DataFilter members 
    if (getDataFilterPanelModel() != null) {
      getMembers (getJListMembers(), getJComboBoxItems(), 
        getDataFilterPanelModel().getContext(), topBottomDataFilter, getMaxMembers (nCmpOperator));
    }

    // Process Value Parameters
    if (getJCheckBoxValueAsParam().isSelected()) {

      String strParameterValuesName = getJTextFieldValueAsParam().getText();
  
      if (strParameterValuesName != null) {
      
        // Update the TopBottomDataFilter parameters 
        DataUtils.updateParameters (topBottomDataFilter, strParameterValuesName, 
          topBottomDataFilter.getValue(), getJCheckBoxAcceptMultipleValues().isSelected());
      }
    }

    return topBottomDataFilter;
  }

  /**
   * Make a <code>RangeDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   */
  protected BaseDataFilter makeRangeDataFilter (String strItemID, int nCmpOperator) {

    // If an item ID has not been specified, use the default
    if (strItemID == null) {
      strItemID = DataFilterUtils.getItemId (getJComboBoxItems());
    }

    RangeDataFilter rangeDataFilter = new RangeDataFilter();
    rangeDataFilter.setItem (strItemID);
    rangeDataFilter.setOperator (nCmpOperator);
    
    // Update the DataFilter operator parameter
    if (getJCheckBoxOperatorAsParam().isSelected()) {
     DataUtils.updateParametersOperator (rangeDataFilter, 
       getJTextFieldOperatorAsParam().getText(), rangeDataFilter.getOperator());
    }

    // Ignore Case checkbox   
    rangeDataFilter.setIgnoreCase (
      getDataFilterPanelValue().getJCheckBoxIgnoreCase().isSelected());

    // Update From member
    DataFilterPanelValue dataFilterPanelValueFrom = getTabbedPaneFromValue (VALUES_FROM);
    if (dataFilterPanelValueFrom != null) {
      JListMutable jListMutable = dataFilterPanelValueFrom.getJListMembers();      
      DefaultListModel defaultListModel = getModel (jListMutable);
      
      if (defaultListModel != null) {
        if (defaultListModel.getSize() > 0) {
          Object objStartValue = getMember (defaultListModel.getElementAt(0));
          rangeDataFilter.setStartValue (objStartValue);  
        }
      }

      // Process Value Parameters
      if (dataFilterPanelValueFrom.getJCheckBoxValueAsParam().isSelected()) {
  
        String strParameterValuesName = 
          dataFilterPanelValueFrom.getJTextFieldValueAsParam().getText();
    
        if (strParameterValuesName != null) {
        
          // Update the TopBottomDataFilter Start Parameter 
          DataUtils.updateParameterStart (rangeDataFilter, strParameterValuesName, 
            rangeDataFilter.getStartValue(), getJCheckBoxAcceptMultipleValues().isSelected());
        }
      }
    }
    
    // Update To member
    DataFilterPanelValue dataFilterPanelValueTo = getTabbedPaneFromValue (VALUES_TO);
    if (dataFilterPanelValueTo != null) {
      JListMutable jListMutable = dataFilterPanelValueTo.getJListMembers();      
      DefaultListModel defaultListModel = getModel (jListMutable);
      
      if (defaultListModel != null) {
        if (defaultListModel.getSize() > 0) {
          Object objEndValue = getMember (defaultListModel.getElementAt(0));
          rangeDataFilter.setEndValue (objEndValue);  
        }
      }

      // Process Value Parameters
      if (dataFilterPanelValueTo.getJCheckBoxValueAsParam().isSelected()) {
  
        String strParameterValuesName = 
          dataFilterPanelValueTo.getJTextFieldValueAsParam().getText();
    
        if (strParameterValuesName != null) {
        
          // Update the TopBottomDataFilter Start Parameter 
          DataUtils.updateParameterEnd (rangeDataFilter, strParameterValuesName, rangeDataFilter.getEndValue());
        }
      }
    }
  
    return rangeDataFilter;
  }

  /**
   * Make a <code>DataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param strItemID A <code>String</code> representing the <code>MetadataManager</code>
   *        item ID.
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison operator.
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * @throws <code>Exception</code>
   * 
   */
  protected BaseDataFilter makeDataFilter (String strItemID, int nCmpOperator) throws Exception {

    // If an item ID has not been specified, use the default
    if (strItemID == null) {
      strItemID = DataFilterUtils.getItemId (getJComboBoxItems());
    }

    DataFilter dataFilter = new DataFilter();
    dataFilter.setItem(strItemID);
    dataFilter.setCmpOperator (nCmpOperator);

    // Update the DataFilter operator parameter
    if (getJCheckBoxOperatorAsParam().isSelected()) {
     DataUtils.updateParametersOperator (dataFilter, 
       getJTextFieldOperatorAsParam().getText(), dataFilter.getCmpOperator());
    }
    
    // Ignore Case checkbox   
    dataFilter.setIgnoreCase (
      getDataFilterPanelValue().getJCheckBoxIgnoreCase().isSelected());

    // Update the DataFilter members 
    if (getDataFilterPanelModel() != null) {
      getMembers (getJListMembers(), getJComboBoxItems(), 
        getDataFilterPanelModel().getContext(), dataFilter, getMaxMembers (nCmpOperator));
    }
    
    // Process Value Parameters
    if (getJCheckBoxValueAsParam().isSelected()) {

      String strParameterValuesName = getJTextFieldValueAsParam().getText();
  
      if (strParameterValuesName != null) {
      
        // Update the DataFilter parameters 
        DataUtils.updateParameters (dataFilter, strParameterValuesName, 
          dataFilter.getCmpValues(), getJCheckBoxAcceptMultipleValues().isSelected());
      }
    }

    return dataFilter;
  }

  /**
   * Update the DataFilter members based on those selected in the 
   * TreeListCombo.
   * 
   * @param jListMembers A <code>jListMembers</code> to check.
   * 
   */
  // TODO
  protected void refreshMembers (JList jListMembers) {
  }

  protected Vector getMemberList() {
    Vector vMembers = new Vector();
    
    JListMutable jListMutableMembers = getJListMembers();
    if (jListMutableMembers != null) {
      int nSize = jListMutableMembers.getModel().getSize();
      
      for (int nIndex = 0; nIndex < nSize; nIndex++) {
        vMembers.add (jListMutableMembers.getModel().getElementAt (nIndex));  
      }
    }

    return vMembers;
  }

  /*
  protected void refreshMembers (TreeListCombo treeListComboMembers) {
    
    String strMembers = null;

    // Refresh the TreeListComboMembers
    if (treeListComboMembers != null) {
      JTree jTree = treeListComboMembers.getTree();
      
      if (jTree != null) {
        Vector vSelectedItems = getSelectedItems (treeListComboMembers.getTree());
  
        strMembers = DataUtils.makeMembersLabel (vSelectedItems, true);
    
        // TODO
        // DataFilterUtils.setCurrentMembers (getJListMembers(), strMembers);
    
        QBUtils.updateDataFilterMembers (getContext());
      }
    }
  }
  */

  protected void setOperatorDisplays (OperatorDisplay[] operatorDisplays) {
    m_operatorDisplays = operatorDisplays;
  }

  protected OperatorDisplay[] getOperatorDisplays() {
    return m_operatorDisplays;
  }

  protected void setJListMembers (JListMutable jListMembers) {
    m_jListMembers = jListMembers;
  }

  protected JListMutable getJListMembers() {
    return m_jListMembers;
  }

  protected JComboBox getComboOperators() {
    return m_jComboBoxOperators;
  }

  protected void setComboOperators (JComboBox jComboBoxOperators) {
    m_jComboBoxOperators = jComboBoxOperators;
  }

  protected JComboBox getJComboBoxItems() {
    return m_jComboBoxItems;
  }

  protected void setJComboBoxItems (JComboBox jComboBoxItems) {
    m_jComboBoxItems = jComboBoxItems;
  }

  protected JCheckBox getJCheckBoxValueAsParam() {
    return m_jCheckBoxValueAsParam;
  }

  protected void setJCheckBoxValueAsParam (JCheckBox jCheckBoxValueAsParam) {
    m_jCheckBoxValueAsParam = jCheckBoxValueAsParam;
  }

  protected JCheckBox getJCheckBoxAcceptMultipleValues() {
    return m_jCheckBoxAccepMultipleValues;
  }

  protected void setJCheckBoxAcceptMultipleValues (JCheckBox jCheckBoxAccepMultipleValues) {
    m_jCheckBoxAccepMultipleValues = jCheckBoxAccepMultipleValues;
  }

  protected JTextField getJTextFieldValueAsParam() {
    return m_jTextFieldValueAsParam;
  }

  protected void setJTextFieldValueAsParam (JTextField jTextFieldValueAsParam) {
    m_jTextFieldValueAsParam = jTextFieldValueAsParam;
  }

  protected void setJCheckBoxOperatorAsParam (JCheckBox jCheckBoxOperatorAsParam) {
    m_jCheckBoxOperatorAsParam = jCheckBoxOperatorAsParam;
  }

  protected JCheckBox getJCheckBoxOperatorAsParam() {
    return m_jCheckBoxOperatorAsParam;
  }

  protected JTextField getJTextFieldOperatorAsParam() {
    return m_jTextFieldOperatorAsParam;
  }

  protected void setJTextFieldOperatorAsParam (JTextField jTextFieldOperatorAsParam) {
    m_jTextFieldOperatorAsParam = jTextFieldOperatorAsParam;
  }

  protected void setMDItem (MDItem mdItem) {
    m_mdItem = mdItem;
  }

  protected MDItem getMDItem() {
    return m_mdItem;
  }

  protected void setClass (Class classType, MDItem mdItem) {
    setClass (classType, mdItem, getJListMembers(), getContext(), getDataFilterPanelModel());   
  }

  protected void setClass (Class classType, MDItem mdItem, JList jListMembers, 
    ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
    MDItem mdItemOld = getMDItem();
    setMDItem (mdItem);          
    
    if (mdItem != null) {

      // If we have updated the item, update the associated members
      if (mdItemOld != mdItem) {
        
        /*
        // Disable the browse button for numeric items
        if (getButtonBrowse() != null) {
          getButtonBrowse().setEnabled (!DataUtils.isNumeric (mdItem));
        }
        */
        
        try {  
          refreshMembers();
          updateModel();
          updateOperators (getComboOperators(), getMDItem());
          updateValueButtonState();
          updateBrowseButtonState(); 
        }
        
        catch (Exception exception) {
          Logger.getLogger ("oracle.dss.queryBuilder.BaseDataFilterPanel").log (Level.INFO, 
            "setClass (Class, MDItem, JList, ComponentContext, DataFilterPanelModel) failed.", exception);
        }
      }
    }
    else {
      setMDItem (null);
    }
  }
  
  // TODO Remove TreeListCombo
  protected void setClass (Class classType, MDItem mdItem, JTextField jTextFieldMembers, 
    ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
      
    MDItem mdItemOld = getMDItem();
    setMDItem (mdItem);          
    
    if ((mdItem != null) && (jTextFieldMembers != null)) {

      // TODO Remove TreeListCombo
      /*
      ComboBoxModel comboBoxModel = treeListComboMembers.getModel();  

      // If we have update the item, update the associated members
      if (mdItemOld != mdItem) {
        String strDataType = (mdItem != null) ? mdItem.getDatatype() : null;
        String strDataTypeOld = (mdItemOld != null) ? mdItemOld.getDatatype() : null;

        // Determine if we need to update the model based on the MDItem data types
        if (mdItemOld == null || MM.STRING.equals (strDataType) || MM.STRING.equals(strDataTypeOld)) { 
          
          comboBoxModel = 
            new TreeListComboBoxModelMembers (componentContext);
      
          treeListComboMembers.setModel (comboBoxModel);
          ((TreeListComboBoxModelMembers)comboBoxModel).setTreeListComboMembers (treeListComboMembers);
          ((TreeListComboBoxModelMembers)comboBoxModel).setItem (mdItem);
        }
      }
      */

      if (String.class == classType) {
        // gek 02/28/07 Retrieve the current DataFilter, if any
        BaseDataFilter dataFilter = dataFilterPanelModel.getDataFilter();
        
        if (dataFilter != null) {
          ItemItemsTreeNode itemItemsTreeNodeRoot = 
            new ItemItemsTreeNode (null, mdItem, componentContext);

          itemItemsTreeNodeRoot.addDataFilter (dataFilter);
        }
           
        if (dataFilter != null) {
          //// TODO
          // treeListComboMembers.setSelectedItem (dataFilter);
        }
      }
    }
    else {
      setMDItem (null);
    }
  }

  protected void updateValueButtonState() {
    DataFilterPanelValue dataFilterPanelValue = getDataFilterPanelValue();
    DataFilterPanelButton dataFilterPanelButtonAdd = null;
    
    if (dataFilterPanelValue != null) {
     
      DataFilterPanelValue dataFilterPanelValueFrom = getTabbedPaneFromValue (VALUES_FROM);
      if (dataFilterPanelValueFrom != null) {
        if (dataFilterPanelValueFrom.getDataFilterControlBar() != null) {
          dataFilterPanelButtonAdd = 
            dataFilterPanelValueFrom.getDataFilterControlBar().getButtonAdd();    
        }

        if (dataFilterPanelButtonAdd != null) {
          dataFilterPanelButtonAdd.setEnabled (
            !dataFilterPanelButtonAdd.getLimitReached (dataFilterPanelValueFrom.getJListMembers()));
        }
      }     
     
      DataFilterPanelValue dataFilterPanelValueTo = getTabbedPaneFromValue (VALUES_TO);
      if (dataFilterPanelValueTo != null) {
        if (dataFilterPanelValueTo.getDataFilterControlBar() != null) {
          dataFilterPanelButtonAdd = 
            dataFilterPanelValueTo.getDataFilterControlBar().getButtonAdd();    
        }

        if (dataFilterPanelButtonAdd != null) {
          dataFilterPanelButtonAdd.setEnabled (
            !dataFilterPanelButtonAdd.getLimitReached (dataFilterPanelValueTo.getJListMembers()));
        }
      }     
    }
    else {
      if (getDataFilterControlBar() != null) {
        dataFilterPanelButtonAdd = getDataFilterControlBar().getButtonAdd();    
      }
  
      if (dataFilterPanelButtonAdd != null) {
        dataFilterPanelButtonAdd.setEnabled (
          !dataFilterPanelButtonAdd.getLimitReached());
      }
    }
  }            

  /**
   * Update the available operators based on the currently selected item.
   * 
   * @param jComboBoxOperators A <code>JComboBox</code>
   * @param mdItem A <code>MDItem</code> mdItem
   * 
   */
  protected void updateOperators (JComboBox jComboBoxOperators, MDItem mdItem) {

    OperatorDisplay[] operatorDisplays = null;

    if ((mdItem != null) && (jComboBoxOperators != null)) {
      
      if (MM.DATE.equals (mdItem.getDatatype())) {
        operatorDisplays = makeOperatorDisplaysDate();
      }
      else if (DataUtils.isNumeric (mdItem)) {
        operatorDisplays = makeOperatorDisplaysNumber();
      } 
      else {
        operatorDisplays = makeOperatorDisplays();
      }
   
      // Remember initial selected value
      Object objItemSelected = jComboBoxOperators.getSelectedItem();

      // Update the list of available operators
      setOperatorDisplays (operatorDisplays);
      jComboBoxOperators.setModel (new DefaultComboBoxModel (getOperatorDisplays()));
      
      // Attempt to find initial selected value in new list
      if (objItemSelected != null) {
        objItemSelected = findOperator (objItemSelected, getOperatorDisplays());

        if (objItemSelected != null) {
          jComboBoxOperators.setSelectedItem (objItemSelected);  
        }
      }
    }
  }

  protected OperatorDisplay findOperator (Object objOperator, OperatorDisplay[] operatorDisplays) {
    OperatorDisplay operatorDisplayFound = null;

    if ((objOperator != null) && (operatorDisplays != null)) {
      String strOperatorDisplay = objOperator.toString();
      OperatorDisplay operatorDisplay = null;

      for (int nIndex = 0; nIndex < operatorDisplays.length; nIndex++) {
        operatorDisplay = operatorDisplays[nIndex];

        if (operatorDisplay != null) {
          if (strOperatorDisplay.equals (operatorDisplay.toString())) {
            operatorDisplayFound = operatorDisplay;
            break;   
          }  
        }
      }  
    }  

    return operatorDisplayFound;
  }  

  /**
   * Update the state of the browse button based on the currently selected item.
   * 
   */
  protected void updateBrowseButtonState() {
    boolean bEnabled = false;

    // Only enable browse button for non-date items
    MDItem mdItem = getMDItem();
    if (mdItem != null) {
      bEnabled = !(MM.DATE.equals (mdItem.getDatatype()));
    }

    DataFilterPanelButton dataFilterPanelButton = getButtonBrowse();
    if (dataFilterPanelButton != null) {
      dataFilterPanelButton.setEnabled (bEnabled);
    }
  }

  protected DataFilterPanelButton getButtonBrowse() {
    DataFilterPanelButton dataFilterPanelButton = null;
    
    DataFilterPanelValue dataFilterPanelValue = getDataFilterPanelValue();

    if (dataFilterPanelValue != null) {
      DataFilterControlBar dataFilterControlBar = 
        dataFilterPanelValue.getDataFilterControlBar();  
        
      if (dataFilterControlBar != null) {
        dataFilterPanelButton = dataFilterControlBar.getButtonBrowse();
      }
    }  
  
    return dataFilterPanelButton;
  }

  protected void updateIgnoreCaseState (JCheckBox jCheckBoxIgnoreCase) {
    BaseDataFilter baseDataFilter = getDataFilter();
    
    if (jCheckBoxIgnoreCase != null) {
      if (isStringDataType (getJComboBoxItems())) {
        jCheckBoxIgnoreCase.setSelected (
          baseDataFilter != null ? baseDataFilter.isIgnoreCase() : false);
        jCheckBoxIgnoreCase.setEnabled (true);
      }
      else {
        jCheckBoxIgnoreCase.setSelected (false);
        jCheckBoxIgnoreCase.setEnabled (false);
      }
    }
  }
  
  protected void updateIgnoreCaseState() {
    DataFilterPanelValue dataFilterPanelValue = getDataFilterPanelValue();
    DataFilterPanelButton dataFilterPanelButtonAdd = null;
    
    if (dataFilterPanelValue != null) {
      JCheckBox jCheckBoxIgnoreCase = dataFilterPanelValue.getJCheckBoxIgnoreCase(); 
      updateIgnoreCaseState (jCheckBoxIgnoreCase);

      DataFilterPanelValue dataFilterPanelValueFrom = getTabbedPaneFromValue (VALUES_FROM);
      if (dataFilterPanelValueFrom != null) {
        jCheckBoxIgnoreCase = dataFilterPanelValueFrom.getJCheckBoxIgnoreCase(); 
        updateIgnoreCaseState (jCheckBoxIgnoreCase);
      }     
     
      DataFilterPanelValue dataFilterPanelValueTo = getTabbedPaneFromValue (VALUES_TO);
      if (dataFilterPanelValueTo != null) {
        jCheckBoxIgnoreCase = dataFilterPanelValueTo.getJCheckBoxIgnoreCase(); 
        updateIgnoreCaseState (jCheckBoxIgnoreCase);
      }     
    }
  }            

  /**
   * Determines if the <code>DataFilter</code> associated with the 
   * <code>DataFilterPanelModel</code> contains a parameter.
   * 
   * @return <code>boolean</code> which is <code>true</code> when a parameter
   *         is present and <code>false</code> otherwise.
   * 
   */
  protected boolean hasParameter() {
    boolean bHasParameter = false;
    
    BaseDataFilter baseDataFilter = null;
    String[] strParameterNames = null;

    if (getDataFilterPanelModel() != null){
      baseDataFilter = getDataFilterPanelModel().getDataFilter();

      if (baseDataFilter != null) {
        strParameterNames = baseDataFilter.getParameterNames();

        if ((strParameterNames != null) && (strParameterNames.length != 0)) {
          bHasParameter = true;  
        }               
      }
    }

    return bHasParameter;
  }

  /**
   * Update the members <code>TreeListCombo</code> using the specified text.
   * 
   * @param strText A <code>String</code> to update the <code>TreeListCombo</code> with.
   * 
   */
  protected static void updateListMembers (JList jListMembers, String strText) {
    // TODO
    /*
    treeListComboMembers.setText (strText);
    
    Component editorComponent = 
      treeListComboMembers.getEditor().getEditorComponent();
    
    if (editorComponent instanceof JTextField) {
     ((JTextField)editorComponent).setText (strText);
    }
    */
  }

  // TODO Remove TreeListCombo
  protected static void updateTextFieldMembers (JTextField jTextFieldMembers, String strText) {
    if (jTextFieldMembers != null) {
     jTextFieldMembers.setText (strText);
    }
  }

  private void updateDataFilter(Object[] objects) {
  }

  /**
   * @internal
   * 
   */
  protected class DataFilterPanelMemberPopupMenuListener implements PopupMenuListener {
    /**
     *  This method is called before the popup menu becomes visible 
     */
    public void popupMenuWillBecomeVisible (PopupMenuEvent popupMenuEvent) {
    }

    /**
     * This method is called before the popup menu becomes invisible
     * Note that a JPopupMenu can become invisible any time 
     */
    public void popupMenuWillBecomeInvisible (PopupMenuEvent popupMenuEvent) {
      
      // Make sure model is up to date in case user cancels
      if (getJListMembers() != null) {
        String strParameterOption = 
          getResourceString (QueryBuilderBundle.BASEDATAFILTERPANEL_PARAMETER_OPTION);

        // TODO
        /*
        if (strParameterOption != null) {
          if (!strParameterOption.equals (getJListMembers().getText())) {
            updateModel();
          }
        }
        */
      }
  
      refreshMembers (getJListMembers());
    }

    /**
     * This method is called when the popup menu is canceled
     */
    public void popupMenuCanceled (PopupMenuEvent popupMenuEvent) {
    }
  }

  /**
   * @internal
   * 
   */
  protected class DataFilterPanelMemberListener implements ItemListener {
  
    /**
     * <pre>
     * Invoked when an item has been selected or deselected by the user.
     * 
     * The code written for this method performs the operations
     * that need to occur when an item is selected (or deselected).
     * </pre>
     *
     * @param itemEvent A <code>ItemEvent</code>
     * 
     */    
    public void itemStateChanged (ItemEvent itemEvent) {
      try {
        processMember (itemEvent);
      }
      
      catch (Exception exception) {
        Logger.getLogger ("oracle.dss.queryBuilder.BaseDataFilterPanel").log (Level.INFO, 
          "itemStateChanged (itemEvent) failed.", exception);
      }
    }
  }

  protected boolean isParameter (Object object) {
    boolean bIsParameter = false;

    String strParameterOption = 
      getResourceString (QueryBuilderBundle.BASEDATAFILTERPANEL_PARAMETER_OPTION);

    if (strParameterOption != null) {
      if (strParameterOption.equals (object)) {
        bIsParameter = true;
      }    
    }

    return bIsParameter;
  }

  protected void processMember (ItemEvent itemEvent) throws Exception {
    if (itemEvent != null) {
      Object objectItem = itemEvent.getItem();
  
      if (isParameter (objectItem)) {
        invokeParameterDialog (itemEvent, getMDItem());
      }
      /*
      else if (objectItem instanceof TreeListComboBoxModelMembers.SelectItems) {
        invokeItemsDialog (itemEvent, BaseDataFilterPanel.ITEMS_DIALOG_NUMERIC);
      }
      */
      else {
        if ((itemEvent != null) && (itemEvent.getStateChange() == ItemEvent.SELECTED)) {
        
          if (objectItem instanceof MDItem) {
            setItem ((MDItem)objectItem);
          }
        }
      } 
    }
  }

  /**
   * @internal
   * 
   */
  protected class DataFilterPanelItemListener implements ItemListener {
   
    /**
     * <pre>
     * Invoked when an item has been selected or deselected by the user.
     * 
     * The code written for this method performs the operations
     * that need to occur when an item is selected (or deselected).
     * </pre>
     *
     * @param itemEvent A <code>ItemEvent</code>
     * 
     */    
    public void itemStateChanged (ItemEvent itemEvent) {
      processItem (itemEvent);
    }
  }

  /**
   * Process the <code>ItemEvent</code>
   * 
   * @param itemEvent A <code>ItemEvent</code> to process.
   * 
   */
  protected void processItem (ItemEvent itemEvent) {
    Object objectItem = itemEvent.getItem();

    if ((itemEvent != null) && (itemEvent.getStateChange() == ItemEvent.SELECTED)) {
    
      if (objectItem instanceof MDItem) {
        setItem ((MDItem)objectItem);
      }
      else {
        if (objectItem instanceof MoreItems) {
          invokeItemsDialog (itemEvent, BaseDataFilterPanel.ITEMS_DIALOG_ALL);  
        }   
      } 
    }
  }

  /**
   * Invoke the default Select Values Dialog.
   * 
   * @return <code>Object[]</code> representing the objects selected.
   *
   */
  protected Object[] invokeSelectValuesDialog() throws Exception {
    // Make sure that the DataFilter is updated.
    updateModel();
    return (invokeSelectValuesDialog (null));
  }

  /**
   * Invoke the Select Items Dialog.
   * 
   * @param baseDataFilterSelected A <code>BaseDataFilter</code> representing the
   *        current one selected.
   * 
   * @return <code>Object[]</code> representing the objects selected.
   * 
   */
  protected Object[] invokeSelectItemsDialog (BaseDataFilter baseDataFilterSelected) throws Exception {

    Object[] objectsSelected = null;
    
    SelectItemsDialog selectItemsDialog = 
      SelectItemsDialog.createSelectItemsDialog (getContext());
    
    MDItem mdItem = 
      (baseDataFilterSelected != null) ? getItem (baseDataFilterSelected) : getMDItem();  
    
    SelectItemsPanel selectItemsPanel = 
      new SelectItemsPanel ((QueryBuilderContext)getContext(), mdItem, 
        null, baseDataFilterSelected);
        
    selectItemsPanel.setPanelParent (getDataFilterPanelValue());      

    selectItemsPanel.initialize();

    HelpUtils.setHelpID (selectItemsPanel, SelectItemsDialog.SELECT_ITEMS_DIALOG_HELP_CONTEXT_ID);    
    selectItemsDialog.setContent (selectItemsPanel);

    // Check if user selected OK
    if (selectItemsDialog.display (BaseDataFilterPanel.this) == StandardDialog.OK) {
      ShuttlePanel shuttlePanel = selectItemsPanel.getShuttlePanelSelected();
      
      if (shuttlePanel != null) {
        if (shuttlePanel.getShuttleComponent() != null) {
          objectsSelected = shuttlePanel.getShuttleComponent().getAllItems();
        }
      }
    }
  
    return objectsSelected;
  }

  /**
   * Invoke the Select Values Dialog.
   * 
   * @param baseDataFilterSelected A <code>BaseDataFilter</code> representing the
   *        current one selected.
   * 
   * @return <code>Object[]</code> representing the objects selected.
   * 
   */
  protected Object[] invokeSelectValuesDialog (BaseDataFilter baseDataFilterSelected) throws Exception {

    Object[] objectsSelected = null;
    
    SelectValuesDialog selectValuesDialog = 
      SelectValuesDialog.createSelectValuesDialog (getContext());
    
    MDItem mdItem = 
      (baseDataFilterSelected != null) ? getItem (baseDataFilterSelected) : getMDItem();  
    
    SelectValuesPanel selectValuesPanel = 
      new SelectValuesPanel ((QueryBuilderContext)getContext(), mdItem, 
        null, baseDataFilterSelected);

    selectValuesPanel.setPanelParent (getDataFilterPanelValue());      

    selectValuesPanel.initialize();

    HelpUtils.setHelpID (selectValuesPanel, SelectValuesDialog.SELECT_VALUES_DIALOG_HELP_CONTEXT_ID);    
    selectValuesDialog.setContent (selectValuesPanel);

    // Check if user selected OK
    if (selectValuesDialog.display (BaseDataFilterPanel.this) == StandardDialog.OK) {
      ShuttlePanel shuttlePanel = selectValuesPanel.getShuttlePanelSelected();
      
      if (shuttlePanel != null) {
        if (shuttlePanel.getShuttleComponent() != null) {
          objectsSelected = shuttlePanel.getShuttleComponent().getAllItems();
        }
      }
    }
  
    return objectsSelected;
  }
  
  /**
   * Invoke the Items Dialog.
   * 
   * @param componentParent A <code>Component</code> that represents the parent.
   * @param nItemTypes A <code>int</code> that represents the items to show which
   *        include all, numeric and string.
   * 
   * @return <code>Object[]</code> representing the objects selected.
   * 
   * @see #ITEMS_DIALOG_ALL
   * @see #ITEMS_DIALOG_NUMERIC
   * @see #ITEMS_DIALOG_STRING
   * 
   */
  protected Object[] invokeItemsDialog (int nItemTypes, Component componentParent) {
    Object[] objectsSelected = null;
    StandardDialog standardDialog = null;
  
    AvailableItemsTree availableItemsTree = makeAvailableItemsTree (nItemTypes);

    Window window = 
      SwingUtilities.windowForComponent (componentParent);
  
    String strTitle = 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_SELECT_ITEM_TITLE);  

    availableItemsTree.getSelectionModel().setSelectionMode (TreeSelectionModel.SINGLE_TREE_SELECTION);
  
    SelectShuttlePanel selectShuttlePanel = 
      new SelectShuttlePanel (getContext(), availableItemsTree);
    
    HelpUtils.setHelpID (selectShuttlePanel, SelectItemsDialog.SELECT_ITEMS_DIALOG_HELP_CONTEXT_ID);      
            
    if (window instanceof Frame) {
      standardDialog = 
        new StandardDialog ((Frame)window, strTitle, true, selectShuttlePanel);
    }
    else if (window instanceof Dialog) {
      standardDialog = 
        new StandardDialog ((Dialog)window, strTitle, true, selectShuttlePanel);
    }
    else {
      standardDialog = 
        new StandardDialog ((Frame)null, strTitle, true, selectShuttlePanel);
    }
            
    // Check if user selected OK
    if (standardDialog.display (BaseDataFilterPanel.this) == standardDialog.OK) {
      objectsSelected = availableItemsTree.getSelectedItems();
    }

    if (getContext() != null) {
      getContext().remove (ComponentContext.SEARCH_MATCHER);
    }

    return objectsSelected;
  }

  /**
   * Invoke the Items Dialog.
   * 
   * @param itemEvent A <code>ItemEvent</code> associated with the Items Dialog
   *        invocation.
   * @param nItemTypes A <code>int</code> that represents the items to show which
   *        include all, numeric and string.
   * 
   * @see #ITEMS_DIALOG_ALL
   * @see #ITEMS_DIALOG_NUMERIC
   * @see #ITEMS_DIALOG_STRING
   * 
   */
  protected void invokeItemsDialog (ItemEvent itemEvent, int nItemTypes) {
    Object[] objectsSelected = null;
    StandardDialog standardDialog = null;
  
    if ((itemEvent != null) && (itemEvent.getStateChange() == ItemEvent.SELECTED)) {

      JComboBox jComboBox = null;

      Object objectItem = itemEvent.getItem();
      if (objectItem instanceof MoreItems) {
        jComboBox = ((MoreItems) objectItem).getComboBox();   
      }
      /*
      else if (objectItem instanceof TreeListComboBoxModelMembers.SelectItems) {
        jComboBox = 
          ((TreeListComboBoxModelMembers.SelectItems) objectItem).getTreeListCombo();   
      }
      */

      objectsSelected = invokeItemsDialog (nItemTypes, jComboBox);
      
      // Check if user selected OK
      if (objectsSelected != null) {
        jComboBox = null;
        
        if (itemEvent.getSource() instanceof JComboBox) {
          jComboBox = (JComboBox) itemEvent.getSource();
        }
     
        updateDataFilter (objectsSelected, jComboBox);
      }
      else {
        DataFilterUtils.setSelectedItem (jComboBox, getMDItem());
        jComboBox.repaint();
      }            
    }
  }

  /**
   * Make a <code>AvailableItemsTree</code>.
   * 
   * @param nItemTypes A <code>int</code> representing the item types to include.
   * 
   * @return <code>AvailableItemsTree</code>
   * 
   */
  protected AvailableItemsTree makeAvailableItemsTree (int nItemTypes) {

    AvailableItemsTree availableItemsTree = 
      new AvailableItemsTree (getContext());
      
    if (availableItemsTree != null) {
      try {
        // Retrieve the Connection from the DataFilterPanelModel to initialize
        // the list of MDItems
        DataFilterPanelModel dataFilterPanelModel = getDataFilterPanelModel();
       
        Connection connection = 
          (dataFilterPanelModel != null) ? dataFilterPanelModel.getConnection() : null;  

        DatasourceItemsTreeNode datasourceItemsTreeNode= 
          new DatasourceItemsTreeNode (availableItemsTree, connection, getContext());
        
        // Add a MetadataFilter if needed
        if (makeMetadataFilter (datasourceItemsTreeNode, nItemTypes) != null) {
          datasourceItemsTreeNode.refresh();
        }

        // Add the generated node to the tree
        availableItemsTree.setRoot (datasourceItemsTreeNode);
      }
      
      catch (Throwable throwable) {
        QBUtils.processError (getContext(), throwable, this.getClass(), "processItem (ItemEvent)");
      }

      // Set the default number of nodes to display at a time
      availableItemsTree.setVisibleRowCount (ITEMS_DIALOG_DEFAULT_COUNT);

    }

    return availableItemsTree;
  }

  /**
   * Invoke the Items Dialog.
   * 
   * @param jComboBoxItems A <code>JComboBox</code> containing the Item that
   *        we want to show members for.
   * @param nItemTypes A <code>int</code> that represents the items to show which
   *        include all, numeric and string.
   * 
   * @see #ITEMS_DIALOG_ALL
   * @see #ITEMS_DIALOG_NUMERIC
   * @see #ITEMS_DIALOG_STRING = 2;
   * 
   */
  protected void invokeItemsDialog (JComboBox jComboBoxItems, int nItemTypes) {
    StandardDialog standardDialog = null;
  
    AvailableItemsTree availableItemsTree = 
      new AvailableItemsTree (getContext());
      
    if (availableItemsTree != null) {
      try {
        // Retrieve the Connection from the DataFilterPanelModel to initialize
        // the list of MDItems
        DataFilterPanelModel dataFilterPanelModel = getDataFilterPanelModel();
       
        Connection connection = 
          (dataFilterPanelModel != null) ? dataFilterPanelModel.getConnection() : null;  

        DatasourceItemsTreeNode datasourceItemsTreeNode= 
          new DatasourceItemsTreeNode (availableItemsTree, connection, getContext());
        
        // Add a MetadataFilter if needed
        if (makeMetadataFilter (datasourceItemsTreeNode, nItemTypes) != null) {
          datasourceItemsTreeNode.refresh();
        }

        // Add the generated node to the tree
        availableItemsTree.setRoot (datasourceItemsTreeNode);
      }
      
      catch (Throwable throwable) {
        QBUtils.processError (getContext(), throwable, this.getClass(), "processItem (ItemEvent)");
      }
    }

    Window window = 
      SwingUtilities.windowForComponent (jComboBoxItems);
  
    String strTitle = 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_SELECT_ITEM_TITLE);  
  
    // gek 05/15/07 Fix Bug 6045750 - SelectItems sub-dialog should provide
    //              vertical scrollbar as needed.
    //
    // Make AvailableItemsTree scrollable.

    JScrollPane jScrollPaneAvailableItemsPanel = 
      new JScrollPane (availableItemsTree);
    
    // Set the default number of nodes to display at a time
    availableItemsTree.setVisibleRowCount (ITEMS_DIALOG_DEFAULT_COUNT);
  
    if (window instanceof Frame) {
      standardDialog = 
        new StandardDialog ((Frame)window, strTitle, true, jScrollPaneAvailableItemsPanel);
    }
    else if (window instanceof Dialog) {
      standardDialog = 
        new StandardDialog ((Dialog)window, strTitle, true, jScrollPaneAvailableItemsPanel);
    }
    else {
      standardDialog = 
        new StandardDialog ((Frame)null, strTitle, true, jScrollPaneAvailableItemsPanel);
    }

    // Check if user selected OK
    if (standardDialog.display (BaseDataFilterPanel.this) == standardDialog.OK) {
      updateDataFilter (availableItemsTree.getSelectedItems(), jComboBoxItems);
      
      /* TODO
      if (itemEvent.getSource() instanceof TreeListCombo) {
        treeListCombo = (TreeListCombo) itemEvent.getSource();
      }
   
      updateDataFilter (availableItemsTree.getSelectedItems(), treeListCombo);
      */
    }
    else {
      DataFilterUtils.setSelectedItem (jComboBoxItems, getMDItem());
      jComboBoxItems.repaint();
    }            
  }
  
  /**
   * Make the <code>MetadataFilter</code> based on the item types requested.
   * 
   * @param nItemTypes A <code>int</code> that represents the items to show which
   *        include all, numeric and string.
   * 
   * @return <code>MetadataFilter</code>.
   * 
   * @see #ITEMS_DIALOG_ALL
   * @see #ITEMS_DIALOG_NUMERIC
   * @see #ITEMS_DIALOG_STRING = 2;
   * 
   * 
   */
  protected MetadataFilter makeMetadataFilter (FolderItemsTreeNode folderItemsTreeNode, int nItemTypes) {

    // Add a MetadataFilter if needed
    MetadataFilter metadataFilter = null;
  
    if (folderItemsTreeNode != null) {
      switch (nItemTypes) {
        case BaseDataFilterPanel.ITEMS_DIALOG_NUMERIC:
          String[] strDataTypesNumeric = new String[] {MM.SHORT, MM.INTEGER, MM.LONG, MM.FLOAT, MM.DOUBLE};
    
          metadataFilter = folderItemsTreeNode.createMetadataFilter (getContext()); 
          metadataFilter.setDataTypes (strDataTypesNumeric);
          break;
    
        case BaseDataFilterPanel.ITEMS_DIALOG_STRING:
          String[] strDataTypesString = new String[] {MM.STRING};
      
          metadataFilter = folderItemsTreeNode.createMetadataFilter (getContext()); 
          metadataFilter.setDataTypes (strDataTypesString);
          break;
      }
    
      if (metadataFilter != null) {
        folderItemsTreeNode.setMetadataFilter (metadataFilter);
      }
    }

    return metadataFilter;
  }

  protected void updateComboBox (JComboBox jComboBox, Vector vItems, Object objSelected, boolean bIncludeMore) {
    if (jComboBox != null) {

      // Apply a brand new model in order to make sure that the comboBox
      // gets updated properly.
      DefaultComboBoxModel defaultComboBoxModel = 
        new DefaultComboBoxModel();

      jComboBox.setModel (defaultComboBoxModel);

      // Add selected object to top of list
      if ((vItems != null) && (objSelected != null) && (!vItems.contains (objSelected))) {
        defaultComboBoxModel.insertElementAt (objSelected, 0);
      }

      if (objSelected != null) {
        defaultComboBoxModel.setSelectedItem (objSelected);
      }

      if ((vItems != null) && (!vItems.isEmpty())) {
        for (int nIndex = 0; nIndex < vItems.size(); nIndex++) {
          
          // Skip MoreItems which are added at the end, if necessary
          if (!(vItems.get (nIndex) instanceof MoreItems)) {
            defaultComboBoxModel.addElement (vItems.get (nIndex));
          }
        }
      }
      else {
        vItems = new Vector();
      }

      // Add MoreItems at end
      if (bIncludeMore) {
        defaultComboBoxModel.addElement (new MoreItems (jComboBox));
      }

      if (objSelected != null) {
        DataFilterUtils.setSelectedItem (jComboBox, objSelected);
      }
    }
  }

 /**
   * Update the <code>DataFilter</code> based on the objects specified.
   * 
   * @param objectsSelected A <code>Object[]</code> to process.
   * @parem jComboBox A <code>JComboBox</code> to update.
   * 
   */
  protected void updateDataFilter (Object[] objectsSelected, JComboBox jComboBox) {

    if ((objectsSelected != null) && (objectsSelected.length != 0)) {
      Object objectNode = objectsSelected[0];
     
      // Attempt to retrieve the MDObject ID from the ComponentNode
      if (objectNode instanceof ComponentNode) {
        String strItem = (String)((ComponentNode)objectNode).getValue();  
        MDObject mdObject = DataUtils.getMDObject (getContext(), strItem);
  
        ComboBoxModel comboBoxModel = null;
        if ((mdObject != null) && (jComboBox != null)) {
          comboBoxModel = jComboBox.getModel();
  
          if (comboBoxModel instanceof DefaultComboBoxModel) {
            DefaultComboBoxModel defaultComboBoxModel = 
              (DefaultComboBoxModel)comboBoxModel;  
  
            // Retrieve the current items  
            Vector vItems = new Vector();
            Object object;
            
            // Only add non-duplicate items
            for (int nIndex = 0; nIndex < defaultComboBoxModel.getSize(); nIndex++) {
              object = defaultComboBoxModel.getElementAt (nIndex);
  
              if (!exists (object, vItems)) {
                vItems.addElement (object);
              }
            }

            updateComboBox (jComboBox, vItems, mdObject, true);

            jComboBox.repaint();
          }  
        }
      }
    }
  }

  /**
   * Determine if the item already exists in the list.
   * 
   * @param objItem A <code>Object</code> to check.
   * @param vMDItems A <code>Vector</code> of MDItems to check.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the item
   *         already exists and <code>false</code> otherwise.
   *
   */
  protected static boolean exists (Object objItem, Vector vMDItems) {

    boolean bExists = false;

    String strMemberID = null;
    Object object = null;

    if (objItem instanceof MDObject) {
      strMemberID = ((MDObject)objItem).getUniqueID();    
    }

    if ((strMemberID != null) && (vMDItems != null)) {
      // Iterate over all of the Member IDs
      for (int nIndex = 0; nIndex < vMDItems.size(); nIndex++) {

        object = vMDItems.get (nIndex);
        if (object instanceof MDObject) {
  
          // If we have found a match, bail...   
          if (strMemberID.equals (((MDObject)object).getUniqueID())) {
            bExists = true;
            break;
          }    
        }
      }      
    }
    
    return bExists;
  }

  /**
   * Invoke the Parameter dialog. 
   * 
   * @param itemEvent A <code>ItemEvent</code> to process.
   * @param mdItem A <code>MDItem</code> to invoke Parameter dialog for.
   * 
   */
  protected void invokeParameterDialog (ItemEvent itemEvent, MDItem mdItem) throws Exception {
    if ((itemEvent != null) && (itemEvent.getStateChange() == ItemEvent.SELECTED) && 
        (mdItem != null) && (getContext() != null)) {
  
      JTextField jTextField = null;

      Object objSource = itemEvent.getSource();
      if (objSource instanceof JTextField) {
        jTextField = (JTextField) objSource;  
      }
      else {
        // TODO Remove TreeListCombo
        // jTextField = getTextFieldMembers();
      }

      //// String strText = treeListCombo.getText();
      String strText = jTextField.getText();

      if (isParameter (itemEvent.getItem())) {
        
        CreateParameterPanelModelImpl createParameterPanelModelImpl = 
          new CreateParameterPanelModelImpl (getContext());
    
        BaseParameter baseParameter = null;    
        String[] strParameterNames = null;
        Object objDefaultValue = null;
        BaseDataFilter baseDataFilter = null;
  
        // Retrieve the current parameter
        if (getDataFilterPanelModel() != null){
          if (hasParameter()) {
            baseDataFilter = getDataFilterPanelModel().getDataFilter();
            objDefaultValue = ((DataFilter)baseDataFilter).getCmpValues();
          }
        }
    
        createParameterPanelModelImpl.setBasedOnFixed (true);
        createParameterPanelModelImpl.setBasedOn (mdItem.getUniqueID(), true, objDefaultValue);
        CreateParameterDialog createParameterDialog = null;
        
        if (getContext().getParent() instanceof Dialog) {
          createParameterDialog = 
            new CreateParameterDialog ((Dialog)getContext().getParent());
        }
        else if (getContext().getParent() instanceof Frame) {
          createParameterDialog = 
            new CreateParameterDialog ((Frame)getContext().getParent());
        }
        else {
          createParameterDialog = new CreateParameterDialog ((Frame)null);
        }
    
        createParameterDialog.getCreateParameterPanel().setComponentContext (getContext());
        createParameterDialog.getCreateParameterPanel().setModel (createParameterPanelModelImpl);
        createParameterDialog.getCreateParameterPanel().initialize();

        if (createParameterDialog.display (BaseDataFilterPanel.this) == createParameterDialog.OK) {
          baseParameter = 
            createParameterPanelModelImpl.getParameter();

          //// TODO
          /// jTextField.setSelectedItem (baseParameter);
          
          if (baseParameter != null) {
            // TODO Remove TreeListCombo
            updateTextFieldMembers (jTextField, baseParameter.toString());
            updateModel();
            
            // Update the DataFilter members so that they are checked
            // in the TreeListCombo
            refresh();
          }
        }
        else {
          // jTextField.setSelectedItem (null);          
          // TODO Remove TreeListCombo
          updateTextFieldMembers (jTextField, strText); 
        }
      }
      else {
        // Process the selected item
        /* TODO
        Object objSelected = treeListCombo.getSelectedItem();
        
        if (objSelected instanceof MemberItemsTreeNode) {
          MemberItemsTreeNode memberItemsTreeNode = 
            (MemberItemsTreeNode)objSelected;
        
          String strMember = 
            (String)memberItemsTreeNode.getComponentNode().getValue();  
        
          DataFilterUtils.setCurrentMembers (getJComboBoxItems(), strMember);
        }
        */
      }
    }
  }

  protected String getResourceString (String strID) {
    String strResourceString = strID;
    
    if ((getContext() != null) && (getContext().getResourceHandler() != null)) {
      strResourceString = 
        getContext().getResourceHandler().getResourceString (strID);
    }
    
    return strResourceString; 
  }

  protected MDItem getCurrentItem (DataFilterPanelModel dataFilterPanelModel, ComponentContext componentContext) {
    if (dataFilterPanelModel != null) {
      return DataFilterUtils.getCurrentItem (dataFilterPanelModel.getDataFilter(), componentContext);
    }

    return null;
  }
 
  protected GridBagConstraints getDefaultGridBagConstraints() {
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 0;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.anchor = GridBagConstraints.NORTHWEST;
    
    return gridBagConstraints;
  }

  protected JPanel getDataFilterPanelNoValue() {

    JPanel jPanel = getDataFilterPanelItemOperator();
    GridBagConstraints gridBagConstraints =
      getDefaultGridBagConstraints();  

    setDataFilterPanelValue (null);

    return jPanel; 
  }

  protected JPanel getDataFilterPanelOneValue (int nInitialValueCount) {
  
    JPanel jPanel = getDataFilterPanelItemOperator();
    GridBagConstraints gridBagConstraints =
      getDefaultGridBagConstraints();  
    
    gridBagConstraints.weighty = 1.0;

    setDataFilterPanelValue (makeValuePanel (nInitialValueCount));

    jPanel.add (getDataFilterPanelValue(), gridBagConstraints);
    
    return jPanel; 
  }

  /**
   * Retrieve the panel associated with the specified tab.
   * 
   * @param nValueTab A <code>int</code> representing the value tab.
   * 
   * @return <code>JPanel</code> associated with the specified tab.
   * 
   * @see #VALUES_FROM
   * @see #VALUES_TO
   */
  protected DataFilterPanelValue getTabbedPaneFromValue (int nValueTab) {
    DataFilterPanelValue dataFilterPanelValue = null;  
    
    if (getTabbedPane() != null) {
      dataFilterPanelValue = 
        (DataFilterPanelValue) getTabbedPane().getComponent (nValueTab);
    }
  
    return dataFilterPanelValue;
  }

  protected JTabbedPane getTabbedPane () {
    return m_jTabbedPane;
  }

  protected void setTabbedPane (JTabbedPane jTabbedPane) {
    m_jTabbedPane = jTabbedPane;
  }

  protected DataFilterPanelValue getDataFilterPanelValue() {
    DataFilterPanelValue dataFilterPanelValue = m_dataFilterPanelValue;
  
    // Get the currently selected panel
    JTabbedPane jTabbedPane = getTabbedPane();
      
    if (jTabbedPane != null) {
      Component component = jTabbedPane.getSelectedComponent();
      
      if (component instanceof DataFilterPanelValue) {
        dataFilterPanelValue = (DataFilterPanelValue) component;
      }
    }
  
    return dataFilterPanelValue;
  }

  protected void setDataFilterPanelValue (DataFilterPanelValue dataFilterPanelValue) {
    m_dataFilterPanelValue = dataFilterPanelValue;
  }

  protected JPanel getDataFilterPanelTwoValues (int nInitialValueCount) {

    JPanel jPanel = getDataFilterPanelItemOperator();
    GridBagConstraints gridBagConstraints =
      getDefaultGridBagConstraints();  

    setTabbedPane (new JTabbedPane());
    
    String strLabelTabFrom = getResourceString (QueryBuilderBundle.DATAFILTERPANEL_TAB_FROM);
    String strLabelTabTo = getResourceString (QueryBuilderBundle.DATAFILTERPANEL_TAB_TO);
    
    // VALUES_FROM
    getTabbedPane().addTab (
      StringUtils.stripMnemonic (strLabelTabFrom), makeValuePanel (nInitialValueCount, VALUES_TWO, VALUES_FROM, nInitialValueCount));
    getTabbedPane().setMnemonicAt (0, StringUtils.getMnemonicKeyCode (strLabelTabFrom));
    
    // VALUES_TO
    getTabbedPane().addTab (
      StringUtils.stripMnemonic (strLabelTabTo), makeValuePanel (nInitialValueCount, VALUES_TWO, VALUES_TO, nInitialValueCount));
    getTabbedPane().setMnemonicAt (1, StringUtils.getMnemonicKeyCode (strLabelTabTo));

    jPanel.add (getTabbedPane(), gridBagConstraints);

    return jPanel; 
  }

  protected JPanel getDataFilterPanelItemOperator() {

    GridBagLayout gridBagLayout = new GridBagLayout();
    JPanel jPanel = new JPanel (gridBagLayout);

    // DataFilter used for initialization
    BaseDataFilter baseDataFilter = getDataFilter();

    GridBagConstraints gridBagConstraints = getDefaultGridBagConstraints();
   
    // Item Label
    JPanel jPanelItem = new JPanel();
    ((FlowLayout)jPanelItem.getLayout()).setAlignment (FlowLayout.LEFT);
    
    JLabel jLabelItem = 
      makeLabel (getResourceString (QueryBuilderBundle.DATAFILTERPANEL_ITEM));
    jPanelItem.add (jLabelItem);

    // Item combobox
    if (getJComboBoxItems() == null) {
      setJComboBoxItems (makeComboBoxItems (null));
    }

    getJComboBoxItems().setEditable (false);
    getJComboBoxItems().setFocusable (true);
    getJComboBoxItems().addItemListener (new DataFilterPanelItemListener());

    DataUtils.setLabelFor (jLabelItem, getJComboBoxItems());

    // Add Item Combo Box to Condition Panel
    jPanelItem.add (getJComboBoxItems());

    jPanel.add (jPanelItem, gridBagConstraints);

    // Operator
    JPanel jPanelOperator = new JPanel();
    ((FlowLayout)jPanelOperator.getLayout()).setAlignment (FlowLayout.LEFT);

    JLabel jLabelOperator =
      makeLabel (getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OPERATOR));
    jPanelOperator.add (jLabelOperator);

    // Add Operator Combo Box to Condition Panel
    if (getComboOperators() == null) {
      setComboOperators (makeComboBox (null));
    }
    
    getComboOperators().setEditable (false);

    DataUtils.setLabelFor (jLabelOperator, getComboOperators());

    // gek 11/28/07 Work around for Bug 6650630 - QUERYBUILDER: ARROW KEYS NOT FUNCTIONING CORRECTLY IN OPERATOR FIELD.
    comboBoxKeyboardHack (getComboOperators());

    getComboOperators().addItemListener (new ItemListener() {
      public void itemStateChanged (ItemEvent itemEvent) {
       
        if (itemEvent.getStateChange() == ItemEvent.SELECTED) {

          // Enable/Disable the state of the Members combo based on the operator
          if (!m_bUpdateOperatorCombo) {
            m_bUpdateOperatorCombo = true;
            updateMemberState();
            
            // Only update if the selected items has changed
            if (!getComboOperators().getSelectedItem().equals (itemEvent.getItem())) {
              getComboOperators().setSelectedItem (itemEvent.getItem());
            
              try {
                updateModel();
              }
              
              catch (Exception exception) {
              }
            }
            
            m_bUpdateOperatorCombo = false;
          }
        }
      }
    });

    jPanelOperator.add (getComboOperators());
    jPanel.add (jPanelOperator, gridBagConstraints) ;

    // Make all the labels the same width
    Vector vComponents = new Vector();
    vComponents.add (jLabelItem);
    vComponents.add (jLabelOperator);
    Utils.updateComponentWidth (vComponents);

    // Pass operator as parameter
    String strLabel = 
      StringUtils.stripMnemonic (
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OPERATOR_PASS_AS_PARAMETER));

    if (getJCheckBoxOperatorAsParam() == null) {
      setJCheckBoxOperatorAsParam (new JCheckBox (strLabel, false));
    }
    
    getJCheckBoxOperatorAsParam().setMnemonic (
      StringUtils.getMnemonicKeyCode (
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OPERATOR_PASS_AS_PARAMETER)));
    
    getJCheckBoxOperatorAsParam().setBorder (BorderFactory.createEmptyBorder());

    gridBagConstraints.fill = GridBagConstraints.NONE;
    jPanel.add (getJCheckBoxOperatorAsParam(), gridBagConstraints);
    
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;

    getJCheckBoxOperatorAsParam().addItemListener (new ItemListener() {
      public void itemStateChanged (ItemEvent itemEvent) {
        getJTextFieldOperatorAsParam().setEnabled (getJCheckBoxOperatorAsParam().isSelected());
      }
    });
    
    // Parameter name
    JPanel jPanelOperatorParameterName = new JPanel();
    ((FlowLayout)jPanelOperatorParameterName.getLayout()).setAlignment (FlowLayout.LEFT);

    jPanelOperatorParameterName.add (Box.createHorizontalStrut (10), gridBagConstraints);
    
    strLabel = 
      getResourceString (QueryBuilderBundle.DATAFILTERPANEL_OPERATOR_PARAMETER_NAME);
    
    JLabel jLabelParameterName = makeLabel (strLabel);

    if (getJTextFieldOperatorAsParam() == null) { 
      setJTextFieldOperatorAsParam (new JTextField (20));
    }
    
    jLabelParameterName.setLabelFor (getJTextFieldOperatorAsParam());

    jPanelOperatorParameterName.add (jLabelParameterName);
    jPanelOperatorParameterName.add (getJTextFieldOperatorAsParam());

    jPanel.add (jPanelOperatorParameterName, gridBagConstraints);

    // Initialize based on DataFilter

    // Initialize the item
    Object objItem = getItemID (baseDataFilter);
    if (baseDataFilter != null) {
      getJComboBoxItems().setSelectedItem (objItem);   
    }

    // Initialize the Operator
    OperatorDisplay operatorDisplay = 
      getCurrentOperator (getOperatorDisplays(), getDataFilterPanelModel());
    
    if (operatorDisplay != null) {
      DataFilterUtils.setSelectedItem (getComboOperators(), operatorDisplay);
    }

    // Initialize the Pass Operator as Parameter and Parameter Name
    String strParameterOperatorValue =  null;
    if (baseDataFilter != null) {
    
      strParameterOperatorValue = 
        baseDataFilter.getAssociatedParameterName (DataFilter.PARAMETER_OPERATOR_VALUE);
  
      getJCheckBoxOperatorAsParam().setSelected (strParameterOperatorValue != null);

      if (strParameterOperatorValue != null) {
        getJTextFieldOperatorAsParam().setText (strParameterOperatorValue);       
      }
    }

    return jPanel;
  }

  /**
   * @internal
   * 
   * <pre>
   * Work around for Bug 6650630 - QUERYBUILDER: ARROW KEYS NOT FUNCTIONING CORRECTLY IN OPERATOR FIELD.
   * 
   * From Sun Bug ID: 4199622
   * Synopsis  RFE: JComboBox shouldn't sending ActionEvents for keyboard navigation  
   * http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4199622
   * 
   * I could trap KeyEvents and set a flag each time an arrow key was pressed, unsetting the flag after
   * it was released, and not perform my "selection action" if the flag is currently set.
   * 
   * Serious Hack Alert:
   * 
   *  What is desired is for the JComboBox to behave like its a table cell editor. Starting with 1.4, the indication that the combo is in a JTable context is provided by the boolean client property "JComboBox.isTableCellEditor". See DefaultCellEditor(JComboBox).
   * 
   *  You can spoof the JComboBox to make it behave like it's in a JTable by setting the client property for each JComboBox:
   *   comboBox.putClientProperty("JComboBox.isTableCellEditor", Boolean.TRUE);
   *   
   *  You would have to add an actionListener to the combo box to manually hide the combo popup:
   *  
   *   comboBox.putClientProperty("JComboBox.isTableCellEditor", Boolean.TRUE);
   *  
   *  You would have to add an actionListener to the combo box to manually hide the combo popup:
   *  
   *   comboBox.addActionListener(new ActionListener() {
   *     public void actionPerformed(ActionEvent evt) {
   *       JComboBox combo = (JComboBox)evt.getSource();
   *       combo.hidePopup();
   *     }
   *   });
   * </pre>
   * 
   */
  protected void comboBoxKeyboardHack (JComboBox jComboBox) {
    if (jComboBox != null) {
      jComboBox.putClientProperty ("JComboBox.isTableCellEditor", Boolean.TRUE);
      
      jComboBox.addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          JComboBox jComboBox = (JComboBox)actionEvent.getSource();
          jComboBox.hidePopup();
          jComboBox.requestFocus();
        }
      });
    }
  }

  protected int getVisibleRowCount() {
    return 5;
  }

  protected void updateConditionPanel (int nValues, int nInitialValueCount) {
    if (getConditionPanel() != null) {
      getConditionPanel().removeAll();
      remove (getConditionPanel());
    }  
     
    setConditionPanel (makeConditionPanel (nValues, nInitialValueCount));
    add (getConditionPanel(), BorderLayout.NORTH);
    validate();
    repaint();
  }

  protected JPanel makeConditionPanel() {
    // Determine the proper Condition Panel
    int nValuesType = VALUES_ONE;
    int nInitialValueCount = 5;
    
    BaseDataFilter baseDataFilter = getDataFilter();
    if (baseDataFilter != null) {

      switch (baseDataFilter.getCmpOperator()) {
        case DataFilter.OP_IS_NULL:
        case DataFilter.OP_IS_NOT_NULL:
          nValuesType = VALUES_NONE;
          nInitialValueCount = 0;
          break;
  
        case RangeDataFilter.OP_BETWEEN:
        case RangeDataFilter.OP_NOT_BETWEEN:
          nValuesType = VALUES_TWO;
          nInitialValueCount = 1;
          break;
  
        case TopBottomDataFilter.OP_TOP:
        case TopBottomDataFilter.OP_BOTTOM:
          nValuesType = VALUES_ONE;
          nInitialValueCount = 1;
          break;
  
        default:
          nValuesType = VALUES_ONE;
          break;
      }
    }
    
    return makeConditionPanel (nValuesType, nInitialValueCount);
  }

  protected JPanel makeConditionPanel (int nValues, int nInitialValueCount) {
    JPanel jPanelCondition = null;

    setTabbedPane (null);

    switch (nValues) {
      case VALUES_ONE:
        jPanelCondition = getDataFilterPanelOneValue (nInitialValueCount);
        break;

      case VALUES_TWO:
        jPanelCondition = getDataFilterPanelTwoValues (nInitialValueCount);
        break;
      
      case VALUES_NONE:
      default:
        jPanelCondition = getDataFilterPanelNoValue();
        break;
    }
    
    updateParameterState();

    return jPanelCondition;
  }

  /**
   * @internal
   * 
   * Update the member state based on operator.
   * 
   */
  protected boolean updateMemberState() {
    int nCmpOperator = DataFilterUtils.getOperatorId (getComboOperators());
    return updateMemberState (nCmpOperator);
  }
  
  protected void updateMemberState (JTextField jTextFieldMembers) {
    int nCmpOperator = DataFilterUtils.getOperatorId (getComboOperators());
    updateMemberState (jTextFieldMembers, nCmpOperator);
  }

  /**
   * @internal
   * 
   * Update the member state based on operator.
   * 
   * @param nCmpOperator A <code>int</code> representing the comparison operator.
   * 
   * @return <code>boolean</code> which is <code>true</code> when the member state
   *         has been updated and <code>false</code> otherwise.
   * 
   */
  protected boolean updateMemberState (int nCmpOperator) {
  
    boolean bUpdated = false;
    
    int nValueType = VALUES_UNDEFINED;
    int nInitialCount = 0;
    
    // Retrieve the current Condition Panel
    DataFilterPanelValue dataFilterPanelValue = getDataFilterPanelValue();
    if (dataFilterPanelValue != null) {
      nValueType = dataFilterPanelValue.getValueType();
      nInitialCount = dataFilterPanelValue.getInitialCount();
    }
  
    switch (nCmpOperator) {
      case DataFilter.OP_IS_NULL:
      case DataFilter.OP_IS_NOT_NULL:
        if ((nValueType != VALUES_NONE) || (nInitialCount != 0)) {
          updateConditionPanel (VALUES_NONE, 0);
          bUpdated = true;
        }
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        if ((nValueType != VALUES_TWO) || (nInitialCount != 1)) {
          updateConditionPanel (VALUES_TWO, 1);
          bUpdated = true;
        }
        break;

      case TopBottomDataFilter.OP_TOP:
      case TopBottomDataFilter.OP_BOTTOM:
        if ((nValueType != VALUES_ONE) || (nInitialCount != 1)) {
          updateConditionPanel (VALUES_ONE, 1);
          bUpdated = true;
        }
        break;

      default:
        if ((nValueType != VALUES_ONE) || (nInitialCount != 5)) {
          updateConditionPanel (VALUES_ONE, 5);
          bUpdated = true;
        }
        break;
    }
  
    if (bUpdated) {
      refresh();
    }
  
    return bUpdated;
  }

  protected static void updateMemberState (JTextField jTextFieldMembers, int nCmpOperator) {
  
    if (jTextFieldMembers != null) {
      switch (nCmpOperator) {
        case DataFilter.OP_IS_NULL:
        case DataFilter.OP_IS_NOT_NULL:
          jTextFieldMembers.setEnabled (false);
          break;

        case RangeDataFilter.OP_BETWEEN:
        case RangeDataFilter.OP_NOT_BETWEEN:
          jTextFieldMembers.setEnabled (true);
          break;
  
        default:
          jTextFieldMembers.setEnabled (true);     
          break;
      }
    }
  }

  /**
   * @internal
   * 
   * Update the member state based on operator.
   * 
   */
  protected void updateMemberState (BaseDataFilter baseDataFilter) {
    if (baseDataFilter != null) {
      updateMemberState (baseDataFilter.getCmpOperator());
    }
  }

  protected void updateMemberState (JTextField jTextFieldMembers, BaseDataFilter baseDataFilter) {
    if (baseDataFilter != null) {
      updateMemberState (jTextFieldMembers, baseDataFilter.getCmpOperator());
    }
  }
  
  protected OperatorDisplay getCurrentOperator (OperatorDisplay[] operatorDisplays, 
                                              DataFilterPanelModel dataFilterPanelModel) {
    if (dataFilterPanelModel != null) {
      return DataFilterUtils.getCurrentOperator (operatorDisplays, 
        dataFilterPanelModel.getDataFilter());
    }

    return null;
  }

  protected String getCurrentMembers (DataFilterPanelModel dataFilterPanelModel) {
    if (dataFilterPanelModel != null) {
      return DataFilterUtils.getCurrentMembers (dataFilterPanelModel.getDataFilter(), 
        getContext());
    }
  
    return null;
  }

  protected String getCurrentMembers (DataFilterPanelModel dataFilterPanelModel, 
      boolean bMembersOnly, boolean bUnformatted) {
    
    if (dataFilterPanelModel != null) {
      DataFilterItemsTreeNode dataFilterItemsTreeNode = 
        new DataFilterItemsTreeNode (getContext());

      return dataFilterItemsTreeNode.getLabel (
        dataFilterPanelModel.getDataFilter(), getContext(), bMembersOnly, bUnformatted);
    }
  
    return null;
  }

  protected JLabel makeLabel (String strLabel, GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    
    if (strLabel != null) {
      JLabel jLabel = DataUtils.getLabel (strLabel, SwingConstants.LEFT);
      
      gridBagLayout.setConstraints (jLabel, gridBagConstraints);
      return jLabel;
    }

    return null;
  }

  protected JLabel makeLabel (String strLabel) {
    JLabel jLabel = null;
    
    if (strLabel != null) {
      jLabel = DataUtils.getLabel (strLabel, SwingConstants.LEFT);
    }

    return jLabel;
  }

  protected JButton makeButton (String strLabel, GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
     
    if (strLabel != null) {
      JButton jButton = new JButton ();
      DataUtils.setLabelText (jButton, strLabel);
     
      gridBagLayout.setConstraints (jButton, gridBagConstraints);
      return jButton;
    }

    return null;
  }

  protected JButton makeButton (String strLabel) {
    JButton jButton = null;
     
    if (strLabel != null) {
      jButton = new JButton();
      DataUtils.setLabelText (jButton, strLabel);
    }

    return jButton;
  }

  protected JComboBox makeComboBox (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    return makeComboBox (gridBagLayout, gridBagConstraints, null);
  }

  protected JComboBox makeComboBox (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints, 
                                  Vector vItems) {
    JComboBox jComboBox = null;
    jComboBox = (vItems == null) ? new JComboBox() : new JComboBox (vItems);
    jComboBox.setEditable (true);
    
    gridBagLayout.setConstraints (jComboBox, gridBagConstraints);
    
    return jComboBox;
  }

  protected JComboBox makeComboBox (Vector vItems) {
    JComboBox jComboBox = null;
    jComboBox = (vItems == null) ? new JComboBox() : new JComboBox (vItems);
    jComboBox.setEditable (true);
    return jComboBox;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private void initGUI (ComponentContext componentContext) {
    setContext (componentContext);
    setOperatorDisplays (makeOperatorDisplays());
    setConditionPanel (makeConditionPanel());
    add (getConditionPanel(), BorderLayout.NORTH);
  }
  
  private static Vector getSelectedItems (JTree jTree) {
    Vector vobjSelectedItems = new Vector();
     
    if (jTree != null) {
      TreeModel treeModel = jTree.getModel();

      if (treeModel instanceof DefaultTreeModel) {
        Object object = ((DefaultTreeModel)treeModel).getRoot();
         
        if (object instanceof DefaultMutableTreeNode) {
          for (Enumeration enumeration = 
              ((DefaultMutableTreeNode)object).preorderEnumeration(); enumeration.hasMoreElements(); ) {
            object = enumeration.nextElement();
             
            if ((object instanceof Checkable) && ((Checkable)object).isChecked()) {
              object = ((DefaultMutableTreeNode)object).getUserObject();
               
              if (object instanceof ComponentNode) {
                vobjSelectedItems.addElement(((ComponentNode)object).getValue());
              }
            }
          }
        }
      }
    }

    return vobjSelectedItems;
  }

  private JComboBox makeComboBoxItems (Vector vItems) {
    
    JComboBox jComboBox = new JComboBox();
    jComboBox.setModel (new DefaultComboBoxModel());
    jComboBox.setEditable (true);
    return jComboBox;
  }

  private DataFilterPanelCheckBox makeCheckBox (String strLabel, boolean bSelected, DataFilterPanelValue dataFilterPanelValue) {
    DataFilterPanelCheckBox dataFilterPanelCheckBox = null;

    if (strLabel != null) {
      dataFilterPanelCheckBox = 
        new DataFilterPanelCheckBox (StringUtils.stripMnemonic (strLabel), bSelected, dataFilterPanelValue);
      dataFilterPanelCheckBox.setMnemonic (StringUtils.getMnemonicKeyCode (strLabel));
      dataFilterPanelCheckBox.setDataFilterPanelValue (dataFilterPanelValue);
    }

     return dataFilterPanelCheckBox;
  }

  private JCheckBox makeCheckBox (String strLabel, boolean bSelected, 
      GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    
    JCheckBox jCheckBox = null;

    if (strLabel != null) {
      jCheckBox = new JCheckBox (StringUtils.stripMnemonic (strLabel), bSelected);

      jCheckBox.setMnemonic (StringUtils.getMnemonicKeyCode (strLabel));
      jCheckBox.setBorder (BorderFactory.createEmptyBorder());
      
      if (gridBagConstraints != null) {
        gridBagLayout.setConstraints (jCheckBox, gridBagConstraints);
      }
    }

     return jCheckBox;
   }

  private JPanel makePanel (GridBagLayout gridBagLayout, GridBagConstraints gridBagConstraints) {
    JPanel jPanel = new JPanel();
    jPanel.setBorder (BorderFactory.createEmptyBorder());
    gridBagLayout.setConstraints (jPanel, gridBagConstraints);
    return jPanel;
  }

  private class InsertAction extends AbstractAction {
    public InsertAction() {
      putValue (Action.NAME, "New...");
    }

    public void actionPerformed(ActionEvent e) {
      // _newItem();
    }
  }

  private class DeleteAction extends AbstractAction {
    public DeleteAction() {
      putValue (Action.NAME, "Delete");
    }

    public void actionPerformed(ActionEvent e) {
      // _deleteItem();
    }
  }

  /////////////////////
  //
  // Inner Classes
  //
  /////////////////////

  /**
   * <code>DataFilterPanelValue</code> inner class.
   * 
   * 
   */
  public class DataFilterPanelValue extends JPanel { 
    
    /////////////////////
    //
    // Members
    //
    /////////////////////

    private JListMutable m_jListMembers = null;
    private int m_nValueType = VALUES_UNDEFINED;
    private int m_nValueSubType = VALUES_UNDEFINED;
    private int m_nInitialCount = 0;
    private DataFilterControlBar m_dataFilterControlBar = null;
    private JCheckBox m_jCheckBoxIgnoreCase = null;
    private JCheckBox m_jCheckBoxValueAsParam = null;
    private JTextField m_jTextFieldValueAsParam  = null;
    private JCheckBox m_jCheckBoxAcceptMultipleValues = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public DataFilterPanelValue () {
      super();
    }

    public DataFilterPanelValue (JListMutable jListMembers) {
      super();
      setJListMembers (jListMembers);  
    }
  
    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public void setJListMembers (JListMutable jListMembers) {
      m_jListMembers = jListMembers;
    }
  
    public JListMutable getJListMembers() {
      return m_jListMembers;
    }
 
    /**
     * Specify the <code>DataFilterControlBar</code>.
     * 
     * @param dataFilterControlBar A <code>DataFilterControlBar</code>.
     * 
     */
    public void setDataFilterControlBar (DataFilterControlBar dataFilterControlBar) {
      m_dataFilterControlBar = dataFilterControlBar;
    }
  
    /**
     * Retrievers the <code>DataFilterControlBar</code>.
     * 
     * @return <code>DataFilterControlBar</code>.
     * 
     */
    public DataFilterControlBar getDataFilterControlBar() {
      return m_dataFilterControlBar;
    }
  
    /**
     * Specify the type of the panel.
     * 
     * @param nValueType A <code>int</code> representing the type of the panel.
     * 
     * @see #VALUES_UNDEFINED
     * @see #VALUES_NONE
     * @see #VALUES_ONE
     * @see #VALUES_TWO
     * 
     */
    public void setValueType (int nValueType) {
      m_nValueType = nValueType;
    }

    /**
     * Retrieve the type of the panel.
     * 
     * @return <code>int</code> representing the type of the panel.
     * 
     * @see #VALUES_UNDEFINED
     * @see #VALUES_NONE
     * @see #VALUES_ONE
     * @see #VALUES_TWO
     * 
     */
    public int getValueType() {
      return m_nValueType;
    }

    /**
     * Specify the sub type of the panel.
     * 
     * @param nValueType A <code>int</code> representing the sub type of the panel.
     * 
     * @see #VALUES_UNDEFINED
     * @see #VALUES_FROM
     * @see #VALUES_TO
     * 
     */
    public void setValueSubType (int nValueSubType) {
      m_nValueSubType = nValueSubType;
    }

    /**
     * Retrieve the sub type of the panel.
     * 
     * @return <code>int</code> representing the sub type of the panel.
     * 
     * @see #VALUES_UNDEFINED
     * @see #VALUES_FROM
     * @see #VALUES_TO
     * 
     */
    public int getValueSubType() {
      return m_nValueSubType;
    }

    /**
     * Specify initial count.
     * 
     * @param nInitialCount A <code>int</code> representing the initial count of the
     *        the number of values to display at a time.
     * 
     * 
     */
    public void setInitialCount (int nInitialCount) {
      m_nInitialCount = nInitialCount;
    }

    /**
     * Retrieve the initial count.
     * 
     * @return <code>int</code> representing the initial count of the the number 
     *         of values to display at a time.
     * 
     */
    public int getInitialCount() {
      return m_nInitialCount;
    }

    public JCheckBox getJCheckBoxIgnoreCase() {
      return m_jCheckBoxIgnoreCase;
    }
  
    public void setJCheckBoxIgnoreCase (JCheckBox jCheckBoxIgnoreCase) {
      m_jCheckBoxIgnoreCase = jCheckBoxIgnoreCase;
    }

    protected JCheckBox getJCheckBoxValueAsParam() {
      return m_jCheckBoxValueAsParam;
    }
    
    protected void setJCheckBoxValueAsParam (JCheckBox jCheckBoxValueAsParam) {
      m_jCheckBoxValueAsParam = jCheckBoxValueAsParam;
    }
    
    protected JTextField getJTextFieldValueAsParam() {
      return m_jTextFieldValueAsParam;
    }
    
    protected void setJTextFieldValueAsParam (JTextField jTextFieldValueAsParam) {
      m_jTextFieldValueAsParam = jTextFieldValueAsParam;
    }

    protected JCheckBox getJCheckBoxAcceptMultipleValues() {
      return m_jCheckBoxAcceptMultipleValues;
    }
    
    protected void setJCheckBoxAcceptMultipleValues (JCheckBox jCheckBoxAcceptMultipleValues) {
      m_jCheckBoxAcceptMultipleValues = jCheckBoxAcceptMultipleValues;
    }
  }

  /**
   * <code>DataFilterControlBar</code> inner class.
   * 
   * 
   */
  public class DataFilterControlBar { 
    
    /////////////////////
    //
    // Members
    //
    /////////////////////

    /**
     * <code>ControlBar</code>.
     * 
     */
    protected ControlBar m_controlBar = null;

    /**
     * Add button.
     * 
     */
    protected DataFilterPanelButton m_jButtonAdd = null;
  
    /**
     * Browse button.
     * 
     */
    protected DataFilterPanelButton m_jButtonBrowse = null;
  
    /**
     * Delete button.
     * 
     */
    protected DataFilterPanelButton m_jButtonDelete = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public DataFilterControlBar (ControlBar controlBar) {
      setControlBar (controlBar);
    }
  
    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Specify the <code>ControlBar</code>.
     * 
     * @param controlBar A <code>ControlBar</code>.
     * 
     */
    public void setControlBar (ControlBar controlBar) {
      m_controlBar = controlBar;
    }
  
    /**
     * Retrievers the <code>ControlBar</code>.
     * 
     * @return <code>ControlBar</code>.
     * 
     */
    public ControlBar getControlBar() {
      return m_controlBar;
    }

    /**
     * Specifies the Add button.
     * 
     * @param jButtonAdd A <code>JButton</code>.
     * 
     */
    public void setButtonAdd (DataFilterPanelButton jButtonAdd) {
      m_jButtonAdd = jButtonAdd;
    }
  
    /**
     * Retrieves the Add button.
     *
     * @return <code>JButton</code> which represents the add button.
     * 
     */
    public DataFilterPanelButton getButtonAdd() {
      return m_jButtonAdd;
    }
  
    /**
     * Specifies the Browse button.
     * 
     * @param jButtonBrowse A <code>JButton</code>.
     * 
     */
    public void setButtonBrowse (DataFilterPanelButton jButtonBrowse) {
      m_jButtonBrowse = jButtonBrowse;
    }
  
    /**
     * Retrieves the Browse button.
     *
     * @return <code>JButton</code> which represents the browse button.
     * 
     */
    public DataFilterPanelButton getButtonBrowse() {
      return m_jButtonBrowse;
    }
  
    /**
     * Specifies the Delete button.
     * 
     * @param jButtonDelete A <code>JButton</code>.
     * 
     */
    public void setButtonDelete (DataFilterPanelButton jButtonDelete) {
      m_jButtonDelete = jButtonDelete;
    }
  
    /**
     * Retrieves the Delete button.
     *
     * @return <code>JButton</code> which represents the delete button.
     * 
     */
    public DataFilterPanelButton getButtonDelete() {
      return m_jButtonDelete;
    }
  }
  
  /**
   * Inner class used to control the buttons in the <code>BaseDataFilterPanel</code>.
   * 
   */
  public class DataFilterPanelButton extends JButton {
  
    /////////////////////
    //
    // Constants
    //
    /////////////////////

    /**
     * Perform default button processing, which includes enabling/disabling 
     * as necessary when items are shuttled in the <code>DataFilterPanel</code>.
     * 
     */
    public static final int DEFAULT  = -1;

    /**
     * Disable button regardless of current <code>DataFilterPanel</code> state.
     * 
     */
    public static final int DISABLED = 0;

    /**
     * Enable button regardless of current <code>DataFilterPanel</code> state.
     * 
     */
    public static final int ENABLED  = 1;

    public static final int NO_LIMIT  = -1;
  
    /////////////////////
    //
    // Members
    //
    /////////////////////

    /**
     * Button state
     */
    private int m_nState = DEFAULT;

    private JListMutable m_jListMembers = null;

    private int m_nValueLimit = NO_LIMIT;

    private Component m_componentOwner = null;

    private DataFilterControlBar m_dataFilterControlBar = null;
  
    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public DataFilterPanelButton () {
      super();
    }

    public DataFilterPanelButton (DataFilterControlBar dataFilterControlBar) {
      super();
      setDataFilterControlBar (dataFilterControlBar);
    }

    public DataFilterPanelButton (JListMutable jListMembers) {
      super();
      setJListMembers (jListMembers);  
    }

    public DataFilterPanelButton (Component componentOwner) {
      super();
      setOwner (componentOwner);  
    }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Retrieves the <code>Component</code> owner.
     * 
     * @return <code>Component</code> representing the owner. 
     * 
     */
    public Component getOwner () {
      return m_componentOwner;      
    }  

    /**
     * Specifies the <code>Component</code> owner.
     * 
     * @param componentOwner A <code>Component</code> representing the owner.
     * 
     */
    public void setOwner (Component componentOwner) {
      m_componentOwner = componentOwner;    
    }  

    /**
     * Retrieves the button state.
     * 
     * @see #DEFAULT
     * @see #DISABLED
     * @see #ENABLED
     * 
     * @return <code>int</code> representing the button state. 
     */
    public int getState() {
      return m_nState;      
    }  

    /**
     * Specifies the button state.
     * 
     * @param nState A <code>int</code> representing the button state.
     * 
     * @see #DEFAULT
     * @see #DISABLED
     * @see #ENABLED
     * 
     */
    public void setState (int nState) {
      m_nState = nState;    
    }  
  
    /**
     * Enables (or disables) the button.
     * 
     * @param bEnabled A <code>boolean</code> which is <code>true</code> to 
     *        enable the button, otherwise <code>false</code>.
     */
    public void setEnabled (boolean bEnabled) {
      switch (getState()) {
        case DISABLED:
          bEnabled = false;
          break;

        case ENABLED:
          bEnabled = true;
          break;        

        case DEFAULT:
        default:
          break;  
      }
      
      super.setEnabled (bEnabled);
    }

    public boolean getLimitReached() {
      return getLimitReached (getJListMembers());
    }

    public boolean getLimitReached (JListMutable jListMutable) {
      boolean bLimitReached = false;
      
      if (getValueLimit() != DataFilterPanelButton.NO_LIMIT) {
        
        if (jListMutable != null) {
          DefaultListModel defaultListModel = 
            (DefaultListModel) jListMutable.getModel();
          
          if (defaultListModel != null) {
            if (defaultListModel.getSize() >= getValueLimit()) {
              bLimitReached = true;    
            }
          }
        }
      }
      
      return bLimitReached;
    }

    public void setJListMembers (JListMutable jListMembers) {
      m_jListMembers = jListMembers;
    }
  
    public JListMutable getJListMembers() {
      return m_jListMembers;
    }

    public void setValueLimit (int nValueLimit) {
      m_nValueLimit = nValueLimit;
    }
  
    public int getValueLimit() {
      return m_nValueLimit;
    }

    /**
     * Specify the <code>DataFilterControlBar</code>.
     * 
     * @param dataFilterControlBar A <code>DataFilterControlBar</code>.
     * 
     */
    public void setDataFilterControlBar (DataFilterControlBar dataFilterControlBar) {
      m_dataFilterControlBar = dataFilterControlBar;
    }
  
    /**
     * Retrievers the <code>DataFilterControlBar</code>.
     * 
     * @return <code>DataFilterControlBar</code>.
     * 
     */
    public DataFilterControlBar getDataFilterControlBar() {
      return m_dataFilterControlBar;
    }
  }

  /**
   * Inner class based on <code>JListMutable</code>.
   * 
   */
  public class DataFilterPanelJListMutable extends JListMutable {

    public DataFilterPanelJListMutable (ListModel listModel) {
      super (listModel);
    }

    public void removeEditor() {
      super.removeEditor();

      EventObject eventObject = getEventObjectEditCellAt();

      DataFilterPanelButton dataFilterPanelButton = null; 

      if (eventObject != null) {
        if (eventObject.getSource() instanceof DataFilterPanelButton) {
          dataFilterPanelButton = 
            (DataFilterPanelButton) eventObject.getSource();
            
          if (dataFilterPanelButton != null) {
            dataFilterPanelButton.setEnabled (!dataFilterPanelButton.getLimitReached());
          }
        }
      }
    }
  }

  /**
   * Inner class used to control the check boxes in the <code>BaseDataFilterPanel</code>.
   * 
   */
  public class DataFilterPanelCheckBox extends JCheckBox {
    
    /////////////////////
    //
    // Members
    //
    /////////////////////
    
    private DataFilterPanelValue m_dataFilterPanelValue = null;
    
    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public DataFilterPanelCheckBox() {
      super();
    }

    public DataFilterPanelCheckBox (DataFilterPanelValue dataFilterPanelValue) {
      super();
      setDataFilterPanelValue (dataFilterPanelValue);
    }

    public DataFilterPanelCheckBox (String strText, boolean bSelected, DataFilterPanelValue dataFilterPanelValue) {
      super (strText, bSelected);
      setDataFilterPanelValue (dataFilterPanelValue);
    }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////
    
    public void setDataFilterPanelValue (DataFilterPanelValue dataFilterPanelValue) {
      m_dataFilterPanelValue = dataFilterPanelValue;
    }
  
    public DataFilterPanelValue getDataFilterPanelValue() {
      return m_dataFilterPanelValue;
    }
  }
}
