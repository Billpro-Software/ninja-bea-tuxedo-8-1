/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if a <code>Query</code> object catches an OLAP API exception
 * that is thrown because of a problem with OLAP API transactions.
 *
 * @status Documented
 */
public class OLAPTransactionException extends OLAPException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public OLAPTransactionException(String s, Throwable e)
    {
        super(s, OLAPException.TRANSACTION_ERROR, e);
    }
}