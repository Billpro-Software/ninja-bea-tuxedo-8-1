/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/CreateParameterPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     02/13/07 - 
    jramanat    10/25/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/CreateParameterPanelModel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil.gui.component.parameter;

import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.parameter.BaseParameter;
import oracle.dss.util.gui.component.ComponentNode;

public interface CreateParameterPanelModel {
  /**
   * Indicates whether the Item/datatype the Parameter is based is fixed (i.e.
   * can not be changed)
   * 
   * @return true if the Item/datatype is fixed, false otherwise
   */
  public boolean isBasedOnFixed();
  
  /**
   * Specifies the item that the Parameter is based on
   * 
   * @param item The ID of the Item
   * @param prompt indicates whether the user prompt should be updated based on
   * the specified item
   */
  public void setBasedOn(String item, boolean prompt);
  
  /**
   * Retrieves the ComponentNode of the item the Parameter is based on
   * 
   * @return The ComponentNode
   */
  public ComponentNode getBasedOn();
  
  /**
   * Retrieves the Parameter being created
   * 
   * @return The BaseParameter
   */
  public BaseParameter getParameter();
  
  /**
   * Retrieves the default name for the Parameter
   * 
   * @return The name
   */
  public String getDefaultName();
  
  /**
   * Specifies the DataFilters to use in filtering the Parameter's LOV
   * 
   * @param filter The DataFilters
   */
  public void setDataFilter(BaseDataFilter[] filter);
  
  /**
   * Type of the default value
   */
  public String getValueType();
}
