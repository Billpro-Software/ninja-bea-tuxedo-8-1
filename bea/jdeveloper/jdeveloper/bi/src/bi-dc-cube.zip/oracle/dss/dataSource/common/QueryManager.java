
package oracle.dss.dataSource.common;
import java.util.EventObject;
import java.util.Hashtable;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

 
/**
 * Interface representing some operations that are common to the client
 * and the middle tier but not necessarily promoted through the remote
 * interface
 */
public interface QueryManager extends QueryManagerInterface
{
    /**
     * Creates an empty <code>Query</code> object.
     *
     * @return The uninitialized <code>Query</code> object.  
     *         Returns <code>null</code> if the call failed.
     *
     * @status Documented
     */
    public Query createQuery();
    
    /**
     * @hidden
     */
    public void processEventList(EventObject[] elist, Query query);      
    
    public void setProperty(String property, Object value) throws Exception;

    public Object getProperty(String property);
    
    public Hashtable getProperties();    
}
