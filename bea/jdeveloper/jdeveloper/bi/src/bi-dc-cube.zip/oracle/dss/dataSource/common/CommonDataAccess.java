/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/CommonDataAccess.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     10/31/06 - Move files back to oracle.dss.util
    bmoroze     08/12/05 - 
    bmoroze     08/03/05 - 
    bmoroze     08/01/05 - bmoroze_bicommon050729
    bmoroze     08/01/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/CommonDataAccess.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.DataAccess;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.SliceOutOfRangeException;

/**
 * @hidden
 * Common base class for all types of data access implementations in the query
 */
public abstract class CommonDataAccess extends Object implements DataAccess
{
    protected QueryState m_queryState = null;
    protected ReleaseHelper m_releaseHelper = null;
    
    public CommonDataAccess(QueryState queryState)
    {
        setQuery(queryState);
    }
    
    public void setQuery(QueryState state)
    {
        m_queryState = state;
        // Grab a clone of query state
        if (m_queryState != null)
        {
            try
            {
                m_queryState = (QueryState)m_queryState.clone(m_queryState);
            }
            catch (CloneException e)
            {            
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }
    }
    
    public static int getEdgeCount(QueryState state)
    {
        // Always at least three available: if we have the hidden edge
        // then report a fourth
        int count = state.getDimTree().getEdgeCount();
        return count > 3 ? count : 3;        
    }
    
    // javadoc from interface
    public int getEdgeCount()
    {
        return getEdgeCount(m_queryState);
    }        
        
    // javadoc from interface
     public Object getSliceLabel(int edge, int slice, String type) throws EdgeOutOfRangeException, SliceOutOfRangeException
     {
         if (type.equals(MetadataMap.METADATA_SHORTLABEL) || type.equals(MetadataMap.METADATA_LONGLABEL) || type.equals(MetadataMap.METADATA_MEDIUMLABEL) ||
             type.equals(MetadataMap.METADATA_DISPLAYNAME) || type.equals(MetadataMap.METADATA_VALUE)) {
             String label = "";            
                 int max = getLayerCount(edge);
                 int i = 0;
                 while (i < max)
                 {
                    try
                    {
                         label = label + getMemberMetadata(edge, i, slice,
                             type) + " ";
                     i += getMemberDepth(edge, i, slice);
                    }
                    catch (LayerOutOfRangeException e)
                    {
                        throw new SliceOutOfRangeException(e.getMessage(), e);
                    }
                 }

             return label.trim();
             }
             return null;
    }    
    
    public void setReleaseHelper(ReleaseHelper rh)
    {
        m_releaseHelper = rh;
    }
    
    public ReleaseHelper getReleaseHelper() 
    {
        return m_releaseHelper;
    }
    
    /**
     * @hidden
     */
    public interface ReleaseHelper
    {
        public void release();
    }
}
