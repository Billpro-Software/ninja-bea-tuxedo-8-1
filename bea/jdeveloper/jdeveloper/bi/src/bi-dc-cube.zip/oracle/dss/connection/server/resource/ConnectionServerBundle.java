/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.server.resource;

// Imports
import java.util.ListResourceBundle;

/**
 * @hidden
 * @status documented
 */
public class ConnectionServerBundle extends ListResourceBundle
{
   // Connection server messages have been assigned 
   // a range from DVT-16400 to DVT-16499.
    public static final String EXC_INSTANTIATION          = "16400";
    public static final String EXC_ILLEAGAL_ACCESS        = "16401";
    public static final String EXC_DRIVER_NOT_FOUND       = "16402";

    static final Object[][] sMessages =  {
        /**
         * @error DVT-16400 <code>Connection</code> driver cannot be instantiated.
         * @cause A failure occurred while creating an instance of the <code>Connection</code> driver.
         *  The failure can happen only if the <code>Connection</code> drivers are interfaces or abstract classes.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_INSTANTIATION, "Connection driver cannot be instantiated." },
        /**
         * @error DVT-16401 illegal attempt to access the <code>Connection</code> driver
         * @cause A failure occurred while creating an instance of the <code>Connection</code> driver.
         *   The failure can happen only if the <code>Connection</code> drivers are not public or are not in the <code>Connection</code> package.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_ILLEAGAL_ACCESS, "illegal attempt to access the Connection driver" },
        /**
         * @error DVT-16402 <code>Connection</code> driver is not found.
         * @cause A failure occurred while creating an instance of the <code>Connection</code> driver.
         *  The failure can happen if the necessary jar files are not referenced in the CLASSPATH setting.
         * @action Ensure that all necessary classes are included in the CLASSPATH setting.
         * @status documented
         */
        { EXC_DRIVER_NOT_FOUND, "Connection driver is not found." }
    };

   /**
    * Return the string resource table.
    *
    * @status protected
    */
    protected Object[][] getContents() {
        return sMessages;
    }
}