package oracle.dss.dataSource.common;

import java.util.Hashtable;

import oracle.dss.util.DataAccess;

/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

/**
 * @hidden
 *
 * JBO-centric bundling of middle-tier that must "cross the wire."
 * @status hidden
 */
public interface QueryManagerObject 
{
    // NEW TEMPORARY CALLS
    public ReturnObject executeQuery(String queryID, QueryState state) throws Exception;    
    // blm - Selection code moved to dvt-olap
/*    public ReturnObject executePivot(String queryID, QueryState state, String source, String target, int flags, Selection[] selsChanged) throws Exception;
    public ReturnObject executeApplySelections(String queryID, QueryState state, Selection[] selections, Selection oldSel) throws Exception;*/
    public ReturnObject executeProperties(String queryID, QueryState state, Object data) throws Exception;
    public ReturnObject executeRefresh(String queryID, QueryState state, int type) throws Exception;
    
    public void flushDataAccessCache();
    
    public void setProperty(String property, Object value) throws Exception;
    
    public Hashtable getProperties();
    
    /**    
     * @hidden
     * Inform all queries of metadata manager database connection
     */
    public String informQueriesOfMetadataManager(boolean available) throws Exception;
     
    /**
     * Reference to middle tier database API object.
     * Note: going forward, this will be a reference to the DSSDatabase's middle tier
     * implementation that corresponds to the database set on the client side
     *
     * @param db database to use as reference
     * @status hidden
     */
    //public String setMetadataManager(MetadataManagerObject db);    



    /**
     * Register a pluggable interface or definition implementation table specifying
     * a Query interface name String (such as "oracle.dss.dataSource.common.CursorInterface") keying
     * a value giving an application's class name String that implements that interface, and that the
     * Query should instantiate instead of its default.  All of the keys found in the given
     * table will be processed and either added to or deleted from a master table that applies to all queries generated
     * from this QueryManager, depending on the add parameter.
     *
     * @param table a Hashtable specifying a key String of a pluggable Query class or interface name, with a corresponding
     *        value specifying an application's implementation of that pluggable class or interface.
     * @param add <code>true</code> to add the keys in table to the master table, <code>false</code> to delete them
     *
     * @status New
     */
    public void registerPluggableClasses(Hashtable table, boolean add);

                  
    /**
     * @hidden
     */
   public class ReturnObject
   {       
        protected String m_queryID = null;
        protected DataAccess m_cursor = null;
        
        public ReturnObject(String queryID, DataAccess da)
        {
            super();
            m_queryID = queryID;
            m_cursor = da;
        }
        
        public String getQueryID()
        {
            return m_queryID;
        }
        
        public DataAccess getDataAccess()
        {
            return m_cursor;
        }
   }
}
