/*
 * Copyright (c) 1999, 2008, Oracle and/or its affiliates. All rights reserved.
 */
package oracle.dss.dataSource.common;

import java.util.Enumeration;
import java.util.Vector;
import java.util.Hashtable;

import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;

import oracle.dss.metadataUtil.MDU;

import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.drill.ItemDrill;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;
import oracle.dss.util.Utility;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.IDResolver;
import oracle.dss.util.parameters.Parameter;
import oracle.dss.util.parameters.ParameterManager;
import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.persistence.PersistableUtilities;

import java.util.Iterator;

import java.util.Map;

import java.util.Set;

import oracle.dss.metadataManager.common.MDItemCalc;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.selection.XMLEvaluator;
import oracle.dss.selection.parameter.BaseParameter;
import oracle.dss.util.parameters.ParameterValueManager;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.transform.BaseNode;


/**
 * Object for capturing Query state
 */
 // blm - Selection code moved to dvt-olap
public class QueryState extends Object implements XMLizable, java.io.Serializable, MetadataFunctions, /*MetadataInfo, */ParameterManager
{

    /**
     * @internal
     */
    public static final String MD_PERSISTABLE = "QueryStateMDPersistable";
    
    // XML label
    /**
     * @internal
     */
    protected static final String XMLName = "QueryState";
   
    // Selection collection at this point
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    protected SelectionList m_selections = new SelectionList();*/
    
    // DataFilter list 
    /**
     * @internal
     */
    protected BaseDataFilter[] m_dataFilter = null;

    // ColumnSort list
    /**
     * @internal
     */
    protected ColumnSortWrapper[] m_columnSort = null;
    
    // ItemSort list
    /**
     * @internal
     */
    protected ItemSortWrapper[] m_itemSort = null;
    
    /**
     * @internal
     */
    protected ItemDrill[] m_itemDrill = null;
    
    // Measure collection at this point
    /**
     * @internal
     */
    protected String[]  m_measures = null;
    
    // Dimension layout at this point
    /**
     * @internal
     */
    protected DimTree m_dimensions = null;
    
    // Should selection be part of generated XML?
    /**
     * @internal
     */
    protected boolean m_selInXML = true;

    // Property support settings
    /**
     * @internal
     */
    protected PropertySupport m_propSupport = null;
    
    /**
     * @internal
     */
    protected MapSupport m_mapSupport = null;

    /**
     * @internal
     */
    protected String m_measDim = null;
    
    /**
     * @internal
     */
    protected String m_wbValidator = null;
    
    /**
     * @internal
     */
    protected QDRoverride m_qdrOverride = null;
    
    /**
     * @internal
     */
    protected Hashtable m_metadataObjects = new Hashtable();

    /**
     * @internal
     */
    protected Hashtable<String, Parameter> m_parameters = new Hashtable<String, Parameter>();
    //protected ParameterValueMappingManager m_parameterValue = new ParameterValueMappingManagerImpl();

    // Maps columns in layout to MetadataMap->other item IDs to use in member metadata implementations
    //protected Map<String, Map<String, String>> m_extraIDs = new HashMap<String, Map<String, String>>();
    
    protected final String ATTRIBUTE_TAG = PersistableConstants.XMLNS + ":Attribute";
    protected final String ATTRIBUTES_TAG = PersistableConstants.XMLNS + ":Attributes";
    protected final String ATTRIBUTE_ID_PROP = "name";
    
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
    public QueryState(/*SelectionList sels, */String[] measures, DimTree dimensions, PropertySupport ps, MapSupport maps, Object propSupport, String measDim)
    {
        this(/*sels,*/ null, measures, dimensions, ps, maps, propSupport, measDim);
    }
    
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
    public QueryState(/*SelectionList sels, */BaseDataFilter[] filters, String[] measures, DimTree dimensions, PropertySupport ps, MapSupport maps, Object propSupport, String measDim)
    {
        this(/*sels, */filters, measures, dimensions, ps, maps, propSupport, measDim, null);
    }
 
     /**
     * @internal
     */
      // blm - Selection code moved to dvt-olap
    public QueryState(/*SelectionList sels, */BaseDataFilter[] filters, String[] measures, DimTree dimensions, PropertySupport ps, MapSupport maps, Object propSupport, String measDim, Hashtable metadata) {
        this(/*sels, */filters, null, null, null, measures, dimensions, ps, maps, propSupport, measDim, metadata);
    }

     /**
     * @internal
     */
      // blm - Selection code moved to dvt-olap
    public QueryState(/*SelectionList sels, */BaseDataFilter[] filters, ColumnSortWrapper[] columnSort, ItemSortWrapper[] itemSort, ItemDrill[] itemDrill, String[] measures, DimTree dimensions, PropertySupport ps, MapSupport maps, Object propSupport, String measDim, Hashtable metadata)
    {
        this(propSupport, measDim);
        try
        {
            // blm - Selection code moved to dvt-olap
/*            if (sels != null)
            {
                m_selections = (SelectionList)sels.clone();
            }*/
            if (filters != null)
            {
                m_dataFilter = new BaseDataFilter[filters.length]; 
                for (int i = 0; i < m_dataFilter.length; i++)
                    m_dataFilter[i] = (BaseDataFilter)filters[i].clone();

            }
            if (columnSort != null) {
              m_columnSort = new ColumnSortWrapper[columnSort.length];
              for (int i = 0; i < m_columnSort.length; i++) {
                m_columnSort[i] = (ColumnSortWrapper)columnSort[i].clone();
              }
            }
            if (itemSort != null) {
              m_itemSort = new ItemSortWrapper[itemSort.length];
              for (int i = 0; i < m_itemSort.length; i++) {
                m_itemSort[i] = (ItemSortWrapper)itemSort[i].clone();
              }
            }
            if (itemDrill != null)
            {
                m_itemDrill = new ItemDrill[itemDrill.length];
                for (int i = 0; i < m_itemDrill.length; i++)
                {
                    m_itemDrill[i] = (ItemDrill)itemDrill[i].clone();
                }
            }
            if (measures != null)
            {
                m_measures = (String[])Utility.arraycopy(measures);
            }
            if (dimensions != null)
            {
                m_dimensions = (DimTree)dimensions.clone();
            }

            if (ps != null)
            {
                m_propSupport = (PropertySupport)ps.clone(propSupport);
            }
            if (maps != null)
            {
                m_mapSupport = (MapSupport)maps.clone();
            }
            if (metadata != null)
            {
                m_metadataObjects = (Hashtable)metadata.clone();
            }
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    /**
     * @internal
     */
    public Hashtable getMetadata()
    {
        return m_metadataObjects;
    }

    /**
     * @internal
     */
    public QueryState(Object propSupport, String measDim)
    {
        super();
        
        m_measDim = measDim;
        
        m_propSupport = new PropertySupport(propSupport);
        m_mapSupport = new MapSupport(false);
    }
    
    /**
     * @internal
     */
    public String getTagName()
    {
        return XMLName;
    }
    
    /**
     * @internal
     * Set the entire set of Selection objects in the state
     * 
     * @param selections Selections to set
     */
     // blm - Selection code moved to dvt-olap
/*    public void setSelections(SelectionList selections)
    {
        m_selections = selections;
    }*/

    /**
     * @internal
     * @throws oracle.dss.dataSource.common.QueryException
     * @param filters
     */
    public void setDataFilters(BaseDataFilter[] filters) throws QueryException
    {
        m_dataFilter = filters;
//        _updateParameterMappings();
    }

    /**
     * @internal
     */
    public BaseDataFilter[] getDataFilters()
    {        
        return m_dataFilter;
    }

    /**
     * @internal
     * @throws oracle.dss.dataSource.common.QueryException
     * @param columnSort
     */
    public void setColumnSorts(ColumnSortWrapper[] columnSort) throws QueryException
    {
        m_columnSort = columnSort;
    }

    /**
     * @internal
     */
    public ColumnSortWrapper[] getColumnSorts()
    {        
        return m_columnSort;
    }

    /**
     * @internal
     * @throws oracle.dss.dataSource.common.QueryException
     * @param itemSort
     */
    public void setItemSorts(ItemSortWrapper[] itemSort) throws QueryException
    {
        m_itemSort = itemSort;
    }

    /**
     * @internal
     */
    public ItemSortWrapper[] getItemSorts()
    {        
        return m_itemSort;
    }

    /**
     * @internal
     * @throws oracle.dss.dataSource.common.QueryException
     */
    public void setItemDrills(ItemDrill[] itemDrill) 
    {
        m_itemDrill = itemDrill;
    }

    /**
     * @internal
     */
    public ItemDrill[] getItemDrills()
    {        
        return m_itemDrill;
    }


    /**
     * @internal
     * @param object
     */
    public void registerMDObject(MDObject object)
    {
        m_metadataObjects.put(object.getUniqueID(), object);
    }
    
    // Shouldn't be called on state
    public MDObject getMDObjectFromMDPersistable(MDObject mdObject)
    {
        return mdObject;
    }
    
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void loadMetadata(MetadataFunctions metadata) throws MetadataManagerException
    {
        // Load all the metadata referenced by this query state
        if (m_measures != null)
        {
            for (int i = 0; i < m_measures.length; i++)
            {
                m_metadataObjects.put(m_measures[i], metadata.getMDObjectFromMDPersistable((MDMeasure)metadata.getMDObject(MM.UNIQUE_ID, m_measures[i], MM.MEASURE)));
            }
        }
        
        if (m_dimensions != null)
        {
            int edgeCount = m_dimensions.getEdgeCount();
            for (int e = 0; e < edgeCount; e++)
            {
                int layerCount = m_dimensions.getNodeCount(e);
                for (int l = 0; l < layerCount; l++)
                {
                    String dim = null;
                    try
                    {
                        dim = m_dimensions.getNode(e, l).getName();
                    }
                    catch (CloneException c)
                    {
                        throw new QueryRuntimeException(c.getMessage(), c);
                    }
                    getMDObjectAndRelatives(dim, metadata);
                }
            }
        }
        
        if (m_selections != null)
        {
            Iterator list = m_selections.iterator();
            while (list.hasNext())
            {
                Selection currSel = (Selection)list.next();
                Vector ids = null;
                try
                {
                    ids = currSel.getAllDependentIDs(metadata.getMeasureDim(), metadata);
                }
                catch (InvalidMetadataException ime)
                {                    
                }
                if (ids != null)
                {
                    Enumeration idsEnum = ids.elements();
                    while (idsEnum.hasMoreElements())
                    {
                        String id = (String)idsEnum.nextElement();
                        getMDObjectAndRelatives(id, metadata);
                    }
                }
            }
        }        
    }            
    
    // Makes sure to load appropriate child objects of certain MDObjects
    protected void getMDObjectAndRelatives(String id, MetadataFunctions metadata)
    {        
        try
        {
            MDObject obj = metadata.getMDObject(MM.UNIQUE_ID, id, MM.OBJECT);
            if (obj instanceof MDHierarchy)
            {
                // Add all its levels, if any
                MDLevel[] levels = ((MDHierarchy)obj).getLevels();
                if (levels != null)
                {
                    for (int i = 0; i < levels.length; i++)
                        if (levels[i] != null)
                            m_metadataObjects.put(levels[i].getUniqueID(), levels[i]);
                }
            }
            
            MDObject putObj = metadata.getMDObject(MM.UNIQUE_ID, id, MM.OBJECT);
            if (putObj != null)
                m_metadataObjects.put(id, putObj);
        }
        catch (MetadataManagerException e)
        {
        }
    }*/
    
    /**
     * @internal
     */
    public void setMeasureDim(String measDim)
    {
        m_measDim = measDim;
    }
    
    /**
     * @internal
     */
    public String getMeasureDim()
    {
        return m_measDim;
    }
    
    /**
     * @internal
     */
    public boolean isMeasure(String id)
    {
        if (id != null)
            return id.equals(getMeasureDim());
        
        return false;
    }
    
    /**
     * @internal
     */
    public void setMDObject(String strID, String strValue, String strType, MDObject obj) throws MetadataManagerException
    {
        if (obj != null)
        {
            // Store it: this is for calc->cursor processing
            // Get the unique ID: storage only by unique ID
            String ID = ((MDObject)obj).getUniqueID();
            m_metadataObjects.remove(ID);
            m_metadataObjects.put(ID, obj); 
        }        
    }
    
    /**
     * @internal
     */
    public MDObject getMDObject(String strID, String strValue, String strType) throws MetadataManagerException
    {
        if (strValue == null || strID == null)
            return null;
        
        if (strID.equals(MM.UNIQUE_ID))
        {
            return (MDObject)m_metadataObjects.get(strValue);
        }
        else if (strID.equals(MM.OLAPI_RUNTIME_ID))
        {
            Enumeration objects = m_metadataObjects.elements();
            while (objects.hasMoreElements())
            {
                MDObject mdObj = (MDObject)objects.nextElement();
                if (mdObj != null && strValue.equals(mdObj.getOLAPIRuntimeID()))
                    return mdObj;
            }
        }
        return null;
    }
    
    /**
     * @internal
     */
    public String getIDFromName(String dimension, String hierarchy, String name)
    {        
        if (hierarchy != null)
        {
            try
            {
                MDHierarchy hier = (MDHierarchy)getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
                MDLevel[] levels = hier.getLevels();
                if (levels != null)
                {
                    for (int i = 0; i < levels.length; i++)
                    {
                        if (levels[i].getName().equals(name) || levels[i].getUniqueID().equals(name))
                            return levels[i].getUniqueID();
                    }            
                }
            }
            catch (MetadataManagerException mme)
            {
                return null;
            }            
        }
        return null;
    }
    

    /**
     * @internal
     */
    public boolean isTimeDimension(String dimension) throws MetadataManagerException
    {
        if (dimension != null)
        {
            MDDimension dim = (MDDimension)getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
            if (dim != null && dim.isTimeDimension())
            {
                return true;
            }
        }
        return false;
    }    
    
    /**
     * @internal
     * Sets whether or not selections should be part of the XML
     */
    public void setSelectionsInXML(boolean inxml) {
        m_selInXML = inxml;
    }
    
    private ContainerNode getAttributes(MetadataManagerServices mms)
    {
        if (m_dimensions == null)
            return null;
        
        ContainerNode attrContainer = null;
        // For each item in the layout, see if that item has a Map of metadata types->other column ID names
        // for use as attributes in the cursor
        BaseNode[][] nodes = null;
        try
        {
            nodes = m_dimensions.getDimTree();
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (nodes != null)
        {
            for (int e = 0; e < nodes.length; e++)
            {
                if (nodes[e] != null)
                {
                    for (int l = 0; l < nodes[e].length; l++)
                    {
                        // Check this MM Object for a map
                        try
                        {
                            MDObject mdObj = mms.getMDObject(MM.UNIQUE_ID, nodes[e][l].getName(), MM.OBJECT);                                
                            Property prop = mdObj != null ? mdObj.getProperty(MM.ATTRIBUTE_MAP) : null;
                            if (prop != null && prop.getObjValue() instanceof Map)
                            {
                                // There's a map here: walk it and output the appropriate extra column tags
                                Map<String, String> map = (Map<String, String>)prop.getObjValue();
                                Set<String> keySet = map.keySet();
                                Iterator<String> iter = keySet.iterator();
                                String id = null;
                                while (iter.hasNext())
                                {
                                    id = iter.next();
                                    if (id != null)
                                    {
                                        if (attrContainer == null)
                                            attrContainer = new ContainerNode(ATTRIBUTES_TAG);
                                        ObjectNode node = new ObjectNode(ATTRIBUTE_TAG);
                                        // Walk the map of types->new IDs
                                        node.addProperty(ATTRIBUTE_ID_PROP, id);
                                        attrContainer.addContainedObject(node);                
                                    }
                                }
                            }
                            
                        }
                        catch (Exception ex)
                        {                                
                            throw new QueryRuntimeException(ex.getMessage(), ex);
                        }
                    }
                }
            }
        }      
        return attrContainer;
    }
    
    /**
     * @internal
     */
    public Object getXML(String name, XMLContext retCons) {
        ObjectNode root = new ObjectNode(PersistableConstants.XMLNS + ":" + name);
        root.addProperty("name", name.toLowerCase());
        
        // Dimensions
        if (m_dimensions != null) {
            root.addProperty((ObjectNode)m_dimensions.getXML(retCons));
        }
        
        MetadataManagerServices mms = null;
        if (retCons.getScope() != null)
        {
            mms = (MetadataManagerServices)retCons.getScope().getObject(MetadataManagerServices.class.getName());
        }
        // Measure list
        ContainerNode container = new ContainerNode(PersistableConstants.XMLNS + ":" + "Measures");
        container.addProperty("name", "Measures".toLowerCase());
        if (m_measures != null) {
            for (int i = 0; i < m_measures.length; i++) {
                ObjectNode node = new ObjectNode(PersistableConstants.XMLNS + ":" + "Measure");
                node.addProperty("name", m_measures[i]);
                if (mms != null)
                {
                    // Check for MDItemCalc: if so, we need the extra expression property output
                    try
                    {
                        MDObject mdObj = mms.getMDObject(MM.UNIQUE_ID, m_measures[i], MM.OBJECT);
                        if (mdObj instanceof MDItemCalc)
                        {
                            MDItemCalc itemCalc = (MDItemCalc)mdObj;
                            node.addProperty("expression", itemCalc.getExpression());
                        }
                    }
                    catch (MetadataManagerException e)
                    {
                        throw new QueryRuntimeException(e.getMessage(), e);
                    }
                }
                
                container.addContainedObject(node);
            }
        }
        root.addContainer(container);
    
        // Call IDResolver API with our measures
        IDResolver resolver = Utility.getIDResolver(retCons);
        if (m_measures != null && resolver != null)
        {          
            for (int i = 0; i < m_measures.length; i++)
            {
                resolver.setDependentID(m_measures[i]);
            }
        }        
    
        // Check for an XML processor: this is a sign that this is being generated for evaluation
        XMLEvaluator xmlEval = (XMLEvaluator)PersistableUtilities.getContextValue(retCons, oracle.dss.selection.XMLEvaluator.class.getName());
        if (xmlEval != null)
        {              
            ContainerNode attrContainer = getAttributes(mms);
            if (attrContainer != null)
                root.addContainer(attrContainer);
        }
        
        // Selections
        // blm - Selection code moved to dvt-olap
/*        if (m_selInXML)
        {
            ContainerNode sels = new ContainerNode("Selections");
            if (m_selections != null) {
                ObjectNode sel;
                Iterator selenum = m_selections.iterator();
                while (selenum.hasNext()) {
                    sels.addContainedObject((ObjectNode)((Selection)selenum.next()).getXML(retCons));
                }
            }
            root.addContainer(sels);
        }*/
        
        if (m_dataFilter != null)
        {
            ContainerNode dfs = new ContainerNode(PersistableConstants.XMLNS + ":DataFilters");
            dfs.addProperty("name", "datafilters");
            ObjectNode node = null;
            boolean anyAdded = false;
            for (int i = 0; i < m_dataFilter.length; i++)
            {
                node = (ObjectNode)m_dataFilter[i].getXML(retCons);
                if (node != null)
                {
                    anyAdded = true;
                    dfs.addContainedObject(node);
                }
            }
            if (anyAdded)
                root.addContainer(dfs);
        }
        
        if (m_columnSort != null) {
          ContainerNode cs = new ContainerNode(PersistableConstants.XMLNS + ":ColumnSorts");
          for (int i = 0; i < m_columnSort.length; i++) {
            cs.addContainedObject((ObjectNode)m_columnSort[i].getXML(retCons));
          }
          root.addContainer(cs);
        }
        if (m_itemSort != null) {
          ContainerNode is = new ContainerNode(PersistableConstants.XMLNS + ":ItemSorts");
          for (int i = 0; i < m_itemSort.length; i++) {
            is.addContainedObject((ObjectNode)m_itemSort[i].getXML(retCons));
          }
          root.addContainer(is);
        }
        
        if (m_itemDrill != null) {
          ContainerNode id = null;
          ObjectNode objNode = null;
          for (int i = 0; i < m_itemDrill.length; i++)
          {
              objNode = null;
              // Determine if we even want to output this drill, if there is an xml processor
              // Check for an XML processor
              if (xmlEval != null)
              {
                  // Check with the xmlEval to see if this drill should be processed
                  if (xmlEval.processXML(m_itemDrill[i].getItem(), ItemDrill.ITEM_PROPERTY, m_itemDrill[i]) != null)
                  {
                      objNode = (ObjectNode)m_itemDrill[i].getXML(retCons);
                  }
              }
              else
              {
                  objNode = (ObjectNode)m_itemDrill[i].getXML(retCons);
              }
              if (objNode != null)
              {
                  if (id == null)
                      id = new ContainerNode(PersistableConstants.XMLNS + ":ItemDrills");
                  id.addContainedObject(objNode);
              }              
          }
          if (id != null)
            root.addContainer(id);
        }
        
        // Output parameters
        if (m_parameters != null && !m_parameters.isEmpty())
        {
            // Output key/value pairs
            ContainerNode params = new ContainerNode(PersistableConstants.XMLNS + ":Parameters");
            params.addProperty("name", "parameters");
            Enumeration<String> keys = m_parameters.keys();
            Parameter value = null;
            ObjectNode node = null;
            while (keys.hasMoreElements())
            {
                value = m_parameters.get(keys.nextElement());
                if (value instanceof XMLizable)
                {
                    params.addContainedObject((ObjectNode)((XMLizable)value).getXML(retCons));
                }
            }
            root.addContainer(params);
        }
        return root;
    }
    
    /**
    * @internal
    */
    public Object getXML(XMLContext retCons) {
        return getXML("QueryState", retCons);
    }

    /**
     * @internal
     * Return the dimension layout in this state
     *
     * @return dimension layout
     */
    public DimTree getDimTree() {
        return m_dimensions;
    }

    /**
     * @internal
     */
    public void setDimTree(DimTree dimensions)
    {
        m_dimensions = dimensions;
    }
    
    /**
     * @internal
     * Return the Selections that are part of this state
     *
     * @return list of Selections in state
     */
     // blm - Selection code moved to dvt-olap
/*    public SelectionList getSelections()
    {
        return m_selections;
    }*/

    /**
     * @internal
     * Return the measures that are part of this state
     *
     * @return measures
     */
    public String[] getMeasures() {
        return m_measures;
    }

    /**
     * @internal
     * Specify the measures that are part of this state
     *
     * @param  strMeasures An array of <code>String</code> values that represents
     *                     the measures to set.
     */
    public void setMeasures(String[] strMeasures) {
      m_measures = (strMeasures != null) ?
        (String[])Utility.arraycopy (strMeasures) : null;
    }

    /**
     * @internal
     */
    public void setMapSupport(MapSupport ms)
    {
        m_mapSupport = ms;
    }
    
    /**
     * @internal
     * Set property support
     */
    public void setPropertySupport(PropertySupport ps)
    {
        m_propSupport = ps;
    }

    /**
     * @internal
     * Get property support
     */
    public PropertySupport getPropertySupport()
    {
        if (m_propSupport == null)
            m_propSupport = new PropertySupport(null);
        return m_propSupport;
    }

    /**
     * @internal
     * Get Map support
     */
    public MapSupport getMapSupport()
    {
        if (m_mapSupport == null)
            m_mapSupport = new MapSupport(false);
        return m_mapSupport;
    }
    
    /**
     * @internal
     */
    public boolean equals(Object obj)
    {
        if (obj == null || !(obj instanceof QueryState))
        {
            return false;
        }
        QueryState state = (QueryState)obj;
        return QueryUtil.compareStringVectors(m_measures, state.m_measures) &&
        // blm - Selection code moved to dvt-olap
/*               m_selections.contentEqual(state.m_selections) &&*/
               m_dimensions.equals(state.m_dimensions) &&
               QueryUtil.compareArrays(state.m_dataFilter, m_dataFilter) &&
               QueryUtil.compareArrays(state.m_columnSort, m_columnSort) &&
               QueryUtil.compareArrays(state.m_itemSort, m_itemSort) &&
               QueryUtil.compareArrays(state.m_itemDrill, m_itemDrill);
    }
    
    public String toString()
    {
        return toString(null);
    }
    
    protected String getIDAndName(MetadataFunctions metadataManager, String ID)
    {
        if (metadataManager == null)
            return ID;
            
        if (metadataManager != null)
        {
            try
            {
                MDObject obj = metadataManager.getMDObject(MM.UNIQUE_ID, ID, MM.OBJECT);
                if (obj != null)
                    return ID + "(" + obj.getName() + ")";
            }
            catch (MetadataManagerException e)
            {
            }
        }        
        return ID;
    }
    
    public String toString(MetadataFunctions metadataManager)
    {
        // blm - Selection code moved to dvt-olap
/*        List sels = new ArrayList();
        sels = getSelections();*/
        String message = "===========QUERY STATE===========\n";
        // blm - Selection code moved to dvt-olap
/*        if (sels != null)
        {
            message += "Selections:\n";
            Iterator sel = sels.iterator();
            while (sel.hasNext())
                message += sel.next() + "\n";
        }*/
        BaseDataFilter[] df = getDataFilters();
        if (df != null)
        {
            for (int i = 0; i < df.length; i++)
            {
                if (df[i] != null)
                    message += df[i].toString() + "\n";
            }
        }
        message += "\nMeasures:\n";
        Vector calcList = new Vector();
        if (getMeasures() != null)
            for (int meas = 0; meas < getMeasures().length; meas++)
            {
                message += getIDAndName(metadataManager, getMeasures()[meas]) + "\n";

                try
                {
                    // Get the MDobject
                    if (metadataManager != null)
                    {
                        MDObject mdobj = metadataManager.getMDObject(MM.UNIQUE_ID, getMeasures()[meas], MM.MEASURE);
                        if (mdobj != null)
                        {
                            // Retrieve the CalcStep wrapper
                            UserObject userObject =
                                mdobj.getUserObject (MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE);

                            // Retrieve the actual CalcStep object
                            if (userObject != null)
                            {
                                // blm - Selection code moved to dvt-olap
/*                                if (userObject.getObject() instanceof Step)
                                {
                                    Step step = (Step) userObject.getObject();
                                    if (step != null)
                                    {
                                        calcList.addElement(step);
                                    }
                                }*/
                            }
                        }
                    }
                }
                catch (MetadataManagerException mme)
                {
                }
            }
        if (calcList.size() > 0)
        {
            message += "\nCalculations:\n";
            Enumeration calcs = calcList.elements();
            while (calcs.hasMoreElements())
            {
                message += calcs.nextElement().toString() + "\n";
            }
        }
        ColumnSortWrapper[] cs = getColumnSorts();
        if (cs != null)
        {
            message += "Column Sorts:\n";
            for (int i = 0; i < cs.length; i++)
                if (cs[i] != null)
                    message += cs[i].toString() + "\n";
        }
        
        ItemSortWrapper[] is = getItemSorts();
        if (is != null)
        {
            message += "Item Sorts:\n";
            for (int i = 0; i < is.length; i++)
                if (is[i] != null)
                    message += is[i].toString() + "\n";
        }
        
        ItemDrill[] id = getItemDrills();
        if (id != null)
        {
            message += "Item Drills:\n";
            for (int i = 0; i < id.length; i++)
                if (id[i] != null)
                    message += id[i].toString() + "\n";                    
        }
        
        message += "\nLayout:\n";
        if (getDimTree() != null)
            message += getIDAndName(metadataManager, getDimTree().toString(metadataManager)) + "\n";
        if (getPropertySupport() != null)
        {
            message += getPropertySupport().toString() + "\n";
        }
        message += "\nMaps:\n";
        message += getMapSupport().toString() + "\n";
        message += "===========END STATE===========\n";
        return message;
    }
    
    /**
     * @internal
     */
    public void setQDROverride(QDRoverride qdroverride)
    {
        m_qdrOverride = qdroverride;
    }
    
    /**
     * @internal
     */
    public QDRoverride getQDROverride()
    {
        return m_qdrOverride;
    }
    
    /**
     * @internal
     */
    public void setWritebackValidator(String validator)
    {
        m_wbValidator = validator;
    }
    
    /**
     * @internal
     */
    public String getWritebackValidator()
    {
        return m_wbValidator;
    }
    
    /**
    * @internal
    */
    public void setXML(XMLContext context, Object node) {
        ObjectNode root = (ObjectNode)node;
        m_dimensions = new DimTree();
        ObjectNode temp = root.getPropertyValueAsObjectNode(PersistableConstants.XMLNS + ":DimTree", true);
        if (temp != null) {
            m_dimensions.setXML(context, temp);
        }
        m_measures = QueryUtil.getStringArrayFromXML(root.getContainer(PersistableConstants.XMLNS + ":Measures"));

        // Call IDResolver API with our measures
        IDResolver resolver = Utility.getIDResolver(context);
        if (m_measures != null && resolver != null)
        {          
            String id = null;
            for (int i = 0; i < m_measures.length; i++)
            {
                id = resolver.getDependentID(m_measures[i]);
                if (id == null// || id.equals(PersistableConstants.INVALID_ID)
                )
                {
                    //throw new InvalidMeasureRuntimeException(null, id, null);
                }
                else
                {
                    m_measures[i] = id;
                }
            }
        }        
        
        // Selections
        // blm - Selection code moved to dvt-olap
/*        m_selections = new SelectionList();
        ContainerNode sels = root.getContainer(PersistableConstants.XMLNS + ":Selections");
        if (sels != null)
        {
            Enumeration sellist = sels.getContainedObject();
            ObjectNode sel;
            Selection newSel;
            while (sellist.hasMoreElements()) {
                sel = (ObjectNode)sellist.nextElement();
                newSel = new Selection();
                newSel.setXML(context, sel);
                m_selections.add(newSel);
            }
        }
  */      
        // Data filters        
        ContainerNode df = root.getContainer(PersistableConstants.XMLNS + ":DataFilters");
        if (df != null)
        {
            Vector <BaseDataFilter>dfs = new Vector<BaseDataFilter>() ;
            Enumeration dfenum = df.getContainedObject();
            ObjectNode filter;
            while (dfenum.hasMoreElements()) {
                filter = (ObjectNode)dfenum.nextElement();
                BaseDataFilter bdf = BaseDataFilter.loadDataFilter(filter);
                if (bdf != null)
                {
                    bdf.setXML(context, filter);
                    dfs.addElement(bdf);
                }
            }            
            m_dataFilter = (BaseDataFilter[])BaseDataFilter.copyListToArray(dfs);
        }
        
        // Column sorts
        ContainerNode cs = root.getContainer(PersistableConstants.XMLNS + ":ColumnSorts");
        if (cs != null) {
          Vector css = new Vector();
          Enumeration csenum = cs.getContainedObject();
          ObjectNode sort;
          while (csenum.hasMoreElements()) {
            sort = (ObjectNode)csenum.nextElement();
            ColumnSortWrapper csort = new ColumnSortWrapper();
            csort.setXML(context, sort);
            css.addElement(csort);
          }
          m_columnSort = (ColumnSortWrapper[])QueryUtil.copyListToArray(css);
        }
        // Item sorts
        ContainerNode is = root.getContainer(PersistableConstants.XMLNS + ":ItemSorts");
        if (is != null) {
          Vector iss = new Vector();
          Enumeration isenum = is.getContainedObject();
          ObjectNode sort;
          while (isenum.hasMoreElements()) {
            sort = (ObjectNode)isenum.nextElement();
            ItemSortWrapper isort = new ItemSortWrapper();
            isort.setXML(context, sort);
            iss.addElement(isort);
          }
          m_itemSort = (ItemSortWrapper[])QueryUtil.copyListToArray(iss);
        }
        
        // Item drills
        ContainerNode id = root.getContainer(PersistableConstants.XMLNS + ":ItemDrills");
        if (id != null) {
          Vector ids = new Vector();
          Enumeration idenum = id.getContainedObject();
          ObjectNode drill;
          while (idenum.hasMoreElements()) {
            drill = (ObjectNode)idenum.nextElement();
            ItemDrill idrill = new ItemDrill();
            idrill.setXML(context, drill);
            ids.addElement(idrill);
          }
          m_itemDrill = (ItemDrill[])QueryUtil.copyListToArray(ids);
        }
        // parameters
        try
        {
            ContainerNode params = root.getContainer(PersistableConstants.XMLNS + ":Parameters"); 
            if (params != null)
            {
                // Output key/value pairs
                Enumeration objs = params.getContainedObject();
                BaseParameter value = null;
                ObjectNode paramObj = null;
                m_parameters = new Hashtable<String, Parameter>();
                while (objs.hasMoreElements())
                {
                    paramObj = (ObjectNode)objs.nextElement();
                    // Must instantiate proper class
                    value = BaseParameter.getParameterObject(paramObj);
                    value.setXML(context, paramObj);
                    m_parameters.put(value.getName(), value);
                }
            }
        }        
        catch (NoSuchPropertyException e)
        {            
        }
    }

    /**
     * @internal
     * Clone the QueryState object
     *
     */
    public Object clone(Object propSupport) throws CloneException
    {
        // blm - Selection code moved to dvt-olap
        QueryState newState = new QueryState(/*m_selections, */m_dataFilter, m_columnSort, m_itemSort, m_itemDrill, m_measures, m_dimensions, m_propSupport, m_mapSupport, propSupport, m_measDim, null);
        newState.m_metadataObjects = (Hashtable)m_metadataObjects.clone();
        return newState;
    }

    /**
     * @internal
     * Return <code>true</code> if the given hierarchy has
     * levels, <code>false</code> if not
     */
     // blm - Selection code moved to dvt-olap
/*    public boolean hasLevels(String hierarchy) throws SelectionException
    {
        if (hierarchy == null)
        {
            return false;
        }
        try
        {
            MDHierarchy hier = (MDHierarchy)getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
            if (hier == null)
            {
                return false;
            }
            return hier.getLevels() != null && hier.getLevels().length > 0;
        }
        catch (MetadataManagerException e)
        {
            throw new SelectionException(e.getMessage(), e);
        }
    }
*/
    /**
     * @internal
     * Return a level name given a dimension, hierarchy and level depth offset.
     *
     * @param dimension dimension for which to get the level name
     * @param hierarchy hierarchy within dimension for which to get the level name
     * @param levelDepth level depth offset within hierarchy at which to find name
     *
     * @return level name
     */
     // blm - Selection code moved to dvt-olap
/*    public String getLevelNameForOffset(String dimension, String hierarchy, int levelDepth)
    {
        // Get the list of levels
        String[] levelNames = getLevelNames(dimension, hierarchy);

        if (levelNames != null && levelDepth >= 0 && levelDepth < levelNames.length)
        {
            return levelNames[levelDepth];
        }
        return null;
    }
*/
    /**
     * @internal
     * Return a level depth offset given a dimension, hierarchy, and level name.
     *
     * @param dimension dimension for which to get the level depth
     * @param hierarchy hierarchy within dimension for which to get the level depth
     * @param level level name within hierarchy for which to get the level depth
     *
     * @return level depth offset
     */
     // blm - Selection code moved to dvt-olap
/*    public int getLevelOffsetForName(String dimension, String hierarchy, String level)
    {
        if (level == null)
            return -1;

        // Get the level names
        String[] levelNames = getLevelNames(dimension, hierarchy);
        if (levelNames == null)
            return -1;

        for (int i = 0; i < levelNames.length; i++)
        {
            if (level.equals(levelNames[i]))
                return i;
        }
        return -1;
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    protected String[] getLevelNames(String dimension, String hierarchy)
    {
        if (dimension == null || hierarchy == null)
            return null;

        // For now, can just look up hierarchy based on unique ID directly
        MDHierarchy hierObj = null;
        try
        {
            hierObj = (MDHierarchy)getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
        }
        catch (MetadataManagerException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (hierObj == null)
            return null;

        MDLevel[] levels = null;
        try
        {
            levels = hierObj.getLevels();
        }
        catch (MetadataManagerException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (levels == null)
            return null;

        String[] levelNames = new String[levels.length];
        for (int l = 0; l < levels.length; l++)
        {
            levelNames[l] = levels[l] != null ? levels[l].getName() : null;
        }
        return levelNames;
    }
  */ 
    /**
     * @internal
     * Returns the default hierarchy ID, if any
     */
     // blm - Selection code moved to dvt-olap
/*    public String getDefaultHierarchy(String dimension) throws SelectionException
    {
        if (dimension == null)
        {
            return null;
        }
        try
        {
            MDDimension dim = (MDDimension)getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
            if (dim == null)
            {
                return null;
            }
            MDHierarchy hier = dim.getDefaultHierarchy();
            if (hier != null)
                return hier.getUniqueID();
        }
        catch (MetadataManagerException e)
        {
            throw new SelectionException(e.getMessage(), e);
        }
        return null;
    } 
  */  
    /**
     * @internal
     */
    public boolean usesParameter(Parameter parameter) {
      BaseDataFilter[] dataFilters = getDataFilters();
      if (dataFilters != null) {
        for (int i = 0; i < dataFilters.length; i++) {
          if (dataFilters[i].usesParameter(parameter)) {
            return true;
          }
        }
      }
      return false;      
    }
    
    /**
     * @internal
     * @return
     */
    public void setParameter(Parameter parameter)
    {
        // Store it
        m_parameters.put(parameter.getName(), parameter);
    }
    
    /**
     * @internal
     */
    public Parameter getParameter(String name)
    {
        return m_parameters.get(name);
    }
    
    /**
     * @internal
     */
    public void removeParameter(Parameter parameter)
    {
        if (parameter != null) {
          m_parameters.remove(parameter.getName());
        }
    }
    
    /**
     * @internal
     */
    public Parameter[] getParameters() {
      Vector params = new Vector();
      BaseDataFilter[] dataFilters = getDataFilters();
      if (dataFilters != null) {
        for (int i = 0; i < dataFilters.length; i++) {
          String[] filterParameters = dataFilters[i].getParameterNames();
          if (filterParameters != null) {
            for (int j = 0; j < filterParameters.length; j++) {
              if (!params.contains(filterParameters[j])) {
                params.add(filterParameters[j]);
              }
            }
          }
        }
      }
      int size = params.size();
      if (size > 0) {
          Parameter[] paramObjs = new Parameter[size];
          for (int i = 0; i < size; i++)
              paramObjs[i] = m_parameters.get(params.elementAt(i));
          return paramObjs;

      }
      return null;
    }
    
    public ParameterValueManager getParameterValueManager()
    {
        return null;
    }
    /**
     * @internal
     */
/*    public ParameterValueMappingManager getParameterValue() {
      return m_parameterValue;
    }
    
    private void _updateParameterMappings() {
      Vector mappedParameters = Utility.copyArrayToVector(m_parameterValue.getMappedParameters());
      if (mappedParameters == null) {
        mappedParameters = new Vector();
      }
      Vector parameters = Utility.copyArrayToVector(getParameters());
      if (parameters == null) {
        parameters = new Vector();
      }
      for (int i = parameters.size() - 1; i >= 0; i--) {
        Parameter param = (Parameter)parameters.get(i);
        if (param.getProperty(Parameter.SHARED)) {
          parameters.remove(param);
        }
      }
      for (int i = 0; i < mappedParameters.size(); i++) {
        if (!parameters.contains(mappedParameters.get(i))) {
          m_parameterValue.removeMappedParameter((Parameter)mappedParameters.get(i));
        }
      }
      for (int i = 0; i < parameters.size(); i++) {
        if (!mappedParameters.contains(parameters.get(i))) {
          m_parameterValue.addMappedParameter((Parameter)parameters.get(i));
        }
      }
    }*/
}
