/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/sort/impl/CrosstabSortPanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil.gui.component.sort.impl;

import java.util.Hashtable;
import java.util.Vector;

import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.sort.CrosstabSortPanelModel;
import oracle.dss.datautil.gui.component.sort.resource.SortBundle;
import oracle.dss.datautil.provider.BIProvider;
import oracle.dss.datautil.provider.MetadataProvider;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.selection.sortWrapper.ItemSortWrapper;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DimensionSortInfo;
import oracle.dss.util.QDRSortInfo;
import oracle.dss.util.SortInfo;
import oracle.dss.util.gui.component.ComponentNode;

/**
 * @hidden
 *
 * <pre>
 * <code>CrosstabSortPanelModelImpl</code>
 * </pre>
 *
 * @author jramanat
 * @since  11.0.0.0.0
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   04/08/08 - 
 *
 */
public class CrosstabSortPanelModelImpl implements CrosstabSortPanelModel {  

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  private static final String RESOURCE_BUNDLE = "oracle.dss.datautil.gui.component.sort.resource.SortBundle";

  /////////////////////
  //
  // Members
  //
  /////////////////////

  private ComponentContext m_componentContext = null;
  private DataDirector m_dataDirector = null;
  private MetadataProvider m_metadataProvider = null;
  private String m_strSortItem = null;
  private Hashtable m_hashTableSorts = new Hashtable();
  
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that takes a <code>ComponentContext</code>
   *     
   * @param context The <code>ComponentContext</code>
   */
  public CrosstabSortPanelModelImpl(ComponentContext context) {
    setComponentContext(context);
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the <code>ComponentContext</code> to use.
   * 
   * @param componentContext The <code>ComponentContext</code>
   */
  public void setComponentContext (ComponentContext componentContext) {
    m_componentContext = componentContext;
    BIProvider provider = getComponentContext().getBIProvider();
    m_dataDirector = provider.getDataDirector();
    retrieveSorts();
    m_metadataProvider = provider.makeMetadataProvider();
  }

  /**
   * Retrieves the <code>ComponentContext</code> used.
   * 
   * @return The <code>ComponentContext</code>
   */
  public ComponentContext getComponentContext() {
    return m_componentContext;
  }

  // javadoc inherited from interface
  public String getMode() {
    return CROSSTAB_MODE;
  }
  
  // javadoc inherited from interface
  public Vector getSortItems() {
    Vector v = m_metadataProvider.getItemObjects(false, true);
    Vector items = new Vector();
    
    for (int i = 0; i < v.size(); i++) {
      MDObject object = (MDObject)v.get(i);
      ComponentNode context = new ComponentNode(object.toString(getComponentContext().getDisplayLabelType()));
      context.setValue(object.getUniqueID());
      items.add(context);
    }

    return items;
  }
  
  // javadoc inherited from interface
  public String getSortItem() {
    return m_strSortItem;
  }
  
  // javadoc inherited from interface
  public void setSortItem (String strItem) {
    m_strSortItem = strItem;
  }
    
  // javadoc inherited from interface
  public Vector getSortCriteria() {
    Vector v = m_metadataProvider.getItemObjects(true, false);
    Vector items = new Vector();

    for (int i = 0; i < v.size(); i++) {
      MDObject object = (MDObject)v.get(i);
      ComponentNode context = new ComponentNode(object.toString(getComponentContext().getDisplayLabelType()));
      context.setValue(object.getUniqueID());
      items.add(context);
    }

    return items;    
  }

  // javadoc inherited from interface
  public boolean isDimension() {
    if (getSortItem() != null) {
      
      try {
        MDObject object = getComponentContext().getBIProvider().getMetadataManager().getMDObjectByUniqueID(getSortItem());
        return object instanceof MDDimension;
      }
      
      catch (MetadataManagerException mme) {
        getComponentContext().getErrorHandler().error(mme, getClass().getName(), "isDimension");
      }
    }

    return false;
  }
  
  // javadoc inherited from interface
  public String getHierarchy() {
    if (getSortItem() != null) {
      return getComponentContext().getMetadataProvider().getHierarchy(getSortItem());
    }

    return null;
  }

  public Object getSorts() {
    if (getSortItem() != null) {
      return m_hashTableSorts.get(getSortItem());
    }

    return null;
  }
  
  public void setSorts(Object sorts) {
    if (getSortItem() != null) {
      if (sorts == null) {
        m_hashTableSorts.remove(getSortItem());
      }
      else {
        m_hashTableSorts.put(getSortItem(), sorts);
      }
    }
  }

  public void applySorts() {
  }

  public Vector getDirections(Object criteria) {
    Vector directions = new Vector();
    ComponentNode cn1 = new ComponentNode(getResourceString (SortBundle.SORTPANEL_MODEL_CROSSTAB_ASCENDING));
    cn1.setValue(new Integer(QDRSortInfo.ASCENDING));
    directions.add(cn1);
    
    ComponentNode cn2 = new ComponentNode(getResourceString (SortBundle.SORTPANEL_MODEL_CROSSTAB_DESCENDING));
    cn2.setValue(new Integer(QDRSortInfo.DESCENDING));
    directions.add(cn2);

    return directions;
  }  

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  String getResourceString (String strKey) {
    if (getComponentContext() != null && getComponentContext().getResourceHandler() != null) {
      return getComponentContext().getResourceHandler().getResourceString(RESOURCE_BUNDLE, strKey);
    }

    return strKey;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////
  
  private void retrieveSorts() {
    try {
      DimensionSortInfo[] dimSorts = m_dataDirector.getDimensionSorts();
      if (dimSorts != null) {
        for (int i = 0; i < dimSorts.length; i++) {
          m_hashTableSorts.put(dimSorts[i].getDimension(), dimSorts[i]);
        }
      }

      SortInfo[] sorts = m_dataDirector.getSorts();
      if (sorts != null) {
        for (int i = 0; i < dimSorts.length; i++) {
          if (sorts[i] instanceof QDRSortInfo) {
            m_hashTableSorts.put(sorts[i].getLayerName(), sorts[i]);
          }
          else {
            m_hashTableSorts.put(sorts[i].getLayerName(), new ItemSortWrapper(sorts[i]));
          }
        }
      }
    }

    catch (Exception e) {
      getComponentContext().getErrorHandler().error (e, getClass().getName(), "retrieveSorts");
    }
  }
}
