/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Enumeration;
import javax.naming.NamingException;


/**
 * Methods that are required for a group of users.
 *
 * @status documented
 */
public interface Group extends User
{
    /**
     * @hidden
     * Adds a user to this group.
     *
     * @param user The user to add to this group.
     *
     * @return <code>true</code> if <code>user</code> is added successfully
     *                           to this group,
     *         <code>false</code> if <code>user</code> is already in this group.
     */
    boolean addMember(User user) throws NamingException;

    /**
     * @hidden
     * Removes a user from this group.
     *
     * @param user The user to remove from this group.
     * @return <code>true</code> if <code>user</code> is removed successfully
     *                           from this group,
     *         <code>false</code> if <code>user</code> was not in this group.
     */
    boolean removeMember(User user);
    
    /**
     * @hidden
     * Indicates whether a user is a member of this group.
     *
     * @param user The user whose membership is in question.
     * @return <code>true</code> if <code>user</code> is a member of this group,
     *         <code>false</code> if not.
     */
    boolean isMember(User user);

    /**
     * @hidden
     * Retrieves a list of the members in this group.
     *
     * @return A list of the memebers in this group.
     */
    Enumeration members();
}