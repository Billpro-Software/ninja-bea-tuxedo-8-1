/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners that the query's dimensionality has changed.
 *
 * @status Documented
*/
public class DimensionalityChangedEvent extends QueryEvent
{
    /**
     * Constructs the event.
     * 
     * @param source The source of the event, that is, a reference to the
     *               object that fired the event.
     *
     * @status Documented
     */
    public DimensionalityChangedEvent(Object source) {
        super(source);
    }    
}
