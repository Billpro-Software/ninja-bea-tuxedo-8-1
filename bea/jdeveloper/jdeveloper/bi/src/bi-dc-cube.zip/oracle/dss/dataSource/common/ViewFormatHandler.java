/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ViewFormatHandler.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     06/27/05 - Phase 2 file additions to bicommon 
    bmoroze     06/17/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ViewFormatHandler.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

/**
 * @hidden
 * Interface to handle view format management for data cursor
 */
public interface ViewFormatHandler
{    
  public Object getViewFormatHandle (String strCacheKey,
    String strNumberFormatString, String strNumberFormatType, long nPage, long nRow, long nCol, Object objResult); 
}