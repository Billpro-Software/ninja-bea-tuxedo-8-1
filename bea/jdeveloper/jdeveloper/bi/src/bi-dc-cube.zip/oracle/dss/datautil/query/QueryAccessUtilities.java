package oracle.dss.datautil.query;

/*
 * QueryAccessUtilities.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

import java.util.Vector;
import java.util.Hashtable;

import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.QueryAccess;
import oracle.dss.util.dimensionList.DimListDataModel;
import oracle.dss.util.LayoutAccess;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.WaitDataAvailableEvent;
import oracle.dss.util.DataChangedEvent;
import oracle.dss.util.DataAvailableEvent;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;

import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.PollingRequiredEvent;
import oracle.dss.util.SliceOutOfRangeException;

/**
 *  @hidden
 *  <pre>
 *  QueryAccessUtilities
 *  Extra Query and Calc builder utilities built around QueryAccess
 *  </pre>
 */

public class QueryAccessUtilities 
    {
    /////////////////////
    //
    // Constants
    //
    /////////////////////

    /////////////////////
    //
    // Member Variables
    //
    /////////////////////
    
    // DataAccess representing the current overall query in the DataSource for layout
    private transient DataAccess m_layoutDA = null;
    private transient DataDirector m_layoutDD = null;
    private transient boolean m_relational = false;
    
    // Cache of DimensionMember values by dim, heir, type
    private transient Hashtable m_valueCache = new Hashtable();

    // reference to a query access    
    private QueryAccess m_qa = null;
    
    // reference to a layout access
    private LayoutAccess m_la = null;
       
    // Reference to an object with an error handler
    private ErrorHandler m_eh = null;
    
    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public QueryAccessUtilities(QueryAccess qa, LayoutAccess la, ErrorHandler eh)
        {
        super();
        
        m_qa = qa;
        m_eh = eh;
        m_la = la;
        }

    /////////////////////
    //
    // Methods
    //
    /////////////////////

    public QueryAccess getQueryAccess() {
        return m_qa;
    }

    public void setRelationalLayoutAccess(LayoutAccess la)
    {
        m_la = la;
        m_relational = true;
    }
    
    /**
     *  Performs a collapse of all levels up to the highest level (0). All
     *  children are hidden up to the root.
     *
     *  @param dimension    dimension to collapse
     *  @return boolean     A <code>true</code> if successful, otherwise failure.
     *
     *  @status New
     */
    public boolean collapseAllList (DimListDataModel dataModel, String dimension, String hierarchy, boolean available, MetadataManager mm)
        {
        // Find the selection associated with the specified dimension
        // blm - Selection code moved to dvt-olap
/*        Selection sel = null;
        if (available) {
            sel = getAutoSelection(dimension, hierarchy, mm);
        }
        else {
            sel = getQueryAccess().getSelection(dimension);
        }
        // If we don't have a hierarchy, simply return
        Vector newLevels = new Vector();
        if (hierarchy != null)
            {
            // Determine if any levels are present
            Step step = sel.getStep(0);
            Vector vLevels = ((ConditionStep)step).getLevels();

            try
            {
                MDHierarchy hier = (MDHierarchy)mm.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
                if (hier != null)
                {
                    String targetLevel = null;
                    if (vLevels != null && vLevels.size() > 0)
                    {
                        targetLevel = (String)vLevels.elementAt(0);
                    }
                    else
                    {
                        MDLevel[] levels = hier.getLevels();
                        if (levels != null && levels.length > 0)
                        {
                            targetLevel = levels[0].getUniqueID();
                        }
                    }
                    if (targetLevel == null)
                    {
                        // No levels at all, but a hierarchy
                        String dimName = dimension;
                        sel = new Selection(dimName);
                        sel.setHierarchy(hierarchy);
                        FamilyStep fs = new FamilyStep(dimName, hierarchy, FamilyStep.OP_FIRSTANCESTORS, null, false);
                        sel.addStep(fs);
                        getQueryAccess().setSelection(sel);
                        return true;
                    }
                    else
                    {
                        newLevels.addElement(targetLevel);
                    }
                }
            }
            catch (MetadataManagerException e)
            {
                m_eh.error(e, getClass().getName(), "collapseAllList");
            }

            // Generate our ALL selection cursor
            String dimName = dimension;
            sel = getAllSelection (dimName, hierarchy, newLevels);
    
            // Check to see if levels is not specified or set to ALL
                // Update our dimension's selection
                getQueryAccess().setSelection (sel);

                return true;
//            }
            }
        else*/
            return false;
        }
        
    /**
     * @hidden
     */
    public void clearLayoutAccess()
    {
        if (m_la != null)
            m_la.release();
            
        m_la = null;
    }
    
    /**
     *  @hidden
     */
    public DimensionMember getCachedValue(String dimension, String hierarchy, String member, String strType)
    {
        return (DimensionMember)m_valueCache.get(dimension + ";" + hierarchy + ";" + member + ";" + strType);
    }
    
    /**
     *  @hidden
     */
    public void putCachedValue(String dimension, String hierarchy, String member, String strType, DimensionMember value)
    {
        if (value != null)
            m_valueCache.put(dimension + ";" + hierarchy + ";" + member + ";" + strType, value);
    }
    
    /**
     *  Performs a expand on all levels down to the lowest level. All
     *  children are expanded.
     *
     *  @param dimension    dimension to expand
     *  @return boolean     A <code>true</code> if successful, otherwise failure.
     *
     *  @status New
     */
    public boolean expandAllList(DimListDataModel dataModel, String dimension, String hierarchy, boolean available, MetadataManager mm)
        {
        // Find the selection associated with the specified dimension
        // blm - Selection code moved to dvt-olap
/*        Selection sel = null;
        if (available) {
            sel = getAutoSelection(dimension, hierarchy, mm);
        }
        else {
            sel = getQueryAccess().getSelection(dimension);
        }
        // If we don't have a hierarchy specified, don't bother drilling
        if (hierarchy != null)
            {
            // Determine if any levels are present
            Step step = sel.getStep(0);
            Vector vLevels = ((ConditionStep)step).getLevels();

            Vector newLevels = new Vector();
            try
            {
                MDHierarchy hier = (MDHierarchy)mm.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
                if (hier != null && (vLevels != null && vLevels.size() > 0))
                {
                    MDLevel[] levels = hier.getLevels();
                    String targetLevel = (String)vLevels.elementAt(0);
                    if (levels != null)
                    {
                        for (int l = 0; l < levels.length; l++)
                        {
                            if (levels[l].getUniqueID().equals(targetLevel))
                            {
                                // Case where target is the top level: just use all with no levels
                                if (l == 0)
                                {
                                    newLevels = null;
                                    break;
                                }
                                for (int i = l; i < levels.length; i++)
                                {
                                    newLevels.addElement(levels[i].getUniqueID());
                                }
                                break;
                            }
                        }
                    }
                }
            }
            catch (MetadataManagerException e)
            {
                m_eh.error(e, getClass().getName(), "expandAllList");
            }

            // Generate our ALL selection cursor
            String dimName = dimension;
            sel = getAllSelection (dimName, hierarchy, newLevels);

            // Update our dimension's selection
            getQueryAccess().setSelection (sel);

            // Check to see if levels is not specified or set to ALL,
            // otherwise, simply restore the original ALL hierarchy
            return true;
            }
        else*/
            return false;
        }

  /**
     * Mimics the old automatic all creation for the available list
     */
   // blm - Selection code moved to dvt-olap
/*    public Selection getAutoSelection(String dimension, String hierarchy, MetadataManager mm)
        {
        // Build an ALL selection for the dimension using
        // the selected data source's facilities

        // Check for an already-available selection
        if (getQueryAccess().isSelectionSet(dimension))
            {
            return getQueryAccess().getSelection(dimension);
            }

        if (dimension == null)
            {
            return null;
            }


        Vector vLevels = null;
        Selection sel = null;
        if (hierarchy != null)
        {
            try
            {
                MDHierarchy hier = (MDHierarchy)mm.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
                if (hier != null)
                {
                    MDLevel[] levels = hier.getLevels();
                    if (levels != null && levels.length > 0)
                    {
                        String targetLevel = levels[0].getUniqueID();
                        vLevels = new Vector();
                        vLevels.addElement(targetLevel);
                        sel = getAllSelection (dimension, hierarchy, vLevels);
                    }
                    else
                    {
                        FamilyStep fs = new FamilyStep(dimension, hierarchy, FamilyStep.OP_FIRSTANCESTORS, null, false);
                        sel = new Selection(dimension);
                        sel.setHierarchy(hierarchy);
                        sel.addStep(fs);
                    }
                }
            }
            catch (MetadataManagerException e)
            {
                m_eh.error(e, getClass().getName(), "getAutoSelection");
            }
        }


        if (sel == null)
        {
            boolean isMeasure = false;
            try
            {
                MDDimension measDim = mm.getMeasureDimension(null);
                if (measDim != null)
                {
                    isMeasure = measDim.getUniqueID().equals(dimension);
                }
            }
            catch (MetadataManagerException e)
            {
            }
            if (isMeasure)
            {
                sel = getAllSelection(dimension, null, null);
            }
            else
            {
                sel = getFirstLastSelection(dimension);
            }
        }

        getQueryAccess().setSelection(sel);
        return sel;
        }

    private Selection getFirstLastSelection(String dimension)
    {
        Selection sel = new Selection(dimension);
        FirstLastStep fs = new FirstLastStep(dimension);
        try
        {
            fs.setFirstLastType(FirstLastStep.FIRST);
            fs.setNumValues(new Integer(1));
        }
        catch (InvalidStepArgException i)
        {
        }
        sel.addStep(fs);
        return sel;
    }
*/

    
    // Maintains hidden dimensions in both the query access and the layout
    // version of the data source
    public void maintainHiddenDimensions(String[] dimensions, boolean hide) {
        if (dimensions == null) {
            return;
        }
        
        getLayoutDA();
        if (m_layoutDD != null && m_layoutDA != null) {
            // Hide/unhide dimensions in the layout access' data source
            
            // Check each specified dimension for its current hidden state: if it's different, 
            // pivot it on the temporary layout data source and mark the difference
            //Selection sel = null;
            String dimName = null;
            
            int hiddenEdge = DataDirector.max_edge+1;
            for (int dim = 0; dim < dimensions.length; dim++)
            {
            	
                dimName = dimensions[dim];
                int currentEdge = getDimEdge(dimName);
                int currentLayer = getDimLayer(dimName, currentEdge);
                try
                {
                    int maxLayer = 0;
                    if (hiddenEdge < getLayoutDA().getEdgeCount()) {
                        maxLayer = getLayoutDA().getLayerCount(hiddenEdge)-1;
                    }
                    if (hide && hiddenEdge != currentEdge)
                    {        	
                        // Hide it on the extra edge if not already there
                        m_layoutDD.pivot(currentEdge, hiddenEdge, currentLayer, maxLayer, DataDirector.PIVOT_MOVE_AFTER);
                    }
                    else if (!hide && currentEdge == hiddenEdge)
                    {
                      //bug 3545372 : LayerOutOfRangeException when adding back a hidden dimension
                      //if layer count for page edge is 0. If layer count for page edge is 0, set the
                      //destination layer to 0.
                      // Put it back on the page edge to make it visible
                      m_layoutDD.pivot(currentEdge, DataDirector.PAGE_EDGE, currentLayer,
                      (getLayoutDA().getLayerCount(DataDirector.PAGE_EDGE) - 1) < 0 ? 0 :
                      (getLayoutDA().getLayerCount(DataDirector.PAGE_EDGE) - 1), DataDirector.PIVOT_MOVE_AFTER);
                    }
                }
                catch (Exception e)
                {
                    m_eh.error(e, getClass().getName(), "maintainHiddenDimensions");
                }
            }
        }
    }
                 
    /**
     *  Generate a selection represented by an All Step.
     *
     *  @param dimension    String uniquely identifying the current Dimension
     *  @param hierarchy    String uniquely identifying the Hierarchy of this Step
     *  @param levels       Vector of Strings uniquely identifying the levels
     *  @return <code> Selection </code> represented by an ALL Step
     *
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getAllSelection (String dimension, String hierarchy,
                                        Vector levels) 
        {
        // Must build an all selection and store it, along with a data access
        AllStep all = new AllStep (dimension, hierarchy, levels);

        Selection sel = new Selection (dimension);
        sel.setHierarchy (hierarchy);
        sel.addStep(all);
        
        return sel;
        }    
*/
  public Object[] getMetadataValue(String dimension, int index, String[] type)
  {
            try {
            DataAccess da = m_qa.getDataAccess(dimension);
            if (da == null)
            {
                return null;
            }
            // These are all one off column cursors
            int[] depth = new int[0];
            if (index < da.getMemberSiblingCount(0,depth, 0))
                {
                Object[] retVal = new Object[type.length];
                for (int t = 0; t < retVal.length; t++)
                {
                    retVal[t] = da.getMemberMetadata(0, depth, 0, index, type[t]);
                }
                return retVal;
                }
        }
        catch (Exception e)
            {
            m_eh.error(e, getClass().getName(), "getMetadataValue");
            }

        return null;
  }

    // Return a given metadata value from the available cursor
    public Object getMetadataValue(String dimension, int index, String type)
        {
            Object[] retVal = getMetadataValue(dimension, index, new String[] {type});
            if (retVal == null || retVal.length == 0)
                return null;
            return retVal[0];
        }
       

            
 /**
  * Returns the properly initialized QDR for the given Measure ID list
  *
  * @return QDR object initialized with the right values for the given 
  *         measure ID list
  */
  /* gek 02/15/00 Not currently used 
  public QDR[] getQDR (Vector measureList) 
	    {
        Vector dimList = 
            getDimensionList((String[])Utility.copyVectorToArray(measureList));
        return _getQDR (dimList, null);
	    }
  */    
  
	

    /**
     * Return the edge(s) on which a given dimension
     * appears in the current layout DataSource
     *
     * @param dimension dimension of interest
     * @return edges on which the dimension is found.  <code>null</code>
     *         if not found
     * @status New
     */
    public int getDimEdge(String dimension) {
        return getEdge(getLayoutDA(), dimension);
    }
    
    /**
     * Return the layer at which a given dimension is found on a given edge
     *
     * @param dimension dimension of interest
     * @param edge edge of interest
     * @return layer at which dimension is found.  -1 if not found
     * @status New
     */    
    public int getDimLayer(String dimension, int edge) {
        return getDepth(getLayoutDA(), dimension, edge);
    }
   
    // Return the 1-based index of the given dimension value in the given dimension
    // if found.  -1 if not found
    public int getDimMemberPosition(String dimension, String value) {
        try {
            // Return the find value on the data access
            DataAccess da = m_qa.getDataAccess(dimension);
            
            if (da != null)
            {
                int pos = da.findMember(0, new int[0], 0, value, MetadataMap.METADATA_VALUE, 0);
                if (pos > -1) {
                    Object memberMetadata = da.getMemberMetadata(0, new int[0], 0, pos, oracle.dss.util.MetadataMap.METADATA_POSITION);
                    if (memberMetadata != null)
                    {
                        return ((Integer)memberMetadata).intValue();
                    }
                }
            }
        }
        catch (Exception e) {
            m_eh.error(e, getClass().getName(), "getDimMemberPosition");                            
        }
        return -1;
    }
 
    private DataAccess getLayoutDA() {
        if (m_layoutDA == null) {
            listenToLayoutDataSource();
        }
        return m_layoutDA;
    }
    
    // Adds listeners to the layout DataSource
    private void listenToLayoutDataSource()
    {
        if (m_la != null && m_la.getDataSource() != null)
        {
            if (m_layoutDD != null)
                return;
                
            if (m_relational)
            {
                m_layoutDD = m_la.getDataSource().createRelationalDataDirector();
            }
            else
            {
                m_layoutDD = m_la.getDataSource().createCubeDataDirector();
            }
                
            if (m_layoutDD != null) 
            {    
                m_layoutDD.addDataDirectorListener(new DataDirectorListener() 
                {
                    public void viewDataChanged(DataChangedEvent e) 
                    {
                        m_layoutDA = e.getDataAccess();
                    }    
                    public void viewDataAvailable(DataAvailableEvent e) 
                    {
                        m_layoutDA = e.getDataAccess();
                    }    
                    public void waitDataAvailable(WaitDataAvailableEvent e) {}
                    public void pollingRequired(PollingRequiredEvent e) {}
                });
            }
        }
    }

    // Get a list of available values for a given dimension with all types included
    public Vector getValues(String dimension, String hier, int maximum, MetadataManager mm, String strLabelType)
        {
        return m_qa.getValues(null, maximum, dimension, hier, strLabelType);
        }


    // Get a list of available values for a given dimension with all types included
    public Vector getValues(String dimension, String hier, int maximum, MetadataManager mm)
        {
        return _getValues(null, maximum, dimension, hier, mm);
        }

    // Get a list of available values for a given dimension
    public Vector getValues(String dimension, String hier, String type, int maximum, MetadataManager mm, String strLabelType) 
        {
        return m_qa.getValues(type, maximum, dimension, hier, strLabelType);
        }

    // Get a list of available values for a given dimension
    public Vector getValues(String dimension, String hier, String type, int maximum, MetadataManager mm)
        {
        return _getValues(type, maximum, dimension, hier, mm);
        }

/*    private Vector _getValues(String type, int max, String dimension, MetadataManager mm, String strLabelType)
        {
        Vector values=null;
        
        Selection sel = m_qa.getSelection(dimension);
        DataAccess da = null;
        boolean shouldClose = false;
        if (sel != null && sel.isAsymmetric())
        {
            // Can't evaluate this for values: do a one-off using firstlast
            Selection tempSel = new Selection(sel.getDimension());
            tempSel.setHierarchy(sel.getHierarchy());
            FirstLastStep fls = new FirstLastStep(tempSel.getDimension());
            fls.setHierarchy(tempSel.getHierarchy());
            fls.setNumValues(new Integer(1));
            try
            {
                fls.setFirstLastType(FirstLastStep.FIRST);
            }
            catch (InvalidStepArgException e)
            {
            }
            tempSel.addStep(fls);
            da = m_qa.getDataAccess(tempSel);
            shouldClose = true;
        }
        else
        {
             da = m_qa.getDataAccess(dimension);
        }
        String hierarchy = null;
        if (sel != null)
        {
            hierarchy = sel.getHierarchy();
        }
        //int[] edgear = m_qa.getDimEdges(dimension);
        //int edge = edgear[0];
        //int depth = m_qa.getDimLayer(dimension, edge);
        //int[] ar = new int[depth];
        
        //for (int i=0; i<depth; i++)
            //ar[i] = 1;
//        
        try
            {        
  //          int dimCount = da.getMemberSiblingCount(edge, ar, depth);
            int dimCount = da.getEdgeExtent(0);
            values = new Vector();
            int intMax = (max == -1) ? dimCount : Math.min(dimCount, max);

            if (type == null)
                {
                // Want DimValue objects
                // String dim = (String)da.getDimensionMetadata(edge, 
                //          depth, DimensionMetadataMap.DIM_METADATA_LONGLABEL);
                for (int l=0; l<intMax; l++)
                    {
                    Object valueDesc, value;
                    String labels;
                    String[] levelID = getLevelOfMember(da, hierarchy, l, mm);
                    value = new DimensionMember(
                        DataUtils._makeString(da.getMemberMetadata(0, 0, l,
                            MetadataMap.METADATA_VALUE)),
                        DataUtils._makeString(da.getMemberMetadata(0, 0, l,
                            strLabelType)),
                         hierarchy, levelID[0], levelID[1]);
                    
                    values.addElement(value);
                    }
                }
            else 
                {
                for (int l=0; l<intMax; l++)
                    {
                    Object valueDesc, value;
                    String labels;
                    value = da.getMemberMetadata(0, 0, l, type);
                    
                    values.addElement(value);
                    }
                }
            } 

        catch (Exception ex) 
            {
            m_eh.error(ex, getClass().getName(), "_getValues");                            
            }

        if (shouldClose)
        {
            da.release();
        }
        return values;   
        }
        */
    private Vector _getValues(String type, int max, String dimension, String hier, MetadataManager mm)
    {
        return m_qa.getValues(type, max, dimension, hier, MetadataMap.METADATA_LONGLABEL);
    }

    public String[] getLevelOfMember(DataAccess da, String hierarchy, int index, MetadataManager mm) throws SliceOutOfRangeException, LayerOutOfRangeException, MetadataManagerException, EdgeOutOfRangeException
    {
        // Find the level, if possible
        Integer ld = (Integer)da.getMemberMetadata(0, 0, index, MetadataMap.METADATA_INDENT);
        String[] levelID = new String[2];
        if (ld != null && mm != null && hierarchy != null)
        {
            int levelDepth = ld.intValue();
            MDHierarchy hierObj = (MDHierarchy)mm.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
            if (hierObj != null)
            {
                MDLevel[] levels = hierObj.getLevels();
                if (levels != null && levels.length > 0 && levelDepth < levels.length)
                {
                    levelID[0] = levels[levelDepth].getUniqueID();
                    levelID[1] = levels[levelDepth].getName();
                }
            }
        }
        return levelID;
    }

    protected int getEdge(DataAccess da, String dim)
        {
        DimInfo di = findEdgeandLayer(da, dim);
        
        if (di != null)
        {
            return di.getEdge();
        }
        return -1;
    }
    
    protected int getDepth(DataAccess da, String dim, int edge) {
        DimInfo di = findEdgeandLayer(da, dim);
     
        if (di != null)
        {
            return di.getDepth();
        }
        return -1;
    }

    // Find this dim's information and cache it
    private DimInfo findEdgeandLayer(DataAccess da, String dim)
        {
        int edge, depth;
        try
            {
            int edgeCount = da.getEdgeCount();
            for (edge = 0; edge < edgeCount; edge++)
                {
                int layerCount = da.getLayerCount(edge);
                for (depth = 0; depth < layerCount; depth++)
                    {
                    if (dim.equals(da.getLayerMetadata(edge, depth,
                        LayerMetadataMap.LAYER_METADATA_NAME)))
                        {
                            DimInfo di = new DimInfo(edge, depth);
                            return di;
                        }
                    }
                }
            }

        catch (Exception e)
            {
            // Something is very wrong
            }

        return null;
        }

    /**
     *  Information about each particular dimension for a given set of data and layout
     *  that we might not want to refind or recalculate.
     *  @status New
     */
    protected class DimInfo extends Object
        {
        public DimInfo(int e, int d)
            {
            super();

            setEdge(e);
            setDepth(d);
            }

        public void setEdge(int e)
            {
            edge = e;
            }

        public int getEdge()
            {
            return edge;
            }        
        
        public void setDepth(int d) 
            {
            depth = d;
            }
        
        public int getDepth() 
            {
            return depth;
            }

        protected int edge  = -1;
        protected int depth = -1;
        }                
}