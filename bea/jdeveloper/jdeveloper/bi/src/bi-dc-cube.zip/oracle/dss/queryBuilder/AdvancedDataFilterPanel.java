/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/queryBuilder/AdvancedDataFilterPanel.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:16 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.queryBuilder;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import oracle.bali.dbUI.DBUIStringConstants;
import oracle.bali.dbUI.constraint.DataConstraint;
import oracle.bali.dbUI.constraintBuilder.AndOrComponent;
import oracle.bali.dbUI.constraintBuilder.ConstraintBuilder;
import oracle.bali.dbUI.constraintBuilder.ConstraintBuilderComp;
import oracle.bali.dbUI.constraintBuilder.DragComponent;
import oracle.bali.dbUI.constraintBuilder.GroupComponent;
import oracle.bali.dbUI.constraintBuilder.ParentComponent;
import oracle.bali.dbUI.constraintComponent.BaseLayoutManager;
import oracle.bali.dbUI.constraintComponent.ComparisonConstraintComp;
import oracle.bali.dbUI.constraintComponent.ConstraintCompFactory;
import oracle.bali.dbUI.constraintComponent.ConstraintComponent;
import oracle.bali.dbUI.constraintComponent.MultiDescriptorComponent;
import oracle.bali.dbUI.db.DataDescriptor;
import oracle.bali.dbUI.db.DataDescriptorProvider;
import oracle.bali.ewt.LWComponent;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.datautil.gui.OperatorDisplay;
import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.queryBuilder.resource.QueryBuilderBundle;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.util.gui.component.comboBox.TreeListComboBoxModel;

import oracle.ide.controls.MenuToolButton;
import oracle.ide.controls.ToggleAction;

import oracle.javatools.icons.OracleIcons;
import oracle.javatools.ui.ComponentWithTitlebar;
import oracle.javatools.ui.ControlBar;


/**
 * <pre>
 * <code>AdvancedDataFilterPanel</code>.
 * </pre>
 *
 * @author rbalexan
 * @since  11.0.0.0.0
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   05/27/08 - 
 *    gkellam   03/22/08 - Fix Bug 6656590 - List of operators should be
 *                         filtered based on data type.
 *    gkellam   03/22/08 - Fix Bug 6656590 - List of operators should be
 *                         filtered based on data type.
 *    gkellam   03/21/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   12/03/07 - Fix Bug 6656326 - QueryBuilder: Scenario where can't
 *                         change from Compound back to Simple.
 *    gkellam   11/14/07 - Disable browse button for TopBottomDataFilter.
 *    gkellam   11/13/07 - Fix incorrect RangeDataFilter generation when moving
 *                         from Compound to Simple.
 *    gkellam   10/19/07 - Fix Bug 6505492 - Beta3: QueryBuilder: Can get
 *                         'Select Values' to init incorrectly.
 *    gkellam   10/17/07 - Fix Bug 6502514 - Beta3: QB: Compound 'Create Data
 *                         Filter' can't drop down 'Add' from keyboard.
 *    gkellam   10/03/07 - RangeDataFilter tweaks.
 *    gkellam   10/01/07 - Tweak operator handling.
 *    gkellam   09/12/07 - Fix keyboard navigation issues.
 *    gkellam   09/07/07 - Update the DataFilter prior to invoking Select
 *                         Values dialog.
 *    gkellam   08/23/07 - Bug 6311941 cleanup.
 *    gkellam   08/19/07 - Modify some DataFilter icons.
 *    gkellam   08/18/07 - Fix Bug 6322323 - QueryBuilder: Wrong data filter
 *                         defaulted in compound data filter dialog.
 *    gkellam   08/17/07 - Clear out members field when item changes.
 *    gkellam   08/16/07 - Fix DataFilter bugs.
 *    gkellam   08/02/07 - Improve data error handling.
 *    gkellam   07/29/07 - More RangeDataFilter updates.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    gkellam   07/26/07 - Fix Bug 6051430 - DataFilter GUI: Missing support
 *                         for between and not between RangeDataFilter.
 *    gkellam   07/18/07 - Remove TreeListCombo from compound datafilter.
 *    gkellam   07/18/07 - Modify and/or button processing.
 *    gkellam   07/17/07 - More DataFilter updates.
 *    gkellam   07/13/07 - Continue working in DataFilter plumbing....
 *    gkellam   07/12/07 - Update JList members model processing.
 *    gkellam   07/10/07 - Implement new BI Model UI for DataFilters.
 *    gkellam   07/05/07 - Continue updating DataFilter GUI.
 *    gkellam   06/12/07 - Fix Bug 5990797 - QueryBuilder: Edit/Add data filter
 *                         dialogs have no mnemonics.
 *    gkellam   06/11/07 - Fix Bug 6072838 - QueryBuilder: Cannot create
 *                         advanced data filter of 'NOT AND' and 'NOT OR'.
 *    gkellam   05/29/07 - Fix Bug 6051440 - DataFilter GUI: Missing support
 *                         for NULL and NOT NULL Datafilters.
 *    gkellam   05/14/07 - Fix Bug 6047578 - QueryBuilder: Erroneous error msg
 *                         in advanced (compound) data filter dlg.
 *    gkellam   05/13/07 - Modify DialogFilterDialog handling.
 *    gkellam   05/13/07 - Add TopBottomDataFilter error checking.
 *    gkellam   05/09/07 - Use same base getMembers method for Advanced and
 *                         Simple DataFilters.
 *    gkellam   05/08/07 - Fix Bug 6037092 - QueryBuilder: Add data filter
 *                         dialog should display warning message.
 *    gkellam   05/03/07 - Fix Bug 6025602 - QueryBuilder: Advanced Data Filter
 *                         dialog initializing with wrong member data.
 *    gkellam   05/03/07 - Fix Bug 6025584 - QueryBuilder: 'More Items...' gets
 *                         selected instead of dialog coming up.
 *    gkellam   04/23/07 - Modify how DataFilterConstraintComponent members are
 *                         initialized.
 *    gkellam   04/23/07 - Fix incorrect DataFilter generation from Advanced
 *                         DataFilter GUI.
 *    gkellam   04/23/07 - APPS3:QB: Compound AND in Edit data filter defaults
 *                         incorrectly.
 *    gkellam   04/21/07 - Remove JTabbedPanes.
 *    gkellam   04/20/07 - Additional support for TreeListCombo options.
 *    gkellam   04/20/07 - Modify TreeListComboMembers handling.
 *    gkellam   04/04/07 - Modify how items are chosen to populate members.
 *    gkellam   03/19/07 - Simplify TreeListComboMembers handling.
 *    gkellam   03/14/07 - Fix Bug 5918743 - QueryBuilder: 'Edit DataFilter'
 *                         dialog, 3rd drop down not initialized.
 */
public class AdvancedDataFilterPanel extends BaseDataFilterPanel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * Action command taken from oracle.bali.dbUI.constraintBuilder.ConstraintBuilder
   * used for menu processing.
   * 
   */
  static final protected String CREATE_NOT_COMMAND = "CREATE_NOT";

  /**
   * Index not found.
   * 
   */
  static final public int NOT_FOUND = -1;

  /////////////////////
  //
  // Members
  //
  /////////////////////

  /**
   * Specifies the <code>MenuToolButton</code> for the DataFilter operations.
   * 
   */
  protected MenuToolButton m_menuToolButton = null;

  /**
   * Specifies the <code>ToggleAction</code> for the Add DataFilter operation.
   * 
   */
  protected ToggleAction m_toggleActionAdd = null;

  /**
   * Specifies the <code>ToggleAction</code> for the New DataFilter operation.
   * 
   */
  protected ToggleAction m_toggleActionNew = null;

  /**
   * Specifies the <code>ToggleAction</code> for the And DataFilter operation.
   * 
   */
  protected ToggleAction m_toggleActionAnd = null;

  /**
   * Specifies the <code>ToggleAction</code> for the Or DataFilter operation.
   * 
   */
  protected ToggleAction m_toggleActionOr = null;

  /**
   * <code>DataFilterConstraintBuilder</code>.
   *
   */
  private DataFilterConstraintBuilder m_dataFilterConstraintBuilder = null;

  /**
   * <code>DataFilter</code> value used to init createDescriptorSelector.
   *    
   */
  public static BaseDataFilter m_baseDataFilterInit = null;

  /**
   * <code>ControlBar</code>.
   * 
   * 
   */
  public static ControlBar m_controlBar = null;

  private ConstraintComponent m_constraintComponent = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  public AdvancedDataFilterPanel() {
    this (null);
  }

  public AdvancedDataFilterPanel (ComponentContext componentContext) {
    this (componentContext, null);
  }

  public AdvancedDataFilterPanel (ComponentContext componentContext, DataFilterPanelModel dataFilterPanelModel) {
    super (new BorderLayout());
    setContext (componentContext);
    setDataFilterPanelModel (dataFilterPanelModel);
    initGUI();
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Specifies the <code>MenuToolButton</code> for the DataFilter operations.
   * 
   * @param menuToolButton A <code>MenuToolButton</code>.
   * 
   * 
   */
  public void setMenuToolButton (MenuToolButton menuToolButton) {
    m_menuToolButton = menuToolButton;
  }

  /**
   * Retrieves the <code>MenuToolButton</code> for the DataFilter operations.
   *
   * @return <code>MenuToolButton</code>.
   * 
   * 
   */
  public MenuToolButton getMenuToolButton() {
    return m_menuToolButton;
  }

  /**
   * Specifies the <code>ToggleAction</code> for the Add DataFilter operation.
   * 
   * @param toggleActionAdd A <code>ToggleAction</code>.
   * 
   * 
   */
  public void setToggleActionAdd (ToggleAction toggleActionAdd) {
    m_toggleActionAdd = toggleActionAdd;
  }

  /**
   * Retrieves the <code>ToggleAction</code> for the Add DataFilter operation.
   *
   * @return <code>ToggleAction</code>.
   * 
   * 
   */
  public ToggleAction getToggleActionAdd() {
    return m_toggleActionAdd;
  }

  /**
   * Specifies the <code>ToggleAction</code> for the New DataFilter operation.
   * 
   * @param toggleActionNew A <code>ToggleAction</code>.
   * 
   * 
   */
  public void setToggleActionNew (ToggleAction toggleActionNew) {
    m_toggleActionNew = toggleActionNew;
  }

  /**
   * Retrieves the <code>ToggleAction</code> for the New DataFilter operation.
   *
   * @return <code>ToggleAction</code>.
   * 
   * 
   */
  public ToggleAction getToggleActionNew() {
    return m_toggleActionNew;
  }

  /**
   * Specifies the <code>ToggleAction</code> for the And DataFilter operation.
   * 
   * @param toggleActionAnd A <code>ToggleAction</code>.
   * 
   * 
   */
  public void setToggleActionAnd (ToggleAction toggleActionAnd) {
    m_toggleActionAnd = toggleActionAnd;
  }

  /**
   * Retrieves the <code>ToggleAction</code> for the And DataFilter operation.
   *
   * @return <code>ToggleAction</code>.
   * 
   * 
   */
  public ToggleAction getToggleActionAnd() {
    return m_toggleActionAnd;
  }

  /**
   * Specifies the <code>ToggleAction</code> for the Or DataFilter operation.
   * 
   * @param toggleActionOr A <code>ToggleAction</code>.
   * 
   * 
   */
  public void setToggleActionOr (ToggleAction toggleActionOr) {
    m_toggleActionOr = toggleActionOr;
  }

  /**
   * Retrieves the <code>ToggleAction</code> for the Or DataFilter operation.
   *
   * @return <code>ToggleAction</code>.
   * 
   * 
   */
  public ToggleAction getToggleActionOr() {
    return m_toggleActionOr;
  }

  /**
   * Make a <code>ControlBar</code> used to display DataFilter buttons.
   * 
   * @return <code>ControlBar</code> containing the <code>ControlBar</code>. 
   */
  public DataFilterControlBar makeControlBar() {
    ControlBar controlBar = new ControlBar();
    
    DataFilterControlBar dataFilterControlBar = 
      new DataFilterControlBar (controlBar);
    
    String strAddLabel = getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_ADD);

    ToggleAction toggleActionAdd = 
      new ToggleAction (strAddLabel, OracleIcons.getIcon (OracleIcons.ADD)){
      
      public void actionPerformed (ActionEvent actionEvent) {
      }
    };

    setToggleActionAdd (toggleActionAdd);

    ToggleAction toggleActionNew = 
      new ToggleAction (getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_NEW), null){
      
      public void actionPerformed (ActionEvent actionEvent) {
        if (getDataFilterConstraintBuilder() != null) {
          getDataFilterConstraintBuilder().addConstraintComponent (null, 
            makeConstraintComponent (null));
        }
      }
    };

    setToggleActionNew (toggleActionNew);
    
    ToggleAction toggleActionAnd = 
      new ToggleAction (getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_AND), null) {
      
      public void actionPerformed (ActionEvent actionEvent) {
        if (getDataFilterConstraintBuilder() != null) {
          getDataFilterConstraintBuilder().createAndOrOnSelection (true);
        }
      }
    };

    setToggleActionAnd (toggleActionAnd);

    ToggleAction toggleActionOr = 
      new ToggleAction (getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_OR), null) {
      
      public void actionPerformed (ActionEvent actionEvent) {
        if (getDataFilterConstraintBuilder() != null) {
          getDataFilterConstraintBuilder().createAndOrOnSelection (false);
        }
      }
    };

    setToggleActionOr (toggleActionOr);

    setMenuToolButton (new DataFilterMenuToolButton (toggleActionAdd));
    getMenuToolButton().getPopupMenu().add (toggleActionNew);
    getMenuToolButton().getPopupMenu().add (toggleActionAnd);
    getMenuToolButton().getPopupMenu().add (toggleActionOr);

    getMenuToolButton().setMnemonic (StringUtils.getMnemonicKeyCode (strAddLabel));
    getMenuToolButton().setToolTipText (StringUtils.stripMnemonic (strAddLabel));
    getMenuToolButton().setFocusable (true);    

    /**
     * Enable/Disable <code>ToggleAction</code> menu picks based on what is selected.
     */
    getMenuToolButton().addItemListener (new ItemListener() {
      public void itemStateChanged (ItemEvent itemEvent) {
        updateToggleActionState();  
      }
    });

    controlBar.add (getMenuToolButton());

    // Delete Button
    dataFilterControlBar.setButtonDelete (new DataFilterPanelButton());

    Utils.initializeIconButton (dataFilterControlBar.getButtonDelete(), 
      getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_DELETE), 
        OracleIcons.getIcon (OracleIcons.DELETE));

    controlBar.add (dataFilterControlBar.getButtonDelete());

    dataFilterControlBar.getButtonDelete().addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        if (getDataFilterConstraintBuilder() != null) {
          getDataFilterConstraintBuilder().deleteSelectedComponents();
        }
      }
    });

    return dataFilterControlBar;
  }

  /**
   * Create space around the <code>AdvancedDataFilterPanel</code>.
   * 
   * This directly affects how the DataFilter panel is resized within the
   * <code>oracle.ide.controls.JComboCardPanel</code>.
   * 
   * @return <code>Insets</code> representing the space around the 
   *         <code>AdvancedDataFilterPanel</code>. 
   */
  public Insets getInsets() { 
    return new Insets (10, 10, 10, 10); 
  } 

  public void setModel (DataFilterPanelModel dataFilterPanelModel) {
    m_dataFilterPanelModel = dataFilterPanelModel;

    if (dataFilterPanelModel != null) {
      setContext (dataFilterPanelModel.getContext());
    }
  }

  public DataFilterPanelModel getModel() {
    return m_dataFilterPanelModel;
  }

  public void setContext (ComponentContext context) {
    m_componentContext = context;
    refresh();
  }

  public ComponentContext getContext() {
    return m_componentContext;
  }

  public void refresh() {
    if ((getDataFilterConstraintBuilder() != null) && (getModel() != null)) {
      refresh (getModel().getDataFilter(), getDataFilterConstraintBuilder().getRoot());
    }
  }

  public Vector getMembers (DataFilterConstraintComponent dataFilterConstraintComponent, 
      DataFilter dataFilter) throws Exception {
    if (dataFilterConstraintComponent != null) {
      JComboBox jComboBoxItems = 
        dataFilterConstraintComponent.getItemComboBox();
      
      JTextField jTextFieldMembers = 
        dataFilterConstraintComponent.getMembersTextField();

      return getMembers (jTextFieldMembers, jComboBoxItems, getContext(), dataFilter);
    }

    return null;
  }

  public Vector getMembers (DataFilterDescriptorComponent dataFilterDescriptorComponent, 
      DataFilter dataFilter) throws Exception {
    if (dataFilterDescriptorComponent != null) {
      JComboBox jComboBoxItems = 
        dataFilterDescriptorComponent.getItemComboBox();
      
      JTextField jTextFieldMembers = 
        dataFilterDescriptorComponent.getMembersTextField();

      BaseDataFilter baseDataFilter = dataFilterDescriptorComponent.getDataFilter();
      if (baseDataFilter instanceof DataFilter) {
        dataFilter.setCmpValues (((DataFilter)baseDataFilter).getCmpValues());
      }
      
      return getMembers (jTextFieldMembers, jComboBoxItems, getContext(), dataFilter);
    }

    return null;
  }

  public Vector getMembers (DataFilterDescriptorComponent dataFilterDescriptorComponent, TopBottomDataFilter topBottomDataFilter) {
    if (dataFilterDescriptorComponent != null) {
      JComboBox jComboBoxItems = 
        dataFilterDescriptorComponent.getItemComboBox();
      
      JTextField jTextFieldMembers = 
        dataFilterDescriptorComponent.getMembersTextField();

      return getMembers (jTextFieldMembers, jComboBoxItems, getContext(), topBottomDataFilter);
    }

    return null;
  }

  public Vector getMembers (DataFilterDescriptorComponent dataFilterDescriptorComponent, RangeDataFilter rangeDataFilter) {
    if (dataFilterDescriptorComponent != null) {
      JComboBox jComboBoxItems = 
        dataFilterDescriptorComponent.getItemComboBox();
      
      JTextField jTextFieldMembers = 
        dataFilterDescriptorComponent.getMembersTextField();

      return getMembers (jTextFieldMembers, jComboBoxItems, getContext(), rangeDataFilter);
    }

    return null;
  }

 public Vector getMembers (DataFilterConstraintComponent dataFilterConstraintComponent, RangeDataFilter rangeDataFilter) {
    if (dataFilterConstraintComponent != null) {
      JComboBox jComboBoxItems = 
        dataFilterConstraintComponent.getItemComboBox();
      
      JTextField jTextFieldMembers = 
        dataFilterConstraintComponent.getMembersTextField();

      return getMembers (jTextFieldMembers, jComboBoxItems, getContext(), rangeDataFilter);
    }

    return null;
  }

  public void updateModel() throws Exception {
    if ((getDataFilterConstraintBuilder() != null) && (getModel() != null)) {
      ParentComponent parentComponent = getDataFilterConstraintBuilder().getRoot();
      
      if (parentComponent != null) {
        ConstraintBuilderComp[] constraintBuilderComp = parentComponent.getChildren();

        if ((constraintBuilderComp != null) && (constraintBuilderComp.length > 0)) {
          if (constraintBuilderComp[0] instanceof AndOrComponent) {
            
            CompoundDataFilter compoundDataFilter = 
              makeCompoundDataFilter (null, (AndOrComponent)constraintBuilderComp[0]);

            if (compoundDataFilter != null) {
              getModel().setDataFilter (compoundDataFilter);
            }
          }
          
          if (constraintBuilderComp[0] instanceof DragComponent) {
            getModel().setDataFilter (
              makeDataFilter (((DragComponent)constraintBuilderComp[0]).getConstraintComponent()));
          }
        }
      }
    }
  }

  /**
   * Retrieves DataFilter based on the state of this panel.
   * 
   * @return <code>DataFilter</code>.
   * 
   * 
   */
  public BaseDataFilter makeBaseDataFilter() throws Exception {
    updateModel();
    return getModel() != null ? getModel().getDataFilter() : null;
  }

  /**
   * @internal
   * 
   */
  public static void main (String[] strArrayArguments) {
    DataFilterPanelModel dataFilterPanelModel = 
      new DataFilterPanelModel (null);
    
    if (false) {
      DataFilter dataFilter = new DataFilter();
      dataFilter.setCmpOperator (DataFilter.OP_CONTAINS_ANY);
      dataFilterPanelModel.setDataFilter (dataFilter);
    }
    
    if (false) {
      CompoundDataFilter compoundDataFilter1 = new CompoundDataFilter();
      compoundDataFilter1.setOperator (CompoundDataFilter.OR);

      DataFilter dataFilter1 = new DataFilter();
      dataFilter1.setCmpOperator (DataFilter.OP_CONTAINS_ANY);
      compoundDataFilter1.addDataFilter (dataFilter1);

      DataFilter dataFilter2 = new DataFilter();
      dataFilter2.setCmpOperator (DataFilter.OP_DOES_NOT_CONTAIN);
      compoundDataFilter1.addDataFilter (dataFilter2);
      dataFilterPanelModel.setDataFilter (compoundDataFilter1);
    }

    if (false) {
      CompoundDataFilter compoundDataFilter1 = new CompoundDataFilter();
      compoundDataFilter1.setOperator (CompoundDataFilter.OR);

      CompoundDataFilter compoundDataFilter2 = new CompoundDataFilter();
      compoundDataFilter2.setOperator (CompoundDataFilter.AND);

      DataFilter dataFilter1 = new DataFilter();
      dataFilter1.setCmpOperator (DataFilter.OP_CONTAINS_ANY);
      compoundDataFilter2.addDataFilter (dataFilter1);

      DataFilter dataFilter2 = new DataFilter();
      dataFilter2.setCmpOperator (DataFilter.OP_DOES_NOT_CONTAIN);
      compoundDataFilter2.addDataFilter (dataFilter2);
      compoundDataFilter1.addDataFilter (compoundDataFilter2);

      DataFilter dataFilter3 = new DataFilter();
      dataFilter3.setCmpOperator (DataFilter.OP_LIKE);
      compoundDataFilter1.addDataFilter (dataFilter3);
      dataFilterPanelModel.setDataFilter (compoundDataFilter1);
    }

    if (false) {
      CompoundDataFilter compoundDataFilter1 = new CompoundDataFilter();
      compoundDataFilter1.setOperator (CompoundDataFilter.AND);

      DataFilter dataFilter1 = new DataFilter();
      dataFilter1.setCmpOperator (DataFilter.OP_CONTAINS_ANY);
      compoundDataFilter1.addDataFilter (dataFilter1);

      DataFilter dataFilter2 = new DataFilter();
      dataFilter2.setCmpOperator (DataFilter.OP_DOES_NOT_CONTAIN);
      compoundDataFilter1.addDataFilter (dataFilter2);

      CompoundDataFilter compoundDataFilter2 = new CompoundDataFilter();
      compoundDataFilter2.setOperator (CompoundDataFilter.AND);

      DataFilter dataFilter3 = new DataFilter();
      dataFilter3.setCmpOperator (DataFilter.OP_LIKE);
      compoundDataFilter2.addDataFilter (dataFilter3);

      DataFilter dataFilter4 = new DataFilter();
      dataFilter4.setCmpOperator (DataFilter.OP_NOT_LIKE);
      compoundDataFilter2.addDataFilter (dataFilter4);

      CompoundDataFilter compoundDataFilter3 = new CompoundDataFilter();
      compoundDataFilter3.setOperator (CompoundDataFilter.OR);
      compoundDataFilter3.addDataFilter (compoundDataFilter1);
      compoundDataFilter3.addDataFilter (compoundDataFilter2);
      dataFilterPanelModel.setDataFilter (compoundDataFilter3);
    }

    AdvancedDataFilterPanel adfp = new AdvancedDataFilterPanel();
    adfp.setModel (dataFilterPanelModel);

    QBUtils.makeFrame (adfp);
  }

  /**
   * @internal
   * 
   * Update the members.
   * 
   * 
   */
  public void updateMembers() {
    updateMembers (null);
  }

  /**
   * @internal
   * 
   * Updates a <code>JTextField</code> from a <code>BaseDataFilter</code>.
   * 
   * BaseDataFilter => JTextField
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code>
   * @param jTextFieldMembers A <code>JTextField</code>
   * 
   * 
   */
  public void updateMembers (BaseDataFilter baseDataFilter, JTextField jTextFieldMembers) {
    if (baseDataFilter == null) {
      baseDataFilter = getDataFilter();
    }

    if (jTextFieldMembers != null) {
    
      // Refresh the Members
      String strCurrentMembers = 
        DataFilterUtils.getCurrentMembers (baseDataFilter, getContext(), true, !hasParameter (baseDataFilter));

      updateTextFieldMembers (jTextFieldMembers, strCurrentMembers);

      updateMemberState (jTextFieldMembers, getModel().getDataFilter());
    }
  }

  /**
   * @internal
   * 
   * Updates a <code>JTextField</code> from a <code>BaseDataFilter</code>.
   * 
   * BaseDataFilter => JTextField
   * 
   * @param baseDataFilter A <code>BaseDataFilter</code>
   * 
   * 
   */
  public void updateMembers (BaseDataFilter baseDataFilter) {
    ConstraintComponent constraintComponent = getConstraintComponent();
 
    // Enable/Disable the state of the Members combo based on the operator
    if (constraintComponent instanceof DataFilterDescriptorComponent) {
      DataFilterDescriptorComponent dataFilterDescriptorComponent = 
        (DataFilterDescriptorComponent)constraintComponent;

      if (baseDataFilter != null) {
        if (!(baseDataFilter instanceof CompoundDataFilter)) {
          JTextField jTextFieldMembers = 
            dataFilterDescriptorComponent.getMembersTextField(); 
    
          updateMembers (baseDataFilter, jTextFieldMembers);  
        }
      }
    }
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * @internal
   * 
   * Update the browse button state based on operator.
   * 
   * 
   */
  protected static void updateBrowseButtonState (DataFilterPanelButton dataFilterPanelButton, int nCmpOperator) {
    
    if (dataFilterPanelButton != null) {
      boolean bEnabled = true;

      switch (nCmpOperator) {
      
        case TopBottomDataFilter.OP_BOTTOM:
        case TopBottomDataFilter.OP_TOP:
          bEnabled = false;
          break;      
      
        default:
          break;
      }
      
      dataFilterPanelButton.setEnabled (bEnabled);
    }
  }

  /**
   * @internal
   * 
   * Update the browse button state based on <code>MDItem</code>.
   * 
   * 
   */
  protected static void updateBrowseButtonState (DataFilterPanelButton dataFilterPanelButton, MDItem mdItem) {
    
    if (dataFilterPanelButton != null) {
      boolean bEnabled = false;

      // Only enable browse button for non-date items
      if (mdItem != null) {
        bEnabled = !(MM.DATE.equals (mdItem.getDatatype()));
      }
      
      dataFilterPanelButton.setEnabled (bEnabled);
    }
  }

  /**
   * Determines if the <code>DataFilter</code> contains a parameter.
   * 
   * @return <code>boolean</code> which is <code>true</code> when a parameter
   *         is present and <code>false</code> otherwise.
   * 
   * 
  */
  protected boolean hasParameter (BaseDataFilter baseDataFilter) {
    boolean bHasParameter = false;
  
    if (baseDataFilter != null) {
      String[] strParameterNames = baseDataFilter.getParameterNames();

      if ((strParameterNames != null) && (strParameterNames.length != 0)) {
        bHasParameter = true;  
      }               
    }

    return bHasParameter;
  }

  protected void setConstraintComponent (ConstraintComponent constraintComponent) {
    m_constraintComponent = constraintComponent;
  }

  protected ConstraintComponent getConstraintComponent() {
    return m_constraintComponent;
  }

  protected void updateDeleteButtonState() { 
    if (getDataFilterConstraintBuilder() != null) {
      if (getDataFilterConstraintBuilder().getSelectionCount() != 0) {
        getDataFilterControlBar().getButtonDelete().setEnabled (true);
      }
      else {
        getDataFilterControlBar().getButtonDelete().setEnabled (false);
      }
    }
  }    

  protected void updateToggleActionState() { 
    if (getDataFilterConstraintBuilder() != null) {
      if (getDataFilterConstraintBuilder().getSelectionCount() != 0) {
        getToggleActionAnd().setEnabled (true);  
        getToggleActionOr().setEnabled (true);  
      }
      else {
        getToggleActionAnd().setEnabled (false);  
        getToggleActionOr().setEnabled (false);  
      }
    }
  }    
  
  protected void setDataFilterConstraintBuilder (DataFilterConstraintBuilder dataFilterConstraintBuilder) { 
    m_dataFilterConstraintBuilder = dataFilterConstraintBuilder;
  }

  protected DataFilterConstraintBuilder getDataFilterConstraintBuilder() { 
    return m_dataFilterConstraintBuilder;
  }

  protected JPanel makeConditionPanel() {
    JPanel jPanel = new JPanel (new BorderLayout());
   
    // Add the Control Bar which has the button options to the Members JList
    JLabel jLabel = 
      makeLabel (getResourceString (QueryBuilderBundle.ADVANCEDDATAFILTERPANEL_TITLE));

    setDataFilterControlBar (makeControlBar());

    // Add the Control Bar which has the button options to the main panel
    ComponentWithTitlebar componentWithTitlebar = 
      new ComponentWithTitlebar (makeConstraintBuilder(), jLabel, 
        getDataFilterControlBar().getControlBar());
 
    jLabel.setLabelFor (componentWithTitlebar.getComponent());

    // Add the main panel
    jPanel.add (componentWithTitlebar, BorderLayout.CENTER);
    
    return jPanel;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  private void initGUI() {
    add (makeConditionPanel(), BorderLayout.CENTER);
  }

  private ParentComponent refresh (BaseDataFilter dataFilter, 
                                   ParentComponent parentComponent) {
    if (dataFilter != null) {
      if (dataFilter instanceof CompoundDataFilter) {
        CompoundDataFilter compoundDataFilter = 
          (CompoundDataFilter)dataFilter;
        
        AndOrComponent andOr = 
          getDataFilterConstraintBuilder().createAndOr(
            compoundDataFilter.getOperator() == CompoundDataFilter.AND);
        
        if (parentComponent != null) {
          parentComponent.addChild (andOr);
        }

        BaseDataFilter[] dataFilters = compoundDataFilter.getDataFilters();
        if ((dataFilters != null) && (dataFilters.length > 0)) {
          for (int i = 0; i < dataFilters.length; i++) {
            refresh (dataFilters[i], andOr);
          }
        }
      }
      else if (dataFilter instanceof BaseDataFilter) {
        setConstraintComponent (makeConstraintComponent (dataFilter));
        
        getDataFilterConstraintBuilder().addConstraintComponent (
          parentComponent, getConstraintComponent());
              
        // Enable/Disable the state of the Members combo based on the operator
        if (getConstraintComponent() instanceof DataFilterDescriptorComponent) {
          DataFilterDescriptorComponent dataFilterDescriptorComponent = 
            (DataFilterDescriptorComponent)getConstraintComponent();

          updateMemberState (dataFilterDescriptorComponent.getMembersTextField(), dataFilter);

          updateBrowseButtonState (dataFilterDescriptorComponent);
        }
      }
    }

    return parentComponent;
  }

  /**
   * @internal
   * 
   * Update the browse button state based on operator.
   * 
   * 
   */
  protected void updateBrowseButtonState (DataFilterDescriptorComponent dataFilterDescriptorComponent) {
    
    if (dataFilterDescriptorComponent != null) {

      int nCmpOperator = 
        DataFilterUtils.getOperatorId (dataFilterDescriptorComponent.getOperatorComboBox());

      ConstraintComponent constraintComponent = 
        dataFilterDescriptorComponent.getConstraintComponent2();   
  
      if (constraintComponent instanceof DataFilterConstraintComponent) {
        DataFilterPanelButton dataFilterPanelButton =  
          ((DataFilterConstraintComponent)constraintComponent).getButtonBrowse();

        updateBrowseButtonState (dataFilterPanelButton, nCmpOperator);

        MDItem mdItem = 
          DataFilterUtils.getMDItem (dataFilterDescriptorComponent.getItemComboBox());

        updateBrowseButtonState (dataFilterPanelButton, mdItem);
     
        // updateOperators (mdItem);
      }
    }
  }

  private CompoundDataFilter makeCompoundDataFilter (CompoundDataFilter parent, 
      AndOrComponent andOrComponent) throws Exception {
    
    if (andOrComponent != null) {
      CompoundDataFilter compoundDataFilter = new CompoundDataFilter();
      compoundDataFilter.setOperator (
        andOrComponent.isAnd() ? CompoundDataFilter.AND : CompoundDataFilter.OR);
      
      if (parent != null) {
        parent.addDataFilter(compoundDataFilter);
      }
      
      ConstraintBuilderComp[] children = andOrComponent.getChildren();
      if (children != null) {
        BaseDataFilter child;
      
        for (int i = 0; i < children.length; i++) {
          if (children[i] instanceof AndOrComponent) {
            makeCompoundDataFilter (compoundDataFilter, (AndOrComponent)children[i]);
          }
      
          if (children[i] instanceof DragComponent) {
            child = 
              makeDataFilter (((DragComponent)children[i]).getConstraintComponent());
      
            if (child != null) {
              compoundDataFilter.addDataFilter(child);
            }
          }
        }
      }
    
      return compoundDataFilter;
    }
    
    return null;
  }

  private BaseDataFilter makeDataFilter (ConstraintComponent constraintComponent) throws Exception {
    BaseDataFilter baseDataFilter = null;
    
    if (constraintComponent instanceof DataFilterDescriptorComponent) {
      DataFilterDescriptorComponent dataFilterDescriptorComponent =
        ((DataFilterDescriptorComponent)constraintComponent);

      int nCmpOperator = 
        DataFilterUtils.getOperatorId (dataFilterDescriptorComponent.getOperatorComboBox());

      baseDataFilter = makeBaseDataFilter (dataFilterDescriptorComponent, nCmpOperator);
    }

    return baseDataFilter;
  }

  /**
   * Make a <code>BaseDataFilter</code> based on the <code>DataFilterConstraintComponent</code>
   * contents.
   * 
   * @param dataFilterConstraintComponent A <code>DataFilterConstraintComponent</code> 
   * 
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  public BaseDataFilter makeBaseDataFilter (DataFilterConstraintComponent dataFilterConstraintComponent) throws Exception{

    BaseDataFilter baseDataFilter = null;
    int nCmpOperator = (dataFilterConstraintComponent != null) ?  
      DataFilterUtils.getOperatorId (dataFilterConstraintComponent.getOperatorComboBox()) : 0;

    switch (nCmpOperator) {
      case TopBottomDataFilter.OP_BOTTOM:
      case TopBottomDataFilter.OP_TOP:
        baseDataFilter = makeTopBottomDataFilter (dataFilterConstraintComponent);
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        baseDataFilter = makeRangeDataFilter (dataFilterConstraintComponent);
        break;
      
      default:
        baseDataFilter = makeDataFilter (dataFilterConstraintComponent);
        break;
    }

    return baseDataFilter;
  }

  /**
   * Make a <code>DataFilter</code> based on the <code>DataFilterConstraintComponent</code>
   * contents.
   * 
   * @param dataFilterConstraintComponent A <code>DataFilterConstraintComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * @throws <code>Exception<code>
   * 
   * 
   */
  protected BaseDataFilter makeDataFilter (DataFilterConstraintComponent dataFilterConstraintComponent) throws Exception {
    
    DataFilter dataFilter = new DataFilter();
    
    dataFilter.setItem(
      DataFilterUtils.getItemId (dataFilterConstraintComponent.getItemComboBox()));
    
    dataFilter.setCmpOperator (
      DataFilterUtils.getOperatorId (dataFilterConstraintComponent.getOperatorComboBox()));
  
    dataFilter.setCmpValues (getMembers (dataFilterConstraintComponent, dataFilter));
  
    return dataFilter;
  }

  /**
   * Make a <code>TopBottomDataFilter</code> based on the <code>DataFilterConstraintComponent</code>
   * contents.
   * 
   * @param dataFilterConstraintComponent A <code>DataFilterConstraintComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  protected BaseDataFilter makeTopBottomDataFilter (DataFilterConstraintComponent dataFilterConstraintComponent) {
    
    TopBottomDataFilter topBottomDataFilter = new TopBottomDataFilter();

    topBottomDataFilter.setItem (
      DataFilterUtils.getItemId (dataFilterConstraintComponent.getItemComboBox()));
    
    topBottomDataFilter.setOperator (
      DataFilterUtils.getOperatorId (dataFilterConstraintComponent.getOperatorComboBox()));

    return topBottomDataFilter;
  }

  /**
   * Make a <code>RangeDataFilter</code> based on the <code>DataFilterConstraintComponent</code>
   * contents.
   * 
   * @param dataFilterConstraintComponent A <code>DataFilterConstraintComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  protected BaseDataFilter makeRangeDataFilter (DataFilterConstraintComponent dataFilterConstraintComponent) {
    
    RangeDataFilter rangeDataFilter = new RangeDataFilter();

    rangeDataFilter.setItem (
      DataFilterUtils.getItemId (dataFilterConstraintComponent.getItemComboBox()));
    
    rangeDataFilter.setOperator (
      DataFilterUtils.getOperatorId (dataFilterConstraintComponent.getOperatorComboBox()));

    Vector vobjMembers = getMembers (dataFilterConstraintComponent, rangeDataFilter);

    // Update the members
    if ((vobjMembers != null) && (!vobjMembers.isEmpty())) {

      // Iterate over the list
      for (int nIndex = 0; nIndex < vobjMembers.size(); nIndex++) {              
        switch (nIndex) {
          case 0:
            rangeDataFilter.setStartValue (vobjMembers.get (nIndex));
            break;
            
          case 1:
            rangeDataFilter.setEndValue (vobjMembers.get (nIndex));
            break;

          // Ignore any extra values                
          default:
            break;
        }
      }
    }

    return rangeDataFilter;
  }

  /**
   * Make a <code>BaseDataFilter</code> based on the <code>BaseDataFilterPanel</code>
   * contents.
   * 
   * @param dataFilterDescriptorComponent A <code>DataFilterDescriptorComponent</code> 
   * @param nCmpOperator A <code>int</code> representing the <code>BaseDataFilter</code>
   *        comparison opeartor.
   * 
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  public BaseDataFilter makeBaseDataFilter (DataFilterDescriptorComponent dataFilterDescriptorComponent, 
      int nCmpOperator) throws Exception{

    BaseDataFilter baseDataFilter = null;

    switch (nCmpOperator) {
      case TopBottomDataFilter.OP_BOTTOM:
      case TopBottomDataFilter.OP_TOP:
        baseDataFilter = makeTopBottomDataFilter (dataFilterDescriptorComponent);
        break;

      case RangeDataFilter.OP_BETWEEN:
      case RangeDataFilter.OP_NOT_BETWEEN:
        baseDataFilter = makeRangeDataFilter (dataFilterDescriptorComponent);
        break;
      
      default:
        baseDataFilter = makeDataFilter (dataFilterDescriptorComponent);
        break;
    }

    return baseDataFilter;
  }

  /**
   * Make a <code>DataFilter</code> based on the <code>DataFilterDescriptorComponent</code>
   * contents.
   * 
   * @param dataFilterDescriptorComponent A <code>DataFilterDescriptorComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * @throws <code>Exception<code>
   * 
   * 
   */
  protected BaseDataFilter makeDataFilter (DataFilterDescriptorComponent dataFilterDescriptorComponent) throws Exception {
    
    DataFilter dataFilter = new DataFilter();
    dataFilter.setItem(
      DataFilterUtils.getItemId (dataFilterDescriptorComponent.getItemComboBox()));
    
    dataFilter.setCmpOperator (
      DataFilterUtils.getOperatorId (dataFilterDescriptorComponent.getOperatorComboBox()));
    
    dataFilter.setCmpValues (getMembers (dataFilterDescriptorComponent, dataFilter));
  
    return dataFilter;
  }

  /**
   * Make a <code>TopBottomDataFilter</code> based on the <code>DataFilterDescriptorComponent</code>
   * contents.
   * 
   * @param dataFilterDescriptorComponent A <code>DataFilterDescriptorComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  protected BaseDataFilter makeTopBottomDataFilter (DataFilterDescriptorComponent dataFilterDescriptorComponent) {
    
    TopBottomDataFilter topBottomDataFilter = new TopBottomDataFilter();
    topBottomDataFilter.setItem (
      DataFilterUtils.getItemId (dataFilterDescriptorComponent.getItemComboBox()));
    
    topBottomDataFilter.setOperator (
      DataFilterUtils.getOperatorId (dataFilterDescriptorComponent.getOperatorComboBox()));

    // Update the DataFilter members 
    Vector vObjects = 
      getMembers (dataFilterDescriptorComponent, topBottomDataFilter);

    if ((vObjects != null) && (!vObjects.isEmpty())) {
      Object object = vObjects.get(0);

      if (object instanceof Number) {
        int nValue = ((Number)object).intValue();
        topBottomDataFilter.setValue (nValue);   
      }
    }
    else {
      topBottomDataFilter.setValue (INVALID_VALUE);   
    }

    return topBottomDataFilter;
  }

  /**
   * Make a <code>RangeDataFilter</code> based on the <code>DataFilterDescriptorComponent</code>
   * contents.
   * 
   * @param dataFilterDescriptorComponent A <code>DataFilterDescriptorComponent</code> 
   *        
   * @return <code>BaseDataFilter</code>
   * 
   * 
   */
  protected BaseDataFilter makeRangeDataFilter (DataFilterDescriptorComponent dataFilterDescriptorComponent) {
    
    RangeDataFilter rangeDataFilter = new RangeDataFilter();
    rangeDataFilter.setItem (
      DataFilterUtils.getItemId (dataFilterDescriptorComponent.getItemComboBox()));
    
    rangeDataFilter.setOperator (
      DataFilterUtils.getOperatorId (dataFilterDescriptorComponent.getOperatorComboBox()));

    // Update the DataFilter members 
    Vector vObjects = 
      getMembers (dataFilterDescriptorComponent, rangeDataFilter);

    if ((vObjects != null) && (!vObjects.isEmpty())) {
      if (vObjects.size() > 1) {
        rangeDataFilter.setStartValue (vObjects.get(0));
        rangeDataFilter.setEndValue (vObjects.get(1));
      }
    }

    return rangeDataFilter;
  }

  public class DataFilterDescriptorComponent extends MultiDescriptorComponent {

    /////////////////////
    //
    // Members
    //
    /////////////////////

    protected JComboBox m_jComboBoxItems;
    private JComboBox m_jComboBoxOperators;

    private BaseDataFilter m_baseDataFilter = null;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    public DataFilterDescriptorComponent (BaseDataFilter baseDataFilter) {
      setDataFilter (baseDataFilter);
    }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public void setContext (ComponentContext context) {
      m_componentContext = context;
    }

    public void setItemComboBox (JComboBox jComboBoxItems) {
      m_jComboBoxItems = jComboBoxItems;
    }

    public JComboBox getItemComboBox() {
      return m_jComboBoxItems;
    }

    public BaseDataFilter getDataFilter() {
      return m_baseDataFilter;
    }

    public void setDataFilter (BaseDataFilter baseDataFilter) {
      m_baseDataFilter = baseDataFilter;
    }

    public void setOperatorComboBox (JComboBox jComboBoxOperators) {
      m_jComboBoxOperators = jComboBoxOperators;
    }

    public JComboBox getOperatorComboBox() {
      return m_jComboBoxOperators;
    }

    public ConstraintComponent getConstraintComponent2() {
      return getConstraintComponent();
    }

    public JTextField getMembersTextField() {
      return getMembersTextField (getConstraintComponent());
    }

    public DataFilterPanelButton getButtonBrowse() {
      return getButtonBrowse (getConstraintComponent());
    }

    /////////////////////
    //
    // Protected Methods
    //
    /////////////////////

    /**
     * Initialize the <code>DataFilterDescriptorComponent</code> based on the
     * <code>DataFilter</code>.
     * 
     * 
     */
    protected void initialize() {
      
      Vector vList = new Vector();
      
      Vector mdItems = QBUtils.getSelectedMDItems (getContext());
      if ((mdItems != null) && (!mdItems.isEmpty())) {
        vList.addElement (new JList (mdItems));
      }
  
      MDItem mdItem = DataFilterUtils.getCurrentItem (getDataFilter(), getContext());
      if ((mdItems != null) && (mdItem != null) && 
          (!mdItems.contains (mdItem))) {
        
        mdItems.addElement (mdItem);
      }

      setItemComboBox (new JComboBox());
  
      getItemComboBox().setModel (new TreeListComboBoxModel());

      Object[] objData = { new MoreItems (getItemComboBox()) };
      vList.addElement (new JList (objData));

      JList[] jLists = new JList [vList.size()];
      vList.copyInto (jLists);

      ((TreeListComboBoxModel)getItemComboBox().getModel()).setLists (jLists);
    
      getItemComboBox().addItemListener (new DataFilterPanelItemListener());
  
      getItemComboBox().addItemListener (new ItemListener() {
        public void itemStateChanged (ItemEvent itemEvent) {
          if ((itemEvent != null) && (itemEvent.getStateChange() == ItemEvent.SELECTED)) {
            Object object = itemEvent.getItem();
            
            if (object instanceof MDItem) {
              ConstraintComponent constraintComponent = getConstraintComponent();
              
              if (constraintComponent instanceof DataFilterConstraintComponent) {
                MDItem mdItem = (MDItem)object;

                DataFilterConstraintComponent dataFilterConstraintComponent =
                  (DataFilterConstraintComponent)constraintComponent;
              
                BaseDataFilter baseDataFilter = 
                  dataFilterConstraintComponent.getDataFilter();
                
                // If the MDItem has changed, zap the members
                if (baseDataFilter != null) {
                  if (!mdItem.getUniqueID().equals (getItemID (baseDataFilter))) {
                    JTextField jTextField = dataFilterConstraintComponent.getMembersTextField();  
                    
                    if (jTextField != null) {
                      jTextField.setText (null);  
                    }
                  }
                }
                
                dataFilterConstraintComponent.setItem (mdItem);
              
                // Update the available operators based on the MDItem datatype
                updateOperators (getOperatorComboBox(), mdItem);
              
                // Update the state of the browse button based on selected item
                updateBrowseButtonState(); 
              }
            }
          }
        }
      });
  
      if (mdItem == null) {
        getItemComboBox().setSelectedIndex(0);
      }
      else {
        getItemComboBox().setSelectedItem (mdItem);
      }
    }

    protected DataFilterDescriptorComponent getDataFilterDescriptorComponent() {
      return this;
    }

    protected JTextField getMembersTextField (ConstraintComponent constraintComponent) {

      if (constraintComponent instanceof DataFilterConstraintComponent) {
        return ((DataFilterConstraintComponent)constraintComponent).getMembersTextField();
      }
      
      return null;
    }

    protected DataFilterPanelButton getButtonBrowse (ConstraintComponent constraintComponent) {

      if (constraintComponent instanceof DataFilterConstraintComponent) {
        return ((DataFilterConstraintComponent)constraintComponent).getButtonBrowse();
      }
      
      return null;
    }

    protected JComboBox createDescriptorSelector() {
      setDataFilter (m_baseDataFilterInit);
      initialize();

      return getItemComboBox();
    }

    protected ConstraintComponent getConstraintComponent (DataDescriptor dataDescriptor) {
      DataFilterConstraintComponent constraintComponent = 
        new DataFilterConstraintComponent (getDataFilter());
      
      constraintComponent.remove (constraintComponent.getConditionComponent());

      setOperatorComboBox (new JComboBox (new DefaultComboBoxModel (getOperatorDisplays())));
      
      getOperatorComboBox().addItemListener (new ItemListener() {
        public void itemStateChanged (ItemEvent itemEvent) {
          // Enable/Disable the state of the Members combo based on the operator
          updateMemberState();
          
          // Enable/Disable the state of the Browse button based on the operator
          updateBrowseButtonState();
        }
      });
      
      OperatorDisplay operatorDisplay = 
        DataFilterUtils.getCurrentOperator (getOperatorDisplays(), getDataFilter());
      DataFilterUtils.setSelectedItem (getOperatorComboBox(), operatorDisplay);
      constraintComponent.add (BaseLayoutManager.CONDITION, getOperatorComboBox());

      // Initialize the members based on the chosen item
      JComboBox jComboBoxItems = getItemComboBox();
      if (jComboBoxItems != null) {
        Object object = jComboBoxItems.getSelectedItem();

        if (object instanceof MDItem) {
          constraintComponent.setItem ((MDItem)object);
        }
      }

      return constraintComponent;
    }

    /**
     * @internal
     * 
     * Update the member state based on operator.
     * 
     * 
     */
    protected void updateMemberState() {
      int nCmpOperator = DataFilterUtils.getOperatorId (getOperatorComboBox());
      BaseDataFilterPanel.updateMemberState (getMembersTextField(), nCmpOperator);
    }

    /**
     * @internal
     * 
     * Update the member state based on operator.
     * 
     * 
     */
    protected void updateMemberState (JTextField jTextFieldMembers, BaseDataFilter baseDataFilter) {
      if (baseDataFilter != null) {
        BaseDataFilterPanel.updateMemberState (jTextFieldMembers, baseDataFilter.getCmpOperator());
      }
    }

    /**
     * @internal
     * 
     * Update the browser button state based on operator.
     * 
     * 
     */
    protected void updateBrowseButtonState() {
      int nCmpOperator = DataFilterUtils.getOperatorId (getOperatorComboBox());
      AdvancedDataFilterPanel.updateBrowseButtonState (getButtonBrowse(), nCmpOperator);

      MDItem mdItem = 
        DataFilterUtils.getMDItem (getItemComboBox());

      AdvancedDataFilterPanel.updateBrowseButtonState (getButtonBrowse(), mdItem);
    }
  }

  private class DataFilterConstraintComponent extends ComparisonConstraintComp {

    /////////////////////
    //
    // Members
    //
    /////////////////////

    protected JTextField m_jTextFieldMembers = null;
    public BaseDataFilter m_baseDataFilter = null;

    /**
     * Browse button.
     * 
     * 
     */
    protected DataFilterPanelButton m_jButtonBrowse = null;

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Specifies the Browse button.
     * 
     * @param jButtonBrowse A <code>JButton</code>.
     * 
     * 
     */
    public void setButtonBrowse (DataFilterPanelButton jButtonBrowse) {
      m_jButtonBrowse = jButtonBrowse;
    }
    
    /**
     * Retrieves the Browse button.
     *
     * @return <code>JButton</code> which represents the browse button.
     * 
     * 
     */
    public DataFilterPanelButton getButtonBrowse() {
      return m_jButtonBrowse;
    }

    /////////////////////
    //
    // Constructors
    //
    /////////////////////
    
    public DataFilterConstraintComponent (BaseDataFilter baseDataFilter) {
      super();
      setValueWidth(200);

      setDataFilter (baseDataFilter);

      JTextField jTextFieldMembers = getMembersTextField(); 

      if (jTextFieldMembers != null) {
        m_jTextFieldMembers = jTextFieldMembers;
      
        // Refresh the Members
        String strCurrentMembers = 
          DataFilterUtils.getCurrentMembers (getDataFilter(), getContext(), true, !hasParameter(getDataFilter()));

        updateTextFieldMembers (jTextFieldMembers, strCurrentMembers);
      }
      
      DataFilterPanelButton dataFilterPanelButton = getDataFilterPanelButton(); 

      if (dataFilterPanelButton != null) {
        m_jButtonBrowse = dataFilterPanelButton;
      }
    }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public void setContext (ComponentContext context) {
      m_componentContext = context;
    }

    public void setItem (MDItem mdItem) {
      setClass (DataFilterUtils.getClass (mdItem), mdItem, 
        getMembersTextField(), m_componentContext, getModel());
    }

    public JTextField getMembersTextField() {
      JTextField jTextFieldMembers = null;

      Component component = getValueComponent(); 
      if (component == null) {
        component = m_jTextFieldMembers;
      }

      if ((component != null) && (component instanceof JPanel)) {
        Component[] components = ((JPanel)component).getComponents();
      
        for (int nIndex = 0; nIndex < components.length; nIndex++) {
          if (components[nIndex] instanceof JTextField) {
            jTextFieldMembers = (JTextField) components[nIndex];   
            break;
          }   
        }
      }
    
      return jTextFieldMembers;
    }

    public DataFilterPanelButton getDataFilterPanelButton() {
      DataFilterPanelButton dataFilterPanelButton = null;

      Component component = getValueComponent(); 
      if (component == null) {
        component = m_jButtonBrowse;
      }

      if ((component != null) && (component instanceof JPanel)) {
        Component[] components = ((JPanel)component).getComponents();
      
        for (int nIndex = 0; nIndex < components.length; nIndex++) {
          if (components[nIndex] instanceof DataFilterPanelButton) {
            dataFilterPanelButton = (DataFilterPanelButton) components[nIndex];   
            break;
          }   
        }
      }
    
      return dataFilterPanelButton;
    }

    public void setMembersTextField (JTextField jTextFieldMembers) {
      m_jTextFieldMembers = jTextFieldMembers;
    }

    public BaseDataFilter getDataFilter() {
      return m_baseDataFilter;
    }

    public void setDataFilter (BaseDataFilter baseDataFilter) {
      m_baseDataFilter = baseDataFilter;
    }

    /////////////////////
    //
    // Protected Methods
    //
    /////////////////////

    /**
     * Determines if the <code>DataFilter</code> contains a parameter.
     * 
     * @return <code>boolean</code> which is <code>true</code> when a parameter
     *         is present and <code>false</code> otherwise.
     * 
     * 
    */
    protected boolean hasParameter (BaseDataFilter baseDataFilter) {
      boolean bHasParameter = false;
    
      if (baseDataFilter != null) {
        String[] strParameterNames = baseDataFilter.getParameterNames();

        if ((strParameterNames != null) && (strParameterNames.length != 0)) {
          bHasParameter = true;  
        }               
      }

      return bHasParameter;
    }
    
    protected boolean isNullAllowed() {
      return true;
    }

    protected Component createValueComponent() {
      
      GridBagLayout gridBagLayout = new GridBagLayout();
      GridBagConstraints gridBagConstraints = new GridBagConstraints();

      JPanel jPanelMembers = new JPanel (gridBagLayout);

      setButtonBrowse (new DataFilterPanelButton (this));
 
      Utils.initializeIconButton (getButtonBrowse(), 
        getResourceString (QueryBuilderBundle.DATAFILTERPANEL_VALUE_TOOLTIP_BROWSE), 
          new ImageIcon (Utils.getImageResource (QueryBuilder.class, "images/search_ena.png")));

      getButtonBrowse().addActionListener (new ActionListener() {
        public void actionPerformed (ActionEvent actionEvent) {
          try {
            DataFilterConstraintComponent dataFilterConstraintComponent = 
              getConstraintComponent (actionEvent);

            BaseDataFilter baseDataFilter = 
              makeBaseDataFilter (dataFilterConstraintComponent);
  
            // Update the DataFilter based on the current state
            setDataFilter (baseDataFilter);

            if (baseDataFilter != null) {
              Object[] objectsSelected = null;
              
              MDItem mdItem = getItem (baseDataFilter);
              
              if (DataUtils.isNumeric (mdItem)) {
                objectsSelected = invokeSelectItemsDialog (baseDataFilter);
              }
              else {
                objectsSelected = invokeSelectValuesDialog (baseDataFilter);
              }
    
              if (objectsSelected != null) {
                
                // Update DataFilter
                updateMembers (getDataFilter(), objectsSelected);
                
                // Update GUI
                if (dataFilterConstraintComponent != null) {
                  updateMembers (getDataFilter(), dataFilterConstraintComponent.getMembersTextField());
                }
              }
            }
          }
          
          catch (Exception exception) {
            Logger.getLogger ("oracle.dss.queryBuilder.AdvancedDataFilterPanel").log (Level.INFO, 
              "invokeSelectValuesDialog failed", exception);
          }
        }
      });

      setDataFilter (m_baseDataFilterInit);

      JTextField jTextFieldMembers = new JTextField();
      jTextFieldMembers.setEditable (true);
      
      setMembersTextField (jTextFieldMembers);
      
      MDItem mdItem = 
        DataFilterUtils.getCurrentItem (getDataFilter(), getContext());

      setItem (mdItem);

      gridBagConstraints.anchor = GridBagConstraints.WEST;
      gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
      gridBagConstraints.weightx = 1.0;

      jPanelMembers.add (jTextFieldMembers, gridBagConstraints);

      gridBagConstraints.weightx = 0.0;
      jPanelMembers.add (getButtonBrowse(), gridBagConstraints);

      return jPanelMembers;
    }

    protected DataFilterConstraintComponent getConstraintComponent (ActionEvent actionEvent) {

      DataFilterConstraintComponent dataFilterConstraintComponent = null;

      Object objSource = actionEvent.getSource();
            
      if (objSource instanceof DataFilterPanelButton) {
        DataFilterPanelButton dataFilterPanelButton =
          (DataFilterPanelButton)objSource;
      
        Component componentOwner = dataFilterPanelButton.getOwner();
        if (componentOwner instanceof DataFilterConstraintComponent) {
          dataFilterConstraintComponent =
            (DataFilterConstraintComponent) componentOwner;
        }
      }
      
      return dataFilterConstraintComponent;
    }

    private JComboBox getOperatorComboBox() {
      JComboBox jComboBoxOperator = null;
      
      if (getDataFilterConstraintBuilder() != null) {
        
        ConstraintBuilderComp[] selectedComponents = 
          getDataFilterConstraintBuilder().getSelected();

        DataFilterDescriptorComponent dataFilterDescriptorComponent = null;
        
        if ((selectedComponents != null) && (selectedComponents.length > 0)) {
          
          if (selectedComponents[0] instanceof DragComponent) {
            ConstraintComponent constraintComponent = 
              ((DragComponent)selectedComponents[0]).getConstraintComponent();
         
            if (constraintComponent instanceof DataFilterDescriptorComponent) {
              dataFilterDescriptorComponent = 
                (DataFilterDescriptorComponent) constraintComponent;  
            }
          }
        }
        
        if (dataFilterDescriptorComponent != null) {
           jComboBoxOperator = dataFilterDescriptorComponent.getOperatorComboBox();  
        }
      }

      return jComboBoxOperator;
    }
    
    private JComboBox getItemComboBox() {
      JComboBox jComboBoxItem = null;
      
      if (getDataFilterConstraintBuilder() != null) {
        
        ConstraintBuilderComp[] selectedComponents = 
          getDataFilterConstraintBuilder().getSelected();

        DataFilterDescriptorComponent dataFilterDescriptorComponent = null;

        // Check to see if we have something selected        
        if ((selectedComponents != null) && (selectedComponents.length > 0)) {
          
          if (selectedComponents[0] instanceof DragComponent) {
            ConstraintComponent constraintComponent = 
              ((DragComponent)selectedComponents[0]).getConstraintComponent();
         
            if (constraintComponent instanceof DataFilterDescriptorComponent) {
              dataFilterDescriptorComponent = 
                (DataFilterDescriptorComponent) constraintComponent;  
            }
          }
        }
        else {
          // If not, just attempt to retrieve first one
          ConstraintComponent[] constraintComponents = 
            getDataFilterConstraintBuilder().getLeaves();
  
          if ((constraintComponents != null) && (constraintComponents.length > 0)) {
            ConstraintComponent constraintComponent = constraintComponents[0];

            if (constraintComponent instanceof DataFilterDescriptorComponent) {
              dataFilterDescriptorComponent = 
                (DataFilterDescriptorComponent) constraintComponent;  
            }
          }        
        }
        
        if (dataFilterDescriptorComponent != null) {
           jComboBoxItem = dataFilterDescriptorComponent.getItemComboBox();  
        }
      }

      return jComboBoxItem;
    }
  }

  private ConstraintComponent makeConstraintComponent (BaseDataFilter baseDataFilter) {
    
    m_baseDataFilterInit = baseDataFilter;

    DataFilterDescriptorComponent dataFilterDescriptorComponent = 
      new DataFilterDescriptorComponent (baseDataFilter);

    m_baseDataFilterInit = null;
    
    return dataFilterDescriptorComponent;
  }

  private ConstraintBuilder makeConstraintBuilder() {
    setDataFilterConstraintBuilder (new DataFilterConstraintBuilder());

    getDataFilterConstraintBuilder().addPropertyChangeListener (new PropertyChangeListener() {
      
      /**
       * Called when a bound property is changed.
       * 
       * @param propertyChangeEvent A <code>PropertyChangeEvent</code> object 
       *        describing the event source and the property that has changed.
       *        
       *         
       */
      public void propertyChange (PropertyChangeEvent propertyChangeEvent) {
        // Update the status of the Delete button
        updateDeleteButtonState();
      }
    });

    return getDataFilterConstraintBuilder();
  }

  protected class DataFilterAndOrComponent extends AndOrComponent {
 
    /**
     * Create an <code>DataFilterAndOrComponent</code> that is either an AND or an OR.
     *
     * @param isAnd true if the AndOrComponent should represent and AND
     */
    public DataFilterAndOrComponent (boolean isAnd) {
      super (isAnd);
    }

    /**
      * Create a new GroupComponent.
      */
    protected GroupComponent createGroupComponent() {
      GroupComponent groupComponent = super.createGroupComponent();
      
      if (groupComponent != null) {
        LWComponent lwComponent = groupComponent.getComponent();
        
        if (lwComponent != null) {
          // Retrieve the components
          Component[] components = lwComponent.getComponents();
          
          if (components != null) {
            // Retrieve the first component
            Component component = lwComponent.getComponent(0);
            
            // Remove the following from the combo box
            //   DBUIStringConstants.STRING_NOT_AND
            //   DBUIStringConstants.STRING_NOT_OR
            if (component instanceof JComboBox) {
              JComboBox jComboBox = (JComboBox)component;
    
              if (jComboBox.getModel() instanceof DefaultComboBoxModel) {
                DefaultComboBoxModel defaultComboBoxModel = 
                  (DefaultComboBoxModel)jComboBox.getModel();
            
                Object objComboBox = null;

                for (int nIndex = defaultComboBoxModel.getSize() - 1; nIndex >= 0; nIndex--)  {         
                  objComboBox = defaultComboBoxModel.getElementAt (nIndex);
                  
                  if ((DBUIStringConstants.STRING_NOT_AND).equals (objComboBox) ||
                      (DBUIStringConstants.STRING_NOT_OR).equals (objComboBox)) {
                    defaultComboBoxModel.removeElementAt (nIndex); 

                    /*                   
                    defaultComboBoxModel.removeElementAt (3); 
                    defaultComboBoxModel.removeElementAt (2); 
                    */
                  }
                }
              }
            }
          }
        }
      }

      return groupComponent;
    }
  }

  protected class DataFilterConstraintBuilder extends ConstraintBuilder {

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public DataFilterConstraintBuilder() {
      super();
      setConstraintCompFactory (new DataFilterConstraintCompFactory());
      setAutoSimplifyEnabled (true);
      setGroupLinesVisible (true);
    }

    public AndOrComponent createAndOr (boolean isAnd) {
      AndOrComponent andOr = createAndOrComponent (isAnd);
      andOr.setConstraintBuilder (this);
      return andOr;
    }

    public DragComponent createDragComp (ConstraintComponent dragged) {
      DragComponent drag = super.createDragComponent (dragged);
      drag.setConstraintBuilder (this);
      return drag;
    }

    public void addConstraintComponent (ParentComponent parent, 
                                        ConstraintComponent constraintComponent) {
      if (parent == null) {
        ConstraintBuilderComp[] constraintBuilderComp = getSelectedComponents();
        
        if ((constraintBuilderComp != null) && (constraintBuilderComp.length > 0)) {
          parent = 
            (constraintBuilderComp[0] instanceof ParentComponent) ? (ParentComponent)constraintBuilderComp[0] : 
            constraintBuilderComp[0].getParentComponent();
        }
        else {
          parent = getDataFilterConstraintBuilder().getRootComponent();
        }
      }

      if ((parent != null) && (constraintComponent != null)) {
        addLeaf (constraintComponent);
        DragComponent dragComponent = 
          getDataFilterConstraintBuilder().createDragComponent(constraintComponent);

        dragComponent.setConstraintBuilder (getDataFilterConstraintBuilder());
        parent.addChild (dragComponent);
      }
    }

    public ConstraintBuilderComp[] getSelected() {
      return getSelectedComponents();  
    }

    /////////////////////
    //
    // Protected Methods
    //
    /////////////////////

    /**
     * Create an AndOrComponent.
     */
    protected AndOrComponent createAndOrComponent (boolean isAnd) {
      return new DataFilterAndOrComponent (isAnd);
    }

    /**
     * Return a <code>JPopupMenu</code> that will be displayed for a AND component, 
     * an OR component, a NOT AND component, and a NOT OR component. 
     * 
     * @param andComponent
     * @param childCount
     * @param root
     * @param isNot
     * @param expanded
     * @return <code>JPopupMenu</code>
     * 
     * 
     */
    protected JPopupMenu getMenuForAndOrComponent (boolean andComponent, 
        int childCount, boolean root, boolean isNot, boolean expanded) {
      
      JPopupMenu jPopupMenu = 
        super.getMenuForAndOrComponent (andComponent, childCount, root, isNot, expanded);
      
      if (jPopupMenu != null) {
        int nIndex = getIndex (jPopupMenu, CREATE_NOT_COMMAND);
        
        // Remove the CREATE_NOT_COMMAND menu item
        if (nIndex != NOT_FOUND) {
          jPopupMenu.remove (nIndex);  
        }  
      }
      
      return jPopupMenu;
    }

    protected JPopupMenu getMenuForSingleComponent (ConstraintComponent comp,
                                                    boolean isNot) {
      JPopupMenu jPopupMenu = 
        super.getMenuForSingleComponent (comp, isNot);

      // Remove the CREATE_NOT_COMMAND menu item
      if (jPopupMenu != null) {
        int nIndex = getIndex (jPopupMenu, CREATE_NOT_COMMAND);
        
        if (nIndex != NOT_FOUND) {
          jPopupMenu.remove (nIndex);  
        }  
      }

      return jPopupMenu;
    }

    protected JPopupMenu getMenuForMultipleSelection (int selectionCount) {
      JPopupMenu jPopupMenu = 
        super.getMenuForMultipleSelection (selectionCount);

      // Remove the CREATE_NOT_COMMAND menu item
      if (jPopupMenu != null) {
        int nIndex = getIndex (jPopupMenu, CREATE_NOT_COMMAND);
        
        if (nIndex != NOT_FOUND) {
          jPopupMenu.remove (nIndex);  
        }  
      }

      return jPopupMenu;
    }

    /**
     * Attempt to find the index of <code>JMenuItem</code> action command in 
     * the specified <code>JPopupMenu</code>.
     * 
     * @param jPopupMenu A <code>JPopupMenu</code> to search.
     * @param strActionCommand A <code>String</code> representing the 
     *        action command to run.
     * 
     * @return <code>int</code> representing the index of the action command in the
     *         specified <code>JPopupMenu</code> or NOT_FOUND if not found.
     * 
     * @see #NOT_FOUND
     * 
     * 
     */
    protected int getIndex (JPopupMenu jPopupMenu, String strActionCommand) {
      int nIndexFound = NOT_FOUND;

      if ((jPopupMenu != null) && (strActionCommand != null))  {
        Component[] components = jPopupMenu.getComponents();
        
        if (components != null) {
          for (int nIndex = 0; nIndex < components.length; nIndex++) {
            if (components[nIndex] instanceof JMenuItem) {
              if (strActionCommand.equals (((JMenuItem)components[nIndex]).getActionCommand())) {
                nIndexFound = nIndex;
                break;
              }
            }
          }
        }
      }

      return nIndexFound;
    }

    protected ParentComponent getRoot() {
      return super.getRootComponent();
    }
  }

  private class DataFilterConstraintCompFactory extends ConstraintCompFactory {

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    public ConstraintComponent createConstraintComponent (DataDescriptorProvider dataDescriptorProvider, 
      DataDescriptor dataDescriptor, DataConstraint dataConstraint) {
      
      return makeConstraintComponent (null);
    }
  }

  /**
   * <code>DataFilterMenuToolButton</code>
   * 
   * Fix Bug 6502514 - Beta3: QB: Compound 'Create Data Filter' can't drop down 'Add' from keyboard.
   * 
   * Extend <code>MenuToolButton</code> so that we can implement a hack to 
   * initialize the underlying mouse pressed time variables so that keyboard 
   * access works.
   * 
   * 
   */
  private class DataFilterMenuToolButton extends MenuToolButton {
  
    public DataFilterMenuToolButton (ToggleAction buttonAction) {
      super (buttonAction);
    }
  
    protected ItemListener createButtonItemListener() {
      ButtonItemListener buttonItemListener = new ButtonItemListener (this);
      
      // Initialize ButtonItemListener with a dummy mouse event so that the 
      // underlying mouse pressed time variables are initialize so that keyboard 
      // access works.

      MouseEvent mouseEvent = 
        new MouseEvent (this, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), 0,
          0, 0, 0, false);

      buttonItemListener.mousePressed (mouseEvent);

      return buttonItemListener;
    }
  }
}