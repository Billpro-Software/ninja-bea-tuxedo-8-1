/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataManager.common.MDDimension;

/**
 * A client-side representation of a selection in an analytic workspace.
 * An <code>MDSelection</code> provides, to a java client, information about
 * a selection in the workspace.
 * <P>
 * An OLAP selection is specification of members that you want to consider
 * in a dimension.
 * For example, in a Time dimension, you might want to consider January,
 * February, and March.
 *
 * @status Reviewed
 */
public class MDSelection extends MDComponent {

    /**
     *
     * @hidden
     *
     */
    public MDSelection() {
        setObjectType(MM.SELECTION);
    }

   	/**
     * Constructor.
     *
     * @param mmServices   The <code>MetadataManagerServices</code> that this
     *                     selection exists in.
     * @param selectionName  The name of this selection.
     * @param parent       The folder that contains this object. Pass an
     *                      <code>MDFolder</code>.
     *
     * @status Documented
     */
    public MDSelection( MetadataManagerServices mmServices, String selectionName, MDObject parent ) {
        super( mmServices, selectionName, parent );
        setObjectType(MM.SELECTION);
    }

  	/**
     * @hidden
     * Retrieves the folder that contains this <code>MDSelection</code>.
     *
     * @return The folder that contains this <code>MDSelection</code>.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status hidden
     */
  	public MDFolder getFolder() throws MetadataManagerException {
  		MDObject parent = getParent();
  		if ( (parent != null) && (parent instanceof MDFolder) ) {
  			return (MDFolder)parent;
  		}
  		return null;
  	}

  	/**
     * Specifies the folder that contains this <code>MDSelection</code>.
     *
     * @param folder The folder that contains this <code>MDSelection</code>.
     *
     * @return A constant that represents success or failure.
     * The valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Reviewed
     */
  	public int setFolder(MDFolder folder) {
  		return setParent(folder);
  	}
 	
    /**
     *
     * @hidden
     *
     */
  	public static MDSelection[] getSelectionArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDSelection[] selections = new MDSelection[objects.length];
		for (int i=0; i<objects.length; i++) {
			selections[i] = (MDSelection)objects[i];
		}
		return selections;		
	}
  
    /**
     *
     * @hidden
     *
     */
  	public static MDSelection[] getSelectionArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDSelection[] selections = new MDSelection[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			selections[i] = (MDSelection)propertyBag[i];
		}
		return selections;		
	}

    /**
     *
     * @hidden
     *
     */
  public MDDimension getDimension() {
    return null;
  }
  
    /**
     *
     * @hidden
     *
     */
  public int setDimension(MDDimension dimension) {
    return MDU.FAILURE;
  }
}