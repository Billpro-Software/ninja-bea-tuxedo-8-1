/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown when an operation that requires an initialized query is attempted
 * but there is no query initialized.
 *
 * @status Documented
 */
public class NoQueryDefinedException extends QueryException
{
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     *
     * @status Documented
     */
    public NoQueryDefinedException(String s)
    {
        super(s, null);
    }
}