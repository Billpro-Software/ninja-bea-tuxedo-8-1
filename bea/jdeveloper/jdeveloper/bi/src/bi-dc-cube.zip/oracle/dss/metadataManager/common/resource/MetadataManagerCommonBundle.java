/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common.resource;

// Imports
import java.util.ListResourceBundle;
/**
 * @hidden
 * Resources for MetadataManager.
 * @status Reviewed
 */
public class MetadataManagerCommonBundle extends ListResourceBundle
{
    // common package range 10300 - 10499
    public static final String EXC_BIND_CONTEXT                  = "10300";
    public static final String EXC_INVALID_ATTRS                 = "10301";
    public static final String EXC_INVALID_NAME                  = "10302";
    public static final String EXC_INVALID_OBJ                   = "10303";
    public static final String EXC_INVALID_SEARCH_CONTROL        = "10304";
    public static final String EXC_NAME_ALREADY_BOUND            = "10305";
    public static final String EXC_NAME_NOT_FOUND                = "10306";
    public static final String EXC_NO_PERMISSION                 = "10307";
    public static final String EXC_NOT_CONTEXT                   = "10308";
    public static final String EXC_OP_NO_SUPPORT                 = "10309";
    public static final String EXC_UNKNOWN                       = "10310";
    public static final String EXC_ATTR_MOD                      = "10311";
    public static final String EXC_NOT_AW_OBJ                    = "10312";
    public static final String EXC_CIRCULAR_REF                  = "10313";
    public static final String EXC_INVALID_FOLDER                = "10315";
   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    * @status protected
    */
    protected Object[][] getContents()
    {
        return sMessageStrings;
    }

    /**
     * Private 2-D array of key-value pairs
     */
    private static final Object[][] sMessageStrings =
    {
        // from general bundle
        /**
         * @error DVT-10300 cannot bind a context
         * @cause An attempt was made to save a folder using the <code>bind</code> method.
         * @action To create a new folder, use the <code>createSubcontext</code> method.
         *         To copy a folder to another folder, use the <code>copy</code> method.
         *         To move a folder to another folder, use the <code>move</code> method.
         *
         * @status documented
         */
        { EXC_BIND_CONTEXT, "cannot bind a context" },
        /**
         * @error DVT-10301 The specified attribute is not valid.
         * @cause The key or the value of one or more attributes in the method was not valid.
         * @action Specify a valid attribute key and value.
         * @status documented
         */
        { EXC_INVALID_ATTRS, "The specified attribute is not valid." },
        /**
         * @error DVT-10302 Name is invalid; the name must not be an empty string.
         * @cause The specified name was not valid. For any methods of <code>BIContext</code>
         *        that require a name argument, the user cannot specify a null value.
         *        The following methods also require that the name argument not be an empty string: 
         *        <code>bind</code>, <code>rebind</code>, <code>createSubcontext</code>, <code>destroySubcontext</code>, <code>rename</code> and <code>unbind</code>.
         *
         * @action Specify a name whose value is not an empty string.
         * @status documented
         */
        { EXC_INVALID_NAME, "Name {0} is invalid; the name must not be an empty string." },
        /**
         * @error DVT-10303 The specified object is invalid.
         * @cause An attempt was made to save a <code>UserObject</code> that contains an object
         *        that is not accepted by the specific driver.
         * @action Set the appropriate object in <code>UserObject</code> for the specified driver type.
         *
         * @status documented
         */
        { EXC_INVALID_OBJ, "The specified object is invalid." },
        /**
         * @error DVT-10304 The specified search control is invalid.
         * @cause The specified search control was not valid for one of the following reasons:  
         *        The search scope was not valid. It must be one of the following: <code>OBJECT_SCOPE</code>, <code>ONELEVEL_SCOPE</code>,
         *         <code>SUBTREE_SCOPE</code>, <code>ONELEVEL_SCOPE_WITH_FOLDERS</code>,
         *         or <code>SELECTIVE_ONELEVEL_SCOPE</code>.
         *         The specified time limit was a negative number.
         *         The specified count limit was a negative number.
         * @action Review the possible reasons and take the appropriate action.
         * @status documented
         */
        { EXC_INVALID_SEARCH_CONTROL, "The specified search control is invalid." },
        /**
         * @error DVT-10305 Object with specified name already exists.
         * @cause An attempt was made to save an object with a name that was already bound to an
         *        object in the storage system, or the destination folder already contained an object that
         *        was bound to that particular name when the copy or move operation was performed.
         * @action If this is a save operation, then use the <code>rebind</code> method to overwrite the existing object that is bound with that name.
         *         If this is a copy operation, then specify a different target name.
         * @status documented
         */
        { EXC_NAME_ALREADY_BOUND, "Object with name {0} already exists." },
        /**
         * @error DVT-10306 Object with specified name cannot be found.
         * @cause An attempt was made to retrieve, copy, or move an object that does not exist.
         * @action No action is necessary.
         * @status documented
         */
        { EXC_NAME_NOT_FOUND, "Object with name {0} cannot be found." },
        /**
         * @error DVT-10307 User lacks sufficient privileges to perform the operation.
         * @cause An attempt was made to perform an operation that requires specific privileges,
         *        for example, saving an object to a folder in which the user does not have write access.
         * @action Request that the owner or user of the folder with full-control privileges assign
         *         sufficient privileges to the appropriate user to perform the operation.
         * @status documented
         */
        { EXC_NO_PERMISSION, "User lacks sufficient privileges to perform the operation." },
        /**
         * @error DVT-10308 The object is not a valid context.
         * @cause Depending on the operation, this error could occur because:
         *       The destination folder for <code>copy</code> or <code>move</code> operations was not a valid folder.
         *       The <code>name</code> argument in <code>list</code>, <code>listBindings</code>, or <code>search</code> operations did not
         *       resolve to a folder.
         * @action Specify a valid folder name.
         * @status documented
         */
        { EXC_NOT_CONTEXT, "The object is not a valid context." },
        /**
         * @error DVT-10309 This operation is not supported.
         * @cause The operation was not supported by the driver in which
         *        the operation was invoked.
         * @action No action is necessary.
         * @status documented
         */
        { EXC_OP_NO_SUPPORT, "This operation is not supported." },
        /**
         * @error DVT-10310 unknown exception
         * @cause An unknown error occurred.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_UNKNOWN, "unknown exception" },
        /**
         * @error DVT-10311 error while adding, removing, or modifying attributes
         * @cause An error has occurred while performing the <code>modifyAttributes</code> operation.
         * @action Check the underlying error stack to find the root cause of the problem.
         * @status documented
         */
        { EXC_ATTR_MOD, "error while adding, removing, or modifying attributes" },
        /**
         * @error DVT-10313 A circular reference is detected.
         * @cause The operation attempted to use aggregated, copied, or moved objects that cause a circular reference.
         * @action If this is a bind or rebind operation, then ensure that no 
         *      circular reference exists in the aggregate tree.
         *      If this is a copy or move operation on a folder, then ensure that 
         *      the parent folder is not copied or moved to the subfolder.
         * @status documented
         */
        { EXC_CIRCULAR_REF, "A circular reference is detected." },
        /**
         * @error DVT-10315 The specified folder path is invalid.
         * @cause An attempt was made to save an object in a folder path that does not exist.
         * @action Specify a valid folder path.
         * @status documented
         */
        { EXC_INVALID_FOLDER, "The specified folder path is invalid." }
    };
}