/*
** Copyright (c) 2007, 2010, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.server.drivers.sba;

// Imports
import oracle.bi.web.soap.internal.SASubjectArea;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Locale;
import java.util.StringTokenizer;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.InitialContext;

import oracle.adf.share.jndi.AdfJndiHelper;

import oracle.bi.presentation.soap.connection.BISoapConnection;
import oracle.bi.presentation.soap.connection.BISoapConnectionFactory;

import oracle.bi.presentation.soap.connection.impl.ConnectionId;

import oracle.dss.connection.common.CB;
import oracle.dss.connection.common.ConnectionException;
import oracle.dss.connection.server.drivers.ConnectionDriver;
import oracle.dss.connection.server.resource.ConnectionServerBundle;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;


/**
 * @hidden
 */
public class SBAConnectionDriverImpl implements ConnectionDriver
{
    private BISoapConnection m_connection;
    private Locale m_locale;
    private Hashtable m_tempHolder = new Hashtable();
    private boolean m_isBootStrappedConn = false;
    private PropertyBag m_properties;

    public boolean isConnected()
    {
        // re-visit this
        return true;
    }

    public PropertyBag connect(PropertyBag properties) throws ConnectionException
    {
        m_properties = properties;
        connect();
        return m_properties;
    }

    public int connect() throws ConnectionException
    {
        if(m_properties != null) {
            if(m_properties.getStrPropertyValue(CB.SOAP) != null)
              return connectBISoap();
/*            
            String _user = m_properties.getStrPropertyValue(CB.USERNAME);
            String _pass = m_properties.getStrPropertyValue(CB.PASSWORD);
            //String _service = m_properties.getStrPropertyValue(CB.SERVICE);
            String _host = m_properties.getStrPropertyValue(CB.HOSTNAME);
            String _port = m_properties.getStrPropertyValue(CB.PORT);
            
            try {
                if(m_properties.getProperty(CB.SAS_JDBC) != null) {
                    String _url = "jdbc:oraclebi://"+ _host + ":" + _port + "/User="+_user + ';'+"Password="+_pass+';';
                    DriverManager.registerDriver(new oracle.bi.jdbc.AnaJdbcDriver());
                    m_sqlConnection = DriverManager.getConnection(_url);
                    //System.out.println(m_sqlConnection.getMetaData().getDriverVersion());
                }
                else {
                    DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
                    m_sqlConnection = DriverManager.getConnection("jdbc:odbc:" + _host, _user, _pass);
                }

            }
            catch(Exception e) {
                throw new ConnectionException(ConnectionServerBundle.class,
                                              ConnectionServerBundle.EXC_INSTANTIATION,
                                              new Object[]{e.getLocalizedMessage()},
                                              m_locale,
                                              e,
                                              getDriverType());
            }
            m_properties.setIntPropertyValue( CB.CONNECTION_STATUS, CB.CONNECTED, MDU.UI_VISIBLE );
*/
        }
        return CB.SUCCESS;
    }

    public int connectBISoap() throws ConnectionException {
      if(m_properties != null) {
        try {
          BISoapConnectionFactory factory = BISoapConnectionFactory.getInstance();
          m_connection = factory.getConnection(new ConnectionId(m_properties.getStrPropertyValue(CB.CONNECTION_STRING)));
          //m_connection.keepAlive(); DRM Code fix remove call
          m_properties.setObjPropertyValue(CB.CONNECTION, m_connection);
        }
        catch (Exception e) {
          try {
            Logger.getLogger("oracle.dss.connection.server.drivers.sba").log(Level.SEVERE, "BISoap connection failed", e);
            InitialContext context = (InitialContext)AdfJndiHelper.createReadOnlyFileSystemContext(m_properties.getStrPropertyValue(CB.SAW_URL));
            m_connection = (BISoapConnection)context.lookup(m_properties.getStrPropertyValue(CB.CONNECTION_STRING));
            //m_connection.keepAlive(); DRM Code fix remove call
            m_properties.setObjPropertyValue(CB.CONNECTION, m_connection);
          }
          catch(Exception e1) {
            Logger.getLogger("oracle.dss.connection.server.drivers.sba").log(Level.SEVERE, "BISoap connection failed", e1);
            throw new ConnectionException(ConnectionServerBundle.class,
                                          ConnectionServerBundle.EXC_INSTANTIATION,
                                          new Object[]{e1.getLocalizedMessage()},
                                          m_locale,
                                          e1,
                                          getDriverType());
          }
        }
        m_properties.setIntPropertyValue( CB.CONNECTION_STATUS, CB.CONNECTED, MDU.UI_VISIBLE );
      }
      return CB.SUCCESS;
    }
/*
    public int connectSoap() throws ConnectionException {
      if(m_properties != null) {
        try {
          String url = m_properties.getStrPropertyValue(CB.SAW_URL) + CB.SOAP_SESSION;
          String user = m_properties.getStrPropertyValue(CB.USERNAME);
          String password = m_properties.getStrPropertyValue(CB.PASSWORD);
          
          String request = SOAPUtility.getRequestHeader("logon") + 
                           SOAPUtility.getParameter("name", user) +
                           SOAPUtility.getParameter("password", password) +
                           SOAPUtility.getRequestFooter("logon");
                           
          String result = SOAPUtility.executeRequest(url, request);
          XMLDocument xmlDoc = SOAPUtility.parseXML(result);
          NodeList nList = xmlDoc.getElementsByTagName("logonResult");
          String sessionID = (nList.item(0).getFirstChild().getFirstChild()).getNodeValue();
          m_properties.setStrPropertyValue(CB.SESSION_ID, sessionID);
          
          request = SOAPUtility.getRequestHeader("keepalive") + 
                    SOAPUtility.getParameter("sessionID", sessionID) +
                    SOAPUtility.getRequestFooter("keepalive");
          result = SOAPUtility.executeRequest(url, request);
        }
        catch(Exception e) {
          throw new ConnectionException(ConnectionServerBundle.class,
                                        ConnectionServerBundle.EXC_INSTANTIATION,
                                        new Object[]{e.getLocalizedMessage()},
                                        m_locale,
                                        e,
                                        getDriverType());
        }
      }
      m_properties.setIntPropertyValue( CB.CONNECTION_STATUS, CB.CONNECTED, MDU.UI_VISIBLE );
      return CB.SUCCESS;
    }
*/
    public int disconnect() throws ConnectionException
    {
        disconnect(null);
        return CB.SUCCESS;
    }

    public PropertyBag disconnect(PropertyBag properties) throws ConnectionException
    {
        if(m_properties.getStrPropertyValue(CB.SOAP) != null)
            return disconnectSoap(properties);
        m_tempHolder.clear();
        m_connection = null;
        m_isBootStrappedConn = false;
        return properties;
    }
    
    public PropertyBag disconnectSoap(PropertyBag properties) throws ConnectionException {
        try {
            m_connection.logoff();
          /*
            String url = m_properties.getStrPropertyValue(CB.SAW_URL) + CB.SOAP_SESSION;
            String sessionID = m_properties.getStrPropertyValue(CB.SESSION_ID);
            String request = SOAPUtility.getRequestHeader("logoff") + 
                             SOAPUtility.getParameter("sessionID", sessionID) +
                             SOAPUtility.getRequestFooter("logoff");
                             
            SOAPUtility.executeRequest(url, request);
          */
        }
        catch(Exception e) {
          
        }
        return properties;
    }
    
    public PropertyBag getConnectionPropertyBag() throws ConnectionException
    {
        return m_properties;
    }

    public String getConnectionString()
    {
        return null;
    }

    public String getDriverType()
    {
        return CB.SBA;
    }

    public String executeCommand(String command, PropertyBag properties) throws ConnectionException
    {
        return null;
    }

    public Object evaluateExpression(String expression, PropertyBag properties) throws ConnectionException
    {
        return null;
    }

    public Object getDriverSpecificObject(PropertyBag properties) throws ConnectionException
    {
        if(properties.getStrPropertyValue(CB.CONNECTION) != null)
            return m_connection;
        return null;
    }

    public int setDriverSpecificObject(Object object, PropertyBag properties) throws ConnectionException
    {
        if(object instanceof Locale)
            m_locale = (Locale)object;
        if(object != null && properties != null)
            m_tempHolder.put(object, properties);
        return MDU.SUCCESS;
    }

    public int removeDriverSpecificObjects(PropertyBag properties) throws ConnectionException
    {
        return CB.SUCCESS;
    }
/*
    public void setSecurityDriverManager(SecurityDriverManager manager)
    {
        m_securityDriverManager = manager;
        return;
    }
*/
    public Object getRemoteConnection()
    {
        return null;
    }

    public void setRemoteConnection(Object remoteConnection)
    {
    }

    public Locale getLocale()
    {
        return m_locale;
    }

    public boolean isAlive()
    {
        return true;
    }

    public PropertyBag getVersionInfo()
    {
        return null;
    }

    public boolean getFeature(String feature)
    {
        return false;
    }
}
