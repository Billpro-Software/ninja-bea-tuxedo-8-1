/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

import java.util.Vector;

import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.LayoutAccess2;
import oracle.dss.util.MetadataMap;

import oracle.dss.selection.OlapQDR;
import oracle.dss.util.StatusInfo;


/**
 * Methods that the QueryBuilder and CalcBuilder beans use to manage changes to
 * <code>selection</code> objects. <code>Selection</code> objects for specific
 * dimensions (along with the layout of the dimensions) provide state for a
 * query-creating component such as the <code>Query</code> object.
 *
 * @status New
 */
public interface QueryEditor extends LayoutAccess2
{
    /**
     * Adds a listener to the listener list
     *
     * @param l The <code>QueryEditorListener</code> to add to the listener
     *          list.
     *
     * @status Documented
     */
    public void addQueryEditorListener(QueryEditorListener l);
 
    /**
     * Removes a listener from the listener list.
     *
     * @param l The <code>QueryEditorListener</code> to remove from the listener
     *          list.
     *
     * @status Documented
     */
    public void removeQueryEditorListener(QueryEditorListener l);    
    
    /**
     * Collapses hierarchical item LOV selections up to their top levels or members.
     * 
     * @param item Item to collapse
     * @param instance Caller-defined ID specifying which of the item instances to collapse.
     * 
     * @return <code>true</code> if successful.
     * 
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
    public boolean collapse(String item, int instance) throws QueryEditorException;
    
    
   /**
     * Expands hierarchical item LOV selections down to their leaf levels or members.
     * 
     * @param item Item to expand
     * @param instance Caller-defined ID specifying which of the item instances to expand.
     * 
     * @return <code>true</code> if successful.
     * 
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
    public boolean expand(String item, int instance) throws QueryEditorException;
    
        
    /**
     * Specifies the full set of DataFilters to be used by this Query.  If filters
     * involves a change to the Query's DataFilters, the Query will refresh.
     *
     * @param filters all DataFilters to be used by the Query
     * @param instance Caller-defined ID specifying which of the item instances to collapse.
     *
     * @throws QueryEditorException thrown if an error occurs, or if data filters are not supported
     * 
     * @status New
     */
    public void setDataFilters(BaseDataFilter[] filters, int instance) throws QueryEditorException;

    /**
     * Returns the full set of DataFilters used by this Query. 
     *
     * @param instance Caller-defined ID specifying which of the item instances to collapse.
     * 
     * @return all data filters used by the Query
     *
     * @status New
     */
    public BaseDataFilter[] getDataFilters(int instance); 

    /**
     * Determine if a given instance has data filters set for it
     *
     * @param instance instance to check
     * @return <code>true</code> if data filters have been set,
     *         <code>false</code> if not
     * @status New
     */
    public boolean isDataFilterSet(int instance);
    
    /**
     * Adds a new data filter to a query
     * @param filter filter to be added to a query
     * @param instance Caller-defined ID specifying which of the item instances to collapse.
     * 
     * @status New
     */
    public void addDataFilter(BaseDataFilter filter, int instance) throws QueryEditorException;
    
    /**
     * Removes a data filter from a query
     * @param filter filter to be removed from a query
     * @param instance Caller-defined ID specifying which of the item instances to collapse.
     * 
     * @status New
     */
    public void removeDataFilter(BaseDataFilter filter, int instance) throws QueryEditorException;
    
    /** 
     * Cleans up the <code>QueryEditor</code> implementation.  Informs the
     * <code>QueryEditor</code> implementation that its user is done and that
     * this implementation will no longer be called or passed as an argument to
     * the <code>applyQueryEditor</code> method.
     *
     * @status Documented
     */
    public void release();    
    
    /**
     * Drills up or down in a specified item�s Selection.  Returns true if the drill succeeds.
     *
     * @param item         The item whose selection should be drilled.
     * @param instance     Caller-defined ID that determines which item Selection to drill.
     * @param value        The item member to be drilled.
     * @param delta        The relative number of levels to traverse within the
     *                     hierarchy that is specified in the item's
     *                     selection (positive numbers drill down, negative
     *                     numbers drill up).
     * @param optimize     <code>true</code> allows the optimization of not
     *                     preserving the steps in a selection;
     *                     <code>false</code> does not allow this optimization.
     *
     * @return  <code>true</code> if the drill succeeds;
     *          <code>false</code> if the drill does not succeed.
     *
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status Documented
     */
    public boolean drill(String item, int instance, String value, int delta, boolean optimize) throws QueryEditorException;
    
    /**
     * Retrieves the <code>DataAccess</code> object for a specified selection.
     *
     * @param selection Specifies the selection to use in the query.
     * @param map Specifies the desired metadata for the resulting
     *            <code>DataAccess</code>.
     *
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection, MetadataMap map) throws QueryEditorException;*/

    /**
     * Retrieves the <code>DataAccess</code> object for a specified selection.
     * 
     * @param selection Specifies the selection to use in the query.
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection);*/

    /**
     * Retrieves the <code>DataAccess</code> object for a specified item (LOV query) and optional set of data filters.
     * 
     * @param item Item for which to run the LOV query
     * @param dataFilters Specifies data filters to use in the LOV query.
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @status Documented
     */
    public DataAccess getDataAccess(String item, BaseDataFilter[] dataFilters);
    
    /**
     * Retrieves a <code>DataAccess</code> object that contains dimension
     * member metadata positioned at the stored selection for the specified
     * item.
     * 
     * @param item         Item for which to get a DataAccess.
     * @param instance     Caller-defined ID that determines which item DataAccess to get.
     * 
     * @return A <code>DataAccess</code> object that contains the specified
     *         item; an empty <code>DataAccess</code> object, which
     *         contains zero values, if there is no selection available to
     *         evaluate.
     *
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
    public DataAccess getDataAccess(String item, int instance) throws QueryEditorException;
        
    /**
     * Retrieves a <code>DataDirector</code> object that maps to a query containing
     * the specified item.
     * 
     * @param item         Item for which to get a DataDirector.
     * @param instance     Caller-defined ID that determines which item query's DataDirector to get.
     * 
     * @return A <code>DataDirector</code> object that maps to a query containing the specified
     *         item; returns <code>null</code> if no Selection is found for the given item.
     *
     * @throws QueryEditorException thrown if an error occurs.
     * 
     * @status New
     */
    public DataDirector getDataDirector(String item, int instance) throws QueryEditorException;
        
    /**
     * Returns a default Selection/Step that the Query would define for the
     * given item.
     *
     * @return A default Selection/Step that the Query would define if none were provided.
     *         Returns null if no default can be defined.
     *
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getDefaultSelection(String item) throws QueryEditorException;*/
    
    /**
     * Return a list of DimensionMembers for a given item/hierarchy containing the 
     * MetadataMap.METADATA_VALUE metadata and the metadata specified in type.
     * 
     * @param item  The item for which to return member metadata.
     * @param instance  Instance ID on which to base any sort of item member values taken from caches.
     * @param hierarchy The hierarchy within item (if any) for which to return member metadata.
     * @param type  A MetadataMap constant that represents the type of member metadata to return
     * @param max   Maximum number of member elements to return.  If -1, return a full set.
     * 
     * @return Vector of DimensionMember objects
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public Vector getValues(String item, int instance, String hierarchy, String type, int max) throws QueryEditorException;
    
    /**
     * Return a list of item member metadata values of the types specified in the types parameter.  
     * Each element in the returned vector represents one item member, and is an array of Objects, 
     * the elements of which correspond one-to-one to the MetadataMap constants in the types parameter.
     * 
     * @param item  The item for which to return member metadata.
     * @param instance  Instance ID on which to base any sort of item member values taken from caches.
     * @param hierarchy The hierarchy within item (if any) for which to return member metadata.
     * @param types  MetadataMap constants representing the types of member metadata values to 
     *               return in each Vector element.
     * @param max   Maximum number of member elements to return.  If -1, return a full set.
     * 
     * @return Vector of Object arrays
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public Vector getValues(String item, int instance, String hierarchy, String[] type, int max) throws QueryEditorException;
    

    /**
     * Retrieves the <code>Selection</code> object that is currently stored for
     * the specified item and instance.
     * 
     * @param item The item for which to return the
     *                  <code>Selection</code> object.
     *        instance  A caller-defined ID for this item's Selection.  A caller can
     *                  store and retrieve multiple Selections for a single item
     *                  using this argument.
     *
     * @return The <code>Selection</code> object that is stored for the
     *         specified dimension and instance; <code>null</code> if there is no
     *         item stored and if the underlying
     *         <code>QueryContext</code> can not provide a selection for the
     *         specified item.
     *
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getSelection(String item, int instance) throws QueryEditorException;       */
    
    /**
     * Stores the specified selection in the selection collection and uses the
     * selection's item as its key at the given instance. These stored selections can be applied
     * to the <code>QueryContext</code> implementor later through the
     * <code>applyQueryEditor</code> method. To retrieve a stored selection,
     * use <code>getSelection(selection.getDimension())</code>.
     * <p>
     * Invoking the <code>setSelection</code> method causes
     * <code>isSelectionSet(selection.getDimension())</code> to return
     * <code>true</code>.
     * 
     * @param sel The selection to store.
     * @param instance  The caller-defined instance ID for the given Selection's item.
     *
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public void setSelection(Selection sel, int instance) throws QueryEditorException;*/
    
   /**
     * Indicates whether a specified item has a selection stored for it
     * in the <code>QueryEditor</code> object.
     *
     * @param item The item to test.
     * @param instance  The instance ID for the item to test.
     *
     * @return <code>true</code> if the item and instance has a selection stored for it,
     *         <code>false</code> if the item and instance does not have a selection
     *         stored for it. Note that whether the underlying
     *         <code>QueryContext</code>
     *         implementation can provide a selection for the specified
     *         dimension does not determine the return value.
     *
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public boolean isSelectionSet(String item, int instance) throws QueryEditorException;   
    
    /**
     * Hides or unhides the given list of items from the current LayoutAccess query's layout.
     * 
     * @param items     The items to show or hide in the layout.
     * @param hide      If <code>true</code> hide the items; if <code>false</code>, show them.
     * 
     * @throws QueryEditorException if an error occurs.
     */
    public void hideItems(String[] items, boolean hide) throws QueryEditorException;
    
    /**
     * Returns an Object indicating support or level of support for 
     * a given capability.  The capability parameter is a set of predefined constants covering capability
     * support that will change with data source type.  These constants will be defined as needed.  
     * Each capability constant will define its expected return value.  See QueryEditorCapabilities.
     *
     * @param capability A predefined capability constant about which to inquire.
     * @param data      Optional object to check against the capability property passed in
     *                  (for example, an inquiry may be made about a capability given a certain metadata ID).
     * 
     * @return Object defined by the capability constant representing the support level for the capability.
     *
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public Object isSupported(int capability, Object data) throws QueryEditorException;
    
    /**
     * Returns an Object indicating the validity of a given object in a given context
     * (validity constant parameter).  The validity parameter will be a set of predefined constants
     * covering different areas of validity checking, as required by the Query Builder.  These constants 
     * will be defined as needed.  Each validity constant will define any expected data parameter, 
     * and will define its expected return value.Example:QueryEditor.VALID_SELECTION: accepts a Selection 
     * data parameter to validate against the current layout state, returns Boolean true or false.
     * 
     * @param validity      A predefined validity constant.
     * @param data          Object on which to inquire about validity.
     * 
     * @return an object representing the validity of the object being checked.
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public Object isValid(String validity, Object data) throws QueryEditorException;
    
    /**
     * Retrieves the name of the measure dimension that is currently used by the
     * <code>QueryAccess</code> object.
     * 
     * @param type One of the enumerated label types in
     *             <code>oracle.dss.util.LayerMetadataMap</code> that specifies
     *             the type of metadata to be returned (such as dimension
     *             database name, short label, long label, etc.).
     *
     * @return The name of the measure dimension in the specified label type.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     * 
     * @throws QueryEditorException thrown if an error occurs.
     *
     * @status Documented
     */
    public String getMeasureItem(String type) throws QueryEditorException;
    
   /**
    * Retrieves the properly initialized <code>OLAPQDR</code> for the specified
    * measure and dimension. This <code>OLAPQDR</code> leaves the following
    * dimensions as varying dimensions:
    * any dimensions on the page edge or on the same edge as the specified
    * dimension; all other dimensions are fixed.
    * <p>
    * Note: An <code>OLAPQDR</code> (qualified data reference) is a reference
    * to a subset of the values in a data source such as the <code>Query</code>
    * object.
    * For example, an <code>OLAPQDR</code> might refer to a Sales measure, but
    * only to those values for the month of May.
    * In another example, an <code>OLAPQDR</code> might refer to a Units measure,
    * but only to the single value that represents the units of TVs sold by
    * catalog in May in Dublin.
    *
    * @param dataItem  The data item to use in initializing the <code>OLAPQDR</code>.
    *                  This data item determines the dimensions to include in the
    *                  fully qualified <code>OLAPQDR</code>.
    * @param type      One of the enumerated label types in
    *                  <code>oracle.dss.util.LayerMetadataMap</code> that
    *                  specifies the type of metadata to be returned (such as
    *                  dimension database name, short label, long label, etc.).
    * @param instance  The instance ID on which to base the QDR's values
    *
    * @return The <code>OlapQDR</code> object initialized with the correct
    *         values for the specified data item.
    *
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
    * 
    * @throws QueryEditorException thrown if an error occurs.
    *
    * @status New
    */
   	public OlapQDR getQDR(String dataItem, String type, int instance) throws QueryEditorException;
   	
   	/**
   	 * Specifies the types of metadata to use for all cursor evaluation.
   	 *
   	 * @param map Set of MetadataMap types for which to return cursor data
     *            when evaluating dimension selections.
     *
   	 * @status Documented
   	 */
   	public void setMetadataMap(MetadataMap map);
    
    /**
     * Fire any pending events from the last QueryEditor call to all listeners.
     * 
     * @return StatusInfo containing status and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo fireEvents() throws QueryEditorException;
    
    
    /**
     * Returns an object that contains progress information (if supported) and contains 
     * an enumerated status constant, and a return value if the call has completed successfully
     * and the call returns a value.
     * 
     * @return StatusInfo containing status, progress information (if supported), and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo getStatus() throws QueryEditorException;
    
    
    /**
     * Must be called to begin execution on an asynchronous QueryEditor.  Returns an object that contains progress information (if supported) and contains 
     * an enumerated status constant, and a return value if the call has completed successfully
     * and the call returns a value.
     * 
     * @return StatusInfo containing status, progress information (if supported), and a return value
     *         for the API call (if relevant).
     * 
     * @throws QueryEditorException if an error occurs.
     * 
     * @status New
     */
    public StatusInfo startExecution() throws QueryEditorException;    

    /**
     * Cancels the current asynchronous QueryEditor operation, if any.
     * 
     * @status New
     */
    public void cancel() throws QueryEditorException;
    
    /**
     * Gets a property from a QueryEditor object.  The supported properties are shown below.
     * The property's values depend on the definition of the property.
     *
     * @param name The name of the property whose value is requested.
     *             Valid property names have constants defined in
     *             DataDirector2 or its extensions. These constants begin with
     *             the prefix PROP_.
     *             Implementations may or may not make use of any
     *             particular property, and their persistence is NOT
     *             guaranteed.
     *
     * @return     The value of the specified property.  Valid values are
     *             determined by the particular property.
     *
     * @see oracle.dss.util.DataDirector2#PROP_ASYNCHRONOUS
     * @see oracle.dss.util.DataDirector2#PROP_AUTO_FIRE_EVENTS
     * 
     * @throws QueryEditorException    If an error occurs getting the
     *                                  specified property.
     * @throws NoSuchPropertyExceptionm If the implementation does
     *                                  not support the given property name.
     *
     * @status New
     */
    public Object getProperty(String name) throws QueryEditorException, oracle.dss.util.xml.NoSuchPropertyException;

    /**
     * Sets a property on a QueryEditor object.  The supported properties are shown below.
     * The property's values depend on the definition of the property.
     *
     * @param name  The name of the property whose value is changing.
     *              Valid property names have constants defined in
     *              DataDirector2 or its extensions. These constants begin with
     *              the prefix PROP_.
     *              Implementations may or may not make use of any
     *              particular property, and their persistence is NOT
     *              guaranteed.
     *
     * @param value A value to apply to the specified property.  Valid
     *              values are determined by the particular property.
     *
     * @see oracle.dss.util.DataDirector2#PROP_ASYNCHRONOUS
     * @see oracle.dss.util.DataDirector2#PROP_AUTO_FIRE_EVENTS
     * 
     * @throws QueryEditorException    If an error occurs setting the
     *                                  specified property.
     * @throws NoSuchPropertyExceptionm If the implementation does
     *                                  not support the given property name.
     *
     * @status New
     */
    public void setProperty(String name, Object value) throws QueryEditorException, oracle.dss.util.xml.NoSuchPropertyException;
        
    /**
     * @hidden
     * Internal metadata type for step source blocks.  Used by the QueryBuilder
     * to access "extra" metadata for the drill call on a Selection.  Optional.
     *
     * @status Documented
     */
    public static final String METADATA_BLOCK = "SourceBlock";
    
    /**
     * @hidden
     * Internal metadata type for query parent information.  Used by the
     * QueryBuilder
     * to access "extra" metadata for the drill call on a Selection.  Optional.
     *
     * @status Documented
     */
    public static final String METADATA_QUERYPARENT = "QueryParent";

    /**
     * @hidden
     * Internal metadata type for determining the number of children a particular
     * member has across an entire hierarchy.  May be used for determining whether
     * a member is a leaf node in a hierarchy.
     *
     * @status New
     */
    public static final String METADATA_CHILDCOUNT = "ChildCount";
}
