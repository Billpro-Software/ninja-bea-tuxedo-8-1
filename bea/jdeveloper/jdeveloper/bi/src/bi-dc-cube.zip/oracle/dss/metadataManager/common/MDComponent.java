/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports

import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.MDU;

/**
 * A component that is stored through the MetadataManager.
 * Normally, an <code>MDComponent</code> wraps a <code>Persistable</code>
 * component, such as a crosstab or a graph, that you want to save through the
 * MetadataManager.
 *
 * @see oracle.dss.util.persistence.Persistable
 *
 * @status documented
 */
/**
 * @hidden
 */
public class MDComponent extends MDObject {

     /**
     *
     * @hidden
     *
     */
    public MDComponent() {
        setObjectType(MM.COMPONENT);
    }

   	/**
     * Constructor.
     *
     * @param mmServices     The <code>MetadataManagerServices</code> that this
     *                       component exists in.
     * @param componentName   Name for this object.
     * @param parent         The folder that contains this component.
     *                       Pass an <code>MDFolder</code>.
     *
     * @see MDFolder
     *
     * @status documented
     */
    public MDComponent( MetadataManagerServices mmServices, String componentName, MDObject parent ) {
        super( mmServices, componentName, parent );
        setObjectType(MM.COMPONENT);
    }

  	/**
     * Retrieves the folder that contains this component.
     *
     * @return The folder that contains this component.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          objects from the server.
     *
     * @status documented
     */
  	public MDFolder getFolder() throws MetadataManagerException {
  		MDObject parent = getParent();
  		if ( (parent != null) && (parent instanceof MDFolder) ) {
  			return (MDFolder)parent;
  		}
  		return null;
  	}
  	
	/**
     * Specifies the folder that contains this component.
     *
     * @param folder The folder that contains this component.
     *
     * @return A constant that represents success or failure.
     * The valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status documented
     */
  	public int setFolder(MDFolder folder) {
  		return setParent(folder);
  	}

     /**
     *
     * @hidden
     *
     */
  	public static MDComponent[] getComponentArray(MDObject[] objects) {
  		if (objects == null)
			return null;
		MDComponent[] components = new MDComponent[objects.length];
		for (int i=0; i<objects.length; i++) {
			components[i] = (MDComponent)objects[i];
		}
		return components;
	}

     /**
     *
     * @hidden
     *
     */
  	public static MDComponent[] getComponentArray(PropertyBag[] propertyBag) {
		if (propertyBag == null)
			return null;
		MDComponent[] components = new MDComponent[propertyBag.length];
		for (int i=0; i<propertyBag.length; i++) {
			components[i] = (MDComponent)propertyBag[i];
		}
		return components;
	}
}