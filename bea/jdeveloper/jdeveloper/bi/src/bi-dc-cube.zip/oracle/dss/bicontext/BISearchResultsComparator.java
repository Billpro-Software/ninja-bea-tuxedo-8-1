/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.bicontext;

import java.text.Collator;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import oracle.dss.util.ErrorHandler;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * Implementation of <code>BIComparator</code> interface.
 * This class is used when comparting (sorting) <code>BISearchResult</code> objects.
 * @status new
 */

public final class BISearchResultsComparator implements BIComparator
{

    // sort based on these attributes
    private String[]     m_sortKeys = null;
    // ascending/descending order for each attribute:
    // true=asc; false=desc
    private boolean[]    m_ascOrderingForKeys = null;
    // flag that indicates whether folders should be clustered together
    // at the beginning or at the end depending on the sorting order of
    // the first attribute in m_sortKeys. Folders go to the beginning of
    // the list by default if this flag is set to true.
    private boolean      m_sepFolders = false;
    // need to keep a Locale message to make language-based comparisons
    private Locale       m_loc = null;
    // all logging messages go to the ErrorHandler
    private ErrorHandler m_eh = null;

    /**
     * Constructor
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     * @param sepFolders <code>true</code> if folders should be separated (clustered)
     *                                     in the returned results
     *                   <code>false</code> if not.
     *
     * see setSortingOptions methods
     * @status new
     */
    public BISearchResultsComparator(String[] keys, boolean sepFolders)
    {
        setSortingOptions(keys);
        setSeparatedFoldersOnSort(sepFolders);
    }

    /**
     * Constructor
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     * @param keyOrderings <code>true</code> if desired comparison order is ascending
     *                     <code>fasle</code> if descending.
     * @param sepFolders <code>true</code> if folders should be separated (clustered)
     *                                     in the returned results
     *                   <code>false</code> if not.
     *
     * see setSortingOptions methods
     * @status new
     */
    public BISearchResultsComparator(String[] keys, boolean keyOrderings, boolean sepFolders)
    {
        setSortingOptions(keys, keyOrderings);
        setSeparatedFoldersOnSort(sepFolders);
    }

    /**
     * Constructor
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     * @param keyOrderings an array of orderings (<code>true</code> if ascending and
     *                     <code>fasle</code> if descending) for each key in
     *                     <code>keyOrderings</code>. The number of elements in
     *                     this array should match the number of elements in
     *                     <code>keyOrderings</code> array.
     * @param sepFolders <code>true</code> if folders should be separated (clustered)
     *                                     in the returned results
     *                   <code>false</code> if not.
     *
     * see setSortingOptions methods
     * @status new
     */
    public BISearchResultsComparator(String[] keys, boolean[] keyOrderings, boolean sepFolders)
    {
        setSortingOptions(keys, keyOrderings);
        setSeparatedFoldersOnSort(sepFolders);
    }

    /**
     * Sets keys (attributes) on which to base object comparisons.
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     *
     * @status new
     */
    public void setSortingOptions(String[] keys)
    {
        // set ascendingOrder to be true by default
        setSortingOptions(keys, true);
    }

    /**
     * Sets keys (attributes) on which to base object comparisons.
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     * @param ascendingOrder <code>true</code> if desired comparison order is ascending
     *                     <code>fasle</code> if descending.
     *
     * @status new
     */
    public void setSortingOptions(String[] keys, boolean ascendingOrder)
    {
        boolean[] orderKeys = null;
        if (keys != null)
        {
            // create an array of sorting orders for each attributes here and
            // fill it with default values: true=ascending order
            orderKeys = new boolean[keys.length];
            Arrays.fill(orderKeys, ascendingOrder);
        }
        setSortingOptions(keys, orderKeys);
    }

    /**
     * Sets keys (attributes) on which to base object comparisons.
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys.
     * @param orderKeys an array of orderings (<code>true</code> if ascending and
     *                  <code>fasle</code> if descending) for each key in
     *                  <code>keyOrderings</code>. The number of elements in
     *                  this array should match the number of elements in
     *                  <code>keyOrderings</code> array.
     *
     * @status new
     */
    public void setSortingOptions(String[] keys, boolean[] orderKeys)
    {
        setSortKeys(keys);
        setKeysAscendingOrdering(orderKeys);
    }

    /**
     * Compares two instances of <code>BISearchResult</code> based on their
     * attributes and sorting order.
     *
     * @param o1 the first object to compare
     * @param o2 the second object to compare
     * @return -1 if o1 precedes o2
     *          0 if the order doesn't change
     *          1 if o1 follows o2
     *
     * This implementation of comparison has the following rules:
     *
     * If the folderOn option is turned on, folders are grouped together separately
     * from the rest of the objects. They come first if the first sorting order key is
     * <code>true</code> (ascending) or last if <code>false</code> (descending).
     *
     * Null attribute values come after non-null values in ascending order.
     *
     * Ascending order is assumed for all missing sorting order keys.
     *
     * @status new
     */
    public int compare(Object o1, Object o2)
    {
        // if no sorting keys are specified, don't sort
        //        if (m_sortKeys == null || m_sortKeys.length == 0)
        //            return 0; // don't change order
        if ((o1 instanceof BISearchResult) && (o2 instanceof BISearchResult))
        {
            BISearchResult r1 = (BISearchResult)o1;
            BISearchResult r2 = (BISearchResult)o2;

            // note that !(a ^ b) gives us true if and only if both a and b are the same values
            // (both are true or false)

            // first, if we want to separate folders, compare if only one is a folder,
            // then put the folder first or last based on the first attribute's order flag;
            // otherwise, proceed comparing objects based on other attributes
            if (m_sepFolders)
            {
                int compFold = compareFolders(r1, r2);
                if (compFold != 0)
                {
                    // if ascending order is sought, return the result of folder comparison;
                    // otherwise, reverse this result to get descending order;
                    // if there are no keys in m_ascOrderingForKeys, assume ascending order by default
                    if ((m_ascOrderingForKeys.length == 0) || m_ascOrderingForKeys[0])
                        return compFold;
                    else return (0 - compFold); // reverse the sign of compFold
                }
            }

            // if no sort keys were specified, compare objects' names
            if (m_sortKeys == null || m_sortKeys.length == 0)
            {
                // object names are strings, so compare using Collator with JVM's Locale
                Collator col = Collator.getInstance(getLocale());
                return col.compare(((BISearchResult)o1).getName(), ((BISearchResult)o2).getName());
            }

            // else: proceed with comparting attributes (both are folders or both are not folders)

            Attributes attrs1 = r1.getAttributes();
            Attributes attrs2 = r2.getAttributes();

            // sort/compare by keys in the appropriate order
            for (int i = 0; i < m_sortKeys.length; i++)
            {
                Attribute atr1 = null;
                Attribute atr2 = null;
                if (m_sortKeys[i] != null && attrs1 != null && attrs2 != null)
                {
                    atr1 = attrs1.get(m_sortKeys[i]);
                    atr2 = attrs2.get(m_sortKeys[i]);
                }

                int compareAttrs = 0;
                if (atr1 == null && atr2 == null)
                    compareAttrs = 0;
                // push objects with null attribute values down
                else if (atr1 == null && atr2 != null)
                    compareAttrs = 1;
                else if (atr2 == null && atr1 != null)
                    compareAttrs = -1;
                // if all attribute names passed as sorting keys are not valid,
                // we'll preserve the original ordering of SearchResults
                else if ((atr1 != null) && (atr2 != null))
                {
                    try
                    {
                        Object atr1Val = atr1.get();
                        Object atr2Val = atr2.get();

                        if (atr1Val == null && atr2Val == null)
                            compareAttrs = 0;
                        // push objects with null attribute values down
                        else if (atr1Val == null && atr2Val != null)
                            compareAttrs = 1;
                        else if (atr2Val == null && atr1Val != null)
                            compareAttrs = -1;
                        else // both atrXVals are not nulls
                        {
                            // compare Strings, Dates, Numbers and Booleans based on their own rules
                            if (atr1Val instanceof String && atr2Val instanceof String)
                            {
                                Collator col = Collator.getInstance(getLocale());
                                compareAttrs = col.compare((String)atr1Val, (String)atr2Val);
                            }
                            else if (atr1Val instanceof Date && atr2Val instanceof Date)
                                compareAttrs = ((Date)atr1Val).compareTo((Date)atr2Val);
                            else if (atr1Val instanceof Number && atr2Val instanceof Number)
                            {
                                double n1 = ((Number)atr1Val).doubleValue();
                                double n2 = ((Number)atr2Val).doubleValue();
                                if (n1 < n2)
                                    compareAttrs = -1;
                                else if (n1 > n2)
                                    compareAttrs = 1;
                                else compareAttrs = 0;
                            }
                            else if (atr1Val instanceof Boolean && atr2Val instanceof Boolean)
                            {
                                boolean b1 = ((Boolean)atr1Val).booleanValue();
                                boolean b2 = ((Boolean)atr2Val).booleanValue();
                                // assume that true comes before false in ascending order
                                if ((b1 == true) && (b2 == false)) // b1 && !b2
                                    compareAttrs = -1;
                                else if ((b1 == false) && (b2 == true)) // b2 && !b1
                                    compareAttrs = 1;
                                else compareAttrs = 0;
                            }
                            else // the attribute has some type other than String, Date or Number
                                 // don't change order
                                compareAttrs = 0;
                            // if they are not equal, return the result
                            // else, proceed comparing other attributes
                            if (compareAttrs != 0)
                            {
                                boolean compAttrs = (compareAttrs < 0 ? true : false);
                                boolean retVal = !(compAttrs ^ m_ascOrderingForKeys[i]);
                                return (retVal ? -1 : 1);
                            }
                        } // else both atrXVals are not nulls
                    } // try
                    catch(NamingException ne) // couldn't get value for specified attribute
                    {
                        if (m_eh != null)
                        {
                            m_eh.log("Unknown attribute for comparison " + m_sortKeys[i] + "... Ignoring.", getClass().getName(), "public int compare(Object o1, Object o2)");
//                            m_eh.error(ne, getClass().getName(), "public int compare(Object o1, Object o2)");
                        }
                    } // catch
                } // if (atr1 != null && atr2 != null)
                if (compareAttrs != 0)
                    return compareAttrs;
            } // for loop
        }
        return 0; // the values are the same (compareAttrs == 0) or
                  // falling through to default: don't change the order
    }

    /**
     * Sets sorting keys to be used for comparison of objects.
     *
     * @param keys an array of <code>String</code> objects that represent sorting keys.
     *             Comparison of two object will be performed based on these keys (attributes).
     *
     * @status new
     */
    public void setSortKeys(String[] keys)
    {
        if (keys == null && m_eh != null)
           m_eh.log("Passed an empty array of sorting attributes. Ignoring a sorting request...", getClass().getName(), "public void setSortKeys(String[] keys)");
        m_sortKeys = keys;
    }

    /**
     * Sets ordering on sorting keys.
     *
     * @param ordering <code>true</code> if desired comparison order is ascending
     *                 <code>fasle</code> if descending.
     *
     * @status new
     */
    public void setKeysAscendingOrdering(boolean ordering)
    {
        if (m_sortKeys == null)
        {
            if (m_eh != null)
                m_eh.log("Array of sorting attributes is empty. Ignoring a sorting request...", getClass().getName(), "public void setKeysAscendingOrdering(boolean ordering)");
            m_ascOrderingForKeys = null;
        }
        else
        {
            // create an array of sorting orders for each attributes here and
            // fill it with "ordering" values
            m_ascOrderingForKeys = new boolean[m_sortKeys.length];
            Arrays.fill(m_ascOrderingForKeys, ordering);
        }
    }


    /**
     * Sets ordering on sorting keys.
     *
     * @param ordering an array of orderings (<code>true</code> if ascending and
     *                 <code>fasle</code> if descending) for each key in
     *                 <code>keyOrderings</code>. The number of elements in
     *                 this array should match the number of elements in
     *                 <code>keyOrderings</code> array.
     *
     * @status new
     */
    public void setKeysAscendingOrdering(boolean[] ordering)
    {
        if (m_sortKeys == null)
        {
            if (m_eh != null)
                m_eh.log("Array of sorting attributes is empty. Ignoring sorting orderings...", getClass().getName(), "public void setKeysAscendingOrdering(boolean[] ordering)");
            m_ascOrderingForKeys = null;
        } // else: m_sortKeys are guaranteed to be not null
        else if (ordering == null)
        {
            if (m_eh != null)
                m_eh.log("Null array of sorting orders; defaulting to ascending order...", getClass().getName(), "public void setKeysAscendingOrdering(boolean[] ordering)");
            setKeysAscendingOrdering(true);
        }
        else
        {
            if(m_sortKeys.length != ordering.length)
            {
                if (m_eh != null)
                {
                    m_eh.log("Cardinalities of arrays of sorting attributes and orderings don't match.", getClass().getName(), "public void setKeysAscendingOrdering(boolean[] ordering)");
                    m_eh.log("Ignoring extra orderings or adding default values (true=asc.) for missing orderings", getClass().getName(), "public void setKeysAscendingOrdering(boolean[] ordering)");
                }
            }
            m_ascOrderingForKeys = new boolean[m_sortKeys.length];
            for (int i = 0; i < m_ascOrderingForKeys.length; i++)
            {
                if (i < ordering.length)
                    m_ascOrderingForKeys[i] = ordering[i];
                else
                    m_ascOrderingForKeys[i] = true; // missing value; default to ascending order
            }
        }
    }

    /**
     * Indicates whether folders should be clustered during sorting.
     *
     * @param sepFolders <code>true</code> if folders should be separated,
     *                   <code>false</code> otherwise.
     *
     * @status new
     */
    public void setSeparatedFoldersOnSort(boolean sepFolders)
    {
        m_sepFolders = sepFolders;
    }

    /**
      * Sets <code>Locale</code>
      *
      * @param l <code>Locale</code> object according to which comparisons will be performed
      *
      * @status new
      */
    public void setLocale(Locale l)
    {
        m_loc = l;
    }

    /**
      * Returns <code>Locale</code>
      *
      * @return <code>Locale</code> object according to which comparisons are performed
      *
      * @status new
      */
    public Locale getLocale()
    {
        return m_loc;
    }

    /**
      * Sets <code>ErrorHandler</code>.
      *
      * @param eh <code>ErrorHandler</code> object
      *
      * @status new
      */
    public void setErrorHandler(ErrorHandler eh)
    {
        m_eh = eh;
    }

    /**
      * Returns <code>ErrorHandler</code>.
      *
      * @return <code>ErrorHandler</code> object
      *
      * @status new
      */
    public ErrorHandler getErrorHandler()
    {
        return m_eh;
    }

    /**
     * @hidden
     */
    private int compareFolders(BISearchResult o1, BISearchResult o2)
    {
        // Get object types of both objects.
        // If they are different, then the one that's a folder comes first.
        String o1Type = o1.getObjectType(),
               o2Type = o2.getObjectType();

        // If one is a folder and the other one is not, return true/false depending on the order.
        if (o1Type.equals(PersistableConstants.FOLDER) && !o2Type.equals(PersistableConstants.FOLDER))
            return -1;
        if (o2Type.equals(PersistableConstants.FOLDER) && !o1Type.equals(PersistableConstants.FOLDER))
            return 1;
        // if both are folders and no sorting keys were specified, sort based on names
        if (o2Type.equals(PersistableConstants.FOLDER) && o1Type.equals(PersistableConstants.FOLDER) &&
            (m_sortKeys == null || m_sortKeys.length == 0))
        {
            // object names are strings, so compare using Collator with JVM's Locale
            Collator col = Collator.getInstance(getLocale());
            return col.compare(o1.getName(), o2.getName());
        }
        // Else neither is a folder or both are folders and sorting keys are specified.
        return 0;


    }
}
