/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.directory.SearchResult;

import javax.swing.tree.TreeNode;

import oracle.dss.bicontext.gui.DefaultDirTreeNode;

import oracle.dss.util.persistence.AggregateInfo;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 * Custom tree node for Persistable objects that are exposed as expandable tree node.
 * For example, Workbook, Worksheet, DataFrame object types
 */
public class PersistableTreeNode extends DefaultDirTreeNode
{
    private Persistable m_persistable;

    /**
     * Constructor for Persistable object whose parent is a non-Persisable object
     */
    public PersistableTreeNode(Hashtable env, SearchResult result)
    {
        super(env, result); 
    }
    
    /**
     * Constructor for Persistable object whose parent is also a Persistable object
     */
    public PersistableTreeNode(Hashtable env, Persistable persistable)
    {
        super();
        setEnvironment(env);
        m_persistable = persistable;
    } 

    /**
     * Override parent class to support Persistable objects
     * @return
     */
    public boolean isLeaf()
    {
        if (m_persistable != null)
        {
            if (m_persistable.getPersistableComponents() != null && m_persistable.getPersistableComponents().length > 0)
                return false;
        }
        else
        {        
            if ("Workbook".equals(getObjectType()))
                return false;
        }
        
        return true;
    }

    /**
     * Override parent class to support Persistable objects
     * @return the name of the object
     */
    public String getName()
    {
        // Special case for Workbook Builder.  The name of the sub-objects are stored in title.
        // note that objects in ET model also uses title to store metadata name.
        if (m_persistable != null)
            return m_persistable.getPersistableAttributes(null).getTitle();
        else
            return super.getName();
    }

    /**
     * Returns the Persistable object held by the tree node
     * @return
     */
    public Persistable getPersistable()
    {
        return m_persistable;
    }

    /**
     * Override parent class to support Persistable objects
     * @return the object type
     */
    public String getObjectType()
    {
        if (m_persistable != null)
        {
            // workaround now for PresentationModel objects.
            // the actual object type (Graph, Crosstab, etc.) is stored in CompSubType1 attribute
            String _type = m_persistable.getPersistableAttributes(null).getObjectType();
            String _compSubType1 = m_persistable.getPersistableAttributes(null).getCompSubType1();
            if ("oracle.bi.app.builder.document.PresentationModel".equals(_type) && _compSubType1 != null)
                return mapType(_compSubType1);                
            else
                return _type;
        }
        else
            return super.getObjectType();
    }

    /**
     * Override DefaultDirTreeNode method to support workbook and worksheet drilling
     */
    protected Vector getChildren()
    {
        Vector _results = new Vector(50);
        
        TreeNodeFactory _factory = (TreeNodeFactory)getEnvironment().get(DefaultDirTreeNode.NODEFACTORY);
        if (!(_factory instanceof PersistableTreeNodeFactory))
            return super.getChildren();
            
        PersistableTreeNodeFactory _pFactory = (PersistableTreeNodeFactory)_factory;
        try
        {
            if (m_persistable != null)
            {
                AggregateInfo[] _infos = m_persistable.getPersistableComponents();

                // this is a special case for Workbook Builder
                // when the dataframe contains only one view, that view would be attach to the worksheet node instead
                // (i.e. no dataframe would be shown)
                if ("oracle.bi.app.builder.document.WorksheetModel".equals(m_persistable.getPersistableAttributes(null).getObjectType()))
                {
                    // only one view in dataframe?
                    for (int i=0; i<_infos.length; i++)
                    {               
                        Persistable _persistable = _infos[i].getPersistable();
                        if ("oracle.bi.app.builder.document.FrameModel".equals(_persistable.getPersistableAttributes(null).getObjectType()))
                        {
                            AggregateInfo[] _views = _persistable.getPersistableComponents();
                            ArrayList _persistables = new ArrayList(_views.length);

                            for (int j=0; j<_views.length; j++)
                            {
                                Persistable _presentation = _views[j].getPersistable();
                                if ("oracle.bi.app.builder.document.PresentationModel".equals(_presentation.getPersistableAttributes(null).getObjectType()) && isViewObject(_presentation.getPersistableAttributes(null).getCompSubType1()))
                                    _persistables.add(_presentation);
                            }

                            TreeNode _node = null;
                            if (_persistables.size() == 1)
                                _node = _pFactory.createTreeNode(getEnvironment(), (Persistable)_persistables.get(0));
                            else if (_persistables.size() > 1)
                                _node = _pFactory.createTreeNode(getEnvironment(), _persistable);

                            if (_node != null)
                                _results.add(_node);                                
                        }
                    }
                }
                else
                {
                    for (int i=0; i<_infos.length; i++)
                    {
                        Persistable _persistable = _infos[i].getPersistable();                            
                        TreeNode _node = _pFactory.createTreeNode(getEnvironment(), _persistable);
                        if (_node != null)
                            _results.add(_node);
                    }                                    
                }
            }
            else
            {
                SearchResult _result = getSearchResult();
                Object _obj = _result.getObject();
                Persistable _persistable = (Persistable)_obj;
    
                AggregateInfo[] _infos =_persistable.getPersistableComponents();
                for (int i=0; i<_infos.length; i++)
                {
                    Persistable _aggr = _infos[i].getPersistable();
                    if (_factory instanceof PersistableTreeNodeFactory)
                    {
                        TreeNode _node = _pFactory.createTreeNode(getEnvironment(), _aggr);
                        if (_node != null)
                            _results.add(_node);
                    }
                }
            }
        }
        catch (Exception ne)
        {
            getErrorHandler().error(ne, getClass().getName(), "getChildren");
        }
        return _results;
    }

    /**
     * Persistable tree nodes are not draggable by default
     * @return
     */
    public boolean isDraggable()
    {
        if (m_persistable != null)
            return false;
        else
            return true;
    }

    public boolean isEditable()
    {
        if (m_persistable != null)
            return false;
        else
            return true;
    }

    public String getID()
    {
        if (m_persistable != null)
            return "PERSISTABLE";
        else
            return "CATALOG";
    }

    private boolean isViewObject(String compSubType1)
    {
        String _type = mapType(compSubType1);
        if (PersistableConstants.CROSSTAB.equals(_type) ||
            PersistableConstants.GRAPH.equals(_type) ||
            PersistableConstants.TABLE.equals(_type))
            return true;
        else
            return false;
    }

    /**
     * @hidden
     * helper method to convert between PresentationType.ENUM to PersistableConstants    
     * @param compSubType1
     * @return
     */
    public static String mapType(String compSubType1)
    {
        if (PersistableConstants.CROSSTAB.toUpperCase().equals(compSubType1))
            return PersistableConstants.CROSSTAB;
        else if (PersistableConstants.GRAPH.toUpperCase().equals(compSubType1))
            return PersistableConstants.GRAPH;
        else if (PersistableConstants.TABLE.toUpperCase().equals(compSubType1))
            return PersistableConstants.TABLE;
        else
            return compSubType1;
    }
}