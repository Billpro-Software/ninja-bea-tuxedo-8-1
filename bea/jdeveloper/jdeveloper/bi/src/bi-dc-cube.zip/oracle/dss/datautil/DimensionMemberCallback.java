/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

/**
 * An interface that gives an application the ability to short-circuit queries
 * run to obtain DimensionMembers by providing the DimensionMembers itself.
 *
 * @hidden
 */
public interface DimensionMemberCallback {
  /**
   * Returns an array of DimensionMembers at the specified dimension, hierarchy,
   * and level.  If the dimension is a list dimension, the hierarchy and level
   * arguments will be null.  If the dimension is hierarchical, the hierarchy
   * argument must be non-null.  If the specified hierarchy is value-based, the
   * level argument will be null.  If the specified hierarchy has named levels,
   * the level argument must be non-null.
   * 
   * @param dimension The dimension from which to return <code>DimensionMembers</code>
   * @param hierarchy The hierarchy from which to return <code>DimensionMembers</code>
   * if the specified dimension is hierarchical.
   * @param level The level from which to return <code>DimensionMembers</code> if the
   * specified hierarchy has named levels.
   * @param strDisplayMemberLabelType The labeltype that should be used for the display
   * names in the return <code>DimensionMembers</code>
   * @param count The maximum number of the <code>DimensionMembers</code> to return.
   * If there are fewer than <code>count</code> members at the specified dimension, 
   * hierarchy, and level, only those members should be returned.
   * @return An array of at most <code>count</coode> <code>DimensionMembers</code>.
   */
  public DimensionMember[] getDimensionMembers(String dimension,
                                               String hierarchy,
                                               String level,
                                               String strDisplayMemberLabelType, 
                                               int count);
}