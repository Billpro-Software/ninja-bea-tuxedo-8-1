/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.EventListener;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SingleSelectionModel;

/**
 * @hidden
 * The component allows users to display a popup menu with sticky 
 * and non sticky items.
 *
 * @status hidden
 */

public class BuilderPopupMenu extends JPopupMenu 
                              implements CustomList
{
    //-------------------------------------------------------------------
    // PUBLIC CONSTANTS
    //-------------------------------------------------------------------
    
    /**
     * The "more" sticky item.
     *
     * @status hidden
     */
    public static final String STICKYITEM_MORE = "more";

    /**
     * The "qualify" sticky item.
     *
     * @status hidden
     */
    public static final String STICKYITEM_QUALIFY = "qualify";

    //-------------------------------------------------------------------
    // NON PUBLIC CONSTANTS
    //-------------------------------------------------------------------
    
    /**
     * The default count for the non sticky item list
     *
     * @status private
     */
    private static final int NONSTICKYITEM_DEFCOUNT = 4;
    
    //-------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-------------------------------------------------------------------

    /**
     * A default menu item listener.
     *
     * @status private
     */
    private CustomMenuItemListener m_menuItemListener = new CustomMenuItemListener ( );
    
    /**
     * The count of non sticky items in the popup menu
     *
     * @status private
     */
    private int m_nNonStickyItemCount = -1;
    
    /**
     * The last selected object in the pop up menu
     *
     * @status private
     */
    private Object m_lastSelectedObject = null;

    /**
     * The non sticky objects in the popup menu
     *
     * @status private
     */
    private Vector m_listNonStickyItems = null;

    /**
     * The sticky objects in the popup menu
     *
     * @status private
     */
    private Vector m_listStickyItems = null;

    private Locale m_locale = null;
    //-------------------------------------------------------------------
    // CONSTRUCTORS
    //-------------------------------------------------------------------

    /**
     * Default constructor.
     *
     * @status hidden
     */
    public BuilderPopupMenu ( )
    {
        super ( );
        
        initializeMembers ( );
    }            
        
    //-------------------------------------------------------------------
    // PUBLIC METHODS
    //-------------------------------------------------------------------

    public void setLocale(Locale locale) {
      m_locale = locale;
    }
    
    /**
     * @hidden
     * Checks if the item can be added to the popup menu
     * 
     * @status hidden
     */
    public boolean canAddItemToMenu ( Vector listDefContents, Object item )
    {                                       
        String defaultItem = null;
        
        if ( null == listDefContents )
            return false;
            
        defaultItem = isValidDefaultItem ( item );
        if ( null == defaultItem )
            return false;
        
        if ( defaultItem.equalsIgnoreCase ( STICKYITEM_QUALIFY ) )
        {   
            return true;
        }
        else if ( defaultItem.equalsIgnoreCase ( STICKYITEM_MORE ) )
        {   // Add the more item only if the the default list contains more elements
            // than the non sticky elements count.
            if ( getNonStickyItemCount ( ) >= listDefContents.size ( ) )
                return false;
                
            return true;                
        }
        
        return false;
    }
    
    /**
     * @hidden
     * Flush the contents of the popup menu
     *   
     * @status hidden
     */
    public void flushContents ( )
    {
        removeAll ( );
        
        if ( m_listNonStickyItems != null && 
             m_listNonStickyItems.size ( ) > 0 )
        {             
             m_listNonStickyItems.removeAllElements ( );
        }
        
        if ( m_listStickyItems != null && 
             m_listStickyItems.size ( ) > 0 )
        {             
             m_listStickyItems.removeAllElements ( );
        }             
    }
    
    /**
     * @hidden
     * Returns the user object of the selected item.
     *   
     * @return Return the user object of the selected item.
     *
     * @status hidden
     */
    public Object getSelectedItem ( )
    {
        return m_lastSelectedObject;
    }
    
    /**
     * @hidden
     * Initialize the contents of the popup menu.
     *   
     * @return Return the id of the selected item.
     *
     * @status hidden
     */
    public void initializeContents ( )
    {
        removeAll ( );
        
        addContents ( m_listStickyItems, CustomList.CUSTOMLIST_ITEMPOS_NORTH );
        addContents ( m_listNonStickyItems, CustomList.CUSTOMLIST_ITEMPOS_DEFAULT );
        addContents ( m_listStickyItems, CustomList.CUSTOMLIST_ITEMPOS_SOUTH );
        if ( getItemCount ( m_listStickyItems, 
                            CustomList.CUSTOMLIST_ITEMPOS_DEFAULT ) > 0 )
        {
            addSeparator ( );
            addContents ( m_listStickyItems, CustomList.CUSTOMLIST_ITEMPOS_DEFAULT );
        }            
    }
    
    /**
     * @hidden
     * Initialize the members of the object.
     *   
     * @status hidden
     */
    public String isValidDefaultItem ( Object item )
    {
        if ( null == item ||
             ! ( item instanceof String ) )
            return null;
        
        if ( ( ( String ) item ).equalsIgnoreCase ( STICKYITEM_MORE ) || 
             ( ( String ) item ).equalsIgnoreCase ( STICKYITEM_QUALIFY ) )
            return ( String ) item;
            
        return null;
    }
    
    //-------------------------------------------------------------------
    // Start implementation of CustomList interface
    //-------------------------------------------------------------------

    /**
     * @hidden
     * Adds an item of specified type to the list. Registers the listener 
     * with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param itemType The type of the item.
     * @param listener The listener for the item. This implementation disregards
     * the listener parameter.
     *
     * @status hidden
     */
    public boolean addItem ( Object anObject, int itemType, EventListener listener )
    {
        return addItem ( anObject, itemType, 
                         CustomList.CUSTOMLIST_ITEMPOS_DEFAULT, listener );
    }
    
    /**
     * @hidden
     * Adds an item of specified type to the list. Registers the listener 
     * with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param itemType The type of the item.
     * @param itemPosition The relative position of the item
     * @param listener The listener for the item.
     *
     * @status hidden
     */
    public boolean addItem ( Object anObject, int itemType, 
                             int itemPosition, EventListener listener )
    {
        BuilderPopupMenuItem    menuItem    = null;
        String                  defaultItem = null, strItemName = null;
        
        // Validation...
        if ( null == anObject || itemType < 0 )
            return false;
            
        if ( listener != null && 
             ! ( listener instanceof ActionListener ) )
            return false;
            
        if ( CustomList.CUSTOMLIST_STICKYITEM == itemType )
        {
            defaultItem = isValidDefaultItem ( anObject );
            if ( defaultItem != null )
            {
                if ( defaultItem.equalsIgnoreCase ( STICKYITEM_MORE ) )
                    strItemName = Utils.getIntlString ( "moreItem", m_locale );
                else if ( defaultItem.equalsIgnoreCase ( STICKYITEM_QUALIFY ) )
                    strItemName = Utils.getIntlString ( "qualifyItem", m_locale );
            }                
            else
            {
                strItemName = anObject.toString ( );
            }

            menuItem = new BuilderPopupMenuItem ( strItemName, anObject, itemPosition );
            menuItem.addActionListener ( ( ActionListener ) listener );
            
            m_listStickyItems.addElement ( menuItem );
        }            
        else if ( CustomList.CUSTOMLIST_NONSTICKYITEM == itemType )
        {
            if ( m_nNonStickyItemCount != -1 && 
                 m_listNonStickyItems.size ( ) >= m_nNonStickyItemCount )
                return false;
              
            menuItem = new BuilderPopupMenuItem ( anObject.toString ( ), 
                                                  anObject, itemPosition );
            menuItem.addActionListener ( ( ActionListener ) listener );
            
            m_listNonStickyItems.addElement ( menuItem );
        }            
        
        return true;
    }
    
    /**
     * @hidden
     * Returns the count of non sticky items in the list.
     *   
     * @return The count of non sticky items in the list.
     *
     * @status hidden
     */
    public int getNonStickyItemCount ( )
    {
        return m_nNonStickyItemCount;
    }
    
    /**
     * @hidden
     * Replaces one item in the non sticky group with the specified item. Registers
     * the listener with the item.
     *   
     * @param anObject The user object to associate with the item.
     * @param listener The listener for the item. This should be an ActionListener.
     *
     * @status hidden
     */
    public void replaceNonStickyItem ( Object anObject, EventListener listener )
    {
        BuilderPopupMenuItem    menuItem    = null;
        int                     nIndex      = -1, nExtraItemCount = -1;
        
        if ( null == anObject )
            return;
        
        if ( listener != null && ! ( listener instanceof ActionListener ) )                    
            return;
            
        menuItem = new BuilderPopupMenuItem ( anObject.toString ( ), 
                                              anObject, CustomList.CUSTOMLIST_ITEMPOS_DEFAULT );
        m_listNonStickyItems.insertElementAt ( menuItem, 0 );
        if ( -1 == m_nNonStickyItemCount )
            return;
            
        if ( m_listNonStickyItems.size ( ) > m_nNonStickyItemCount )
        {
            nExtraItemCount = m_listNonStickyItems.size ( ) - m_nNonStickyItemCount;
            for ( nIndex = 0; nIndex < nExtraItemCount; nIndex++ )
                m_listNonStickyItems.removeElementAt ( m_listNonStickyItems.size ( ) - 1 );
        }
        
        // Re-initialize the contents of the popup menu here
        initializeContents ( );
    }
    
    /**
     * @hidden
     * Specifies the count of non sticky items in the list.
     *   
     * @param itemCount The count of non sticky items in the list.
     *
     * @status hidden
     */
    public void setNonStickyItemCount ( int itemCount )
    {
        m_nNonStickyItemCount = itemCount;
    }
    
    //-------------------------------------------------------------------
    // End implementation of CustomList interface
    //-------------------------------------------------------------------

    //-------------------------------------------------------------------
    // NON PUBLIC METHODS
    //-------------------------------------------------------------------

    /**
     * Adds content to the popup menu
     *   
     * @status private
     */
    private void addContents ( Vector listItems, int nPositionFilter )
    {
        BuilderPopupMenuItem    menuItem    = null;
        int                     nIndex      = -1;
        
        if ( null == listItems )
            return;
            
        for ( nIndex = 0; nIndex < listItems.size ( ); nIndex++ )
        {
            menuItem = ( BuilderPopupMenuItem ) listItems.elementAt ( nIndex );
            if ( null == menuItem )
                continue;
            
            if ( nPositionFilter == menuItem.getItemPosition ( ) )
            {
                // Hook up the menu item listener
                menuItem.addActionListener ( m_menuItemListener );
                add ( menuItem );
            }                
        }            
    }
    
    /**
     * Retrieves the count of the items with the position filter in the 
     * list.
     *   
     * @status private
     */
    private int getItemCount ( Vector listItems, int nPositionFilter )
    {
        BuilderPopupMenuItem    menuItem    = null;
        int                     nIndex      = -1, nCount = -1;
        
        if ( null == listItems )
            return -1;
            
        nCount = 0;            
        for ( nIndex = 0; nIndex < listItems.size ( ); nIndex++ )
        {
            menuItem = ( BuilderPopupMenuItem ) listItems.elementAt ( nIndex );
            if ( null == menuItem )
                continue;
            
            if ( nPositionFilter == menuItem.getItemPosition ( ) )
            {
                nCount++;
            }                
        }      
        
        return nCount;
    }
    
    /**
     * Initialize the members of the object.
     *   
     * @status private
     */
    private void initializeMembers ( )
    {
        m_nNonStickyItemCount = NONSTICKYITEM_DEFCOUNT;

        m_listNonStickyItems = new Vector ( );
        m_listStickyItems = new Vector ( );
    }
    
    //-------------------------------------------------------------------
    // Inner Classes
    //-------------------------------------------------------------------
    
    /**
     * The menu item for a builder popup menu.
     *   
     * @status private
     */
    private class BuilderPopupMenuItem extends JMenuItem
    {
        private int     m_nItemPosition = -1;
        private Object  m_userObject    = null;    
        
        public BuilderPopupMenuItem ( String text, 
                                      Object userObject, 
                                      int nItemPosition )
        {
            super ( text );
            
            m_userObject = userObject;
            m_nItemPosition = nItemPosition;
        }            
        
        public int getItemPosition ( )
        {
            return m_nItemPosition;
        }
        
        public Object getUserObject ( )
        {
            return m_userObject;
        }            
    }
    
    private class CustomMenuItemListener implements ActionListener
    {
        public void actionPerformed ( ActionEvent event )
        {
            Object source = null;
            
            source = event.getSource ( );
            if ( source != null && ! ( source instanceof BuilderPopupMenuItem ) )
                return;
                
            m_lastSelectedObject = ( ( BuilderPopupMenuItem ) source ).getUserObject ( );
        }
    }
}
    