/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.QDR;

/**
 * Base class for cell override events.
 *
 * @status Documented
 */
public abstract class CellOverrideEvent extends QueryEvent
{

/**
 * Constructor for this class.
 *
 * @param source  The source of the event, that is, the object that fired the
 *                event.
 * @param row     The row of the cell that was edited.
 * @param col     The column of the cell that was edited.
 * @param page    The page of the cell that was edited.
 * @param data    The new data in the cell that was edited.
 * @param qdr     The QDR object that represents the cell that was edited.
 *
 * @status Documented
 */
    public CellOverrideEvent(Object source, long row, long col, long page, Object data, QDR qdr)
    {
        super(source);
        m_row = row;
        m_col = col;
        m_page = page;
        m_qdr = qdr;
        m_data = data;
    }

/**
 * Retrieves the QDR object that represents the cell that was edited.
 *
 * @status Documented
 */
    public QDR getQDR ()
    {
        return m_qdr;
    }

/**
 * Retrieves the row of the cell that was edited.
 *
 * @status Documented
 */
    public long getRow()
    {
        return m_row;
    }

/**
 * Retrieves the column of the cell that was edited.
 *
 * @status Documented
 */
    public long getCol()
    {
        return m_col;

    }

/**
 * Retrieves the page of the cell that was edited.
 *
 * @status Documented
 */
    public long getPage()
    {
        return m_page;
    }

/**
 * Retrieves the new data in the cell that was edited.
 *
 * @status Documented
 */
    public Object getData()
    {
        return m_data;
    }

    /**
     * @hidden
     */
    protected QDR m_qdr;

    // the column number of the data cell
    /**
     * @hidden
     */
    protected long m_col;

    // the row number of the data cell
    /**
     * @hidden
     */
    protected long m_row;

    // the page number of hte data cell
    /**
     * @hidden
     */
    protected long m_page;

    // the new data of the cell, should be a string
    /**
     * @hidden
     */
    protected Object m_data;

}