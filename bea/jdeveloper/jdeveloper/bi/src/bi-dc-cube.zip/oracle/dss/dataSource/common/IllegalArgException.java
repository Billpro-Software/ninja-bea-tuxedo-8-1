/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if the caller passes in a bad argument to the Query API.
 *
 * @status Documented
 */
public class IllegalArgException extends QueryException
{
    /**
     * @hidden
     * @serial Illegal argument number
     */
    protected int m_argNum = 0;
    
    /**
     * @hidden
     * @serial Illegal argument value
     * Note throwers of this exception must make sure that the value they
     * pass can be serialized!
     */
    protected Object m_argVal = null;
    
    /**    
     * Constructor.
     *
     * @param s      Message to display.
     * @param argNum Argument number that was illegal, starting with 1.
     * @param argVal Argument value that was illegal.
     *
     * @status Documented
     */
    public IllegalArgException(String s, int argNum, Object argVal)
    {
        super(s, null);
        m_argNum = argNum;
        m_argVal = argVal;
    }
    
    /**
     * Retrieves the illegal argument number.
     *
     * @return The illegal argument number.
     *
     * @status Documented
     */
    public int getIllegalArgNumber()
    {
        return m_argNum;
    }
    
    /**
     * Retrieves the illegal argument value.
     *
     * @return The illegal argument value.
     *
     * @status Documented
     */
    public Object getIllegalArgValue()
    {
        return m_argVal;
    }
    
    /**
     * Retrieves this exception's message.
     *
     */
    public String getMessage()
    {
        return super.getMessage() + ": Argument " + m_argNum + " with value " + m_argVal;
    }
}