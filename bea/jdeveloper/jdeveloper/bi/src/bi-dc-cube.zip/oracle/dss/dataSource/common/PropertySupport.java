/*
** Copyright (c) 2007, 2008, Oracle and/or its affiliates. All rights reserved.
**
*/
package oracle.dss.dataSource.common;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import oracle.dss.util.DataDirector;
import oracle.dss.util.HierarchicalQDR;
import oracle.dss.util.Utility;
import oracle.dss.selection.OlapQDR;
import oracle.dss.util.QDR;

import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.PropertyNode;
import oracle.dss.util.xml.NoSuchPropertyException;

/**
 * @hidden
 * This class is aggregated by the top level classes and supports the
 * property get/set mechanisms.
 */
public class PropertySupport extends Object implements java.io.Serializable, Cloneable, XMLizable
{
    /**
     * @hidden
     * Table of defaults
     * 
     */
    protected Object[][] m_defaultTable = new Object[][]
                                            {{QueryConstants.PROPERTY_IS_SELF_CALC_TOTALS, new Boolean(QueryConstants.DEFAULT_IS_SELF_CALC_TOTALS)},
                                             {QueryConstants.PROPERTY_DEBUG_MODE, new Boolean(QueryConstants.DEFAULT_DEBUG_MODE)},
                                             {QueryConstants.PROPERTY_PRINT_QUERY_STATE, new Boolean(QueryConstants.DEFAULT_PRINT_QUERY_STATE)},
                                             {QueryConstants.PROPERTY_ALLOW_DIVIDE_BY_ZERO, new Boolean(QueryConstants.DEFAULT_ALLOW_DIVIDE_BY_ZERO)},
                                             {QueryConstants.PROPERTY_VALUE_ONLY, new Boolean(QueryConstants.DEFAULT_VALUE_ONLY)},
                                             {QueryConstants.PROPERTY_SQL_TYPE, new Long(QueryConstants.DEFAULT_SQL_TYPE)},
                                             {QueryConstants.PROPERTY_AUTO_SUBMIT, new Boolean(QueryConstants.DEFAULT_AUTO_SUBMIT)},
                                             {QueryConstants.PROPERTY_AUTO_FIRE_EVENTS, new Boolean(QueryConstants.DEFAULT_AUTO_FIRE_EVENTS)},
                                             {QueryConstants.PROPERTY_ASYNCHRONOUS, new Boolean(QueryConstants.DEFAULT_ASYNCHRONOUS)},
                                             {QueryConstants.PROPERTY_TABULAR_QUERY, new Boolean(QueryConstants.DEFAULT_TABULAR_QUERY)},
                                             {QueryConstants.PROPERTY_OUTLINE, new Boolean(QueryConstants.DEFAULT_OUTLINE)},
                                             {QueryConstants.PROPERTY_DRILL_MEMBERS_ABOVE, new Boolean(QueryConstants.DEFAULT_DRILL_MEMBERS_ABOVE)},
                                            };
    protected static final int PROP_NAME = 0;
    protected static final int DEFAULT_VALUE = 1;
            
    /**
     * @serial Bound property support
     */
    protected transient PropertyChangeSupport   boundSupport;
    
    /**
     * Constructor.
     *
     * @param obj the object that participates in bean's property support
     * notification.
     */
    public PropertySupport(Object obj)
    {
        super();

        suppression = _initSuppression();
        
        setUpBoundSupport(obj);
    }

    protected void setUpBoundSupport(Object obj)
    {
        boundSupport = new PropertyChangeSupport(obj);
    }

    private Vector _initSuppression()
    {
        // Initialize suppression defaults
        Vector tempsuppression = new Vector();
        // Three edges to start, all cleared bits
        Integer tempEdge;
        for (int i = 0; i < 3; i++) {
            tempEdge = new Integer(DataDirector.NO_SUPPRESSION);
            tempsuppression.addElement(tempEdge);
        }      
        
        return tempsuppression;
    }
    


	// Return a brand-new copy of the suppression property
    protected Vector cloneSuppression()
	{
		return cloneSuppression(suppression);
	}

    // Return a brand-new copy of the given suppression property
    protected Vector cloneSuppression(Vector oldSuppression)
	{
        Vector newSuppression = null;

		if (oldSuppression != null)
		{
			newSuppression = new Vector();
        	for (int i = 0; i < oldSuppression.size(); i++)
			{
            	newSuppression.addElement(new Integer(((Integer)oldSuppression.elementAt(i)).intValue()));
			}
        }
        else
        {
            newSuppression = _initSuppression();          
        }

        return newSuppression;
    }

    /**
     * Indicate that all operations should be sent to the middle tier for processing
     * immediately.
     *
     * @param b send all operations immediately if <code>true</code>
     */
    public void setAutoUpdate(boolean b) {
        Boolean oldValue = new Boolean(isAutoUpdate());
        autoUpdate = b;

        firePropertyChange("AutoUpdate", oldValue, new Boolean(b));
        if(oldValue != b)
          defaultChanged = true;
    }

    /**
     * Are all operations immediately sent to the middle tier?
     *
     * @return <code>true</code>if operations are sent immediately
     */
    public boolean isAutoUpdate() {
        return autoUpdate;
    }

    /**
     * Determine the suppression (NA/zero) when data is fetched.
     *
     * @param index edge of interest
     * @param suppress description of what to suppress
     * @throws ArrayIndexOutOfBoundsException thrown if index is invalid
     */
    public void setSuppressionState(int index, int suppress) throws ArrayIndexOutOfBoundsException {
        if (index < 0) {
            throw new ArrayIndexOutOfBoundsException();
        }

        Vector oldValue = cloneSuppression();

        if (suppression == null) {
            // Initialize if necessary
            suppression = new Vector();
        }

        // Grow the list if not big enough
        if (index >= suppression.size()) {
            suppression.setSize(index+1);
        }

        suppression.setElementAt(new Integer(suppress), index);

        firePropertyChange("SuppressionState", oldValue, suppression);
    }

    /**
     * Return the suppression state (NA/zero)
     *
     * @param index edge of interest
     * @return current suppression state
     * @throws ArrayIndexOutOfBoundsException thrown if index is invalid
     */
    public int getSuppressionState(int index) throws ArrayIndexOutOfBoundsException {
        if (index < 0 || index >= suppression.size()) {
            throw new ArrayIndexOutOfBoundsException();
        }

        return ((Integer)suppression.elementAt(index)).intValue();
    }

    /**
     * Determine the suppression (NA/zero) when data is fetched.
     *
     * @param suppress description of what to suppress
     */
    public void setSuppressionState(int[] suppress) {
        suppression = new Vector();
        for (int i = 0; i < suppress.length; i++) {
            suppression.addElement(new Integer(suppress[i]));
        }
    }

    /**
     * Return the suppression state (NA/zero)
     *
     * @return current suppression state
     */
    public int[] getSuppressionState() {
        int[] temp = new int[suppression.size()];
        for (int edge = 0; edge < temp.length; edge++)
        {
            Integer edgeVal = (Integer)suppression.elementAt(edge);
            if (edgeVal != null)
            {
                temp[edge] = edgeVal.intValue();
            }
        }

        return temp;
    }

    /**
     * Set suppression for columns
     *
     * @param suppress suppression state to set
     */
    public void setSuppressColumns(int suppress) {
        if (suppression == null) {
            // Initialize if necessary
            suppression = new Vector();
        }

        int oldValue = getSuppressColumns();

        // Grow the list if not big enough
        if (DataDirector.COLUMN_EDGE >= suppression.size()) {
            suppression.setSize(DataDirector.COLUMN_EDGE+1);
        }

        suppression.setElementAt(new Integer(suppress), DataDirector.COLUMN_EDGE);

        firePropertyChange("SuppressColumns", new Integer(oldValue), new Integer(suppress));
    }

    /**
     * Return the suppression state (NA/zero) for columns
     *
     * @return current suppression state of columns
     */
    public int getSuppressColumns() {
        return ((Integer)suppression.elementAt(DataDirector.COLUMN_EDGE)).intValue();
    }

    /**
     * Set suppression for rows
     *
     * @param suppress suppression state to set
     */
    public void setSuppressRows(int suppress) {
        if (suppression == null) {
            // Initialize if necessary
            suppression = new Vector();
        }

        int oldValue = getSuppressRows();

        // Grow the list if not big enough
        if (DataDirector.ROW_EDGE >= suppression.size()) {
            suppression.setSize(DataDirector.ROW_EDGE+1);
        }

        suppression.setElementAt(new Integer(suppress), DataDirector.ROW_EDGE);

        firePropertyChange("SuppressRows", new Integer(oldValue), new Integer(suppress));
    }

    /**
     * Return the suppression state (NA/zero) for rows
     *
     * @return current suppression state of rows
     */
    public int getSuppressRows() {
        return ((Integer)suppression.elementAt(DataDirector.ROW_EDGE)).intValue();
    }

    /**
     * Set suppression for pages
     *
     * @param suppress suppression state to set
     */
/*    public void setSuppressPages(int suppress) {
        if (suppression == null) {
            // Initialize if necessary
            suppression = new Vector();
        }

        int oldValue = getSuppressPages();

        // Grow the list if not big enough
        if (DataDirector.PAGE_EDGE >= suppression.size()) {
            suppression.setSize(DataDirector.PAGE_EDGE+1);
        }

        suppression.setElementAt(new Integer(suppress), DataDirector.PAGE_EDGE);

        firePropertyChange("SuppressPages", new Integer(oldValue), new Integer(suppress));
    }
*/
    /**
     * Return the suppression state (NA/zero) for pages
     *
     * @return current suppression state of pages
     */
/*    public int getSuppressPages() {
        return ((Integer)suppression.elementAt(DataDirector.PAGE_EDGE)).intValue();
    }
*/
    /**
     * Set the list of measures and create a default cube
     *
     * @param measures list of measures to use to make a default cube
     * @status New
     */
/*    public void setMeasures(String[] measures) {
        String[] oldMeas = getMeasures();
        if (!Utility.compareListsExact(oldMeas, measures)) {
            measList = measures;

            firePropertyChange("Measures", oldMeas, measures);
        }
    }*/

    /**
     * Get the list of measures
     *
     * @return list of measures
     * @status New
     */
/*    public String[] getMeasures() {
        return measList;
    }*/

    /**
     * Set the default number of dimensions to put on a column for default layouts
     *
     * @param numCol number of dimensions to put on the column
     * @status New
     */
    public void setDefaultColumnCount(int numCol) {
        int oldCol = getDefaultColumnCount();
        if (oldCol != numCol) {
            numCols = numCol;
            firePropertyChange("DefaultColumnCount", new Integer(oldCol), new Integer(numCol));
            defaultChanged = true;
        }
    }

    /**
     * Get the default number of dimensions put on a column for default layouts
     *
     * @return number of dimensions
     * @status New
     */
    public int getDefaultColumnCount() {
        return numCols;
    }

    /**
     * Set the default number of dimensions to put on a row for default layouts
     *
     * @param numRow number of dimensions to put on the row
     * @status New
     */
    public void setDefaultRowCount(int numRow) {
        int oldRow = getDefaultRowCount();
        if (oldRow != numRow) {
            numRows = numRow;
            firePropertyChange("DefaultRowCount", new Integer(oldRow), new Integer(numRow));
            defaultChanged = true;
        }
    }

    /**
     * Set whether pages should be shared or not
     */
    public void setSharePage(boolean sharePage)
    {
        boolean oldShare = isSharePage();
        if (oldShare != sharePage) {
            m_sharePage = sharePage;
            firePropertyChange("SharePage", new Boolean(oldShare), new Boolean(m_sharePage));
        }
    }

    /**
     * Return whether or not pages are shared.
     */
    public boolean isSharePage()
    {
        return m_sharePage;
    }

    /**
     * Set shared page number
     */
    public void setCurrentPage(long page, QDR qdrPage)
    {
        long oldPage = getCurrentPage();
        m_qdrPage = qdrPage;
        if (oldPage != page) {
            m_page = page;
            firePropertyChange("CurrentPage", new Long(oldPage), new Long(m_page));
            defaultChanged = true;
        }
    }

    /**
     * Return current shared page number
     */
    public long getCurrentPage()
    {
        return m_page;
    }

    /**
     * Return current QDR page number
     */
    public QDR getCurrentQDRPage()
    {
        return m_qdrPage;
    }

    /**
     * Indicates whether hierarchical drilling should be used exclusively f
     *
     * @param hierDrill <code>true</code> to always use hierarchical drilling
     * @status New
     */
    public void setHierarchicalDrilling(boolean hierDrill)
    {
        boolean oldHierDrill = isHierarchicalDrilling();
        if (oldHierDrill != hierDrill) {
            m_hierDrill = hierDrill;
            firePropertyChange("HierarchicalDrilling", new Boolean(oldHierDrill), new Boolean(hierDrill));
            defaultChanged = true;
        }
    }

    /**
     * Indicates whether hierarchical drilling is set exclusively
     *
     * @return <code>true</code> if hierarchical drilling is used exclusively
     * @status New
     */
    public boolean isHierarchicalDrilling()
    {
        return m_hierDrill;
    }

    /**
     * Indicates whether asymmetric drilling should be used
     *
     * @param asymmetric <code>true</code> to indicate asymmetric drilling
     * @status New
     */
    public void setAsymmetricDrilling(boolean asymmetric)
    {
        boolean oldAsymDrill = isAsymmetricDrilling();
        if (oldAsymDrill != asymmetric) {
            m_asymDrill = asymmetric;
            firePropertyChange("AsymmetricDrilling", new Boolean(oldAsymDrill), new Boolean(asymmetric));
            defaultChanged = true;
        }
    }

    /**
     * Indicates whether asymmetric drilling is set
     *
     * @return <code>true</code> if asymmetric drilling is set
     * @status New
     */
    public boolean isAsymmetricDrilling()
    {
        return m_asymDrill;
    }
    
    /**
     * Set whether or not to filter children when drilling down.
     * 
     * @param all		If <code>true</code>, drill children may be 
     * filtered by the query.  If 
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @status New
     */
    public void setDrillWithFilteredChildren(boolean filter)
    {
        boolean oldDrillFiltered = isDrillWithFilteredChildren();
        if (oldDrillFiltered != filter)
        {
            m_drillWithFilteredChildren = filter;
            firePropertyChange("DrillWithFilteredChildren", new Boolean(oldDrillFiltered), new Boolean(filter));
            defaultChanged = true;
        }
    }
 
    /**
     * Get whether or not to filter children when drilling down.
     * 
     * @return	If <code>true</code>, drill children may be filtered by
     * the query.  If
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @status New
     */
    public boolean isDrillWithFilteredChildren()
    {
        return m_drillWithFilteredChildren;
    }
    

    /**
     * Sets fetch buffer size
     *
     * @param size integer indicating number of values to fetch per buffer read
     *             for cursors.  -1 turns partial fetching off and fetches the entire
     *             cursor
     * @status New
     */
    public void setFetchSize(int size)
    {
        int oldFetchSize = getFetchSize();
        if (oldFetchSize != size)
        {
            m_fetchSize = size;
            firePropertyChange("FetchSize", new Integer(oldFetchSize), new Integer(size));
            defaultChanged = true;
        }
    }

    /**
     * Returns the currently-set fetch buffer size
     *
     * @return currently set fetch buffer size.  -1 if fetch all is set
     *
     * @status New
     */
    public int getFetchSize()
    {
        return m_fetchSize;
    }

    /**
     * Sets whether entire page edges are fetched.  Default is <code>true</code>.
     *
     * @param fullfetch if <code>true</code>, the page edge is fully fetched.  If not, partial fetching applies.
     */
    public void setFetchPageEdge(boolean fullfetch)
    {
        boolean oldfullfetch = getFetchPageEdge();
        if (oldfullfetch != fullfetch)
        {
            m_fullFetch = fullfetch;
            firePropertyChange("FetchPageEdge", new Boolean(oldfullfetch), new Boolean(fullfetch));
            defaultChanged = true;
        }
    }

    /**
     * Returns whether entire page edges are fetched.
     *
     * @return <code>true</code> if entire page edges are fetched.
     *
     * @status New
     */
    public boolean getFetchPageEdge()
    {
        return m_fullFetch;
    }

    /**
     * @hidden
     * Sets whether page dimensions are fetched separately, if possible.
     *
     * @param separate if <code>true</code>, the page dimensions are fetched separately.  If not, they are fetched together.
     */
    public void setSeparatePageDimensions(boolean separate)
    {
        boolean oldsepDims = getSeparatePageDimensions();
        if (oldsepDims != separate)
        {
            m_separateDims = separate;
            firePropertyChange("SeparatePageDimensions", new Boolean(oldsepDims), new Boolean(separate));
        }
    }

    /**
     * @hidden
     * Returns whether page dimensions are fetched separately.
     *
     * @return <code>true</code> if page dimensions are fetched separately.
     *
     * @status New
     */
    public boolean getSeparatePageDimensions()
    {
        // This must be off if separate page is off
        //if (m_query.isSeparatePage())
            return m_separateDims;
        //return false;
    }

    /**
     * Set a universe selection for a given dimension.
     *
     * @param dimension dim name
     * @param selection selection to store
     */
     // blm - Selection code moved to dvt-olap
/*    public void setUniverseSelection(String dimension, Selection selection) {
        if (selection == null) {
            // Remove the key
            universeSelections.remove(dimension);
            return;
        }
        universeSelections.put(dimension, selection);
    }*/

    /**
     * Get a universe selection for a given dimension.
     *
     * @param dimension dim name
     * @return selection found, if any
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getUniverseSelection(String dimension) {
        return (Selection)universeSelections.get(dimension);
    }*/

    /**
     * Turn off actual cursor evaluation
     *
     * @param eval should cursors be evaluated?
     */
    public void setEvaluateCursor(boolean eval) {
        boolean oldEval = isEvaluateCursor();
        if (oldEval != eval) {
            evalCursor = eval;
            firePropertyChange("EvaluateCursor", new Boolean(oldEval), new Boolean(eval));
        }
    }

    /**
     * Is cursor evaluation on?
     *
     * @return <code>true</code> if cursor evaluation is on
     */
    public boolean isEvaluateCursor() {
        return evalCursor;
    }

    /**
     * Get the default number of dimensions put on a column for default layouts
     *
     * @return number of dimensions
     * @status New
     */
    public int getDefaultRowCount() {
        return numRows;
    }

   /**
    * Sets the value of the given property on the Query.
    * <code>property</code> should be one of the PROPERTY_
    * constants defined in <code>QueryConstants</code>, and the
    * <code>value</code> should match the description there for
    * the given property.
    *
    * @param property name of the property to set, from <code>QueryConstants</code>
    * @param value value of the property to set
    *
    * @see oracle.dss.dataSource.common.QueryConstants
    * @status New
    */
   public void setProperty(String property, Object value) 
   {
        if (property != null)
        {
            // Check property type
            //checkPropertyType(property, value);

            if (value != null)
            {
                
                Object oldValue = m_properties.get(property);
                if (!value.equals(oldValue))
                {
                    firePropertyChange(property, oldValue, value);
                }
                m_properties.put(property, value);
            }
            else
                m_properties.remove(property);
        }
   }

/*   protected void checkPropertyType(String property, Object value) throws IllegalArgException
   {
        if (property.equals(QueryConstants.PROPERTY_STEP_DEFAULTS))
        {
            if (value != null && !(value instanceof DefaultStepTable))
                throw new IllegalArgException(null, 0, value);
        }
   }*/

    public long getPropertyAsLong(String property)
    {
        Object val = getProperty(property);
        if (val instanceof Long)
            return ((Long)val).longValue();
        return 0;
    }
    
    public boolean getPropertyAsBoolean(String property)
    {
        Object val = getProperty(property);
        if (val instanceof Boolean)
            return ((Boolean)val).booleanValue();
        
        return false;
    }
    
   /**
    * Gets the value of the given property from the Query.
    * <code>property</code> should be one of the PROPERTY_
    * constants defined in <code>QueryConstants</code>.  The return
    * value depends on the property requested.
    *
    * @param property name of the property to get, from <code>QueryConstants</code>
    *
    * @return value of the given property, if any
    *
    * @see oracle.dss.dataSource.common.QueryConstants
    * @status New
    */
   public Object getProperty(String property)
   {
        if (property != null) {
          Object objProperty = m_properties.get(property); 
          
          
          if (objProperty == null)
          {
              // Not found: look up default
              objProperty = getDefault(property);
          }
          
          return objProperty;
        }

        return null;
   }

    /**
     * @hidden
     * Return the default for the given property, if any
     */
    protected Object getDefault(String property)
    {
        for (int i = 0; i < m_defaultTable.length; i++)
        {
            if (property.equals(m_defaultTable[i][PROP_NAME]))
            {                
                return m_defaultTable[i][DEFAULT_VALUE];
            }
        }
        return null;
    }
    
    
   /*
    * @hidden
    */
   public void setProperties(Hashtable properties)
   {
        if (properties == null)
            return;
            
        Enumeration keys = properties.keys();
        while (keys.hasMoreElements())
        {
            Object key = keys.nextElement();
            Object value = properties.get(key);
            if (value != null)
                m_properties.put(key, value);
        }        
   }

    /**
     * Add a property change listener.
     *
     * @param l property change listener
     */
    public void addPropertyChangeListener(PropertyChangeListener l) {
        boundSupport.addPropertyChangeListener(l);
    }

    /**
     * Remove a property change listener.
     *
     * @param l property change listener
     */
    public void removePropertyChangeListener(PropertyChangeListener l) {
        boundSupport.removePropertyChangeListener(l);
    }

    /**
     * @hidden
     * Clone this class.  Note! Property change listeners are not copied
     * @throws CloneNotSupportedException in case clones are not supported
     */
    public Object clone(Object obj) throws CloneNotSupportedException {
        // Field-wise clone
        PropertySupport ps = (PropertySupport)super.clone();

        // Replace prop support
        ps.boundSupport = new PropertyChangeSupport(obj);

        // Redo the suppression property
        ps.suppression = cloneSuppression();

        // Copy universe selections
        ps.universeSelections = cloneHashtable(universeSelections);

        // Copy properties
        ps.m_properties = cloneHashtable(m_properties);

        return ps;
    }

    /**
     * @hidden
     * @throws java.lang.CloneNotSupportedException
     * @return 
     * @param t
     */
    protected Hashtable cloneHashtable(Hashtable t) throws CloneNotSupportedException {
        Hashtable newtable = new Hashtable();
        Enumeration keys = t.keys();
        Object key;
        Object value;
        while (keys.hasMoreElements()) {
            key = keys.nextElement();
            value = t.get(key);
            if (value != null)
            {
                try
                {
                    Method m = value.getClass().getMethod("clone", null);
                    value = m.invoke(value, null);
                }
                catch (NoSuchMethodException e)
                {                    
                }      
                catch (IllegalAccessException e2)
                {                    
                }
                catch (InvocationTargetException e3)
                {                    
                }
            }
            newtable.put(key, value);
        }
        return newtable;
    }

    /**
     * @hidden
     */
    public String getTagName()
    {
        return XMLName;
    }

    public Object getXML(XMLContext retCons) {
        ObjectNode root = new ObjectNode(PersistableConstants.XMLNS + ":" + XMLName);
        root.addProperty("name", XMLName.toLowerCase());

        // Universe selections
        // blm - Selection code moved to dvt-olap
/*        ContainerNode selections = new ContainerNode(PersistableConstants.XMLNS + ":" + "UniverseSelections");
        selections.addProperty("name", "universeselections");
        Enumeration sels = universeSelections.elements();
        while (sels.hasMoreElements()) {
            selections.addContainedObject((ObjectNode)((Selection)sels.nextElement()).getXML(retCons));
        }
        root.addContainer(selections);
*/
        root.addProperty("AutoUpdate", autoUpdate);

        // Suppression bit sets
        ContainerNode suppress = new ContainerNode(PersistableConstants.XMLNS + ":" + "Suppression");
        suppress.addProperty("name", "suppression");
        int temp = 0;
        Integer t = null;
        for (int i = 0; i < suppression.size(); i++) {
            t = (Integer)suppression.elementAt(i);
            if (t != null)
            {
                temp = ((Integer)suppression.elementAt(i)).intValue();
            }
            else
            {
                temp = 0;
            }
            ObjectNode suppressedEdge = new ObjectNode(PersistableConstants.XMLNS + ":" + "SuppressedEdge");
            suppressedEdge.addProperty("name", "suppressededge");
            suppressedEdge.addProperty("value", temp);
            suppress.addContainedObject(suppressedEdge);
            //suppress.addContainedObject(new PropertyNode("SuppressedEdge", temp));
        }
        root.addContainer(suppress);

        // Measure list
//        root.addContainer(QueryUtil.getXMLStringArray("Measures", "Measure", measList));

        root.addProperty("DefaultColumnDimensions", numCols);
        root.addProperty("DefaultRowDimensions", numRows);
        root.addProperty("EvaluateCursor", evalCursor);
        root.addProperty("HierarchicalDrilling", m_hierDrill);
        root.addProperty("AsymmetricDrilling", m_asymDrill);
        root.addProperty("DrillWithFilteredChildren", m_drillWithFilteredChildren);
        root.addProperty("FetchSize", m_fetchSize);
        root.addProperty("FetchPageEdge", m_fullFetch);
        root.addProperty("SharePage", m_sharePage);
        long page = isSharePage() ? m_page : 0;
        root.addProperty("PageNumber", page);
        if (m_qdrPage != null)
        {
            // Convert to OlapQDR for saving: DTD issues
            OlapQDR qdr = null;
            // Not sure why we have to do this: almost feels like a Java inheritance bug
            if (m_qdrPage instanceof OlapQDR)
            {
                qdr = new OlapQDR((OlapQDR)m_qdrPage);
            }
            else if (m_qdrPage instanceof HierarchicalQDR)
            {
                qdr = new OlapQDR((HierarchicalQDR)m_qdrPage);                
            }
            else
                qdr = new OlapQDR(m_qdrPage);
            root.addContainer((ContainerNode)qdr.getXML(retCons));
        }
        root.addProperty("SeparatePageDimensions", m_separateDims);
 
        // Retrieve the PROPERTY_DIMENSIONCALCS_SUPPORTED Boolean value        
        Boolean boolDimCalcsSupported = 
          (Boolean) getProperty (QueryConstants.PROPERTY_DIMENSIONCALCS_SUPPORTED);
        
        // Convert the Boolean value to a boolean primitive
        boolean bDimCalcs = 
          (boolDimCalcsSupported == null) ? false : boolDimCalcsSupported.booleanValue();

        root.addProperty ("DimensionCalcsSupported", bDimCalcs);
        
        // Do rest of properties
        ContainerNode propContainer = new ContainerNode(PersistableConstants.XMLNS + ":" + "Properties");
        propContainer.addProperty("name", "properties");
        Enumeration props = m_properties.keys();
        while (props.hasMoreElements())
        {
            String property = (String)props.nextElement();
            Object value = m_properties.get(property);
            if (value != null)
                propContainer.addContainedObject(getPropertyNodeForType(property, value));
        }
        root.addContainer(propContainer);
        return root;
    }

    protected ObjectNode getPropertyNodeForType(String property, Object value)
    {
        ObjectNode node = new ObjectNode(PersistableConstants.XMLNS + ":" + property);
        node.addProperty("name", property.toLowerCase());
        if (value instanceof Integer) 
            node.addProperty("value", ((Integer)value).intValue());
        if (value instanceof Long)
            node.addProperty("value", ((Long)value).longValue());
        if (value instanceof String)
            node.addProperty("value", (String)value);
        if (value instanceof Boolean)
            node.addProperty("value", ((Boolean)value).booleanValue());
        if (value instanceof Character)
            node.addProperty("value", ((Character)value).charValue());
        if (value instanceof Double)
            node.addProperty("value", ((Double)value).doubleValue());
            
        return node;
    }

/*
    protected PropertyNode getPropertyNodeForType(String property, Object value)
    {
        if (value instanceof Integer) {
            ObjectNode node = new ObjectNode(QueryConstants.XMLNS + ":" + property);
            node.addProperty("name", property.toLowerCase());
            node.addProperty("value", ((Integer)value).intValue());
            return new PropertyNode(property, ((Integer)value).intValue());
        }
        if (value instanceof Long)
            return new PropertyNode(property, ((Long)value).longValue());
        if (value instanceof String)
            return new PropertyNode(property, (String)value);
        if (value instanceof Boolean)
            return new PropertyNode(property, ((Boolean)value).booleanValue());
        if (value instanceof Character)
            return new PropertyNode(property, ((Character)value).charValue());
        if (value instanceof Double)
            return new PropertyNode(property, ((Double)value).doubleValue());
            
        return null;
    }
*/    
    protected Object getPropertyValueFromNode(PropertyNode pn)
    {
        String property = pn.getName();
        Object defValue = getDefault(property);
        if (defValue instanceof Boolean)
            return new Boolean(pn.getValueAsBoolean());
        if (defValue instanceof Long)
            return new Long(pn.getValueAsLong());
        if (defValue instanceof String)
            return pn.getValueAsString();
        if (defValue instanceof Double)
            return new Double(pn.getValueAsDouble());
        if (defValue instanceof Character)
            return new Character(pn.getValueAsCharacter());
        if (defValue instanceof Integer)
            return new Integer(pn.getValueAsInteger());
        
        return null;
    }
    
    /**
    * @hidden
    */
    public void setXML(XMLContext context, Object node) {
        try {
            ObjectNode root = (ObjectNode)node;
            
            // Universe selections
            if (root == null)
                return;
            ContainerNode selections = root.getContainer(PersistableConstants.XMLNS + ":UniverseSelections");
            Enumeration sels = selections == null ? null : selections.getContainedObject();
            ObjectNode sel;
            // blm - Selection code moved to dvt-olap
/*            Selection newSel;        
            while (sels.hasMoreElements()) {
                sel = (ObjectNode)sels.nextElement();
                newSel = new Selection();
                newSel.setXML(context, sel);
                universeSelections.put(newSel.getDimension(), newSel);
            }*/
            
            autoUpdate = root.getPropertyValueAsBoolean("AutoUpdate");
            
            // Suppression bit sets
            ContainerNode suppress = root.getContainer(PersistableConstants.XMLNS + ":Suppression");
            Enumeration suppList = suppress.getContainedObject(PersistableConstants.XMLNS + ":SuppressedEdge");
            int temp = 0;
            suppression = new Vector();
            ObjectNode supp;        
            while (suppList.hasMoreElements()) {
                supp = (ObjectNode)suppList.nextElement();
                if (supp != null) {
                    suppression.addElement(new Integer(supp.getPropertyValueAsInteger("value")));
                }
                else {
                    suppression.addElement(new Integer(0));
                }
            }
            
            // Measure list 
//            measList = QueryUtil.getStringArrayFromXML(root.getContainer("Measures"));
            
            numCols = root.getPropertyValueAsInteger("DefaultColumnDimensions");
            numRows = root.getPropertyValueAsInteger("DefaultRowDimensions");
            evalCursor = root.getPropertyValueAsBoolean("EvaluateCursor");
            m_hierDrill = root.getPropertyValueAsBoolean("HierarchicalDrilling");
            try
            {
                m_asymDrill = root.getPropertyValueAsBoolean("AsymmetricDrilling");
            }
            catch (NoSuchPropertyException nspe)
            {
            }
            try
            {
                m_drillWithFilteredChildren = root.getPropertyValueAsBoolean("DrillWithFilteredChildren");
            }
            catch (NoSuchPropertyException nspe)
            {              
            }
            try
            {
                m_fetchSize = root.getPropertyValueAsInteger("FetchSize");
            }
            catch (NoSuchPropertyException nspe2)
            {
            }
            try
            {
                m_fullFetch = root.getPropertyValueAsBoolean("FetchPageEdge");
            }
            catch (NoSuchPropertyException nspe3)
            {
            }
            m_sharePage = root.getPropertyValueAsBoolean("SharePage");
            try
            {
                m_page = isSharePage() ? root.getPropertyValueAsLong("PageNumber") : 0;
            }
            catch (Exception e)
            {
                m_page = isSharePage() ? root.getPropertyValueAsInteger("PageNumber") : 0;
            }
            // Retrieve the QDR information
            OlapQDR qdr = new OlapQDR();

            ContainerNode qdrNode = (ContainerNode)root.getContainer(qdr.getTagName());

            if (qdrNode != null)
            {
                // Set the QDR data from the property node
                qdr.setXML(context, qdrNode);
                // Comes in as an OlapQDR but originally was a QDR, so convert it
                m_qdrPage = qdr.makeQDR();
            }
            try
            {
                m_separateDims = root.getPropertyValueAsBoolean("SeparatePageDimensions");
            }
            catch (NoSuchPropertyException nspe4)
            {
            }
            try
            {
                boolean dimCalcs = root.getPropertyValueAsBoolean("DimensionCalcsSupported");
                if (dimCalcs)
                {
                    setProperty (QueryConstants.PROPERTY_DIMENSIONCALCS_SUPPORTED, 
                      new Boolean(true));
                }
            }                
            catch (NoSuchPropertyException nspe5)
            {
            }
            ContainerNode propContainer = root.getContainer(PersistableConstants.XMLNS + ":Properties");
            if (propContainer != null)
            {
                Enumeration properties = propContainer.getPropertyNodes();
                while (properties.hasMoreElements())
                {
                    PropertyNode pn = (PropertyNode)properties.nextElement();
                    if (pn != null)
                    {   
                        setProperty(pn.getName(), getPropertyValueFromNode(pn));
                    }
                }
            }
        }
        catch (NoSuchPropertyException e) {
            throw new oracle.dss.dataSource.common.NoSuchPropertyException(null, e.getMessage(), e);
        }

    }
 
    /**
     * Handle a property change for the entire bean.
     *
     * @param propName the name of the property (minus get/set)
     * @param oldValue the previous value of the property
     * @param newValue the new value of the property
     */
    protected void firePropertyChange(String propName, Object oldValue, Object newValue) {
        // Mark this change in the undo stack

        // Fire the true beans bound support
        if (boundSupport != null) {
            boundSupport.firePropertyChange(propName, oldValue, newValue);
        }
    }  
    
    /****************************
     * ThinState implementation *
     ****************************/

    /**
     * Returns the state changes
     * For now returns only the share page and page number properties
     *
     * @return state as a String, null if there are no changes
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public String getState(PropertySupport basePropSupport)
    {
        StringBuffer state = new StringBuffer();
        boolean stateChanged = false;

        boolean baseSharePage   = true;
        long basePage            = 0;
        QDR baseQDRPage         = null;
        Vector baseSuppression  = null;

        if (basePropSupport != null)
        {
            // Get the information from the base property support
            baseSharePage = basePropSupport.isSharePage();
            basePage = basePropSupport.getCurrentPage();
            baseQDRPage = basePropSupport.getCurrentQDRPage();
            baseSuppression = basePropSupport.suppression;
        }

        // Get the share page and current page state
        if ((m_sharePage != baseSharePage) ||
            (m_page != basePage) ||
            !Utility.compareObj(m_qdrPage, baseQDRPage))
        {
            state.append((m_sharePage)? "1":"0");
            state.append(Long.toString(m_page));
            if (m_qdrPage != null)
            {
                state.append(Selection.escapeStateString(
                    m_qdrPage.getDimMemberPairs(), DELIMITERS, null, ESCAPE_CHAR));
            }
            stateChanged = true;
        }

        // Get the suppression state
        if (!Utility.compareVectors(baseSuppression, suppression))
        {
            if (suppression != null)
            {
                state.append(STATE_DELIMITER);
                for (Enumeration e = suppression.elements(); e.hasMoreElements(); )
                {
                    Integer suppress = (Integer)e.nextElement();
                    state.append((suppress != null)? suppress.toString() : "0");
                }
            }
            stateChanged = true;
        }

        if (stateChanged)
            return state.toString();

        return null;
    }
*/
    /**
     * Sets the new state based on the information in the given String
     *
     * @param state String containing state information
     *
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*     public void setState(String state, PropertySupport basePropSupport)
     {
        if (Utility.compareObj(state, getState(basePropSupport)))
            return;

        boolean baseSharePage   = true;
        long basePage            = 0;
        QDR baseQDRPage         = null;
        Vector baseSuppression  = null;

        if (basePropSupport != null)
        {
            // Get the information from the base property support
            baseSharePage = basePropSupport.isSharePage();
            basePage = basePropSupport.getCurrentPage();
            baseQDRPage = basePropSupport.getCurrentQDRPage();
            baseSuppression = basePropSupport.suppression;
        }

        String pageState 		= null;
        String suppressionState = null;

        if (state != null && state.length() > 0)
        {
            int delimiter = state.indexOf(STATE_DELIMITER);

            if (delimiter > -1)
            {
                pageState = state.substring(0, delimiter);
                suppressionState = state.substring(delimiter+1);
            }
            else
            {
                pageState = state;
            }
        }

        if (pageState != null && pageState.length() > 0)
        {
            // Read share page property from the first character
            boolean bSharePage = (pageState.charAt(0) == '1');
            setSharePage(bSharePage);

            // Parse the rest of the state to get the current page
            long newPage = basePage;
            QDR newQDRPage = baseQDRPage;

            if (pageState.length() > 1)
            {
                newPage = Long.parseLong(pageState.substring(1, 2));
                if (pageState.length() > 2)
                {
                    // Unescape QDR state before recreating the QDR
                    newQDRPage = new QDR(null,
                        Selection.unescapeStateString(pageState.substring(2), DELIMITERS, null, ESCAPE_CHAR));
                }
            }
            // Set the new current page and QDR
            setCurrentPage(newPage, newQDRPage);
        }
        else
        {
            // If share page property is different from the base, set it to base
            if (m_sharePage != baseSharePage)
            {
                setSharePage(baseSharePage);
            }
            // If current page properties are different from the base, set them to base
            if (m_page != basePage || !Utility.compareObj(m_qdrPage, baseQDRPage))
            {
                QDR baseQDRCopy = null;
                if (baseQDRPage != null)
                {
                    baseQDRCopy = (QDR)baseQDRPage.clone();
                }
                setCurrentPage(basePage, baseQDRCopy);
            }
        }

        // Read suppression state
        if (suppressionState != null && suppressionState.length() > 0)
        {
            char[] suppressionChars = suppressionState.toCharArray();
            int[] intSuppressionState = new int[suppressionChars.length];

            for (int i=0; i<suppressionChars.length; i++)
            {
                intSuppressionState[i] = Integer.parseInt(String.valueOf(suppressionChars[i]));
            }
            setSuppressionState(intSuppressionState);
        }
        else
        {
            // If supression is different from base, set it to base
            if (!Utility.compareVectors(baseSuppression, suppression))
            {
                suppression = cloneSuppression(baseSuppression);
            }
        }
     }
    // End thin state implementation
*/
    public String toString()
    {
        String output = "Universe Selections:\n";

        // blm - Selection code moved to dvt-olap
/*        // Universe selections
        Enumeration sels = universeSelections.elements();
        while (sels.hasMoreElements())
        {
            output += ((Selection)sels.nextElement()) + "\n";
        }*/
        output += "AutoUpdate: " + autoUpdate + "\n";

        // Suppression bit sets
        output += "Suppression:\n";
        int temp = 0;
        Integer t = null;
        for (int i = 0; i < suppression.size(); i++) {
            t = (Integer)suppression.elementAt(i);
            if (t != null)
            {
                temp = ((Integer)suppression.elementAt(i)).intValue();
            }
            else
            {
                temp = 0;
            }
            output += "Edge: " + i + " suppressed value: " + temp + "\n";
        }

/*        if (measList != null)
        {
            // Measure list
            output += "Measure:\n";
            for (int m = 0; m < measList.length; m++)
            {
                output += measList[m] + "\n";
            }
        }*/

        output += "Default Column Dimensions: " + numCols + "\n";
        output += "Default Row Dimensions: " + numRows + "\n";
        //output += "Default Query: " + m_query.isDefaultQuery() + "\n";
        output += "Evaluate Cursor: " + evalCursor + "\n";
        output += "HierarchicalDrilling: " + m_hierDrill + "\n";
        output += "AsymmetricDrilling: " + m_asymDrill + "\n";
        output += "DrillWithFilteredChildren: " + m_drillWithFilteredChildren + "\n";
        //output += "Separate Page: " + m_query.m_separatePage + "\n";
        output += "Fetch Size: " + m_fetchSize + "\n";
        output += "SharePage: " + m_sharePage + "\n";
        if (isSharePage())
        {
            output += "Page Number: " + m_page + "\n";
        }
        output += "Page QDR: " + m_qdrPage + "\n";

        Enumeration keys = m_properties.keys();
        while (keys.hasMoreElements())
        {
            Object key = keys.nextElement();
            if (key == null)
                continue;
            Object value = m_properties.get(key);
            output += "Property: " + key.toString() + ", Value: " + (value != null ? value.toString() : value) + "\n";
        }

        return output;
    }

    public boolean isDefaultChanged() {
        return defaultChanged;
    }


    protected Hashtable               universeSelections    = new Hashtable();

    /**
     * @serial evaluate cursors
     */
    protected boolean                 evalCursor      = true;

    /**
     * @serial autoUpdate property storage
     */
    protected boolean                 autoUpdate      = true;
    /**
     * @serial NA/zero suppression property storage
     */
    protected Vector                  suppression     = null;    
    /**
     * @serial Measure list
     */
//    protected String[] measList = null;
    
    /**
     * @serial default number of dimensions for a column in default layout
     */
    protected int numCols = 2;
    
    /**
     * @serial default number of dimensions for a row in default layout
     */
    protected int numRows = 1;
    
    /**
     * @serial Drill hierarchically?
     */
    protected boolean m_hierDrill = false;

    /**
     * @serial Drill asymmetrically?
     */
    protected boolean m_asymDrill = true;

    /**
     * @serial Fetch size
     */
    protected int m_fetchSize = 1000;

    /**
     * @serial Full page fetch
     */
    protected boolean m_fullFetch = true;

    /**
     * @serial Separate page dim fetch
     */
    protected boolean m_separateDims = true;

    /**
     * @serial Should pages be shared?
     */
    protected boolean m_sharePage = true;

    /**
     * @serial Expose all drill children?
     */
    protected boolean m_drillWithFilteredChildren = true;

    /**
     * @serial Current page number (0 if not shared)
     */
    protected long m_page = 0;

    /**
     * @serial QDR version of current page number
     */
    protected QDR m_qdrPage = null;

    /**
     * @serial General property container
     */
    protected Hashtable m_properties = new Hashtable();

    protected static final String XMLName = "Properties";

	protected static final char ESCAPE_CHAR     = 'q';
    protected static final char STATE_DELIMITER = '*';
    protected static final char[] DELIMITERS = {STATE_DELIMITER};

    private boolean defaultChanged = false;
}
