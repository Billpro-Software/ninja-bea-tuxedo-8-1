/**
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui.panel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

import javax.swing.table.AbstractTableModel;

import oracle.bali.ewt.text.MultiLineLabel;
import oracle.bali.ewt.text.WordWrapper;

import oracle.dss.datautil.gui.StandardTable;

import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * @hidden
 * A panel that contains a table that displays user-defined data.
 *
 * @status hidden
 */  
public class ListPanel extends JPanel
{
    //-----------------------------------------------------------------------
    // NON PUBLIC CONSTANTS
    //-----------------------------------------------------------------------

    private static final Dimension DEFAULT_TABLEVIEWPORTSIZE = new Dimension ( 300, 200 );

    //-----------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-----------------------------------------------------------------------

    /**
     * true if the UI contents of the flag have been initialized, false otherwise.
     *
     * @status protected
     */
    protected boolean m_bInitialized = false;

    /**
     * Table displaying the table based information.
     *
     * @status protected
     */
    protected StandardTable m_dataTable = null;

    /**
     * Multi line label displaying the caption describing the table.
     *
     * @status protected
     */
    protected MultiLineLabel m_lblCaption = null;
    
    /**
     * The caption for the multi line label.
     *
     * @status protected
     */
    protected String m_strCaption = null;

    /**
     * List of column info elements. Each element contains display information 
     * and contents for a column.
     *
     * @status protected
     */
    protected Vector m_listColumnInfo = null;

    //-----------------------------------------------------------------------
    // PUBLIC METHODS
    //-----------------------------------------------------------------------

    /** 
     * Constructor.
     *
     * @status hidden
     */  
    public ListPanel ( )
    {
        initializeMembers ( );
    }   

    /** 
     * @hidden
     * Adds a column into the data table.
     *
     * @param strHeaderTitle The string for the column header title.
     * @param listColumnElements The list of elements to display in the column.
     *
     * @return An index >= 0 at which the column was added, -1 otherwise.
     *
     * @status hidden
     */  
    public int addColumn ( String strHeaderTitle, Vector listColumnElements )
    {
        ColumnInfo  columnInfo  = null;
        
        columnInfo = createColumnInfo ( strHeaderTitle, listColumnElements );
        if ( null == columnInfo )
            return -1;
            
        m_listColumnInfo.addElement ( columnInfo );            
        return m_listColumnInfo.size ( ) - 1;
    }

    /**
     * @hidden
     * Flush any existing columns in the table.
     *   
     * @status hidden
     */
    public void flushContents ( )
    {
        if ( m_listColumnInfo.size ( ) > 0 )
            m_listColumnInfo.removeAllElements ( );
    }

    /** 
     * @hidden
     * Retrieves the caption describing the data in the table.
     *
     * @return Retrieves the caption set in the table
     *
     * @status hidden
     */  
    public String getCaption ( ) 
    {
        return m_strCaption;
    }

    /** 
     * @hidden
     * Retrieves the multi line label object in the panel.
     *
     * @return Retrieves the multi line label object in the panel.
     *
     * @status hidden
     */  
    public MultiLineLabel getLabel ( ) 
    {
        return m_lblCaption;
    }
    
    /** 
     * @hidden
     * Retrieves the table object in the panel.
     *
     * @return Retrieves the table object in the panel.
     *
     * @status hidden
     */  
    public StandardTable getTable ( ) 
    {
        return m_dataTable;
    }
    
    /** 
     * @hidden
     * Retrieves the user object for a particular row and column.
     *
     * @param rowIndex The row index of the data.
     * @param columnIndex The column index of the data.
     *
     * @return Retrieves the user object for a particular row and column.
     *
     * @status hidden
     */  
    public Object getUserObjectAt ( int rowIndex, int columnIndex ) 
    {
        ColumnInfo  colInfo = null;
        Vector      listColumnElements  = null;
        
        if ( rowIndex < 0 || columnIndex < 0 )
            return null;
            
        if ( columnIndex >= m_listColumnInfo.size ( ) )
            return null;
            
        colInfo = ( ColumnInfo ) m_listColumnInfo.elementAt ( columnIndex );
        if ( null == colInfo )
            return null;
            
        listColumnElements = colInfo.getColumnElements ( );            
        if ( null == listColumnElements || rowIndex >= listColumnElements.size ( ) )
            return null;
                        
        return listColumnElements.elementAt ( rowIndex );
    }
    
    /** 
     * @hidden
     * Call this method to initialize the table with the columns and their elements.
     *
     * @return true if the panel was initialized successfully, false otherwise.
     *
     * @status hidden
     */  
    public boolean initializeContents () throws MetadataManagerException
        {
        boolean bRetVal = false;

        if (!m_bInitialized)
            {
            // Initialize the UI contents of the panel.
            bRetVal = initUIContents ();
            if (!bRetVal)
                {
                removeAll ( );
                return bRetVal;
                }

            m_bInitialized = true;
            }

        return true;
        }

    /**
     * @hidden
     * Removes a column into the data table.
     *
     * @param nIndex The column index to remove from the data table.
     *
     * @status hidden
     */  
    public void removeColumnAt ( int nIndex ) 
                throws ArrayIndexOutOfBoundsException 
    {
        m_listColumnInfo.removeElementAt ( nIndex );
    }

    /** 
     * @hidden
     * Sets the caption describing the data in the table.
     *
     * @param strCaption The caption for the 
     *
     * @status hidden
     */  
    public void setCaption ( String strCaption ) 
    {
        m_strCaption = strCaption;
        if ( m_lblCaption != null && strCaption != null )
            m_lblCaption.setText ( strCaption );
    }
    
    /** 
     * @hidden
     * Updates the data from the data structures into the UI.
     *
     * @status hidden
     */  
    public boolean updateData ( )
    {   
        // Update the data for the caption
        if ( m_strCaption != null )
            m_lblCaption.setText ( m_strCaption );

        if ( 0 == m_listColumnInfo.size ( ) )
            return false;
            
        // Update the data for the table
        m_dataTable.setModel ( new DataTableModel ( ) );
        // Resize the columns to fit
        m_dataTable.sizeColumnsToFit ( JTable.AUTO_RESIZE_ALL_COLUMNS );
        
        return true;
    }
    
    //-----------------------------------------------------------------------
    // NON PUBLIC METHODS
    //-----------------------------------------------------------------------

    /** 
     * Initializes the caption UI.
     *
     * @return true if initialized successfully, false otherwise.
     *
     * @status protected
     */  
    protected boolean initUICaption ( )
    {
        m_lblCaption.setTextWrapper ( WordWrapper.getTextWrapper ( ) );
        m_lblCaption.setPreferredAspectRatio ( MultiLineLabel.ASPECTRATIO_NONE );
        m_lblCaption.setPreferredRows ( 2 );
        
        return true;
    }
    
    /** 
     * Initializes the table UI.
     *
     * @return true if initialized successfully, false otherwise.
     * 
     * @status protected
     */  
    protected boolean initUITable ( )
    {
        m_dataTable.setBackground ( Color.white );
        m_dataTable.setAutoResizeMode ( JTable.AUTO_RESIZE_ALL_COLUMNS );
        m_dataTable.setPreferredScrollableViewportSize ( DEFAULT_TABLEVIEWPORTSIZE );
        m_dataTable.setSelectionMode ( ListSelectionModel.SINGLE_SELECTION );
        
        return true;
    }
    
    /** 
     * Builds the UI layout for the panel.
     *
     * @status protected
     */  
    protected boolean buildUILayout ( )
    {
        JScrollPane scrollPane  = null;
        
        setLayout ( new BoxLayout ( this, BoxLayout.Y_AXIS ) );
        // setBorder ( BorderFactory.createEmptyBorder ( 10, 10, 10, 10 ) );
        
        m_lblCaption.setAlignmentX ( Component.LEFT_ALIGNMENT );
        
        // Create the scroll pane and add the table to it. 
        scrollPane = new JScrollPane ( m_dataTable );
        scrollPane.setAlignmentX ( Component.LEFT_ALIGNMENT );
        scrollPane.setBackground ( Color.white );

        // Add the caption component if we have a valid caption to display.
        if ( m_strCaption != null && m_strCaption.length ( ) > 0 )
        {
            add ( m_lblCaption );
        }            
        add ( Box.createRigidArea ( new Dimension ( 0, 10 ) ) );
        add ( scrollPane );
        
        return true;
    }
    
    /** 
     * Initializes the members of the panel.
     *
     * @status protected
     */  
    protected ColumnInfo createColumnInfo ( String strHeaderTitle, Vector listColumnElements )
    {
        if ( null == strHeaderTitle || 0 == strHeaderTitle.length ( ) )
            return null;
            
        // Allow the column to have no elements
/*            
        if ( null == listColumnElements || 0 == listColumnElements.size ( ) )
            return null;
*/            
        return new ColumnInfo ( strHeaderTitle, listColumnElements );            
    }

    /** 
     * Retrieves the ColumnInfo object at the specified index.
     *
     * @status protected
     */  
    protected ColumnInfo getColumnInfoAt ( int nIndex )
    {
        ColumnInfo  columnInfo  = null;
            
        if ( nIndex < 0 || 
             nIndex >= m_listColumnInfo.size ( ) )
            return null;
                
        columnInfo = ( ColumnInfo ) m_listColumnInfo.elementAt ( nIndex );
        return columnInfo;
    }
    
    /** 
     * Determines the maximum row count in the columns.
     *
     * @status protected
     */  
    protected int getMaxRowCount ( )
    {
        ColumnInfo  columnInfo  = null;
        int         nIndex      = -1, nCurRowCount = -1, nMaxRowCount = -1;
        Vector      listColumnElements = null;
        
        for ( nIndex = 0; nIndex < m_listColumnInfo.size ( ); nIndex++ )
        {
            columnInfo = ( ColumnInfo ) m_listColumnInfo.elementAt ( nIndex );
            if ( null == columnInfo )
                continue;
                
            listColumnElements = columnInfo.getColumnElements ( );
            if ( null == listColumnElements || 0 == listColumnElements.size ( ) )
                continue;
                
            nCurRowCount = listColumnElements.size ( );
            if ( nCurRowCount > nMaxRowCount )
                nMaxRowCount = nCurRowCount;
        }
        return nMaxRowCount;
    }
    
    /** 
     * Initializes the members of the panel.
     *
     * @status protected
     */  
    protected void initializeMembers ( )
    {
        m_dataTable = new StandardTable ( );
        m_lblCaption = new MultiLineLabel ( );
        m_strCaption = new String ( );
        m_listColumnInfo = new Vector ( );
    }        

    /** 
     * Initializes the UI content of the panel.
     *
     * @status protected
     */  
    protected boolean initUIContents ( )
    {
        boolean bRetVal = false;
        
        bRetVal = initUICaption ( );
        if ( ! bRetVal )   
            return bRetVal;
            
        bRetVal = initUITable ( );
        if ( ! bRetVal )   
            return bRetVal;

        bRetVal = buildUILayout ( );
        
        return bRetVal;
    }
    
    //-----------------------------------------------------------------------
    // INNER CLASSES
    //-----------------------------------------------------------------------

    /** 
     * Contains information about one column of the data table.
     *
     * @status protected
     */  
    protected class ColumnInfo extends Object
    {
        private String  m_strHeaderTitle        = null;
        private Vector  m_listColumnElements    = null;
        
        public ColumnInfo ( String strHeaderTitle, Vector listColumnElements )
        {
            m_strHeaderTitle = strHeaderTitle;
            m_listColumnElements = listColumnElements;
        }
        
        public String getHeaderTitle ( )
        {
            return m_strHeaderTitle;
        }            
        
        public Vector getColumnElements ( )
        {
            return m_listColumnElements;
        }
        
        public void setHeaderTitle ( String strHeaderTitle )
        {
            m_strHeaderTitle = strHeaderTitle;
        }            
    }
    
    /** 
     * Implements the table model for the data table.
     *
     * @status private
     */  
    private class DataTableModel extends AbstractTableModel
    {
        public DataTableModel ( )
        {
        }
        
        //-----------------------------------------------------------------------
        // Begin implementation of TableModel interface.
        //-----------------------------------------------------------------------

        public Class getColumnClass ( int columnIndex )
        {
            Object  value   = null;
            
            value = getValueAt ( 0, columnIndex );
            if ( null == value )
                return null;
                
            return value.getClass ( );
        }
        
        public int getColumnCount ( )
        {
            return m_listColumnInfo.size ( );
        }            
        
        public String getColumnName ( int columnIndex )
        {
            ColumnInfo  columnInfo  = null;
            
            columnInfo = getColumnInfoAt ( columnIndex );
            if ( null == columnInfo )
                return null;
                
            return columnInfo.getHeaderTitle ( );                
        }     

        public int getRowCount ( )
        {
            return getMaxRowCount ( );
        }
 
        public Object getValueAt ( int rowIndex, int columnIndex )
        {
            ColumnInfo  columnInfo  = null;
            Vector      listColumnElements = null;
            
            columnInfo = getColumnInfoAt ( columnIndex );
            if ( null == columnInfo )
                return null;
            
            listColumnElements = columnInfo.getColumnElements ( );
            if ( null == listColumnElements )
                return null;
                
            if ( rowIndex < 0 || rowIndex >= listColumnElements.size ( ) )
                return null;

            return listColumnElements.elementAt ( rowIndex );                
        }
        
        public boolean isCellEditable ( int rowIndex, int columnIndex )
        {
            return false;
        }
        
        //-----------------------------------------------------------------------
        // End implementation of TableModel interface.
        //-----------------------------------------------------------------------
    }
}