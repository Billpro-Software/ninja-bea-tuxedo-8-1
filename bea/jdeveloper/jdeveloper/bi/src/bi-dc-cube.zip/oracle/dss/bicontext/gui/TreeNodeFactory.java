/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.util.Hashtable;

import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;

import javax.swing.tree.TreeNode;

/**
 * @hidden
 * Default factory class for tree nodes used by the Catalog Tree UI.  Users can
 * override and register their TreeNodeFactory through the CatalogTreeModel class.
 */
public class TreeNodeFactory
{
    /**
     * For creating non-root tree nodes
     * @return 
     * @param result
     * @param env
     */
    public TreeNode createTreeNode(Hashtable env, SearchResult result)
    {
        return new DefaultDirTreeNode(env, result);
    }
    
    /**
     * For creating the root tree node
     * @return 
     * @param rootName
     * @param context
     * @param env
     */
    public TreeNode createTreeNode(Hashtable env, DirContext context, String rootName)
    {
        return new DefaultDirTreeNode(env, context, rootName);
    }
}