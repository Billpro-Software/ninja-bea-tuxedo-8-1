/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

/**
 * Support late setting of ObjectLoader.  By setting an ObjectLoader 
 * late, the Object returned can be of the type appropriate for the 
 * abstraction layer.  Eg JNDI for the untyped JNDI layer or 
 * a StubPM for the typed client layer.  
 * @hidden
 */
public abstract interface ObjectLoaderTarget
{
    public void setObjectLoader(ObjectLoader objectLoader);
}
