/*
** Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.metadataManager.server.drivers.sba;

// Imports
import oracle.bi.web.soap.internal.MetadataServiceSoap;

import oracle.bi.web.soap.internal.QueryResults;
import oracle.bi.web.soap.internal.SASubjectArea;

import oracle.bi.web.soap.internal.SASubjectAreaDetails;

import oracle.bi.web.soap.internal.SATable;

import oracle.bi.web.soap.internal.XMLQueryExecutionOptions;
import oracle.bi.web.soap.internal.XMLQueryOutputFormat;

import java.io.StringReader;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.Enumeration;
import java.util.List;

import javax.naming.CompoundName;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.ModificationItem;

import oracle.bi.presentation.soap.connection.BISoapConnection;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.PropertyMap;

import oracle.dss.bicontext.BIInvalidNameException;
import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.Privilege;

import oracle.dss.connection.client.Connection;
import oracle.dss.connection.common.ConnectionException;
import oracle.dss.connection.common.CB;
import oracle.dss.connection.server.drivers.ConnectionDriver;

import oracle.dss.metadataManager.common.MDRoot;
import oracle.dss.metadataManager.common.MDContentBag;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerRuntimeException;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.metadataManager.common.MDItemFolder;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataManager.common.UnsupportedOperationException;
import oracle.dss.metadataManager.common.MMUtilities;
import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;
import oracle.dss.metadataManager.server.drivers.MetadataDriver;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.ErrorHandler;

import oracle.dss.util.persistence.Persistable;

import oracle.dss.util.persistence.PersistableConstants;

import oracle.xml.parser.v2.SAXParser;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @hidden
 */
public class SBAMetadataDriverImpl implements MetadataDriver {

    private ConnectionDriver m_connectionDriver = null;
    private Locale m_locale;
    private ErrorHandler m_errorHandler;
    private PropertyBag m_metadataPropertyBag;
    private MetadataManagerServices m_MetadataManagerServices;
    private MDFolder m_root;
    private ResourceBundle m_resourceBundle = null;
    private MDObjectFactory m_factory;
    private NameParserImpl m_nameParser;
    private boolean m_isDrillPathSet = false;
    private BISoapConnection m_connection;
    private MetadataServiceSoap m_metadataSrvcSoap;
    private Vector m_ds;

    /**
     * Retrieves the children of the given <code>MDObject</code> object.
     *
     * @param mdObject The <code>MDObject</code> object.
     *
     * @return A MDContentBag that contains the children.
     *
     * @status New
     */
    public MDContentBag getChildren( MDObject mdObject ) throws MetadataManagerException {
        return null;
    }

    /**
     * @hidden
     */
    public ResourceBundle getResourceBundle()
    {
        /** gek 11/03/06
        if (m_resourceBundle == null)
        {
            try
            {
                m_resourceBundle = ResourceBundle.getBundle("oracle.dss.metadataManager.server.drivers.mdm.resource.MDMMetadataDriverBundle", getLocale());
            }
            catch (Exception e)
            {
                    getErrorHandler().error(e, getClass().getName(), "getResourceBundle");
            }
        }
        */
        return m_resourceBundle;
    }

    /**
     * Retrieves the relatives of the given <code>MDObject</code> object.
     *
     * @param mdObject The <code>MDObject</code> object.
     *
     * @return A MDContentBag that contains the children.
     *
     * @status New
     */
    public MDContentBag getRelatives( MDObject mdObject ) throws MetadataManagerException
    {
        return null;
    }

    /************************************************************************
    * Methods to query the cache and driver.
    ************************************************************************/

    /**
     * @hidden
     */
    public MDObject getMDObject ( PropertyBag properties ) throws MetadataManagerException {
        MDObject _obj = null;
        if (properties != null)
        {
            String _dsName = null;
            String _objName = null;
            String _tmp = null;
            if ((_tmp = properties.getStrPropertyValue(MM.UNIQUE_ID)) != null && _tmp.indexOf('.', 4) != -1)
                _dsName = _tmp.substring(4, _tmp.indexOf('.'));
            else if ((_tmp = properties.getStrPropertyValue(MM.PATH)) != null && _tmp.indexOf('/') != -1)
                _dsName = _tmp.substring(0, _tmp.indexOf('/'));
            else if ((_tmp = properties.getStrPropertyValue(MM.ESCAPED_UID)) != null && _tmp.indexOf('.') != -1)
                _dsName = _tmp.substring(0, _tmp.indexOf('.'));
            else if ((_tmp = properties.getStrPropertyValue(MM.OBJECT_NAME)) != null ||
                (_tmp = properties.getStrPropertyValue(MM.OBJECT_LABEL)) != null)
                _objName = _tmp;
            
            try
            {
                if (_dsName != null)
                {
                    for(Enumeration _enumeration = m_ds.elements(); _enumeration.hasMoreElements();)
                    {
                        MetadataManagerSearchResultImpl _msr = (MetadataManagerSearchResultImpl)_enumeration.nextElement();
                        Connection _ds = (Connection)_msr.getObject();
                        if (_ds != null && _dsName.equals(_ds.getConnectionKey()) && 
                            _ds.getConnectionObj().getStrPropertyValue("COMPLETE") == null)
                        {
                            getItemFolders(_ds.getRoot());
                            _obj = m_MetadataManagerServices.getMDObject(properties, true);
                            if (_obj != null)
                                break;
                        }
                    }
                }
                else if(_objName != null)
                {
                    for(Enumeration _enumeration = m_ds.elements(); _enumeration.hasMoreElements();)
                    {
                        MetadataManagerSearchResultImpl _msr = (MetadataManagerSearchResultImpl)_enumeration.nextElement();
                        Connection _ds = (Connection)_msr.getObject();
                        if (_ds != null && _ds.getConnectionObj().getStrPropertyValue("COMPLETE") == null)
                        {
                            getItemFolders(_ds.getRoot());
                            _obj = m_MetadataManagerServices.getMDObject(properties, true);
                            if (_obj != null)
                                break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                
            }
        }
        return _obj;
    }

    /**
     * @hidden
     */
    public MDObject[] getMDObjects(PropertyBag properties ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public MDObject[] getChildren(MDObject mdObject, PropertyBag properties ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public MDObject[] getRelatives( MDObject mdObject, String relation ) throws MetadataManagerException {
            throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public MDObject[] getRelatives(MDObject mdObject, PropertyBag properties ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /************************************************************************
    * Methods to update the cache and the drivers.
    ************************************************************************/

    /**
     * @hidden
     */
    public MDObject setMDObject( MDObject mdObject, Attributes attributes ) throws MetadataManagerException {
        //if(mdObject instanceof MDFolder)
        //    return createSubcontext((MDFolder)mdObject);
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public int removeMDObject( MDObject mdObject ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public int removeAllChildren ( MDObject mdObject ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public int setRelatedMDObject( MDObject firstObject, MDObject secondObject, String relation	) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public int removeRelatedMDObject( MDObject firstObject, MDObject secondObject, String relation ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public MDObject refresh( MDObject mdObject, int depth ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public MDObject copy ( MDObject objectToBeCopied, MDObject newParent, PropertyBag properties ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
    public int move ( MDObject objectToBeMoved, MDObject newParent, PropertyBag properties ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
/*
    private boolean isMatched (MDObject mdObj, Attributes attrs, boolean isCaseSensitive)
    {
        boolean _matching = true;
        NamingEnumeration _enum = attrs.getIDs();
        while (_enum.hasMoreElements())
        {
            String _id = (String)_enum.nextElement();
            Attribute _attr = attrs.get(_id);

            boolean _oneValueMatched = false;
            try
            {
                NamingEnumeration _enum2 = _attr.getAll();
                while (_enum2.hasMoreElements())
                {
                    Object _val = _enum2.nextElement();

                    Property _prop = new Property();
                    if (_val instanceof String)
                        _prop.setStrValue(_id, (String)_val, MDU.UI_ALL);
                    else
                        _prop.setObjValue(_id, _val, MDU.UI_ALL);

                    if (mdObj.contains(_prop, isCaseSensitive))
                    {
                        _oneValueMatched = true;
                        break;
                    }
                }
            }
            catch (NamingException ne){
                // matching will be false
            }

            if (!_oneValueMatched)
            {
                _matching = false;
                break;
            }
        }

        return _matching;
    }
*/
    /**
     * @hidden
     */
    public Vector search(MDObject mdObject, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
/*
        int scope = controls.getSearchScope();
        Vector returnVec = new Vector();
        if(scope == BISearchControls.SUBTREE_SCOPE)
        {
            searchBySubScope(mdObject, attributes, returnVec, controls);
        }
        else if(scope == BISearchControls.SELECTIVE_ONELEVEL_SCOPE)
        {
            String objType = null;
            try
            {
                if (attributes.get(MDU.OBJECT_TYPE) != null)
                    objType = (String)attributes.get(MDU.OBJECT_TYPE).get();
            }
            catch (NamingException ne){}
                
            boolean isMeasure = (objType != null && objType.equals(MM.MEASURE));
            fillChildren(mdObject);
            MDObject[] mdObjArray = m_MetadataManagerServices.getChildrenFromIndex(mdObject);
            if(mdObjArray != null)
            {
                for(int i = 0; i < mdObjArray.length; i++)
                {
                    if(MMUtilities.isMDM(mdObjArray[i]))
                    {
                        if (attributes == null)
                        {
                            returnVec.addElement(mdObjArray[i]);
                        }
                        else if (controls instanceof MDSearchControls && ((MDSearchControls)controls).isIgnoreMatchingAttributes())
                        {
                            returnVec.addElement(mdObjArray[i]);
                        }
                        else if(isMeasure && mdObjArray[i].getObjectType().equals(MM.FOLDER))
                        {
                            returnVec.addElement(mdObjArray[i]);
                        }
                        else if(searchByOneLevelScope(mdObjArray[i], attributes, controls))
                        {
                            returnVec.addElement(mdObjArray[i]);
                        }
                    }
                }
            }
        }
        else if(scope == BISearchControls.ONELEVEL_SCOPE_WITH_FOLDERS)
        {
            fillChildren(mdObject);
            MDObject[] mdObjArray = m_MetadataManagerServices.getChildrenFromIndex(mdObject);
            if(mdObjArray != null)
            {
                for(int i = 0; i < mdObjArray.length; i++)
                {
                    if(mdObjArray[i].getDriverType().equals(MDU.SBA))
                    {
                        if(mdObjArray[i].getObjectType().equals(MM.FOLDER))
                            returnVec.addElement(mdObjArray[i]);
                        else
                        {
                            if (attributes == null)
                                returnVec.addElement(mdObjArray[i]);
                            else
                            {
                                if (isMatched(mdObjArray[i], attributes, controls.isCaseSensitive()))
                                    returnVec.addElement(mdObjArray[i]);
                            }
                        }
                    }
                }
            }
        }
        else if(scope == BISearchControls.ONELEVEL_SCOPE)
        {
            fillChildren(mdObject);
            MDObject[] mdObjArray = m_MetadataManagerServices.getChildrenFromIndex(mdObject);
            if(mdObjArray != null)
            {
                for(int i = 0; i < mdObjArray.length; i++)
                {
                    if(mdObjArray[i].getDriverType().equals(MDU.SBA))
                    {
                        if (attributes == null)
                            returnVec.addElement(mdObjArray[i]);
                        else
                        {
                            if (isMatched(mdObjArray[i], attributes, controls.isCaseSensitive()))
                                returnVec.addElement(mdObjArray[i]);
                        }
                    }
                }
            }
        }

        if(returnVec.size() > 0)
        {
            BIFilter _filter = controls.getResultFilter();
            if (_filter != null && _filter instanceof MDFilter)
            {
                Vector _finalResult = new Vector(returnVec.size());
                for (int n=0; n<returnVec.size(); n++)
                {
                    if (((MDFilter)_filter).evaluate((MDObject)returnVec.elementAt(n)))
                        _finalResult.addElement(returnVec.elementAt(n));
                }
                return _finalResult;
            }
            else
                return returnVec;
        }
        else
*/
            return null;
	}
/*
    private void searchBySubScope(MDObject mdObject, Attributes attrs, Vector returnVec, BISearchControls controls) throws MetadataManagerException
    {
        String objType = mdObject.getObjectType();
        if(objType != null && (objType.equals(MM.FOLDER)
                               || objType.equals(MM.DIMENSION)
                               || objType.equals(MM.HIERARCHY)
                               || objType.equals(MM.ROOT)))
        {
            fillChildren(mdObject);
            MDObject[] mdObjArray = m_MetadataManagerServices.getChildrenFromIndex(mdObject);
            if(mdObjArray != null)
            {
                for(int i = 0; i < mdObjArray.length; i++)
                {
                    if(mdObjArray[i].getDriverType().equals(MDU.SBA))
                    {
                        if (attrs == null)
                            returnVec.addElement(mdObjArray[i]);
                        else
                        {
                            if (isMatched(mdObjArray[i], attrs, controls.isCaseSensitive()))
                                returnVec.addElement(mdObjArray[i]);
                        }
                        searchBySubScope(mdObjArray[i], attrs, returnVec, controls);
                    }
                }
            }
        }
    }

    private boolean searchByOneLevelScope(MDObject child, Attributes attrs, BISearchControls controls) throws MetadataManagerException
    {
        if(child != null)
        {
            // null attributes = no matching attributes = must match
            if (attrs == null)
                return true;

            if (isMatched(child, attrs, controls.isCaseSensitive()))
                return true;
            else
            {
                String objType = child.getObjectType();
                if(objType != null && (objType.equals(MM.FOLDER)
                                       || objType.equals(MM.DIMENSION)
                                       || objType.equals(MM.HIERARCHY)
                                       || objType.equals(MM.ROOT)))
                {
                    fillChildren(child);
                    MDObject[] mdObjArray = m_MetadataManagerServices.getChildrenFromIndex(child);
                    if(mdObjArray != null)
                    {
                        for(int i = 0; i < mdObjArray.length; i++)
                        {
                            if(searchByOneLevelScope(mdObjArray[i], attrs, controls))
                                return true;
                        }
                    }
                }
            }
        }
        return false;
    }
*/
    public Vector search(String uniqueID, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
/*
        Vector _msr = new Vector();
        PropertyBag _bag = new PropertyBag();
        _bag.setStrPropertyValue(MM.UNIQUE_ID, uniqueID);
        
        Vector _mdVec = search(m_MetadataManagerServices.getMDObject(_bag, true), attributes, controls);
        for(int i=0; _mdVec != null && i < _mdVec.size(); i++)
        {
            MDObject _obj = (MDObject)_mdVec.elementAt(i);
            String[] _attrKeys = controls.getReturningAttributes();
            Attributes _attrs = null;
            // returns all properties if returning attributes is null
            if (_attrKeys == null)
            {
                PropertyBag _retBag = _obj.getPropertyBag();    
                _attrs = MMUtilities.propertyBagToAttributes(_retBag);
            }
            else
            {
                _attrs = new BasicAttributes();
                for(int j=0; j<_attrKeys.length; j++)
                {
                    Property _prop = _obj.getProperty(_attrKeys[j]);
                    if(_prop != null && _prop.getObjValue() != null)
                        _attrs.put(_attrKeys[j], _prop.getObjValue());
                }
            }
            MetadataManagerSearchResultImpl _sr = new MetadataManagerSearchResultImpl(_obj.toString(), _obj.getClassName(), _obj, _attrs, _obj.getObjectType(), getMetadataManagerServices());
            _sr.setFullPathName(MMUtilities._extractID(_obj.getPath()));
            _sr.setDriverType(MDU.SBA);
            _msr.addElement(_sr);
        }
        return _msr;
*/
        return null;
    }

    /*
     * @hidden
     * Fill children bag of the mdObject if children bag is not filled.
     */
/*
    private void fillChildren(MDObject mdObject) throws MetadataManagerException
    {
        if(isDeferredLoad() && mdObject.getChildrenStatus(MDU.SBA) == MM.NOT_COMPLETE) {
            mdObject = addChildren(mdObject, false);
        }
        else if(isAsynchronousLoad()) {
            synchronized(m_MetadataManagerServices) {
                while(!isAsyncLoadComplete() && mdObject.getChildrenStatus(MDU.SBA) != MM.COMPLETE) {
                    try {
                        m_MetadataManagerServices.notifyAll();
                        m_MetadataManagerServices.wait();
                    }
                    catch(InterruptedException e) {
                    }
                }
            }
        }
    }
*/
  	/************************************************************************
  	* Operations on the objects that only exist on the source platform.
  	************************************************************************/

    /**
     * Retrieves the object for the given PropertyBag and object.
     *
     * @param properties The PropertyBag.
     * @param object The object.
     *
     * @return The Object that matches the given criteria.
     *
     * @status New
     */
    public Object getDriverSpecificObject( PropertyBag properties, Object object ) throws MetadataManagerException
    {
        if ( properties == null )
            return null;
        String name = properties.getStrPropertyValue ( MM.OBJECT_NAME );
        if ( name == null )
            return null;
        if ( name.equals ( "MeasureDimensionSource" ) )
            return (Object) getMeasureDimensionSource ( properties, object );
        return null;
    }

    /**
     * Retrieves the object representing the Measure Dimension.
     *
     * @param properties The PropertyBag.
     * @param object The object.
     *
     * @return The Object that matches the given criteria.
     *
     * @status New
     */
    public Object getMeasureDimensionSource ( PropertyBag properties, Object measureArray ) 
    {
        return null;
    }

    /**
     * @hidden
     */
	public int setDriverSpecificObject( Object object, PropertyBag properties )	throws MetadataManagerException {
        if(properties != null) {
            String errorHandler = properties.getStrPropertyValue("ErrorHandler");
            if(errorHandler != null)
            {
                m_errorHandler = (ErrorHandler)object;
                return MDU.SUCCESS;
            }
        }
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
	public int removeDriverSpecificObjects( PropertyBag properties ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

  	/************************************************************************
  	* Support for Security
  	************************************************************************/
  	
    /**
     * @hidden
     */
	public boolean addEntries ( MDFolder folder, Name name, Vector entries, boolean cascadeToSubfolders, boolean cascadeToObjects ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
    public boolean setEntries ( MDFolder folder, Name name, Vector entries, boolean cascadeToSubfolders, boolean cascadeToObjects ) throws MetadataManagerException {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }

    /**
     * @hidden
     */
	public boolean removeEntries ( MDFolder folder, Name name, Vector entries, boolean cascadeToSubfolders, boolean cascadeToObjects ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
	public Vector entries ( MDFolder folder, Name name ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
	public Vector getAllUsers () throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
	public Privilege getPrivilege ( MDFolder folder, Name name ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

  	/************************************************************************
  	* Other
  	************************************************************************/
  	
    /**
     * @hidden
     */
	public int free ( MDObject mdObject) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
  	public int free() throws MetadataManagerException {
  		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}
  	
    /**
     * Sets the locale.
     *
     * @param locale The <code>Locale</code> object.
     *
     * @status New
     */
	public void setLocale(Locale locale) {
		m_locale = locale;
	}
	
    /**
     * Gets the locale.
     *
     * @return The <code>Locale</code> object.
     *
     * @status New
     */
	public Locale getLocale() {
		return m_locale;
	}
		
  	/************************************************************************
  	* ConnectionDriver related Operations
  	************************************************************************/
  	
	/**
     * Specifies the <code>ConnectionDriver</code> object for the driver.
     *
     * @param connectionDriver The <code>ConnectionDriver</code> object.
     *
     * @return A constant that represents success or failure.
     * The valid constants are:
     * <ul>
     * <li><code>SUCCESS</code></li>
     * <li><code>FAILURE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status New
     */
  	public int setConnectionDriver( ConnectionDriver connectionDriver) throws MetadataManagerException {
  		m_connectionDriver = connectionDriver;
  		return MDU.SUCCESS;
  	}

    /**
     * Retrieves the <code>ConnectionDriver</code> object for the driver.
     *
	 * @return The <code>ConnectionDriver</code> object.
     *
     * @status New
     */
  	public ConnectionDriver getConnectionDriver() throws MetadataManagerException {
  		return m_connectionDriver;
  	}
	
    /**
     * Retrieves the connection string for the driver.
     *
     * @return A String that represents the connection string.
     *
     * @status New
     */
    public String getConnectionString() {
        if (m_connectionDriver != null)
        {
            String _str = m_connectionDriver.getConnectionString();
            if(_str == null)
            {
                try {
                    _str = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SERVICE);
                    if(_str == null)
                        _str = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SID);
                }catch(ConnectionException ce){
                    getErrorHandler().error(ce, getClass().getName(), "getConnectionString");
                }
            }
            return _str;
        }
        return null;
    }

  	/************************************************************************
  	* Attach and Detach Operations
  	************************************************************************/

    /**
     * Attach to the database.
     *
     * @return A constant that represents success or failure.
     * The valid constants are:
     * <ul>
     * <li><code>SUCCESS</code></li>
     * <li><code>FAILURE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status New
     */
    public int attach() throws MetadataManagerException {
        attach(m_metadataPropertyBag);
        return (isAttached() ? MDU.SUCCESS : MDU.FAILURE);
    }

    /**
     * Attach to the database.
     *
     * @return A PropertyBag that contains the status information.
     *
     * @status New
     */
    public PropertyBag attach (PropertyBag propertyBag) throws MetadataManagerException
    {
        m_metadataPropertyBag = propertyBag;
        PropertyBag _properties = new PropertyBag();
        _properties.setStrPropertyValue(CB.CONNECTION, "");
        try {
          m_connection = (BISoapConnection)m_connectionDriver.getDriverSpecificObject(_properties);
          if(m_connection != null)
            m_metadataSrvcSoap = m_connection.getMetadataService();
        }
        catch(Exception e) {
            // ignore
        }
        
        if(m_connection != null || m_metadataSrvcSoap != null)
            m_metadataPropertyBag.setIntPropertyValue(MM.ATTACH_STATUS, MM.ATTACHED, MM.UI_ALL);
        else
            m_metadataPropertyBag.setIntPropertyValue(MM.ATTACH_STATUS, MM.NOT_ATTACHED, MM.UI_ALL);

        if(m_connection != null)
          m_factory = new MDObjectFactory(m_MetadataManagerServices, m_connection);
          
        m_nameParser = new NameParserImpl();
        return m_metadataPropertyBag;
    }

    /**
     * Detach the database.
     *
     * @return A constant that represents success or failure.
     * The valid constants are:
     * <ul>
     * <li><code>SUCCESS</code></li>
     * <li><code>FAILURE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status New
     */
    public int detach() throws MetadataManagerException {
            detach(m_metadataPropertyBag);
            return (isDetached() ? MDU.SUCCESS : MDU.FAILURE);
    }

    /**
     * Detach the database.
     *
     * @return A PropertyBag that contains the status information.
     *
     * @status New
     */
    public PropertyBag detach (PropertyBag propertyBag) throws MetadataManagerException
    {
        m_MetadataManagerServices = null;
        m_root = null;
        m_isDrillPathSet = false;
        m_ds = null;
        m_metadataPropertyBag.setIntPropertyValue(MM.ATTACH_STATUS, MM.NOT_ATTACHED, MM.UI_ALL);
        return m_metadataPropertyBag;
    }
	
    /**
     * Retrieve the driver type.
     *
     * @return A String containing the driver type.
     *
     * @status New
     */
    public String getDriverType(){
        return MDU.SBA;
    }

    /**
     * Retrieve an integer indicating whether or not the database is attached.
     *
     * @return A integer indicating the connection status.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     *
     * @status New
     */
    public boolean isAttached() {
        return (( m_metadataPropertyBag != null ) && 
                        ( m_metadataPropertyBag.getIntPropertyValue ( MM.ATTACH_STATUS) == MM.ATTACHED ) );
    }

    /**
     * Retrieve an integer indicating whether or not the database is detached.
     *
     * @return A integer indicating the connection status.
     *
     * @see oracle.dss.metadataManager.common.MM#ATTACHED
     * @see oracle.dss.metadataManager.common.MM#NOT_ATTACHED
     *
     * @status New
     */
  	public boolean isDetached() {
    	return (( m_metadataPropertyBag != null ) &&
          		( m_metadataPropertyBag.getIntPropertyValue ( MM.ATTACH_STATUS) == MM.NOT_ATTACHED ) );
  	}
  	
    /**
     * Retrieve the database string.
     *
     * @return A String representing the database string.
     *
     * @status New
     */
    public String getDatabaseString() {
        return "";
    }

	/**
     * Specifies the database string.
     *
     * @param databaseString The database string.
     *
     * @return A constant that represents success or failure.
     * The valid constants are:
     * <ul>
     * <li><code>SUCCESS</code></li>
     * <li><code>FAILURE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status New
     */
    public int setDatabaseString( String databaseString ){
      	if (m_metadataPropertyBag == null) {
        	m_metadataPropertyBag = new PropertyBag();      
      	}
      	m_metadataPropertyBag.setStrPropertyValue( MM.DATABASE_STRING, databaseString, MDU.UI_VISIBLE );
      	return MDU.SUCCESS;
    }

    /**
     * Retrieve the root object, usually a folder.
     *
     * @return The root object.
     *
     * @status New
     */
    public MDObject getRoot() {
        String path = null;
        try {
            path = "/users/" + this.m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.USERNAME);
        }
        catch(Exception e) {}
        m_root = m_factory.makeDriverRoot("",path);
        return m_root;
    }

    /**
     * @hidden
     */
    public int setRoot( MDObject mdObject ) {
        return -1;
    }

  	/************************************************************************
  	* Support for the PropertyMaps and Driver side constants
  	************************************************************************/
  	
    /**
     * @hidden
     */
	public PropertyMap getPropertyMap() throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}

    /**
     * @hidden
     */
	public int setPropertyMap( PropertyMap propertyMap ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}
																	
    /**
     * @hidden
     */
	public PropertyMap getConstantMap( PropertyMap constantMap ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
	}
  
  	public int renameMDObject( MDObject mdObject, Name newName ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}

  	public int modifyMDObject( MDObject mdObject, ModificationItem[] items ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}

  /************************************************************************
  * Support for User Objects ( for example XML object of Graph) 
  * from the driver based on an MDObject. 
  ************************************************************************/
  
    /**
     * @hidden
     */
  	public UserObject getUserObject( MDObject mdObject, String relation, Hashtable args ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}

    /**
     * @hidden
     */
  	public int setUserObject( MDObject mdObject, UserObject userObject ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}

    /**
     * @hidden
     */
  	public int removeUserObject( MDObject mdObject ) throws MetadataManagerException {
		throw new UnsupportedOperationException(MDU.SBA, getLocale());
  	}

  /************************************************************************
  * Set MetadataManager Services
  ************************************************************************/
  
    /**
     * Specifies the <code>MetadataManagerServices</code> object.
     *
     * @param metadataManagerServices The <code>MetadataManagerServices</code> object.
     *
     * @return A constant that represents success or failure.
     * The valid constants are:
     * <ul>
     * <li><code>SUCCESS</code></li>
     * <li><code>FAILURE</code></li>
     * </ul>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status New
     */
  	public int setMetadataManagerServices( MetadataManagerServices metadataManagerServices ) {
    	m_MetadataManagerServices = metadataManagerServices;
  		return MDU.SUCCESS;
  	}

    /**
     * Retrieves the <code>MetadataManagerServices</code> object.
     *
     * @return The <code>MetadataManagerServices</code> object.
     *
     * @status New
     */
  	public MetadataManagerServices getMetadataManagerServices() {
    	return m_MetadataManagerServices;
  	}
		
	//!!!!!!!!!!!!!!!
	//PRIVATE METHODS
	//!!!!!!!!!!!!!!!
  	
    private ErrorHandler getErrorHandler() {
        if (m_errorHandler == null) {
            m_errorHandler = new DefaultErrorHandler();
        }
        return m_errorHandler;
    }

	private boolean connectOnDemand() throws MetadataManagerException {
		if (!m_connectionDriver.isConnected()) {
			try {
				m_connectionDriver.connect();
		 	}
		 	catch (ConnectionException e) {  
		 	  /** gek 11/03/06   
		 	  throw new MetadataManagerException(MDMMetadataDriverBundle.class, MDMMetadataDriverBundle.EXC_CONNECTION, null, getLocale(), MDU.SBA, e);
		 	  */
		 	  getErrorHandler().log (e.toString(), getClass().getName(), "connectOnDemand()");
		 	}
		}
		return m_connectionDriver.isConnected();
	}
/*	
    private Object[] copyListToArray (List list, Class className)
    {
        Object objArray[] = null;
        if(list != null && list.size() != 0 && className != null)
        {
            objArray = (Object[])Array.newInstance(className, list.size());
            list.toArray(objArray);
        }
        return objArray;
    }

    private MDFolder mergeFolders(MDFolder mdmFolder, MDFolder cachedFolder)
    {  
        cachedFolder.setDriverType(MDU.SBA);
        cachedFolder.setUniqueID(MDU.SBA, mdmFolder.getOLAPIMetadataID());
        cachedFolder.setOLAPIMetadataID(mdmFolder.getOLAPIMetadataID());
        cachedFolder.setName(mdmFolder.getName());
        cachedFolder.setOLAPIRuntimeID(mdmFolder.getOLAPIRuntimeID());
        String strDescription = mdmFolder.getDescription();
        cachedFolder.setDescription(strDescription);
        cachedFolder.setLongLabel(strDescription);
        cachedFolder.setShortLabel(strDescription);
        cachedFolder.setChildrenStatus(MDU.SBA, MM.NOT_COMPLETE);
        cachedFolder.setRelativeStatus(MM.NOT_COMPLETE);
        return cachedFolder;
    }
*/
    public MDObject getMDObject(String uniqueID) throws MetadataManagerException
    {
        PropertyBag _props = new PropertyBag();
        _props.setStrPropertyValue(MM.UNIQUE_ID, uniqueID);
        return getMDObject(_props);
    }

    /**
     * @hidden
     */
    public void setLoadParameter(String loadType)
    {
    }

    /**
     * @hidden
     */
    public boolean isDeferredLoad()
    {
        return true;
    }

    /**
     * @hidden
     */
    public boolean isAsynchronousLoad()
    {
        return false;
    }

    public MDRoot addToObjectModel(MDRoot mdRoot) throws MetadataManagerException
    {
        if(m_root == null)
            m_root = (MDFolder)getRoot();
        mdRoot.setChildrenStatus(MDU.SBA, MM.NOT_COMPLETE);
        m_root.setChildrenStatus(MDU.SBA, MM.NOT_COMPLETE);
        // if deferred load, do nothing

        mdRoot.setDriverType(getDriverType());
        mdRoot.setChild(m_factory.createMeasureDimension(), MM.MEASURE_DIMENSION);
        mdRoot.setPath(m_root.getPath());
        m_MetadataManagerServices.setMDObjectInCache(m_root);
        
        // pre-load all the metadata
        Vector _vec = getDatasources();
        /*
        for(int i=0; i < _vec.size(); i++) {
          MetadataManagerSearchResultImpl _msr = (MetadataManagerSearchResultImpl)_vec.elementAt(i);
          try {
            getItemFolders(((oracle.dss.connection.client.Connection)_msr.getObject()).getRoot());
          }
          catch(Exception e) {}
        }
        */
        m_isDrillPathSet = true;
        
        return mdRoot;
    }

   	/**
     * @hidden
     * Load Metadata from driver in to specified folder
     *
     * @param mmDrivers     MetadataDriver object from which Metadata is to
     *                      be read
     * @param mdRootFolder  Root folder which will be filled with Metadata from
     *                      olap datasource
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return  root folder with filled object tree under it.
     *
     * @status private
     */
/*
    public void fillOlapObjectModel(MDFolder mdRootFolder) throws MetadataManagerException
    {
        if(mdRootFolder == null)
            return;
        // get all folders, dimensions and measures of rootschema.
        mdRootFolder = (MDFolder)addChildren(mdRootFolder, false);
        MDObject[] mdRootChildren = m_MetadataManagerServices.getChildrenFromIndex(mdRootFolder);

        if(mdRootChildren == null)
            return;
        for(int i = 0; i < mdRootChildren.length; i++)
        {
            Vector driverTypes = mdRootChildren[i].getDriverTypes();
            for(int j = 0; driverTypes != null && j < driverTypes.size(); j++)
            {
                String driverType = (String)driverTypes.elementAt(j);
                if(driverType != null && driverType.equals(MDU.SBA))
                    mdRootChildren[i] = addChildren(mdRootChildren[i], true);
            }
        }

        for(int i = 0; i < mdRootChildren.length; i++)
        {
            Vector driverTypes = mdRootChildren[i].getDriverTypes();
            for(int j = 0; driverTypes != null && j < driverTypes.size(); j++)
            {
                String driverType = (String)driverTypes.elementAt(j);
                if(driverType != null && driverType.equals(MDU.SBA))
                    mdRootChildren[i] = addRelatives(mdRootChildren[i], true, true);
            }
        }

        // retrieve aw object name.
        PropertyBag _bag = null;
        try { _bag = m_connectionDriver.getConnectionPropertyBag(); }
        catch(ConnectionException ce) 
        {
            m_errorHandler.log("Unable to retrieve connection properties", getClass().getName(), "fillOlapObjectModel");
        }

        removeEmptyFolders(mdRootFolder);
    }
*/
   	/**
     * @hidden
     * Build children tree recursively, if specified, under parent mdObject
     *
     * @param mmDriver     MetadataDriver object from which objects will be read
     * @param parent       Parent mdObject whose children tree will be build
     * @param isRecursive  Boolean value to specify recursion.
     *                     <code>true</code>  Build complete children tree
     *                                        under parent
     *                     <code>false</code> fill only children bag of parent.
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return  parent mdObject.
     *
     * @status private
     */
    public MDObject addChildren(MDObject parent, boolean isRecursive )
                                                throws MetadataManagerException
    {
        return parent;
    }

   	/**
     * @hidden
     * Build relative tree recursively, if specified, under parent mdObject
     *
     * @param mmDriver     MetadataDriver object from which objects will be read
     * @param parent       Parent mdObject whose relative tree will be build
     * @param isRecursive  Boolean value to specify recursion.
     *                     <code>true</code>  Build complete relative tree
     *                                        under parent
     *                     <code>false</code> fill only relative bag of parent.
     *
     * @throws MetadataManagerException if detach process failed
     *
     * @return  parent mdObject.
     *
     * @status private
     */
    public MDObject addRelatives(MDObject parent, boolean isRecursive, boolean isCalledFromDriver)
                                                throws MetadataManagerException
    {
        return parent;
    }

    /**
     * @hidden
     * For deferred load
     */
/*
    private void setDimensionRelatives(MDObject mdObject)
                                                throws MetadataManagerException
    {
        MDRoot mdRoot = m_MetadataManagerServices.getMDRoot();
        if(mdRoot != null)
        {
            // if children bag of root is complete then all measures have
            // already been loaded.
            int status = mdRoot.getChildrenStatus(MDU.SBA);
            if(status != MM.COMPLETE && status != MM.COMPLETING)
            {
                addChildren(mdRoot, false);
            }

            MDMeasure[] measures = m_MetadataManagerServices.getMeasures();
            if(measures != null && measures.length > 0)
            {
                for(int i = 0; i < measures.length; i++)
                {
                    if(measures[i].getRelativeStatus() != MM.COMPLETE)
                    {
                        addRelatives(measures[i], false, true);
                    }
                }
            }
        }
        if(mdObject.getChildrenStatus(MDU.SBA) == MM.NOT_COMPLETE)
            addChildren(mdObject, false);
    }
*/
    /**
     * @hidden
     */
/*
    private MDObject addChildrenRecursivelyIfNeeded(MDObject mdObject)
                                                throws MetadataManagerException
    {
        if(mdObject != null)
        {
            if(mdObject.getChildrenStatus(MDU.SBA) == MM.NOT_COMPLETE)
            {
                addChildren(mdObject, true);
            }
            else
            {
                MDObject[] mdObjects = m_MetadataManagerServices.getChildrenFromIndex(mdObject);
                if(mdObjects != null)
                {
                    for(int i = 0; i < mdObjects.length; i++)
                    {
                        addChildrenRecursivelyIfNeeded(mdObjects[i]);
                    }
                }
            }
        }
        return mdObject;
    }
*/
    /**
     * @hidden
     */
    public void done()
    {
    }

    /**
     * @hidden
     */
    public void waitUntilDone()
    {
    }

    /**
     * @hidden
     */
    public boolean isAsyncLoadComplete() throws MetadataManagerException
    {
        return true;
    }

    public MDObject getMDObject(Persistable persistable) throws MetadataManagerException
    {
        return null;
    }

    public MDObject getMDObjectUsingFullPath(String fullPath) throws MetadataManagerException
    {
        PropertyBag _bag = new PropertyBag();
        _bag.setStrPropertyValue(MM.PATH, fullPath);
        MDObject _mdObject = m_MetadataManagerServices.getMDObject(_bag, true);
        if (_mdObject == null)
        {
            String id = MMUtilities._makeUniqueID(getDriverType(), fullPath.replace('/', '.'));
            Object _obj = getObject(id, null);
            if(_obj instanceof MDObject)
                _mdObject = (MDObject)_obj;
        }
        return _mdObject;
    }

    public Attributes getAttributes(MDObject mdObj, String[] properties, int flag) throws MetadataManagerException
    {
        return null;
    }

    public boolean getFeature(String feature)
    {
        if (m_connectionDriver != null)
            return m_connectionDriver.getFeature(feature);
        else
            return false;
    }

    // New methods
    public void renameMDObject( MDFolder mdFolder, Name oldName, Name newName ) throws MetadataManagerException
    {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
    public void modifyMDObject( MDFolder mdFolder, Name name, ModificationItem[] items ) throws MetadataManagerException
    {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
    public void removeMDObject( MDFolder mdFolder, Name name, boolean isFolder ) throws MetadataManagerException
    {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
    public void copy (MDFolder mdFolder, Name objectToBeCopied, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
    public void move (MDFolder mdFolder, Name objectToBeMoved, MDFolder newParent, PropertyBag properties) throws MetadataManagerException
    {
        throw new UnsupportedOperationException(MDU.SBA, getLocale());
    }
    public Vector search (MDFolder mdFolder, Name name, Attributes attributes, BISearchControls controls) throws MetadataManagerException
    {
        if(attributes != null) {
            Vector retVec = new Vector();
            try {
                Attribute _objTypeAttr = attributes.get(PersistableConstants.Attributes.OBJECT_TYPE);
                if(_objTypeAttr != null) {
                    for(NamingEnumeration _enumeration = _objTypeAttr.getAll(); _enumeration.hasMoreElements();) {
                        String _objType = (String)_enumeration.nextElement();
                        if(_objType != null) {
                            if(_objType.equals(MM.DATASOURCE))
                            {
                                //return getDatasources();
                                retVec.addAll(getDatasources());
                            }
                            else if(_objType.equals(MM.ITEMFOLDER)) {
                                //return getItemFolders(mdFolder);
                                retVec.addAll(getItemFolders(mdFolder));
                            }
                            else 
                            {
                                PropertyBag props = new PropertyBag();
                                props.setStrPropertyValue(MM.OBJECT_TYPE, _objType);
                                MDObject obj[] = mdFolder.getChildren(props);
                                if (obj != null)
                                    for (int i = 0; i < obj.length; i++)
                                    {
                                        Attributes _attrs = getAttributes(obj[i].getName(), obj[i].getLabel(), obj[i].getObjectType(), obj[i].getPath(), obj[i].getUniqueID());
                                        retVec.addElement(new MetadataManagerSearchResultImpl(obj[i].getName(), obj[i], _attrs, true, _objType, m_MetadataManagerServices));
                                    }
                            }
                        }
                    }
                    return retVec;
                }
                //return browseCatalog(mdFolder, name);
            }
            catch(Exception e) {
                // ignore
            }
        }
        return null;
    }
/*
    private Vector getDatasources() {
        if(m_sessionID != null)
            return getDatasourcesThruSoap();
        else if(m_connection != null) {
            Vector _vec = new Vector(5);
            try{
                DatabaseMetaData metadata = m_connection.getMetaData();
                ResultSet rsCatalog = metadata.getCatalogs();
                while(rsCatalog.next()) {
                    String name = rsCatalog.getString(1);
                    oracle.dss.connection.client.Connection _connection = (oracle.dss.connection.client.Connection)m_factory.getDatasource(name);
                    Attributes _attrs = getAttributes(name, name, MM.DATASOURCE, null, null);
                    MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(name, _connection, _attrs, false, MM.DATASOURCE, m_MetadataManagerServices);
                    _vec.add(_msr);
                }
            }
            catch(Exception e) {
                // ignore
            }
            return _vec;
        }
        return null;
    }
*/
    private Vector getDatasources() {
      if(m_ds != null)
        return m_ds;
      try {
        m_ds = new Vector(5);
        String _sessionID = m_connection.getLogonToken().getStringToken();
        List<SASubjectArea> subjectAreaList = m_metadataSrvcSoap.getSubjectAreas(_sessionID);
        for(SASubjectArea currentSubjectArea : subjectAreaList) {
            String name = currentSubjectArea.getName();
            if (name != null && name.startsWith("\"") && name.endsWith("\""))
            {
                // Strip off quotes
                name = name.substring(1, name.length()-1);
            }
            Connection _connection = (Connection)m_factory.getDatasource(name);
            Attributes _attrs = getAttributes(name, name, MM.DATASOURCE, null, null);
            MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(name, _connection, _attrs, false, MM.DATASOURCE, m_MetadataManagerServices);
            m_ds.add(_msr);
        }
        return m_ds;
      }
      catch(Exception e) {
         e.printStackTrace();
         throw new MetadataManagerRuntimeException(e.getMessage(), e);
      }
    }
/*    
    private Vector getItemFolders(MDFolder parent) {
        if(m_sessionID != null) {
            Vector _vec =  getItemFoldersThruSoap(parent);
            if(!m_isDrillPathSet)
                setDrillPathsThruSoap(_vec);
            return _vec;
        }
        else if(m_connection != null) {
            Vector _vec = new Vector(5);
            Hashtable _tmpTable = new Hashtable();
            try{
                DatabaseMetaData metadata = m_connection.getMetaData();
                ResultSet rs = metadata.getColumns(parent.getName(), null, null, null);
                while(rs.next()) {
                    String name = rs.getString(3);
                    MDItemFolder _itemFolder = m_factory.createItemFolder(parent, rs);
                    if(!_tmpTable.containsKey(_itemFolder)) {
                        _tmpTable.put(_itemFolder, "");
                        Attributes _attrs = getAttributes(_itemFolder.getName(), _itemFolder.getLabel(), _itemFolder.getObjectType(), _itemFolder.getPath(), _itemFolder.getUniqueID());
                        MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(name, _itemFolder, _attrs, false, MM.ITEMFOLDER, m_MetadataManagerServices);
                        _vec.add(_msr);
                    }
                }
                rs.close();
                if(!m_isDrillPathSet)
                    setDrillPaths(_vec);
            }
            catch(Exception e) {
                e.printStackTrace();
            }
            return _vec;
        }
        return null;
    }
*/
    private Vector getItemFolders(MDFolder parent) {
        try {
            String sessionID = m_connection.getLogonToken().getStringToken();
            SASubjectArea sa = m_metadataSrvcSoap.describeSubjectArea(parent.getName(),
                                                                      SASubjectAreaDetails.INCLUDE_TABLES_AND_COLUMNS,
                                                                      sessionID);
            Vector _vec = new Vector(5);
            List<SATable> tableList = sa.getTables();
            for(int i=0; i < tableList.size(); i++) {
                MDItemFolder _itemFolder = m_factory.createItemFolder(parent, tableList.get(i));
                Attributes _attrs = getAttributes(_itemFolder.getName(), _itemFolder.getLabel(), _itemFolder.getObjectType(), _itemFolder.getPath(), _itemFolder.getUniqueID());
                MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl(_itemFolder.getName(), _itemFolder, _attrs, false, MM.ITEMFOLDER, m_MetadataManagerServices);
                _vec.add(_msr);
                
                // nested folders
                int j = i+1;
                for(; j < tableList.size(); j++)
                {
                    if(isNestedFolder(tableList.get(j)))
                    {
                        MDItemFolder _subItemFolder = m_factory.createItemFolder(parent, tableList.get(j));
                        _itemFolder.setChild(_subItemFolder, MM.ITEMFOLDER);
                    }
                    else
                        break;
                }
                
                if (j != i+1) // found nested folders
                    i=j-1;
            }
            ((Connection)parent.getDatasource()).getConnectionObj().setStrPropertyValue("COMPLETE", "COMPLETE");
            //if(!m_isDrillPathSet)
                //setDrillPaths(_vec);
            return _vec;
        }
        catch(Exception e) {
          
        }
        return null;
    }

    private boolean isNestedFolder(SATable table) 
    {
        if (table == null)
            return false;
        String _name = table.getName();
        String _desc = table.getDescription();
        return (_name.startsWith("\"- ") || _desc.startsWith("->"));
    }

/*
    private void setDrillPaths(Vector vec) {
        Hashtable _itemHolder = new Hashtable();
        try {
            for(int i = 0; i < vec.size(); i++) {
                MDItemFolder _itemFld = (MDItemFolder)((MetadataManagerSearchResultImpl)vec.elementAt(i)).getObject();
                MDItem[] _items = _itemFld.getItems();
                for(int j = 0; j < _items.length; j++) {
                    if(!_itemHolder.containsKey(_items[j])) {
                        _itemHolder.put(_items[j], "");
                        if(MM.INTEGER.equals(_items[j].getDatatype()))
                            continue;
                        // run the sql to get drill paths
                        Statement _s = m_connection.createStatement();
                        ResultSet _rs = null;
                        try {
                          _rs = _s.executeQuery("call NQSGenerateDrillDownQuery('SELECT " + _items[j].getStrPropertyValue(MM.ESCAPED_UID) + " FROM " + _itemFld.getParent().getName() + "','0','','-1-1','')");
                        }
                        catch(Exception e) {
                        }
                        Vector _drillDownVec = null;
                        if(_rs == null)
                          continue;
                        while(_rs.next()) {
                            String _drillItem =  _rs.getString(1);
                            int _index = _drillItem.indexOf(',');
                            if(_index  != -1) {
                              _drillItem = _drillItem.substring(_index+1);
                              _drillItem = _drillItem.replaceAll("\"", "");
                              _drillItem = _drillItem.trim();
                              _drillItem = _itemFld.getParent().getName() + "." + _drillItem;
                              _drillItem = MMUtilities._makeUniqueID(getDriverType(), _drillItem);
                            }
                            MDObject _mdObj = m_MetadataManagerServices.getMDObjectByUniqueID(_drillItem);
                            if(_mdObj != null) {
                                // drill down
                                if(_drillDownVec == null)
                                    _drillDownVec = new Vector(3);
                                _drillDownVec.addElement(_mdObj);
                                
                                // drill up
                                Vector _drillUpVec = (Vector)_mdObj.getObjPropertyValue(MM.DRILL_UP_PATHS);
                                if(_drillUpVec == null)
                                    _drillUpVec = new Vector(3);
                                if(!_drillUpVec.contains(_items[j]))
                                    _drillUpVec.addElement(_items[j]);
                                _mdObj.setObjPropertyValue(MM.DRILL_UP_PATHS, _drillUpVec);
                            }
                        }
                        _rs.close();
                        _s.close();
                        if(_drillDownVec != null)
                            _items[j].setObjPropertyValue(MM.DRILL_DOWN_PATHS, _drillDownVec);
                    }
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
*/
    
    public void addMDObject(MDObject mdObject) throws MetadataManagerException
    {
        String folder = mdObject.getStrPropertyValue(MM.ROOT_FOLDER);
        if (mdObject.getUniqueID() == null)
        {
            String ID = new java.rmi.server.UID().toString();
            mdObject.setUniqueID(MM.SBA, folder + "." + ID);
            mdObject.setObjectID(m_MetadataManagerServices.generateMDObjectID());
            mdObject.setPath(folder + "/" + mdObject.getName());
        }
        else
            mdObject.setDriverType(MM.SBA);
        
        mdObject.setDatasource(getDatasource(folder));
        // Need to set the parent of this to its ROOT_FOLDER MDFolder, and load
        // that MDFolder first if necessary
        MDFolder mdFolder = (MDFolder)m_MetadataManagerServices.getMDObject(MM.OBJECT_NAME, mdObject.getStrPropertyValue(MM.ROOT_FOLDER), MM.FOLDER);
        if (mdFolder != null)
            mdObject.setParent(mdFolder);
        PropertyBag bag = new PropertyBag();
        bag.setStrPropertyValue(MM.UNIQUE_ID, mdObject.getUniqueID());
        if (mdFolder != null && !mdFolder.hasChild(bag))
            mdFolder.setChild(mdObject, MM.CHILD);
    }
    
    private Connection getDatasource(String dsName)
    {
        for(Enumeration _enumeration = m_ds.elements(); _enumeration.hasMoreElements();)
        {
            MetadataManagerSearchResultImpl _msr = (MetadataManagerSearchResultImpl)_enumeration.nextElement();
            Connection _ds = (Connection)_msr.getObject();
            if (_ds != null && dsName.equals(_ds.getConnectionKey()))
            {
                return _ds;
            }
        }
        return null;
    }
    
   
    public void deferredObjectSetUp(MDObject obj) throws MetadataManagerException {
        if (obj instanceof MDItem)
            try
            {
                setDrillPath((MDItem)obj);
            }
            catch (Exception e) {
                throw new MetadataManagerException(e.getMessage(), MDU.SBA, e);
            }
    }
    
    private void setDrillPath(MDItem item) throws Exception {
        // run the sql to get drill paths
        String result = null;
        String sessionID = m_connection.getLogonToken().getStringToken();
        MDItemFolder _itemFld = null;
        MDObject parent = item.getParent();
        while (!(parent instanceof MDItemFolder) && parent != null)
            parent = parent.getParent();
        if (parent instanceof MDItemFolder)
            _itemFld = (MDItemFolder)parent;
        try {
          
          String itemName = item.getStrPropertyValue(MM.ESCAPED_UID);
          String folderName = _itemFld.getParent().getName();
          // Now remove the table name, if there
          if (itemName.indexOf(folderName) == 0)
              itemName = itemName.substring(folderName.length()+1);
          
          // Make sure folder is quoted
          if (folderName != null && !folderName.startsWith("\"") && !folderName.endsWith("\""))
              folderName = "\"" + folderName + "\"";
          
          XMLQueryExecutionOptions queryExecutionOptions = new XMLQueryExecutionOptions();
          //false, 100, false, false, "xml";
          queryExecutionOptions.setAsync(false);
          queryExecutionOptions.setMaxRowsPerPage(100);
          queryExecutionOptions.setRefresh(false);
          queryExecutionOptions.setPresentationInfo(false);
          queryExecutionOptions.setType("xml");
            
          QueryResults qr = m_connection.getXmlViewService().executeSQLQuery("call NQSGenerateDrillDownQuery('SELECT " + itemName + " FROM " + folderName + "','0','','-1-1','')",
                                                                             XMLQueryOutputFormat.SAW_ROWSET_DATA,
                                                                             queryExecutionOptions,
                                                                             sessionID);
          /*
          String m_url = "http://imohamma-pc/analytics/saw.dll";
          String request = SOAPUtility.getRequestHeader("executeSQLQuery") + 
                           SOAPUtility.getParameter("sql", "call NQSGenerateDrillDownQuery('SELECT " + _items[j].getStrPropertyValue(MM.ESCAPED_UID) + " FROM " + _itemFld.getParent().getName() + "','0','','-1-1','')") +
                           SOAPUtility.getParameter("outputFormat", "SAWRowsetData") +
                           SOAPUtility.getComplexParameter("executionOptions", new String[][] {{"async", "false"},{"maxRowsPerPage", "100"},{"refresh", "false"},{"presentationInfo", "false"},{"type", "xml"}} ) +
                           SOAPUtility.getParameter("sessionID", sessionID) +
                           SOAPUtility.getRequestFooter("executeSQLQuery");
          result = SOAPUtility.executeRequest(m_url + CB.SOAP_XMLVIEW, request);
          */
          result = qr.getRowset();
        }
        catch(Exception e) {
           e.printStackTrace();
        }
        Vector _drillDownVec = null;
        if(result == null)
          return;
        //XMLDocument xmlDoc = SOAPUtility.parseXML(result);
        //NodeList nList = xmlDoc.getElementsByTagName("Column0");
        SAXParser parser = new SAXParser();       
        parser.setPreserveWhitespace(false);
        DrillPathParseHandler dph = new DrillPathParseHandler();
        parser.setContentHandler(dph);
        parser.parse(new InputSource(new StringReader(result)));            
        
        ArrayList<String> nodes = dph.getNodes();
        for(int k=0; k < nodes.size(); k++) {
        //                         for(int k=0; k < nList.getLength(); k++) {
            
            String _drillItem =  nodes.get(k);
            //   String _drillItem =  nList.item(k).getFirstChild().getNodeValue();
                int _index = _drillItem.indexOf(',');
            if(_index  != -1) {
              _drillItem = _drillItem.substring(_index+1);
              _drillItem = _drillItem.replaceAll("\"", "");
              _drillItem = _drillItem.trim();
              _drillItem = MMUtilities._makeUniqueID(MDU.SBA, _drillItem);
            }
            MDObject _mdObj = m_MetadataManagerServices.getMDObjectByUniqueID(_drillItem);
            if (_mdObj == null) {
                // Try with folder appended to front: backward 10.1.3 compatibility
                _drillItem = _itemFld.getParent().getName() + "." + _drillItem;
                _mdObj = m_MetadataManagerServices.getMDObjectByUniqueID(_drillItem);
            }
            if(_mdObj != null) {
                // drill down
                if(_drillDownVec == null)
                    _drillDownVec = new Vector(3);
                _drillDownVec.addElement(_mdObj);
                
                // drill up
                Vector _drillUpVec = (Vector)_mdObj.getObjPropertyValue(MM.DRILL_UP_PATHS);
                if(_drillUpVec == null)
                    _drillUpVec = new Vector(3);
                if(!_drillUpVec.contains(item))
                    _drillUpVec.addElement(item);
                _mdObj.setObjPropertyValue(MM.DRILL_UP_PATHS, _drillUpVec);
            }
        }
        if(_drillDownVec != null)
            item.setObjPropertyValue(MM.DRILL_DOWN_PATHS, _drillDownVec);
    }
/*    
   private void setDrillPaths(Vector vec) {
     Hashtable _itemHolder = new Hashtable();
     try {
         for(int i = 0; i < vec.size(); i++) {
             MDItemFolder _itemFld = (MDItemFolder)((MetadataManagerSearchResultImpl)vec.elementAt(i)).getObject();
             MDItem[] _items = _itemFld.getItems();
             for(int j = 0; j < _items.length; j++) {
                 if(!_itemHolder.containsKey(_items[j])) {
                     _itemHolder.put(_items[j], "");
                     if(MM.INTEGER.equals(_items[j].getDatatype()))
                         continue;
                     setDrillPath(_items[j]);
                 }
             }
         }
     }
     catch(Exception e) {
         e.printStackTrace();
     }
   }
*/
    protected static class DrillPathParseHandler extends DefaultHandler
    {        
        protected boolean m_inColZero = false;
        protected ArrayList<String> m_nodes = new ArrayList<String>();

        public ArrayList<String> getNodes()
        {
            return m_nodes;
        }
        
        public void startElement(java.lang.String namespaceURI,
                                 java.lang.String localName,
                                 java.lang.String qName,
                                 org.xml.sax.Attributes attrs)
                          throws SAXException
        {
            if (localName.equals("Column0"))
                m_inColZero = true;
        }
        
        public void endElement(java.lang.String namespaceURI,
                               java.lang.String localName,
                               java.lang.String qName)
                        throws SAXException
        {
            if (localName.equals("Column0"))
                m_inColZero = false;
        }
        
        public void characters(char[] ch,
                               int start,
                               int length)
                        throws SAXException
        {
            if (m_inColZero)
            {
                // Store these
                m_nodes.add(new String(ch, start, length));
            }
        }
                        
    }

/*
    private createOlapMetadata(Vector vec) {
      for(int i = 0; i < vec.size(); i++) {
        MDItemFolder _itemFld = (MDItemFolder)((MetadataManagerSearchResultImpl)vec.elementAt(i)).getObject();
        
      }
    }
*/
/*
    private ResultSet execute(String sql) {
        if(m_connection != null)
        {
            try {
                Statement _s = m_connection.createStatement();
                return _s.executeQuery(sql);
            }
            catch(Exception e) {
                // ignore
            }
        }
        return null;
    }
*/    
    public Attributes getAttributes(MDFolder mdFolder, Name name, String[] attrIds, int flag) throws MetadataManagerException
    {
/*
        Attributes _attrs = null;
        
        MDObject _obj = null;
        if(name != null && name.size() > 0)
            _obj = (MDObject)lookup(mdFolder, name, null, null);
        else
            _obj = mdFolder;
            
        if (_obj != null)
        {
            if (attrIds == null)
            {
                PropertyBag _props = _obj.getPropertyBag();
                _attrs = MMUtilities.propertyBagToAttributes(_props);
            }
            else
            {
                _attrs = new BasicAttributes();
                for (int i=0; i<attrIds.length; i++)
                {
                    Property _prop = _obj.getProperty(attrIds[i]);
                    if (_prop != null)
                        _attrs.put(attrIds[i], _prop.getObjValue());
                }
            }
        }
        else
            _attrs = new BasicAttributes();
            
        return _attrs;
*/
        return null;
    }

    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException
    {
        PropertyBag _bag = new PropertyBag();
        _bag.setStrPropertyValue(MM.PATH, fullPath);
        MDObject _obj = m_MetadataManagerServices.getMDObject(_bag, true);
        if(_obj instanceof MDFolder)
            return (MDFolder)_obj;
        return null;
    }
    
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attributes, String bindOption, Hashtable env) throws MetadataManagerException
    {
        String path = folder.getPath();
        if(name != null && name.size() > 0)
            path = path + '/' + name.toString();
        return null;
    }
    
    public Object lookup(MDFolder folder, Name name, Hashtable args, Attributes options) throws MetadataManagerException
    {
        if(folder != null && name != null)
        {
            String _path = MMUtilities.composePath(folder, name.toString());
            PropertyBag _bag = new PropertyBag();
            _bag.setStrPropertyValue(MM.PATH, _path);
           return m_MetadataManagerServices.getMDObject(_bag, true);
/*
            if(_mdObj != null && MMUtilities.isMDM(_mdObj))
                return _mdObj;
            else {
                try {
                    String sessionID = m_connection.getLogonToken().getStringToken();
                    String _url = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SAW_URL) + CB.SOAP_WEBCATALOG;
                    String request = SOAPUtility.getRequestHeader("getItemInfo") + 
                                     SOAPUtility.getParameter("path", _path) +
                                     SOAPUtility.getParameter("resolveLinks", "true") +
                                     SOAPUtility.getParameter("sessionID", sessionID) +
                                     SOAPUtility.getRequestFooter("getItemInfo");
                    XMLDocument _xmlDoc = SOAPUtility.parseXML(SOAPUtility.executeRequest(_url, request));
                    if(isFolder(_xmlDoc))
                        return m_factory.createMDFolder(folder, _xmlDoc.getElementsByTagName("return").item(0));
                    else {
                        request = SOAPUtility.getRequestHeader("readObject") + 
                                  SOAPUtility.getParameter("path", _path) +
                                  SOAPUtility.getParameter("resolveLinks", "true") +
                                  SOAPUtility.getParameter("sessionID", sessionID) +
                                  SOAPUtility.getRequestFooter("readObject");
                        _xmlDoc = SOAPUtility.parseXML(SOAPUtility.executeRequest(_url, request));
                        return createPersistable(_xmlDoc);
                    }
                }
                catch(Exception e) {
                    
                }
            }
*/
        }
        return null;

    }
/*
    private void removeEmptyFolders(MDFolder folder)
    {
        if(folder != null && MMUtilities.isMDM(folder))
        {
            MDObject[] _children = m_MetadataManagerServices.getChildrenFromIndex(folder);
            if(_children != null && _children.length > 0)
            {
                for(int i=0; _children != null && i<_children.length; i++)
                {
                    if(MM.FOLDER.equals(_children[i].getObjectType()) ||
                       MM.ROOT.equals(_children[i].getObjectType()) )
                    {
                        removeEmptyFolders((MDFolder)_children[i]);
                    }
                }
            }
            else
            {
                Vector _vec = folder.getDriverTypes();
                if(_vec != null && _vec.size() == 1 && MM.SBA.equals(_vec.elementAt(0)))
                {
                    MDObject _grandParent = null;
                    try
                    {
                        _grandParent = folder.getParent();
                    }
                    catch(MetadataManagerException e) {}
                    if(_grandParent != null)
                        _grandParent.removeChild(folder);
                }
            }
        }
    }
*/    

    public Object getObject(String id, Hashtable env) throws MetadataManagerException
    {
        PropertyBag _bag = new PropertyBag();
        _bag.setStrPropertyValue(MM.UNIQUE_ID, id);
        _bag.setStrPropertyValue(MM.DRIVER_TYPE, MM.SBA);
        Object _obj = m_MetadataManagerServices.getMDObject(_bag, true);
/*
        if(_obj == null && id != null) {
            try {
                String sessionID = m_connection.getLogonToken().getStringToken();
                String _path = MMUtilities._extractID(id).replace('.', '/');
                String _url = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SAW_URL) + CB.SOAP_WEBCATALOG;
                String request = SOAPUtility.getRequestHeader("getItemInfo") + 
                                 SOAPUtility.getParameter("path", _path) +
                                 SOAPUtility.getParameter("resolveLinks", "true") +
                                 SOAPUtility.getParameter("sessionID", sessionID) +
                                 SOAPUtility.getRequestFooter("getItemInfo");
                XMLDocument _xmlDoc = SOAPUtility.parseXML(SOAPUtility.executeRequest(_url, request));
                if(isFolder(_xmlDoc))
                    return m_factory.createMDFolder(m_MetadataManagerServices.getMDRoot(), _xmlDoc.getElementsByTagName("return").item(0));
                else {
                    request = SOAPUtility.getRequestHeader("readObject") + 
                              SOAPUtility.getParameter("path", _path) +
                              SOAPUtility.getParameter("resolveLinks", "true") +
                              SOAPUtility.getParameter("sessionID", sessionID) +
                              SOAPUtility.getRequestFooter("readObject");
                    _xmlDoc = SOAPUtility.parseXML(SOAPUtility.executeRequest(_url, request));
                    _obj = createPersistable(_xmlDoc);
                }
            }
            catch(Exception e) {
                
            }
        }
*/
        return _obj;
    }
    
    public void refresh(MDObject mdObject) throws MetadataManagerException
    {
    }

    public Vector listAssociates(MDFolder mdFolder, Name relativeSourceName, String[] attrsToReturn, Attribute identifier) throws MetadataManagerException
    {
        return null;
    }

    public void setObjectInstanceClassName(String type, String clsName)
    {
        
    }

    public MDItemFolder[] getJoinableItemFolders(MDFolder folder, MDItemFolder itemFolder, boolean searchSubContext)
    {
        return null;
    }
    
    private Attributes getAttributes(String name, String label, String type, String path, String uniqueID) {
        BasicAttributes _attrs = new BasicAttributes();
        if(name != null)
            _attrs.put(MM.OBJECT_NAME, name);
        if(label != null)
            _attrs.put(MM.OBJECT_LABEL, label);
        if(type != null)
            _attrs.put(MM.OBJECT_TYPE, type);
        if(path != null)
            _attrs.put(MM.PATH, path);
        if(uniqueID != null)
            _attrs.put(MM.UNIQUE_ID, uniqueID);
        return _attrs;
    }
/*    
    private boolean isFolder(XMLDocument xmlDoc) {
        NodeList _nList = xmlDoc.getElementsByTagName("type");
        String _type = _nList.item(0).getFirstChild().getNodeValue();
        return "Folder".equals(_type);
    }
    
    private Persistable createPersistable(XMLDocument xmlDoc) throws Exception {
        NodeList _nList = xmlDoc.getElementsByTagName("catalogObject");
        String objXML = _nList.item(0).getFirstChild().getNodeValue();
        PersistableAttributes _psrAttrs = getPSRAttributes(xmlDoc.getElementsByTagName("itemInfo").item(0));
        
        Persistable _pers = new PersistableAdapter(_psrAttrs.getObjectType());
        _pers.setXMLAsString(objXML);
        _pers.setPersistableAttributes(_psrAttrs);
        return _pers;
    }

    private Attributes getAttributes(Node node) throws Exception {
        BasicAttributes _attrs = new BasicAttributes();
        Hashtable _attrTable = getAttrTable(node);
        for(Enumeration _enum = _attrTable.keys(); _enum.hasMoreElements();) {
            String _key = (String)_enum.nextElement();
            _attrs.put(_key, _attrTable.get(_key));
        }
        return _attrs;
    }

    private PersistableAttributes getPSRAttributes(Node node) throws Exception {
        PersistableAttributes _psrAttrs = new PersistableAttributes();
        Hashtable _attrTable = getAttrTable(node);
        for(Enumeration _enum = _attrTable.keys(); _enum.hasMoreElements();) {
            String _key = (String)_enum.nextElement();
            if(_key.equals(PSRConstants.Attributes.OBJECT_FULLPATH_NAME))
                _psrAttrs.setFullPath((String)_attrTable.get(_key));
            else if(_key.equals(PSRConstants.Attributes.OBJECT_NAME))
                _psrAttrs.setObjectName((String)_attrTable.get(_key));
            else if(_key.equals(PSRConstants.Attributes.OBJECT_TYPE))
                _psrAttrs.setObjectType((String)_attrTable.get(_key));
            else if(_key.equals(PSRConstants.Attributes.TIME_DATE_MODIFIED))
                _psrAttrs.setTimeDateModified((Date)_attrTable.get(_key));
            else if(_key.equals(PSRConstants.Attributes.TIME_DATE_CREATED))
                _psrAttrs.setTimeDateCreated((Date)_attrTable.get(_key));
            else if(_key.equals(PSRConstants.Attributes.TIME_DATE_LAST_ACCESSED))
                _psrAttrs.setTimeDateLastAccessed((Date)_attrTable.get(_key));
        }
        return _psrAttrs;
    }
    
    private Hashtable getAttrTable(Node node) throws Exception {
        Hashtable table = new Hashtable();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        NodeList _nList = node.getChildNodes();
        for(int i=0; i<_nList.getLength(); i++) {
            String nodeName = _nList.item(i).getNodeName();
            if("path".equals(nodeName)) {
              String path = _nList.item(i).getFirstChild().getNodeValue();
              table.put(PSRConstants.Attributes.OBJECT_FULLPATH_NAME, path);
              table.put(MM.UNIQUE_ID, MMUtilities._makeUniqueID(getDriverType(), path.replace('/', '.')));
            }
            else if("caption".equals(nodeName))
              table.put(PSRConstants.Attributes.OBJECT_NAME, _nList.item(i).getFirstChild().getNodeValue());
            else if("type".equals(nodeName))
              table.put(PSRConstants.Attributes.OBJECT_TYPE, _nList.item(i).getFirstChild().getNodeValue());
            else if("lastModified".equals(nodeName)) {
              String date = _nList.item(i).getFirstChild().getNodeValue();
              date = date.substring(0, date.length()-1);
              table.put(PSRConstants.Attributes.TIME_DATE_MODIFIED, dateFormat.parse(date));
            }
            else if("created".equals(nodeName)) {
              String date = _nList.item(i).getFirstChild().getNodeValue();
              date = date.substring(0, date.length()-1);
              table.put(PSRConstants.Attributes.TIME_DATE_CREATED, dateFormat.parse(date));
            }
            else if("accessed".equals(nodeName)) {
              String date = _nList.item(i).getFirstChild().getNodeValue();
              date = date.substring(0, date.length()-1);
              table.put(PSRConstants.Attributes.TIME_DATE_LAST_ACCESSED, dateFormat.parse(date));
            }
        }
        return table;
    }
    
    private Vector browseCatalog(MDFolder mdFolder, Name name) throws Exception {
        Vector _vec = new Vector();
        String _path = mdFolder.getPath();
        if(name != null && name.size() > 0)
            _path = _path + '/' + name.toString();

        String sessionID = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SESSION_ID);
        String url = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SAW_URL) + CB.SOAP_WEBCATALOG;

        String request = SOAPUtility.getRequestHeader("getSubItems") + 
                         SOAPUtility.getParameter("path", _path) +
                         SOAPUtility.getParameter("mask", "*") +
                         SOAPUtility.getParameter("resolveLinks", "true") +
                         SOAPUtility.getComplexParameter("options", new String[][] {{"filter", "null"},{"includeACL", "true"},{"withPermission", "null"},{"withPermissionMask", "null"},{"withAttributes", "null"},{"withAttributesMask","null"}}) +
                         SOAPUtility.getParameter("sessionID", sessionID) +
                         SOAPUtility.getRequestFooter("getSubItems");

        String result = SOAPUtility.executeRequest(url, request);
        XMLDocument xmlDoc = SOAPUtility.parseXML(result);
        NodeList _nList = xmlDoc.getElementsByTagName("itemInfo");
        for(int i=0; i<_nList.getLength(); i++) {
            Attributes _attrs = getAttributes(_nList.item(i));
            MetadataManagerSearchResultImpl _msr = new MetadataManagerSearchResultImpl((String)_attrs.get(MM.OBJECT_NAME).get(), _attrs.get(MM.UNIQUE_ID).get(), _attrs, false, (String)_attrs.get(MM.OBJECT_TYPE).get(), m_MetadataManagerServices);
            _msr.setFullPathName((String)_attrs.get(PSRConstants.Attributes.OBJECT_FULLPATH_NAME).get());
            _msr.setDriverType(getDriverType());
            _vec.add(_msr);
        }
        return _vec;
    }
    
    public MDFolder createSubcontext(MDFolder folder) throws MetadataManagerException {
        String path = folder.getPath();
        try {
            String sessionID = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SESSION_ID);
            String url = m_connectionDriver.getConnectionPropertyBag().getStrPropertyValue(CB.SAW_URL) + CB.SOAP_WEBCATALOG;
            String request = SOAPUtility.getRequestHeader("createFolder") + 
                             SOAPUtility.getParameter("path", path) +
                             SOAPUtility.getParameter("createIfNotExists", "true") +
                             SOAPUtility.getParameter("sessionID", sessionID) +
                             SOAPUtility.getRequestFooter("createFolder");
      
            String result = SOAPUtility.executeRequest(url, request);
            System.out.println(result);
        }
        catch(Exception e) {e.printStackTrace();}
        return folder;
    }
*/
    // checks whether name is null
    private void checkNullName(String name) throws NamingException
    {
        if (name == null)
          throw new BIInvalidNameException(MetadataManagerCommonBundle.class, MetadataManagerCommonBundle.EXC_INVALID_NAME, new String[]{name}, getLocale(), null);
    }

    public class NameParserImpl implements NameParser, java.io.Serializable
    {
        public Name parse(String name) throws NamingException
        {
            checkNullName(name);
            Properties syntax = new Properties();
  
            syntax.put("jndi.syntax.direction", "left_to_right");
            syntax.put("jndi.syntax.separator", "/");
  
            return new CompoundName(name, syntax);
        }
    }
}
