/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/DataFilterChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    bmoroze     07/28/05 - bmoroze_bicommon050726
    bmoroze     07/26/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/DataFilterChangedEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.datautil;

import oracle.dss.selection.dataFilter.BaseDataFilter;

/**
 * Describes the event that carries new data filter information
 * to <code>QueryEditor</code> clients.
 *
 * @status Documented
 */
public class DataFilterChangedEvent extends QueryEditorInstanceEvent
{    
    /**
     * Constructs the event.
     *
     * @param source The object that fired this event. (Note: This object can be
     *               the same <code>QueryEditor</code> object that is referenced
     *               by the parameter <code>qa</code>. It is also possible that
     *               this <code>source</code> parameter could be a higher level
     *               object (such as a <code>QueryAccessBundle</code> class that
     *               you might create) and the parameter
     *               <code>qa</code> could be a <code>QueryEditor</code> object
     *               that was contained within the higher level object.)
     * @param df     The changed data filters.
     * @param olddf  The previous data filters.
     * @param instance The instance number that changed
     * @param qe     The <code>QueryEditor</code> object that gives access
     *               to cursor
     *
     * @status New
     * @hidden
     */
     public DataFilterChangedEvent(QueryEditor qe, BaseDataFilter[] df, BaseDataFilter[] olddf, int instance)
     {
        super(qe, instance);
        
        m_df = df;
        m_oldDF = olddf;
    }
        
    /**
     * Retrieves the changed <code>DataFilter</code> objects.
     * 
     * @return The changed <code>DataFilter</code> objects.
     */
    public BaseDataFilter[] getDataFilters() {
        return m_df;
    }

    /**
     * Retrieves the <code>DataFilters</code> that were set before the change.
     * 
     * @return The previous <code>DataFilter</code> objects.
     */
    public BaseDataFilter[] getPreviousDataFilters() {
        return m_oldDF;
    }

            
    /**
     * @hidden
     *
     * @serial DataFilter that changed
     */
    protected BaseDataFilter[] m_df = null;

    /**
     * @hidden
     *
     * @serial previous set of DataFilters (before change)
     */
    protected BaseDataFilter[] m_oldDF = null;
    
    
}
