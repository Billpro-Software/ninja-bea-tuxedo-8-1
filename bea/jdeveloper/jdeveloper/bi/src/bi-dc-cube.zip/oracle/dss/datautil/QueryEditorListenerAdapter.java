/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/QueryEditorListenerAdapter.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

import oracle.dss.dataSource.common.CellOverriddenEvent;
import oracle.dss.dataSource.common.CellOverridingEvent;
import oracle.dss.dataSource.common.CellsSubmittedEvent;
import oracle.dss.dataSource.common.CellsSubmittingEvent;
import oracle.dss.dataSource.common.ColumnSortChangedEvent;
import oracle.dss.dataSource.common.ColumnSortChangingEvent;
import oracle.dss.dataSource.common.DataAvailableEvent;
import oracle.dss.dataSource.common.DataChangedEvent;
import oracle.dss.dataSource.common.DataChangingEvent;
import oracle.dss.dataSource.common.DataFilterChangingEvent;
import oracle.dss.dataSource.common.DimensionalityChangedEvent;
import oracle.dss.dataSource.common.DrillRequestedEvent;
import oracle.dss.dataSource.common.DrillRequestingEvent;
import oracle.dss.dataSource.common.ItemDrillRequestedEvent;
import oracle.dss.dataSource.common.ItemDrillRequestingEvent;
import oracle.dss.dataSource.common.ItemSortChangedEvent;
import oracle.dss.dataSource.common.ItemSortChangingEvent;
import oracle.dss.dataSource.common.LayoutChangedEvent;
import oracle.dss.dataSource.common.LayoutChangingEvent;
import oracle.dss.dataSource.common.NullStatusEvent;
import oracle.dss.dataSource.common.SelectionChangingEvent;
import oracle.dss.dataSource.common.StateChangedEvent;
import oracle.dss.dataSource.common.StateChangingEvent;
import oracle.dss.dataSource.common.UndoAvailableEvent;

/**
 * Listener for events that users of a <code>QueryEditor</code> object may want
 * to respond to.
 *
 * @status Documented
 */
public class QueryEditorListenerAdapter implements QueryEditorListener {
  
  /**
   * Called when either the available selection or the selected
   * selection of a <code>QueryEditor</code> object is changed with a
   * resulting change in the corresponding DataAccess cursor.
   *
   * @param e The SelectionChangedEvent, which gives access to the new
   *          selection.
   *
   * @status Documented
   */
   // blm - Selection code moved to dvt-olap
/*  public void selectionChanged(SelectionChangedEvent e){};*/
  
  /**
   * Called when both a selection change occurs in one of the
   * <code>DataAccess</code> cursors of a <code>QueryEditor</code> and a
   * client requests the changed cursor. In a <code>QueryEditor</code>, there
   * are the following cursors:
   * <ul>
   * <li>available selection cursor</li>
   * <li>selected selection cursor</li>
   * </ul>
   *
   * @param e The DataAccessChangedEvent that gives access to the new
   *          <code>DataAccess</code> object.
   *
   * @status Documented
   */
  public void dataAccessChanged(DataAccessChangedEvent e){};
  
  /**
   * Called when the dimensionality of a <code>QueryEditor</code> has
   * changed.
   *
   * @param e The DimensionsChangedEvent, which describes the dimensionality
   *          change.
   *
   * @status Documented
   */
  public void dimensionsChanged(DimensionsChangedEvent e){};    
  
  /**
   * Called when the main item/measure list of a <code>QueryEditor</code>
   * has changed.
   * 
   * @param e The ItemsChangedEvent, which describes the item list change.
   * 
   * @status New
   */
  public void itemsChanged(ItemsChangedEvent e){};
  
  /**
   * Called when a data filter changes 
   * 
   * @param e The DataFilterChanged event, which describes the change.
   * 
   * @status New
   */
  public void dataFilterChanged(DataFilterChangedEvent e){};

  /**
   * Event fired to inform listeners that the given QueryEditor requires polling to retrieve data using 
   * the QueryEditor calls getStatus and possibly fireEvents.
   * 
   * @param polling Event informing listener of data needing polling
   */
  public void pollingRequired(PollingRequiredEvent polling){};    

    /**
     * Responds when data, metadata, or both data and metadata are available or
     * revoked.
     * 
     * This event cannot be consumed.
     *
     * @param dataAvailableEvent A <code>DataAvailableEvent</code>
     *
     * @status Documented
     */
    public void dataAvailable (DataAvailableEvent dataAvailableEvent) {};

    /**
     * Responds when data, metadata, or both data and metadata have changed.
     * This event cannot be consumed.
     *
     * @param dataChangedEvent A <code>DataChangedEvent</code>
     *
     * @status Documented
     */
    public void dataChanged (DataChangedEvent dataChangedEvent) {};

    /**
     * Responds when an operation will change data if it succeeds.
     * This event cannot be consumed.
     *
     * @param e DataChangingEvent
     *
     * @status Documented
     */
    public void dataChanging(DataChangingEvent e) {};
    
    /**
     * Responds when the dimensionality of a <code>Query</code> object changes.
     * This event cannot be consumed.
     *
     * @param e DimensionalityChangedEvent
     *
     * @status Documented
     */
    public void dimensionalityChanged(DimensionalityChangedEvent e) {};
    
    /**
     * Responds when a drill has been executed.
     * This event is fired after the drill operation executes.
     * This event cannot be consumed.
     *
     * @param e DrillRequestedEvent
     *
     * @status needs change
     */
    public void drillRequested(DrillRequestedEvent e) {};
    
    /**
     * Responds when a drill has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     *
     * @param e DrillRequestingEvent
     *
     * @status Documented
     */
    public void drillRequesting(DrillRequestingEvent e) {};
    
    /**
     * Responds when a layout change has been executed.
     * This event is fired after the layout change executes.
     * This event cannot be consumed.
     *
     * @param layoutChangedEvent LayoutChangedEvent
     *
     * @status needs change
     */
    public void layoutChanged (LayoutChangedEvent layoutChangedEvent) {};
    
    /**
     * Responds when a layout change has been requested.
     * A listener can veto this event by calling its
     * <code>consume</code> method.
     *
     * @param e LayoutChangingEvent
     *
     * @status Documented
     */
    public void layoutChanging (LayoutChangingEvent layoutChangingEvent) {};
    
    /**
     * Responds when one or more of the edges of a <code>Query</code> object
     * evaluate to null.
     *
     * @param e NullStatusEvent
     *
     * @status Documented
     */
    public void nullStatus (NullStatusEvent e) {};
    
    /**
     * Responds when a selection has been changed.
     * This event is fired after the actual selection and query are changed.
     * This event cannot be consumed.
     *
     * @param e SelectionChangedEvent
     *
     * @status needs change
     */
    public void selectionChanged (oracle.dss.dataSource.common.SelectionChangedEvent e) {};
    
    /**
     * Responds when a selection has been requested to change.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e SelectionChangingEvent
     *
     * @status Documented
     */
    public void selectionChanging (SelectionChangingEvent e) {};
    
    /**
     * Responds when the state of the <code>Query</code> object has been
     * asked to change through the use of the undo mechanism.
     *
     *
     * @param e StateChangingEvent
     *
     * @status Documented
     */
    public void stateChanging (StateChangingEvent e) {};
    
    /**
     * Responds when the state of the <code>Query</code> object has been changed
     * through the use of the undo mechanism.
     *
     * @param e StateChangedEvent
     *
     * @status Documented
     */
    public void stateChanged (StateChangedEvent e) {};
    
    /**
     * Responds when a new undoable edit is available for a <code>Query</code>
     * object.
     *
     * @param e UndoAvailableEvent
     *
     * @status Documented
     */
    public void undoAvailable (UndoAvailableEvent e) {};
    
    /**
     * Responds when the data in a cell is about to be overwritten.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e CellOverridingEvent
     *
     * @status Documented
     */
    public void cellOverriding (CellOverridingEvent e) {};
    
    /**
     * Responds when the data in a cell has been overwritten.
     *
     * @param e CellOverriddenEvent
     *
     * @status Documented
     */
    public void cellOverridden (CellOverriddenEvent e) {};
    
    /**
     * Responds when changes to the data in cells are about to be submitted for
     * update in the database.
     * A listener can veto this event by calling its <code>consume</code>
     * method.
     *
     * @param e CellsSubmittingEvent
     *
     * @status Documented
     */
    public void cellsSubmitting (CellsSubmittingEvent e) {};
    
    /**
     * Responds when changes to the data in cells have been submitted for
     * update in the database.
     *
     * @param e CellsSubmittedEvent
     *
     * @status Documented
     */
    public void cellsSubmitted (CellsSubmittedEvent e ) {};

    /**
     * Responds when a total has been changed.
     * This event is fired after the actual total and query are changed.
     * This event cannot be consumed.
     *
     * @param e TotalChangedEvent
     *
     * @status new
     */
     // blm - Selection code moved to dvt-olap
/*    public void totalChanged (TotalChangedEvent e) {};*/
    
    /**
     * Responds when a total has been requested to change or is changing
     * due to a layout change.
     * A listener can veto this event by calling its <code>consume</code>
     * method.  A listener can alter the TotalSteps sent to the Query
     * by changing the TotalSteps in the event object.
     *
     * @param e TotalChangingEvent
     *
     * @status New
     */
     // blm - Selection code moved to dvt-olap
/*    public void totalChanging(TotalChangingEvent e) {};*/
    
    // javadoc from interface
    public void dataFilterChanged(oracle.dss.dataSource.common.DataFilterChangedEvent e) {};
    
    // javadoc from interface
    public void dataFilterChanging(DataFilterChangingEvent e) {};
    
    // javadoc from interface
    public void queryPollingRequired(oracle.dss.util.PollingRequiredEvent e) {};
    
    // javadoc from interface
    public void columnSortChanging(ColumnSortChangingEvent e) {};
    
    // javadoc from interface
    public void columnSortChanged(ColumnSortChangedEvent e) {};    
    
    // javadoc from interface
    public void itemSortChanging(ItemSortChangingEvent e) {};
    
    // javadoc from interface
    public void itemSortChanged(ItemSortChangedEvent e) {};

    // javadoc from interface    
    public void itemDrillRequesting(ItemDrillRequestingEvent e) {};

    // javadoc from interface    
    public void itemDrillRequested(ItemDrillRequestedEvent e) {};
}