/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if the <code>Query</code> object catches an OLAP API Exception.
 *
 * @status Documented
 */
public class OLAPException extends QueryException
{
    /**
     * Error while creating an OLAP API cursor.
     *
     * @status Documented
     */
    public static final int CREATE_CURSOR   = 0;
    
    /**
     * Error while running SPL.
     *
     * @status Documented
     */
    public static final int SPL_FAILURE     = 1;

    /**
     * Error while dealing with transactions.
     *
     * @status Documented
     */
    public static final int TRANSACTION_ERROR   = 2;
    
    /**
     * Error while dealing with connecting to the database.
     *
     * @status Documented
     */
    public static final int COULD_NOT_CONNECT = 3;

    /**
     * The call to the database was interrupted, probably by a call to cancel().
     *
     * @status New
     */
    public static final int INTERRUPTED = 4;

    /**
     * @hidden
     * @serial Type of OLAPI error
     */
    protected int m_errType = -1;
    
    /**
     * @hidden
     * @serial OLAPI error description information
     */
    protected String m_description = null;
    
    /**    
     * Constructor.
     *
     * @param s  Message to display.
     * @param et Error type
     * @param e  Previous exception to carry (may be null).
     *
     * @status Documented
     */
    public OLAPException(String s, int et, Throwable e)
    {
        super(s + System.getProperty("line.separator") + e.toString(), e);
        m_errType = et;        
    }
            
    /**
     * Retrieves the type of OLAP API error that was caught.
     *
     * @return Enumerated type that describes the type of OLAP API error.
     *
     * @status Documented
     */
    public int getErrorType()
    {
        return m_errType;
    }    
}