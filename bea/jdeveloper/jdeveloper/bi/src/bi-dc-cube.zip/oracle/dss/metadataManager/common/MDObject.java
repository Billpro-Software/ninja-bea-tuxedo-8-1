/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.metadataManager.common;

// Imports
import java.util.Enumeration;
import java.util.Vector;
import java.util.Hashtable;

import oracle.dss.metadataManager.common.resource.MetadataManagerCommonBundle;

import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.OrderedHashtable;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.metadataUtil.UserObjectBag;

import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.persistence.XMLizable;
import oracle.dss.util.xml.BIParseException;
import oracle.dss.util.xml.ContainerNode;
import oracle.dss.util.xml.NoSuchPropertyException;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.PropertyNode;
import oracle.dss.util.xml.XMLObjectReader;
import oracle.dss.util.xml.XMLObjectWriter;

/****************************************************
 * The MDObject class
 ****************************************************/
/**
 * A client-side representation of an object in an analytic workspace or in
 * the BI Beans Catalog.
 * Subclasses of this class indicate the kind of object that is being
 * represented.
 * An <code>MDObject</code> is analogous to a <code>Context</code> in JNDI.
 *
 * @status Reviewed
 */
public class MDObject extends PropertyBag implements XMLizable {
    /************************************************************************
    * Private members
    ************************************************************************/
    // Parent MDObject
    //private transient MDObject m_Parent = null;
    protected MDObject m_Parent = null;

    // Holds all MDObject children
    private transient MDContentBag m_Children = null;

    // Holds all MDObjects related to this objects
    private transient MDContentBag m_Relatives = null;

    // Holds all User Objects
    private UserObjectBag m_UserObjects = null;

    // Holds parent ID
    private long m_ParentID = MDU.ILLEGAL_LONG_VALUE;

    // Holds children ID
    private OrderedHashtable m_ChildrenID;

    // Holds relatives ID
//    private OrderedHashtable m_RelativesID;

    // Holds dependent objects.
    private OrderedHashtable m_DependentsID;

    // MetadataManagerServices reference
    private transient MetadataManagerServices m_MetadataManagerServices = null;

    // Initial children and relative bag size
    private int m_InitSize = 11;

    // Store referenced mdObjects. e.g. annotation measure
    private transient Hashtable m_referencedObjs;

    // Store referenced object ids
    private Hashtable m_referencedObjIDs;
    
    private Object m_ds;
    /************************************************************************
    * Public Methods
    ************************************************************************/
   	/**
     * Constructor.
     *
     * @status Reviewed
     */
    public MDObject(){
/*
        m_Children      = new MDContentBag( m_InitSize );
//        m_Relatives     = new MDContentBag( m_InitSize );
        m_UserObjects   = new UserObjectBag();
        m_referencedObjs = new Hashtable(3);
        m_referencedObjIDs = new Hashtable(3);

        m_ChildrenID    = new OrderedHashtable( m_InitSize );
//        m_RelativesID   = new OrderedHashtable( m_InitSize );
        m_DependentsID 	= new OrderedHashtable( m_InitSize );
*/
        _setBoundStatus( MM.NOT_BOUND );
    }

   	/**
     * Constructor.
     *
     * @param mmServices   The <code>MetadataManagerServices</code> that this
     *                     root folder exists in.
     * @param mdObjName    The name of this object.
     * @param parent       The object that contains this object.
     *
     * @status Documented
     */
    public MDObject( MetadataManagerServices mmServices, String mdObjName, MDObject parent ) {
        this();
        m_MetadataManagerServices = mmServices;
        setName( mdObjName );
        setParent( parent );
    }

    protected final String DATA_TYPE_PROP = "dataTypeProp";
    protected final String PROP_VALUE_PROP = "propValueProp";
    protected final String PROP_LIST = "PropertyList";
    
    // XMLizable interface
    public Object getXML(XMLContext context)
    {        
        ObjectNode root = new ObjectNode(PersistableConstants.XMLNS + ":" + getTagName());
        root.addProperty("xmlns:"+PersistableConstants.XMLNS, PersistableConstants.XMLNS_URL);

        // Do all the properties in the property bag
        ContainerNode bigContainer = new ContainerNode(PersistableConstants.XMLNS + ":" + PROP_LIST);
        Property[] props = super.getProperties();
        if (props != null)
        {
            int dataType = -1;
            String propName = null;
            ObjectNode containerNode = null;
            ObjectNode propNode = null;
            for (int i = 0; i < props.length; i++)
            {
                dataType = props[i].getDataType();
                propName = PersistableConstants.XMLNS + ":" + getXMLizablePropName(props[i].getName());
                propNode = new ObjectNode(propName);
                propNode.addProperty(DATA_TYPE_PROP, dataType);
                switch (dataType)
                {
                    case MDU.STRING:
                        propNode.addProperty(PROP_VALUE_PROP, props[i].getStrValue());
                        bigContainer.addContainedObject(propNode);
                        break;
                    case MDU.INTEGER:                    
                        propNode.addProperty(PROP_VALUE_PROP, props[i].getIntValue());
                        bigContainer.addContainedObject(propNode);
                        break;
                    case MDU.LONG:
                        propNode.addProperty(PROP_VALUE_PROP, props[i].getLongValue());
                        bigContainer.addContainedObject(propNode);
                        break;
                    case MDU.STRING_VECTOR:
                        containerNode = new ObjectNode(propName);
                        Vector<String> value = (Vector<String>)props[i].getStringVectorValue();
                        if (value != null)
                        {
                            int size = value.size();
                            for (int v = 0; v < size; v++)
                                containerNode.addProperty("Value"+v, value.elementAt(v));
                        }
                        propNode.addProperty(PROP_VALUE_PROP, containerNode);
                        bigContainer.addContainedObject(propNode);                    
                        break;
                    default:
                        break;
                }
            }
        }
        root.addContainer(bigContainer);
        return root;        
    }

    protected final String DATA_TYPE = "data_type";
    protected final String UNIQUE_ID = "unique_id";
    protected final String DRIVER_TYPE = "driver_type";
    protected final String BOUND_STATUS = "bound_status";
    protected final String LONG_LABEL = "long_label";
    protected final String SHORT_LABEL = "short_label";
    
    protected final String XML_PROP_TABLE[][] = {{MM.DATA_TYPE, DATA_TYPE},
                                                 {MM.UNIQUE_ID, UNIQUE_ID},
                                                 {MM.DRIVER_TYPE, DRIVER_TYPE},
                                                 {MM.BOUND_STATUS, BOUND_STATUS},
                                                 {MM.SHORT_LABEL, SHORT_LABEL},
                                                 {MM.LONG_LABEL, LONG_LABEL}};
        
    protected String getXMLizablePropName(String propName)
    {
        for (int i = 0; i < XML_PROP_TABLE.length; i++)
            if (propName.equals(XML_PROP_TABLE[i][0]))
                return XML_PROP_TABLE[i][1];
        return propName;
    }
    
    
    protected String getRealPropName(String xmlPropName)
    {
        int indexOf = xmlPropName.indexOf(":");
        xmlPropName = xmlPropName.substring(indexOf+1);
        for (int i = 0; i < XML_PROP_TABLE.length; i++)
            if (xmlPropName.equals(XML_PROP_TABLE[i][1]))
                return XML_PROP_TABLE[i][0];
        return xmlPropName;
    }
    
    public void setXML(XMLContext context, Object node)
    {        
        ObjectNode objNode = (ObjectNode)node;

        ContainerNode bigContainer = objNode.getContainer(PersistableConstants.XMLNS + ":" + PROP_LIST);
        String propName = null;
        ObjectNode pn = null;
        Object value = null;
        int dataType = -1;      
        Enumeration props = bigContainer.getContainedObject();
        while (props.hasMoreElements())
        {
            pn = (ObjectNode)props.nextElement();
            if (pn != null)
            {
                propName = getRealPropName(pn.getName());
                try
                {
                    dataType = pn.getPropertyValueAsInteger(DATA_TYPE_PROP);
                    switch (dataType)
                    {
                        case MDU.STRING:
                            setStrPropertyValue(propName, pn.getPropertyValueAsString(PROP_VALUE_PROP), MDU.UI_ALL);
                            break;
                        case MDU.INTEGER:                    
                            setIntPropertyValue(propName, pn.getPropertyValueAsInteger(PROP_VALUE_PROP), MDU.UI_ALL);
                            break;
                        case MDU.LONG:
                            setLongPropertyValue(propName, pn.getPropertyValueAsLong(PROP_VALUE_PROP), MDU.UI_ALL);
                            break;
                        case MDU.STRING_VECTOR:
                            ObjectNode vals = pn.getPropertyValueAsObjectNode(PROP_VALUE_PROP);
                            Enumeration valProps = vals.getPropertyNames();
                            String valPropName = null;
                            Vector<String> objValues = new Vector<String>();
                            while (valProps.hasMoreElements())
                            {
                                valPropName = (String)valProps.nextElement();
                                objValues.addElement(vals.getPropertyValueAsString(valPropName));
                            }
                            setStringVectorPropertyValue(propName, objValues);
                            break;
                        default:
                            break;                
                    }
                }
                catch (NoSuchPropertyException noSuchPropertyException)
                {
                }
            }
        }
    }

    public String getTagName()
    {
        return getObjectType();
    }
        
    public String getXMLAsString() throws BIPersistenceException
    {
        String _xml = null;
        try
        {
            XMLObjectWriter _xmlWriter = new XMLObjectWriter();
            XMLContext context = new XMLContext();
            _xmlWriter.writeObjectNode((ObjectNode)getXML(context));
            _xml = _xmlWriter.toString();
        }
        catch (oracle.dss.util.xml.BIIOException ioe)
        {
            throw new BIPersistenceException(ioe.getMessage(), (Exception)ioe.getPreviousException());
        }
        return _xml;
    }

    
    /**
     * @hidden
     */
    public boolean setXMLAsString(String xml) throws BIPersistenceException
        {
       try
        {
            XMLObjectReader _xmlReader = new XMLObjectReader(xml);
            
            ObjectNode _node = _xmlReader.readObjectNode();
            XMLContext context = new XMLContext();            
            setXML(context, _node);
            return true;
        }
        catch (BIParseException bipe)
        {
            //If there is an exception here, the XML is incorrect
            throw new BIPersistenceException(bipe.getMessage(), (Exception)bipe.getPreviousException());
        }
        catch (oracle.dss.util.xml.BIXMLException xmle2)
        {
            throw new BIPersistenceException(xmle2.getMessage(), (Exception)xmle2.getPreviousException());
        }
    }
        
    /**
     * @hidden
     * Set BOUND_STATUS of MDObject.  Default value is NOT_BOUND.
     *
     * @param boundStatus   Can be set to one of the following constants.
     *                      <code>MM.BOUND</code> set BOUND_STATUS to BOUND
     *                      <code>MM.NOT_BOUND</code> set BOUND_STATUS to
     *                                                NOT_BOUND
     * @see MM#BOUND
     * @see MM#NOT_BOUND
     *
     * @status hidden
     */
    public void _setBoundStatus( int boundStatus ){
        setIntPropertyValue( MM.BOUND_STATUS, boundStatus, MDU.UI_ALL );
    }

    /**
     * @hidden
     * Retrieves the bind status of this object.
     *
     * @return  A constant that indicates whether this object is bound.
     *          Valid constants are listed in the See Also section.
     *
     * @see MM#BOUND
     * @see MM#NOT_BOUND
     *
     * @status hidden
     */
    public int getBoundStatus(){
        return getIntPropertyValue( MM.BOUND_STATUS );
    }
    	
    private boolean containsUniqueID(Property property)
    {
        String strValue = property.getStrValue();
        if (strValue != null)
        {
/*        
            String strID = MMUtilities._extractID(strValue);

            Property newProperty = new Property();
            newProperty.setStrValue(MMUtilities._getUniqueDriverConstant(strValue), strID, MDU.UI_ALL);
*/
            // If the current unique id matches, then return immediately.
            if (super.contains(property)) {
                return true;
            }
/*
            //Otherwise, loop over all available driver types and search for a match.
            Vector _dVec = getDriverTypes();
            if(_dVec != null)
            {
                for(Enumeration e=_dVec.elements(); e.hasMoreElements(); )
                {
                    newProperty.setStrValue(MMUtilities._getUniqueDriverConstant((String)e.nextElement()), strID, MDU.UI_ALL);
                    if (super.contains(newProperty)) {
                        return true;
                    }
                }
            }
            else
            {
                if(m_MetadataManagerServices != null)
                {
                    m_MetadataManagerServices.getErrorHandler().log(getName() + " has no driverType set on it.", getClass().getName(), "containsUniqueID");
                }
            }
*/
        }
        return false;
    }
	
    /**
     * @hidden
     * Indicates whether this object has the specified property.
     *
     * @param property  The property that you want to check to see if this
     *                  object has.
     *
     * @return   <code>true</code> if this object has <code>property</code>,
     *           <code>false</code> if this object does not have the property.
     *
     * @status hidden
     */
	public boolean contains(Property property) {
		// If the key MM.UNIQUE_ID is found, replace it with the driver
		// specific constant (i.e. MM.MDM) and the id.
		if (property != null) {
			String strName = property.getName();
			if ( (strName != null) && (strName.equals(MM.UNIQUE_ID)) ) {
				return containsUniqueID(property);
			}
		}
		return super.contains(property);
	}

    /**
     * Specifies the <code>MetadataManagerServices</code> for this object.
     * Before you call this method, this object has a <code>null</code>
     * <code>MetadataManagerServices</code>.
     *
     * @param metadataManagerServices  The implementation of
     *            <code>MetadataManagerServices</code> for this object.
     *
     * @return      A constant that indicates whether the
     *              <code>MetadataManagerServices</code> was successfully set.
     *              The valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Reviewed
     */
    public int setMetadataManagerServices( MetadataManagerServices metadataManagerServices ) {
        m_MetadataManagerServices = metadataManagerServices;
/*
        if(m_Parent != null)
        {
            m_Parent.setMetadataManagerServices(metadataManagerServices);
        }
*/
        return MDU.SUCCESS;
    }

    /**
     * Retrieves the <code>MetadataManagerServices</code> in this object.
     *
     * @return  The implementation of <code>MetadataManagerServices</code>
     *          that this object uses, or <code>null</code> if no
     *         <code>MetadataManagerServices</code> implementation has been
     *          set for this object.
     *
     * @status Reviewed
     */
    public MetadataManagerServices getMetadataManagerServices() {
        return m_MetadataManagerServices;
    }

    /**
     * @hidden
     * Checks if mdObject's children bag is empty.
     *
     * @return      <code>true</code> mdObject's m_Children bag is empty
     *              <code>false</code> mdObject's m_Children bag is not empty
     *
     * @status hidden
     */
    public boolean isChildrenBagEmpty() {
        if ( ( m_Children == null ) || ( m_Children.size() == 0 ) )
            return true;
        return false;
    }

    /**
     * @hidden
     * Checks if mdObject's m_Children bag is complete.
     *
     * @return      <code>true</code> mdObject's m_Children is complete
     *              <code>false</code> mdObject's m_Children is not complete.
     * @status hidden
     */
    public boolean isChildrenBagComplete() {
        if( getChildrenStatus() == MM.NOT_COMPLETE ) {
            return false;
        }
        if ( ( m_Children != null ) && (m_ChildrenID != null) && ( m_Children.size() != m_ChildrenID.size() ) ) {
            return false;
        }
        return true;
    }

    /**
     * @hidden
     * Checks if mdObject has children.
     *
     * @return      <code>true</code> mdObject has children.
     *              <code>false</code> mdObject has no children.
     * @status hidden
     */
    public boolean hasChildren() {
        return (m_ChildrenID != null && m_ChildrenID.size() != 0);
    }

    /**
     * @hidden
     * Retrieve the count of children in m_Children.
     *
     * @return      Count of children in m_Children.
     *
     * @status hidden
     */
    public int getChildrenBagCount() {
        if( m_Children != null ) {
            return m_Children.size();
        }
        return 0;
    }

    /**
     * @hidden
     * Retrieve the count of children.
     *
     * @return      count of children for MDObject.
     *
     * @status hidden
     */
    public int getChildrenCount() {
        return (m_ChildrenID != null)? m_ChildrenID.size() : 0;
    }

    /**
     * @hidden
     * Checks if m_Relatives bag is empty.
     *
     * @return      <code>true</code> m_Relative bag is empty
     *              <code>false</code> m_Relative bag is not empty.
     *
     * @status hidden
     */
    public boolean isRelativesBagEmpty() {
        if ( ( m_Relatives == null ) || ( m_Relatives.size() == 0 ) )
            return true;
        return false;
    }

    /**
     * @hidden
     * Check if m_Relatives bag is complete.
     *
     * @return      <code>true</code> m_Relatives bag is complete
     *              <code>false</code> m_Relatives bag is not complete
     * @status hidden
     */
    public boolean isRelativesBagComplete() {
        if( getRelativeStatus() == MM.NOT_COMPLETE )
            return false;
//        if ( ( m_Relatives != null ) && ( m_Relatives.size() != m_RelativesID.size() ) )
//            return false;
        return true;
    }

    /**
     * @hidden
     * Checks if mdObject has relatives.
     *
     * @return      <code>true</code> mdObject has relatives.
     *              <code>false</code> mdObject has no relatives.
     * @status hidden
     */
    public boolean hasRelatives() {
//        return (m_RelativesID.size() != 0);
        return (m_Relatives != null && m_Relatives.size() != 0);
    }

    /**
     * @hidden
     * Retrieve the count of relatives in m_Relatives.
     *
     * @return      Count of relatives in m_Relatives.
     *
     * @status hidden
     */
    public int getRelativesBagCount() {
        if( m_Relatives != null )
            return m_Relatives.size();

        return 0;
    }

    /**
     * @hidden
     * Retrieve the count of relatives in m_RelativesID.
     *
     * @return      count of relatives in m_RelativesID.
     *
     * @status hidden
     */
    public int getRelativesCount() {
//        return m_RelativesID.size();
        return (m_Relatives != null)? m_Relatives.size() : 0;
    }

    /**
     * @hidden
     * Retrieves the number of <code>UserObject</code> objects that this
     * object has.
     * The number that this method returns does not count any
     * <code>UserObjects</code> in the cache.
     *
     * @return      The number of <code>UserObjects</code> in this
     *              <code>MDObject</code>.
     *
     * @see oracle.dss.metadataUtil.UserObject
     *
     * @status hidden
     */
    public int getUserObjectCount() {
        return (m_UserObjects != null)? m_UserObjects.size() : 0;
    }

    /**
     * @hidden
     * Retrieve object ID of this MDObject
     *
     * @return      int representing ObjectID.
     *
     * @status hidden
     */
    public long getObjectID(){
        return (getLongPropertyValue(MM.OBJECT_ID));
    }

    /**
     * @hidden
     * Set object ID of this MDObject.  The ID should be obtained from
     * generateMDObjectID() method on MetadataManager Bean.
     *
     * @param       ObjectID.
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @status hidden
     */
    public int setObjectID( long objectID ){
        setLongPropertyValue(MM.OBJECT_ID, objectID, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the metadata ID that is specified in OLAP Services for this
     * object.
     *
     * @return      The OLAP Services ID.
     *
     * @status hidden
     */
    public String getOLAPIMetadataID(){
        return (getStrPropertyValue(MM.OLAPI_METADATA_ID));
    }

    /**
     * @hidden
     * Set OLAPIMetadataID of this MDObject.
     *
     * @param       String representing OlapiMetadataID
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setOLAPIMetadataID( String strOLAPIMetadataID ){
        setStrPropertyValue(MM.OLAPI_METADATA_ID, strOLAPIMetadataID, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the runtime ID that is specified for this object in
     * OLAP Services.
     *
     * @return      The OLAP Services runtime ID for this object.
     *
     * @status hidden
     */
    public String getOLAPIRuntimeID(){
        return (getStrPropertyValue(MM.OLAPI_RUNTIME_ID));
    }

    /**
     * @hidden
     * Set OLAPIRuntimeID of this MDObject.
     *
     * @param       String representing OlapiRuntimeID
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setOLAPIRuntimeID( String strOLAPIRuntimeID ){
        setStrPropertyValue(MM.OLAPI_RUNTIME_ID, strOLAPIRuntimeID, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the runtime IDs that are specified for this object in
     * OLAP Services.
     *
     * @return    All of the runtime IDs for this object.
     *
     * @status hidden
     */
    public Vector getOLAPIRuntimeIDs()
        {
        return ((Vector)getStringVectorPropertyValue(MM.OLAPI_RUNTIME_IDS));
        }

    /**
     * @hidden
     * gek 12/04/00 Set vector of Olapi Runtime IDs
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setOLAPIRuntimeIDs (Vector vOLAPIRuntimeIDs)
    {
        if(m_MetadataManagerServices != null)
            m_MetadataManagerServices.setMDObjectInCacheByOLAPIRunID(this, vOLAPIRuntimeIDs);

        setStringVectorPropertyValue (MM.OLAPI_RUNTIME_IDS, vOLAPIRuntimeIDs, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the runtime ID that is set for this object by the persistence
     * service.
     *
     * @return     The persistence runtime ID.
     *
     * @status hidden
     */
    public String getPersistenceRuntimeID(){
        return (getStrPropertyValue(MM.PERSISTENCE_RUNTIME_ID));
    }

    /**
     * @hidden
     * Set persistence RuntimeID
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setPersistenceRuntimeID( String strPersitenceRuntimeID ){
        setStrPropertyValue(MM.PERSISTENCE_RUNTIME_ID, strPersitenceRuntimeID, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves a unique ID for this object.
     * The ID is based on the type of driver that this object uses.
     *
     * @param  strDriverType The type of driver that this object uses.
     *          You can call the <code>getDriverType</code> to get this value.
     *
     * @return   A unique ID for this object. Returns <code>null</code> if
     *           <code>strDriverType</code> is <code>null</code>.
     *
     * @see #getDriverType
     *
     * @status hidden
     */
    public String getUniqueID(String strDriverType) {
        Vector _idVec = getStringVectorPropertyValue(MM.UNIQUE_ID);
        String _id = null;
        if(_idVec != null && strDriverType != null)
        {
            for(int i=0; i < _idVec.size() && ((_id=(String)_idVec.elementAt(i)) != null) && !_id.startsWith(strDriverType); i++);
            if(_id != null && !_id.startsWith(strDriverType)) 
                _id = null;
        }
        return _id;
    }

    /**
     * Retrieves a unique ID for this object.
     * The ID is based on the type of driver that this object uses.
     *
     * @return   A unique ID for this object.
     *
     * @status Reviewed
     */
    public String getUniqueID() {
    	return getUniqueID(getDriverType());
    }

    /**
     * @hidden
     */
    public boolean isAncestor( String uniqueID ) throws MetadataManagerException {
        if ( uniqueID == null )
            return true;
        MDObject mdParent = getParent();
        while ( mdParent != null ) {
            if ( uniqueID.equals ( mdParent.getUniqueID() ))
                return true;
            mdParent = mdParent.getParent();
        }
        return false;
    }

    /**
     * Retrieves the path of this object.
     * The path name includes the name of this object.
     * For metadata, the path name is structured as follows:
     * <P>
     * <code>service_name!workspace_name\root_folder_name\subfolder_name\object_name</code>
     * <P>
     * For objects in the repository, the path name is structured as follows:
     * <P>
     * <code>/subfolder/object_name</code>
     * <P>
     *
     * @return  The path of this object.
     *
     * @status Reviewed
     */
	public String getPath() {
		return (getStrPropertyValue(MM.PATH));
	}

    /**
     * @hidden
     */
	public int setPath( String strPath ){
		setStrPropertyValue(MM.PATH, strPath, MDU.UI_ALL);
		return MDU.SUCCESS;
	}

    /**
     * Retrieves the description of this object.
     * This method returns the value of the Description property of this
     * object.
     *
     * @return   The description of this object.
     *
     * @status Reviewed
     */
	public String getDescription() {
		return (getStrPropertyValue(MM.DESCRIPTION));
	}

    /**
     * @hidden
     * Set object description
     * @param strDescription      String representing Object description
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
	public int setDescription( String strDescription ){
		setStrPropertyValue(MM.DESCRIPTION, strDescription, MDU.UI_ALL);
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Retrieve String type
     * @return      StringType
     *
     * @status hidden
     */
    public String getStringType() {
        return (getStrPropertyValue(MM.STRING_TYPE));
    }

    /**
     * @hidden
     * Set String type
     *
     * @param strDescription      String representing Object description
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setStringType( String strStringType ){
        setStrPropertyValue(MM.STRING_TYPE, strStringType, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * Retrieves all of the driver types for this object.
     * A calculation can have more than one kind of driver.
     * Most components that you save will have only one.
     *
     * @return   The driver types for this object.
     *
     * @status Reviewed
     */
    public Vector getDriverTypes() {
    	return getStringVectorPropertyValue(MM.DRIVER_TYPE);
    }

    /**
     * Retrieves the type of driver that this object uses.
     *
     * @return   The type of driver for this object.
     *
     * @status Reviewed
     */
    public String getDriverType() {
    	Vector driverTypes = getDriverTypes();
    	if (driverTypes != null) {
    		return (String)driverTypes.firstElement();
    	}
    	return null;
    }

    /**
     * Specifies the type of driver that this object requires.
     *
     * @param strDriverType The type of driver.
     *                      For components, pass <code>MDU.PERSISTENCE_DRIVER</code>.
     *
     * @return      A constant that indicates whether the driver was successfully
     *              set. Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     * @see oracle.dss.metadataUtil.MDU#PERSISTENCE_DRIVER
     * @see oracle.dss.metadataUtil.MDU#MDM_DRIVER
     *
     * @status Reviewed
     */
    public int setDriverType(String strDriverType) {
    	Vector driverTypes = getStringVectorPropertyValue(MM.DRIVER_TYPE);
    	if (driverTypes == null) {
    		driverTypes = new Vector();
    	}
    	if (!driverTypes.contains(strDriverType)) {
    		driverTypes.addElement(strDriverType);
    	}
    	
    	setStringVectorPropertyValue(MM.DRIVER_TYPE, driverTypes, MDU.UI_ALL);
    	return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieves the objects that contain an object, up to and including
     * the root folder?
     * The specified object is the last element in the array.
     *
     * @param mdObject The object whose containers to retrieve.
     * @param depth  The number of containers that this object has?
     *
     * @return  An array of all of the objects that contain <code>MDObject</code>.
     *
     * @status hidden
     */
	public MDObject[] getPathToRoot(MDObject mdObject, int depth) throws MetadataManagerException {
		MDObject[] retNodes;

		/* Check for null, in case someone passed in a null node, or
		   they passed in an element that isn't rooted at root. */
		if(mdObject == null) {
		    if(depth == 0)
			return null;
		    else
			retNodes = new MDObject[depth];
		}
		else {
		    depth++;
		    retNodes = getPathToRoot(mdObject.getParent(), depth);
		    retNodes[retNodes.length - depth] = mdObject;
		}
		return retNodes;
	}

    /**
     * @hidden
     * Retrieve parent of this mdObject.
     *
     * @throws      MetadataManagerException.
     *
     * @return      parent of this mdObject.  Null is returned if mdObject is root.
     *
     * @status hidden
     */
    public MDObject getParent() throws MetadataManagerException {
        if(m_Parent == null && m_ParentID != MDU.ILLEGAL_LONG_VALUE) {
            if(m_MetadataManagerServices != null) {
                m_Parent = m_MetadataManagerServices.getMDObjectByID( m_ParentID );
            }
        }
        return m_Parent;
    }

    /**
     * @hidden
     * Retrieve parent of this mdObject.
     *
     * @return      int representing parent id.
     *
     * @status hidden
     */
    public long getParentID(){
        return m_ParentID;
    }

    /**
     * @hidden
     * Specifies the object that contains this object.
     *
     * @param parent The object that contains this object.
     *
     * @return          A constant that indicates whether the container
     *                 was successfully set. The valid constants are
     *                 listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
	public int setParent( MDObject parent ){
		if ( parent == null ) {
			return MDU.FAILURE;
		}
		m_Parent = parent;
        m_ParentID = parent.getObjectID();

    setPath(MMUtilities.composePath(parent, toString()));
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Fill the m_children.  This method goes across the wire to get children if
     * needed.
     *
     * @status hidden
     */
    private void fillChildrenBag( int depth ) throws MetadataManagerException {
    /*
        if(m_ChildrenID == null)
            return;
    */
    if(true)
      return;
        if(MM.MEASURE.equals(getObjectType()))
            return;
        
        if(m_Children  == null)
          m_Children = new MDContentBag( m_InitSize );

        if(m_ChildrenID == null)
          m_ChildrenID = new OrderedHashtable( m_InitSize );

        if( !isChildrenBagComplete() || depth > 1 || depth == -1 ) {
            if ( m_MetadataManagerServices == null ) {
                return;
            }
            //m_Children.setContentTable( m_MetadataManagerServices.getChildrenTable( this, m_ChildrenID, depth ) );

            MetadataManagerServices _mm = m_MetadataManagerServices;
            OrderedHashtable table = m_MetadataManagerServices.getChildrenTable( this, m_ChildrenID, depth );
            m_MetadataManagerServices = _mm;
            if( table != null ) {
                Enumeration enumer = table.keys();
                while( enumer.hasMoreElements() ) {
                    MDObject obj = (MDObject)enumer.nextElement();
                    obj.setMetadataManagerServices( m_MetadataManagerServices );
                    m_ChildrenID.put( new Long(obj.getObjectID()), table.get(obj) );
                }
                m_Children.setContentTable( table );
            }

            if(getDriverTypes() != null)
                for(Enumeration _enum = getDriverTypes().elements(); _enum.hasMoreElements();)
                    setChildrenStatus((String)_enum.nextElement(), MM.COMPLETE);

        }
        else
        {
            Enumeration _enum = m_Children.keys();
            while(_enum.hasMoreElements())
            {
                MDObject obj = (MDObject)_enum.nextElement();
                obj.setMetadataManagerServices(m_MetadataManagerServices);
            }
        }
    }

    /**
     * @hidden
     * Fill the m_Relatives.  This method goes across the wire to get relatives
     * if needed.
     *
     * @status private
     */
    private void fillRelativesBag() throws MetadataManagerException{
/*
        try{
            m_Relatives.keys();
        }
        catch( Throwable e ) {
            m_Relatives = new MDContentBag( m_InitSize );
        }
*/
        if( !isRelativesBagComplete() ) {
            if ( m_MetadataManagerServices == null ){
                return;
            }
            //m_Relatives.setContentTable( m_MetadataManagerServices.getRelativeTable( this, m_RelativesID ) );
/*
            OrderedHashtable table = m_MetadataManagerServices.getRelativeTable( this, m_RelativesID );
            if( table != null ) {
                Enumeration enumer = table.keys();
                while( enumer.hasMoreElements() ) {
                    MDObject obj = (MDObject)enumer.nextElement();
                    obj.setMetadataManagerServices( m_MetadataManagerServices );
                    m_RelativesID.put( new Long(obj.getObjectID()), table.get(obj) );
                }
                m_Relatives.setContentTable( table );
            }
*/
            // this will make sure that the relative bag is complete.
            try{m_MetadataManagerServices.getMDObject(MM.UNIQUE_ID, "MDM!LEVEL", MM.LEVEL);} catch(Exception e){}
            setRelativeStatus(MM.COMPLETE);
            //m_Relatives.setContentTable( table );
        }
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @return  MDObject array containing children. Null, if mdObject has no children.
     *
     * @status hidden
     */
    public MDObject[] getChildren() throws MetadataManagerException {
        fillChildrenBag( 1 );
        return (m_Children != null)? getMDObjectArray (  m_Children.getContents() ) : null;
    }

    /**
     * @hidden
     * Retrieve first child, if there is one, of this mdObject.
     *
     * @param relation      String representing the relation of child with mdObject
     * @return              First child. Null, if mdObject has no children.
     *
     * @status hidden
     */
    public MDObject getFirstChild(String relation) throws MetadataManagerException {
        if(!isChildrenBagComplete())
            fillChildrenBag( 1 );
/*
        OrderedHashtable _table = m_Children.getContentTable();
        for(Enumeration _enum = _table.keys(); _enum.hasMoreElements();)
        {   
            MDObject _tmp = (MDObject)_enum.nextElement();
            if(_tmp != null && _table.get(_tmp).equals(relation))
                return _tmp;
        }
*/
        if(m_Children != null)
        {
            OrderedHashtable _table = m_Children.getContentTable();
            for(Enumeration _enum = _table.keys(); _enum.hasMoreElements();)
            {   
                MDObject _tmp = (MDObject)_enum.nextElement();
                if(_tmp != null && _table.get(_tmp).equals(relation))
                    return _tmp;
            }
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param strRelation   String representing the relation of child with mdObject
     * @param propertyBag   Properties that a child must have to be the one we want.
     * @return              MDObject array containing children. Null is returned if
     *                      mdObject has no children or no child with strRelation
     *                      and properties in propertyBag exist.
     * @status hidden
     */
    public MDObject[] getChildren(String strRelation, PropertyBag propertyBag)
                                                throws MetadataManagerException
    {
        if( strRelation == null || propertyBag == null )
            return null;
        MDObject[] objects = getChildren( strRelation );
        if( objects == null || objects.length == 0 )
            return null;

        Vector mdVec = new Vector();
        Property[] properties = propertyBag.getProperties();
        for( int i = 0; i < objects.length; i++ ) {
            int j;
            MDObject tempMDObject = objects[i];
            // loop through all properties in propertyBag and break the loop if
            // a property does not exist in tempMDObject
            for( j = 0; j < properties.length && tempMDObject.contains( properties[j] ); j++ );
            // if j == properties.length, all properties in propertyBag existed
            // in tempMDObject so add it to mdVec.
            if( j == properties.length ){
                mdVec.addElement( tempMDObject );
            }
        }
        if( mdVec.size() != 0 ) {
            MDObject[] mdObjects = new MDObject[mdVec.size()];
            mdVec.copyInto( mdObjects );
            return mdObjects;
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param relation      String representing the relation of child with mdObject
     * @return              MDObject array containing children. Null is returned if
     *                      mdObject has no children or no child with strRelation
     *                      exists.
     * @status hidden
     */
	public MDObject[] getChildren( String relation ) throws MetadataManagerException {
        fillChildrenBag( 1 );
		return (m_Children != null)? getMDObjectArray (m_Children.getContents( relation )) : null;
	}

    /**
     * @hidden
     * Check if a child exists that contain properties in propertyBag.
     *
     * @param propertyBag   Properties that a child must have to be the one we want.
     * @return              <code>true</code> if a child with propertyBag is found.
     *                      <code>false</code> if a child with propertyBag is not found.
     * @status hidden
     */
    public boolean hasChild(PropertyBag propertyBag)
                                            throws MetadataManagerException
    {
    	MDObject[] mdObjects = getChildren(propertyBag);
    	if ( (mdObjects != null) && (mdObjects.length > 0) ) {
    		return true;
    	}
    	return false;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param propertyBag   Properties that a child must have to be the one we want.
     * @return              MDObject array containing children. Null is returned if
     *                      mdObject has no children or no child with properties in
     *                      propertyBag exists.
     * @status hidden
     */
    public MDObject[] getChildren (PropertyBag propertyBag) throws MetadataManagerException {
        if( propertyBag == null || propertyBag.size() == 0 )
            return null;

        if( !hasChildren() ) {
            return null;
        }

        fillChildrenBag( 1 );
        Vector vec = new Vector();
        Property[] propertyArray = propertyBag.getProperties();
        Enumeration enumer = m_Children.keys();
        MDObject tempMDObject = null;
        while( enumer.hasMoreElements() ) {
            tempMDObject = (MDObject)enumer.nextElement();
            int i;
            // For tempMDObject to be eqaul to propertyBag, it should contain
            // all properties in propertyBag
            for( i = 0; i < propertyArray.length && tempMDObject.contains( propertyArray[i] ); i++ );
            // if i == propertyArray.length then all properties existed in tempMDObject
            if( i == propertyArray.length )
                vec.addElement( tempMDObject );
        }
        if( vec.size() != 0 ) {
            MDObject[] mdObjects = new MDObject[vec.size()];
            vec.copyInto( mdObjects );
            return mdObjects;
        }
		return null;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param propertyBag   Properties that a child must have to be the one we want.
     * @param depth         depth of object model underneath this mdObject.
     * @return              MDObject array containing immediate children. Null is returned
     *                      if mdObject has no children or no child with properties in
     *                      propertyBag exists.
     * @status hidden
     */
    public MDObject[] getChildren (PropertyBag propertyBag, int depth) throws MetadataManagerException {
        if( propertyBag == null || propertyBag.size() == 0 )
            return null;
        if(!hasChildren())
            return null;
            
        fillChildrenBag( depth );
        MDObject[] childrenArray = getMDObjectArray (  m_Children.getContents() );
        if( childrenArray == null || childrenArray.length == 0 )
            return null;

        Vector childrenVec = new Vector();
        Property[] propertyArray = propertyBag.getProperties();
        for( int i = 0; i < childrenArray.length; i++ ) {
            // For childrenArray[i] to be eqaul to propertyBag, it should contain
            // all properties in propertyBag
            int j;
            for( j = 0; j < propertyArray.length && childrenArray[i].contains( propertyArray[j] ); j++ );
            // if j == propertyArray.length then all properties existed in childrenArray[i]
            if( j == propertyArray.length ){
                childrenVec.addElement( childrenArray[i] );
            }
        }

        if( childrenVec.size() != 0 ) {
            MDObject[] mdObjects = new MDObject[childrenVec.size()];
            childrenVec.copyInto( mdObjects );
            return mdObjects;
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param property      Property that a child must have to be the one we want.
     * @return              MDObject array containing children. Null is returned
     *                      if mdObject has no children or no child with a property
     *                      exists.
     * @status hidden
     */
 	public MDObject[] getChildren (Property property) throws MetadataManagerException {
        fillChildrenBag( 1 );
  	    return (m_Children != null)? getMDObjectArray (  m_Children.getContents(property) ) : null;
 	}

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param depth         depth of object model underneath this mdObject.
     * @return              MDObject array containing immediate children. Null is returned
     *                      if mdObject has no children or no child with property
     *                      exists.
     * @status hidden
     */
    public MDObject[] getChildren( int depth ) throws MetadataManagerException {
        fillChildrenBag( depth );
        return (m_Children != null)? getMDObjectArray (  m_Children.getContents() ) : null;
    }

    /**
     * @hidden
     * Retrieve children, if any, of this mdObject.
     *
     * @param relation      String representing the relation of child with mdObject
     * @param property      Property that a child must have to be the one we want.
     * @param depth         depth of object model underneath this mdObject.
     * @return              MDObject array containing immediate children. Null is returned
     *                      if mdObject has no children or no child with property
     *                      exists.
     * @status hidden
     */
    public MDObject[] getChildren( String relation, Property property, int depth ) throws MetadataManagerException {
        // Fill children bag till depth
        if( !hasChildren() ) {
            return null;
        }
        fillChildrenBag( depth );

        PropertyBag[] propertyBag = m_Children.getContents( relation, property );
        if( propertyBag == null ) {
            return null;
        }
        MDObject[] mdObjects = new MDObject[propertyBag.length];
        for( int i = 0; i < propertyBag.length; i++ ) {
            mdObjects[i] = (MDObject)propertyBag[i];
        }
        return mdObjects;
    }

    /**
     * @hidden
     * Determines whether the specified MDObject's name is equivalent to
     * this MDObject's name. Use this method to determine if the name of an 
     * MDObject from one driver is 
     * the same as the name of an MDObject from a different driver.
     * 
     * @param object The object that is to be compared to the current object
     *
     * @return <code>true</code>  if specified MDObject's name is equivalent
     *         <code>false</code> if specified MDObject's name is not equivalent
     *
     * @status hidden
     */
    public boolean nameEquals (MDObject object) {
    	if (object != null) {
   			return (this.getName().equals(object.getName()));
    	}
    	return false;
   	}
    
    /**
     * @hidden
     * Reset a child of this mdObject.
     *
     * @param mdObject      child that needs to be reset
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int resetChild ( MDObject mdObject ) {
        if( m_Children != null && m_Children.getContentTable().containsKey( mdObject ) ){
            String propertyName = null;
            if ( mdObject.getDriverType().equals ( MDU.MDM ) )
                propertyName = MM.OLAPI_METADATA_ID;
            else if ( mdObject.getDriverType().equals ( MDU.PERSISTENCE ) )
                propertyName = MM.REPOS_RUNTIME_ID;
            m_Children.resetContentItem ( mdObject, propertyName );
            return MDU.SUCCESS;
        }
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Reset relative of this mdObject.
     *
     * @param mdObject      Relative that needs to be reset
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int resetRelative ( MDObject mdObject ) {
        if( m_Relatives != null && m_Relatives.getContentTable().containsKey( mdObject ) ) {
            String propertyName = null;
            if ( mdObject.getDriverType().equals ( MDU.MDM ) )
                propertyName = MM.OLAPI_METADATA_ID;
            else if ( mdObject.getDriverType().equals ( MDU.PERSISTENCE ) )
                propertyName = MM.REPOS_RUNTIME_ID;
                m_Relatives.resetContentItem ( mdObject, propertyName );
            return MDU.SUCCESS;
        }
        return MDU.FAILURE;
    }

    /**
     * @hidden
     * Set child of this mdObject.
     *
     * @param mdObject      MDObject that needs to be set as child
     * @param relation      relation between this mdObject and child mdObject
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setChild( MDObject mdObject, String relation ){
        if( mdObject == null )
            return MDU.FAILURE;
        if( m_Children == null )
            m_Children = new MDContentBag();

        if( m_ChildrenID == null )
            m_ChildrenID = new OrderedHashtable();
        
        m_Children.setContentItem( mdObject, relation);
        m_ChildrenID.put( new Long( mdObject.getObjectID() ), relation );
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Remove child of this mdObject.
     *
     * @param mdObject      MDObject that needs to be removed
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int removeChild( MDObject mdObject ){
        if( mdObject == null ) {
            return MDU.FAILURE;
        }
        if( m_Children != null ) {
            m_Children.removeContentItem( mdObject );
        }

        if( m_ChildrenID != null ) {
            Long mdObjectID = new Long( mdObject.getObjectID() );
            m_ChildrenID.remove( mdObjectID );
        }

		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Remove all children of this mdObject.
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
	public int removeAllChildren(){
        if( m_Children != null )
		   m_Children.removeAll();

        if(m_ChildrenID != null)
            m_ChildrenID.clear();

		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Retrieve children bag of this mdObject.
     *
     * @return      m_Children is returned after it is filled.
     *
     * @status hidden
     */
	public MDContentBag getChildrenBag() throws MetadataManagerException {
        fillChildrenBag( 1 );
		return m_Children;
	}
    
    /**
     * @hidden
     * Retrieve m_childrenID of this mdObject.
     *
     * @return      Ordered hashtable of childrenIDs.
     *
     * @status hidden
     */
    public OrderedHashtable getChildrenID() {
        return m_ChildrenID;
    }

    /**
     * @hidden
     * @status hidden
     */
    public void setChildrenID(OrderedHashtable ids) 
    {
        m_ChildrenID = ids;
    }

    /**
     * @hidden
     * Set m_Children and m_ChildrenID of this mdObject.
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @status hidden
     */
    public int setChildrenBag( MDContentBag childrenBag ){
        m_Children = childrenBag;

        if( m_Children != null ) {
            if(m_ChildrenID == null)
                m_ChildrenID = new OrderedHashtable();

            OrderedHashtable contentHashtable = m_Children.getContentTable();
            Enumeration keys = contentHashtable.keys();
            Object obj;
            Long objLongID;
            while ( keys.hasMoreElements() ) {
                obj = (Object)keys.nextElement();
                objLongID = new Long( ((MDObject) obj).getObjectID() );
                m_ChildrenID.put( objLongID, contentHashtable.get( obj ) );

            }
        }
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Retrieve relatives, if any, of this mdObject.
     *
     * @return  MDObject[] containing relatives. Null, if mdObject has no relatives.
     *
     * @status hidden
     */
	public MDObject[] getRelatives() throws MetadataManagerException {
        fillRelativesBag();
		return (m_Relatives != null)? getMDObjectArray (  m_Relatives.getContents() ) : null;
	}

    /**
     * @hidden
     * Retrieve relatives, if any, of this mdObject.
     *
     * @param relation      String representing the relation of relative with mdObject
     * @return              MDObject array containing relatives. Null is returned if
     *                      mdObject has no relatives or a relative with strRelation
     *                      does not exists.
     * @status hidden
     */
	public MDObject[] getRelatives( String relation ) throws MetadataManagerException {
        fillRelativesBag();
		return (m_Relatives != null)? getMDObjectArray (  m_Relatives.getContents( relation ) ) : null;
	}

    /**
     * @hidden
     * Retrieve first relative, if there is one, of this mdObject.
     *
     * @param relation      String representing the relation between relative and mdObject
     * @return              First relative. Null, if mdObject has no children or a
     *                      relative of param-relation doesn't exist.
     * @status hidden
     */
    public MDObject getFirstRelative(String relation) throws MetadataManagerException {
        if(!isRelativesBagComplete())
            fillRelativesBag();

        if(m_Relatives == null)
            return null;
        OrderedHashtable _table = m_Relatives.getContentTable();
        for(Enumeration _enum = _table.keys(); _enum.hasMoreElements();)
        {   
            MDObject _tmp = (MDObject)_enum.nextElement();
            if(_tmp != null && _table.get(_tmp).equals(relation))
                return _tmp;
        }
        return null;
    }
    /**
     * @hidden
     * Retrieve first relative, if there is one, of this mdObject.
     *
     * @param property      Property that a relative should have to be the one we
     *                      are looking for.
     * @return              First relative. Null, if mdObject has no relative or a
     *                      relative with param-property doesn't exists.
     * @status hidden
     */
	public MDObject getFirstRelative(Property property) throws MetadataManagerException {
		MDObject[] objects = getRelatives(property);
		if ( (objects != null) && (objects.length > 0) ) {
			return objects[0];
		}
		return null;
	}

    /**
     * @hidden
     * Check if a relative that contains properties in propertyBag exists.
     *
     * @param propertyBag   Properties that a relative must have to be the one we want.
     * @return              <code>true</code> if a relative with propertyBag is found.
     *                      <code>false</code> if a relative with propertyBag is not found.
     * @status hidden
     */
    public boolean hasRelative(PropertyBag propertyBag) throws MetadataManagerException {
    	MDObject[] mdObjects = getRelatives(propertyBag);
    	if ( (mdObjects != null) && (mdObjects.length > 0) ) {
    		return true;
    	}
    	return false;
    }

    /**
     * @hidden
     * Retrieve relatives, if any, of this mdObject.
     *
     * @param propertyBag   Properties that a relative must have to be the one we want.
     * @return              MDObject array containing relatives. Null is returned if
     *                      mdObject has no relatives or no relative with properties in
     *                      propertyBag exists.
     * @status hidden
     */
    public MDObject[] getRelatives( PropertyBag propertyBag )  throws MetadataManagerException {
        if( propertyBag == null || propertyBag.size() == 0 )
            return null;

        if( !hasRelatives() ) {
            return null;
        }
        fillRelativesBag();
        Vector vec = new Vector();
        Property[] propertyArray = propertyBag.getProperties();
        Enumeration enumer = m_Relatives.keys();
        MDObject tempMDObject = null;
        while( enumer.hasMoreElements() ) {
            tempMDObject = (MDObject)enumer.nextElement();
            int i;
            // For tempMDObject to be eqaul to propertyBag, it should contain
            // all properties in propertyBag
            for( i = 0; i < propertyArray.length && tempMDObject.contains( propertyArray[i] ); i++ );
            // if i == propertyArray.length then all properties existed in tempMDObject
            if( i == propertyArray.length )
                vec.addElement( tempMDObject );
        }
        if( vec.size() != 0 ) {
            MDObject[] mdObjects = new MDObject[vec.size()];
            vec.copyInto( mdObjects );
            return mdObjects;
        }
        return null;
    }

    /**
     * @hidden
     * Retrieve relatives, if any, of this mdObject.
     *
     * @param property      Property that a relative must have to be the one we want.
     * @return              MDObject[] containing immediate relatives. Null is returned
     *                      if mdObject has no relatives or no relative with a property
     *                      exists.
     * @status hidden
     */
 	public MDObject[] getRelatives (Property property)  throws MetadataManagerException {
        fillRelativesBag();
    	return (m_Relatives != null)? getMDObjectArray (  m_Relatives.getContents(property) ) : null;
 	}

    /**
     * @hidden
     * Retrieve relative, if any, of this mdObject.
     *
     * @param relation      String representing the relation of relative with mdObject
     * @param property      Property that a relative must have to be the one we want.
     * @param depth         depth of object model underneath this mdObject.
     * @return              MDObject[] containing immediate relative. Null is returned
     *                      if mdObject has no relatives or no relative with property
     *                      exists.
     * @status hidden
     */
	public MDObject[] getRelatives( String relation, Property property, int depth)
                                                throws MetadataManagerException
    {
		// needs recursion here.
        fillRelativesBag();
		return (m_Relatives != null)? getMDObjectArray (  m_Relatives.getContents( relation, property) ) : null;
	}

    /**
     * @hidden
     * Set relative of this mdObject.
     *
     * @param mdObject      MDObject that needs to be set as relative
     * @param relation      relation between this mdObject and relative
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setRelative( MDObject mdObject, String relation ){
      if( mdObject == null )
        return MDU.FAILURE;
        
        if( m_Relatives == null )
            m_Relatives = new MDContentBag();

        m_Relatives.setContentItem( mdObject, relation);
//        m_RelativesID.put( new Long( mdObject.getObjectID() ), relation );
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Remove relative of this mdObject.
     *
     * @param mdObject      relative that needs to be removed
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
	public int removeRelative( MDObject mdObject ){
        if( mdObject == null ) {
            return MDU.FAILURE;
        }
        if( m_Relatives != null ) {
            m_Relatives.removeContentItem( mdObject );
        }
/*
        if( m_RelativesID != null ) {
            Long mdObjectID = new Long( mdObject.getObjectID() );
            m_RelativesID.remove ( mdObjectID );
        }
*/
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Remove all relatives of this mdObject.
     *
     * @return              A constant that represents success or failure.
     *                      The valid constants are:
     *                      <code>SUCCESS</code>
     *                      <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
	public int removeAllRelatives(){
        if( m_Relatives != null )
		   m_Relatives.removeAll();
/*
        if(m_RelativesID != null)
            m_RelativesID.clear();
*/
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Retrieve relative bag of this mdObject.
     *
     * @return      m_Relative is returned after it is filled.
     *
     * @status hidden
     */
	public MDContentBag getRelativesBag() throws MetadataManagerException {
        fillRelativesBag();
		return m_Relatives;
	}

    /**
     * @hidden
     * Set m_Relatives and m_RelativesID of this mdObject.
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setRelativesBag( MDContentBag RelativesBag ){
        if(RelativesBag == null || RelativesBag.size() == 0)
            return MDU.SUCCESS;
            
        if(m_Relatives == null)
        {
            m_Relatives = RelativesBag;
            return MDU.SUCCESS;
        }

        OrderedHashtable contentHashtable = RelativesBag.getContentTable();
        Enumeration keys = contentHashtable.keys();
        Object obj;
        Hashtable table = new Hashtable();
        while ( keys.hasMoreElements() ) {
            obj = (Object)keys.nextElement();
            if( obj instanceof MDObject ) {
                String _uniqueID = ((MDObject)obj).getUniqueID();
                if( table.containsKey( _uniqueID ) ) {
                    m_Relatives.removeContentItem( (PropertyBag)table.get(_uniqueID) );
                }
                else {
                    table.put(((MDObject)obj).getUniqueID(), obj);
                }
                m_Relatives.setContentItem((MDObject)obj, (String)contentHashtable.get( obj ));
            }
        }
        return MDU.SUCCESS;
    }

    /**
     * @hidden
     * Saves a <code>UserObject</code> of this <code>MDObject</code> and
     * places this object in the cache.
     * This object is stored in both the client-tier cache and in the
     * middle-tier cache.
     *
     * @param propertyBag   Properties of this object.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem storing
     *          the object on the server. For example, this exception is thrown
     *          if the caller does not have permission to write to the server.
     *
     * @return   This object, or <code>null</code> if there is no
     *           <code>MetadataManagerServices</code> set for this object.
     *
     * @see oracle.dss.metadataUtil.UserObject
     *
     * @status hidden
     */
    public MDObject setMDObject ( PropertyBag propertyBag ) throws MetadataManagerException {
        if( m_MetadataManagerServices == null ) {
            return null;
        }
        return m_MetadataManagerServices.setMDObject( this, MMUtilities.propertyBagToAttributes(propertyBag));
    }

    /************************************************************************
    * Support for User Objects ( for example XML object of Graph)
    * from the driver based on an MDObject.
    ************************************************************************/

    /**
     * @hidden
     * Retrieves the <code>UserObject</code> for this object.
     * If the user object is not available locally, then this method
     * attempts to retrieve the user object from the underlying driver.
     *
     * @param relation  The relationship between this object and its user object.
     * @param driverType  The type of driver that the user object uses.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @return  The <code>UserObject</code> for this object, or <code>null</code>
     *          if there is no <code>MetadataManagerServices</code> set for
     *          this object, or if <code>relation</code> or <code>driverType</code>
     *          is <code>null</code>.
     *
     * @status hidden
     */
    public UserObject getUserObject( String relation, String driverType ) throws MetadataManagerException {
        if( m_MetadataManagerServices == null || relation == null || driverType == null ){
            return null;
        }
        return m_MetadataManagerServices.getUserObject( this, relation, driverType  );
    }

    /**
     * @hidden
     * Retrieves the <code>UserObject</code> for this object.
     * If the user object is not available locally, then this method
     * attempts to retrieve the user object from the underlying driver.
     *
     * @param relation  The relationship between this object and its user object.
     * @param driverType  The type of driver that the user object uses.
     * @param args A hashtable that might contain objects that can help restore
     *             userObject on client side (reference resolver).
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @return  The <code>UserObject</code> for this object, or <code>null</code>
     *          if there is no <code>MetadataManagerServices</code> set for
     *          this object, or if <code>relation</code> or <code>driverType</code>
     *          is <code>null</code>.
     *
     * @status hidden
     */
    public UserObject getUserObject( String relation, String driverType, Hashtable args) throws MetadataManagerException {
        if( m_MetadataManagerServices == null || relation == null || driverType == null ){
            return null;
        }
        return m_MetadataManagerServices.getUserObject( this, relation, driverType, args );
    }

    /**
     * @hidden
     * Adds a <code>UserObject</code> to this object.
     *
     * @param relation  The relationship between this object and its user object.
     * @param userObject  The user object to add to this object.
     *
     * @status hidden
     */
    public void addUserObject( String relation, UserObject userObject ) {
        int cacheSemantic = userObject.getCacheSemantic();
        if((cacheSemantic == MDU.BOTH) && (m_MetadataManagerServices != null)) {
            if(m_UserObjects == null)
                m_UserObjects = new UserObjectBag();
            m_MetadataManagerServices._addUserObject( this, userObject, relation );
            m_UserObjects.setUserObject( relation, userObject );
        }
        else if( (cacheSemantic == MDU.CLIENT_ONLY) && (m_MetadataManagerServices != null)
                    && (m_MetadataManagerServices.isBeanClass())) {
            m_MetadataManagerServices._addUserObject( this, userObject, relation );
        }
        else if( (cacheSemantic == MDU.SERVER_ONLY) && (m_MetadataManagerServices != null)
                    && !(m_MetadataManagerServices.isBeanClass())) {
            m_MetadataManagerServices._addUserObject( this, userObject, relation );
        }
        else {
            if(m_UserObjects == null)
                m_UserObjects = new UserObjectBag();
            m_UserObjects.setUserObject( relation, userObject );
        }
    }

    /**
     * @hidden
     * Removes userObject from the m_UserObjects of this mdObject.
     *
     * @param relation      String representing relation between mdObject and userObject.
     *
     * @status hidden
     */
    public void removeUserObject( String relation ){
        if(m_UserObjects != null)
            m_UserObjects.removeUserObject( relation );
    }

    /**
     * @hidden
     * @status hidden
     */
    public UserObject getUserObject( String relation ){
        return (m_UserObjects != null)? m_UserObjects.getUserObject( relation ) : null;
    }

    /**
     * @hidden
     * Retrieves the <code>UserObject</code> from its driver and updates
     * the copy of the user object in the local cache.
     *
     * @param relation  The relationship between this object and its user object.
     * @param driverType The type of driver that the user object uses.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @status hidden
     */
    public void refreshUserObject( String relation, String driverType ) throws MetadataManagerException {
        if( m_MetadataManagerServices != null ) {
            m_MetadataManagerServices.refreshUserObject( this, relation, driverType );
        }
    }

/*
    public int setUserObject( UserObject userObject, String relation, String driverType ) {
        if( m_MetadataManagerServices == null ){
            return MDU.FAILURE;
        }
        int isSuccess = MDU.FAILURE;
        try{
            isSuccess = m_MetadataManagerServices.setUserObject( this, userObject, relation, driverType );
        } catch( MetadataManagerException e ){
            e.printStackTrace();
        }
        return isSuccess;
    }

    public int removeUserObject( String relation, String driverType ) {
        if( m_MetadataManagerServices == null ){
            return MDU.FAILURE;
        }
        int isSuccess = MDU.FAILURE;
        try{
            isSuccess = m_MetadataManagerServices.removeUserObject( this, relation, driverType );
        } catch( MetadataManagerException e ){
            e.printStackTrace();
        }
        return isSuccess;
    }

    public Object[] getObjects( Property property ){
        return m_UserObjects.getObjects( property );
    }

*/

    /**
     * @hidden
     * Retrieves an object that is significant to this object.
     *
     * @param relation The relationship between this object and the object
     *                 that you want to retrieve.
     *                 To retrieve the object from a <code>UserObject</code>,
     *                 pass <code>MM.PERSISTENCE_OBJECT</code>.
     *
     * @return The object.
     *
     * @see MM
     * @see oracle.dss.metadataUtil.UserObject
     *
     * @status hidden
     */
    public Object getObject( String relation ){
        if(m_UserObjects != null)
        {
            UserObject userObject = m_UserObjects.getUserObject( relation );
            if ( userObject != null )
                return userObject.getObject();
        }
        return null;
    }

    /**
     * @hidden
     * Retrieves the user objects that this object has.
     *
     * @return The user objects that this object has.
     *
     * @status hidden
     */
    public UserObject[] getUserObjects()
    {
        return (m_UserObjects != null)? m_UserObjects.getUserObjects() : null;
    }
/*
	public UserObject[] getUserObjects( Property property ){
		return m_UserObjects.getUserObjects( property );
	}
	public int setUserObject( String relation, UserObject userObject )
    {
        if (getDriverType() != null)
            userObject.setStrPropertyValue(MM.DRIVER_TYPE, getDriverType());
		m_UserObjects.setUserObject( relation, userObject);
		return MDU.SUCCESS;
	}

    public int setObject( String relation, Object object ){
        UserObject userObject = new UserObject();
        userObject.setObject ( object );
        m_UserObjects.setUserObject( relation, userObject);
        return MDU.SUCCESS;
    }
	public int removeUserObject( String relation ){
		m_UserObjects.removeUserObject( relation );
		return MDU.SUCCESS;
	}
*/
    /**
     * @hidden
     * Remove all UserObject from m_UserObjects of this mdObject.
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     * @status hidden
     */
	public int removeAllUserObjects(){
        if(m_UserObjects != null)
    		m_UserObjects.removeAll();
		return MDU.SUCCESS;
	}

    /**
     * @hidden
     * Retrieve UserObject bag of this mdObject.
     *
     * @return      Returns m_UserObjects of this mdObject.
     *
     * @status hidden
     */
	public UserObjectBag getUserObjectBag(){
		return m_UserObjects;
	}
/*
	public int setUserObjectBag( UserObjectBag userObjectBag ){
		m_UserObjects = userObjectBag;
		return MDU.SUCCESS;
	}
*/
    /**
     * Retrieves the short label of this object.
     *
     * @return  The short label of this object.
     *
     * @status Reviewed
     */
    public String getShortLabel() {
        String strLabel = getStrPropertyValue(MM.SHORT_LABEL);

        if ( (strLabel == null) || (strLabel.equals("")) ) {
            strLabel = getStrPropertyValue(MM.LONG_LABEL);
            if(strLabel == null || strLabel.equals(""))
                strLabel = getName();
        }
        return strLabel;
    }

    /**
     * @hidden
     * Retrieves the medium label of this object.
     *
     * @return  The medium label of this object.
     *
     * @status hidden
     */
  	public String getMediumLabel() {
  		String strLabel = getStrPropertyValue(MM.MEDIUM_LABEL);
  		if ( (strLabel == null) || (strLabel.equals("")) ) {
  			return getShortLabel();
  		}
  		return strLabel;
  	}

    /**
     * Retrieves the long label of this object.
     *
     * @return  The long label of this object.
     *
     * @status Reviewed
     */
  	public String getLongLabel() {
  		String strLabel = getStrPropertyValue(MM.LONG_LABEL);
  		if ( (strLabel == null) || (strLabel.equals("")) ) {
  			return getMediumLabel();
  		}
  		return strLabel;
  	}

    /**
     * @hidden
     * Set long label of this mdObject.
     *
     * @param longLabel     String representing long label.
     *
     * @status hidden
     */
  	public int setLongLabel(String longLabel) {
  		setStrPropertyValue(MM.LONG_LABEL, longLabel, MDU.UI_ALL);
  		return(MDU.SUCCESS);
  	}

    /**
     * @hidden
     * Set short label of this mdObject.
     *
     * @param shortLabel     String representing short label.
     *
     * @status hidden
     */
  	public int setShortLabel(String shortLabel) {
  		setStrPropertyValue(MM.SHORT_LABEL, shortLabel, MDU.UI_ALL);
  		return(MDU.SUCCESS);
  	}

    /**
     * Generates a <code>String</code> representation of this object.
     * This method returns the long label of this object.
     *
     * @return   The long label of this object.
     *
     * @status Reviewed
     */
    public String toString(){
    	return getShortLabel();
    }

    /**
     * Generates a <code>String</code> representation of this object.
     * This method returns the specified label.
     *
     * @param strLabelType  A constant that identifies the type of label
     *                      that you want.
     *                      Valid constants are listed in the See Also section.
     *
     * @return   The requested label, or <code>null</code> if
     *           <code>strLabelType</code> is not a valid label type.
     *
     * @see MM#UNIQUE_ID
     * @see MM#OLAPI_METADATA_ID
     * @see MM#SHORT_LABEL
     * @see MM#MEDIUM_LABEL
     * @see MM#LONG_LABEL
     * @see MM#DESCRIPTION
     * @see oracle.dss.metadataUtil.MDU#OBJECT_NAME
     *
     * @status Reviewed
     */
    public String toString(String strLabelType) {
        if (strLabelType != null) {
            // Return the appropriate label.
            if ( (strLabelType.equals(MM.UNIQUE_ID)) ||
                      (strLabelType.equals(LayerMetadataMap.LAYER_METADATA_NAME)) ||
                      (strLabelType.equals(MetadataMap.METADATA_VALUE)) ) {
                return getUniqueID();
            }
            if (strLabelType.equals(MM.OLAPI_METADATA_ID)) {
                return getUniqueID();
            }
            if ( (strLabelType.equals(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME)) ||
                      (strLabelType.equals(MetadataMap.METADATA_DISPLAYNAME)) ||
                      (strLabelType.equals(MDU.OBJECT_NAME)) ) {
                return getName();
            }
            if ( (strLabelType.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL)) ||
                      (strLabelType.equals(MetadataMap.METADATA_SHORTLABEL)) ||
                      (strLabelType.equals(MM.SHORT_LABEL)) ) {
                return getShortLabel();
            }
            if ( (strLabelType.equals(LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL)) ||
                      (strLabelType.equals(MetadataMap.METADATA_MEDIUMLABEL)) ||
                      (strLabelType.equals(MM.MEDIUM_LABEL)) ) {
                return getMediumLabel();
            }
            if ( (strLabelType.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL)) ||
                      (strLabelType.equals(MetadataMap.METADATA_LONGLABEL)) ||
                      (strLabelType.equals(MM.LONG_LABEL)) ) {
                return getLongLabel();
            }
            if (strLabelType.equals(MM.DESCRIPTION)) {
                return getDescription();
            }
        }
        //return null;
        return toString();
    }

    /**
     * @hidden
     * Print contents of this mdObject.
     *
     * @param type      If type is set to 1 then mdObject's properties are
     *                  printed as well.
     *
     * @status hidden
     */
    public void print( int type ) {
        System.out.println ( "===MDObject ID(" + getObjectID() +
            ") Type(" + getObjectType() +
            ") Unique_ID(" + getUniqueID() + ") Name(" + getName() + ")" );
        if ( type == 1)
            super.print();

        if (m_Children != null) {
            System.out.println ( "====No. of Children = " + m_Children.size() ) ;
            m_Children.print( type );
        }
        if (m_Relatives != null ) {
            System.out.println ( "====No. of Relatives = " + m_Relatives.size() ) ;
            m_Relatives.print( type );
        }
    }

    /**
     * @hidden
     * Remove references to children and relatives.  Clear the super class's
     * propertyBag
     *
     * @return      A constant that represents success or failure.
     *              The valid constants are:
     *              <code>SUCCESS</code>
     *              <code>FAILURE</code>
     * @status hidden
     */
    public int free()
    {
        super.free();
        if ( m_Children != null )
            m_Children.removeAll();
        if ( m_Relatives != null )
            m_Relatives.removeAll();
        if ( m_UserObjects != null )
            m_UserObjects.removeAll();
        if ( m_DependentsID != null )
            m_DependentsID.clear();

        m_Parent = null;
        m_Children = null;
        m_Relatives = null;
        m_UserObjects = null;
        m_DependentsID = null;
        return MDU.SUCCESS;
    }

  /************************************************************************
  * Shortcut methods for accessing common properties
  ************************************************************************/
    /**
     * Retrieves the name of this object.
     *
     * @return  The name of this mdObject, or <code>null</code> if no name
     *          has been set.
     *
     * @status Reviewed
     */
    public String getName() {
        if ( getProperty(MDU.OBJECT_NAME) != null )
            return getStrPropertyValue(MDU.OBJECT_NAME);
        return null;
    }

    /**
     * Specifies a name for this object.
     *
     * @parem name  The name for this object.
     *
     * @return      A constant that indicates whether the name was successfully
     *              set. Valid constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Reviewed
     */
    public int setName(String name) {
        setStrPropertyValue(MDU.OBJECT_NAME, name, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * Retrieves the label of this object.
     *
     * @return  The label of this mdObject, or <code>null</code> if no label
     *          has been set.
     *
     * @status Documented
     */
    public String getLabel() {
        if ( getProperty(MDU.OBJECT_LABEL) != null )
            return getStrPropertyValue(MDU.OBJECT_LABEL);
        return null;
    }

    /**
     * @hidden
     */
    public int setLabel(String label) {
        setStrPropertyValue(MDU.OBJECT_LABEL, label, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * Retrieves the class name of this object.
     *
     * @return  The class name for this object, or <code>null</code> if no
     *          class name has been set for this object.
     *
     * @status Reviewed
     */
    public String getClassName() {
        if ( getProperty(MDU.CLASS_NAME) != null )
            return getStrPropertyValue(MDU.CLASS_NAME);
        return null;
    }

    /**
     * Specifies a class name for this object.
     *
     * @parem className  The class name for this object.
     *
     * @return      A constant that indicates whether the class name was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Documented
     */
    public int setClassName(String className) {
        setStrPropertyValue(MDU.CLASS_NAME, className, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * Retrieves the object type of this object.
     *
     * @return  The type of this object, or <code>null</code> if no object
     *          type has been set.
     *
     * @status Reviewed
     */
    public String getObjectType() {
        if ( getProperty(MDU.OBJECT_TYPE) != null )
            return getProperty(MDU.OBJECT_TYPE).getStrValue();
        return null;
    }

    /**
     * Specifies the object type of this object.
     *
     * @parem objType  The type of this object.
     *
     * @return      A constant that indicates whether the object type was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Documented
     */
    public int setObjectType(String objType) {
        setStrPropertyValue(MDU.OBJECT_TYPE, objType, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * Retrieve subobject type of this object.
     *
     * @return  The subobject type of this object, or <code>null</code> if no
     *          subobject type has been set for this object.
     *
     * @status Reviewed
     */
    public String getSubObjectType() {
        if ( getProperty(MDU.SUB_OBJECT_TYPE) != null )
            return getProperty(MDU.SUB_OBJECT_TYPE).getStrValue();
        return null;
    }

    /**
     * Specifies the subobject type for this object.
     *
     * @param objType  The subobject type of this object.
     *
     * @return      A constant that indicates whether the subobject type was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status Documented
     */
    public int setSubObjectType(String objType) {
        setStrPropertyValue(MDU.SUB_OBJECT_TYPE, objType, MDU.UI_ALL);
        return MDU.SUCCESS;
    }

    /**
     * @deprecated
     * @hidden
     * Specifies an object that depends on this object.
     * Calling this method specifies the object in an array of dependent objects.
     * The relation between the two objects is "DEPENDENT".
     *
     * NOTE: Setting twice with the same position will replace the object.
     *
     * @param mdObject  The dependent object.
     * @param intPosition The index into the array of dependent objects in
     *                     which to place the dependent object.
     *                   If an object is already at this position, then
     *                   <code>mdObject</code> replaces that object.
     *
     * @return      A constant that indicates whether the object type was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
  	public int setDependent(MDObject mdObject, int intPosition) {
        if(m_DependentsID == null)
            m_DependentsID = new OrderedHashtable(m_InitSize);
  		m_DependentsID.put(new Integer(intPosition), mdObject.getUniqueID());
  		return setRelative(mdObject, "DEPENDENT");

  	}

    /**
     * @deprecated
     * @hidden
     * Removes an object from the list of dependent objects.
     *
     * @param intPosition  The index, in the array of the dependent objects,
     *               that identifies the object to remove.
     *
     * @return      A constant that indicates whether the object type was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem removing
     *          the object from the server.
     *
     * @status hidden
     */
  	public int removeDependent(int intPosition) throws MetadataManagerException {
        if(m_DependentsID != null)
      		m_DependentsID.remove(new Integer(intPosition));
  		MDObject[] relatives = getRelatives("DEPENDENT");
  		if ( (relatives != null) && (relatives.length == 1) ) {
  			removeRelative(relatives[0]);
  		}
		return MDU.SUCCESS;
  	}

    /**
     * @deprecated
     * @hidden
     * Retrieves a dependent object from the list of dependent objects.
     *
     * @param intPosition  The position, in the array of dependent objects,
     *                     of the object to retrieve.
     *
     * @return      A constant that indicates whether the object type was
     *              successfully set. Valid constants are listed in the See Also
     *              section.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
  	public MDObject getDependent(int intPosition) throws MetadataManagerException {
        if(m_DependentsID == null)
            return null;
  		String strUniqueID = (String)m_DependentsID.get(new Integer(intPosition));
  		Property property = new Property();
  		property.setStrValue(MM.UNIQUE_ID, strUniqueID, MDU.UI_ALL);
  		return getFirstRelative(property);
  	}

    /**
     * @deprecated
     * @hidden
     * Retrieves all of the objects that are dependent on this object.
     * This method retrieves each object in the list of dependent objects,
     * in list order.
     *
     * @return  The objects that are dependent on this object.
     *
     * @throws  MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem retrieving
     *          the object from the server.
     *
     * @status hidden
     */
  	public MDObject[] getDependents() throws MetadataManagerException {
        if(m_DependentsID == null)
            return null;
  		MDObject[] mdObjects = new MDObject[m_DependentsID.size()];
  		int i=0;
  		for (Enumeration e=m_DependentsID.keys(); e.hasMoreElements(); ) {
  			mdObjects[i++] = getDependent(((Integer)e.nextElement()).intValue());
  		}
  		return mdObjects;
  	}

    /**
     * @deprecated
     * @hidden
     * Retrieve m_DependentID of this mdObject.
     *
     * @return      Ordered hashtable of dependentIDs.
     *
     * @status hidden
     */
    public OrderedHashtable getDependentID()
    {
        return m_DependentsID;
    }

    /**
     * @deprecated
     * @hidden
     * Retrieve m_DependentID of this mdObject.
     *
     * @return      Ordered hashtable of dependentIDs.
     *
     * @status hidden
     */
    public void setDependentID(OrderedHashtable depsID)
    {
        m_DependentsID = depsID;
    }

    /**
     * @deprecated
     * @hidden
     * Retrieves the positions of all dependent objects.
     * This method retrieves a position in the array of dependent objects,
     * for each object in the array.
     *
     * @return      All dependent object positions.
     *
     * @status hidden
     */
  	public int[] getDependentPositions() {
        if(m_DependentsID == null)
            return new int[0];
            
  		int[] intPositions = new int[m_DependentsID.size()];
  		int i = 0;
  		for (Enumeration e=m_DependentsID.keys(); e.hasMoreElements(); ) {
  			intPositions[i++] = ((Integer)e.nextElement()).intValue();
  		}
  		return intPositions;
  	}

  	/**
     * Retrieves an <code>MDObject</code> object array for
     * the given <code>PropertyBag</code>object array.
     *
     * @param propertyBag An array of <code>PropertyBag</code> objects.
     *
     * @return An array of <code>MDObject</code> objects.
     *
     * @hidden
     *
     * @status hidden
     */
  	public static MDObject[] getMDObjectArray( PropertyBag[] propertyBag ) {
		if ( propertyBag == null )
			return null;
		MDObject[] mdObjects = new MDObject[propertyBag.length];
		for ( int i = 0; i < propertyBag.length ; i++ ) {
			mdObjects[i] = (MDObject)propertyBag[i];
		}
		return mdObjects;
  	}

   /**
    * @hidden
    */
    public void setChildrenStatus( String driverType, int status )
    {
        Hashtable _status = (Hashtable)getObjPropertyValue(MM.CHILDREN_STATUS);
        if(_status == null)
            _status = new Hashtable(5);

        _status.put(driverType, new Integer(status));
        setObjPropertyValue(MM.CHILDREN_STATUS, _status);
    }

    /**
     * @hidden
     */
    public int getChildrenStatus(String driverType)
    {
        Hashtable _status = (Hashtable)getObjPropertyValue(MM.CHILDREN_STATUS);
        if(_status != null && _status.containsKey(driverType))
            return ((Integer)_status.get(driverType)).intValue();
        else
            return MM.ILLEGAL_INT_VALUE;
    }
   /**
    * @hidden
    */
    public int getChildrenStatus()
    {
        Vector _vec = getDriverTypes();
        int _status = MM.COMPLETE;
        if(_vec == null || _vec.size() == 0)
            _status = MM.COMPLETE;
        else
        {
            for(Enumeration _enum = _vec.elements(); _enum.hasMoreElements();)
            {
                if(getChildrenStatus((String)_enum.nextElement()) != MM.COMPLETE)
                {
                    _status = MM.NOT_COMPLETE;
                    break;
                }
            }
        }
        return _status;
    }

   /**
    * @hidden
    */
    public void setRelativeStatus( int status ) {
        setIntPropertyValue( MM.RELATIVEBAG_STATUS, status, MDU.UI_ALL );
    }

   /**
    * @hidden
    */
    public int getRelativeStatus() {
        return getIntPropertyValue( MM.RELATIVEBAG_STATUS );
    }

    /**
     * Specifies an MDObject that is to be referenced by or associated with 
     * this MDObject.  For example, use this method to specify an annotation 
     * mdObject that can be referenced by this mdObject.
     * 
     * @param referenceName  Name of the referenced mdObject or a string 
     *        that specifies the reference, for example, ANNOTATION.
     * @param mdobj The referenced object.
     * 
     * @return   A constant that indicates whether the operation was 
     *           successful. Valid constants are in the See Also section.
     * 
     * @see MM#FAILURE
     * @see MM#SUCCESS
     * 
     * @status Documented
     */
    public int setReferencedObject(String referenceName, MDObject mdObj)
    {
        if(referenceName != null && mdObj != null)
        {
            // In VB mode, transient become null
            if(m_referencedObjs == null)
                m_referencedObjs = new Hashtable(3);
                
            if(m_referencedObjIDs == null)
                m_referencedObjIDs = new Hashtable(3);

            m_referencedObjs.put(referenceName, mdObj);
            m_referencedObjIDs.put(referenceName, new Long(mdObj.getObjectID()));
            
            PropertyBag props = new PropertyBag();
            props.setStrPropertyValue(MM.REFERENCE_NAME, referenceName);
            props.setStrPropertyValue(MM.REFERENCE_BY_OBJ, getUniqueID());
            props.setStrPropertyValue(MM.REFERENCE_OBJ, mdObj.getUniqueID());
            if(m_MetadataManagerServices._setReferencedObject(props) == MM.FAILURE)
            {
                m_referencedObjs.remove(referenceName);
                m_referencedObjIDs.remove(referenceName);
                return MM.FAILURE;
            }
            return MM.SUCCESS;
        }
        return MM.FAILURE;
    }

    /**
     * @hidden
     */
    public Hashtable getReferencedObjects()
    {
        return m_referencedObjs;
    }
    
    /**
     * @hidden
     */
    public void setReferencedObjects(Hashtable refObj)
    {
        m_referencedObjs = refObj;
    }
    
    /**
     * @hidden
     */
    public Hashtable getReferencedObjectIDs()
    {
        return m_referencedObjIDs;
    }
    
    /**
     * @hidden
     */
    public void setReferencedObjectIDs(Hashtable refObj)
    {
        m_referencedObjIDs = refObj;
    }
    
    /**
     * @hidden
     */
    public int _setReferencedObject(String referenceName, MDObject mdObj)
    {
        // In VB mode, transient become null
        if(m_referencedObjs == null)
            m_referencedObjs = new Hashtable(3);

        if(m_referencedObjIDs == null)
            m_referencedObjIDs = new Hashtable(3);

        m_referencedObjs.put(referenceName, mdObj);
        m_referencedObjIDs.put(referenceName, new Long(mdObj.getObjectID()));
        return MM.SUCCESS;
    }

    /**
     * Remove an MDObject that is referenced by or associated with 
     * this MDObject.  For example, use this method to remove an annotation 
     * mdObject that is referenced by this mdObject.
     * 
     * @param referenceName  Name of the referenced mdObject or a string 
     *        that specifies the reference, for example, ANNOTATION.
     * 
     * @return   A constant that indicates whether the operation was 
     *           successful. Valid constants are in the See Also section.
     * 
     * @see MM#FAILURE
     * @see MM#SUCCESS
     * 
     * @status New
     */
    public int removeReferencedObject(String referenceName)
    {
        if(m_referencedObjs != null && m_referencedObjs.containsKey(referenceName))
        {
            PropertyBag props = new PropertyBag();
            props.setStrPropertyValue(MM.REFERENCE_NAME, referenceName);
            props.setStrPropertyValue(MM.REFERENCE_BY_OBJ, getUniqueID());
            if(m_MetadataManagerServices._removeReferencedObject(props) == MM.SUCCESS)
            {
                m_referencedObjs.remove(referenceName);
                m_referencedObjIDs.remove(referenceName);
                return MM.SUCCESS;
            }
            return MM.FAILURE;
        }
        return MM.FAILURE;
    }
    
    /**
     * @hidden
     */
    public int _removeReferencedObject(String referenceName)
    {
        // In VB mode, transient become null
        if(m_referencedObjs != null)
        {
            m_referencedObjs.remove(referenceName);
            m_referencedObjIDs.remove(referenceName);
            return MM.SUCCESS;
        }
        return MM.FAILURE;
    }

    /**
     * Retrieves the referenced MDObject.  For example, the annotation MDObject
     * can be retrieved for this MDObject, if one is specified.
     * 
     * @param mdObjectName  Name of the referenced mdObject or a string 
     *        that specifies the relation, for example, ANNOTATION.
     *        
     * @return the referenced MDObject or null if no mdObject was set for the
     *         specified mdObjectName.
     *         
     * @status Documented
     */
    public MDObject getReferencedObject(String mdObjectName) throws MetadataManagerException
    {
        // In VB mode, transient become null
        if(m_referencedObjs == null)
            m_referencedObjs = new Hashtable(3);
            
        if(m_referencedObjIDs == null)
            m_referencedObjIDs = new Hashtable(3);

        if(mdObjectName != null)
        {
            MDObject _obj;
            Long _objID;
            if((_obj = (MDObject) m_referencedObjs.get(mdObjectName)) != null)
                return _obj;
            else if((_objID = (Long) m_referencedObjIDs.get(mdObjectName)) != null)
            {
                _obj = m_MetadataManagerServices.getMDObjectByID(_objID.longValue());
                if(_obj != null)
                    m_referencedObjs.put(mdObjectName, _obj);
                return _obj;
            }
        }
        return null;
    }

    /**
     * Determines whether the object is a logical representation of an object 
     * in the Analytic Workspace.
     * 
     * @return  <code>true</code> if the object is an Analytic Workspace object,
     *          <code>false</code> if the object is not an Analytic Workspace
     *          object.
     *          
     * @status Documented
     */
    public boolean isAWObject()
    {
        return (getProperty(MM.IS_AW_OBJECT) != null);
    }

    /**
     * Retrieves the object name in the Analytic Workspace.
     * 
     * @return  String that represents the object name in the Analytic Workspace
     * 
     * @throws MetadataManagerException if the object is not an AW object.
     * 
     * @status Documented
     */
    public String getAWObjectName() throws MetadataManagerException
    {
        if(isAWObject())
            return getStrPropertyValue(MM.AW_OBJECT_NAME);
        else
            throw new MetadataManagerException(MetadataManagerCommonBundle.class,
                                               MetadataManagerCommonBundle.EXC_NOT_AW_OBJ,
                                               null,
                                               m_MetadataManagerServices.getLocale(),
                                               MDU.MDM);
    }

    /**
     * @hidden
     */
    public int setAWObjectName(String awObjName)
    {
        if(awObjName != null)
        {
            setStrPropertyValue(MM.AW_OBJECT_NAME, awObjName);
            setStrPropertyValue(MM.IS_AW_OBJECT, "true");
            return MM.SUCCESS;
        }
        return MM.FAILURE;
    }

    /**
     * @hidden
     * Only the metadata driver should call this method!!!
     */
    public void setUniqueID(String driverType, String id)
    {
    	Vector _idVec = getStringVectorPropertyValue(MM.UNIQUE_ID);
    	if(_idVec == null) {
    		_idVec = new Vector(3);
    	}

        String _id = MMUtilities._makeUniqueID(driverType, id);
        for(int i=0; driverType != null && i < _idVec.size(); i++) {// remove duplicates
            String _tmp = (String)_idVec.elementAt(i);
            if(_tmp != null && _tmp.startsWith(driverType))
                _idVec.removeElementAt(i);
        }
        _idVec.addElement(_id);
    	setStringVectorPropertyValue(MM.UNIQUE_ID, _idVec, MDU.UI_ALL);
    }
    
    public Object getState()
    {
        return getObjPropertyValue(MM.STATE_OBJECT);
    }
    
    /**
     * 
     * @return 
     */
    public Object getDatasource()
    {
        return m_ds;
    }

    /**
     * @hidden
     */
    public void setDatasource(Object ds)
    {
        m_ds = ds;
    }
}