/*
 * AccessibleLabel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.accessible;

import java.awt.Component;
import java.awt.event.FocusEvent;

import javax.accessibility.AccessibleContext;
import javax.swing.JLabel;

/**
 *  Provides the capability of accessibility to labels.
 *  <p>Application developers should not use this class. It is for internal
 *  use only.</p>
 *
 *  @see oracle.dss.datautil.gui.accessible.AccessiblePanel
 *  @see oracle.dss.datautil.gui.accessible.AccessibleUtils 
 *  @status documented
 *
 */

 public class AccessibleLabel extends JLabel {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructor that specifies only the text for an <code>AccessibleLabel</code> 
   * instance.
   *
   * @param  strText A <code>string</code> that represents the
   *         text to be displayed by the label.
   *
   * @status documented
   */
  public AccessibleLabel (String strText) {
    super(strText);
  }


  /**
   * Constructor that specifies all arguments for an <code>AccessibleLabel</code> 
   * instance.
   *
   * @param  strText A <code>string</code> that represents the
   *         text to be displayed by the label.
   *
   * @param  nHorizontalAlignment An <code>integer</code> that represents the
   *         Swing constant that represents the horizontal
   *         alignment for the text of this title.
   *
   * @see javax.swing.SwingConstants#LEFT
   * @see javax.swing.SwingConstants#CENTER
   * @see javax.swing.SwingConstants#RIGHT
   *
   * @status documented
   */
  public AccessibleLabel (String strText, int nHorizontalAlignment) {
    super (strText, nHorizontalAlignment);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Indicates whether this object can accept focus or not.
   *
   * @return <code>true</code> if the object
   *         can accept focus and <code>false</code> if it cannot.
   *
   *  @status documented
   */
  public boolean isFocusTraversable() {
    return true;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
