/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataUtil;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Properties;
import java.util.Enumeration;

/**
 * An object that can have variable properties.
 * A <code>PropertyBag</code> contains a hashtable of properties.
 * Methods in this class provide access to these properties.
 *
 * @status Reviewed
 */
public class PropertyBag implements Serializable
    {
    /////////////////////
    //
    // Private Members
    //
    /////////////////////

    // OrderedHashtable with property name as key and property as value
    private Hashtable m_PropertyBag = null;
    // Initial hashtable size
    private int m_initSize = 11;

    private int m_bit = 0x0;

    /////////////////////
    //
    // Constructors
    //
    /////////////////////

    /**
     * Constructor.
     *
     * @status Reviewed
     */
    public PropertyBag()
        {
        m_PropertyBag = new Hashtable(m_initSize);
        }

    /////////////////////
    //
    // Public Methods
    //
    /////////////////////

    /**
     * Retrieves size of this <code>PropertyBag</code>.
     * The size is the size of the internal vector of properties.
     *
     * @return The size of the vector of properties.
     *
     * @status Reviewed
     */
    public int size()
        {
        return m_PropertyBag.size();
        }

    /**
     * @hidden
     * Indicates whether a property exists in this <code>PropertyBag</code>.
     *
     * @param property The name of the property to find.
     *
     * @return <code>true</code>  if <code>property</code> exists in propertyBag
     *         <code>false</code> if it does not.
     *
     * @status hidden
     */
    public boolean contains (Property property)
    {
        if (property == null)
            return false;

        String name = property.getName();
        if(name != null)
        {
            Property prop = (Property)m_PropertyBag.get(name);
            if(prop != null && !isStringAndStringVector(prop.getDataType(),
                                                        property.getDataType()))
            {
                return prop.equals(property);
            }
            else if(prop != null)
            {
                String strValue = null;
                Vector vValues = null;
                // Check property in propertyBag
                switch (prop.getDataType())
                {
                    case MDU.STRING:        strValue = prop.getStrValue();
                                            break;
                    case MDU.STRING_VECTOR: vValues = prop.getStringVectorValue();
                                            break;
                    default:                break;
                }

                // Check the passed in property object
                switch (property.getDataType())
                {
                    case MDU.STRING:        strValue = property.getStrValue();
                                            break;
                    case MDU.STRING_VECTOR: vValues = property.getStringVectorValue();
                                            break;
                    default:                break;
                }
                // Determine if the string can be found in the string vector
                return prop.containsString (strValue, vValues);
            }
        }
        return false;
    }
    /**
     * @hidden
     */
    private boolean isStringAndStringVector (int nDataType1, int nDataType2)
        {
        return (nDataType1 == MDU.STRING && nDataType2 == MDU.STRING_VECTOR) ||
               (nDataType1 == MDU.STRING_VECTOR && nDataType2 == MDU.STRING);
        }

    /**
     * Removes a property from this <code>PropertyBag</code>.
     *
     * @param name  Name of the property to remove.
     *
     * @status Reviewed
     */
    public void removeProperty(String name)
    {
        m_PropertyBag.remove(name);
        // set the bit
        if(MDU.UNIQUE_ID.equals(name))
            m_bit &= (~MDU.UID_BIT);
        else if(MDU.PATH.equals(name))
            m_bit &= (~MDU.PATH_BIT);
        else if(MDU.OLAPI_METADATA_ID.equals(name))
            m_bit &= (~MDU.OLAPID_BIT);
        else if(MDU.OLAPI_RUNTIME_ID.equals(name))
            m_bit &= (~MDU.OLAPRUNID_BIT);
        else if(MDU.OLAPI_RUNTIME_IDS.equals(name))
            m_bit &= (~MDU.OLAPRUNIDS_BIT);
    }

    /**
     * @hidden because Property class is hidden.
     * Retrieves a property from this <code>PropertyBag</code>.
     *
     * @param name  Name of the property to retrieve.
     *
     * @return Property with specified name. Null if property is not found.
     *
     * @status hidden
     */
    public Property getProperty(String name)
    {
        return (Property) ((m_PropertyBag != null)? m_PropertyBag.get(name) : null);
    }

    /**
     * @hidden because Property class is hidden
     * Create a property with specified name and add it to this PropertyBag.
     * If a property with similar name exists in PropertyBag, it gets
     * replaced by new property.
     *
     * @param name  Name of the property that needs to be created
     *
     * @return Property with specified name.
     *
     * @status hidden
     */
    public Property createProperty (String name)
        {
        Property prop = new Property();
        prop.setName (name);
        setProperty (prop);
        return prop;
        }

    /**
     * @hidden because Property class is hidden.
     * Adds a property to this PropertyBag.  If a property with
     * similar name exists in PropertyBag, it gets replaced by new property.
     *
     * @param property  Property to add to this propertyBag
     *
     * @status hidden
     */
    public void setProperty (Property property)
    {
        if (m_PropertyBag == null)
            m_PropertyBag = new Hashtable(m_initSize);

        m_PropertyBag.put(property.getName(), property);
        
        // set the bit
        String _name = property.getName();
        if(MDU.UNIQUE_ID.equals(_name))
            m_bit |= MDU.UID_BIT;
        else if(MDU.PATH.equals(_name))
            m_bit |= MDU.PATH_BIT;
        else if(MDU.OLAPI_METADATA_ID.equals(_name))
            m_bit |= MDU.OLAPID_BIT;
        else if(MDU.OLAPI_RUNTIME_ID.equals(_name))
            m_bit |= MDU.OLAPRUNID_BIT;
        else if(MDU.OLAPI_RUNTIME_IDS.equals(_name))
            m_bit |= MDU.OLAPRUNIDS_BIT;
    }

    /**
     * @hidden because Property class is hidden.
     * Retrieve all properties in this PropertyBag
     *
     * @return  Array of properties in this propertyBag
     *
     * @status hidden
     */
    public Property[] getProperties()
    {
        if (size() == 0)
            return null;

        Property[] props = new Property[size()];
        Enumeration enumer = m_PropertyBag.elements();
        int i=0;
        while(enumer.hasMoreElements()) {
            props[i++] = (Property)enumer.nextElement();
        }
        return props;
    }

    /**
     * @hidden because Property class is hidden.
     * Retrieve properties of specified data type in this PropertyBag
     *
     * @param dataType  Interger representing dataType.
     *                  Possible values are listed in the SEe Also section
     *                  <code>STRING</code>
     *                  <code>LONG</code>
     *                  <code>INTEGER</code>
     *                  <code>OBJ</code>
     *                  <code>STRING_VECTOR</code>
     *                  <code>ALL_DATATYPES</code>
     *
     * @return  Array of properties with specified data type
     *
     * @status hidden
     */
    public Property[] getProperties(int dataType)
        {
        return getProperties (dataType, MDU.UI_ALL);
        }

    /**
     * @hidden because Property class is hidden.
     * Retrieve properties of specified data type and UI flag.
     *
     * @param dataType  Interger representing dataType.
     *                  Possible values are:
     *                  <code>STRING</code>
     *                  <code>LONG</code>
     *                  <code>INTEGER</code>
     *                  <code>OBJ</code>
     *                  <code>STRING_VECTOR</code>
     *                  <code>ALL_DATATYPES</code>
     * @param flags     UI flags.  Possible values are:
     *                  <code>UI_VISIBLE</code>
     *                  <code>UI_WRITE</code>
     *                  <code>UI_DELETE</code>
     *                  <code>UI_ENCRYPT</code>
     *                  <code>UI_ALL</code>
     *                  <code>UI_NONE</code>
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     * @see MDU#STRING
     * @see MDU#LONG
     * @see MDU#INTEGER
     * @see MDU#OBJ
     * @see MDU#STRING_VECTOR
     * @see MDU#ALL_DATATYPES
     *
     * @return  Array of properties with specified data type and UI flags
     *
     * @status hidden
     */
    public Property[] getProperties(int dataType, int flags)
    {

        if (size() == 0)
            return null;

        Property prop = null;
        Vector vec = new Vector(m_PropertyBag.size());
        Enumeration names = m_PropertyBag.keys();
        while(names.hasMoreElements())
        {
            prop = (Property)m_PropertyBag.get(names.nextElement());
            if ((prop != null) &&
                 ((dataType == MDU.ALL_DATATYPES) ||
                  (dataType == prop.getDataType())) && (prop.is (flags)))
            {
                vec.addElement(prop);
                prop = null;
            }
        }

        int size = vec.size();
        if(size > 0)
        {
            Property[] props = new Property[size];
            vec.copyInto(props);
            return props;
        }
        else {
            return null;
        }
    }

    /**
     * @hidden because Property class is hidden.
     * Retrieve properties of specified string value.
     *
     * @return  Array of properties with specified string value.
     *
     * @status hidden
     */
    public Property[] getProperties(String value)
    {
        if (size() == 0 || value == null)
            return null;

        Property prop = null;

        Vector vec = new Vector(size());
        Enumeration names = m_PropertyBag.keys();
        while(names.hasMoreElements())
        {
            prop = (Property)m_PropertyBag.get(names.nextElement());
            if ((prop != null) && value.equals(prop.getStrValue()))
            {
                vec.addElement(prop);
                prop = null;
            }
        }
        int size = vec.size();
        if(size > 0) {
            Property[] props = new Property[size];
            vec.copyInto(props);
            return props;
        }
        else {
            return null;
        }
    }

    /**
     * Retrieves the data type of a property in this <code>PropertyBag</code>.
     *
     * @param name The name of the property whose data type you want.
     *
     * @return  A constant that represents the data type of
     *          the <code>name</code> property.
     *          Possible values are listed in the See Also section.
     *
     * @see MDU#STRING
     * @see MDU#LONG
     * @see MDU#INTEGER
     * @see MDU#OBJ
     * @see MDU#STRING_VECTOR
     * @see MDU#ALL_DATATYPES
     *
     * @status Reviewed
     */
    public int getPropertyDataType (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getDataType();
        return 0;
        }

    /**
     * Shortcut methods
     */

    /**
     * Adds a property to this <code>PropertyBag</code>.
     * If a property already exists, then this method replaces the property
     * value.
     *
     * @param name      The name of the property to add.
     * @param object    The value of the property.
     * @param dataType  A constant that represents the data type of the
     *                  property.
     *                  Valid constants are:
     *                  <ul>
     *                  <li><code>STRING</code></li>
     *                  <li><code>LONG</code></li>
     *                  <li><code>INTEGER</code></li>
     *                  <li><code>OBJ</code></li>
     *                  <li><code>STRING_VECTOR</code></li>
     *                  <li><code>ALL_DATATYPES</code></li>
     *                  </ul>
     * @param flags     A constant that indicates how the property appears
     *                  in the user interface. Valid constants are:
     *                  <ul>
     *                  <li><code>UI_VISIBLE</code></li>
     *                  <li><code>UI_WRITE</code></li>
     *                  <li><code>UI_DELETE</code></li>
     *                  <li><code>UI_ENCRYPT</code></li>
     *                  <li><code>UI_ALL</code></li>
     *                  <li><code>UI_NONE</code></li>
     *                  </ul>
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     * @see MDU#STRING
     * @see MDU#LONG
     * @see MDU#INTEGER
     * @see MDU#OBJ
     * @see MDU#STRING_VECTOR
     * @see MDU#ALL_DATATYPES
     *
     * @status Reviewed
     */
    public void setProperty (String name, Object object, int dataType, int flags)
        {
        Property prop = new Property();
        prop.setProperty (name, object, dataType, flags);
        setProperty(prop);
        return;
        }

    /**
     * Retrieves the value of a <code>String</code> property.
     *
     * @param name  The name of the property whose value you want.
     *
     * @return The property value, or <code>null</code> if the property
     *         has no value.
     *
     * @status Reviewed
     */
    public String getStrPropertyValue (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getStrValue();
        return null;
        }

    /**
     * Specifies the value of a <code>String</code> property.
     * This method sets the user-interface flag to <code>UI_NONE</code>.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     *
     * @status Reviewed
     */
    public void setStrPropertyValue (String name, String value)
        {
        setStrPropertyValue (name, value, MDU.UI_NONE);
        }

    /**
     * Specifies the value of a <code>String</code> property and the
     * user-interface flags.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     * @param flags User-interface flags. Valid values are listed in the
     *              See Also section.
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     *
     * @status Reviewed
     */
    public void setStrPropertyValue (String name, String value, int flags)
        {
        Property prop = new Property();
        prop.setStrValue (name, value, flags);
        setProperty(prop);
        return;
        }

    /**
     * Retrieves the value of a <code>long</code> property.
     *
     * @param name  The name of the property whose value you want.
     *
     * @return The property value, or <code>MDU.ILLEGAL_LONG_VALUE</code> if
     *         the property is <code>null</code>.
     *
     * @see MDU#ILLEGAL_LONG_VALUE
     *
     * @status Reviewed
     */
    public long getLongPropertyValue (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getLongValue();

        return MDU.ILLEGAL_LONG_VALUE;
        }

    /**
     * Specifies the value of a <code>long</code> property.
     * This method sets the user-interface flag to <code>UI_NONE</code>.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     *
     * @see MDU#UI_NONE
     *
     * @status Documented
     */
    public void setLongPropertyValue(String name, long value)
        {
        setLongPropertyValue (name, value, MDU.UI_NONE);
        }

    /**
     * Specifies the value of a <code>long</code> property and the
     * user-interface flags.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     * @param flags User-interface flags. Valid values are listed in the
     *              See Also section.
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     *
     * @status Reviewed
     */
    public void setLongPropertyValue(String name, long value, int flags )
        {
        Property prop = new Property();
        prop.setLongValue (name, value, flags);
        setProperty(prop);
        return;
        }

    /**
     * Retrieves the value of an <code>int</code> property.
     *
     * @param name  The name of the property whose value you want.
     *
     * @return The property value, or <code>MDU.ILLEGAL_INT_VALUE</code> if
     *         the property value is <code>null</code>.
     *
     * @see MDU#ILLEGAL_INT_VALUE
     *
     * @status Reviewed
     */
    public int getIntPropertyValue (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getIntValue();

        return MDU.ILLEGAL_INT_VALUE;
        }

    /**
     * Specifies the value of an <code>int</code> property.
     * This method sets the user-interface flag to <code>UI_NONE</code>.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     *
     * @see MDU#UI_NONE
     *
     * @status Documented
     */
    public void setIntPropertyValue(String name, int value)
        {
        setIntPropertyValue(name, value, MDU.UI_NONE);
        }

    /**
     * Specifies the value of an <code>int</code> property and the
     * user-interface flags.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     * @param flags User-interface flags. Valid values are listed in the
     *              See Also section.
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     *
     * @status Reviewed
     */
    public void setIntPropertyValue(String name, int value, int flags )
        {
        Property prop = new Property();
        prop.setIntValue (name, value, flags);
        setProperty(prop);
        return;
        }


    /**
     * Retrieves the value of an <code>Object</code> property.
     *
     * @param name  The name of the property whose value you want.
     *
     * @return The property value, or <code>null</code> if the property
     *         has no value.
     *
     * @status Reviewed
     */
    public Object getObjPropertyValue (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getObjValue();

        return null;
        }

    /**
     * Specifies the value of an <code>Object</code> property.
     * This method sets the user-interface flag to <code>UI_NONE</code>.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     *
     * @see MDU#UI_NONE
     *
     * @status Documented
     */
    public void setObjPropertyValue (String name, Object value)
        {
        setObjPropertyValue (name, value, MDU.UI_NONE);
        }

    /**
     * Specifies the value of an <code>Object</code> property and the
     * user-interface flags.
     *
     * @param name  The name of the property to set.
     * @param value The value to set for <code>name</code>.
     * @param flags User-interface flags. Valid values are listed in the
     *              See Also section.
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     *
     * @status Reviewed
     */
    public void setObjPropertyValue(String name, Object value, int flags )
        {
        Property prop = new Property();
/*
        if (!(value instanceof java.io.Serializable))
            System.out.println ("****************** Object is Not Serializable ********** " +
                name + " " + value );
*/
        prop.setObjValue (name, value, flags);
        setProperty(prop);
        return;
        }

    /**
     * Retrieves the vector of values of a <code>String</code> vector property.
     *
     * @param name  The name of the property whose values you want.
     *
     * @return The vector of property values, or <code>null</code> if no
     *         values have been set.
     *
     * @status Reviewed
     */
    public Vector getStringVectorPropertyValue (String name)
        {
        Property prop = getProperty (name);
        if (prop != null)
            return prop.getStringVectorValue();

        return null;
        }

    /**
     * Specifies the values of a <code>String</code> vector property.
     * This method sets the user-interface flag to <code>UI_NONE</code>.
     *
     * @param name  The name of the property to set.
     * @param value The values to set for <code>name</code>.
     *
     * @see MDU#UI_NONE
     *
     * @status Documented
     */
    public void setStringVectorPropertyValue (String name, Vector value)
        {
        setStringVectorPropertyValue (name, value, MDU.UI_NONE);
        }

    /**
     * Specifies the values of a <code>String</code> vector property and the
     * user-interface flags.
     *
     * @param name  The name of the property to set.
     * @param value The vector of values to set for <code>name</code>.
     * @param flags User-interface flags. Valid values are listed in the
     *              See Also section.
     *
     * @see MDU#UI_VISIBLE
     * @see MDU#UI_WRITE
     * @see MDU#UI_DELETE
     * @see MDU#UI_ENCRYPT
     * @see MDU#UI_ALL
     * @see MDU#UI_NONE
     *
     * @status Reviewed
     */
    public void setStringVectorPropertyValue (String name, Vector value, int flags)
        {
        Property prop = new Property();
        prop.setStringVectorValue (name, value, flags);
        setProperty(prop);
        return;
        }

    /**
     * @hidden
     * Indicates whether a property exists in this <code>PropertyBag</code>.
     *
     * @param property The name of the property to look for.
     *
     * @return <code>true</code>  if <code>property</code> exists in this
     *                            <code>PropertyBag</code>,
     *         <code>false</code> if it does not.
     *
     * @status hidden
     */
    public boolean equals (Property property)
    {
        if(property != null)
        {
            Property prop = (Property)m_PropertyBag.get(property.getName());
            if(prop != null)
            {
                if (prop == property)
                    return true;

                int datatype = property.getDataType();
                if(prop.getDataType() == datatype)
                {
                    if ((datatype == MDU.LONG) &&
                        (prop.getLongValue() == property.getLongValue()))
                        return true;
                    if ((datatype == MDU.INTEGER) &&
                        (prop.getIntValue() == property.getIntValue()))
                        return true;
                    if ((datatype == MDU.OBJ) &&
                        (prop.getObjValue() == property.getObjValue()))
                        return true;
                    if ((datatype == MDU.STRING) &&
                        (prop.toString().equals (property.toString())))
                        return true;
                    if ((datatype == MDU.STRING_VECTOR) &&
                        (prop.getStringVectorValue() ==
                        (property.getStringVectorValue())))
                        return true;
                }
            }
        }
        return false;
        }

    /**
     * @hidden
     * Print properties in propertyBag
     *
     * @status hidden
     */
    public void print()
    {
        Enumeration props = m_PropertyBag.elements();
        int i=1;
        while(props.hasMoreElements())
        {
            Property prop = (Property)props.nextElement();
            System.out.println ("--------ProperyName[" + (i++) + "] = " +
            prop.getName() + "; PropertyValue = " + prop.getStrValue());
        }
    }

    /**
     * @hidden
     * Remove all property references from propertyBag
     *
     * @return <code>SUCCESS</code> if all references were removed successfully.
     *
     * @see MDU#SUCCESS
     *
     * @status hidden
     */
    public int free()
        {
        if (m_PropertyBag != null)
            {
            m_PropertyBag.clear();
            m_PropertyBag = null;
            }

        return MDU.SUCCESS;
        }

    /****************************************************
     * Protected for sub classes only
     ****************************************************/
    /**
     * @hidden
     * Retrieve propertyBag
     *
     * @return PropertyBag
     *
     * @status hidden
     */
    public PropertyBag getPropertyBag()
        {
        return (PropertyBag) this;
        }

    /**
     * Set properties in specified propertyBag to this propertyBag.
     *
     * @param propertyBag    propertyBag that needs to be set to
     *                       <code>this</code>.
     * @param keepRemoveFlag <code>KEEP</code>     keep the existing properties
     *                       <code>REMOVE</code>   remove all existing
     *                                             properties and add new ones.
     *
     * @return <code>SUCCESS</code>
     *         <code>FAILURE</code>
     *
     * @see MDU#KEEP
     * @see MDU#REMOVE
     * @see MDU#SUCCESS
     * @see MDU#FAILURE
     *
     * @status hidden
     */
    public int setPropertyBag (PropertyBag propertyBag , int keepRemoveFlag)
        {
        if ((propertyBag == null) || (propertyBag.size() == 0))
            return MDU.FAILURE;

        if (keepRemoveFlag == MDU.REMOVE)
            m_PropertyBag.clear();

        Property[] props = propertyBag.getProperties();
        for (int i =0 ; i < props.length ; i++)
            {
            setProperty(props[i]);
            }

        return MDU.SUCCESS;
        }

    /**
     * Merges two <code>PropertyBag</code> objects.
     * If the two property bags contain the same property,
     * then the value that is specified in the first property bag is used.
     * The value in the second property bag is discarded.
     *
     * @param firstBag    First property bag to merge.
     * @param secondbag   Second property bag to merge.
     *
     * @return A property bag that contains the properties in
     *         <code>firstBag</code> and the properties in <code>secondBag</code>.
     *
     * @status Reviewed
     */
    public static PropertyBag mergePropertyBags (PropertyBag firstBag,
                                                 PropertyBag secondBag)
    {
        if ((firstBag == null) || (secondBag == null))
            return null;

        Property[] props = secondBag.getProperties();
        for (int i =0 ; i < props.length ; i++)
        {
            firstBag.setProperty(props[i]);
        }

        if (firstBag.size() > 0)
            return firstBag;

        return null;
    }

    // These methods are used for partial matching
    /**
     * @hidden
     * check if contains the property value in property bag
     * this one supports wild card and case sensitivity
     */
    public boolean contains(Property property, boolean isCaseSensitive)
    {
        if (property == null)
            return false;

        String _name = property.getName();
        Property _prop = null;
        if (_name != null)
            _prop = (Property)m_PropertyBag.get(_name);

        if (_prop != null && _prop.getDataType() == MDU.STRING)
            return _prop.equalsString(property, isCaseSensitive);
        else
            return contains(property);
    }

    /**
     * @hidden
     */
    public boolean isBitOn(short bit)
    {
        return (m_bit & bit) == bit;
    }
    
    public Object clone()
    {
        PropertyBag _props = new PropertyBag();
        _props.m_PropertyBag = (Hashtable)m_PropertyBag.clone();
        _props.m_bit = m_bit;
        _props.m_initSize = m_initSize;
        return _props;
    }
}
