/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.io.Serializable;

/**
 * Methods that are required for a user.
 *
 * @status documented
 */
public interface User extends Serializable
{
    /**
     * Indicates whether the specified user is equivalent to this user.
     *
     * @param obj The object to compare with this <code>user</code>.
     * @return <code>true</code> if <code>user</code> is equivalent to this
     *          user,
     *         <code>false</code> if it is not.
     *
     * @status documented
     */
    public boolean equals(Object obj);
    
    /**
     * Retrieves the name of this user.
     *
     * @return The name of this user.
     *
     * @status documented
     */
    public String getName();

    /**
     * Retrieves detailed information for this user.
     *
     * @return The full name of this user.
     *
     * @status documented
     */
    public String getFullName();
    
    /**
     * Converts all of the information about this user to a <code>String</code>.
     *
     * @return The <code>String</code> representation of this user.
     *
     * @status documented
     */
    public String toString();
}