/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.common;

import oracle.dss.util.persistence.Persistable;

public interface PersistenceHelper
{
    public MDObject getMDObject(Persistable persistable) throws MetadataManagerException;
}