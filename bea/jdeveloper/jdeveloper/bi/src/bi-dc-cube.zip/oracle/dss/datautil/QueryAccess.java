/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

import java.util.Vector;

import oracle.dss.selection.OlapQDR;
import oracle.dss.util.DataAccess;
import oracle.dss.util.MetadataMap;

/**
 * Methods that the QueryBuilder and CalcBuilder beans use to manage changes to
 * <code>selection</code> objects. <code>Selection</code> objects for specific
 * dimensions (along with the layout of the dimensions) provide state for a
 * query-creating component such as the <code>Query</code> object.
 *
 * @status Documented
 */
public interface QueryAccess
{
    /**
     * Adds a listener to the listener list
     *
     * @param l The <code>QueryAccessListener</code> to add to the listener
     *          list.
     *
     * @status Documented
     */
    public void addQueryAccessListener(QueryAccessListener l);
 
    /**
     * Removes a listener from the listener list.
     *
     * @param l The <code>QueryAccessListener</code> to remove from the listener
     *          list.
     *
     * @status Documented
     */
    public void removeQueryAccessListener(QueryAccessListener l);    
    
    /** 
     * Cleans up the <code>QueryAccess</code> implementation.  Informs the
     * <code>QueryAccess</code> implementation that its user is done and that
     * this implementation will no longer be called or passed as an argument to
     * the <code>applyQueryAccess</code> method.
     *
     * @status Documented
     */
    public void release();    
    
    /**
     * Adds a <code>Step</code> object to perform drilling on the specified
     * dimension's <code>selection</code>. Drills to a relative level at the
     * specified position.
     *
     * @param dimension    The dimension whose selection should be drilled.
     * @param value        The dimension member to be drilled.
     * @param delta        The relative number of levels to traverse within the
     *                     hierarchy that is specified in the dimension's
     *                     selection (positive numbers drill down, negative
     *                     numbers drill up).
     * @param optimize     <code>true</code> allows the optimization of not
     *                     preserving the steps in a selection;
     *                     <code>false</code> does not allow this optimization.
     *
     * @return  <code>true</code> if the drill succeeds;
     *          <code>false</code> if the drill does not succeed.
     *
     * @status Documented
     */
    public boolean drillList(String dimension, String value, int delta, boolean optimize);
    
    /**
     * Retrieves the <code>DataAccess</code> object for a specified selection.
     * 
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection);*/

    /**
     * Retrieves the <code>DataAccess</code> object for a specified selection.
     *
     * @param map Specifies the desired metadata for the resulting
     *            <code>DataAccess</code>.
     *
     * @return A <code>DataAccess</code> object that contains the specified
     *         selection.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public DataAccess getDataAccess(Selection selection, MetadataMap map);*/

    /**
     * Retrieves a <code>DataAccess</code> object that contains dimension
     * member metadata positioned at the stored selection for the specified
     * dimension.
     * 
     * @return A <code>DataAccess</code> object that contains the specified
     *         dimension; an empty <code>DataAccess</code> object, which
     *         contains zero values, if there is no selection available to
     *         evaluate.
     *
     * @status Documented
     */
    public DataAccess getDataAccess(String dimension);
    
    /**
     * Retrieves the <code>selection</code> object that is currently stored for
     * the specified dimension.
     * 
     * @param dimension The dimension for which to return the
     *                  <code>selection</code> object.
     *
     * @return The <code>selection</code> object that is stored for the
     *         specified dimension; <code>null</code> if there is no
     *         dimension stored and if the underlying
     *         <code>QueryContext</code> can not provide a selection for the
     *         specified dimension.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection getSelection(String dimension);    */
    
    /**
     * Stores the specified selection in the selection collection and uses the
     * selection's dimension as its key. These stored selections can be applied
     * to the <code>QueryContext</code> implementor later through the
     * <code>applyQueryAccess</code> method. To retrieve a stored selection,
     * use <code>getSelection(selection.getDimension())</code>.
     * <p>
     * Invoking the <code>setSelection</code> method causes
     * <code>isSelectionSet(selection.getDimension())</code> to return
     * <code>true</code>.
     * 
     * @param sel The selection to store.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public void setSelection(Selection sel);*/
    
    /**
     * Indicates whether a specified dimension has a selection stored for it
     * in the <code>QueryAccess</code> object.
     *
     * @param dimension The dimension to test.
     *
     * @return <code>true</code> if the dimension has a selection stored for it,
     *         <code>false</code> if the dimension does not have a selection
     *         stored for it. Note that whether the underlying
     *         <code>QueryContext</code>
     *         implementation can provide a selection for the specified
     *         dimension does not determine the return value.
     *
     * @status Documented
     */
    public boolean isSelectionSet(String dimension);
    
    /**
     * Retrieves the current dimensionality tracked by the
     * <code>QueryAccess</code> object or the set of measures chosen in the
     * selection table for the specified type of metadata.
     *
     * @param type One of the enumerated label types in
     *             <code>oracle.dss.util.LayerMetadataMap</code> that specifies
     *             the type of metadata to be returned (such as dimension
     *             database name, short label, long label, etc.).
     *
     * @return The list of dimension member name strings.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public Vector getDimensions(String type);    
    
    /**
     * Updates the current dimension list based on a specified set of measures.
     * This method can delete stored <code>selection</code> objects whose
     * dimensions do not match the new dimensionality of the specified measures.
     * This method alters the list that is returned by the
     * <code>getDimensions</code> method.
     *
     * @param measures The list of measures from which to determine the
     *                 <I>legal</I> stored selections and the dimension list.
     *
     * @status Documented
     */
    public void updateDimensions(String[] measures);    

    /**
     * Retrieves the name of the measure dimension that is currently used by the
     * <code>QueryAccess</code> object.
     * 
     * @param type One of the enumerated label types in
     *             <code>oracle.dss.util.LayerMetadataMap</code> that specifies
     *             the type of metadata to be returned (such as dimension
     *             database name, short label, long label, etc.).
     *
     * @return The name of the measure dimension in the specified label type.
     *
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
     * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
     *
     * @status Documented
     */
    public String getMeasureDimension(String type);    
    
   /**
    * Retrieves the properly initialized <code>OLAPQDR</code> for the specified
    * measure and dimension. This <code>OLAPQDR</code> leaves the following
    * dimensions as varying dimensions:
    * any dimensions on the page edge or on the same edge as the specified
    * dimension; all other dimensions are fixed.
    * <p>
    * Note: An <code>OLAPQDR</code> (qualified data reference) is a reference
    * to a subset of the values in a data source such as the <code>Query</code>
    * object.
    * For example, an <code>OLAPQDR</code> might refer to a Sales measure, but
    * only to those values for the month of May.
    * In another example, an <code>OLAPQDR</code> might refer to a Units measure,
    * but only to the single value that represents the units of TVs sold by
    * catalog in May in Dublin.
    *
    * @param measure   The measure to use in initializing the <code>OLAPQDR</code>.
    *                  This measure determines the dimensions to include in the
    *                  fully qualified <code>OLAPQDR</code>.
    * @param dimension The dimension that represents the edge on which other
    *                  dimensions should be varying rather than fixed
    *                  within the <code>OLAPQDR</code>.
    * @param type      One of the enumerated label types in
    *                  <code>oracle.dss.util.LayerMetadataMap</code> that
    *                  specifies the type of metadata to be returned (such as
    *                  dimension database name, short label, long label, etc.).
    *
    * @return The <code>OlapQDR</code> object initialized with the correct
    *         values for the specified measure and dimension.
    *
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
    * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_DISPLAYNAME
    *
    * @status Documented
    */
   	public OlapQDR getQDR (String measure, String dimension, String type);

    /**
     * Return a list of values of type <code>type</code> up to the maximum
     * number specified, from the given type and/or label type.  Use the context
     * from which this QueryAccess was created to retrieve the values, if possible.
     *
     * @param type  if <code>null</code>, return a Vector of <code>DimensionMember</code>
     *              objects containing the member ID values and the type specified in
     *              strLabelType.  If not null, return a Vector of objects of type <code>type</code>.
     * @param max   return up to this many items, regardless of the number available.  The number returned
     *              may be less than <code>max</code>.
     * @param dimension the dimension for which to return values.
     * @param hierarchy the hierarchy for which to return values.
     * @param strLabelType  the type to place in the <code>DimensionMember</code> IDs, if <code>type</code> is <code>null</code>.
     *
     * @status New
     */
    public Vector getValues(String type, int max, String dimension, String hierarchy, String strLabelType);
   	
   	/**
   	 * Specifies the types of metadata to use for all cursor evaluation.
   	 *
   	 * @param map Set of MetadataMap types for which to return cursor data
     *            when evaluating dimension selections.
     *
   	 * @status Documented
   	 */
   	public void setMetadataMap(MetadataMap map);
    
    /**
     * Migrate Selection to unique value mode
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection migrateToUnique(Selection sel);*/
    
    /**
     * Migrate Step to unique value mode
     */
     // blm - Selection code moved to dvt-olap
/*    public Step migrateToUnique(Step step);*/

    /**
     * Return a default selection that produces members + a DataAccess
     */
     // blm - Selection code moved to dvt-olap
/*    public DefaultStepInfo getDefaultStep(String dimension, String hierarchy, boolean fullListDim, Vector preferredLevels, int preferredMaxLevels) throws Exception;*/
    
    /**
     * Return a default selection that optionally produces members
     * @param dimension
     * @param hierarchy
     * @param fullListDim
     * @param preferredLevels
     * @param preferredMaxLevels
     * @return
     * @throws Exception
     */
     // blm - Selection code moved to dvt-olap
/*    public DefaultStepInfo getDefaultStep(String dimension, String hierarchy, boolean fullListDim, Vector preferredLevels, int preferredMaxLevels, boolean fallBack) throws Exception;*/
    
    /**
     * @hidden
     * Internal metadata type for step source blocks.  Used by the QueryBuilder
     * to access "extra" metadata for the drill call on a Selection.  Optional.
     *
     * @status Documented
     */
    public static final String METADATA_BLOCK = "SourceBlock";
    
    /**
     * @hidden
     * Internal metadata type for query parent information.  Used by the
     * QueryBuilder
     * to access "extra" metadata for the drill call on a Selection.  Optional.
     *
     * @status Documented
     */
    public static final String METADATA_QUERYPARENT = "QueryParent";

    /**
     * @hidden
     * Internal metadata type for determining the number of children a particular
     * member has across an entire hierarchy.  May be used for determining whether
     * a member is a leaf node in a hierarchy.
     *
     * @status New
     */
    public static final String METADATA_CHILDCOUNT = "ChildCount";
    
    // blm - Selection code moved to dvt-olap
/*    public class DefaultStepInfo extends Object
    {
        protected Step m_defaultStep = null;
        protected DataAccess m_da = null;
        
        public DefaultStepInfo(Step defaultStep, DataAccess da)
        {
            super();
            m_defaultStep = defaultStep;
            m_da = da;
        }
        
        public DataAccess getDataAccess()
        {
            return m_da;
        }
        
        public Step getStep()
        {
            return m_defaultStep;
        }
    }*/
}