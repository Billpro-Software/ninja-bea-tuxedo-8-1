/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.text.Collator;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;

import oracle.dss.util.persistence.PersistableConstants;

/**
 * The BISearchResult class is a structure that contains
 * the name of the object, the class name of the object, a reference to the
 * object, as well as the attributes associated with the object.
 * The <code>BISearchResult</code> object is returned when any of the search
 * methods is called on a directory. The 'real' object can be loaded on
 * demand by invoking the <code>getObject</code> method of the
 * <code>BISearchResult</code>.
 *
 * <p>The attributes that are included in the BISearchResult depend on whether
 * the optional third parameter was used when the search method was invoked.
 * The third parameter of the search methods lets you specify one of the
 * following:
 * <ul>
 * <li>The returningAttributes parameter, which is a <code>String</code> array
 * of constants that identify attributes. </li>
 * <li>The searchControls parameter, which is a <code>BISearchControls</code>
 * object. The setReturningAttributes method of BISearchControls lets you
 * specify a <code>String</code> array of constants that identify attributes.</li>
 * </ul>
 * If the third parameter of the <code>search</code> method is not supplied,
 * then all predefined attributes are returned for the objects that are
 * selected by the search.</p>
 *
 * @see oracle.dss.bicontext.BISearchControls
 *
 * @status documented
 */
public class BISearchResult extends SearchResult
    implements Comparable, ObjectLoaderTarget
{
    private String m_type;
    private String m_label;
    private transient ObjectLoader m_loader;

    /**
     * @hidden
     */
    public BISearchResult(String name, Object obj, Attributes attrs, String type)
    {
        super(name, obj, attrs);
        m_type = type;
    }



    /**
     * @hidden
     */
    public BISearchResult(String name, String className, Object obj, Attributes attrs, String type)
    {
        super(name, className, obj, attrs);
        m_type = type;
    }

    /**
     * @hidden
     */
    public BISearchResult(String name, Object obj, Attributes attrs, boolean isRelative, String type)
    {
        super(name, obj, attrs, isRelative);
        m_type = type;
    }


    /**
     * @hidden
     */
    public BISearchResult(String name, String className, Object obj, Attributes attrs, boolean isRelative, String type)
    {
        super(name, className, obj, attrs, isRelative);
        m_type = type;
    }



    /**
     * Returns the label of the enclosing object.
     *
     * @return the label of the enclosing object.
     *
     * @status New
     */
    public String getLabel()
    {
        if (m_label != null)
            return m_label;
        else
            return getName();
    }

    /**
     * @hidden
     */
    public void setLabel(String label)
    {
        m_label = label;
    }

    /**
     * Returns the object type of the enclosing object.
     *
     * @return the object type of the enclosing object.
     *
     * @status New
     */
    public String getObjectType()
    {
        return m_type;
    }

    /**
     * @hidden
     */
    public void setObjectType(String type)
    {
        m_type = type;
    }

    /**
     * @hidden
     */
    public void setObjectLoader(ObjectLoader loader)
    {
        m_loader = loader;
    }

    /**
     * @hidden
     */
    public ObjectLoader getObjectLoader()
    {
        return m_loader;
    }

    /**
     * @hidden
     */
    public Object getObjectDefinition()
    {
        return getObject();
    }

    /**
     * Default implementation of Comparable interface
     * If o is not an instance of SearchResult class, the result of sorting is unpredictable
     *
     * @hidden
     */
    public int compareTo(Object o)
    {
        // Compare based on object names (names are always guaranteed to be non-null in BISearchResults)
        if (o instanceof BISearchResult)
        {
            // move folders to the top: if one is a folder and the other one is not,
            // propagate the folder to the top.
            if (this.getObjectType().equals(PersistableConstants.FOLDER) &&
                !((BISearchResult)o).getObjectType().equals(PersistableConstants.FOLDER))
                return -1;
            if (((BISearchResult)o).getObjectType().equals(PersistableConstants.FOLDER)&&
                !this.getObjectType().equals(PersistableConstants.FOLDER))
                return 1;
            else
            {
                // object names are strings, so compare using Collator with JVM's Locale
                Collator col = Collator.getInstance();
                return col.compare(this.getName(), ((BISearchResult)o).getName());
            }
        }
        else // o is not a SearchResult instance, push it down
            return -1;
    }
}