/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners when the layout of the <code>Query</code> object is about
 * to change. A listener has the option to veto the change by calling the
 * <code>consume</code> method of this event. If a listener vetoes the
 * operation, then subsequent listeners are not notified and the operation is
 * cancelled (that is, the operation is not added to the pending operation
 * queue).
 *
 * @status Documented
 */
public class LayoutChangingEvent extends LayoutEvent implements Consumable
{
    /**
     * Constructor to use if the affected dimension names are available from
     * the original call that is about to change the layout.
     *
     * @param source      The source of the event, that is, a reference to the
     *                    object that fired the event.
     * @param dimensions  The names of the dimensions that are affected
     *                    by the call that will change the layout.
     *
     * @status Documented
     */
    public LayoutChangingEvent(Object source, String[][] dimensions) {
        super(source, null, dimensions);
    }    

    /**
     * Constructor to use to specify the kind of pivot.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param sourcedim   The name of the source dimension for a pivot or swap.
     * @param targetdim   The name of the target dimension for a pivot or swap.
     * @param flags       A constant that indicates the type of pivot. Use
     *                    either <code>PivotConstants.PIVOT_AFTER</code> or
     *                    <code>PivotConstants.PIVOT_BEFORE</code>.
     *
     * @see PivotConstants#PIVOT_AFTER
     * @see PivotConstants#PIVOT_BEFORE
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutChangingEvent(Object source, String sourcedim, String targetdim, int flags) {
        super(source, null, sourcedim, targetdim, null, flags);
    }    

    /**
     * Constructor to use for a swap or pivot of specific dimensions.
     * 
     * @param source       The source of the event, that is, a reference to the
     *                     object that fired the event.
     * @param sourcedim   The name of the source dimension for a pivot or swap.
     * @param targetdim   The name of the target dimension for a pivot or swap.
     *
     * @status needs change inclAdjacent parameter removed
     */
    public LayoutChangingEvent(Object source, String sourcedim, String targetdim) {
        super(source, null, sourcedim, targetdim, null);
    }    

    /**
     * Constructor to use for an edge swap.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param sourceedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the source edge for an edge swap.
     * @param targetedge A constant (<code>DataDirector.COLUMN_EDGE</code>,
     *                   <code>DataDirector.PAGE_EDGE</code>, or
     *                   <code>DataDirector.ROW_EDGE</code>) that represents
     *                   the target edge for an edge swap.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * @status Documented
     */
    public LayoutChangingEvent(Object source, int sourceedge, int targetedge) {
        super(source, sourceedge, targetedge, null);
    }    
    
    /**
     * Consumes this event.
     *
     * @status Documented
     */
    public void consume() {
        super.consume();
    }
    
    /**
     * Indicates whether this event was consumed.
     *
     * @return <code>true</code> if consumed, <code>false</code> if not.
     *
     * @status Documented
     */
    public boolean isConsumed() {
        return super.isConsumed();
    }        
}
