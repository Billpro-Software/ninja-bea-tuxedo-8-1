// Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
/**
 * Resources for metadataUtil.
 *
 */
package oracle.dss.metadataUtil.resource;

import java.util.ListResourceBundle;
/**
 * @hidden
 * @status hidden
 */
public class MetadataUtilBundle extends ListResourceBundle
{
   /**
    * Database messages have been assigned a range from DVT-10000 to DVT-10999.
    * Database Client messages start at DVT-10000
    *
    * @status documented
    */
    public static final String EXC_INCONSUMABLE_EVENT         = "10000";
    static final Object[][] metadataUtilResources = {
        /**
         * @error DVT-10000 Event is not consumable.
         * @cause An attempt was made to consume an event that is not consumable.
         * @action No action is necessary.
         * @status documented
         */
        {EXC_INCONSUMABLE_EVENT, "Event is not consumable." }
    };

   /**
    * Return the string resource table.
    *
    * @status protected
    */
    protected Object[][] getContents()
    {
        return metadataUtilResources;
    }
}