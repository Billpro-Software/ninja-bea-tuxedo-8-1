/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/query/DataUtils.java /bibeans_root/32 2009/03/27 16:40:15 bmoroze Exp $
 *
 * Copyright (c) 1999, 2009, Oracle and/or its affiliates. 
All rights reserved. 
 */

package oracle.dss.datautil.query;

import java.awt.event.FocusEvent;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.accessibility.AccessibleContext;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTree;
import javax.swing.SwingConstants;

import oracle.bali.share.nls.StringUtils;

import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryState;
import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MDHierarchy;
import oracle.dss.metadataManager.common.MDLevel;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDSearchControls;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MMUtilities;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.Property;
import oracle.dss.persistence.PSRConstants;
import oracle.dss.selection.OlapQDR;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.selection.dataFilter.VariableSettingDataFilter;
import oracle.dss.selection.parameter.ItemValueParameter;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.Utility;
import oracle.dss.util.format.BaseViewFormat;
import oracle.dss.util.parameters.Parameter;
import oracle.dss.util.persistence.Persistable;
import oracle.dss.util.persistence.PersistableAttributes;
import oracle.dss.util.persistence.PersistableConstants;


/** gek 11/03/06
import oracle.dss.calculation.client.calcBuilder.CalcBuilderContext;
import oracle.dss.calculation.client.MDMeasureCalc;
*/

// import oracle.dss.datautil.persistence.MDCalcPersistable;

//HBR: Persistence removal
//import oracle.dss.persistence.persistencemanager.common.PersistenceNameParserImpl;

/** gek 11/03/06
import oracle.dss.selection.calcStep.CalcStep;
import oracle.dss.selection.calcStep.CalcValue;
*/

/**
 * <pre>
 * Utility class containing data beans related methods.
 * </pre>
 *
 * 
 *
 * MODIFIED    (MM/DD/YY)
 *    gkellam   01/05/09 - Tweak RangeDataFilter parameter handling.
 *    gkellam   12/29/08 - Fix RangeDataFilter parameter parsing logic.
 *    gkellam   12/24/08 - Fix BUG 7667096 - CANNOT SPECIFY 'PARAMETER ACCEPTS
 *                         MULTIPLE VALUES' FOR COMPOUND DATA FILTERS.
 *    gkellam   12/03/08 - Continue variable work.
 *    gkellam   06/11/08 - Add support for multiple parameter values.
 *    gkellam   06/10/08 - Add ability to trim delimited strings.
 *    bmoroze   05/27/08 - 
 *    gkellam   04/01/08 - Fix Date processing.
 *    gkellam   03/31/08 - Address DataFilter evaluation issues related to
 *                         updated date handling.
 *    gkellam   03/21/08 - Add some Date utilities.
 *    gkellam   03/18/08 - Fix Bug 6890560 - DataFilter UI logic needs to be
 *                         updated to distinguish measures, dimensions.
 *    gkellam   12/03/07 - Fix Bug 6656326 - QueryBuilder: Scenario where can't
 *                         change from Compound back to Simple.
 *    gkellam   11/26/07 - Tweak value parsing logic.
 *    gkellam   11/18/07 - Tweak Number handling.
 *    gkellam   11/16/07 - Add ability to tokenize quotes.
 *    gkellam   11/05/07 - Add ability to create a label based on a single
 *                         value.
 *    gkellam   11/02/07 - Add missing TopBottomDataFilter and RangeDataFilter
 *                         parameter support.
 *    gkellam   08/29/07 - When processing members, if we find an MDItem,
 *                         return label instead of ID.
 *    gkellam   08/02/07 - Improve data error handling.
 *    gkellam   07/29/07 - Add support for Between/Not Between DataFilter.
 *    bmoroze   06/06/07 - 
 *    gkellam   05/14/07 - Fix Bug 6047578 - QueryBuilder: Erroneous error msg
 *                         in advanced (compound) data filter dlg.
 *    gkellam   05/14/07 - Fix Bug 6051496 - PARAMETER XML IS IMPROPERLY
 *                         QUOTING DEFAULT VALUES.:
 *    gkellam   05/11/07 - Tweaks for TopBottomDataFilter.
 *    bmoroze   03/15/07 - 
 *    gkellam   03/09/07 - Check for existing quotes before encoding.
 *    gkellam   03/07/07 - Move common utility methods.
 *    gkellam   03/01/07 - Add support for parameterizing operators.
 *    gkellam   02/25/07 - Continue Parameter parsing support.
 * 
 */
public class DataUtils extends Object {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @internal
   * 
   * Default Date pattern used for user validation.
   * 
   * 
   */
  public static String DEFAULT_DATE_INPUT_DATE_TIME = "MM/dd/yyyy hh:mm:ss";

  /**
   * @internal
   * 
   * Default Date pattern used for user validation.
   * 
   * 
   */
  public static String DEFAULT_DATE_INPUT_DATE = "MM/dd/yyyy";
  
  /**
   * @internal
   * 
   * Default Date pattern used for user validation.
   * 
   * 
   */
  public static String DEFAULT_DATE_OUTPUT_DATE = DEFAULT_DATE_INPUT_DATE;

  /**
   * @internal
   * 
   * Default Date pattern used for Answers evaluation.
   * 
   * 
   */
  public static String DEFAULT_EVAL_ANSWERS_OUTPUT_DATE_TIME = "yyyy-MM-dd'T'hh:mm:ss";

  /**
   * @internal
   * 
   * Default Date pattern used for Answers evaluation.
   * 
   * 
   */
  public static String DEFAULT_EVAL_ANSWERS_INPUT_DATE = DEFAULT_EVAL_ANSWERS_OUTPUT_DATE_TIME;

  /**
   * @internal
   * 
   * Default Date pattern used for Answers evaluation.
   * 
   * 
   */
  public static String DEFAULT_EVAL_ANSWERS_OUTPUT_DATE = "yyyy-MM-dd'T'00:00:00";

  /**
   * @internal
   *
   * Default data types.
   *
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * 
   * 
   */
  protected static String[] DEFAULT_DATA_TYPES = 
    new String[] {MM.INTEGER, MM.SHORT, MM.LONG, MM.FLOAT, MM.DOUBLE};

  /**
   * @internal
   * 
   * Property used to store the number of intersecting dimensions used to 
   * determine dimensional ranking.
   * 
   * This property can be specified as a <code>MDObject</code> IntPropertyValue
   * or as a <code>MetadataManagerSearchResultImpl Attribute</code>.
   * 
   * 
   */
  private static String FILTER_DIMENSION_RANK = "FilterDimensionRank";

  // Data type classes
  private static final int CLASS_UNKNOWN      = -1;
  private static final int CLASS_NUMERIC      = 0;
  private static final int CLASS_NON_NUMERIC  = 1;

  /**
   * Filter none.  Do not filter dimensions.
   *
   * 
   */
  public static final int FILTER_NONE    = 0;

  /**
   * Filter dimensions by measure.  Filters out all dimensions that aren't
   * dimensioned by a Measure.
   *
   * 
   */
  public static final int FILTER_BY_MEASURE = 1;

  /**
   * Filter dimensions by hierarchy.  Filters out all dimensions that don't
   * contain a hierarchy.
   *
   * 
   */
  public static final int FILTER_BY_HIERARCHY = 2;

  /**
   * @internal
   *
   * If we have a custom measure which is part of a selection, blast it away
   * from our measure list to insure that we pick up any changes to the
   * underlying custom measures (if any).
   *
   * 
   */
  public final static int MEASURE_REMOVE = 0;

  /**
   * @internal
   *
   * Converts persisted aggregate measure ID based on position to
   * MetadataManager runtime ID.
   *
   * 
   */
  public final static int MEASURE_AGG_TO_RUNTIME = 1;

  /**
   * @internal
   *
   * Converts MetadataManager runtime ID to persisted aggregate ID based on
   * position.
   *
   * 
   */
  public final static int MEASURE_RUNTIME_TO_AGG = 2;

  /**
   * @internal
   *
   * Converts persisted aggregate favorite ID based on position to
   * MetadataManager runtime ID.
   *
   * 
   * @deprecated As of 2.8.0.50, should be using SavedSelectionStep
   */
  public final static int FAVORITE_AGG_TO_RUNTIME = 0;

  /**
   * @internal
   *
   * Converts MetadataManager runtime ID to persisted aggregate ID based on
   * position.
   *
   * 
   * @deprecated As of 2.8.0.50, should be using SavedSelectionStep
   */
  public final static int FAVORITE_RUNTIME_TO_AGG = 1;

  /**
   * @internal
   *
   * Transient Hashtable used when saving to associated persisted aggregate IDs
   * based on position to associated MetadataManager runtime IDs.
   *
   * 
   */
  private transient static Hashtable m_aggregatedMeasures = new Hashtable();

  /**
   * @internal
   *
   * Token used to delimit items used in a data filter.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_DELIMETER_EMPTY = "";

  /**
   * @internal
   *
   * Token used to delimit items used in a data filter.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_DELIMETER = ",";

  /**
   * @internal
   *
   * Quote regular expression used to delimit items used in a data filter.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_REGEX_QUOTES = "(\'|\")";

  /**
   * @internal
   *
   * Token used to specify parameters used in a data filter.
   * 
   * Note: This should be in a resource file.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_PARAMETER = ":";

  /**
   * @internal
   *
   * Token used to specify parameters used in a data filter that accept multiple
   * values.
   * 
   * Note: This should be in a resource file.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_PARAMETER_ACCEPT_MULTIPLE_VALUES = "::";

  /**
   * @internal
   *
   * Token used to specify the start of parameter values in a data filter.
   * 
   * Note: This should be in a resource file.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_PARAMETER_VALUE_START = "(";

  /**
   * @internal
   *
   * Token used to specify the end of parameter values in a data filter.
   * 
   * Note: This should be in a resource file.
   *
   * 
   */
  public final static String DATAFILTER_TOKEN_PARAMETER_VALUE_END = ")";

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * Constructs a default DataUtils object.
   *
   * 
   */
  public DataUtils () {
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieve the <code>MDObject</code> associated with the specified ID.
   * 
   * @param componentContext A <code>ComponentContext</code> used to retrieve a 
   *        <code>MetadataManager</code> reference.
   * @param strID A <code>String</code> representing the <code>MetadataManager</code> 
   *        unique ID.
   * 
   * @return <code>MDObject</code> associated with the specified ID.
   * 
   * 
   */
  public static MDObject getMDObject (ComponentContext componentContext, String strID) {
    MDObject mdObject = null;
      
    try {
      if (componentContext != null) {
        if (componentContext.getBIProvider() != null) {
          if (componentContext.getBIProvider().getMetadataManager() != null) {
            mdObject = 
              componentContext.getBIProvider().getMetadataManager().getMDObjectByUniqueID (strID);
          }    
        }    
      }
    }
  
    // Ignore exceptions
    catch (MetadataManagerException metadataManagerException) {
    }
  
    return mdObject;
  }

  public static boolean canAcceptMultipleValues (BaseDataFilter baseDataFilter) {
    boolean bAcceptMultipleValues = false;

    // Initialize Accept Multiple Values
    if (baseDataFilter != null) {
      Parameter[] parameters = baseDataFilter.getParameters();
      Parameter parameter = null;
      
      if ((parameters != null) && (parameters.length > 0)) {
        for (int nIndex = 0; nIndex < parameters.length; nIndex++) {
          parameter = parameters[nIndex];
          
          if ((parameter != null) && (parameter.canAcceptMultipleValues())) {
            bAcceptMultipleValues = true;
            break;   
          }
        }  
      }
    }

    return bAcceptMultipleValues;
  }
  
  /**
   * Creates a delimited list of members.
   * 
   * @param vobjMembers A <code>Vector</code> of <code>Object</code> members to encode.
   * @param bUnformatted A <code>boolean</code> which is <code>true</code> when the
   *        output should be unformatted and <code>false</code> otherwise.
   * 
   * @return <code>String</code> representing the delimited list.
   */
  public static String makeMembersLabel (ComponentContext componentContext, 
      Vector vobjMembers, boolean bUnformatted) {
    String strMember = null;
    String strLabel = bUnformatted ? new String() : new String("(");

    if (vobjMembers != null) {
      for (int i = 0; i < vobjMembers.size(); i++) {

        if (!bUnformatted) {
          
          // TODO Allow locale to be specified
          strMember = format (componentContext, vobjMembers.elementAt(i), Locale.getDefault());
          
          // Check for existing quotes before encoding
          if (!strMember.startsWith("'")) {
            strLabel += "'";  
          }

          strLabel += strMember;
        
          if (!strMember.endsWith("'")) {
            strLabel += "'";  
          }
        }
        else {
          // TODO Allow locale to be specified
          strLabel += format (componentContext, vobjMembers.elementAt(i), Locale.getDefault());
        }

        if (i < vobjMembers.size() - 1) {
          strLabel += ",";
        }
      }
    }

    if (!bUnformatted) {
      strLabel += ")";
    }

    return strLabel;
  }

  /**
   * Creates a delimited list of members.
   * 
   * @param strMember A <code>String</code> representing the member to encode.
   * @param bUnformatted A <code>boolean</code> which is <code>true</code> when the
   *        output should be unformatted and <code>false</code> otherwise.
   * 
   * @return <code>String</code> representing the delimited list.
   */
  public static String makeMemberLabel (String strMember, boolean bUnformatted) {
    String strMembers = null;
    if (strMember != null) {
      Vector vstrMembers = new Vector();
      vstrMembers.add (strMember);
      
      strMembers = makeMembersLabel (null, vstrMembers, bUnformatted);
    }
 
    return strMembers;
  }

  /**
   * Creates a delimited list of members.
   * 
   * @param vstrMembers A <code>Vector</code> of <code>String</code> members to encode.
   * @param bUnformatted A <code>boolean</code> which is <code>true</code> when the
   *        output should be unformatted and <code>false</code> otherwise.
   * 
   * @return <code>String</code> representing the delimited list.
   */
  public static String makeMembersLabel (Vector vstrMembers, boolean bUnformatted) {
    return makeMembersLabel (null, vstrMembers, bUnformatted);
  }

  /**
   * Creates a delimited list of members.
   * 
   * @param objMember A <code>Object</code> member to encode.
   * @param bUnformatted A <code>boolean</code> which is <code>true</code> when the
   *        output should be unformatted and <code>false</code> otherwise.
   * 
   * @return <code>String</code> representing the delimited list.
   */
  public static String makeMemberLabel (Object objMember, boolean bUnformatted) {
    String strMember = null;
    String strLabel = bUnformatted ? new String() : new String("(");

    if (objMember != null) {
      if (!bUnformatted) {
        strMember = objMember.toString();
        
        // Check for existing quotes before encoding
        if (!strMember.startsWith("'")) {
          strLabel += "'";  
        }

        strLabel += strMember;
      
        if (!strMember.endsWith("'")) {
          strLabel += "'";  
        }
      }
      else {
        strLabel += objMember;
      }
    }

    if (!bUnformatted) {
      strLabel += ")";
    }

    return strLabel;
  }

  /**
   * @internal
   *
   * Attempts to create a <code>Double</code> based <code>CalcValue</code> from 
   * the specified <code>String</code> value using the chosen <code>Locale</code>.
   *
   * @param strValue A <code>String</code> value to retrieve the <code>Double</code>
   *        <code>CalcValue</code> for.
   * @param locale A <code>Locale</code> to use when parsing the <code>String</code>
   *        value.
   *
   * @return <code>CalcValue</code> which contains the <code>Double</code> 
   *         representation of the specified <code>String</code> value based on
   *         the chosen <code>Locale</code>.  A null is returned if a 
   *         <code>CalcValue</code> cannot be generated.
   *
   * 
   */
  /** gek 11/03/06
  public static CalcValue parseCalcValueDouble (String strValue, Locale locale) {
    
    CalcValue calcValue = null;
    
    // Attempt to generate a Double value from the string
    Double doubleValue = parseDouble (strValue, locale);    
        
    if (doubleValue != null) {
      calcValue = new CalcValue (doubleValue , Double.class);  
    }
  
    return calcValue;
  }
  */

  /**
   * @internal
   *
   * Attempts to create a <code>Double</code> value from the specified 
   * <code>String</code> and chosen code>Locale</code>.
   * 
   * @param strValue A <code>String</code> value to retrieve the <code>Double</code>
   *        value for.
   * @param locale A <code>Locale</code> to use when parsing the <code>String</code>
   *        value.
   *
   * @return <code>Double</code> representation of the specified <code>String</code> 
   *         based on the chosen <code>Locale</code>.  A null if returned of a 
   *         <code>Double</code> value cannot be generated.
   * 
   * 
   */
  public static Double parseDouble (String strValue, Locale locale) {
    
    Double doubleValue = null;
    
    // Attempt to parse the string into a Double
    try {
      Number numValue = parseNumber(strValue, locale, false);
      if (numValue != null) {
        doubleValue = new Double(numValue.doubleValue());
      }
    } 
    
    catch (Exception exception) {
      // Ignore exception and simply return null
    }
  
    return doubleValue;
  }

  /**
   * @internal
   * 
   * Attempts to generate a <code>String</code> representation of the 
   * specified <code>Double</code> value based on the chosen locale.
   * 
   * @param doubleValue A <code>Double</code> value to retrieve the <code>String</code>
   *        representation for.
   * @param locale A <code>Locale</code> to use when generating the <code>String</code>
   *        representation.
   *
   * @return <code>String</code> representation of the specified <code>Double</code> 
   *         value based on the chosen<code>Locale</code>.  A null if returned 
   *         if <code>String</code> cannot be generated.
   *        
   *        
   */
  public static String formatDouble (Double doubleValue, Locale locale) {
    
    String strValue = null;
    
    // Attempt to parse the string into a Double
    try {
      if (doubleValue != null) {
        strValue = formatNumber(doubleValue, locale);
      }
    } 
    
    catch (Exception exception) {
      // Ignore exception and simply return null
    }
  
    return strValue;
  }

  /**
   * @internal
   * 
   * Attempts to generate a <code>String</code> representation of the 
   * specified <code>Number</code> value based on the chosen locale.
   * 
   * @param num A <code>Number</code> value to retrieve the <code>String</code>
   *        representation for.
   * @param locale A <code>Locale</code> to use when generating the <code>String</code>
   *        representation.
   *
   * @return <code>String</code> representation of the specified <code>Number</code> 
   *         value based on the chosen<code>Locale</code>.
   *        
   *        
   */
  public static String formatNumber(Number num, Locale locale) {
    NumberFormat nf = NumberFormat.getInstance(locale);
    nf.setMaximumFractionDigits(Integer.MAX_VALUE);      
    return nf.format(num.doubleValue());
  }

  /**
   * @internal
   *
   * Attempts to create a <code>Number</code> value from the specified 
   * <code>String</code> and chosen code>Locale</code>.
   * 
   * @param strValue A <code>String</code> value to retrieve the <code>Number</code>
   *        value for.
   * @param locale A <code>Locale</code> to use when parsing the <code>String</code>
   *        value.
   * @param integer A <code>boolean</code> indicating whether the Number should be parsed
   *        as an <code>Integer</code>
   *
   * @return <code>Number</code> representation of the specified <code>String</code> 
   *         based on the chosen <code>Locale</code>.  A <code>NumberFormatException</code> is thrown
   *         if a <code>Number</code> value cannot be generated.
   * 
   * 
   */
  public static Number parseNumber(String strValue, Locale locale, boolean integer) {
    // Trim off white space
    strValue = strValue == null ? "" : strValue.trim();
    
    NumberFormat nf = NumberFormat.getInstance(locale);
    nf.setParseIntegerOnly(integer);
    // Replace space (0x20) with non-breaking space (0xA0)
    if (nf instanceof DecimalFormat) {
      DecimalFormat df = (DecimalFormat)nf;
      if (df.getDecimalFormatSymbols() != null) {
        DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
        if (dfs.getGroupingSeparator() == 0xA0) {
          strValue = strValue.replace((char)0x20, (char)0xA0);
        }
      }
    }
    ParsePosition pp = new ParsePosition(0);
    Number num = nf.parse(strValue, pp);
    
    if (num == null || pp.getIndex() != strValue.length()) {
      throw new NumberFormatException(strValue);
    }
    
    return num;
  }

  /**
   * @internal
   *
   * Retrieves a <code>Vector</code> of <code>MetadataManager</code> unique 
   * IDs associated with each <code>DimensionMember</code> object.
   *
   * @param vDimensionMembers A <code>Vector</code> of <code>DimensionMember</code>
   *        objects to retrieve <code>MetadataManager</code> unique IDs for.
   *
   * @return A <code>Vector</code> of <code>MetadataManager</code> unique 
   *         IDs associated with each <code>DimensionMember</code> object.
   *         
   * 
   */
  public static Vector getIDs (Vector vDimensionMembers) {
    Vector vstrIDs = null;

    DimensionMember dimensionMember;
    String strID;
    
    if ((vDimensionMembers != null) && (!vDimensionMembers.isEmpty())) {
      vstrIDs = new Vector();
      
      for (int nIndex = 0; nIndex < vDimensionMembers.size(); nIndex++) {
        dimensionMember = (DimensionMember) vDimensionMembers.get (nIndex);    
        
        if (dimensionMember != null) {
          strID = (String) dimensionMember.getObject();          

          if (strID != null) {
            vstrIDs.add (strID);      
          }
        }
      }
    }
    
    return vstrIDs;
  }

  /**
   * @internal
   *
   * Filters out measures that are not dimensioned by Time.
   *
   * This method removes measures that are not dimensioned by time from the
   * specified list.  This includes any values that can't be verified.
   *
   * @param metadataManager The <code>MetadataManagerServices</code> object 
   *        from which to retrieve the dimensions.
   * @param vstrMeasureIDs The <code>Vector</code> of <code>MetadataManager</code>
   *        uniqueIDs representing the measures to filter.
   * @param bIsValueBasedHiersAllowed A <code>boolean</code> value which is 
   *        <code>true</code> if value-based hierarchies are allowed and 
   *        <code>false</code> otherwise.
   *
   * @return A <code>Vector</code> value that contains the updated measure
   *         list filtered by Time.
   *         
   * 
   */
  public static Vector filterByTime (MetadataManagerServices metadataManager, 
    Vector vstrMeasureIDs, boolean bIsValueBasedHiersAllowed) {

    // Check for invalid input
    if (vstrMeasureIDs == null || vstrMeasureIDs.size() == 0)
      return vstrMeasureIDs;

    // If we can't verify that we have any time dimensions, remove everything
    if (metadataManager == null)
      vstrMeasureIDs.removeAllElements();

    String strMeasureID;
    
    // Iterate over each measure, starting at the end
    for (int nIndex = vstrMeasureIDs.size() - 1; nIndex >= 0; nIndex--) {
      strMeasureID = (String) vstrMeasureIDs.elementAt(nIndex);

      try {
        // Filter out measures which don't have any time dimensions
        Vector vTimeDimensions =
          getTimeDimensions (metadataManager, strMeasureID);

        // Determine if value based hierarchies are allowed
        if (!bIsValueBasedHiersAllowed) {
          vTimeDimensions = 
            filterByValueBasedHierarchy (metadataManager, vTimeDimensions);
        }

        // If we don't have any time dimensions, remove measure
        if ((vTimeDimensions == null) || (vTimeDimensions.size() == 0)) {
          vstrMeasureIDs.removeElementAt (nIndex);
        }
      }
    
      // Remove measure if it cannot be verified        
      catch (MetadataManagerException metadataManagerException) {
        vstrMeasureIDs.removeElementAt (nIndex);
      }
    }

    // Return measures which are dimensioned by Time
    return vstrMeasureIDs;
  }

  /**
   * @internal
   *
   * Filters out measures that are not dimensioned by Time.
   *
   * This method removes measures that are not dimensioned by time from the
   * specified list.  This includes any values that can't be verified.
   *
   * @param metadataManager The <code>MetadataManagerServices</code> object 
   *        from which to retrieve the dimensions.
   * @param vstrMeasureIDs The <code>Vector</code> of <code>MetadataManager</code>
   *        uniqueIDs representing the measures to filter.
   *
   * @return A <code>Vector</code> value that contains the updated measure
   *         list filtered by Time.
   *         
   * 
   */
  public static Vector filterByTime (MetadataManagerServices metadataManager, Vector vstrMeasureIDs) {
    return filterByTime (metadataManager, vstrMeasureIDs, true);
  }

  /**
   * @internal
   *
   * Filters out dimensions that contain value-based hierarchies.
   * A hierarchy is value-based if it contains no named levels.
   *
   * @param metadataManager The <code>MetadataManagerServices-</code> object from which
   *        to retrieve the hierarchy information.
   * @param vstrDimensionIDs The <code>Vector</code> of <code>MetadataManager</code>
   *        unique IDs which represent the dimensions to verify.
   *
   * @return A <code>Vector</code> filtered dimensions.
   *         
   * 
   */
  public static Vector filterByValueBasedHierarchy (MetadataManagerServices metadataManager, 
                                                    Vector vstrDimensionIDs) {
 
    // Check for invalid input
    if ((vstrDimensionIDs == null) || (vstrDimensionIDs.size() == 0))
      return vstrDimensionIDs;
    
    // If we can't verify that we have any dimensions, remove everything
    if (metadataManager == null) {
      vstrDimensionIDs.removeAllElements();
    }

    String strDimensionID;
    MDDimension mdDimension;
    MDHierarchy[] mdHierarchies;
    MDLevel mdLevels[];
    boolean bRemoveDimension;
    
    // Iterate over each measure, starting at the end
    for (int nIndex = vstrDimensionIDs.size() - 1; nIndex >= 0; nIndex--) {
      
      bRemoveDimension = true;
      
      try {
        strDimensionID = (String)vstrDimensionIDs.get (nIndex);

        if (strDimensionID != null) {
          mdDimension = 
            (MDDimension) metadataManager.getMDObject (MM.UNIQUE_ID, 
              strDimensionID, MM.DIMENSION);

          if (mdDimension != null) {
            mdHierarchies = mdDimension.getHierarchies();
            
            for (int nIndexHier = 0; ((mdHierarchies != null) && (nIndexHier < mdHierarchies.length)); nIndexHier++) {
              mdLevels = mdHierarchies[nIndex].getLevels();
              
              // Only keep the dimension if we have found a hierarchy with 
              // levels.
              if (mdLevels != null) {
                bRemoveDimension = false;
                break;  
              }
            }
          }    
        }        

        if (bRemoveDimension) {
          vstrDimensionIDs.remove (nIndex);
        }
      }
      
      catch (Exception exception) {
        // If we generate an exception, remove offending element
        vstrDimensionIDs.removeElementAt (nIndex);
      }
    }
 
    return vstrDimensionIDs;
  }

  /**
   * @internal
   * 
   * Retrieves the <code>MDFolder</code> associated with the specified full 
   * path.
   *
   * <pre>
   * Note: This method will return the root folder if a null or "" is 
   *       specified for the relative path.
   * </pre>
   * 
   * @param strFullPath a <code>String</code> which represents the full path, 
   *        including the relative directory path and object name.
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * 
   * @return <code>MDFolder</code> associated with the relative path.
   * 
   * @throws <code>NamingException</code> if <code>MDFolder</code> cannot be
   *         retrieved from the relative path.
   *
   * @see #getFolder(MetadataManagerServices, String)
   * 
   * 
   */
  public static MDFolder getFolder (String strFullPath, 
    MetadataManagerServices metadataManagerServices) throws Exception {

    return getFolder (metadataManagerServices, getRelativePath (strFullPath));
  }

  /**
   * @internal
   * 
   * Retrieves the <code>MDFolder</code> associated with the specified relative 
   * path.
   *
   * <pre>
   * Note: This method will return the root folder if a null or "" is 
   *       specified for the relative path.
   * </pre>
   * 
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param strRelativePath a <code>String</code> which represents the relative 
   *        directory path.  
   * 
   * @return <code>MDFolder</code> associated with the relative path.
   * 
   * @throws <code>NamingException</code> if <code>MDFolder</code> cannot be
   *         retrieved from the relative path.
   * 
   * @see #getFolder(String, MetadataManagerServices)
   * @see #getRelativePath(String)
   * 
   * 
   */
  public static MDFolder getFolder (MetadataManagerServices metadataManagerServices,
                              String strRelativePath) throws Exception {

    MDFolder mdFolder = null;
        
    if (metadataManagerServices != null) {
      if ((strRelativePath != null) && (strRelativePath != "")) {
        //mdFolder = (MDFolder) metadataManagerServices.getMDRoot().lookup (strRelativePath);    
        mdFolder = (MDFolder) metadataManagerServices.getMDObject(MM.PATH, strRelativePath, MM.FOLDER);
      }
      else {
        // Default to the root folder
        mdFolder = metadataManagerServices.getMDRoot();   
      }
    }
    
    return mdFolder;
  }

  /**
   * @internal
   * 
   * Retrieves the relative path from the full path (which includes the 
   * directory path and object name).
   * 
   * <pre>
   * Example:
   *   Full Path:
   *     DataSourceTableTest/AdditionSalesCosts  
   *   Relative Path:
   *     DataSourceTableTest
   * </pre>
   * 
   * @return <code>String</code> which represents the relative path or null.
   * 
   * 
   */
  public static String getRelativePath (String strFullPath) {
    String strRelativePath = null;
    
    if (strFullPath != null) {
      int nIndex = strFullPath.lastIndexOf ('/');
      
      if ((nIndex != -1) && (nIndex != 0)) {
        strRelativePath = strFullPath.substring (0, nIndex);
      }
    }
    
    return strRelativePath;
  }

  /**
   * @internal
   *
   * Determines the number type associated with the <code>BaseViewFormat</code>.
   *
   * @param baseViewFormat The <code>BaseViewFormat</code> to check.
   *
   * @return <code>int</code> which represents the number type.
   *
   * @see oracle.dss.util.format.BaseViewFormat#NUMTYPE_GENERAL
   * @see oracle.dss.util.format.BaseViewFormat#NUMTYPE_CURRENCY
   * @see oracle.dss.util.format.BaseViewFormat#NUMTYPE_PERCENT
   *
   * 
   */
  static public int getNumberType (BaseViewFormat baseViewFormat) {

    int nViewFormatType = BaseViewFormat.NUMTYPE_GENERAL;

    if (baseViewFormat != null) {

      // Retrieve the current number type
      nViewFormatType = baseViewFormat.getNumberType();

      // Determine if a percentage formatting string has been specified
      String strFormatString = baseViewFormat.getNumberFormatString();
      boolean bPercentUsed =
        (strFormatString != null) ? strFormatString.indexOf ("%") != -1 : false;

      if (bPercentUsed)
        nViewFormatType = BaseViewFormat.NUMTYPE_PERCENT;
    }

    return nViewFormatType;
  }

  /**
   * Determines whether the specified name is valid.
   *
   * @param  strName The <code>String</code> name to validate.
   *
   * @return <code>boolean</code> which is <code>true</code> when the name
   *         is valid and <code>false</code> otherwise.
   *
   * @throws NamingException If the name cannot be validated.
   *
   * 
   */
  public static boolean validateName (String strName) throws NamingException {
    boolean bValid = false;
    if (strName != null) {
      // Replace any embedded back slash characters with forward slash characters
      String strTemp = strName.replace ('\\', '/');


      //HBR: Persistence removal
      // Create a name parser
/*        NameParser nameParser = new PersistenceNameParserImpl();
      if (nameParser != null) {
        // Convert the name to 'javax.name.Name' equivalent and determine
        // if it is valid
        bValid = PSRUtilities.isValid (nameParser.parse (strTemp));
      }
*/
      // Fix Bug 2304595: Text of CalcBuilder validation dialogs need to be
      // updated
      //
      // Also need to check for invalid forward and backward slashes
      if (bValid) {
        if ((strName.indexOf('\\') != -1) || (strName.indexOf('/') != -1)) {
          bValid = false;
        }
      }
    }
    return bValid;
  }

  /**
   * @internal
   *
   * Retrieves the list of measures defined by the query filter associated
   * with the specified <code>CalcBuilderContext</code>, if any.
   *
   * @param calcBuilderContext a <code>CalcBuilderContext</code> value that
   *        contains the query filter used to define the list of available
   *        measures.
   *
   * @return A <code>Vector</code> value that contains a list of available
   *         measures.
   *
   */
  /** gek 11/03/06
  public static Vector getMeasures (CalcBuilderContext calcBuilderContext) {

    if ((calcBuilderContext == null))
      return null;

    Vector vMDMeasures = null;
    
    // Determine if a query filter has been specified
    try {
      // Create MeasureFilter based on Query filter
      MeasureFilter measureFilter = 
        new MeasureFilter (calcBuilderContext.getQueryFilter());

      measureFilter.setMetadataManagerServices (calcBuilderContext.getMetadataManager());
      
      // Only include MDM measures
      measureFilter.setObjectTypes (new String[] {MM.MEASURE});         
      
      // Include our default data types (e.g. MM.INTEGER, MM.SHORT, MM.LONG, 
      // MM.FLOAT and MM.DOUBLE).
      measureFilter.setDataTypes (DEFAULT_DATA_TYPES);
      
      // Limit the number of MDObjects retrieved by the combo box count
      measureFilter.setCountLimit (calcBuilderContext.getPopupItemCount());
    
      // Only include measures with intersecting dimensionality.
      measureFilter.setIntersectionFilter (MeasureFilter.DIMENSIONALITY_ANY_INTERSECTING);
    
      vMDMeasures = measureFilter.getMDObjects(); 

      // If no filter has been specified, return default
      if (vMDMeasures == null) {
        vMDMeasures = calcBuilderContext.getMeasureContext();
      }
      else {
        vMDMeasures = DataUtils.getUniqueIDs (vMDMeasures);
      }
    }
    
    catch (Exception exception) {
    }

    return vMDMeasures;
  }
  */

  /**
   * @internal
   *
   * Retrieves the list of dimensions defined by the query filter associated
   * with the specified <code>CalcBuilderContext</code>, if any.
   *
   * @param calcBuilderContext a <code>CalcBuilderContext</code> value that
   *        contains the query filter used to define the list of available
   *        dimensions.
   *
   * @return A <code>Vector</code> value that contains a list of available
   *         dimensions.
   *
   */
  /** gek 11/03/06
  public static Vector getDimensions (CalcBuilderContext calcBuilderContext) {

    if ((calcBuilderContext == null))
      return null;

    // Return dimensions
    return DataUtils.getDimensions (calcBuilderContext.getQueryFilter());
  }
  */    

  /**
   * @internal
   *
   * Retrieves the hierarchy associated with the specified dimension defined
   * by the query filter associated with the <code>CalcBuilderContext</code>,
   * if any.
   *
   * @param calcBuilderContext a <code>CalcBuilderContext</code> value that
   *        contains the query filter used to define the list of available
   *        measures.
   *
   * @param strDimension a <code>String</code> value that represents the
   *        dimension to retrieve the hierarchy for.
   *
   * @return A <code>String</code> value that contains the hierarchy
   *         associated with the dimension, if any.
   *
   */
  /** gek 11/03/06
  public static String getHierarchy (CalcBuilderContext calcBuilderContext,
                                String strDimension) {

    // If we have invalid parameters, simply return
    if ((calcBuilderContext == null) || (strDimension == null))
      return null;

    // Retrieve the hierarchy
    return DataUtils.getHierarchy (calcBuilderContext.getQueryFilter(),
      strDimension);
  }
  */

  /**
   * @internal
   *
   * Retrieves the list of measures defined by the query.
   *
   * @param query a <code>Query</code> value that contains the query used to
   *        define the list of available measures.
   *
   * @return A <code>Vector</code> value that contains a list of available
   *         measures.
   *
   */
  public static Vector getMeasures (Query query) {

    Vector vMeasures = null;

    // Determine if a query has been specified
    if (query != null) {
      // Retrieve the query state which contains the list of measures
      QueryState queryState = null;

      try {
        queryState = query.getQueryState();

        // Retrieve the list of available measures
        if (queryState != null) {
          String strMeasures[] = queryState.getMeasures();

          // Create a list of measures to return
          if (strMeasures != null) {
            vMeasures = new Vector (strMeasures.length);
            for (int nIndex = 0; nIndex < strMeasures.length; nIndex++) {
              vMeasures.addElement (strMeasures[nIndex]);
            }
          }
        }
      }

      // If we have a problem retrieving the measures, return null vector
      catch (CloneException e) {
        return null;
      }
    }

    return vMeasures;
  }

  /**
   * @internal
   *
   * Retrieves the list of dimensions defined by the query.
   *
   * @param query a <code>Query</code> value that contains the query used to
   *        define the list of available dimensions.
   *
   * @return A <code>Vector</code> value that contains a list of available
   *         dimensions.
   *
   */
  public static Vector getDimensions (Query query) {

    Vector vDimensions = null;

    // Determine if a query has been specified
    if (query != null) {
      // Retrieve the query state which contains the list of measures
      QueryState queryState = null;

      try {
        queryState = query.getQueryState();

        // Retrieve the list of available measures
        if (queryState != null) {
          String strMeasures[] = queryState.getMeasures();

          // Create a list of measures to return
          if (strMeasures != null) {
            Vector vMeasures = new Vector (strMeasures.length);
            for (int nIndex = 0; nIndex < strMeasures.length; nIndex++) {
              vMeasures.addElement (strMeasures[nIndex]);
            }

            // Retrieve the list of dimensions associated with these measures
            vDimensions =
              getDimensions (query.getMetadataManager(), vMeasures);
          }
        }
      }

      // If we have a problem retrieving the measures, return null vector
      // This can be because of a CloneException or MetadataManagerException
      catch (Exception e) {
        return null;
      }
    }

    return vDimensions;
  }

  /**
   * @internal
   *
   * Retrieves the hierarchy associated with the specified dimension defined
   * by the query.
   *
   * @param query a <code>Query</code> value that contains the query used to
   *        retrieve the dimension and hierarchy for.
   *
   * @param strDimension a <code>String</code> value that represents the
   *        dimension to retrieve the hierarchy for.
   *
   * @return A <code>String</code> value that contains the hierarchy
   *         associated with the dimension, if any.
   *
   */
  public static String getHierarchy (Query query, String strDimension) {

    // If we have invalid parameters, simply return
    if ((query == null) || (strDimension == null))
      return null;

    // Retrieve the query's state
    QueryState queryState = null;

    try {
      // Retrieve the QueryState associated with the query
      queryState = query.getQueryState();

      if (queryState != null) {
        // Retrieve the list of selections
        // blm - Selection code moved to dvt-olap
/*        List listSelections = queryState.getSelections();
        if (listSelections == null)
          return null;

        // Iterate over the selections
        Iterator iterator = listSelections.iterator();
        while (iterator.hasNext()) {

          Selection selection = (Selection) iterator.next();

          if (selection != null) {

            // Determine if this selection contains the dimension we are
            // interested in
            String strDimensionSelection = selection.getDimension();
            if ((strDimensionSelection != null) &&
                (strDimensionSelection.equals (strDimension))) {
              return selection.getHierarchy();
            }
          }
        }*/
      }
    }

    // If we have a problem retrieving the selections, return null vector
    catch (CloneException e) {
      return null;
    }

    return null;
  }

  /**
   *  @internal
   *  Retrieves the Measure's persisted aggregate ID based on the
   *  specified MetadataManager runtime ID and position.
   *
   *  Maps the aggregate ID to the runtime ID which is used when loading the query.
   *
   *
   *  @param  nPosition a <code>int</code> value that represents the
   *          position to associate with the measure. A -1 value simply places
   *          the measure at the end of the current list.
   *  @param  strMeasureRuntime a <code>String</code> value that represents the
   *          runtime measure we want to update.
   *  @return <code>String</code> representing the Measure's runtime ID.
   *  
   */
  public static String getMeasureAggregate (int nPosition, String strMeasureRuntime) {

    // By default, return original ID
    String strMeasureAggregate = strMeasureRuntime;

    // Check to see if we have a runtime ID
    String driverType = MMUtilities._getDriverType(strMeasureRuntime);
    if (driverType != null && driverType.equals (MM.PERSISTENCE)) {

      // Add the aggregate to the end of the list
      if (nPosition == -1) {
        nPosition = m_aggregatedMeasures.size();
      }

      // Generate a new aggregate ID based on the position
      Integer intPosition = new Integer (nPosition);
      strMeasureAggregate =
        MMUtilities._makeUniqueID (PersistableConstants.AGG, intPosition.toString());

      // Map the aggregate ID to the runtime ID
      if (!m_aggregatedMeasures.containsKey(strMeasureAggregate)) {
        m_aggregatedMeasures.put (strMeasureAggregate, strMeasureRuntime);
      }
    }

    // Return the aggregated ID
    return strMeasureAggregate;
  }

  /**
   *  @internal
   *  Retrieves the Measure's persisted aggregate ID based on the
   *  specified MetadataManager runtime ID and position.
   *
   *  Maps the runtime ID to the aggregate ID which is used when save the query.
   *
   *  @param  strMeasureRuntime a <code>String</code> value that represents the
   *          measure we want to update.
   *  @param  nPosition a <code>int</code> value that represents the
   *          position to associate with the measure. A -1 value simply places
   *          the measure at the end of the current list.
   *  @return <code>String</code> representing the measure.
   *  
   */
  public static String getMeasureAggregate (String strMeasureRuntime, int nPosition) {

    // By default, return original ID
    String strMeasureAggregate = strMeasureRuntime;

    // Check to see if we have a runtime ID
    String driverType = MMUtilities._getDriverType(strMeasureRuntime);
    if (driverType != null && driverType.equals (MM.PERSISTENCE)) {
      // Check to see if this runtime ID already exists
      if (!m_aggregatedMeasures.containsKey(strMeasureRuntime)) {

        // Add the aggregate to the end of the list
        if (nPosition == -1) {
          nPosition = m_aggregatedMeasures.size();
        }

        // Generate a new aggregate ID based on the position
        Integer intPosition = new Integer (nPosition);
        strMeasureAggregate =
          MMUtilities._makeUniqueID (PersistableConstants.AGG, intPosition.toString());

        // Map the runtime ID  to the aggregate ID
        m_aggregatedMeasures.put (strMeasureRuntime, strMeasureAggregate);
        }
      else {
        // Retrieve the existing aggregate ID
        strMeasureAggregate =
          (String) m_aggregatedMeasures.get (strMeasureRuntime);
      }
    }

  // Return the aggregated ID
  return strMeasureAggregate;
  }

  /**
   *  @internal
   *
   *  Insures that the custom measures associated with the specified selection
   *  get updated based on the specified options.
   *
   *  @param  selection a <code>Selection</code> value used to retrieve
   *          custom measures from.
   *  @param  nOption a <code>int</code> value that is represents how the
   *          custom measures should be updated.
   *
   *  @see #MEASURE_REMOVE
   *    If we have a custom measure which is part of a selection, blast
   *    it away from our measure list so that we insure that we pick up
   *    any changes to the underlying custom measures (if any).
   *  @see #MEASURE_AGG_TO_RUNTIME
   *    Converts persisted aggregate measure ID based on position to
   *    MetadataManager runtime ID.
   *  @see #MEASURE_RUNTIME_TO_AGG
   *    Converts MetadataManager runtime ID to persisted aggregate ID based on
   *    position.
   *
   *  @return <code>Selection</code> representing the updated selection
   *  @throws MetadataManagerException if Measure dimension can't be retrieved
   *  @throws CloneNotSupportedException if <code>Selection</code> can't be cloned
   *
   *  
   */
   // blm - Selection code moved to dvt-olap
/*  public static Selection updateCustomMeasures (Selection selection, int nOption, MetadataManagerServices mm)
                throws CloneNotSupportedException, MetadataManagerException {

    Selection selectionNew = selection;

    // Check for a null selection
    if (selectionNew != null) {

      // Clone the selection so that we don't modify the original!
      if (nOption == MEASURE_RUNTIME_TO_AGG)
        selectionNew = (Selection)selection.clone();

      // Iterate over each step in the selection, along with sort specs & drill steps
      // Build new linear vector
      Vector steps = new Vector();
      for (int nIndex = 0; nIndex < selectionNew.getStepCount(); nIndex++) {
        steps.addElement(selectionNew.getStep(nIndex));
      }

      // Now do sort spec
      SortSpec spec = selectionNew.getSortSpec();
      if (spec != null) {
        for (int i = 0; i < spec.getMemberSortStepCount(); i++) {
          steps.addElement(spec.getMemberSortStepAt(i));
        }

        for (int i = 0; i < spec.getConditionSortStepCount(); i++) {
          steps.addElement(spec.getConditionSortStepAt(i));
        }

        if (spec.getHierarchicalSortStep() != null) {
          steps.addElement(spec.getHierarchicalSortStep());
        }
      }

    // Add the drill step
    DrillStep drillStep = selectionNew.getDrillStep();
    if (drillStep != null) {
      steps.addElement(drillStep);
    }

    for (int nIndex = 0; nIndex < steps.size(); nIndex++) {
      // Get the step at the current index
      Step step = (Step)steps.elementAt(nIndex);

      // Retrieve a list of dependent measures
      Vector vMeasures = step.getDependentIDs(mm.getMeasureDimension(null).getUniqueID());

      // Iterate over all measures in the vector
      if (vMeasures != null && !vMeasures.isEmpty()) {
        for (int nPosition = 0; nPosition < vMeasures.size(); nPosition++) {

          // Retrieve the measure at the current position
          String strMeasureID = (String) vMeasures.elementAt (nPosition);

          // Determine which option was specified
          switch (nOption) {
            // If we have a custom measure which is part of a selection, blast
            // it away from our measure list to insure that we pick up
            // any changes to the underlying custom measures (if any).
            case MEASURE_REMOVE:
              break;

            // Convert persisted aggregate IDs to MetadataManager runtime IDs
            case MEASURE_AGG_TO_RUNTIME:
              // Determine if this is a aggregated measure
              String driverType = MMUtilities._getDriverType (strMeasureID);
              if (driverType != null && driverType.equals (PersistableConstants.AGG)) {
                // Retrieve the runtime ID based on the aggregated ID
                String strMeasureRuntime =
                  (String) m_aggregatedMeasures.get (strMeasureID);

                // Replace aggregated ID with runtime ID
                if (strMeasureRuntime != null)
                  vMeasures.setElementAt (strMeasureRuntime, nPosition);
              }
              break;

            // Convert MetadataManager runtime IDs to persisted aggregate IDs
            case MEASURE_RUNTIME_TO_AGG:
              // Determine if this is a runtime custom measure
              driverType = MMUtilities._getDriverType(strMeasureID);
              if (driverType != null && driverType.equals (MM.PERSISTENCE)) {

                // Retrieve aggregated ID based on the runtime ID
                String strMeasureAggregate =
                  (String) m_aggregatedMeasures.get (strMeasureID);

                // Replace runtime ID with aggregated ID
                vMeasures.setElementAt (strMeasureAggregate, nPosition);
              }
              break;

            // Do nothing
            default:
              break;
            }
          }

          // Update the measures associated with this step
          if (nOption != MEASURE_REMOVE) {
            // Update the dependent measures
            step.setDependentIDs(mm.getMeasureDimension(null).getUniqueID(), vMeasures);
          }
        }
      }
    }

  return selectionNew;
  }
*/
  /**
   *  @internal
   *
   *  Insures that the custom favorites associated with the specified selection
   *  get updated based on the specified options.
   *
   *  @param  selection a <code>Selection</code> value used to retrieve
   *          favorites from.
   *  @param  nOption a <code>int</code> value that is represents how the
   *          custom measures should be updated.
   *  @param  mdSelection a <code>MDSelection</code> value used to retrieve
   *          runtime names if nOption == FAVORITE_AGG_TO_RUNTIME
   *
   *  @see #FAVORITE_AGG_TO_RUNTIME
   *    Converts persisted aggregate favorite ID based on position to
   *    MetadataManager runtime ID.
   *  @see #FAVORITE_RUNTIME_TO_AGG
   *    Converts MetadataManager runtime ID to persisted aggregate ID based on
   *    position.
   *
   *  @return <code>Selection</code> representing the updated selection
   *  @throws MetadataManagerException if Measure dimension can't be retrieved
   *  @throws CloneNotSupportedException if <code>Selection</code> can't be cloned
   *
   *  
   * @deprecated As of 2.8.0.50, should be using SavedSelectionStep
   */
   // blm - Selection code moved to dvt-olap
/*  public static Selection updateFavorites (Selection selection, int nOption,
                              MDSelection mdSelection, MetadataManagerServices metadataManager)
                throws CloneNotSupportedException, MetadataManagerException {

    Selection selectionNew = selection;

    // Check for a null selection
    if (selectionNew != null) {

      // Clone the selection so that we don't modify the original!
      if (nOption == FAVORITE_RUNTIME_TO_AGG)
        selectionNew = (Selection)selection.clone();

      MDSelection[] dependents = null;

      int aggIndex = 0;
      Hashtable mappings = new Hashtable();

      if (mdSelection != null) {
        MDObject[] allDependents = mdSelection.getDependents();
        if (allDependents == null || allDependents.length == 0)
          return selectionNew;

        Vector selections = new Vector();
        for (int i = 0; i < allDependents.length; i++) {
          if (allDependents[i] instanceof MDSelection) {
            selections.addElement(allDependents[i]);
          }
          else {
            // gek 05/19/02 Fix Bug 2260285 Favorites not converting saved
            //              calc IDs back to pathnames

            // Determine if this is a measure
            if ((allDependents[i] instanceof MDMeasure) &&
                (nOption == FAVORITE_AGG_TO_RUNTIME)) {

              // Retrieve the runtime ID
              String strRuntimeID = allDependents[i].getUniqueID();
              if (strRuntimeID != null) {
                // Update the hashtable mapping from AGG IDs to Runtime measure IDs
                getMeasureAggregate (i, strRuntimeID);

                // Update the measure, replacing AGG IDs with Runtime IDs
                selectionNew =
                  updateCustomMeasures (selection, MEASURE_AGG_TO_RUNTIME, metadataManager);
              }
            }
          }
        }

        if (selections.size() == 0)
          return selectionNew;

        dependents = (MDSelection[])selections.toArray(new MDSelection[selections.size()]);
      }

      for (int nIndex = 0; nIndex < selectionNew.getStepCount(); nIndex++) {
        // Get the step at the current index
        Step step = selectionNew.getStep(nIndex);

        if (step instanceof FavoriteStep) {
          FavoriteStep fs = (FavoriteStep)step;
          String driverType = MMUtilities._getDriverType(fs.getSelectionID());

          // Determine which option was specified
          switch (nOption) {
            // Convert persisted aggregate IDs to MetadataManager runtime IDs
            case FAVORITE_AGG_TO_RUNTIME:
              // Determine if this is a aggregated measure
              if (driverType == null || driverType.equals(MM.PERSISTENCE) ||
                  mdSelection == null)
                // already updated
                return selectionNew;

              if (driverType.equals(PersistableConstants.AGGF)) {
                int index =
                  Integer.valueOf(MMUtilities._extractID(fs.getSelectionID())).intValue();

                fs.setSelectionID(dependents[index].getUniqueID());
                fs.setSelection(updateFavorites(fs.getSelection(), nOption,
                  dependents[index], metadataManager));
                fs.setSelection(updateDimMembersToRuntime(fs.getSelection(), dependents[index]));
              }
              break;

            // Convert MetadataManager runtime IDs to persisted aggregate IDs
            case FAVORITE_RUNTIME_TO_AGG:
              // Determine if this is a runtime custom measure
              if (driverType == null || driverType.equals(PersistableConstants.AGGF))
                // already updated
                return selectionNew;

              if (driverType.equals(MM.PERSISTENCE)) {
                if (mappings.containsKey(fs.getSelectionID()))
                  fs.setSelectionID((String)mappings.get(fs.getSelectionID()));
                else {
                  String aggID =
                    MMUtilities._makeUniqueID(PersistableConstants.AGGF, String.valueOf(aggIndex));

                  mappings.put(fs.getSelectionID(), aggID);

                  fs.setSelectionID(aggID);
                  aggIndex++;
                  fs.setSelection(updateFavorites(fs.getSelection(), nOption, mdSelection, metadataManager));
                }
              }
              break;
          }
        }
      }
    }

    return selectionNew;
  }
*/
  /**
   *  @internal
   *
   *  Updates any custom dimension members references with aggregate id's
   *  of the form "AGGD!n"
   *
   *  @param  selection The Selection to update
   *  @param  vMDMembers The MDDimensionCalcs referenced by the selection
   *
   *  @return <code>Selection</code> representing the updated selection
   *  @throws CloneNotSupportedException if <code>Selection</code> can't be cloned
   *
   *  
   */
   // blm - Selection code moved to dvt-olap
/*  public static Selection updateDimMembersToAgg(Selection selection, Vector vMDMembers) throws CloneNotSupportedException {
    Selection sel = (Selection)selection.clone();
    if (vMDMembers != null && vMDMembers.size() > 0) {
      Vector dimensions = new Vector();
      Vector members = new Vector();
      Vector replacements = new Vector();
      for (int i = 0; i < vMDMembers.size(); i++) {
        MDDimensionCalc dimCalc = (MDDimensionCalc)vMDMembers.elementAt(i);
        String dimMember = dimCalc.getProperty(PersistableConstants.Attributes.COMPSUBTYPE2).getStrValue();
        StringTokenizer st = new StringTokenizer(dimMember, ":");
        st.nextToken();
        String dimension = st.nextToken();
        String member = dimCalc.getProperty(MM.OBJECT_NAME).getStrValue();
        String repl = MMUtilities._makeUniqueID(PersistableConstants.AGGD, new Integer(i).toString());
        dimensions.addElement(dimension);
        members.addElement(member);
        replacements.addElement(repl);
      }
      sel.replaceDimensionMembers(dimensions, members, replacements);
    }
    return sel;
  }
*/
  /**
   *  @internal
   *
   *  Updates any "AGGD!n" references in a selection with runtime IDs
   *
   *  @param  selection The Selection to update
   *  @param  mdSelection The MDSelection from which to retrieve the MDDimensionCalc's
   *
   *  @return <code>Selection</code> representing the updated selection
   *  @throws MetadataManagerException if Measure dimension cannot be retrieved
   *
   *  
   */
    // blm - Selection code moved to dvt-olap
/*  public static Selection updateDimMembersToRuntime(Selection selection, MDSelection mdSelection) throws MetadataManagerException {
    MDObject[] deps = mdSelection.getDependents();
    if (deps == null || deps.length == 0)
      return selection;
    Vector vMDMeasures = new Vector();
    for (int i = 0; i < deps.length; i++)
      if (deps[i] instanceof MDDimensionCalc)
        vMDMeasures.addElement(deps[i]);
    return _updateDimMembersToRuntime(selection, vMDMeasures);
  }
*/
  /**
   *  @internal
   *
   *  Updates any "AGGD!n" references in a selection with runtime IDs
   *
   *  @param  selection The Selection to update
   *  @param  persistenceHelper The PersistenceHelper from which to 
   *					retrieve MDDimensionCalc
   *
   *  @return <code>Selection</code> representing the updated selection
   *  @throws MetadataManagerException if Measure dimension can't be retrieved
   *
   *  
   */
  /** gek 11/03/06
  public static Selection updateDimMembersToRuntime(Selection selection, 
    PersistenceHelper persistenceHelper) throws MetadataManagerException {
    AggregateInfo[] aggregateInfo = selection.getPersistableComponents();
    if (aggregateInfo == null || aggregateInfo.length == 0)
      return selection;
    Vector vMDMeasures = new Vector();
    for (int i = 0; i < aggregateInfo.length; i++) {
      if (aggregateInfo[i].getPersistable() instanceof CalcStep) {
        CalcStep cs = (CalcStep)aggregateInfo[i].getPersistable();
        if (cs.getAnalyticWorkspace() != null) {
           vMDMeasures.addElement (persistenceHelper.getMDObject(cs));
        }
      }
    }
    return _updateDimMembersToRuntime(selection, vMDMeasures);
  }
  */

  /**
   *  @internal
   *
   *  Updates any "AGG!n" or "AGGD!n" references in a custom measure with runtime IDs
   *
   *  @param  mdObject The MDObject to update
   *
   *  @throws MetadataManagerException if Measure dimension can't be retrieved
   *
   *  
   */
  /** gek 11/03/06
  public static void updateCustomMeasuresToRuntime(MDObject mdObject) throws MetadataManagerException {
    if (mdObject != null && mdObject instanceof MDMeasure) {
      MDObject[] deps = mdObject.getDependents();
      
      if (deps != null && deps.length > 0) {
        Vector measures = new Vector();
        Vector dimCalcs = new Vector();
        for (int i = 0; i < deps.length; i++) {
          if (deps[i] instanceof MDMeasure && MMUtilities._getDriverType(deps[i].getUniqueID()).equals(MM.PERSISTENCE)) {
            measures.addElement(deps[i]);
          }
          else if (deps[i] instanceof MDDimensionCalc)
            dimCalcs.addElement(deps[i]);
        }
        
        UserObject userObject = 
          mdObject.getUserObject(MM.PERSISTENCE_OBJECT, MM.PERSISTENCE);
        
        if (userObject != null) {
          // Retrieve the step associated with this MDObject
          CalcStep cs = null;

          if (mdObject instanceof MDCalcPersistable) {
            cs = (CalcStep) ((MDCalcPersistable)mdObject).getPersistable();   
          }

          if (cs != null) {
            // Fix up measure IDs
            Vector ids = 
              cs.getDependentIDs(mdObject.getMetadataManagerServices().getMeasureDimension(null).getUniqueID());
            
            for (int i = 0; i < ids.size(); i++) {
              if (ids.elementAt(i) != null) {
                String id = (String)ids.elementAt(i);
                
                if (MMUtilities._getDriverType(id).equals(PersistableConstants.AGG)) {
                  int index = new Integer(MMUtilities._extractID(id)).intValue();
                  String uniqueID = ((MDMeasure)measures.elementAt(index)).getUniqueID();
                  ids.setElementAt(uniqueID, i);
                }
              }
            }
            
            cs.setDependentIDs (null, ids);
            
            // Fix up custom dimension member IDs
            Vector dimensions = new Vector();
            Vector members = new Vector();
            Vector replacements = new Vector();
            
            for (int i = 0; i < dimCalcs.size(); i++) {
              MDDimensionCalc dimCalc = (MDDimensionCalc)dimCalcs.elementAt(i);
              String dimMember = 
                dimCalc.getProperty(PersistableConstants.Attributes.COMPSUBTYPE2).getStrValue();
              StringTokenizer st = new StringTokenizer(dimMember, ":");
              st.nextToken();
              String dimension = st.nextToken();
              String member = MMUtilities._makeUniqueID(PersistableConstants.AGGD, new Integer(i).toString());
              String repl = dimCalc.getProperty(MM.OBJECT_NAME).getStrValue();
              dimensions.addElement(dimension);
              members.addElement(member);
              replacements.addElement(repl);                
            }
            
            cs.replaceDimensionMembers(dimensions, members, replacements);
          }
          
          mdObject.addUserObject(MM.PERSISTENCE_OBJECT, userObject);
        }
      }   
    }
  }
  */

  /**
   *  @internal
   *
   *  Updates any runtime IDs in an MDMeasure with "AGG!n" or "AGGD!n" references
   *
   *  @param  calcStep The CalcStep to update (not actually modified)
   *  @param  mdObject The corresponding MDMeasure (modified)
   *
   *  @throws MetadataManagerException if Measure dimension can't be retrieved
   *
   *  
   */
  /** gek 11/03/06
  public static void updateCustomMeasuresToAgg(CalcStep calcStep, MDObject mdObject) throws MetadataManagerException {
    if ((calcStep != null) && (mdObject != null)) {
      Vector vstrIDs = calcStep.getDependentIDs(null);
      Vector vDimIDs = calcStep.getMemberDependencies();
      Vector vMDDims = DataUtils.getCustomDimMembers(vDimIDs, mdObject.getMetadataManagerServices());
    
      // If we have no dependent objects specified, simply return
      if (vstrIDs == null && (vMDDims == null || vMDDims.size() == 0))
        return;

      CalcStep newStep = (CalcStep)calcStep.clone();
      // Retrieve each of the dependent MDMeasure IDs      
      if (vstrIDs != null) {
        Hashtable fixups = new Hashtable();
        Vector fixed = new Vector();
        int index = 0;
        for (int i = 0; i < vstrIDs.size(); i++) {
          String strID = (String)vstrIDs.elementAt(i);
          if (strID != null) {
            // fix up Persistence! IDs
            String driverType = MMUtilities._getDriverType(strID);
            if (driverType != null && driverType.equals (MM.PERSISTENCE)) {
              if (!fixups.containsKey(strID)) {
                // generate new agg! id, add to list
                String newID = MMUtilities._makeUniqueID(PersistableConstants.AGG, new Integer(index).toString());
                fixups.put(strID, newID);
              }
              fixed.addElement(fixups.get(strID));
            }
            else  {
              fixed.addElement(strID);
            }
          }
          else {
            // Increment to the next position, leaving an empty space
            fixed.addElement(null);
          }
        }
        newStep.setDependentIDs(null, fixed);
      }

      if (vMDDims != null) {
        Vector dimensions = new Vector();
        Vector members = new Vector();
        Vector replacements = new Vector();
        for (int i = 0; i < vMDDims.size(); i++) {
          MDDimensionCalc dimCalc = (MDDimensionCalc)vMDDims.elementAt(i);
          String dimMember = dimCalc.getProperty(PersistableConstants.Attributes.COMPSUBTYPE2).getStrValue();
          StringTokenizer st = new StringTokenizer(dimMember, ":");
          st.nextToken();
          String dimension = st.nextToken();
          String member = dimCalc.getProperty(MM.OBJECT_NAME).getStrValue();
          String repl = MMUtilities._makeUniqueID(PersistableConstants.AGGD, new Integer(i).toString());
          dimensions.addElement(dimension);
          members.addElement(member);
          replacements.addElement(repl);
        }
        newStep.replaceDimensionMembers(dimensions, members, replacements);
      }
      UserObject saveObject = new UserObject(newStep, MM.PERSISTENCE);
      mdObject.addUserObject(MM.PERSISTENCE_OBJECT, saveObject);
    }
  }
  */

  /**
   *  @internal
   *
   *  Updates any "AGGD!n" references in a selection with runtime IDs
   *
   *  @param  selection The Selection to update
   *  @param  vMDMembers The MDDimensionCalcs referenced by the selection
   *
   *  @return <code>Selection</code> representing the updated selection
   *
   *  
   */
   // blm - Selection code moved to dvt-olap
/*  private static Selection _updateDimMembersToRuntime(Selection selection, Vector vMDMeasures) {    
    Vector dimensions = new Vector();
    Vector members = new Vector();
    Vector replacements = new Vector();
    for (int i = 0; i < vMDMeasures.size(); i++) {
      MDDimensionCalc dimCalc = (MDDimensionCalc)vMDMeasures.elementAt(i);
      String dimMember = dimCalc.getProperty(PersistableConstants.Attributes.COMPSUBTYPE2).getStrValue();
      StringTokenizer st = new StringTokenizer(dimMember, ":");
      st.nextToken();
      String dimension = st.nextToken();
      String member = dimCalc.getProperty(MM.OBJECT_NAME).getStrValue();
      String repl = MMUtilities._makeUniqueID(PersistableConstants.AGGD, new Integer(i).toString());
      dimensions.addElement(dimension);
      members.addElement(member);
      replacements.addElement(repl);
    }
    if (dimensions.size() > 0)
      selection.replaceDimensionMembers(dimensions, replacements, members);        
    return selection;
  }
  */
  /**
   * @internal
   *
   * Traverses the selection and evaluates any custom dimension members encountered
   *
   * @param selection The selection to traverse
   * @param olapDmlUtil An OlapDmlUtil object used to evaluate the dimension member
   *
   * 
   */
/*    public static Selection evaluateDimMembers(Selection selection, OlapDmlUtil olapDmlUtil) 
              throws IOException, StepEvaluatorException, ConnectionException, 
                     SQLException, MetadataManagerException {
    selection = (Selection)_evaluateDimMembers(selection, olapDmlUtil);
    for (int i = 0; i < selection.getStepCount(); i++) {
      if (selection.getStep(i) instanceof FavoriteStep) {
        FavoriteStep fs = (FavoriteStep)selection.getStep(i);
        fs.setSelection(evaluateDimMembers(fs.getSelection(), olapDmlUtil));
      }
    }
    return selection;
  }
*/
  /**
   * @internal
   *
   * Traverses the persistable and evaluates any custom dimension members encountered
   *
   * @param persistable The persistable to traverse
   * @param olapDmlUtil An OlapDmlUtil object used to evaluate 
   *        the dimension member
   *
   */
/*    private static Persistable _evaluateDimMembers(Persistable persistable, 
                                      OlapDmlUtil olapDmlUtil) 
              throws IOException, StepEvaluatorException, ConnectionException, 
                     SQLException, MetadataManagerException {
  if (persistable == null)
      return persistable;

    AggregateInfo[] aggregateInfo = persistable.getPersistableComponents();
    if (aggregateInfo == null || aggregateInfo.length == 0)
      return persistable;

    for(int i = 0; i < aggregateInfo.length; i++) {
      _evaluateDimMembers(aggregateInfo[i].getPersistable(), olapDmlUtil);
      if (aggregateInfo[i].getPersistable() instanceof CalcStep) {
        CalcStep cs = (CalcStep)aggregateInfo[i].getPersistable();
        if (cs.getAnalyticWorkspace() != null) {
          // Attempt to retrieve a AwStepEvaluator
          AwStepEvaluator awStepEvaluator = AwStepEvaluator.getStepEvaluator(cs);

          // Evaluate the calculation
          if (awStepEvaluator != null) {
            awStepEvaluator.setOlapDmlUtil (olapDmlUtil);
            awStepEvaluator.evaluate();
          }
        }
      }
    }
    return persistable;
  }
*/
  /**
   * @internal
   *
   * Traverses the MDObject and evaluates any custom dimension members encountered
   *
   * @param mdObject The mdObject to traverse
   * @param olapDmlUtil An OlapDmlUtil object used to evaluate the dimension member
   *
   * 
   */
/*    public static MDObject evaluateDimMembers(MDObject mdObject, OlapDmlUtil olapDmlUtil) 
              throws IOException, StepEvaluatorException, ConnectionException, 
                     SQLException, MetadataManagerException {
    MDObject[] deps = mdObject.getDependents();
    if (deps == null || deps.length == 0)
      return mdObject;

    for(int i = 0; i < deps.length; i++) {
      if (deps[i] instanceof MDDimensionCalc) {
        CalcStep cs = getCalcStep(deps[i]);
        if (cs.getAnalyticWorkspace() != null) {
          // Attempt to retrieve a AwStepEvaluator
          AwStepEvaluator awStepEvaluator = AwStepEvaluator.getStepEvaluator(cs);

          // Evaluate the calculation
          if (awStepEvaluator != null) {
            awStepEvaluator.setOlapDmlUtil (olapDmlUtil);
            awStepEvaluator.evaluate();
          }
        }
      }
      else {
        deps[i] = evaluateDimMembers(deps[i], olapDmlUtil);
      }
    }
    return mdObject;
  }
*/
  /**
   * Retrieves the <code>CalcStep</code> that is associated with the specified
   * <code>MDObject</code>.
   *
   * @param  mdObject The <code>MDObject</code> to retrieve the
   *                  <code>CalcStep</code> from.
   *
   * @return  A <code>CalcStep</code> that represents the <code>CalcStep</code>
   *          that is associated with the specified <code>MDObject</code>.
   *
   * @throws MetadataManagerException If a <code>CalcStep</code> object
   *         cannot be retrieved from the <code>MDObject</code>.
   *
   */
  /** gek 11/03/06
  public static CalcStep getCalcStep (MDObject mdObject) throws MetadataManagerException {
    // Retrieve the potential step from the metadataManager object
    Object object = null;

    // Verify that we have a non-null mdObject
    if (mdObject != null) {
      // Retrieve the CalcStep wrapper
      UserObject userObject =
        mdObject.getUserObject (MM.PERSISTENCE_OBJECT, MM.PERSISTENCE);

      // Retrieve the actual CalcStep object
      if (userObject != null)
        object = userObject.getObject ();
    }

    // Verify that we actually have a CalcStep
    CalcStep calcStep = null;
    if (object instanceof CalcStep) {
      calcStep = (CalcStep) object;
    }

    return calcStep;
  }
  */

  /**
   * @internal
   *
   * Retrieves a vector of <code>MDDimensionCalc<code> objects that are associated
   * with the specified vector of custom dimension member names.
   *
   * @param vstrMembers a <code>Vector</code> of dimension member names to 
   *        search for.
   * @param metadataManager a <code>MetadataManagerServices</code> used to 
   *        search for metadata
   *
   * @return <code>Vector</code> representing the list of associated 
   *         <code>MDDimensionCalc</code> objects, if any
   * 
   * 
   * 
   * @deprecated As of 3.2.0.33, this method will return null since this 
   *             functionality was never fully supported.
   */
  public static Vector getCustomDimMembers (Vector vstrDimensionMembers, 
    MetadataManagerServices metadataManager) throws MetadataManagerException {

    // NOTE: This method is currently not supported and will return null.
    if (true) {
      return null;
    }

    List listDimMembers = null;
    Hashtable hashtable = null;
    
    Vector vMDMembers = new Vector();

    if (metadataManager != null) {
      MDFolder mdFolderRoot = metadataManager.getMDRoot();

      if (mdFolderRoot != null) {          
        for (int i = 0; i < vstrDimensionMembers.size(); i++) {
          StringTokenizer stringTokenizer = 
            new StringTokenizer ((String)vstrDimensionMembers.elementAt(i), ":");

          String strDependentDimension = stringTokenizer.nextToken();
          String strDependentName = stringTokenizer.nextToken();

          BasicAttributes attributes = new BasicAttributes();
          BasicAttribute typeAttribute = 
            new BasicAttribute (MM.OBJECT_TYPE, MM.DIMENSIONCALC);

          /*
          BasicAttribute nameAttribute = 
            new BasicAttribute (MM.OBJECT_NAME, strDependentName);
          attributes.put (nameAttribute);
          */

          attributes.put (typeAttribute);
          
          MDSearchControls searchControls = new MDSearchControls();
          searchControls.setDriverType (MM.PERSISTENCE);
          searchControls.setSearchScope (BISearchControls.SELECTIVE_ONELEVEL_SCOPE);

          try {
            listDimMembers = 
              getMDObjects (mdFolderRoot, attributes, searchControls);
          }

          catch (NamingException namingException) {
          }
        }
      }
    }

    return vMDMembers;
  }

  /**
   * @internal
   *
   * Retrieves a vector of <code>MDObject<code> values that are associated
   * with the specified <code>MM</code> object type.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> used to 
   *        search for metadata
   * @param strObjectType A <code>String</code> representing the object type 
   *        to retrieve.
   *
   * @return <code>List</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * 
   */
  public static List getMDObjects (MetadataManagerServices metadataManager, String strObjectType) 
    throws MetadataManagerException, NamingException {

    // Retrieve all MDObjects
    return getMDObjects (metadataManager, strObjectType, -1);
  }

  /**
   * @internal
   *
   * Retrieves a vector of <code>MDObject<code> values that are associated
   * with the specified <code>MM</code> object type.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> used to 
   *        search for metadata
   * @param strObjectType A <code>String</code> representing the object type 
   *        to retrieve.
   * @param lCount a <code>long</code> representing the maximum number of measures
   *        to retrieve.  A value of 0 implies all measures.
   *
   * @return <code>List</code> representing the list of associated 
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   * 
   * 
   */
  public static List getMDObjects (MetadataManagerServices metadataManager, 
                                              String strObjectType, long lCount) 
    throws MetadataManagerException, NamingException {

    List listDimMembers = null;
    Hashtable hashtable = null;
    
    if (metadataManager != null) {
      MDFolder mdFolderRoot = metadataManager.getMDRoot();

      BasicAttributes attributes = new BasicAttributes();
      BasicAttribute typeAttribute = 
        new BasicAttribute (MM.OBJECT_TYPE, strObjectType);

      attributes.put (typeAttribute);
          
      MDSearchControls searchControls = new MDSearchControls();
      searchControls.setDriverType (MM.PERSISTENCE);
      searchControls.setSearchScope (BISearchControls.SELECTIVE_ONELEVEL_SCOPE);

      listDimMembers = 
        getMDObjects (mdFolderRoot, attributes, searchControls, lCount);
    }

    return listDimMembers;
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of available <code>MDDimensionCalc<code> 
   * objects.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> used 
   *        to search for metadata
   *
   * @return <code>List</code> representing the list of available 
   *         <code>MDDimensionCalc</code> objects, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *
   * 
   */
  public static List getCustomMeasures (MetadataManagerServices metadataManagerServices) 
    throws MetadataManagerException, NamingException {

    return getMDObjects (metadataManagerServices, MM.CALCULATION);
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of available <code>MDDimensionCalc<code> 
   * objects.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> used 
   *        to search for metadata
   * @param lCount a <code>int</code> representing the maximum number of measures
   *        to retrieve.  A value of 0 implies all measures.
   *
   * @return <code>List</code> representing the list of available 
   *         <code>MDDimensionCalc</code> objects, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *
   * 
   */
  public static List getCustomMeasures (MetadataManagerServices metadataManagerServices, long lCount) 
    throws MetadataManagerException, NamingException {

    return getMDObjects (metadataManagerServices, MM.CALCULATION, lCount);
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of available <code>MDDimensionCalc<code> 
   * objects.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> 
   *        used to search for metadata
   *
   * @return <code>List</code> representing the list of available  
   *         <code>MDDimensionCalc</code> objects, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDDimensionCalc</code> objects cannot be retrieved.
   *
   * 
   */
  public static List getCustomDimMembers (MetadataManagerServices metadataManagerServices) 
                            throws NamingException, MetadataManagerException {

    return getMDObjects (metadataManagerServices, MM.DIMENSIONCALC);
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of <code>MDObject</code> values meeting
   * the specified search criteria.
   *
   * @param mdFolder a <code>MDFolder</code> where the search begins.
   * @param basicAttributes a <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls a <code>SearchControls</code> that contains the
   *        search controls to search for.
   *
   * @return <code>List</code> representing the list of available  
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * 
   */
  static protected List getMDObjects (MDFolder mdFolder, 
    BasicAttributes basicAttributes, SearchControls searchControls) 
                            throws MetadataManagerException, NamingException {

    return getMDObjects (mdFolder, basicAttributes, searchControls, new Vector());
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of <code>MDObject</code> values meeting
   * the specified search criteria.
   *
   * @param mdFolder a <code>MDFolder</code> where the search begins.
   * @param basicAttributes a <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls a <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param listMembers a <code>List</code> of <code>MDObject</code> values
   *        to be recursively updated.
   *
   * @return <code>List</code> representing the list of available  
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * 
   */
  static protected List getMDObjects (MDFolder mdFolder, 
    BasicAttributes basicAttributes, SearchControls searchControls, 
      List listMembers) throws MetadataManagerException, NamingException {

    return getMDObjects (mdFolder, basicAttributes, searchControls, listMembers, -1);
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of <code>MDObject</code> values meeting
   * the specified search criteria.
   *
   * @param mdFolder a <code>MDFolder</code> where the search begins.
   * @param basicAttributes a <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls a <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param lCount a <code>long</code> representing the maximum number of objects
   *        to retrieve.  A value of 0 implies all measures.
   *
   * @return <code>List</code> representing the list of available  
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * 
   */
  static protected List getMDObjects (MDFolder mdFolder, 
    BasicAttributes basicAttributes, SearchControls searchControls, long lCount) 
                            throws MetadataManagerException, NamingException {

    return getMDObjects (mdFolder, basicAttributes, searchControls, new Vector(), lCount);
  }

  /**
   * @internal
   *
   * Retrieves a <code>List</code> of <code>MDObject</code> values meeting
   * the specified search criteria.
   *
   * @param mdFolder a <code>MDFolder</code> where the search begins.
   * @param basicAttributes a <code>BasicAttributes</code> that contains the
   *        the attributes to search for.
   * @param searchControls a <code>SearchControls</code> that contains the
   *        search controls to search for.
   * @param listMembers a <code>List</code> of <code>MDObject</code> values
   *        to be recursively updated.
   * @param lCount a <code>long</code> representing the maximum number of objects
   *        to retrieve.  A value of 0 implies all measures.
   *
   * @return <code>List</code> representing the list of available  
   *         <code>MDObject</code> values, if any
   * 
   * @throws <code>NamingException</code> or <code>MetadataManagerException</code>
   *         if <code>MDObject</code> values cannot be retrieved.
   *         
   * 
   */
  static protected List getMDObjects (MDFolder mdFolder, 
    BasicAttributes basicAttributes, SearchControls searchControls, 
      List listMembers, long lCount) throws MetadataManagerException, NamingException {

    // Invoke the search
    Enumeration enumeration = 
      mdFolder.search ("", basicAttributes, searchControls);

    // Iterate over the search results
    if (enumeration != null) {
      MetadataManagerSearchResultImpl mmResult = null;
      long lItems = (listMembers != null) ? listMembers.size() : 0;
      
      while (enumeration.hasMoreElements() && 
            (lCount <= 0 || (lItems < lCount))) {

        // Retrieve the next search result
        mmResult = (MetadataManagerSearchResultImpl) enumeration.nextElement();
        if (mmResult != null) {
          // Retrieve the number of intersecting dimensions used for ranking
          Attributes attributes = mmResult.getAttributes();
          Integer intIntersection = null;

          if (attributes != null) {
            // Retrieve the number of intersecting dimensions used for ranking
            Attribute attribute = 
              attributes.get (FILTER_DIMENSION_RANK);
            
            if (attribute != null) {
              intIntersection = (Integer)attribute.get();
            }
          }
  
          MDObject mdObject = (MDObject) mmResult.getObject();

          // Remember the number of intersecting dimensions used for ranking
          if (intIntersection != null) {
            mdObject.setIntPropertyValue (FILTER_DIMENSION_RANK, 
              intIntersection.intValue()) ;  
          }
          
          // If we found a folder, keep recursing
          if (mdObject instanceof MDFolder) {
            getMDObjects ((MDFolder)mdObject, basicAttributes, searchControls, listMembers, lCount); 
          }
          else {
            // If we have found a dimension calc, add it to the list
            if (listMembers != null) {
              listMembers.add (mdObject);
            }
          }

          if (listMembers != null) {
            lItems = listMembers.size();
          }
        }
      }
    }
    
    return listMembers;
  }

  /**
   * @internal
   *
   * Retrieves a <code>Hashtable</code> which maps <code>MM.AW_OBJECT_NAME</code>
   * values to the corresponding <code>MDDimensionCalc<code> object.
   *
   * @param listDimMembers a <code>List</code> of <code>MDDimensionCalc</code> 
   *        values to retrieve <code>MM.AW_OBJECT_NAME</code> values for.
   *
   * @return <code>Hashtable</code> representing the mapping of 
   *         <code>MM.AW_OBJECT_NAME</code> values to <code>MDDimensionCalc</code> 
   *         objects, if any
   * 
   * @throws <code>MetadataManager</code> exception if <code>MDDimensionCalc<code>
   *         objects can not be retrieved.
   *         
   * 
   */
  public static Hashtable getCustomDimMembers (List listDimMembers) 
                                              throws MetadataManagerException {

    Hashtable hashtable = new Hashtable();
    
    if ((listDimMembers != null) && (!listDimMembers.isEmpty())) {
      Iterator iterator = listDimMembers.iterator();
      if (iterator != null) {
      
        MDObject mdObject;
        String strAWname; 
        
        while (iterator.hasNext()) {
          mdObject = (MDObject) iterator.next();

          strAWname = null;
          
          try {
            strAWname = mdObject.getAWObjectName();      
          }
          
          catch (Exception e) {
            
          }

          // Map the AW object name to the MDObject
          if ((strAWname != null) && (mdObject != null)) {
            hashtable.put (strAWname, mdObject);   
          }
        }
      }
    }

    return hashtable;
  }

  /**
   *  Associates a label with a combo box control to simplify focus control.
   *
   *  When the combo box is editable, this routine associates the label with
   *  the combo box's editor component instead of the combo box itself.
   *
   *  @param  jLabel a <code>JLabel</code> value to associate with a combo box.
   *  @param  jComboBox a <code>JComboBox</code> value to associate the label
   *          with.
   *
   *  
   */
  static public void setLabelFor (JLabel jLabel, JComboBox jComboBox) {
    if ((jLabel != null) && (jComboBox != null)) {
      // Associate this label with the combo box

      // If the combo box is editable, we must set the focus on the Editor
      // Component instead of the Combo box
      if (jComboBox.isEditable())
        jLabel.setLabelFor (jComboBox.getEditor().getEditorComponent());
      else
        jLabel.setLabelFor (jComboBox);
      
      AccessibleContext accessibleContext = jComboBox.getAccessibleContext();
      if (accessibleContext != null)
        accessibleContext.setAccessibleName(jLabel.getAccessibleContext().getAccessibleName());
    }
  }

  /**
   *  Retrieves a <code>JRadioButton</code> based on the specified text
   *  value that is processed for mnemonics.
   *
   *  @param  strText a <code>String</code> value that represents the
   *          button's text that is processed for mnemonics.
   *  @param  alignmentY a <code>float</code> value that represents the button's
   *          Y alignment.
   *  @return <code>JRadioButton</code> which represents the newly constructed
   *          button.
   *  
   */
  static public JRadioButton getRadioButton (String strText, float alignmentY) {
    JRadioButton jRadioButton = new JRadioButton (strText);
    jRadioButton.setAlignmentY (alignmentY);
    jRadioButton.setMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jRadioButton.setText(StringUtils.stripMnemonic(strText));
    return jRadioButton;
  }

  /**
   *  Retrieves a <code>JLabel</code> based on the specified text
   *  value that is processed for mnemonics.
   *
   *  @param  strText a <code>String</code> value that represents the
   *          label's text that is processed for mnemonics.
   *  @param  horizontalAlignmentY a <code>int</code> value that represents
   *          the label's horizontal alignment.
   *  @return <code>JLabel</code> which represents the newly constructed
   *          label.
   *  
   */
  static public JLabel getLabel (String strText, int horizontalAlignment) {
    JLabel jLabel = new JLabel (strText, horizontalAlignment);
    jLabel.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jLabel.setText(StringUtils.stripMnemonic(strText));
    return jLabel;
  }

  /**
   *  Retrieves a <code>JLabel</code> based on the specified text
   *  value that is processed for mnemonics.  Defaults alignment to
   *  <code>SwingConstants.LEFT</code>.
   *
   *  @param  strText a <code>String</code> value that represents the
   *          label's text that is processed for mnemonics.
   *  @return <code>JLabel</code> which represents the newly constructed
   *          label.
   *  
   */
  static public JLabel getLabel (String strText) {
    return getLabel (strText, SwingConstants.LEFT);
  }

  /**
   *  Sets the text value that associated with the specified <code>JLabel</code>
   *  which is processed for mnemonics.
   *
   *  @param  jLabel a <code>JLabel</code> value that represents the
   *          label to process.
   *  @param  strText a <code>String</code> value that represents the
   *          label's text that is processed for mnemonics.
   *  
   */
  static public void setLabelText (JLabel jLabel, String strText) {
    jLabel.setDisplayedMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jLabel.setText(StringUtils.stripMnemonic(strText));
  }

  /**
   *  Sets the text value that associated with the specified <code>JLabel</code>
   *  which is processed for mnemonics.
   *
   *  @param  jButton a <code>JButton</code> value that represents the
   *          button to process.
   *  @param  strText a <code>String</code> value that represents the
   *          button's text that is processed for mnemonics.
   *  
   */
  static public void setLabelText (JButton jButton, String strText) {
    jButton.setMnemonic(StringUtils.getMnemonicKeyCode(strText));
    jButton.setText(StringUtils.stripMnemonic(strText));
  }

  static public String getCommaDelimitedString(Vector objs, int intMaxItems)
  {
      StringBuffer strBuffer = null;
      boolean blnItemsInList = false;

      if (objs != null)
      {
          strBuffer = new StringBuffer();

          // Loops through each object, adding it string
          // representation to a string buffer. Each new
          // string is separated by a comma.
          int intLoopMax = Math.min(objs.size(), intMaxItems);
          int i;
          for (i=0; i<intLoopMax; i++)
          {
              if ( (i<intLoopMax) && (blnItemsInList) )
              {
                  strBuffer.append(", ");
              }
              strBuffer.append(objs.elementAt(i));
              blnItemsInList = true;
          }

          // If there were more items to display, tack on a
          // '...' on the end.
          if ( (i==intMaxItems) && (objs.size()>intMaxItems) )
          {
              strBuffer.append("...");
          }

          if (strBuffer.length() > 0)
          {
              return (strBuffer.toString());
          }
      }

      return (null);
  }

  /**
  * @internal
  * 
  * Returns a comma-delimited list based upon a vector.
  * The toString() method of the object type stored in vector
  * is used to evaluate the string representation.
  * 
  * 
  */
  static public String getCommaDelimitedString(Vector objs) {
      StringBuffer strBuffer = null;
      boolean blnItemsInList = false;

      if (objs != null) {
          strBuffer = new StringBuffer();

          // Loops through each object, adding it string
          // representation to a string buffer. Each new
          // string is separated by a comma.
          for (Enumeration e = objs.elements();  e.hasMoreElements(); ) {
              if ((e.hasMoreElements()) && (blnItemsInList)) {
                  strBuffer.append(",");
              }
              strBuffer.append(e.nextElement());
              blnItemsInList = true;
          }
          if (strBuffer.length() > 0) {
              return (strBuffer.toString());
          }
      }
      return (null);
  }

  /**
  * @internal
  * 
  * Returns a comma-delimited list based upon an object array.
  * The toString() method of the object type stored in the array
  * is used to evaluate the string representation.
  * 
  * 
  */
  static public String getCommaDelimitedString(Object[] objs) {
      StringBuffer strBuffer = null;
      boolean blnItemsInList = false;

      if (objs != null) {
          strBuffer = new StringBuffer();

          // Loops through each object, adding it string
          // representation to a string buffer. Each new
          // string is separated by a comma.
          for (int i=0; i<objs.length; i++) {
              if ((i<objs.length) && (blnItemsInList)) {
                  strBuffer.append(", ");
              }
              strBuffer.append(objs[i]);
              blnItemsInList = true;
          }

          if (strBuffer.length() > 0) {
              return (strBuffer.toString());
          }
      }
      return (null);
  }

  public static String[] parseDelimitedStringArray(String str, String delim) {
    Vector result = parseDelimitedStringVector(str, delim);
    if (result == null)
      return null;
    return (String[])result.toArray(new String[result.size()]);
  }
  
  public static Vector parseDelimitedStringVector(String str, String delim, boolean bTrim) {
    if (str == null || delim == null)
      return null;
    Vector result = new Vector();
    StringTokenizer st = new StringTokenizer(str, delim);
    while (st.hasMoreTokens()) {
      if (bTrim) {
        result.addElement(st.nextToken().trim());
      }
      else {
        result.addElement(st.nextToken());
      }  
    }
    return result;
  }

  public static Vector parseDelimitedStringVector(String str, String delim) {
    return parseDelimitedStringVector(str, delim, false);
  }

  public static String getDelimitedString(String[] strs, char delim) {
    if (strs == null)
      return null;
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < strs.length; i++) {
      if (i != 0)
        sb.append(delim);
      sb.append(strs[i]);
    }
    return sb.toString();
  }

  /**
   * Constructs a default DataUtils object.
   *
   *
   *
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  public static Selection evaluateSelection ( QueryContext queryContext,
                                              Selection selection, MetadataMap map )
                                              throws IllegalArgException
  {
      DataAccess  dataAccess      = null;
      MemberStep  memberStep      = null;
      QueryAccess queryAccess     = null;
      Selection   selectionBase   = null;

      // If the user hasn't specified a QueryContext, there isn't much
      // we can do.
      if (queryContext == null)
          throw new IllegalArgException (
              DataUtilClientBundle.EXC_QUERYCONTEXT_NOT_SET, 1, queryContext);

      // If the user hasn't specified a Selection, there isn't much
      // we can do.
      if (queryContext == null)
          throw new IllegalArgException (
              DataUtilClientBundle.EXC_SELECTION_NOT_SET, 2, selection);

      // Provide a default map if none is supplied.
      if ( null == map )
      {
          map = new MetadataMap ( new String [ ]
                                  {
                                    MetadataMap.METADATA_VALUE,
                                    MetadataMap.METADATA_SHORTLABEL,
                                    MetadataMap.METADATA_MEDIUMLABEL,
                                    MetadataMap.METADATA_LONGLABEL
                                  } );
      }

      queryAccess = queryContext.createQueryAccess ( );
      if ( null == queryAccess )
          return null;

      queryAccess.setMetadataMap ( map );
      dataAccess = queryAccess.getDataAccess ( selection );
      if ( dataAccess != null )
      {
          memberStep = getDataAccessMembers ( dataAccess );
          if ( memberStep != null )
          {
              selectionBase = new Selection ( );
              
              memberStep.setDimension ( selection.getDimension ( ) );
              selectionBase.setDimension ( selection.getDimension ( ) );
              
              selectionBase.addStep ( memberStep, 0 );
          }
          
          dataAccess.release ( );
      }            
      // Release the Query Access object
      queryAccess.release ( );
      
      return selectionBase;
  }    
  */

  /**
   * Retrieves the dimensions from a specified metadataManager and stores them
   * as a flat list. The list includes the measure dimension.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> 
   *                        object from which to retrieve the dimensions.
   * @param labelType       One of the constants from
   *                        <code>util.LayerMetadataMap</code>
   *                        that describes a metadata label type such as
   *                        short, long, or medium labels.
   *
   * @param listDimensions  The vector in which to store the dimensions.
   *                        Each dimension is stored as a
   *                        <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the dimensions
   *         were retrieved and stored successfully;
   *         <code>false</code> if they were not retrieved and stored
   *         successfully.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   *
   * 
   */
  static public boolean getAllDimensions ( MetadataManagerServices metadataManagerServices,
                                           String labelType, Vector listDimensions )
  {
      boolean         bRetVal             = false;
      DimensionMember measureDimension    = null;

      if ( metadataManagerServices == null  ||
           labelType == null ||
           listDimensions == null )
           return false;

      bRetVal = getDimensions ( metadataManagerServices, labelType, listDimensions );
      if ( ! bRetVal || 0 == listDimensions.size ( ) )
      {
          if ( listDimensions.size ( ) > 0 )
              listDimensions.removeAllElements ( );
          return false;
      }

      measureDimension = getMeasureDimension ( null,
                                               metadataManagerServices, labelType );
      if ( null == measureDimension )
      {
          if ( listDimensions.size ( ) > 0 )
              listDimensions.removeAllElements ( );
          return false;
      }

      // Add the measure dimension at the very top.
      listDimensions.insertElementAt ( measureDimension, 0 );

      return true;
  }

  /**
   * Retrieves the members of the specified data access.
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  public static MemberStep getDataAccessMembers ( DataAccess dataAccess )
  {
      int         nIndex      = -1, nMemberCount = -1;
      MemberStep  memberStep  = null;
      String      strMember   = null;
      String      strLevel    = null;
      
      if ( null == dataAccess )
          return null;

      memberStep = new MemberStep ( ); 
      
      try
      {
          nMemberCount = dataAccess.getEdgeExtent ( DataDirector.COLUMN_EDGE );
          for ( nIndex = 0; nIndex < nMemberCount; nIndex++ )
          {
              strMember = DataUtils._makeString( dataAccess.getMemberMetadata (
                                                DataDirector.COLUMN_EDGE,
                                                0, nIndex, MetadataMap.METADATA_VALUE ) );
              strLevel = DataUtils._makeString( dataAccess.getMemberMetadata (
                                                DataDirector.COLUMN_EDGE,
                                                0, nIndex, MetadataMap.METADATA_LEVEL_NAME ) );

              if ( strMember != null && strMember.length ( ) > 0 )
              {
                  memberStep.addMember( new String ( strMember ), strLevel );
              }
          }
      }
      catch ( Exception exception )
      {
          return null;
      }

      if ( 0 == memberStep.getMemberCount ( ) )
          return null;

      return memberStep;
  }
*/
  /**
   * Retrieves the dimensions from a specified metadataManager and stores them
   * as a flat <code>MDDimension</code> list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to
   *                       retrieve the dimensions.
   * @param nFilter   Dimension filter.
   *
   * @return <code>MDDimension[]</code> representing the filtered dimension list.
   *
   * @throws <code>MetadataManagerException</code> if the dimensions can't be
   *         retrieved.
   *
   * @see oracle.dss.datautil.DataUtils#FILTER_NONE
   * @see oracle.dss.datautil.DataUtils#FILTER_BY_MEASURE
   * @see oracle.dss.datautil.DataUtils#FILTER_BY_HIERARCHY
   *
   * 
   */
  static public MDDimension[] getDimensions (MetadataManagerServices metadataManagerServices,
                                             int nFilter)
                                             throws MetadataManagerException {

    MDDimension[] mdDimensions = null;
    if (metadataManagerServices == null)
      return null;

    // Retrieve the dimension list
    mdDimensions = metadataManagerServices.getDimensions();

    Vector vDimensions = new Vector();

    // Determine if we need to filter by measure
    if ((nFilter & FILTER_BY_MEASURE) != 0) {
      if (mdDimensions != null) {
        MDMeasure[] mdMeasures = metadataManagerServices.getMeasures();
        if (mdMeasures == null)
          return null;

        // Iterate over each dimension
        for (int nDimension = 0; nDimension < mdDimensions.length; nDimension++) {
          // Iterate over each measure
          for (int nMeasure = 0; nMeasure < mdMeasures.length; nMeasure++) {
            // Check to see if this measure references the current dimension
            if (DataUtils.isDimensionedBy (
              metadataManagerServices, mdMeasures[nMeasure].getUniqueID(),
                mdDimensions [nDimension].getUniqueID())) {

              // Add this dimension to our list
              vDimensions.addElement (mdDimensions [nDimension]);
              break;
            }
          }
        }
      }
    }

    // Determine if we need to filter by hierarchy
    if ((nFilter & FILTER_BY_HIERARCHY) != 0) {
      if (!vDimensions.isEmpty()) {
        // Iterate over each dimension
        for (int nDimension = vDimensions.size()-1; nDimension > -1; nDimension--) {
          // Check to see if this dimension references a hierarchy
          MDDimension mdDimension = (MDDimension) vDimensions.elementAt(nDimension);
          MDHierarchy mdHierarchy = mdDimension.getDefaultHierarchy();

          // If we don't have a hierarchy, remove dimension
          if (mdHierarchy == null) {
            // Add this dimension to our list
            vDimensions.removeElementAt (nDimension);
          }
        }
      }
      else
        if (mdDimensions != null) {
          // Iterate over each dimension
          for (int nDimension = 0; nDimension < mdDimensions.length; nDimension++) {
            // Check to see if this measure references the current dimension
            MDHierarchy mdHierarchy =
              mdDimensions [nDimension].getDefaultHierarchy();

            if (mdHierarchy != null) {
              // Add this dimension to our list
              vDimensions.addElement (mdDimensions [nDimension]);
            }
          }
        }
      }

    // Check to see if we have any dimensions
    if ((nFilter & (FILTER_BY_MEASURE | FILTER_BY_HIERARCHY)) != 0) {
      if (!vDimensions.isEmpty()) {
        // Create the dimension list
        mdDimensions = new MDDimension [vDimensions.size()];
        mdDimensions = (MDDimension[])Utility.copyVectorToArray(vDimensions);
      }
      else
        mdDimensions = null;
    }

    return mdDimensions;
  }

  /**
   * Retrieves the dimensions from a specified metadataManager and stores them
   * as a flat list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to
   *                       retrieve the dimensions.
   * @param strLabelType  One of the label type constants from
   *                      <code>util.LayerMetadataMap</code> that represents
   *                      long labels, short labels, or medium labels.
   * @param vDimensions   The vector in which to store the dimensions.
   *                      Each dimension is stored as a
   *                      <code>DimensionMember</code> object.
   * @param nFilter       Dimension filter.
   *
   * @return <code>true</code> if the dimensions
   *          were retrieved and stored successfully;
   *          <code>false</code> if the dimensions were not
   *          retrieved and stored successfully.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   *
   * @see oracle.dss.datautil.DataUtils#FILTER_NONE
   * @see oracle.dss.datautil.DataUtils#FILTER_BY_MEASURE
   *
   * 
   */
  static public boolean getDimensions (MetadataManagerServices metadataManagerServices,
    String strLabelType, Vector vDimensions, int nFilter) {
    int             nIndex          = -1;
    String          strDimId        = null;
    String          strDimDesc      = null;
    MDDimension     mdDimension     = null;
    MDDimension[]   mdDimensions    = null;

    if (metadataManagerServices == null ||
        strLabelType == null            ||
        vDimensions == null )
      return false;

    try {
      mdDimensions = getDimensions (metadataManagerServices, nFilter);
      if (mdDimensions == null)
        return false;
    }

    catch (Exception e) {
      return false;
    }

    for (nIndex = 0; nIndex < mdDimensions.length; nIndex++) {
      mdDimension = mdDimensions [nIndex];
      if (mdDimension == null)
        continue;

      strDimId = new String (getMdObjectDesc (mdDimension,
                                 LayerMetadataMap.LAYER_METADATA_NAME));

      strDimDesc = new String (getMdObjectDesc (mdDimension, strLabelType));

      if (strDimId.length() == 0 || strDimDesc.length() == 0)
        continue;

      vDimensions.addElement (new DimensionMember (strDimId, strDimDesc));
    }

    return true;
  }

  /**
   * Retrieves the dimensions from a specified metadataManager and stores them
   * as a flat list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to
   *                       retrieve the dimensions.
   * @param labelType      One of the label type constants from
   *                       <code>util.LayerMetadataMap</code> that represents
   *                       long labels, short labels, or medium labels.
   * @param listDimensions The vector in which to store the dimensions.
   *                       Each dimension is stored as a
   *                       <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the dimensions
   *          were retrieved and stored successfully;
   *          <code>false</code> if the dimensions were not
   *          retrieved and stored successfully.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   *
   */
  static public boolean getDimensions (MetadataManagerServices metadataManagerServices,
                                       String labelType,
                                       Vector listDimensions) {

    return getDimensions (metadataManagerServices, labelType, listDimensions,
      FILTER_NONE);
  }

  /**
   * Retrieves the list of dimensions for a measure in the metadataManager.
   *
   * @param metadataManagerServices The MetadataManagerServices in which to find the dimensions.
   * @param strMeasure      The measure for which to retrieve the dimensions.
   * @param labelType       One of the label type constants from
   *                        <code>util.LayerMetadataMap</code> that represents
   *                        long labels, short labels, medium labels.
   * @param listDimensions  The vector in which to store the dimensions.
   *                        Each dimension is stored as a
   *                        <code>DimensionMember</code> object.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   *
   * 
   */
  static public boolean getDimensions ( MetadataManagerServices metadataManagerServices,
                                        String strMeasure, String labelType,
                                        Vector listDimensions )
  {
      int             nIndex          = -1;
      String          strDimId        = null, strDimDesc = null;
      MDMeasure       mdMeasure       = null;
      MDDimension     mdDimension     = null;
      MDDimension [ ] mdDimensionList = null;

      if ( metadataManagerServices == null    ||
           strMeasure == null  ||
           labelType == null   ||
           listDimensions == null)
           return false;

      // Attempt to get the MDMeasure object first..
      try
      {
          mdMeasure = metadataManagerServices.getMeasure (
                                          MM.UNIQUE_ID, strMeasure );
      }
      catch (MetadataManagerException mme)
      {
          mme.printStackTrace();
      }

      if ( null == mdMeasure )
          return false;

      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          mdDimensionList = mdMeasure.getDimensions ( );
          if ( mdDimensionList == null )
              return false;
          }

      catch (Exception e)
          {
          return false;
          }                

      for ( nIndex = 0; nIndex < mdDimensionList.length; nIndex++ )
      {
          mdDimension = mdDimensionList [ nIndex ];
          if ( mdDimension == null )
              continue;

          strDimId =new String ( getMdObjectDesc ( mdDimension,
                                 LayerMetadataMap.LAYER_METADATA_NAME ) );

          strDimDesc = new String ( getMdObjectDesc ( mdDimension, labelType ) );

          if ( strDimId.length ( ) == 0 || strDimDesc.length ( ) == 0 )
               continue;

          listDimensions.addElement (new DimensionMember (strDimId, strDimDesc));
      }

      return true;
  }

  /**
   * Retrieves the dimensions for a label type from a specified MetadataManagerServices
   * and gets the specified label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object
   * from which to retrieve the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param srcDimension The incoming dimension name.
   *
   * @return <code>DimensionMember</code> if the dimensions label was retrieved
   * <code>null</code> if not.
   *
   * 
   */
  static public DimensionMember getDimensionLabel ( MetadataManagerServices metadataManagerServices, 
                                                    String srcLabelType,
                                                    String targetLabelType,
                                                    String strDimension )
  {
      boolean bRetVal     = false;
      Vector  listDimSrc  = null, listDimTarget = null;

      if ( null == metadataManagerServices || null == srcLabelType ||
           null == targetLabelType || null == strDimension )
          return null;
      
      listDimSrc = new Vector ( );
      listDimSrc.addElement ( strDimension );
      
      listDimTarget = new Vector ( );

      bRetVal = getDimensionLabels ( metadataManagerServices,
                                     srcLabelType, targetLabelType,
                                     listDimSrc, listDimTarget );
      if ( bRetVal && 1 == listDimTarget.size ( ) )
          return ( DimensionMember ) listDimTarget.elementAt ( 0 );

      return null;
  }

  /**
   * Retrieves the dimensions for a label type from a specified MetadataManagerServices
   * and gets the specified label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code>
   * object from which to retrieve the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param srcListDimensions The list of incoming dimension names. Each name
   * is identified by the srcLabelType param.
   * @param targetListDimensions The vector in which to store the dimensions.
   * Each measure is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the dimensions were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */
  static public boolean getDimensionLabels (
                        MetadataManagerServices metadataManagerServices,
                        String srcLabelType,
                        String targetLabelType,
                        Vector srcListDimensions,
                        Vector targetListDimensions )
  {
      int         nIndex      = -1;
      MDDimension mdDimension = null;
      String      strDimSrcId = null, strDimTargetId = null;

      if ( null == metadataManagerServices ||
           null == srcLabelType ||null == targetLabelType ||
           null == srcListDimensions ||null == targetListDimensions )
          return false;

      for ( nIndex = 0; nIndex < srcListDimensions.size ( ); nIndex++ )
      {
          strDimSrcId = ( String ) srcListDimensions.elementAt ( nIndex );
          if ( null == strDimSrcId )
              continue;

          try
          {
              mdDimension = metadataManagerServices.getDimension (
                                                mapToMetadataManagerId ( srcLabelType ),
                                                strDimSrcId );
          }
          catch (MetadataManagerException mme)
          {
              mme.printStackTrace();
          }

          if ( null == mdDimension )
              continue;

          strDimTargetId = new String ( getMdObjectDesc (
                                        mdDimension, targetLabelType ) );

          if ( null == strDimTargetId || 0 == strDimTargetId.length() )
              continue;

          targetListDimensions.addElement ( new DimensionMember (
                                            new String ( getMdObjectDesc ( mdDimension,
                                            LayerMetadataMap.LAYER_METADATA_NAME ) ),
                                            strDimTargetId ) );
      }

      return true;
  }

  /**
   * Retrieves the dimension member (id/label pair) for one dimension member
   * based on an initial source label and a target source label.
   *
   * @param queryContext The QueryContext object.
   * @param srcLabelType The label type of the incoming dimension member.
   * @param targetLabelType The label type of the outgoing dimension member.
   * @param strDimension The name of the dimension.
   * @param strHierarchy The name of the dimension's hierarchy. 
   * @param strDimMember The label of the dimension member.
   *
   * @return The DimensionMember object describing the dimension member.
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  static public DimensionMember getDimensionMemberLabel (QueryContext queryContext,
    String srcLabelType, String targetLabelType, String strDimension,
    String strHierarchy, String strDimMember) {

    boolean bRetVal             = false;
    Vector  listSrcDimMember    = null;
    Vector  listTargetDimMember = null;

    if (queryContext == null || srcLabelType == null ||
        targetLabelType == null || strDimension == null ||
        strDimMember == null)
      return null;

    listSrcDimMember = new Vector ( );
    listSrcDimMember.addElement ( strDimMember );

    listTargetDimMember = new Vector ( );

    bRetVal =
      getDimensionMembersLabel (queryContext, srcLabelType,
        targetLabelType, strDimension, strHierarchy, listSrcDimMember,
          listTargetDimMember);

    if (!bRetVal || listTargetDimMember.size() == 0)
      return null;

    return (DimensionMember) listTargetDimMember.elementAt (0);
  }
*/


  /**
   * Retrieves the default hierarchy associated with the specified dimension.
   *
   * @param strDimensionID a <code>String</code> value that represents the ID
   *        of the dimension to retrieve default hierachy from.
   *
   * @return  A <code>String</code> value that represents the hierarchy ID or
   *          null
   *
   * 
   */
  static public String getDefaultHierarchy (MetadataManagerServices metadataManager,
                                            String strDimensionID)
                                            throws MetadataManagerException
      {
      String strHierarchyID = null;

      MDDimension mdDimension =
          (MDDimension)metadataManager.getDimension(MM.UNIQUE_ID,
              strDimensionID);

      if (mdDimension != null)
          {
          MDHierarchy mdHierarchy = mdDimension.getDefaultHierarchy();
          if (mdHierarchy != null)
              {
              strHierarchyID = mdHierarchy.getUniqueID();
              }
          }

      return strHierarchyID;
      }


  /**
   * Generates some reasonable form of an initial condition type step only
   */
   // blm - Selection code moved to dvt-olap
/*  public static ConditionStep getInitialConditionStep(String dimension, String hierarchy, Vector vLevels, MetadataManagerServices metadataManager) throws MetadataManagerException, InvalidStepArgException
  {
      return (ConditionStep)getInitialStep(dimension, hierarchy, vLevels, true, metadataManager);
  }
*/
  /**
   * Generates some reasonable form of an initial, small step regardless of the presence
   * of a hierarchy, levels, etc.
   */
   // blm - Selection code moved to dvt-olap
/*  public static Step getInitialStep(String dimension, String hierarchy, Vector vLevels, MetadataManagerServices metadataManager) throws MetadataManagerException, InvalidStepArgException
  {
      return getInitialStep(dimension, hierarchy, vLevels, 1, false, metadataManager);
  }
*/
  /**
   * Generates some reasonable form of an initial, small step regardless of the presence
   * of a hierarchy, levels, etc.
   */
   // blm - Selection code moved to dvt-olap
/*  public static Step getInitialStep(String dimension, String hierarchy, Vector vLevels, boolean allStep, MetadataManagerServices metadataManager) throws MetadataManagerException, InvalidStepArgException
  {
      return getInitialStep(dimension, hierarchy, vLevels, 1, allStep, metadataManager);
  }
*/
  /**
   * Generates some reasonable form of an initial, small step regardless of the presence
   * of a hierarchy, levels, etc.
   */
   // blm - Selection code moved to dvt-olap
/*  public static Step getInitialStep(String dimension, String hierarchy, Vector vLevels, int maxLevel, boolean allStep, MetadataManagerServices metadataManager) throws MetadataManagerException, InvalidStepArgException
  {
      if (dimension == null)
          return null;

      // Get the MDDimension
      MDDimension dim = (MDDimension)metadataManager.getMDObject(MM.UNIQUE_ID, dimension, MM.DIMENSION);
      if (dim == null)
          return null;

      MDHierarchy hier = null;
      if (hierarchy == null)
      {
          // If we don't have a hierarchy, can we get the default?
          hier = dim.getDefaultHierarchy();
      }
      else
      {
          hier = (MDHierarchy)metadataManager.getMDObject(MM.UNIQUE_ID, hierarchy, MM.HIERARCHY);
      }

      if (hier == null)
      {
          // This must be a dimension without a hierarchy.  Is it the measure?
          String measID = metadataManager.getMeasureDimension(null).getUniqueID();
          if (allStep)
          {
              return new AllStep(dimension, null, null);
          }
          if (dimension.equals(measID))
          {
              // Just use the zeroth measure from the metadata manager
              MDMeasure[] measures = metadataManager.getMeasures();
              if (measures != null && measures.length > 0)
              {
                  String id = measures[0].getUniqueID();
                  Selection tempSel = new Selection(dimension);
                  MemberStep ms = new MemberStep(dimension);
                  ms.addMember(id);
                  return ms;
              }
              return null;
          }
          else
          {
              // Just a regular, hierarchy-less dimension.  Use firstlast step
              FirstLastStep fls = new FirstLastStep(dimension);
              fls.setFirstLastType(FirstLastStep.FIRST);
              fls.setNumValues(new Integer(1));
              return fls;
          }
      }
      else
      {
          // OK we have a hierarchy
          if (vLevels == null || vLevels.size() == 0)
          {
              // Check for levels--no levels specified
              MDLevel[] levels = hier.getLevels();
              if (levels != null && levels.length > 0)
              {
                  vLevels = new Vector();
                  // Just do the first N, if specified, one if not
                  int numLevels = maxLevel > levels.length ? levels.length : maxLevel;
                  for (int i = 0; i < numLevels; i++)
                  {
                      vLevels.addElement(levels[i].getUniqueID());
                  }
              }
          }
          if (vLevels != null && vLevels.size() > 0)
          {
              // And we presumably have levels
              AllStep all = new AllStep(dimension, hierarchy, vLevels);
              return all;
          }
          else
          {
              // No levels specified, and we couldn't find any.  Possibly a value based hierarchy.
              // Use special top ancestor family step
              FamilyStep fs = new FamilyStep(dimension, hierarchy, FamilyStep.OP_FIRSTANCESTORS, null, false);
              return fs;
          }
      }
  }
*/
  /**
   * Retrieves a <code>Vector</code> of <code>DimensionMember</code> objects
   * associated with the specified dimension, hierarchy, levels and label type.
   *
   * @param queryContext A <code>QueryContext</code> object from which to
   *        retrieve the dimension members.
   * @param strDimensionID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the dimension whose 
   *        members are to be retrieved.
   * @param strHierarchyID A <code>String</code> that represents the 
   *        <code>MetadataManager</code> unique ID of the hierarchy whose 
   *        members are to be retrieved.      
   * @param vstrLevelIDs A <code>Vector/code> of <code>String</code> values 
   *        that represents the <code>MetadataManager</code> unique IDs of the 
   *        levels whose members are to be retrieved.      
   * @param strLabelType A <code>String</code> that represents the type of labels 
   *        to be retrieved.
   * @param vDimensionMembers A <code>Vector</code> of <code>DimensionMember</code>
   *        objects that represent the dimension members found.
   *
   * @return <code>boolean</code> which is <code>true</code> if the dimension 
   *         members were retrieved successfully and <code>false</code> otherwise.
   *
   * @see oracle.dss.util.LayerMetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_VALUE
   * @see oracle.dss.util.LayerMetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.LayerMetadataMap#METADATA_SHORTLABEL
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  static public boolean getDimensionMembers (QueryContext queryContext,
    String strDimensionID, String strHierarchy, Vector vstrLevels, String strLabelType,
      Vector vDimensionMembers) throws IllegalArgException {
  
    return QueryUtils.getDimensionMembers (queryContext, strDimensionID, 
      strHierarchy, vstrLevels, strLabelType, vDimensionMembers);
  }*/

  /**
   * Retrieves a list of  dimension member (id/label pair) for dimension members
   * based on an initial source label and a target source label.
   *
   * @param queryContext The QueryContext object.
   * @param srcLabelType The label type of the incoming dimension member.
   * @param targetLabelType The label type of the outgoing dimension member.
   * @param strDimension The name of the dimension.
   * @param strHierarchy The name of the dimension's hierarchy.
   * @param listSrcDimMember The incoming list of dimension members.
   * @param listTargetDimMember The outgoing list of DimensionMember objects
   * describing each dimension member.
   *
   * @return true if the operation was successful, false otherwise.
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  static public boolean getDimensionMembersLabel (QueryContext queryContext,
      String srcLabelType, String targetLabelType, String strDimension,
      String strHierarchy, Vector listSrcDimMember, Vector listTargetDimMember) {

    AllStep     allStep             = null;
    boolean     bRetVal             = false;
    DataAccess  dataAccess          = null;
    int         nIndex              = -1;
    int         nResult             = -1;
    MetadataMap metadataMap         = null;
    Selection   selection           = null;
    String      strMemberId         = null;
    String      strSrcDimMember     = null;
    String      strTargetDimMember  = null;
    QueryAccess queryAccess         = null;

    if (queryContext == null || srcLabelType == null ||
        targetLabelType == null || strDimension == null ||
        listSrcDimMember == null || listTargetDimMember == null)
      return false;
    
    if (strDimension.length() == 0 || listSrcDimMember.size() == 0)
      return false;
    
    metadataMap = 
      new MetadataMap (new String [] {MetadataMap.METADATA_VALUE,
                                      mapToMetadataMapType (srcLabelType),
                                      mapToMetadataMapType (targetLabelType)
                                     });
         
    // Build a new Selection object for this query
    selection = new Selection (strDimension);

    // Create an allStep for the query
    allStep = new AllStep (strDimension);

    // Update the hierarchy
    selection.setHierarchy (strHierarchy);
    allStep.setHierarchy (strHierarchy);

    // Add the step to the selection.
    selection.addStep (allStep);
    
    try {
      queryAccess = queryContext.createQueryAccess ( );
      
      // Let the user know if we can create a QueryAccess.
      if (queryAccess == null)
        throw new DataUtilRuntimeException (
          DataUtilClientBundle.EXC_QUERYACCESS_NOT_CREATED, null);

      queryAccess.setMetadataMap ( metadataMap );
      queryAccess.setSelection ( selection );
      dataAccess = queryAccess.getDataAccess ( selection.getDimension ( ) );

      // Let the user know if we can create a DataAccess.
      if (dataAccess == null)
        throw new DataUtilRuntimeException (
          DataUtilClientBundle.EXC_DATAACCESS_NOT_CREATED, null);

      for (nIndex = 0; nIndex < listSrcDimMember.size(); nIndex++) {
        strSrcDimMember = _makeString( listSrcDimMember.elementAt (nIndex));
        nResult = 
          dataAccess.findMember (0, new int [0], 0, strSrcDimMember,
            mapToMetadataMapType (srcLabelType), DataAccess.FIND_CASE_INSENSITIVE);

        if (nResult > -1) {
          listTargetDimMember.addElement (
            new DimensionMember (_makeString( dataAccess.getMemberMetadata (0, 0, nResult,
              MetadataMap.METADATA_VALUE)),
                _makeString( dataAccess.getMemberMetadata (0, 0, nResult,
                  mapToMetadataMapType (targetLabelType))), strHierarchy, _makeString( dataAccess.getMemberMetadata (0, 0, nResult,
              MetadataMap.METADATA_LEVEL)), _makeString( dataAccess.getMemberMetadata (0, 0, nResult,
              MetadataMap.METADATA_LEVEL_NAME))));
            }
        }

      bRetVal = true;            
    }
    
    catch (Exception exception) {
      throw new DataUtilRuntimeException (
        DataUtilClientBundle.EXC_DATAACCESS_NOT_CREATED, null);
    }

    if (dataAccess != null)
      dataAccess.release ();

    if (queryAccess != null)
        queryAccess.release ();

    return bRetVal;
  }
*/
  /**
   * @internal
   */
  public static String _makeString(Object value) {
    return value == null ? null : value.toString();
  }

  /**
   * @internal
   */
  public static String[] _makeString(Object[] value)
  {
      if (value == null)
      {
          return null;
      }
      String[] retVal = new String[value.length];
      for (int i = 0; i < value.length; i++)
      {
          if (value[i] != null)
          {
              retVal[i] = value[i].toString();
          }
      }
      return retVal;
  }

  /**
   * Retrieves the <code>DimensionMember</code> associated with the specified
   * <code>MDObject</code>.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object
   *        from which to retrieve the dimensions.
   * @param mdHierarchy a <code>MDObject</code> value that we need to retrieve
   *        the code>DimensionMember</code> for.
   * @param strLabelType a <code>String</code> value which is one of the constants
   *        from <code>util.LayerMetadataMap</code> that describes a metadata
   *        label type such as short, long, or medium labels.
   *
   * @return A <code>DimensionMember</code> value that associated with the
   *         <code>MetadataManager</code> object.
   *
   * 
   */
  static public DimensionMember getDimensionMember (MetadataManagerServices metadataManagerServices,
                                  MDObject mdObject, String strLabelType)
                                    throws MetadataManagerException {

    DimensionMember dimensionMember = null;

    // Check for null parameters
    if (metadataManagerServices == null || mdObject == null  ||
        strLabelType == null)
      return null;

    // Retrieve hierarchy runtime ID
    String strID =
      getMdObjectDesc (mdObject, LayerMetadataMap.LAYER_METADATA_NAME);

    // Retrieve hierarchy description
    String strDescription =
      getMdObjectDesc (mdObject, strLabelType);

    // Check to see if we have retrieved non-null hierarchy information
    if ((strID != null) && (strID.length() != 0)) {
      if ((strDescription != null) && (strDescription.length() != 0)) {
        dimensionMember =
          new DimensionMember (new String(strID),
            new String (strDescription));
      }
    }

    // Return the DimensionMember associated with the MDObject
    return dimensionMember;
  }

  /**
   * Retrieves the <code>Vector</code> of <code>DimensionMember</code> objects
   * associated with the specified dimensions.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object
   *        from which to retrieve the dimensions.
   * @param vstrDimensions a <code>Vector</code> value containing a list of
   *        dimensions that we need to retrieve <code>DimensionMember</code> values
   *        for.
   * @param strLabelType a code>String</code> value which is one of the constants
   *        from <code>util.LayerMetadataMap</code> that describes a metadata
   *        label type such as short, long, or medium labels.
   *
   * @return A <code>Vector</code> of <code>DimensionMember</code> values that
   *         associated with the dimensions.
   *
   * 
   */
  static public Vector getDimensionMembers (MetadataManagerServices metadataManagerServices,
                                  Vector vstrDimensions, String strLabelType)
                                    throws MetadataManagerException {

    Vector vDimensionMembers = new Vector();

    if (vstrDimensions != null) {
      Enumeration enumeration = vstrDimensions.elements();
      while (enumeration.hasMoreElements ()) {
        String strDimension = (String)enumeration.nextElement();

        // Retrieve the MDHierarchy associated with this runtime ID
        MDDimension mdDimension =
          (MDDimension)metadataManagerServices.getMDObject (MM.UNIQUE_ID,
            strDimension, MM.DIMENSION);

        if (mdDimension != null) {
          DimensionMember dimensionMember =
            getDimensionMember (metadataManagerServices, mdDimension, strLabelType);

          if (dimensionMember != null) {
            vDimensionMembers.addElement (dimensionMember);
          }
        }
      }
    }

    return vDimensionMembers;
  }

  /**
   * Retrieves the <code>DimensionMember</code> associated with the specified
   * <code>MDDimension</code>.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object
   *        from which to retrieve the dimensions.
   * @param strDimension a <code>String</code> value for the dimension that
   *        we need to retrieve the <code>DimensionMember</code> for.
   * @param strLabelType a code>String</code> value which is one of the constants
   *        from <code>util.LayerMetadataMap</code> that describes a metadata
   *        label type such as short, long, or medium labels.
   *
   * @return A <code>DimensionMember</code> value that associated with the
   *         dimension.
   *
   * 
   */
  static public DimensionMember getDimension (MetadataManagerServices metadataManagerServices,
                                  String strDimension, String strLabelType)
                                    throws MetadataManagerException {

    // Retrieve the MDDimension associated with this runtime ID
    MDDimension mdDimension =
      (MDDimension)metadataManagerServices.getMDObject (MM.UNIQUE_ID,
        strDimension, MM.DIMENSION);

    return getDimensionMember (metadataManagerServices, mdDimension, strLabelType);
  }

  /**
   * Retrieves the <code>DimensionMember</code> associated with the specified
   * <code>MDHierarchy</code>.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object
   *        from which to retrieve the dimensions.
   * @param strHierarchy a <code>String</code> value for the hierarchy that
   *        we need to retrieve the <code>DimensionMember</code> for.
   * @param strLabelType a code>String</code> value which is one of the constants
   *        from <code>util.LayerMetadataMap</code> that describes a metadata
   *        label type such as short, long, or medium labels.
   *
   * @return A <code>DimensionMember</code> value that associated with the
   *         hierarchy.
   *
   * 
   */
  static public DimensionMember getHierarchy (MetadataManagerServices metadataManagerServices,
                                  String strHierarchy, String strLabelType)
                                    throws MetadataManagerException {

    // Retrieve the MDHierarchy associated with this runtime ID
    MDHierarchy mdHierarchy =
      (MDHierarchy)metadataManagerServices.getMDObject (MM.UNIQUE_ID,
        strHierarchy, MM.HIERARCHY);

    return getDimensionMember (metadataManagerServices, mdHierarchy, strLabelType);
  }

  /**
   * Retrieves the list of hierarchy <code>DimensionMember</code> objects
   * associated with the specified dimension.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object
   *        from which to retrieve the dimensions.
   * @param strDimension a <code>String</code> ID value for the dimension that
   *        we need to retrieve the hierarchy <code>DimensionMember</code> for.
   * @param strLabelType a code>String</code> value which is one of the constants
   *        from <code>util.LayerMetadataMap</code> that describes a metadata
   *        label type such as short, long, or medium labels.
   * @param vHierarchies a <code>Vector</code> value used to store the
   *        <code>DimensionMember</code> objects associate with the dimension.
   *
   * @return A <code>boolean</code> value that is <code>true</code> when the
   *         operation is successful and <code>false</code> otherwise.
   *
   * 
   */
  static public boolean getHierarchies (MetadataManagerServices metadataManagerServices,
                                        String strDimension, String strLabelType,
                                        Vector vHierarchies) {
    int           nIndex          = -1;
    MDDimension   mdDimension     = null;
    MDHierarchy   mdHierarchy     = null;
    MDHierarchy[] mdHierarchyList = null;
    String        strHierId       = null;
    String        strHierDesc     = null;

    if (metadataManagerServices == null || strDimension == null  ||
        strLabelType == null || vHierarchies == null)
      return false;

    try {
      // Attempt to get the MDDimension object first..
      mdDimension =
        metadataManagerServices.getDimension (MM.UNIQUE_ID, strDimension);

      if (mdDimension == null)
        return false;
    }

    catch (Exception e) {
      return false;
    }

    try {
      mdHierarchyList = mdDimension.getHierarchies();
      if (mdHierarchyList == null)
        return false;
    }

    catch (Exception e) {
      return false;
    }

    for (nIndex = 0; nIndex < mdHierarchyList.length; nIndex++) {
      mdHierarchy = mdHierarchyList [nIndex];
      if (mdHierarchy == null)
        continue;

      DimensionMember dimensionMember = null;

      try {
        dimensionMember =
          getDimensionMember (metadataManagerServices, mdHierarchy, strLabelType);

        if (dimensionMember == null)
          continue;
      }

      catch (MetadataManagerException mme) {
        continue;
      }

      vHierarchies.addElement (dimensionMember);
    }

    return true;
  }

  /**
   * Retrieves the hierarchy for a label type from a specified metadataManagerServices
   * and gets the specified label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param strHierarchy The incoming hierarchy name.
   *
   * @return <code>DimensionMember</code> if the hierarchy label was retrieved
   * <code>null</code> if not.
   *
   * 
   */
  static public DimensionMember getHierarchyLabel ( MetadataManagerServices metadataManagerServices,
                                                    String srcLabelType,
                                                    String targetLabelType,
                                                    String strDimension,
                                                    String strHierarchy )
  {
      boolean bRetVal     = false;
      Vector  listHierSrc = null, listHierTarget = null;
      
      if ( null == metadataManagerServices || null == srcLabelType ||
           null == targetLabelType || null == strDimension || null == strHierarchy )
          return null;
      
      listHierSrc = new Vector ( );
      listHierSrc.addElement ( strHierarchy );
      
      listHierTarget = new Vector ( );

      bRetVal = getHierarchyLabels ( metadataManagerServices,
                                     srcLabelType, targetLabelType,
                                     strDimension, listHierSrc, listHierTarget );

      if ( bRetVal && 1 == listHierTarget.size ( ) )
          return ( DimensionMember ) listHierTarget.elementAt ( 0 );
      
      return null;
  }
  
  /**
   * Retrieves the hierarchy for a label type from a specified metadataManagerServices
   * and gets the specified label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param srcListHierarchies The list of incoming hierarchy names. Each name
   * is identified by the srcLabelType param.
   * @param targetListHierarchies The vector in which to store the hierarchy.
   * Each hierarchy is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the hiearchies were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */
  static public boolean getHierarchyLabels ( MetadataManagerServices metadataManagerServices, 
                                             String srcLabelType,
                                             String targetLabelType,
                                             String strDimension,
                                             Vector srcListHierarchies,
                                             Vector targetListHierarchies )
  {
      int             nIndex          = -1, nHierIndex = -1;
      MDDimension     mdDimension     = null;
      MDHierarchy     mdHierarchy     = null;
      MDHierarchy [ ] mdHierarchyList = null;
      String          strHierSrcId    = null, strCurHierLabel = null;
      String          strHierId = null, strHierDesc = null;
      
      if ( null == metadataManagerServices || null == srcLabelType ||
           null == targetLabelType || null == strDimension ||
           null == srcListHierarchies || null == targetListHierarchies )
          return false;

      // Attempt to get the MDDimension object first..
      try
      {
          mdDimension = metadataManagerServices.getDimension (
                                            MM.UNIQUE_ID, strDimension );
      }
      catch (MetadataManagerException mme)
      {
          mme.printStackTrace();
      }

      if ( null == mdDimension )
          return false;

      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          mdHierarchyList = mdDimension.getHierarchies ( );
          if ( mdHierarchyList == null )
              return false;
          }
        
      catch (Exception e)
          {
          return false;
          }            

      for ( nIndex = 0; nIndex < srcListHierarchies.size ( ); nIndex++ )
      {
          strHierSrcId = ( String ) srcListHierarchies.elementAt ( nIndex );

          for ( nHierIndex = 0; nHierIndex < mdHierarchyList.length; nHierIndex++ )
          {
              mdHierarchy = mdHierarchyList [ nHierIndex ];
              if ( mdHierarchy == null )
                  continue;

              strCurHierLabel = getMdObjectDesc ( mdHierarchy, srcLabelType );
              if ( null == strCurHierLabel )
                  continue;

              if ( strHierSrcId.equalsIgnoreCase ( strCurHierLabel ) )
              {
                  strHierId = new String ( getMdObjectDesc ( mdHierarchy,
                                           LayerMetadataMap.LAYER_METADATA_NAME ) );

                  strHierDesc = new String ( getMdObjectDesc (
                                             mdHierarchy, targetLabelType ) );

                  if ( strHierId.length () == 0 || strHierDesc.length () == 0 )
                      continue;

                  targetListHierarchies.addElement ( new DimensionMember (
                                                     strHierId, strHierDesc ) );

                  break;
              }                    
          }
      }

      return true;
  }

  /**
   * Retrieves the target label type for a specified level in a specified
   * dimension given the source label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the dimension and level.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param strDimension The name of the dimension containing the specified level.
   * @param strLevel The name of the level.
   *
   * @return <code>DimensionMember</code> if the level label was retrieved
   * <code>null</code> if not.
   *
   * 
   */
  static public DimensionMember getLevelLabel ( MetadataManagerServices metadataManagerServices, 
                                                String srcLabelType,
                                                String targetLabelType, 
                                                String strDimension, 
                                                String strLevel )
  {
      boolean bRetVal         = false;
      Vector  listLevelSrc    = null, listLevelTarget = null;

      if ( null == metadataManagerServices || 
           null == srcLabelType || null == targetLabelType ||
           null == strDimension || null == strLevel )
          return null;
      
      listLevelSrc = new Vector ( );
      listLevelSrc.addElement ( strLevel );
      
      listLevelTarget = new Vector ( );

      bRetVal = getLevelLabels ( metadataManagerServices,  
                                 srcLabelType, targetLabelType,
                                 strDimension, listLevelSrc, listLevelTarget );
                                 
      if ( bRetVal && 1 == listLevelTarget.size ( ) )
          return ( DimensionMember ) listLevelTarget.elementAt ( 0 );
      
      return null;
  }

  /**
   * Retrieves the target label type for a list of levels in a specified
   * dimension given the source label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param strDimension The specified dimension containing the levels.
   * @param srcListLevels The list of incoming level names.
   * @param targetListLevels The vector in which to store the level labels.
   * Each level label is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the level labels were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */
  static public boolean getLevelLabels ( MetadataManagerServices metadataManagerServices, 
                                         String srcLabelType, String targetLabelType,
                                         String strDimension,
                                         Vector srcListLevels, Vector targetListLevels )
  {
      int             nIndex              = -1, nLevelIndex = -1;
      MDDimension     mdDimension         = null;
      MDLevel         mdLevel             = null;
      MDLevel [ ]     mdLevelList         = null;
      String          strLevelSrcLabel    = null, strLevelTargetLabel = null;
      String          strCurLevelLabel    = null, strLevelTargetId = null;

      if ( null == metadataManagerServices ||
           null == srcLabelType || null == srcLabelType ||
           null == strDimension ||
           null == srcListLevels || null == targetListLevels )
          return false;

      // Attempt to get the MDDimension object first..
      try
      {
          mdDimension = metadataManagerServices.getDimension (
                                            MM.UNIQUE_ID, strDimension );
      }
      catch (MetadataManagerException mme)
      {
          mme.printStackTrace();
      }
                                            
      if ( null == mdDimension )
          return false;

      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          //mdLevelList = mdDimension.getLevels ( );
          mdLevelList = getDimensionLevels ( mdDimension );
          if ( mdLevelList == null )
              return false;
          }
        
      catch (Exception e)
          {
          return false;
          }            

      for ( nIndex = 0; nIndex < srcListLevels.size ( ); nIndex++ )
      {
          strLevelSrcLabel = ( String ) srcListLevels.elementAt ( nIndex );

          for ( nLevelIndex = 0; nLevelIndex < mdLevelList.length; nLevelIndex++ )
          {
              mdLevel = mdLevelList [ nLevelIndex ];
              if ( null == mdLevel )
                  continue;

              strCurLevelLabel = getMdObjectDesc ( mdLevel, srcLabelType );
              if ( null == strCurLevelLabel )
                  continue;

              if ( strLevelSrcLabel.equalsIgnoreCase ( strCurLevelLabel ) )
              {
                  strLevelTargetId = getMdObjectDesc ( mdLevel, LayerMetadataMap.LAYER_METADATA_NAME );
                  strLevelTargetLabel = getMdObjectDesc ( mdLevel, targetLabelType );

                  if ( null == strLevelTargetId || null == strLevelTargetLabel )
                      continue;

                  targetListLevels.addElement ( new DimensionMember (
                                                new String ( strLevelTargetId ),
                                                new String ( strLevelTargetLabel ) ) );
                  break;
              }
          }
      }

      return true;
  }

  /**
   * Retrieves the levels for a dimension from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the measures.
   * @param strDimension The dimension name for which to retrieve the label for.
   * @param labelType The speciifed label type.
   * @param listLevels The vector in which to store the level objects.
   * Each level is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the levels
   * were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */

  /* gek 02/23/01 Levels are now only associated with hierarchies, not levels
  static public boolean getLevels ( MetadataManagerServices metadataManagerServices,
                                    String strDimension,
                                    String labelType,
                                    Vector listLevels )
  {
      int         nIndex      = -1;
      String      strLevelId  = null, strLevelDesc = null;
      MDDimension mdDimension = null;
      MDLevel     mdLevel     = null;
      MDLevel [ ] mdLevelList = null;

      if ( metadataManagerServices == null || strDimension == null ||
           labelType == null || listLevels == null )
           return false;

      // Attempt to get the MDDimension object first..
      try
      {
          mdDimension = metadataManagerServices.getDimension (
                                            MM.UNIQUE_ID, strDimension );
      }
      catch (MetadataManagerException mme)
      {
          mme.printStackTrace();
      }

      if ( null == mdDimension )
          return false;

      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          //mdLevelList = mdDimension.getLevels ( );
          // TODO - This is temporary and should be removed.
          mdLevelList = getDimensionLevels ( mdDimension );
          if ( mdLevelList == null )
              return false;
          }

      catch (Exception e)
          {
          return false;
          }

      for ( nIndex = 0; nIndex < mdLevelList.length; nIndex++ )
      {
          mdLevel = mdLevelList [ nIndex ];
          if ( mdLevel == null )
              continue;

          strLevelId = new String ( getMdObjectDesc ( mdLevel,
                                    LayerMetadataMap.LAYER_METADATA_NAME ) );

          strLevelDesc = new String ( getMdObjectDesc ( mdLevel, labelType ) );

          if ( strLevelId.length ( ) == 0 || strLevelDesc.length () == 0 )
               continue;

          listLevels.addElement ( new DimensionMember ( strLevelId, strLevelDesc ) );
      }

      return true;
  }
  */

  /**
   * Retrieves the levels for a dimension from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code>
   * object from which to retrieve the measures.
   * @param strHierarchy The hierarchy name for which to retrieve the levels for.
   * @param labelType The specifed label type.
   * @param listLevels The vector in which to store the level objects.
   * Each level is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the levels
   * were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */
  /*
  // gek 02/23/01 For now, this is not needed.  In general, we will want to
  //              use the getLevels() method which takes both the dimension AND
  //              hierarchy since we going forward, we will be using Olapi's
  //              strict option which always requires a valid dimension/hierachy
  //              combination.
  static public boolean getLevels (MetadataManagerServices metadataManagerServices,
                                   String strHierarchy,
                                   String labelType,
                                   Vector listLevels)
      {
      int             nIndex          = -1;
      MDHierarchy     mdHierarchy     = null;
      MDLevel         mdLevel         = null;
      MDLevel [ ]     mdLevelList     = null;
      String          strCurHierLabel = null;
      String          strLevelId      = null, strLevelDesc = null;

      if (metadataManagerServices == null ||
          strHierarchy == null            ||
          labelType == null               ||
          listLevels == null )
          return false;

      try
          {
          mdHierarchy =
              metadataManagerServices.getHierarchy (MM.UNIQUE_ID, strHierarchy);

          if (mdHierarchy == null)
              return false;
          }

      catch (Exception e)
          {
          return false;
          }

      try
          {
          mdLevelList = mdHierarchy.getLevels ();
          if (mdLevelList == null)
              return false;
          }

      catch (Exception e)
          {
          return false;
          }

      for (nIndex = 0; nIndex < mdLevelList.length; nIndex++)
          {
          mdLevel = mdLevelList [ nIndex ];
          if (mdLevel == null)
              continue;

          strLevelId = new String (getMdObjectDesc (mdLevel,
                                   LayerMetadataMap.LAYER_METADATA_NAME));

          strLevelDesc = new String (getMdObjectDesc (mdLevel, labelType));

          if (strLevelId.length () == 0 || strLevelDesc.length () == 0)
               continue;

          listLevels.addElement (new DimensionMember (strLevelId, strLevelDesc));
          }

      return true;
      }
  */

  /**
   * Retrieves the levels for a dimension from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code>
   * object from which to retrieve the measures.
   * @param strDimension The dimension name for which to retrieve the label for.
   * @param strHierarchy The hierarchy name for which to retrieve the label for.
   * @param labelType The specifed label type.
   * @param listLevels The vector in which to store the level objects.
   * Each level is stored as a <code>DimensionMember</code> object.
   *
   * @return <code>true</code> if the levels
   * were retrieved and stored successfully;
   * <code>false</code> if they were not.
   *
   * 
   */
  static public boolean getLevels (MetadataManagerServices metadataManagerServices,
                                   String strDimension,
                                   String strHierarchy,
                                   String labelType,
                                   Vector listLevels)
      {
      int             nIndex          = -1;
      MDDimension     mdDimension     = null;
      MDHierarchy     mdCurHierarchy  = null;
      MDHierarchy     mdHierarchy     = null;
      MDHierarchy[]   mdHierarchyList = null;
      MDLevel         mdLevel         = null;
      MDLevel[]       mdLevelList     = null;
      String          strCurHierLabel = null;
      String          strLevelId      = null;
      String          strLevelDesc    = null;

      if (metadataManagerServices == null || strDimension == null ||
           strHierarchy == null || labelType == null || listLevels == null)
           return false;

      // Attempt to get the MDDimension object first
      try
          {
          mdDimension =
              metadataManagerServices.getDimension (MM.UNIQUE_ID, strDimension);
          }

      catch (MetadataManagerException mme)
          {
          mme.printStackTrace();
          }

      if (mdDimension == null)
          return false;

      try
          {
          // Retrieve the hierarchies associated with the dimension
          mdHierarchyList = mdDimension.getHierarchies ();
          if (mdHierarchyList == null)
              return false;
          }

      catch (Exception e)
          {
          return false;
          }

      // Attempt to get the specified MDHierarchy object
      for (nIndex = 0; nIndex < mdHierarchyList.length; nIndex++)
          {
          mdCurHierarchy = mdHierarchyList [ nIndex ];

          if (mdCurHierarchy == null)
              continue;

          strCurHierLabel =
              getMdObjectDesc (mdCurHierarchy, LayerMetadataMap.LAYER_METADATA_NAME);

          if (strHierarchy.equalsIgnoreCase (strCurHierLabel))
              {
              mdHierarchy = mdCurHierarchy;
              break;
              }
          }

      if (mdHierarchy == null)
          return false;

      try
          {
          // Retrive the levels associated with this hierarchy
          mdLevelList = mdHierarchy.getLevels ();
          if (mdLevelList == null)
              return false;
          }

      catch (Exception e)
          {
          return false;
          }

      for (nIndex = 0; nIndex < mdLevelList.length; nIndex++)
          {
          mdLevel = mdLevelList [nIndex];
          if (mdLevel == null)
              continue;

          strLevelId = new String (getMdObjectDesc (mdLevel,
                                   LayerMetadataMap.LAYER_METADATA_NAME));

          strLevelDesc = new String (getMdObjectDesc (mdLevel, labelType));

          if (strLevelId.length () == 0 || strLevelDesc.length () == 0)
               continue;

          listLevels.addElement ( new DimensionMember ( strLevelId, strLevelDesc ) );
          }

      return true;
      }

 /**
   * Retrieves the appropriate label for a specified <code>MetadataManager</code> 
   * object based on a specified metadata type.
   *
   * @param mdObject a <code>MDObject</code> whose label is to be retrieved.
   * @param strType a <code>String</code> that represents the type label to 
   *        retrieve.
   * 
   * The valid constants are:
   * <ul>
   * <li><code>LAYER_METADATA_LONGLABEL</code></li>
   * <li><code>LAYER_METADATA_NAME</code></li>
   * <li><code>LAYER_METADATA_SHORTLABEL</code></li>
   * <li><code>METADATA_LONGLABEL</code></li>
   * <li><code>METADATA_SHORTLABEL</code></li>
   * <li><code>METADATA_MEDIUMLABEL</code></li>
   * <li><code>METADATA_VALUE</code></li>
   * </ul>
   *
   *
   * @return <code>String</code> which represents the label based on
   *         label type associated with the <code>MDObject</code>.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   *
   * @see oracle.dss.util.MetadataMap#METADATA_LONGLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_SHORTLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_MEDIUMLABEL
   * @see oracle.dss.util.MetadataMap#METADATA_VALUE
   *
   * 
   */
  static public String getMdObjectDesc (MDObject mdObject, String strType) {
    if (mdObject == null)
      return null;

    if (strType == null)
      strType = LayerMetadataMap.LAYER_METADATA_LONGLABEL;

    if (strType.equalsIgnoreCase (LayerMetadataMap.LAYER_METADATA_NAME) ||
        strType.equalsIgnoreCase (MetadataMap.METADATA_VALUE)) {
      return mdObject.getUniqueID();
    }
    else if (strType.equalsIgnoreCase (LayerMetadataMap.LAYER_METADATA_SHORTLABEL) ||
             strType.equalsIgnoreCase (MetadataMap.METADATA_SHORTLABEL)) {
      return mdObject.getShortLabel();
    }
    else if (strType.equalsIgnoreCase (LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL) || 
             strType.equalsIgnoreCase (MetadataMap.METADATA_MEDIUMLABEL)){
      return mdObject.getMediumLabel();
    }
    else if (strType.equalsIgnoreCase (LayerMetadataMap.LAYER_METADATA_LONGLABEL) ||
             strType.equalsIgnoreCase (MetadataMap.METADATA_LONGLABEL)) {
      return mdObject.getLongLabel();
    }

    return null;
  }
      
  /**
   * Retrieves the description and name of the
   * measure dimension in a specified metadataManagerServices and stores them in a
   * <code>DimensionMember</code> object.
   *
   * @param dbName The name of the database containing the measures dimension
   * to retrieve
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the description and name of the measure dimension.
   * @param labelType The label type
   *
   * @return The <code>DimensionMember</code> object.
   *
   * 
   */
  static public DimensionMember getMeasureDimension ( String dbName,
                                                      MetadataManagerServices metadataManagerServices,
                                                      String labelType )
  {
      MDDimension measDimension   = null;
      String      strMeasureId    = null, strMeasureLabel = null;

      if ( metadataManagerServices == null || labelType == null )
          return null;

      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          // Ask the metadataManagerServices for the measure dimension
          measDimension = metadataManagerServices.getMeasureDimension ( dbName );
          if ( null == measDimension )
              return null;
          }
      
      catch (Exception e)
          {
          return null;
          }

      strMeasureId = getMdObjectDesc ( measDimension,
                                       LayerMetadataMap.LAYER_METADATA_NAME );
      strMeasureLabel = getMdObjectDesc ( measDimension, labelType );

      if ( null == strMeasureId || 0 == strMeasureId.length ( ) ||
           null == strMeasureLabel || 0 == strMeasureLabel.length ( ) )
           return null;
      
      return new DimensionMember ( new String ( strMeasureId ),
                                   new String ( strMeasureLabel ) );          
  }    
  
  /**
   * Retrieves the measures for a label type from a specified metadataManagerServices
   * and gets the specified label type.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
   * the measures.
   * @param srcLabelType The source label type.
   * @param targetLabelType The target label type.
   * @param srcMeasure The incoming measure name. 
   *
   * @return <code>DimensionMember</code> if the dimensions label was retrieved
   * <code>null</code> if not.
   *
   * 
   */
  static public DimensionMember getMeasureLabel ( MetadataManagerServices metadataManagerServices, 
                                                  String srcLabelType,
                                                  String targetLabelType,
                                                  String strMeasure )
  {
      boolean bRetVal     = false;
      Vector  listMeasSrc  = null, listMeasTarget = null;
      
      if ( null == metadataManagerServices || null == srcLabelType ||
           null == targetLabelType || null == strMeasure )
          return null;
      
      listMeasSrc = new Vector ( );
      listMeasSrc.addElement ( strMeasure );
      
      listMeasTarget = new Vector ( );

      bRetVal = getMeasuresLabel ( metadataManagerServices,
                                   srcLabelType, targetLabelType,
                                   listMeasSrc, listMeasTarget );
                                   
      if ( bRetVal && 1 == listMeasTarget.size ( ) )
          return ( DimensionMember ) listMeasTarget.elementAt ( 0 );
      
      return null;
  }

  /**
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param nCount a <code>int</code> representing the maximum number of measures
   *        to retrieve.  A value of -1 implies all measures.
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   *
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @return <code>List</code> of <code>DimensionMember</code> objects. 
   *
   * 
   */
  static public List getMeasures (int nCount, 
    MetadataManagerServices metadataManagerServices, String strLabelType) {

    Vector vMeasures = new Vector();
    boolean bResult = 
      getMeasures (nCount, metadataManagerServices, strLabelType, vMeasures);
    return vMeasures;    
  }

  /**
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param nCount a <code>int</code> representing the maximum number of measures
   *        to retrieve.  A value of -1 implies all measures.
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   * 
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @param vMeasures a <code>Vector</code> of <code>DimensionMember</code> objects.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measures 
   *         were retrieved successfully and <code>false</code> otherwise.
   *
   * 
   */
  static public boolean getMeasures (int nCount, MetadataManagerServices metadataManagerServices,
                                     String strLabelType, Vector vMeasures) {
    return DataUtils.getMeasures(nCount, metadataManagerServices, strLabelType, vMeasures, null, false);
  }

  /**
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.  
   *
   * @param nCount a <code>int</code> representing the maximum number of measures
   *        to retrieve.  A value of -1 implies all measures.
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   * @param vMeasures a <code>Vector</code> of <code>DimensionMember</code> objects.
   * @param strDimension the dimension id of a dimension to use to filter measures.  This is specifically
   *  used to filter measures based on the selected time dimension in CalcBuilder. 
   * @param bNumericMeasuresOnly if true, then only numeric measures are returned. 
   * 
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @return <code>boolean</code> which is <code>true</code> if the measures 
   *         were retrieved successfully and <code>false</code> otherwise.
   *
   * 
   */
  static public boolean getMeasures (int nCount, MetadataManagerServices metadataManagerServices,
    String strLabelType, Vector vMeasures, String strDimension, boolean bNumericMeasuresOnly) {
    String      strMeasureID          = null;
    String      strMeasureDescription = null;
    MDMeasure   mdMeasure             = null;
    MDMeasure[] mdMeasureList         = null;

    if (metadataManagerServices == null || strLabelType == null || vMeasures == null)
      return false;

    try {
      mdMeasureList = metadataManagerServices.getMeasures();
      if (mdMeasureList == null)
        return false;
    } catch (Exception e) {
      return false;
    }

    int nMeasures = mdMeasureList.length;
    int nMax = (nCount == -1) ? nMeasures : Math.min (nMeasures, nCount);
    int nMeasureCount = 0;
    for (int nIndex = 0; (nIndex<nMeasures) && (nMeasureCount<nMax); nIndex++) {
      mdMeasure = mdMeasureList [nIndex];
      if (mdMeasure == null)
        continue;        

      // check if the measure is numeric
      if(bNumericMeasuresOnly && ( mdMeasure.getDataType().equals(MM.BOOLEAN) ||
                                   mdMeasure.getDataType().equals(MM.DATE) ||
                                   mdMeasure.getDataType().equals(MM.STRING) ))
        continue;                                     

      // check if the measure is dimensioned by another dimension
      if( (strDimension!=null) && (!DataUtils.isDimensionedBy(mdMeasure,strDimension)) )
        continue;

      // gek 02/12/04 Fix Bug 3425747: Calc Builder does not respect MDObject
      //              "HIDDEN" property.
      //
      //              mdMeasure.setStrPropertyValue (MM.HIDDEN, MM.HIDE_ALWAYS);
      //
      //              Skip over hidden measures
      if (MM.HIDE_ALWAYS.equals (mdMeasure.getStrPropertyValue (MM.HIDDEN))) 
        continue;

      strMeasureID = 
        new String (getMdObjectDesc (mdMeasure, LayerMetadataMap.LAYER_METADATA_NAME));

      strMeasureDescription = 
        new String (getMdObjectDesc (mdMeasure, strLabelType));

      if (strMeasureID.length() == 0 || strMeasureDescription.length() == 0)
          continue;

      vMeasures.addElement (new DimensionMember (strMeasureID, strMeasureDescription));
      nMeasureCount++; // only bump the count if we add it to the list 
    }

    return true;
  }

  /**
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   * 
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @param vMeasures a <code>Vector</code> of <code>DimensionMember</code> objects.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measures 
   *         were retrieved successfully and <code>false</code> otherwise.
   *
   * 
   */
  static public boolean getMeasures (MetadataManagerServices metadataManagerServices,
                                     String strLabelType, Vector vMeasures) {

    return getMeasures (-1, metadataManagerServices, strLabelType, vMeasures);
  }

  /**
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   * 
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @param vMeasures a <code>Vector</code> of <code>DimensionMember</code> objects.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measures 
   *         were retrieved successfully and <code>false</code> otherwise.
   *
   * 
   */
  static public boolean getMeasuresDimensionMembers (MetadataManagerServices metadataManagerServices,
                                     String strLabelType, Vector vMeasures) {

    return getMeasures (-1, metadataManagerServices, strLabelType, vMeasures);
  }

  /**
   * @internal
   * 
   * Retrieves the measures from a specified metadataManagerServices
   * and stores them as a flat list.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code> object 
   *        from which to retrieve the measures.
   * @param strLabelType a <code>String</code> representing the label type.
   * 
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_LONGLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_NAME
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_SHORTLABEL
   * @see oracle.dss.util.LayerMetadataMap#LAYER_METADATA_MEDIUMLABEL
   * 
   * @param vMeasures a <code>Vector</code> of <code>MDMeasure</code> objects.
   *
   * @return <code>boolean</code> which is <code>true</code> if the measures 
   *         were retrieved successfully and <code>false</code> otherwise.
   *
   * 
   */
  static public List getMeasuresDimensionMembers (MetadataManagerServices metadataManagerServices,
      String strLabelType, List listMeasures) throws MetadataManagerException {

    String  strMeasureID          = null;
    String  strMeasureDescription = null;
    Vector  vDimensionMembers     = null;

    if (metadataManagerServices == null || strLabelType == null || 
        listMeasures == null || listMeasures.isEmpty())
      return null;

    vDimensionMembers = new Vector();
    MDMeasure mdMeasure = null;

    for (int nIndex = 0; nIndex < listMeasures.size(); nIndex++) {
      mdMeasure = (MDMeasure) listMeasures.get (nIndex);
      if (mdMeasure == null)
          continue;

      strMeasureID = 
        new String (getMdObjectDesc (mdMeasure, LayerMetadataMap.LAYER_METADATA_NAME));

      strMeasureDescription = 
        new String (getMdObjectDesc (mdMeasure, strLabelType));
      
      if (strMeasureID != null && strMeasureDescription != null) { 
        vDimensionMembers.addElement (new DimensionMember (strMeasureID, strMeasureDescription));
      }
    }

    return vDimensionMembers;
  }

/**
 * @internal
 * 
 * Retrieves the measures for a label type from a specified metadataManagerServices
 * and retrives the specified label type.
 *
 * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
 * the measures.
 * @param srcLabelType The source label type.
 * @param targetLabelType The target label type.
 * @param srcListMeasures The list of incoming measures names.
 * @param targetListMeasures The vector in which to store the measures labels.
 * Each measure label is stored as a <code>DimensionMember</code> object.
 *
 * @return <code>true</code> if the measures labels were retrieved and stored successfully;
 * <code>false</code> if they were not.
 *
 * 
 */
static public boolean getMeasuresLabel (MetadataManagerServices metadataManagerServices,
  String srcLabelType, String targetLabelType, Vector srcListMeasures, Vector targetListMeasures) {

  return getMeasuresLabel (metadataManagerServices, srcLabelType, targetLabelType, 
    srcListMeasures, targetListMeasures, null);
}

/**
 * @internal
 * 
 * Retrieves the measures for a label type from a specified metadataManagerServices
 * and retrives the specified label type.
 *
 * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to retrieve
 * the measures.
 * @param srcLabelType The source label type.
 * @param targetLabelType The target label type.
 * @param srcListMeasures The list of incoming measures names.
 * @param targetListMeasures The vector in which to store the measures labels.
 * Each measure label is stored as a <code>DimensionMember</code> object.
 *
 * @return <code>true</code> if the measures labels were retrieved and stored successfully;
 * <code>false</code> if they were not.
 *
 * 
 */
static public boolean getMeasuresLabel (MetadataManagerServices metadataManagerServices,
  String srcLabelType, String targetLabelType, Vector srcListMeasures, Vector targetListMeasures, 
  ErrorHandler errorHandler) {

  int nIndex = -1;
  String strMeasSrcId = null;
  String strMeasTargetId = null;
  MDMeasure mdMeasure = null;

  if (metadataManagerServices == null || srcLabelType  == null ||
      srcLabelType  == null || srcListMeasures  == null ||
      targetListMeasures == null)
    return false;

  for (nIndex = 0; nIndex < srcListMeasures.size(); nIndex++) {
    strMeasSrcId = (String) srcListMeasures.elementAt (nIndex);
    if (strMeasSrcId == null)
      continue;

    try {
      mdMeasure = 
        metadataManagerServices.getMeasure (mapToMetadataManagerId (srcLabelType),
          strMeasSrcId );
    }
    
    catch (MetadataManagerException metadataManagerException) {
      if (errorHandler != null) {
        errorHandler.log (metadataManagerException.getMessage(), 
          "oracle.dss.datautil.DataUtils", 
            "getMeasuresLabel (MetadataManagerServices, String, String, Vector, Vector, ErrorHandler)");
      }
    }
      
    if (mdMeasure == null)
      continue;
        
    strMeasTargetId = 
      new String (getMdObjectDesc (mdMeasure, targetLabelType));
    
    if (strMeasTargetId == null || strMeasTargetId.length() == 0) 
      continue;
    
    targetListMeasures.addElement (
      new DimensionMember (strMeasSrcId, strMeasTargetId));
  }
  
  return true;
}

  /**
   * Indicates whether a specifed measure is the measure dimension for
   * a specified metadataManagerServices.
   *
   * @param dbName The name of the database containing the measures dimension
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object.
   * @param strTestMeasDim The label to test for.
   *
   * @return <code>true</code> if the measure is the measure dimension
   * for the specified metadataManagerServices;
   * <code>false</code> if it is not.
   *
   * 
   */
  public static boolean isMeasureDimension ( String dbName,
                                             MetadataManagerServices metadataManagerServices, 
                                             String strTestMeasDim )
  {
      String      strMeasDim      = null;
      boolean     bRetVal         = false;
      MDDimension measDimension   = null;
      
      if ( metadataManagerServices == null        || 
           strTestMeasDim  == null ||
           strTestMeasDim.length() == 0 )
      {
          return false;
      }
      
      // gek 01/17/01 Handle MetadataManager exception
      try
          {
          // Ask the metadataManagerServices for the measure dimension
          measDimension = metadataManagerServices.getMeasureDimension ( dbName );
          if ( null == measDimension )
              return false;
          }
      
      catch (Exception e)
          {
          return false;
          }

      strMeasDim = new String ( );
      strMeasDim = measDimension.getUniqueID ( );

      // Be pessimistic at first.
      bRetVal = false;
      if ( strMeasDim.equalsIgnoreCase ( strTestMeasDim ) )
          bRetVal = true;

      return bRetVal;
  }

  /**
   * Indicates whether the measure is dimensioned by the
   * the specified dimension specified metadataManagerServices.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object.
   * @param strMeasure The measure to test for dimensionality
   * @param strDimension The dimension to test the measure against
   *
   * @return <code>true</code> if the measure is dimensioned by the dimension
   * for the specified metadataManagerServices;
   * <code>false</code> if it is not.
   *
   * 
   */
  public static boolean isDimensionedBy (MetadataManagerServices metadataManagerServices,
                                         String strMeasure,
                                         String strDimension) {
    MDDimension   mdDimension   = null;
    MDDimension[] mdDimensions  = null;
    MDMeasure     mdMeasure     = null;
    int           nIndex        = -1;
    String        strCompare    = null;

    // Check for null parameters
    if (metadataManagerServices == null || strMeasure == null ||
        strDimension == null)
      return false;

    // Attempt to retrieve the MDMeasure associated with the specfied ID
    try {
      mdMeasure = metadataManagerServices.getMeasure (MM.UNIQUE_ID, strMeasure);
    }

    catch (MetadataManagerException mme) {
      mme.printStackTrace();
    }

    return DataUtils.isDimensionedBy(mdMeasure, strDimension);
  }

  /**
   * Indicates whether the measure is dimensioned by the
   * the specified dimension
   *
   * @param MDMeasure The measure to test for dimensionality
   * @param strDimension The dimension to test the measure against
   *
   * @return <code>true</code> if the measure is dimensioned by the dimension
   * <code>false</code> if it is not.
   *
   * 
   */
  public static boolean isDimensionedBy (MDMeasure mdMeasure,
                                         String strDimension) {
    MDDimension   mdDimension   = null;
    MDDimension[] mdDimensions  = null;
    int           nIndex        = -1;
    String        strCompare    = null;

    // Check for null parameters
    if (mdMeasure == null)
      return false;

    // Retrieve the dimensions associated with the measure
    try {
      mdDimensions = DataUtils.getDimensions (mdMeasure);
      if (mdDimensions == null)
        return false;
    }

    // If we can't retrieve the dimensions, return false
    catch (Exception e) {
      return false;
    }

    // Iterate over each dimension looking for the one specified
    for (nIndex = 0; nIndex < mdDimensions.length; nIndex++) {
      // Retrieve the current dimension
      mdDimension = mdDimensions [nIndex];

      // Determine if this is the dimension we are looking for
      strCompare =
        getMdObjectDesc (mdDimension, LayerMetadataMap.LAYER_METADATA_NAME);

      // If we have found it, return true
      if (strDimension.equalsIgnoreCase (strCompare))
        return true;
    }

    // We haven't found the specified dimension, so we should return false
    return false;
  }


  /**
   * Indicates whether the dimensions that a measure is dimensioned by is a
   * proper subset of the specified dimension list.
   *
   * The measure's dimensionality is a proper subset of the dimension list
   * if every dimension in the measure is found in the dimension list even though
   * it may contain additional dimensions.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> value
   *                                which is used to retrieve metadata.
   * @param strMeasure A <code>String</code> value which represents the measure
   *                   whose dimensionality we wish to check.
   * @param vstrDimensions A <code>Vector</code> of <code>String</code> objects
   *                       which contains a list of dimensions to test the
   *                       measure against.
   *
   * @return <code>true</code> if the measure is dimensioned by a proper subset
   * of the dimensions specified; <code>false</code> if it is not.
   *
   * @throws <code>MetadataManagerException</code> if metadata cannot be retrieved.
   *
   * 
   */
  public static boolean isDimensionedBy (MetadataManagerServices metadataManagerServices,
                                         String strMeasure, Vector vstrDimensions)
                                         throws MetadataManagerException {
    MDDimension   mdDimension         = null;
    MDDimension[] mdDimensions        = null;
    MDMeasure     mdMeasure           = null;
    String        strDimensionMeasure = null;

    // Check for null parameters
    if (metadataManagerServices == null || strMeasure == null ||
        vstrDimensions == null)
      return false;

    // Attempt to retrieve the MDMeasure associated with the specfied ID
    mdMeasure = metadataManagerServices.getMeasure (MM.UNIQUE_ID, strMeasure);

    // If we can't retrieve measure, return false
    if (mdMeasure == null)
      return false;

    // Retrieve the dimensions associated with the measure
    mdDimensions = DataUtils.getDimensions (mdMeasure);

    if (mdDimensions != null) {
      // Iterate over each dimension in the measure
      for (int nIndex = 0; nIndex < mdDimensions.length; nIndex++) {
        // Retrieve the current dimension
        mdDimension = mdDimensions [nIndex];

        // Determine if this is the dimension we are looking for
        strDimensionMeasure =
          getMdObjectDesc (mdDimension, LayerMetadataMap.LAYER_METADATA_NAME);

        // Initialize to not found
        boolean bFound = false;

        // Iterate over all of the superset dimensions
        for (int nDimension = 0; nDimension < vstrDimensions.size(); nDimension++) {
          // If we have found it, return true
          String strDimension = (String) vstrDimensions.elementAt(nDimension);

          if (strDimension.equalsIgnoreCase (strDimensionMeasure)) {
            bFound = true;
            break;
          }
        }

        // If we haven't found the dimension, return false
        if (!bFound)
          return false;
      }
    }
    else {
      return false;
    }

    // The dimensions that the measure is dimensioned by is a proper subset
    // of the specified dimensions.
    return true;
  }

  /**
   * Retrieves a superset of all dimensions referenced by the specified
   * measure list without duplicates.
   *
   * @param metadataManagerServices A <code>MetadataManagerServices</code> value
   *                                which is used to retrieve metadata.
   * @param vstrMeasures A <code>Vector</code> of <code>String</code> values
   *                     which represents the measure whose dimensionality we
   *                     return.
   *
   * @return <code>Vector</code> of <code>String</code> values which represents a
   *         list of dimensions associated with the specified measures.
   *
   * @throws <code>MetadataManagerException</code> if metadata cannot be retrieved.
   *
   * 
   */
  public static Vector getDimensions (MetadataManagerServices metadataManagerServices,
                                      Vector vstrMeasures)
                                         throws MetadataManagerException {

    MDDimension   mdDimension         = null;
    MDDimension[] mdDimensions        = null;
    MDMeasure     mdMeasure           = null;
    Vector        vstrDimensions      = new Vector();

    // Check for null parameters
    if ((metadataManagerServices == null) || (vstrMeasures == null))
      return vstrDimensions;

    for (int nIndex = 0; nIndex < vstrMeasures.size(); nIndex++) {
      // Attempt to retrieve the MDMeasure associated with the specfied ID
      mdMeasure =
        metadataManagerServices.getMeasure (MM.UNIQUE_ID, (String) vstrMeasures.elementAt (nIndex));

      // Retrieve the dimensions associated with the measure
      mdDimensions = DataUtils.getDimensions (mdMeasure);

      // Iterate over each dimension in the measure
      for (int nDimension = 0; nDimension < mdDimensions.length; nDimension++) {
        // Retrieve the current dimension
        mdDimension = mdDimensions [nDimension];

        // Retrieve the dimensions's name
        String strDimension =
          getMdObjectDesc (mdDimension, LayerMetadataMap.LAYER_METADATA_NAME);

        // Add the dimension to the list, if it doesn't already exist
        if (strDimension != null) {
          boolean bFound = false;

          // Iterate over the current dimension list
          for (int nPosition = 0; nPosition < vstrDimensions.size(); nPosition++) {
            if (strDimension.equals (vstrDimensions.elementAt (nPosition))) {
              bFound = true;
              break;
            }
          }

          // If we haven't found it yet, add it to the list
          if (!bFound) {
            vstrDimensions.addElement (strDimension);
          }
        }
      }
    }

    // Return the dimensions associated with the specified measures
    return vstrDimensions;
  }

  /**
   * Converts the label types into MetadataManager constants.
   *
   * 
   */
  static public String mapToMetadataManagerId ( String strLabelType )
  {
      // Default to the long label
      if ( null == strLabelType )
          return MM.LONG_LABEL;

      if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_NAME ) )
      {
          return MM.UNIQUE_ID;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_LONGLABEL ) )
      {
          return MM.LONG_LABEL;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL ) )
      {
          return MM.MEDIUM_LABEL;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_SHORTLABEL ) )
      {
          return MM.SHORT_LABEL;
      }
      else if (strLabelType.equalsIgnoreCase(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME))
          return MM.OBJECT_NAME;
      
      // For all other cases assume long label
      return MM.LONG_LABEL;
  }
  
  /**
   * Converts the label types into MetadataManager constants.
   *
   * @param strLabelType The specified layer metadate type.
   *
   * 
   */
  static public String mapToMetadataMapType ( String strLabelType )
  {
      if ( null == strLabelType )
          return MetadataMap.METADATA_LONGLABEL;

      if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_NAME ) )
      {
          return MetadataMap.METADATA_VALUE;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_LONGLABEL ) )
      {
          return MetadataMap.METADATA_LONGLABEL;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL ) )
      {
          return MetadataMap.METADATA_MEDIUMLABEL;
      }
      else if ( strLabelType.equalsIgnoreCase ( LayerMetadataMap.LAYER_METADATA_SHORTLABEL ) )
      {
          return MetadataMap.METADATA_SHORTLABEL;
      }

      // For all other cases assume long label
      return MetadataMap.METADATA_LONGLABEL;
  }

  /**
   * Converts the label types into MetadataManager constants.
   *
   * @param strLabelType The specified layer metadate type.
   *
   * 
   */
  static public String mapMetadataManagerIdToLayerMetadataMapType ( String strMetadataManagerId )
  {
      if ( null == strMetadataManagerId )
          return LayerMetadataMap.LAYER_METADATA_LONGLABEL;

      if ( strMetadataManagerId.equalsIgnoreCase ( MM.UNIQUE_ID ) )
      {
          return LayerMetadataMap.LAYER_METADATA_NAME;
      }
      else if ( strMetadataManagerId.equalsIgnoreCase ( MM.LONG_LABEL ) )
      {
          return LayerMetadataMap.LAYER_METADATA_LONGLABEL;
      }
      else if ( strMetadataManagerId.equalsIgnoreCase ( MM.MEDIUM_LABEL ) )
      {
          return LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL;
      }
      else if ( strMetadataManagerId.equalsIgnoreCase ( MM.SHORT_LABEL ) )
      {
          return LayerMetadataMap.LAYER_METADATA_SHORTLABEL;
      }

      // For all other cases assume long label
      return LayerMetadataMap.LAYER_METADATA_LONGLABEL;
  }

  /**
   *  Changes focus to first selected row in <code>JTree</code>.
   *
   *  If there are no rows selected, it defaults to the first available.
   *
   *  @param  jTree a <code>JTree</code> value that represents the
   *          component whose focus we are trying to set.
   *  @param  focusEvent a <code>FocusEvent</code> value that will be used
   *          to determine if the focus is being set on the <code>JTree</code>.
   *
   *  
   */
  static public void setFocusToFirstSelectedRow (JTree jTree, FocusEvent focusEvent) {
    // Make sure our parameters are non-null
    if ((jTree != null) && (focusEvent != null)) {
      // Check to see if we are gaining focus
      if (focusEvent.getID() == FocusEvent.FOCUS_GAINED) {
        // Determine if any rows are currently selected
        int[] nRows = jTree.getSelectionRows();
        if (nRows != null)
          // Go to the first selected row
          jTree.setSelectionRow (nRows[0]);
        else
          // Default to the first row
          jTree.setSelectionRow (0);
      }
    }
  }

  /**
   * @internal
   *
   * Updates the data type based on the two specified values.
   *
   * @param  strDataTypeCurrent A <code>String</code> which represents the current
   *                            data type.
   * @param  strDataTypeNext A <code>String</code> which represents the next
   *                         data type.
   *
   * @return <code>String</code> value which represents the new data type.
   *
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#INDETERMINATE
   *
   * 
   *
   */
  static public String updateDataType (String strDataTypeCurrent, String strDataTypeNext) {

    if ((strDataTypeCurrent != null) && (strDataTypeNext != null)) {

      // Get the classes of each data type
      int nClassCurrent = DataUtils.getClass (strDataTypeCurrent);
      int nClass = getClass (strDataTypeNext);

      // If the data type classes don't match, we have an indeterminante
      // state
      if (nClassCurrent != nClass) {
        return MM.INDETERMINATE;
      }

      // Check the numeric classes, promoting if necessary
      if (nClass == CLASS_NUMERIC) {
        if (strDataTypeCurrent.equals (MM.SHORT)) {
          if (strDataTypeNext.equals (MM.INTEGER)) {
            return MM.INTEGER;
          }

          if (strDataTypeNext.equals (MM.LONG)) {
            return MM.LONG;
          }

          if (strDataTypeNext.equals (MM.FLOAT)) {
              return MM.FLOAT;
          }

          if (strDataTypeNext.equals (MM.DOUBLE)) {
            return MM.DOUBLE;
          }
        }

        if (strDataTypeCurrent.equals (MM.INTEGER)) {
          if (strDataTypeNext.equals (MM.LONG)) {
            return MM.LONG;
          }

          if (strDataTypeNext.equals (MM.FLOAT)) {
            return MM.FLOAT;
          }

          if (strDataTypeNext.equals (MM.DOUBLE)) {
            return MM.DOUBLE;
          }
        }

        if (strDataTypeCurrent.equals (MM.LONG)) {
          if (strDataTypeNext.equals (MM.FLOAT)) {
            return MM.FLOAT;
          }

          if (strDataTypeNext.equals (MM.DOUBLE)) {
            return MM.DOUBLE;
          }
        }

        if (strDataTypeCurrent.equals (MM.FLOAT)) {
          if (strDataTypeNext.equals (MM.DOUBLE)) {
            return MM.DOUBLE;
          }
        }
      }
      else if (nClass == CLASS_NON_NUMERIC) {
        // Check non-numeric classes
        if (strDataTypeCurrent.equals (MM.BOOLEAN)) {
          if (!strDataTypeNext.equals (MM.BOOLEAN)) {
            return MM.INDETERMINATE;
          }
        }

        if (strDataTypeCurrent.equals (MM.STRING)) {
          if (!strDataTypeNext.equals (MM.STRING)) {
            return MM.INDETERMINATE;
          }
        }

        if (strDataTypeCurrent.equals (MM.DATE)) {
          if (!strDataTypeNext.equals (MM.DATE)) {
            return MM.INDETERMINATE;
          }
        }
      }
    }

    return strDataTypeCurrent;
  }

  /**
   * @internal
   *
   * Updates the <code>MDMeasure</code> data type based on current value and
   * the specified one.
   *
   * @param  mdMeasure The <code>MDMeasure</code> object to update.
   * @param  strDataType The new data type.
   *
   * @return A constant that represents success or failure.
   *         The valid constants are defined in the <code>MDU</code> class,
   *         and they are listed in the See Also section.
   *
   * @see oracle.dss.metadataUtil.MDU#SUCCESS
   * @see oracle.dss.metadataUtil.MDU#FAILURE
   *
   * @see oracle.dss.metadataManager.common.MM#BOOLEAN
   * @see oracle.dss.metadataManager.common.MM#SHORT
   * @see oracle.dss.metadataManager.common.MM#INTEGER
   * @see oracle.dss.metadataManager.common.MM#LONG
   * @see oracle.dss.metadataManager.common.MM#FLOAT
   * @see oracle.dss.metadataManager.common.MM#DOUBLE
   * @see oracle.dss.metadataManager.common.MM#STRING
   * @see oracle.dss.metadataManager.common.MM#DATE
   * @see oracle.dss.metadataManager.common.MM#INDETERMINATE
   *
   * 
   *
   */
  static public int updateDataType (MDMeasure mdMeasure, String strDataType){

    if ((mdMeasure != null) && (strDataType != null)) {
      // Get the current data type
      String strDataTypeCurrent = mdMeasure.getDataType();

      // Update the MDMeasure based on the new data type
      return mdMeasure.setDataType (updateDataType (strDataTypeCurrent, strDataType));
    }

  return MDU.SUCCESS;
  }

  /**
   * Retrieves the dimensions associated with the specified measure.
   *
   * If the measure represents a custom measure, it is loaded if necessary prior
   * to determining its dimensionality.
   *
   * @param  mdMeasure a <code>MDMeasure</code> value that represents the
   *         measure to retrieve the dimensions for.
   *
   * @return <code>MDDimension[]</code> array which represents the dimensionality
   *         associated with the measure.
   *
   * @throws MetadataManagerException if dimensionality cannot be retrieved.
   * 
   */
  public static MDDimension[] getDimensions (MDMeasure mdMeasure)
      throws MetadataManagerException {

    // Check for null MDMeasure
    if (mdMeasure == null)
      return null;

    // Retrieve the dimensionality
    MDDimension[] mdDimensions = null;
    mdDimensions = mdMeasure.getDimensions();

    // If we have no dimensionality, determine if this is a custom measure
    // that hasn't been loaded yet
    if (mdDimensions == null) {
      /** gek 11/03/06
      // Make sure that we have a custom measure
      if (isCalculation (mdMeasure)) {
        // Update the dimensionality
        mdDimensions = mdMeasure.getDimensions();
      }
      */
    }

    return mdDimensions;
  }

  /**
   * @internal
   *
   * Retrieves a list of available Time Dimensions.
   *
   * @param metadataManager The <code>MetadataManager</code> object from which
   *                        to retrieve the dimensions.
   * @param strMeasureID The <code>String</code> ID of the measure used
   *                     to filter time dimension by.  If this value is not
   *                     null, only time dimensions associated with the measure
   *                     are returned, otherwise all time dimensions are returned.
   * @return A <code>Vector</code> value that contains the list of available
   *         Time dimensions.
   *
   * @throws MetadataManagerException if metadata could not be retrieved
   *
   * 
   */
  static public Vector getTimeDimensions (MetadataManagerServices metadataManager,
                                          String strMeasureID)
                                          throws MetadataManagerException {
    if (metadataManager == null)
      return null;

    Vector vTimeIDs = null;
    MDDimension[] mdDimensions = null;

    if (strMeasureID != null) {
      MDMeasure mdMeasure =
        (MDMeasure)metadataManager.getMDObject(MM.UNIQUE_ID,
          strMeasureID, MM.MEASURE);

      mdDimensions = mdMeasure.getDimensions();
    }
    else {
      mdDimensions = metadataManager.getDimensions ();
    }

    if (mdDimensions == null)
        return null;

    for (int nIndex = 0; nIndex < mdDimensions.length; nIndex++) {
      if (mdDimensions[nIndex].isTimeDimension()) {
        if (vTimeIDs == null) {
          vTimeIDs = new Vector();
        }

        vTimeIDs.addElement (mdDimensions[nIndex].getUniqueID());
      }
    }

    return vTimeIDs;
  }

  /**
   * @internal
   * 
   * Retrieve the Evaluator instance associated with the specified parameters.
   *
   * @param classStepEvaluator a <code>Class</code> value that represents the
   *        class of the step evaluator that we wish to create.
   * @param step a <code>Step</code> value that represents the
   *        step used to retrieve evaluator for.
   * @return <code>AwStepEvaluator</code> which represents an instance of a
   *         newly created step evaluator instance.
   * @throws <code>StepEvaluatorException</code> If the <code>AwStepEvaluator</code>
   *         constructor is not found.
   * 
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  public static Object getEvaluatorInstance (Class classStepEvaluator,
                                      Step step) throws StepEvaluatorException {

    Object objectEvaluator = null;
    Constructor constructor = null;

    if ((classStepEvaluator != null) && (step != null)) {
      // Retrieve contructor
      try {
        constructor = classStepEvaluator.getConstructor (new Class[] {Step.class});
      }
  
      catch (NoSuchMethodException nsme) {
        // Can't find constructor with the specified class and arguments
        throw new StepEvaluatorException (nsme.getMessage(),
          classStepEvaluator.getName(), nsme);
      }
  
      try {
        // Attempt to create an instance
        objectEvaluator =  constructor.newInstance(new Object[] {step});
      }
  
      catch (Exception e) {
        throw new StepEvaluatorException(e.getMessage(), classStepEvaluator.getName(), e);
      }
    }

    return objectEvaluator;
  }
*/
  /**
   * @internal
   * 
   * Returns the Evaluator instance associated with the specified step.
   *
   * @param step a <code>Step</code> value that represents the
   *        step used to retrieve evaluator for.
   *
   * @return <code>Object</code> which represents the evaluator
   *          instance associated with the specified step or null.
   *
   * @throws StepEvaluatorException if evaluator class for step can't be retrieved.
   *
   * 
   */
   // blm - Selection code moved to dvt-olap
/*  public static Object getStepEvaluator (Step step) throws StepEvaluatorException {
    Class classEvaluator = null;
    Object object = null;

    if (step != null) {
      try {
        classEvaluator = step.getEvaluatorClass();
      }
  
      catch (SelectionException selectionExeception) {
        throw new StepEvaluatorException (selectionExeception.getMessage(),
          (classEvaluator != null) ? classEvaluator.getName() : null, 
            selectionExeception);
      }
  
      if (classEvaluator != null) {
        // Create an instance
        object = getEvaluatorInstance (classEvaluator, step);
      }
    }
    
    return object;
  }
*/

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * @internal
   *
   * Returns the class of of the specified data type.
   *
   * @param  strDataType The new data type.
   *
   * 
   *
   */
  static private int getClass (String strDataType) {
    int nClass = CLASS_UNKNOWN;

    if (strDataType == null)
        return nClass;

    if (strDataType.equals (MM.SHORT) ||
      strDataType.equals (MM.INTEGER) ||
      strDataType.equals (MM.LONG)    ||
      strDataType.equals (MM.FLOAT)   ||
      strDataType.equals (MM.DOUBLE)) {
      return CLASS_NUMERIC;
    }

    if (strDataType.equals (MM.BOOLEAN) ||
      strDataType.equals (MM.STRING)  ||
      strDataType.equals (MM.DATE)) {
      return CLASS_NON_NUMERIC;
    }

    return nClass;
  }

  /**
   * @internal
   *
   * Removes all non-custom measures from the specified list.
   *
   * @param  vMeasures a <code>Vector</code> of values to prune.
   *
   * @return A <code>Vector</code> of measures that only consists of custom
   *         measures.
   */
  private static Vector removeMeasures (Vector vMeasures) {
    // Iterate over all measures in the vector
    if (vMeasures != null && !vMeasures.isEmpty()) {
      // Move backwards through the list
      for (int nPosition = vMeasures.size() - 1; nPosition >= 0; nPosition--) {
        // Retrieve the measure at the current position
        String strMeasureID = (String) vMeasures.elementAt (nPosition);

        // Determine if this is a custom measure (i.e. persisted)
        String driverType = MMUtilities._getDriverType(strMeasureID);
        if (driverType == null || !driverType.equals (MM.PERSISTENCE)) {
          // Remove measure if it not a custom measure
          vMeasures.remove (strMeasureID);
        }
      }
    }
    return vMeasures;
  }

  // TODO - We want to remove this method eventually. It's only purpose is
  // to retrofit the new model where only hierarchies have a list of levels
  // with the old model where each dimension has a list of levels.
  private static MDLevel[] getDimensionLevels(MDDimension dimension) {
    if ( dimension != null ) {
     
      try {
      MDHierarchy[] hierarchies = dimension.getHierarchies();
      if (hierarchies != null) {
        Vector levels = new Vector();
        MDLevel[] levelArray;
          for (int i=0; i<hierarchies.length; i++) {
            levelArray = hierarchies[i].getLevels();
            if (levelArray != null) {
              for (int j=0; j<levelArray.length; j++) {
                levels.addElement(levelArray[j]);
              }
            }
          }
          return (MDLevel[])oracle.dss.util.Utility.copyVectorToArray(levels);
	      }
      }

      catch (MetadataManagerException mme) {
        mme.printStackTrace();
      }
    }
    return null;
  }
 
  /**
   * @internal
   *
   * Removes duplicate strings that appear in the specified <code>Vector</code>.
   *
   * @param  vstrValues a <code>Vector</code> of <code>String</code> values that
   *         need to have duplicate entries removed.
   *
   * @return <code>Vector</code> with duplicate entries removed.
   *
   * 
   */
  public static Vector removeDuplicates (Vector vstrValues) {

    // Check for a null vector
    if (vstrValues == null)
      return vstrValues;

    HashSet hashSet = new HashSet();
    Vector vstrResults = new Vector();

    // Iterate over all entries in the vector
    Enumeration enumeration = vstrValues.elements();
    while (enumeration.hasMoreElements ()) {
      // Retrieve the string at the current position
      String strValue = (String)enumeration.nextElement();

      // Check to see if we have already added this value
      if (strValue != null) {
        if (hashSet.add (strValue)) {
          vstrResults.add (strValue);
        }
      }
    }

    // Return vector that contains no duplicate entries
    return vstrResults;
  }

  /**
   * @internal
   * 
   * Determines whether the specified <code>Attributes</code> represent a
   * short cut object.
   *
   * @param attributes A <code>Attributes</code> object which contain the list
   *        of attributes to check.
   *        
   * @return <code>boolean</code> which is <code>true</code> if the attributes
   *         represent a short cut object and <code>false</code> otherwise.
   *
   * 
   */
  public static boolean isShortCut (Attributes attributes) {
    Boolean bIsShortCut = new Boolean (false);
      
    try {
      if (attributes != null) {  
        // Retrieve the short cut attribute value
        Attribute attributeShortCut = 
          attributes.get (PSRConstants.Attributes.IS_SHORTCUT);
            
        if (attributeShortCut != null) {
          bIsShortCut = (Boolean)attributeShortCut.get();
        }
      }
     }
      
    catch (Exception e) {
      // Ignore the exception  
    }
    
    return bIsShortCut.booleanValue();
  }

  /**
   * @internal
   * 
   * If the <code>Attributes</code> represent a short cut object, the 
   * <code>Attributes</code> associated with the target object are returned
   * instead of those associated with the short cut.
   *
   * @param attributes A <code>Attributes</code> value to check.
   * @param errorHandler A <code>ErrorHandler</code> used to handle exceptions.
   * @param metadataManagerServices A <code>MetadataManagerServices</code> value
   *        used to retrieve metadata.
   *
   * @return <code>Attributes</code> value which contains the original attributes
   *         or those of the target if a short cut has been specified.
   *
   * 
   */
  public static Attributes getShortCutAttributes (BISearchResult biSearchResult, 
                              MetadataManagerServices metadataManagerServices) {
    Attributes attributes = null;

    if (biSearchResult != null) {
      attributes = biSearchResult.getAttributes();      
    
      boolean bIsShortCut = isShortCut (attributes);  
      if (bIsShortCut) {
        Object object = biSearchResult.getObject();
        
        if (object instanceof Persistable) {
          PersistableAttributes persistableAttributes = 
            ((Persistable)object).getPersistableAttributes (null);
          
          String strPath = persistableAttributes.getObjectFullPathName();       
          if (strPath != null) {
            try {  
              attributes = 
                metadataManagerServices.getMDRoot().getAttributes (strPath); 
            }
            
            catch (Exception exception) {
              // Ignore exceptions  
            }
          }
        }  
      }
    }
    
    return attributes;
  }  

  /**
   * @internal
   * 
   * Update the specified <code>BISearchControls</code> to include short cuts.
   * 
   * @param biSearchControls A <code>BISearchControls</code> to update to include
   *        short cuts.
   * 
   * 
   */
  public static void includeShortCuts (BISearchControls biSearchControls) {
    if (biSearchControls != null) {
      // Set up shortcut filter
      biSearchControls.setIncludeShortcutTarget (true);
      
      // Only specify the attributes that we actually need so that we do not
      // unnecessarily load others.
      //
      // Note: When ReturningAttributes are specified, only the those 
      //       attributes specifically referenced will be returned.  It will 
      //       not include the 'default' attributes list.
      //
      //       The MMUtilities.getAllReturningAttributes (String[]) method can
      //       be used to merge your desired attribute with the 'default'
      //       attributes list.
      
      String[] strArrayAttr = 
        new String[] {
          PSRConstants.Attributes.COMPSUBTYPE1, 
          PSRConstants.Attributes.COMPSUBTYPE2, 
          PSRConstants.Attributes.COMPSUBTYPE3,
          PSRConstants.Attributes.IS_SHORTCUT,
          MM.UNIQUE_ID,
          PSRConstants.Attributes.OBJECT_FULLPATH_NAME, 
          PSRConstants.Attributes.OBJECT_NAME, 
          PSRConstants.Attributes.OBJECT_TYPE,
          PSRConstants.Attributes.OBJECT_LABEL};
         
      // Include default attributes along with our chosen ones   
      // String[] strArrayAttr1 = MMUtilities.getAllReturningAttributes (strArrayAttr);  
      
      // Update the SearchControls with our chosen attributes   
      biSearchControls.setReturningAttributes (strArrayAttr);
    }
  }

  /**
   * @internal
   * 
   * Determines whether time-based calculations are available based on the
   * specified measure.
   * 
   * By default, this method returns <code>true</code> if no measure can be 
   * retrieved or no <code>MetadataManagerServices<code> is available.
   * 
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        retrieve the metadata.
   * @param strMeasureID A <code>String</code> which represents the 
   *        <code>MetadataManager</code> runtime unique ID to check.
   *
   * @param <code>
   * 
   * @return <code>boolean</code> which is <code>true</code> when time-based
   *         calculations are available and <code>false</code> otherwise.
   *        
   *        
   */
  public static boolean isTimeAvailable (MetadataManagerServices metadataManagerServices, 
                    String strMeasureID) throws MetadataManagerException {
    
    boolean bIsTimeAvailable = true;

    if (metadataManagerServices != null) {
    
      // Verify that the query contains measures          
      if (strMeasureID != null) {
        Vector vstrTimeDimensions = null;

        if (metadataManagerServices != null) {
          bIsTimeAvailable = false;

          // Determine if any time dimensions are available
          vstrTimeDimensions = 
            DataUtils.getTimeDimensions (metadataManagerServices, strMeasureID);
        
          // If we have found a measure referencing time, simply exit
          if ((vstrTimeDimensions != null) && (!vstrTimeDimensions.isEmpty())) {
            bIsTimeAvailable = true;
          }
        }
      }
    }
  
    return bIsTimeAvailable;
  }

  /**
   * @internal
   * 
   * Determines whether time-based calculations are available based on the
   * specified measures.
   * 
   * By default, this method returns <code>true</code> if no measures can be 
   * retrieved or no <code>MetadataManagerServices<code> is available.
   * 
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        retrieve the metadata.
   * @param mdMeasures A <code>MDMeasure[]</code> of measures to verify.
   *
   * @return <code>boolean</code> which is <code>true</code> when time-based
   *         calculations are available and <code>false</code> otherwise.
   *        
   *        
   */
  public static boolean isTimeAvailable (MetadataManagerServices metadataManagerServices, 
                    MDMeasure[] mdMeasures) throws MetadataManagerException {

    boolean bIsTimeAvailable = true;

    if (metadataManagerServices != null) {
    
      // Verify that the query contains measures          
      if (mdMeasures != null) {

        if (metadataManagerServices != null) {
          bIsTimeAvailable = false;

          // Iterate over each measure
          for (int nIndex = 0; nIndex < mdMeasures.length; nIndex++) {
          
            if (isTimeAvailable (metadataManagerServices, 
              mdMeasures [nIndex].getUniqueID())) {
              bIsTimeAvailable = true;
              break;
            }
          }
        }
      }
    }
  
    return bIsTimeAvailable;
  }
                    
  /**
   * @internal
   * 
   * Determines whether time-based calculations are available based on the
   * specified measures.
   * 
   * By default, this method returns <code>true</code> if no measures can be 
   * retrieved or no <code>MetadataManagerServices<code> is available.
   * 
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        retrieve the metadata.
   * @param vstrMeasureIDs A <code>Vector</code> that contains the list of 
   *        <code>MetadataManager</code> runtime unique IDs to check.
   * @param bTimeValueHierarchiesAllowed A <code>boolean</code> value which is 
   *        <code>true</code> if value-based hierarchies are allowed and 
   *        <code>false</code> otherwise.
   *
   * @return <code>boolean</code> which is <code>true</code> when time-based
   *         calculations are available and <code>false</code> otherwise.
   *        
   *        
   */
  public static boolean isTimeAvailable (MetadataManagerServices metadataManagerServices, 
    Vector vstrMeasureIDs, boolean bTimeValueHierarchiesAllowed) {

    boolean bIsTimeAvailable = true;

    if ((vstrMeasureIDs != null) && (!vstrMeasureIDs.isEmpty())) {
      bIsTimeAvailable = false;
      
      // Filter out any measures that aren't dimensioned by Time
      vstrMeasureIDs = 
        DataUtils.filterByTime (metadataManagerServices, vstrMeasureIDs, 
          bTimeValueHierarchiesAllowed);
  
      // After filtering, determine if the are any measures based on time
      // still available
      if ((vstrMeasureIDs != null) && (vstrMeasureIDs.size() != 0)) {
        bIsTimeAvailable = true;  
      }
    }
  
    return bIsTimeAvailable;
  }

  /**
   * @internal
   * 
   * Determines whether time-based calculations are available based on the
   * specified measures.
   * 
   * By default, this method returns <code>true</code> if no measures can be 
   * retrieved or no <code>MetadataManagerServices<code> is available.
   * 
   * @param metadataManagerServices A <code>MetadataManagerServices</code> used to 
   *        retrieve the metadata.
   * @param strMeasureIDs A <code>String[]</code> that contains the list of 
   *        <code>MetadataManager</code> runtime unique IDs to check.
   *
   * @return <code>boolean</code> which is <code>true</code> when time-based
   *         calculations are available and <code>false</code> otherwise.
   *        
   *        
   */
  public static boolean isTimeAvailable (MetadataManagerServices metadataManagerServices, 
                    String[] strMeasureIDs) throws MetadataManagerException {
    
    boolean bIsTimeAvailable = true;

    if (metadataManagerServices != null) {
    
      // Verify that the query contains measures          
      if (strMeasureIDs != null) {

        if (metadataManagerServices != null) {
          bIsTimeAvailable = false;

          // Iterate over each measure
          for (int nIndex = 0; nIndex < strMeasureIDs.length; nIndex++) {
          
            if (isTimeAvailable (metadataManagerServices, strMeasureIDs [nIndex])) {
              bIsTimeAvailable = true;
              break;
            }
          }
        }
      }
    }
  
    return bIsTimeAvailable;
  }
  
  /**
   * @internal
   * 
   * Retrieves the <code>MetadataManager</code> runtime IDs associated with 
   * the specified MDObjects.
   *
   * @param mdObjects An array which represents the list of MDObjects to retrieve 
   *        <code>MetadataManager</code> Unique IDs for.
   *
   * @return <code>Vector</code> of <code>MDObject</code> runtime IDs associated 
   *         with the specified MDObjects.
   *        
   * @throws <code>MetadataManagerException</code> if runtime ID cannot be
   *         retrieved.
   */
  public static String[] getUniqueIDs (MDObject[] mdObjects) throws MetadataManagerException {
    
    String[] strMDObjectIDs = null;

    if (mdObjects != null) {
      strMDObjectIDs = new String [mdObjects.length];
      
      MDObject mdObject;
      
      for (int nIndex = 0; nIndex < mdObjects.length; nIndex++) {
        // Retrieve the MDObject at the current position
        mdObject = (MDObject) mdObjects [nIndex];
        
        // Retrieve the runtime ID associated with the MDObject
        strMDObjectIDs[nIndex] = mdObject.getUniqueID();
      }
    }    

    return strMDObjectIDs;
  }

  /**
   * @internal
   * 
   * Retrieves the <code>MetadataManager</code> runtime IDs associated with 
   * the specified MDObjects.
   *
   * @param vMDObjects A <code>Vector</code> which represents the list of 
   *        MDObjects to retrieve <code>MetadataManager</code> Unique IDs for.
   *
   * @return <code>Vector</code> of <code>MDObject</code> Unique IDs associated 
   *         with the specified MDObjects.
   *        
   * @throws <code>MetadataManagerException</code> if runtime ID cannot be
   *         retrieved.
   */
  public static Vector getUniqueIDs (Vector vMDObjects) throws MetadataManagerException {
    
    Vector vstrRuntimeIDs = null;

    if ((vMDObjects != null) && !vMDObjects.isEmpty()) {
      vstrRuntimeIDs = new Vector ();
      
      MDObject mdObject;
      
      for (int nIndex = 0; nIndex < vMDObjects.size(); nIndex++) {
        // Retrieve the MDObject at the current position
        mdObject =  (MDObject)vMDObjects.get (nIndex);
        
        // Retrieve the runtime ID associated with the MDObject
        if (mdObject != null) {
          vstrRuntimeIDs.add (mdObject.getUniqueID());
        }   
      }
    }    

    return vstrRuntimeIDs;
  }

  /**
   * @internal
   * 
   * Retrieves the <code>MetadataManager</code> MDObjects associated with the 
   * specified runtime IDs.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param vstrRuntimeIDs A <code>String</code> which represents the 
   *        <code>MetadataManager</code> runtime IDs associated with each 
   *        <code>MDObject</code> to retrieve.
   *
   * @return <code>Vector</code> of MDObjects objects associated with the specified
   *         <code>MetadataManager</code> runtime IDs.
   *        
   * @throws <code>MetadataManagerException</code> if MDObjects cannot be
   *         retrieved.
   *      
   * @see #getDimensionality(MetadataManagerServices, Vector)     
   */
  public static Vector getMDObjects (MetadataManagerServices metadataManagerServices,
                          Vector vstrRuntimeIDs) throws MetadataManagerException {
    
    Vector vMDObjects = null;

    if (metadataManagerServices != null) {
      if ((vstrRuntimeIDs != null) && !vstrRuntimeIDs.isEmpty()) {
        vMDObjects = new Vector ();
        
        MDMeasure mdMeasure;
        
        for (int nIndex = 0; nIndex < vstrRuntimeIDs.size(); nIndex++) {
          // Retrieve the MDMeasure associated with the ID
          mdMeasure = 
            metadataManagerServices.getMeasure (MM.UNIQUE_ID, 
              (String)vstrRuntimeIDs.get (nIndex));
          
          if (mdMeasure != null) {
            vMDObjects.add (mdMeasure);
          }   
        }
      }
    }    

    return vMDObjects;
  }
                          
  /**
   * @internal
   * 
   * Retrieves the combined dimensionality associated with the specified measures.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param vMDMeasures A <code>Vector</code> which represents the 
   *        list of <code>MDMeasure</code> objects to retrieve dimensionality for.
   *
   * @return <code>Vector</code> of <code>String</code> values which represents 
   *         <code>MetadataManager</code> runtime IDs associated with each 
   *         dimension of the combined dimensionality.
   *        
   * @throws <code>MetadataManagerException</code> if dimensions cannot be
   *         retrieved.
   */
  public static Vector getDimensionality (MetadataManagerServices metadataManagerServices,
                          Vector vMDMeasures) throws MetadataManagerException {     
  
    Vector vstrDimensionIDs = null;
    
    if (metadataManagerServices != null) {
      if ((vMDMeasures != null) && !vMDMeasures.isEmpty()) {
        vstrDimensionIDs = new Vector();
        
        MDMeasure mdMeasure;
        
        for (int nIndex = 0; nIndex < vMDMeasures.size(); nIndex++) {
          // Retrieve the MDMeasure associated with the ID
          mdMeasure = (MDMeasure) vMDMeasures.get (nIndex);
          
          if (mdMeasure != null) {
            vstrDimensionIDs.addAll (getDimensionality (metadataManagerServices, mdMeasure));
          }   
        }
      
        // Remove any duplicate entries
        vstrDimensionIDs = removeDuplicates (vstrDimensionIDs);
      }
    }    

    return vstrDimensionIDs;
  }

  /**
   * @internal
   * 
   * Retrieves the dimensionality associated with the specified measure.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param strMeasureID A <code>String</code> which represents the 
   *        <code>MetadataManager</code> runtime ID associated with the 
   *        measure to retrieve dimensionality for.
   *
   * @return <code>Vector</code> of <code>String</code> values which represents 
   *         <code>MetadataManager</code> runtime IDs associated with the measure's
   *         dimensionality.
   *        
   * @throws <code>MetadataManagerException</code> if dimensions cannot be
   *         retrieved.
   */
  public static Vector getDimensionality (MetadataManagerServices metadataManagerServices,
                          String strMeasureID) throws MetadataManagerException {     
  
    Vector vstrDimensionIDs = null;
    
    if (metadataManagerServices != null) {
      // Retrieve the MDMeasure associated with the ID
      MDMeasure mdMeasure = 
        metadataManagerServices.getMeasure (MM.UNIQUE_ID, strMeasureID);
      
      if (mdMeasure != null) {
        vstrDimensionIDs = 
          getDimensionality (metadataManagerServices, mdMeasure);
      }   
    }    
  
    return vstrDimensionIDs;
  }


  /**
   * @internal
   * 
   * Retrieves the dimensionality associated with the specified measure.
   *
   * @param metadataManagerServices a <code>MetadataManagerServices</code>
   *        object which allows metadata retrieval.
   * @param mdMeasure A <code>MDMeasure</code> to retrieve dimensionality for.
   *
   * @return <code>Vector</code> of <code>String</code> values which represents 
   *         <code>MetadataManager</code> runtime IDs associated with the measure's
   *         dimensionality.
   *        
   * @throws <code>MetadataManagerException</code> if dimensions cannot be
   *         retrieved.
   */
  public static Vector getDimensionality (MetadataManagerServices metadataManagerServices,
                          MDMeasure mdMeasure) throws MetadataManagerException {     
  
    Vector vstrDimensionIDs = null;
    
    if (metadataManagerServices != null) {
      if (mdMeasure != null) {
        // Attempt to retrieve each measure's dimensionality
        MDDimension[] mdDimensions = mdMeasure.getDimensions();
     
        if (mdDimensions != null) {
          MDDimension mdDimension = null;
          String strDimensionID = null;
          
          // Iterate over all of the dimensions
          for (int nIndex = 0; nIndex < mdDimensions.length; nIndex++) {
            mdDimension = mdDimensions[nIndex];  
            
            if (mdDimension != null) {
              // Retrieve the unique ID of the MDDimension
              strDimensionID = mdDimension.getUniqueID();
              
              if (strDimensionID != null) {
              
                // Create the vector if it hasn't been done yet
                if (vstrDimensionIDs == null) {
                  vstrDimensionIDs = new Vector();
                }
                
                // Add the dimension ID
                vstrDimensionIDs.add (strDimensionID);  
              }
            }
          }
        }
      }
    }
  
    return vstrDimensionIDs;
  }

  /**
   * @internal
   *
   * Returns the value for an operand.
   *
   * @param calcValue a <code>calcValue</code> value that we wish to obtain
   *        a string representation for.
   *
   * @return A <code>String</code> value that represents the string
   *         representation of the specified CalcValue.
   *
   * 
   */
  /** gek 11/03/06
  public static  String getOperandValue (CalcValue calcValue) {
    OlapQDR qdr       = null;
    String  strValue  = null;
    String  strMeasureDimension = null;

    if (calcValue == null)
      return null;

    if (OlapQDR.class == calcValue.getType()) {
      qdr = (OlapQDR) calcValue.getValue();

      strMeasureDimension = qdr.getMeasureDim();

      if (strMeasureDimension == null)
          return null;

      // Get the dimension member for the dimension.
      strValue = qdr.getDimMember (strMeasureDimension).toString ();
      if (strValue == null || 0 == strValue.length())
        return null;

      return new String (strValue);
    }
    else if (String.class == calcValue.getType()) {
      return new String ((String) calcValue.getValue ());
    }

    return null;
  }
  */
  
  /**
   * @internal
   * 
   * Determines whether the specified data types are compatible with each other.
   * 
   * @param strDataType1 A <code>String</code> which represents data type 1.
   * @param strDataType2 A <code>String</code> which represents data type 2.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         data types are compatible and <code>false</code> otherwise.
   *          
   * 
   */
  public static boolean areCompatibleDataTypes (String strDataType1, String strDataType2) {
    
    if ((strDataType1 != null) && (strDataType2 != null)) {
      return ((strDataType1.equals(MM.BOOLEAN) && strDataType2.equals(MM.BOOLEAN)) ||
              (strDataType1.equals(MM.DATE) && strDataType2.equals(MM.DATE)) || 
              (strDataType1.equals(MM.STRING) && strDataType2.equals(MM.STRING)) ||
              (isNumeric(strDataType1) && isNumeric(strDataType2)));
    }
    
    return false;
  }

  /**
   * @internal
   * 
   * Determines whether or not the specified <code>MDObject</code> is numeric.
   * 
   * @param mdObject A <code>MDObject</code> to check.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         <code>MDObject</code> is numeric and <code>false</code> otherwise.
   *          
   * 
   */
  public static boolean isNumeric (MDObject mdObject) {
    boolean bIsNumeric = false;

    if (mdObject != null) {
      bIsNumeric = isNumeric (mdObject.getStrPropertyValue (MM.DATA_TYPE));
    }  
    
    return bIsNumeric;
  }

  /**
   * @internal
   * 
   * Determines whether or not the specified <code>MDObject</code> has 
   * an aggregation rule.
   * 
   * @param mdObject A <code>MDObject</code> to check.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         <code>MDObject</code> has an aggregation rule and <code>false</code> otherwise.
   *          
   * 
   */
  public static boolean hasAggRule (MDObject mdObject) {
    boolean bHasAggRule = false;

    if (mdObject != null) {

      Property propertyAggRule = mdObject.getProperty (MM.AGGR_RULE);
      String strAggRule = MM.UNKNOWN;
      
      if (propertyAggRule != null) {
        strAggRule = propertyAggRule.getStrValue();
      }

      if (!MM.UNKNOWN.equals (strAggRule)) {
        bHasAggRule = true;    
      }
    }  
    
    return bHasAggRule;
  }

  /**
   * @internal
   * 
   * Determines whether or not the given data type is numeric.
   * 
   * @param strDataType A <code>String</code> which represents the data type.
   *
   * @return <code>boolean</code> value which is <code>true</code> if the 
   *         data type is numeric and <code>false</code> otherwise.
   *          
   * 
   */
  public static boolean isNumeric (String strDataType) {
    return ((MM.INTEGER.equals(strDataType)) ||
            (MM.SHORT.equals(strDataType))   ||
            (MM.FLOAT.equals(strDataType))   ||
            (MM.DOUBLE.equals(strDataType))  ||
            (MM.LONG.equals(strDataType)));
  }

  /**
   * @internal
   * 
   * Retrieve single value from CalcValue whether it's a QDR or not
   * 
   * @param calcValue A <code>CalcValue</code> to retrieve the single value from.
   * 
   * @return <code>String</code>, which represents the single value.
   * 
   * 
   */
  /** gek 11/03/06
  public static String getStringValue (CalcValue calcValue) {
    String strValue = null;

    if (calcValue != null) {
      if (calcValue.getType() == String.class) {
        strValue = (String)calcValue.getValue();
      }
      else {
        if (isQDR (calcValue.getType())) {
            QDR qdr = (QDR) calcValue.getValue();
            Enumeration enumeration = qdr.getDimensions();
            String dim = (String)enumeration.nextElement();

            QDRMember qdrMember = qdr.getDimMember(dim);
            if (qdrMember.getType() == QDRMember.FIXED) {
              return (String) qdrMember.getData();
            }
        }
      }
    }

    return strValue;            
  }
  */

  /**
   * @internal
   * 
   * Determines if the given class type is either <code>OlapQDR</code> or 
   * <code>QDR</code>.
   * 
   * @param strClass A <code>String</code> which represents the class of the 
   *        object.
   *
   * @return <code>boolean</code>, which is <code>true</code> of the class
   *         represents a <code>OlapQDR</code> or <code>QDR</code> and 
   *         <code>false</code> otherwise.
   *         
   * 
   */
  public static boolean isQDR (Class strClass) {
    return strClass == QDR.class || strClass == OlapQDR.class;
  }

  public static Object parseMemberString (String strMemberString, String strDataType, 
      String strFormatMask, boolean ignoreDate, Locale locale, ErrorHandler errorHandler) {
    if (MM.INTEGER.equals (strDataType) ||
        MM.LONG.equals (strDataType) ||
        MM.SHORT.equals (strDataType)) {
      return parseNumber (strMemberString, locale, true);
    }
    
    if (MM.DOUBLE.equals (strDataType) ||
        MM.FLOAT.equals (strDataType)) {
      return parseNumber (strMemberString, locale, false);
    }
    
    if (MM.DATE.equals (strDataType) && !ignoreDate) {
        BaseViewFormat baseViewFormat = new BaseViewFormat();
        baseViewFormat.setLocale (locale);
        baseViewFormat.setOracleDateFormat (strFormatMask);
        baseViewFormat.setErrorHandler (errorHandler);
        return baseViewFormat.StringToDate (strMemberString, false);
    }

    return strMemberString;
  }

  /**
   * Parse the member string associated with a DataFilter.
   * 
   * TODO: Improve parsing error processing.    
   * @param strMembersString A <code>String</code>
   * @param strDatatype A <code>String</code>
   * @param strFormatMask A <code>String</code>
   * @param locale A <code>Locale</code>
   * @param errorHandler A <code>ErrorHandler</code>
   * 
   * @return <code>Vector</code> of member <code>String</code> values.
   * 
   * @throws <code>Exception</code>
   * 
   *  
   */
  public static Vector parseMembersString (String strMembersString, String strDatatype, 
      String strFormatMask, Locale locale, ErrorHandler errorHandler) throws Exception {
    return parseMembersString (strMembersString, strDatatype, strFormatMask, locale, errorHandler, (DataFilter)null);
  }
  
  /**
   * Parse the member string and update the specified DataFilter.
   * 
   * TODO: Improve parsing error processing.   
   *  
   * @param strMembersString A <code>String</code>
   * @param strDatatype A <code>String</code>
   * @param strFormatMask A <code>String</code>
   * @param locale A <code>Locale</code>
   * @param errorHandler A <code>ErrorHandler</code>
   * @param dataFilter A <code>DataFilter</code> to update.
   * 
   * @return <code>Vector</code> of member <code>String</code> values.
   * 
   * @throws <code>Exception</code>
   * 
   *  
   */
  public static Vector parseMembersString (String strMembersString, String strDatatype, 
      String strFormatMask, Locale locale, ErrorHandler errorHandler, DataFilter dataFilter) throws Exception {

    // Break up the strings based on quotation
    String[] strExpressions = parseExpression (strMembersString, DATAFILTER_TOKEN_REGEX_QUOTES);
  
    Vector vobjMembers = null;
    String strParamName = null;
    boolean bAcceptMultipleValues = false;
    
    if (strExpressions != null) {  
      for (int nIndex = 0; nIndex < strExpressions.length; nIndex++) {
        strMembersString = strExpressions[nIndex];

        if ((strMembersString != null) && (!DATAFILTER_TOKEN_DELIMETER.equals (strMembersString)) &&
            (!DATAFILTER_TOKEN_PARAMETER_VALUE_START.equals (strMembersString)) && 
            (!DATAFILTER_TOKEN_PARAMETER_VALUE_END.equals (strMembersString))) {
          if (vobjMembers == null) {
            vobjMembers = new Vector();
          }
          
          Number number = null;
          
          // Simply try to convert string to Number
          try {
            number = parseNumber (strMembersString, locale, false);
          }
          
          // If number conversion fails, just ignore it.
          catch (Exception exception) {
          }
          
          String strDelimiter = 
            (number != null) ? DATAFILTER_TOKEN_DELIMETER_EMPTY : 
              DATAFILTER_TOKEN_DELIMETER + DATAFILTER_TOKEN_PARAMETER_VALUE_START + DATAFILTER_TOKEN_PARAMETER_VALUE_END;
          
          StringTokenizer stringTokenizer = 
            new StringTokenizer (strMembersString, strDelimiter);
          
          String strToken = null;          
    
          int nIndexParameterValue = -1;
          boolean bProcessParameter = false;
          Object objMember = null;

          while (stringTokenizer.hasMoreTokens()) {
            // Process each comma delimited token
            strToken = stringTokenizer.nextToken();
            objMember = null;

            if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER_ACCEPT_MULTIPLE_VALUES)) {
              bProcessParameter = true;
    
              // Strip off parameter token
              strToken = strToken.substring (2, strToken.length());
     
              bAcceptMultipleValues = true;
            }
            else if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER)) {
              bProcessParameter = true;
    
              // Strip off parameter token
              strToken = strToken.substring (1, strToken.length());
            }

            // Process standard values
            if (!bProcessParameter) {
              try {
                objMember = 
                  parseMemberString (strToken, strDatatype, strFormatMask, false, locale, errorHandler);  
              }
           
              // If the parsing fails, try to determine if it is an ID
              catch (Exception exception) {
                if (strToken != null) {
                  Vector vCmpValues = dataFilter.getCmpValues();  
                  if ((vCmpValues != null) && (vCmpValues.size() > 0)) {
                    for (int nIndex1 = 0; nIndex1 < vCmpValues.size(); nIndex1++) {
                      if (strToken.equals (vCmpValues.get (nIndex1).toString())) {
                        objMember = vCmpValues.get (nIndex1);
                        break;
                      }
                    }
                  }
                }
              }
           
              if (objMember != null) {
                vobjMembers.addElement (objMember);
              }
            }
            else {
              // Process Parameter name
              strParamName = strToken;
              bProcessParameter = false;
            }
          }
        }
      }

      // Update the DateFilter based on the results
      if (dataFilter != null) {

        // Update the members
        if ((vobjMembers != null) && (!vobjMembers.isEmpty())) {
          dataFilter.setCmpValues (vobjMembers);
        }

        // Update the parameters 
        updateParameters (dataFilter, strParamName, vobjMembers, bAcceptMultipleValues);
      }
    }

    return vobjMembers;
  }

  /**
   * Parse the member string and update the specified DataFilter.
   * 
   * TODO: Improve parsing error processing.   
   *  
   * @param strMembersString A <code>String</code>
   * @param strDatatype A <code>String</code>
   * @param strFormatMask A <code>String</code>
   * @param locale A <code>Locale</code>
   * @param errorHandler A <code>ErrorHandler</code>
   * @param topBottomDataFilter A <code>TopBottomDataFilter</code> to update.
   * 
   * @return <code>Vector</code> of member <code>String</code> values.
   * 
   *  
   */
  public static Vector parseMembersString (String strMembersString, String strDatatype, 
      String strFormatMask, Locale locale, ErrorHandler errorHandler, TopBottomDataFilter topBottomDataFilter) {
    if (strMembersString != null) {
      Vector vobjMembers = new Vector();
      
      StringTokenizer stringTokenizer = new StringTokenizer (strMembersString, DATAFILTER_TOKEN_DELIMETER);
      String strToken = null;

      boolean  bProcessParameter = false;
      String strParamName = null;
      boolean bAcceptMultipleValues = false;

      Vector vstrParamDefaultValues = new Vector();
      int nIndexParameterValue = -1;
  
      while (stringTokenizer.hasMoreTokens()) {
        try {
          // Process each comma delimited token
          strToken = stringTokenizer.nextToken();

          if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER_ACCEPT_MULTIPLE_VALUES)) {
            bProcessParameter = true;
  
            // Strip off parameter token
            strToken = strToken.substring (2, strToken.length());
   
            bAcceptMultipleValues = true;
          }
          else if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER)) {
            bProcessParameter = true;

            // Strip off parameter token
            strToken = strToken.substring (1, strToken.length());
          }

          // Process standard values
          if (!bProcessParameter) {  
            vobjMembers.addElement (parseMemberString (strToken, strDatatype, strFormatMask, true, locale, errorHandler));
          }
          else {
            // Process Parameter values
            if (strToken.contains (DATAFILTER_TOKEN_PARAMETER_VALUE_START)) {
              nIndexParameterValue = strToken.indexOf (DATAFILTER_TOKEN_PARAMETER_VALUE_START);  
              
              // Strip off parameter name
              strParamName = strToken.substring (0, nIndexParameterValue);
        
              // Strip off the first default parameter value
              strToken = strToken.substring (nIndexParameterValue + 1, strToken.length());
            }

            if (strToken.contains (DATAFILTER_TOKEN_PARAMETER_VALUE_END)) {
              bProcessParameter = false;  

              nIndexParameterValue = strToken.indexOf (DATAFILTER_TOKEN_PARAMETER_VALUE_END);  

              // Strip off the last default parameter value
              strToken = strToken.substring (0, nIndexParameterValue);
            }

            if (strToken != null) {
              vstrParamDefaultValues.addElement (parseMemberString (strToken, strDatatype, 
                strFormatMask, true, locale, errorHandler));
            }
          }
        }
        
        catch (Exception exception) {
          errorHandler.error (exception, DataUtils.class.getName(), "parseMembersString");
        }
      }

      int nValue = -1;

      // Update the DateFilter based on the results
      if (topBottomDataFilter != null) {

        // Update the members
        if ((vobjMembers != null) && (!vobjMembers.isEmpty())) {
          Object objMember = vobjMembers.get(0);
          
          if (objMember instanceof Number) {
            nValue = ((Number)objMember).intValue();
            topBottomDataFilter.setValue (nValue);
          }
        }

        // Update the parameters
        updateParameters (topBottomDataFilter, strParamName, nValue);        
      }

      return vobjMembers;
    }

    return null;
  }

  /**
   * Parse the member string and update the specified DataFilter.
   * 
   * TODO: Improve parsing error processing.   
   *  
   * @param strMembersString A <code>String</code>
   * @param strDatatype A <code>String</code>
   * @param strFormatMask A <code>String</code>
   * @param locale A <code>Locale</code>
   * @param errorHandler A <code>ErrorHandler</code>
   * @param rangeDataFilter A <code>RangeDataFilter</code> to update.
   * 
   * @return <code>Vector</code> of member <code>String</code> values.
   * 
   *  
   */
  public static Vector parseMembersString (String strMembersString, String strDatatype, 
      String strFormatMask, Locale locale, ErrorHandler errorHandler, RangeDataFilter rangeDataFilter) {

    if (strMembersString != null) {
      Vector vobjMembers = new Vector();
 
      String strParamNameStart = null;
      String strParamNameEnd = null;
      int nParamIndex = 0;
      
      // Break up the strings based on quotation
      StringTokenizer stringTokenizer = 
        new StringTokenizer (strMembersString, DATAFILTER_TOKEN_REGEX_QUOTES);
      
      String strToken = null;

      boolean  bProcessParameter = false;
      //// String strParamName = null;
      
      boolean bAcceptMultipleValues = false;
      boolean bAcceptMultipleValuesStart = false;
      boolean bAcceptMultipleValuesEnd = false;

      int nIndexParameterValue = -1;
      Object objMember = null;
  
      while (stringTokenizer.hasMoreTokens()) {
        try {
          // Process each comma delimited token
          strToken = stringTokenizer.nextToken();
          objMember = null;

          if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER_ACCEPT_MULTIPLE_VALUES)) {
            bProcessParameter = true;
  
            // Strip off parameter token
            strToken = strToken.substring (2, strToken.length());
   
            bAcceptMultipleValues = true;
          }
          else if (strToken.startsWith (DATAFILTER_TOKEN_PARAMETER)) {
            bProcessParameter = true;

            // Strip off parameter token
            strToken = strToken.substring (1, strToken.length());
          }

          // Process standard values
          if (!bProcessParameter) { 
            try {
              if (strToken.startsWith (DATAFILTER_TOKEN_DELIMETER)) {
                nParamIndex++;
              }
              else {
                objMember = parseMemberString (strToken, strDatatype, strFormatMask, true, locale, errorHandler);
              }
            }

            // If the parsing fails, try to determine if it is an ID
            catch (Exception exception) {
              if (strToken != null) {
                Object objStartValue = rangeDataFilter.getStartValue();
                
                if (objStartValue != null) {
                  if (strToken.equals (objStartValue.toString())) {
                    objMember = objStartValue;
                  }
                }
                
                if (objMember == null) {
                  Object objEndValue = rangeDataFilter.getEndValue();
                  
                  if (objEndValue != null) {
                    if (strToken.equals (objEndValue.toString())) {
                      objMember = objEndValue;
                    }
                  }
                }
              }
            }

            if (objMember != null) {
              vobjMembers.addElement (objMember);
            }
          }
          else {
            // Process Parameter names
            if (nParamIndex == 0){
              strParamNameStart = strToken;
              bAcceptMultipleValuesStart = bAcceptMultipleValues;
            }
            else {
              strParamNameEnd = strToken;
              bAcceptMultipleValuesEnd = bAcceptMultipleValues;
            }

            bProcessParameter = false;
            bAcceptMultipleValues = false;
          }
        }
        
        catch (Exception exception) {
          errorHandler.error (exception, DataUtils.class.getName(), "parseMembersString");
        }
      }

      // Update the DateFilter based on the results
      if (rangeDataFilter != null) {

        // Update the members
        if ((vobjMembers != null) && (!vobjMembers.isEmpty())) {
          if (vobjMembers.size() > 1) {
            rangeDataFilter.setStartValue (vobjMembers.get(0));
            rangeDataFilter.setEndValue (vobjMembers.get(1));
          }
        }

        // Update the parameters
        if (strParamNameStart != null) {
          updateParameterStart (rangeDataFilter, strParamNameStart, 
            rangeDataFilter.getStartValue(), bAcceptMultipleValuesStart);
        }
        
        if (strParamNameEnd != null) {
          updateParameterEnd (rangeDataFilter, strParamNameEnd, 
            rangeDataFilter.getEndValue(), bAcceptMultipleValuesEnd);
        }
      }

      return vobjMembers;
    }

    return null;
  }

  /**
   * Update <code>TopBottomDataFilter</code> parameter operator values.
   * 
   * @param topBottomDataFilter A <code>TopBottomDataFilter</code>
   * @param strParamName A <code>String</code>
   * @param nDefaultValue A <code>int</code>
   * 
   * @see oracle.dss.selection.dataFilter.DataFilter#setCmpOperator(int)
   *
   * 
   */
  public static void updateParametersOperator (TopBottomDataFilter topBottomDataFilter, 
      String strParamName, int nDefaultValue) {
    if ((topBottomDataFilter != null) && (strParamName != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, topBottomDataFilter.getItem());
      
      itemValueParameter.setDefaultValue (new Integer (nDefaultValue));
      
      topBottomDataFilter.associateParameter (DataFilter.PARAMETER_OPERATOR_VALUE, itemValueParameter);
  
      // Make the default parameters the operator default value for the DataFilter.
      topBottomDataFilter.setOperator (nDefaultValue);
    }
  }

  /**
   * Update <code>RangeDataFilter</code> parameter operator values.
   * 
   * @param rangeDataFilter A <code>RangeBottomDataFilter</code>
   * @param strParamNameFrom A <code>String</code>
   * @param nDefaultValueFrom A <code>int</code>
   * @param strParamNameTo A <code>String</code>
   * @param nDefaultValueTo A <code>int</code>
   * 
   */
 public static void updateParametersOperator (RangeDataFilter rangeDataFilter, 
      String strParamName, int nDefaultValue) {
    if ((rangeDataFilter != null) && (strParamName != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, rangeDataFilter.getItem());
      
      // TODO: Update parameter handling based to to/from values
      itemValueParameter.setDefaultValue (new Integer (nDefaultValue));
      
      rangeDataFilter.associateParameter (DataFilter.PARAMETER_OPERATOR_VALUE, itemValueParameter);
  
      // Make the default parameters the operator default value for the DataFilter.
      rangeDataFilter.setOperator (nDefaultValue);
    }   
  }
      
  /**
   * Update <code>DataFilter</code> parameter operator values.
   * 
   * @param dataFilter A <code>DataFilter</code>
   * @param strParamName A <code>String</code>
   * @param nDefaultValue A <code>int</code>
   * 
   * @see oracle.dss.selection.dataFilter.DataFilter#setCmpOperator(int)
   *
   * 
   */
  public static void updateParametersOperator (DataFilter dataFilter, String strParamName, int nDefaultValue) {
    if ((dataFilter != null) && (strParamName != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, dataFilter.getItem());
      
      itemValueParameter.setDefaultValue (new Integer (nDefaultValue));
      
      dataFilter.associateParameter (DataFilter.PARAMETER_OPERATOR_VALUE, itemValueParameter);
  
      // Make the default parameters the operator default value for the DataFilter.
      dataFilter.setCmpOperator (nDefaultValue);
    }
  }

  /**
   * Update <code>DataFilter</code> parameter comparison values.
   * 
   * @param dataFilter A <code>DataFilter</code>
   * @param strParamName A <code>String</code>
   * @param vstrParamDefaultValues A <code>Vector</code>
   * 
   * @status new 
   */
  public static void updateParameters (DataFilter dataFilter, String strParamName, Vector vstrParamDefaultValues) {
    updateParameters (dataFilter, strParamName, vstrParamDefaultValues, false);
  }

  /**
   * Update <code>DataFilter</code> parameter comparison values.
   * 
   * @param dataFilter A <code>DataFilter</code>
   * @param strParamName A <code>String</code>
   * @param vstrParamDefaultValues A <code>Vector</code>
   * @param bAcceptMultipleValues A <code>boolean</code>
   * 
   * @status new
   */
  public static void updateParameters (DataFilter dataFilter, String strParamName, 
      Vector vstrParamDefaultValues, boolean bAcceptMultipleValues) {
    
    if ((dataFilter != null) && (strParamName != null) && (vstrParamDefaultValues != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, dataFilter.getItem());
      
      itemValueParameter.setDefaultValue (vstrParamDefaultValues);
      itemValueParameter.setAcceptMultipleValues (bAcceptMultipleValues);
      
      dataFilter.associateParameter (DataFilter.PARAMETER_COMPARISON_VALUES, itemValueParameter);
  
      // Make the default parameters the default values for the DataFilter.
      // Non-null comparison values must be specified for the DataFilter to be processed properly
      // by the query.
      dataFilter.setCmpValues (vstrParamDefaultValues);
    }
  }

  /**
   * Update <code>DataFilter</code> parameter comparison values.
   * 
   * @param dataFilter A <code>DataFilter</code>
   * @param strParamName A <code>String</code>
   * @param vstrParamDefaultValues A <code>Vector</code>
   * @param bAcceptMultipleValues A <code>boolean</code>
   * 
   * @status new
   */
  public static void updateParameters (VariableSettingDataFilter variableSettingDataFilter, 
      String strParamName, String strDefaultValue) {
    
    if ((variableSettingDataFilter != null) && (strParamName != null) && (strDefaultValue != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, variableSettingDataFilter.getItem());
      
      itemValueParameter.setDefaultValue (strDefaultValue);
      
      variableSettingDataFilter.associateParameter (VariableSettingDataFilter.PARAMETER_COMPARISON_VALUE, itemValueParameter);
  
      // Make the default parameters the default values for the DataFilter.
      // Non-null comparison values must be specified for the DataFilter to be processed properly
      // by the query.
      variableSettingDataFilter.setCmpValue (strDefaultValue);
    }
  }

  /**
   * Update <code>DataFilter</code> parameter comparison values.
   * 
   * @param topBottomDataFilter A <code>TopBottomDataFilter</code>
   * @param strParamName A <code>String</code>
   * @param nDefaultValue A <code>int</code>
   * 
   * @status new
   */
  public static void updateParameters (TopBottomDataFilter topBottomDataFilter, String strParamName, int nDefaultValue) {
    updateParameters (topBottomDataFilter, strParamName, nDefaultValue, false);
  }

  /**
   * Update <code>DataFilter</code> parameter comparison values.
   * 
   * @param topBottomDataFilter A <code>TopBottomDataFilter</code>
   * @param strParamName A <code>String</code>
   * @param nDefaultValue A <code>int</code>
   * @param bAcceptMultipleValues A <code>boolean</code>
   * 
   * @status new
   */
  public static void updateParameters (TopBottomDataFilter topBottomDataFilter, 
      String strParamName, int nDefaultValue, boolean bAcceptMultipleValues) {
    
    if ((topBottomDataFilter != null) && (strParamName != null)) {
      
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamName, topBottomDataFilter.getItem());
      
      itemValueParameter.setDefaultValue (new Integer (nDefaultValue));
      itemValueParameter.setAcceptMultipleValues (bAcceptMultipleValues);
      
      topBottomDataFilter.associateParameter (TopBottomDataFilter.PARAMETER_COMPARISON_VALUE, itemValueParameter);
  
      // Make the default parameter the default value for the DataFilter.
      topBottomDataFilter.setValue (nDefaultValue);
    }
  }

  /**
   * Update <code>RangeDataFilter</code> parameter comparison values.
   * 
   * @param rangeDataFilter A <code>RangeDataFilter</code>
   * @param strParamStartName A <code>String</code>
   * @param objStartValue A <code>Object</code>
   * @param strParamEndName A <code>String</code>
   * @param objEndValue A <code>Object</code>
   *
   * @status new 
   */
  public static void updateParameterStart (RangeDataFilter rangeDataFilter, String strParamStartName, Object objStartValue) {
    updateParameterStart (rangeDataFilter, strParamStartName, objStartValue, false);  
  }

  /**
   * Update <code>RangeDataFilter</code> parameter comparison values.
   * 
   * @param rangeDataFilter A <code>RangeDataFilter</code>
   * @param strParamStartName A <code>String</code>
   * @param objStartValue A <code>Object</code>
   * @param strParamEndName A <code>String</code>
   * @param objEndValue A <code>Object</code>
   * @param bAcceptMultipleValues A <code>boolean</code>
   *
   * @status new 
   */
  public static void updateParameterStart (RangeDataFilter rangeDataFilter, 
      String strParamStartName, Object objStartValue, boolean bAcceptMultipleValues) {
    
    if (rangeDataFilter != null) {
      if ((strParamStartName != null) && (objStartValue != null)) {
        // Create the parameter
        ItemValueParameter itemValueParameter = 
          new ItemValueParameter (strParamStartName, rangeDataFilter.getItem());
        
        itemValueParameter.setDefaultValue (objStartValue);
        itemValueParameter.setAcceptMultipleValues (bAcceptMultipleValues);
      
        rangeDataFilter.associateParameter (RangeDataFilter.PARAMETER_START_VALUE, itemValueParameter);
  
        // Make the default parameters the default values for the DataFilter.
        rangeDataFilter.setStartValue (objStartValue);
      }
    }
  }

  /**
   * Update <code>RangeDataFilter</code> parameter comparison values.
   * 
   * @param rangeDataFilter A <code>RangeDataFilter</code>
   * @param strParamStartName A <code>String</code>
   * @param objStartValue A <code>Object</code>
   * @param strParamEndName A <code>String</code>
   * @param objEndValue A <code>Object</code>
   * 
   * @status new 
   */
  public static void updateParameterEnd (RangeDataFilter rangeDataFilter, String strParamEndName, Object objEndValue) {
    updateParameterEnd (rangeDataFilter, strParamEndName, objEndValue, false);
  }
    
  /**
   * Update <code>RangeDataFilter</code> parameter comparison values.
   * 
   * @param rangeDataFilter A <code>RangeDataFilter</code>
   * @param strParamStartName A <code>String</code>
   * @param objStartValue A <code>Object</code>
   * @param strParamEndName A <code>String</code>
   * @param objEndValue A <code>Object</code>
   * @param bAcceptMultipleValues A <code>boolean</code>
   *
   * @status new 
   */
  public static void updateParameterEnd (RangeDataFilter rangeDataFilter, 
      String strParamEndName, Object objEndValue, boolean bAcceptMultipleValues) {
    
    if ((strParamEndName != null) && (objEndValue != null)) {
      // Create the parameter
      ItemValueParameter itemValueParameter = 
        new ItemValueParameter (strParamEndName, rangeDataFilter.getItem());
      
      itemValueParameter.setDefaultValue (objEndValue);
      itemValueParameter.setAcceptMultipleValues (bAcceptMultipleValues);
    
      rangeDataFilter.associateParameter (RangeDataFilter.PARAMETER_END_VALUE, itemValueParameter);

      // Make the default parameters the default values for the DataFilter.
      rangeDataFilter.setEndValue (objEndValue);
    }
  }

  public static String formatMember(Object member, String datatype, String formatMask, Locale locale, ErrorHandler eh) {
    if (MM.INTEGER.equals(datatype) ||
        MM.LONG.equals(datatype) ||
        MM.SHORT.equals(datatype)) {
      return formatNumber((Number)member, locale);
    }
    if (MM.DOUBLE.equals(datatype) ||
        MM.FLOAT.equals(datatype)) {
      return formatNumber((Number)member, locale);
    }
    if (MM.DATE.equals(datatype)) {
      BaseViewFormat bvf = new BaseViewFormat();
      bvf.setLocale(locale);
      bvf.setOracleDateFormat(formatMask);
      bvf.setErrorHandler(eh);
      java.util.Date javaDate = (java.util.Date)member;
      java.sql.Date sqlDate = new java.sql.Date(javaDate.getTime());
      return bvf.DateToString(sqlDate);
    }
    return member.toString();    
  }

  public static String formatMembers(Vector members, String datatype, String formatMask, Locale locale, ErrorHandler eh) {
    if (members != null) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < members.size(); i++) {
        if (i > 0) {
          sb.append(", ");
        }
        sb.append(formatMember(members.get(i), datatype, formatMask, locale, eh));
      }
      return sb.toString();
    }
    return null;
  }

  protected static String[] parseExpression (String strExpression, String strRegularExpression) {
    String[] strExpressions = null;
  
    if ((strExpression != null) && (strRegularExpression != null)) {
      strExpressions = strExpression.split (strRegularExpression);      
    }
    
    return strExpressions;
  }

  /**
   * Validates the specified Date using the default input/output date patterns and locale.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String validateDate (String strDateIn) throws ParseException {
    return validateDate (strDateIn, Locale.getDefault());
  }

  /**
   * Validates the specified Date using the format expected by Answers.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String validateDateAnswers (String strDateIn, Locale locale) throws ParseException {
    return validateDate (strDateIn, DataUtils.DEFAULT_EVAL_ANSWERS_INPUT_DATE, DataUtils.DEFAULT_EVAL_ANSWERS_OUTPUT_DATE, locale);
  }

  /**
   * Parses the specified Date using the format expected by Answers.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>Date</code> containing the output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static Date parseDateAnswers (String strDateIn, Locale locale) throws ParseException {
    SimpleDateFormat simpleDateFormat = 
      new SimpleDateFormat (DataUtils.DEFAULT_EVAL_ANSWERS_INPUT_DATE);

    return simpleDateFormat.parse (strDateIn);  
  }

  /**
   * Validates the specified Date using the default input/output date patterns.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String validateDate (String strDateIn, Locale locale) throws ParseException {
    return validateDate (strDateIn, DataUtils.DEFAULT_DATE_INPUT_DATE, DataUtils.DEFAULT_EVAL_ANSWERS_OUTPUT_DATE, locale);
  }

  /**
   * Validates the specified Date using the default input/output date patterns.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * @param strInputPattern A <code>String</code> representing the input date pattern.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String validateDate (String strDateIn, String strInputPattern, Locale locale) throws ParseException {
    String strOutputPattern = DataUtils.DEFAULT_EVAL_ANSWERS_OUTPUT_DATE;
    
    if (DataUtils.DEFAULT_DATE_INPUT_DATE_TIME.equals (strInputPattern)) {
      strOutputPattern = DEFAULT_EVAL_ANSWERS_OUTPUT_DATE_TIME;  
    }
    
    return validateDate (strDateIn, strInputPattern, strOutputPattern, locale);
  }

  /**
   * Validates the specified Date.
   *
   * @param strDateIn A <code>String</code> that represents the date to validate.
   * @param strInputPattern A <code>String</code> representing the input date pattern.
   * @param strOutputPattern A <code>String</code> representing the output date pattern.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   */
  public static String validateDate (String strDateIn, String strInputPattern, String strOutputPattern, Locale locale) throws ParseException {
    String strDateFormattedOut = null;
    SimpleDateFormat simpleDateFormat = null;
    Date date = null;

    if ((strDateIn != null) && (strInputPattern != null)) {
      simpleDateFormat = new SimpleDateFormat (strInputPattern, locale);
      
      // Create a Date object from the Date String
      if (simpleDateFormat != null) {
        date = (Date)simpleDateFormat.parse (strDateIn);
      }
  
      strDateFormattedOut = makeFormattedDate (date, strOutputPattern, locale);
    }

    return strDateFormattedOut;
  }

  /**
   * Generates a formatted date using the default output date patterns.
   *
   * @param date A <code>Date</code> to format.
   * @param strOutputPattern A <code>String</code> representing the output date pattern.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String makeFormattedDate (Date date, String strOutputPattern, Locale locale) throws ParseException {
    String strDateFormattedOut = null;
    SimpleDateFormat simpleDateFormat = null;

    if ((date != null) && (strOutputPattern != null)) {
      simpleDateFormat = new SimpleDateFormat (strOutputPattern);
      
      // Create a formatted Date String from the Date object
      if (simpleDateFormat != null) {
        strDateFormattedOut = simpleDateFormat.format (date);
      }
    }

    return strDateFormattedOut;
  }

  /**
   * Generates a formatted date using the default output date patterns.
   *
   * @param date A <code>Date</code> to format.
   * @param locale A <code>Locale</code>
   * 
   * @return <code>String</code> containing the formatted output date.
   * 
   * @throws ParseException if date string is invalid.
   * 
   * @see #validateDate(String,String,String,Locale)
   */
  public static String makeFormattedDate (Date date, Locale locale) throws ParseException {
    return makeFormattedDate (date, DataUtils.DEFAULT_EVAL_ANSWERS_OUTPUT_DATE, locale);
  }

  /**
   * Format the specified object 
   *
   * @param componentContext A <code>ComponentContext</code>
   * @param object A <code>Object</code> to format.
   * @param locale A <code>Locale</code>
   * 
   * @return
   */
  public static String format (ComponentContext componentContext, Object object, Locale locale) {
    String strObject = null;

    if (object instanceof Date) {
      try {
        strObject = makeFormattedDate ((Date)object, DataUtils.DEFAULT_DATE_OUTPUT_DATE, Locale.getDefault());
      }

      catch (ParseException parseException) {
      }
    }
    else {
      strObject = object.toString();

      // Check for MDObjects
      MDObject mdObject = getMDObject (componentContext, strObject);
      if (mdObject != null) {
        // Return the name instead of the ID
        strObject = mdObject.getName();
      }
    }  
 
    return strObject;
  }
}
