/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemDrillRequestingEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     01/17/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ItemDrillRequestingEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:14 kmchorto Exp $
 *  @author  bmoroze 
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.dss.dataSource.common;

import java.util.BitSet;
import oracle.dss.util.QDR;

/**
 * Informs listeners when an item drill operation is requested. A listener has the
 * option to veto the drill operation by calling the <code>consume</code>
 * method of this event. If a listener vetoes the operation, then subsequent
 * listeners are not notified and the operation is cancelled (that is, not
 * added to the pending operation queue).
 *
 * @status Documented
 */
public class ItemDrillRequestingEvent extends DrillRequestingEvent
{
    // Fully qualified targets on which to drill
    protected QDR[] m_targets = null;
    
    // javadoc from superclass
    public ItemDrillRequestingEvent(Object source, String item, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags)
    {
        super(source, item, null, drillPath, null, null, drillTarget, null, null, null);
        fl = new BitSet[] {flags};
        m_targets = target;
    }
    
    /**
     * Return the item being drilled.
     * 
     * @return The item being drilled
     * 
     * @status New
     */
    public String getItem()
    {
        return super.getDimension();
    }

    /**
     * Return the Item's members on which to drill
     * 
     * @return drilled members
     * 
     * @status new
     */
    public QDR[] getTargets()
    {
        return m_targets;
    }
    
    /**
     * Return the drill paths for this drill
     * 
     * @return drill paths
     * 
     * @status New
     */
    public String[] getDrillPaths()
    {
        return hier;
    }
    
    /**
     * Return the drill targets for this drill
     * 
     * @return drill targets
     * 
     * @status New
     */
    public String[] getDrillTargets()
    {
        return m_valueParent;
    }
}

