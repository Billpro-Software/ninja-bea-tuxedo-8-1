/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/Utils.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.datautil.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.directory.Attributes;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import oracle.bali.ewt.LWComponent;
import oracle.bali.ewt.border.BorderAdapter;
import oracle.bali.ewt.graphics.ImageUtils;
import oracle.bali.ewt.painter.SeparatorBorderPainter;
import oracle.bali.share.nls.StringUtils;

import oracle.dss.bicontext.BIFilter;
import oracle.dss.bicontext.BISearchResult;
import oracle.dss.bicontext.gui.DefaultDirTreeNode;
import oracle.dss.dataView.managers.ViewFormat;
import oracle.dss.datautil.DimensionMember;
import oracle.dss.datautil.gui.component.Size;
import oracle.dss.datautil.gui.dialog.MeasureListDialog;
import oracle.dss.datautil.gui.panel.MeasureListPanel;
import oracle.dss.datautil.gui.panel.StandardPanel;
import oracle.dss.datautil.query.DataUtils;
import oracle.dss.datautil.query.QueryBuilderUtils;
import oracle.dss.datautil.query.QueryUtils;
import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MetadataManagerSearchResultImpl;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.util.ErrorHandler;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.NumberFormatType;

import oracle.javatools.ui.plaf.IconicButtonUI;

/**
 * @hidden
 *
 * <pre>
 * Common GUI utilities.
 * </pre>
 *
 * @status hidden
 *
 * MODIFIED    (MM/DD/YY)
 *    bmoroze   07/19/07 - 
 *    jwtang    06/08/07 - 
 * 
 */
public class Utils extends QueryUtils {

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Common button initialization.
   * 
   * @param jButton A <code>JButton</code>
   * @param strText A <code>String</code>
   * @param icon A <code>Icon</code>
   * 
   * @status hidden
   */
  public static void initializeIconButton (JButton jButton, String strText, Icon icon) {
    jButton.setMnemonic (StringUtils.getMnemonicKeyCode (strText));
    jButton.setToolTipText (StringUtils.stripMnemonic (strText));
    jButton.setIcon (icon);
    IconicButtonUI.install( jButton );
  }

  /**
   * Convert <code>Size</code> object to equivalent <code>Dimension</code> 
   * swing version.
   * 
   * @param size A <code>Size</code> value to convert.
   *
   * @return <code>Dimension</code> object based on the specified
   *         <code>Size</code>.
   * 
   * @status new
   */
  public static Dimension getDimension(Size size) {
    Dimension dimension = null;

    if (size != null) {
      dimension = new Dimension((int)size.getWidth(), (int)size.getHeight());
    }

    return dimension;
  }

  /**
   * Convert <code>Dimension</code> swing object to equivalent <code>Size</code> 
   * version.
   * 
   * @param dimension A <code>Dimension</code> value to convert.
   *
   * @return <code>Size</code> object based on the specified
   *         <code>Dimension</code>.
   * 
   * @status new
   */
  public static Size getSize(Dimension dimension) {
    Size size = null;

    if (dimension != null) {
      size = new Size((int)dimension.getWidth(), (int)dimension.getHeight());
    }

    return size;
  }

  /**
   * @hidden
   * 
   * Retrieves a <code>ViewFormat</code> associated with the specified number type
   * and string.
   *
   * @param strNumberType A <code>String</code> which represents the number type.
   * @param strNumberString A <code>String</code> which represents the number format
   *        string.
   *
   * @return <code>ViewFormat</code> value assciated with the specified number
   *         type and string.
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * 
   * @see oracle.dss.dataView.managers.ViewFormat#UNKNOWN_PATTERN_STR
   * @see oracle.dss.dataView.managers.ViewFormat#ORACLE_PATTERN_STR
   * @see oracle.dss.dataView.managers.ViewFormat#BIBEANS_PATTERN_STR
   * 
   * @status hidden
   */
  public static ViewFormat getViewFormat(String strNumberType, 
                                         String strNumberString) {
    return getViewFormat(strNumberType, strNumberString, Locale.getDefault());
  }

  /**
   * @hidden
   * 
   * Retrieves a <code>ViewFormat</code> associated with the specified number type
   * and string.
   *
   * @param strNumberType A <code>String</code> which represents the number type.
   * @param strNumberString A <code>String</code> which represents the number format
   *        string.
   * @param locale A <code>Locale</code> used to specify the language used to format
   *        the number.
   *
   * @return <code>ViewFormat</code> value assciated with the specified number
   *         type and string.
   *
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_ORACLE
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_OEO
   * @see oracle.dss.util.NumberFormatType#NUMBER_FORMAT_TYPE_BIBEANS
   * 
   * @see oracle.dss.dataView.managers.ViewFormat#UNKNOWN_PATTERN_STR
   * @see oracle.dss.dataView.managers.ViewFormat#ORACLE_PATTERN_STR
   * @see oracle.dss.dataView.managers.ViewFormat#BIBEANS_PATTERN_STR
   * 
   * @status hidden
   */
  public static ViewFormat getViewFormat(String strNumberType, 
                                         String strNumberString, 
                                         Locale locale) {
    ViewFormat viewFormat = null;

    // Make sure that our type and string are non-null
    if ((strNumberType != null) && (strNumberString != null)) {
      int nNumberType = ViewFormat.UNKNOWN_PATTERN_STR;

      // Check to see if Oracle is specified
      if (strNumberType.equals(NumberFormatType.NUMBER_FORMAT_TYPE_ORACLE)) {
        nNumberType = ViewFormat.ORACLE_PATTERN_STR;
      }
      // Check to see if OEO is specified
      else if (strNumberType.equals(NumberFormatType.NUMBER_FORMAT_TYPE_OEO)) {
        nNumberType = ViewFormat.OEO_PATTERN_STR;
      }
      // Check to see if BIBeans is specified
      else if (strNumberType.equals(NumberFormatType.NUMBER_FORMAT_TYPE_BIBEANS)) {
        nNumberType = ViewFormat.BIBEANS_PATTERN_STR;
      }

      viewFormat = new ViewFormat(strNumberString, nNumberType);
      viewFormat.setLocale(locale);
    }

    return viewFormat;
  }

  /**
   * @hidden
   * Determines if the given condition step's levels are valid for the step's hierarchy.
   *
   * @param metadataManagerServices The <code>MetadataManagerServices</code> object from which to
   *                        retrieve the hierarchy.
   * @param conditionStep A <code>Condition Step</code> object containing levels.
   *
   * @return <code>true</code> if the levels are valid for the hierarchy;
   *         <code>false</code> if the levels are not valid for the hierarchy.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    public static boolean areLevelsValidForHierarchy (MetadataManagerServices metadataManagerServices,
                                                ConditionStep conditionStep) {
        Vector levels = conditionStep.getLevels();

        // "null" for levels indicates all levels.
        if (levels == null)
            return true;

        String strHierarchy = conditionStep.getHierarchy();
        if (strHierarchy != null) {
            try {
                MDHierarchy hierarchy =
                    metadataManagerServices.getHierarchyByUniqueID(strHierarchy);

                if (hierarchy != null) {
                    MDLevel[] hierarchyLevels = hierarchy.getLevels();
                    if (hierarchyLevels != null) {
                        MDLevel oldLevel;
                        int intNewLevel;
                        int intSize = levels.size();

                        for (int i=0; i<intSize; i++) {
                            oldLevel =
                                metadataManagerServices.getLevelByUniqueID((String)levels.elementAt(i));
                            intNewLevel =
                                MMUtilities._indexOfByName(hierarchyLevels, oldLevel);

                            // Nope, level not found by name.
                            if (intNewLevel > -1) {
                                // Replace the old level with the new level in the step.
                                levels.setElementAt(hierarchyLevels[intNewLevel].getUniqueID(), i);
                            }
                            else {
                                return false;
                            }
                        }

                    return true;
                    }
                }
            }
            catch (MetadataManagerException mme) {
                return false;
            }
        }

        return false;
    }
  */

  /**
   * @hidden
   * Retrieves the list of items in a combo box.
   *
   * @param cboList The <code>JComboBox</code> object from which to retrieve
   * the list of items.
   * @param listContents The vector in which to store the list of items.
   *
   * @return <code>true</code> if the list of items was retrieved successfully;
   * <code>false</code> if it was not.
   *
   * status hidden
   */
  public static boolean buildListContents(JComboBox cboList, 
                                          Vector listContents) {
    int nIndex = -1;

    if (cboList == null || listContents == null)
      return false;

    for (nIndex = 0; nIndex < cboList.getItemCount(); nIndex++)
      listContents.addElement(cboList.getItemAt(nIndex));

    return true;
  }

  /**
   * @hidden
   *
   * Center the component in the middle of the
   * invoking component.
   *
   * @param thisComponent reference to the component to center.
   */
  public static void centerComponent(Component thisComponent, 
                                     Component frame) {
    if (frame == null) {
      centerComponent(thisComponent);
    } else {
      Point NewPosition = new Point(0, 0);
      int intChildWidth = thisComponent.getSize().width;
      int intChildHeight = thisComponent.getSize().height;

      //System.out.println("frame.getSize().width: " + frame.getSize().width);
      //System.out.println("frame.getSize().height: " + frame.getSize().height);
      //System.out.println("frame.getLocationOnScreen().x: " + frame.getLocationOnScreen().x);
      //System.out.println("frame.getLocationOnScreen().y: " + frame.getLocationOnScreen().y);

      int intFrameWidth = frame.getSize().width;
      int intFrameHeight = frame.getSize().height;
      int intFrameLeft = frame.getLocationOnScreen().x;
      int intFrameTop = frame.getLocationOnScreen().y;

      NewPosition.x = (intFrameLeft + intFrameWidth / 2) - (intChildWidth / 2);
      NewPosition.y = 
          (intFrameTop + intFrameHeight / 2) - (intChildHeight / 2);

      thisComponent.setLocation(NewPosition.x, NewPosition.y);
    }
  }

  /**
   * @hidden
   *
   * Center the component in the middle of the
   * user's workspace.
   *
   * @param thisComponent reference to the component to center.
   */
  public static void centerComponent(Component thisComponent) {
    if (thisComponent == null)
      return;

    Point NewPosition = new Point(0, 0);
    int intChildWidth = thisComponent.getSize().width;
    int intChildHeight = thisComponent.getSize().height;

    int intScreenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
    int intScreenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

    NewPosition.x = (intScreenWidth - intChildWidth) / 2;
    NewPosition.y = (intScreenHeight - intChildHeight) / 2;

    thisComponent.setLocation(NewPosition.x, NewPosition.y);
  }

  /**
   * @hidden
   * Returns whether or not a Vector contains a given String.
   *
   * @param vSource the Vector containing the objects to test for.
   * @param strTarget the String to test for.
   *
   * @status hidden
   */
  public static boolean contains(Vector vSource, String strTarget) {
    for (Enumeration e = vSource.elements(); e.hasMoreElements(); ) {
      Object object = e.nextElement();
      if (object != null) {
        String strValue = object.toString();
        if (strValue != null) {
          if (strValue.equals(strTarget)) {
            return (true);
          }
        }
      }
    }

    return (false);
  }

  /**
   * @hidden
   * Returns whether or not a String array contains a given String.
   *
   * @param source the String array containing the objects to test for.
   * @param target the String to test for.
   *
   * @status hidden
   */
  public static boolean contains(String[] source, String target) {
    if ((source != null) && (target != null)) {
      for (int i = 0; i < source.length; i++) {
        if (source[i].equals(target)) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * @hidden
   * Returns whether or not a vector contains a StandardPanel
   *
   * @param s The StandandPanel.
   * @param v The Vector of StandardPanels;
   *
   * @return A boolean value indicating whether s is in v.
   *
   * @status hidden
   */
  public static boolean contains(StandardPanel s1, Vector v) {
    Object o;
    StandardPanel s2;

    for (Enumeration e = v.elements(); e.hasMoreElements(); ) {
      o = e.nextElement();
      if (o instanceof StandardPanel) {
        s2 = (StandardPanel)o;
        if (s1.getId().equals(s2.getId())) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * @hidden
   * Creates a separator.
   *
   * @param sepSize The <code>Dimension</code> object that encapsulates
   * the width and height of the spearator.
   *
   * @return The <code>LWComponent</code> object that represents the separator.
   *
   * @status hidden
   */
  public static LWComponent createSeparator(Dimension sepSize) {
    Border border = null;
    LWComponent separator = null;

    separator = new LWComponent();
    border = 
        new BorderAdapter(new SeparatorBorderPainter(1, false, SeparatorBorderPainter.ORIENTATION_TOP));

    separator.setBorder(border);

    separator.setMinimumSize(sepSize);
    separator.setPreferredSize(sepSize);
    separator.setMinimumSize(sepSize);

    return separator;
  }

  /**
   * @hidden
   * Returns a vector resulting from the difference between
   * the two given vectors.
   *
   * @param v1 The vector containing the old data.
   * @param v2 The vector containing the new data.
   * @param v3 The vector resulting from v1 - v2.
   *
   * @status hidden
   */
  public static void difference(Vector v1, Vector v2, Vector v3) {
    Object o;
    StandardPanel s;

    for (Enumeration e = v1.elements(); e.hasMoreElements(); ) {
      o = e.nextElement();
      if (o instanceof StandardPanel) {
        s = (StandardPanel)o;
        if (!contains(s, v2)) {
          v3.addElement(s);
        }
      }
    }
  }

  /**
   * 
   * @hidden
   * @param v1 The vector containing the old data.
   * @param v2 The vector containing the new data.
   * @param v3 The vector resulting from v2 - v1.
   * @param v4 The vector resulting from v1 - v2.
   *
   * @status hidden
   */
  public static void difference(Vector v1, Vector v2, Vector v3, Vector v4) {
    difference(v1, v2, v3);
    difference(v2, v1, v4);
  }

  /**
   * @hidden
   * Loops up the hierarchy, trying to find the parent Dialog.
   *
   * @param parentComp reference to the Container component.
   */
  public static Dialog findParentDialog(Component parentComp) {
    while (parentComp != null) {
      if (parentComp instanceof Dialog) {
        return (Dialog)parentComp;
      } else {
        parentComp = parentComp.getParent();
      }
    }
    return null;
  }

  /**
   * @hidden
   * Loops up the hierarchy, trying to find the parent Frame.
   *
   * @param parentComp reference to the Container component.
   */
  public static Frame findParentFrame(Component parentComp) {
    while (parentComp != null) {
      if (parentComp instanceof Frame) {
        return (Frame)parentComp;
      } else {
        parentComp = parentComp.getParent();
      }
    }
    return null;
  }

  /**
   * @hidden
   * Loops up the hierarchy, trying to find the parent Window.
   *
   * @param parentComp reference to the Container component.
   */
  public static Window findParentWindow(Component parentComp) {
    while (parentComp != null) {
      if (parentComp instanceof Window) {
        return (Window)parentComp;
      } else {
        parentComp = parentComp.getParent();
      }
    }
    return null;
  }

  /**
   * @hidden
   * Retrieves the text for the supported components i.e. JLabel and JRadioButton.
   *
   * @return The text associated with the component, null otherwise.
   *
   * @status hidden
   */
  public static String getComponentText(JComponent component) {
    if (component == null)
      return null;

    if (component instanceof JLabel) {
      return ((JLabel)component).getText();
    }

    if (component instanceof JRadioButton) {
      // The actual width of the radio button is more than the text.
      // We use the word "Buffer" to make up for the loss.
      return ((JRadioButton)component).getText() + "Buffer";
    }

    if (component instanceof JTextComponent) {
      return ((JTextComponent)component).getText();
    }

    return null;
  }

  /**
   * @hidden
   * Accesses an image file from the same location (with an optional
   * relative path) where this class was loaded from (e.g. applet via http 
   * or application and directory).
   *
   * @param  targetObject An <code>object</code> that specifies the target
   *                      for loading the image.    
   *
   * @param  strName      A <code>String</code> value that specifies 
   *                      the resources name to retrieve.
   *
   * @return <code>Image</code> which represents the image associated with
   *         the specified name.
   *
   * @status hidden
   */
  public static Image getImageResource(Component targetObject, 
                                       String strName) {
    Image image = null;

    if (targetObject == null || strName == null) {
      return null;
    }

    try {
      image = ImageUtils.getImageResource(targetObject.getClass(), strName);
    }

    catch (Exception e) {
      System.out.println("Exception loading image (" + strName + ") excep = " + 
                         e);
    }

    return image;
  }

  /**
   * @hidden
   * Accesses an image file from the same location (with an optional
   * relative path) where this class was loaded from (e.g. applet via http 
   * or application and directory).
   *
   * @param  thisClass    An <code>class</code> that specifies the target
   *                      for loading the image.    
   *
   * @param  strName      A <code>String</code> value that specifies
   *                      the resources name to retrieve.
   *
   * @return <code>Image</code> which represents the image associated with
   *         the specified name.
   *
   * @status hidden
   */
  public static Image getImageResource(Class thisClass, String strName) {
    Image image = null;

    try {
      image = ImageUtils.getImageResource(thisClass, strName);
    }

    catch (Exception e) {
      System.out.println("Exception loading image (" + strName + ") excep = " + 
                         e);
    }

    return image;
  }

  /**
   * @hidden
   * Retrieves the value element for the specified key element from the
   * <code>DataUtilBundle</code> object.
   * For example, for a key element "btnOK", it
   * might retrieve the value element "OK".
   *
   * @param strKey The key element whose value is to be retrieved.
   *
   * @return The value element of the specified key element.
   *
   * @status hidden
   */
  public static String getIntlString(String strKey, Locale locale) {
    try {
      ResourceBundle resources = 
        ResourceBundle.getBundle("oracle.dss.datautil.gui.resource.DataUtilGUIBundle", 
                                 locale);

      if (resources == null)
        return strKey;

      String strResource = resources.getString(strKey);
      return strResource;
    } catch (MissingResourceException e) {
      return strKey;
    }
  }

  /**
   * @hidden
   * Retrieves the index of a specified item from a list of
   * <code>DimensionMember</code> objects.
   *
   * @param listContents The vector of <code>DimensionMember</code> objects to search.
   * @param strSearchDimId The name of the item whose index is to be
   * retrieved.
   *
   * @return The index of the specified item.
   *
   * @status hidden
   */
  public static int getSelectedIndex(Vector listContents, 
                                     String strSearchDimId) {
    int nIndex = -1;
    Object listMember = null;
    DimensionMember dimMember = null;

    for (nIndex = 0; nIndex < listContents.size(); nIndex++) {
      listMember = listContents.elementAt(nIndex);
      if (!(listMember instanceof DimensionMember))
        continue;

      dimMember = (DimensionMember)listMember;
      if (strSearchDimId.equalsIgnoreCase(dimMember.getDimMemberID()))
        return nIndex;
    }

    return -1;
  }

  /**
   * @hidden
   * Returns the index of the given StandardPanel in the vector of StandardPanels.
   *
   * @param s The StandandPanel.
   * @param v The Vector of StandardPanels.
   *
   * @return The index of s in v.
   *
   * @status hidden
   */
  public static int indexOf(StandardPanel s1, Vector v) {
    Object o;
    StandardPanel s2;

    for (int i = 0; i < v.size(); i++) {
      o = v.elementAt(i);
      if (o instanceof StandardPanel) {
        s2 = (StandardPanel)o;
        if (s1.getId().equals(s2.getId())) {
          return i;
        }
      }
    }

    return -1;
  }

  /**
   * @hidden
   * Returns the index of the specified object in a JComboBox.
   *
   * @param cboSource the JComboBox.
   * @param objTarget the object to look for.
   * @return int the index of the object.
   * @status hidden
   */
  public static int indexOf(JComboBox cboSource, Object objTarget) {
    int intIndex = -1;
    if ((cboSource != null) && (objTarget != null)) {
      int intMax = cboSource.getItemCount();
      Object objCurrent;
      String strTarget = objTarget.toString();

      // Loop through all objects.
      for (int i = 0; i < intMax; i++) {
        objCurrent = cboSource.getItemAt(i);
        if ((objCurrent.toString()).equals((strTarget))) {
          intIndex = i;
          break;
        }
      }
    }

    return intIndex;
  }

  /**
   * @hidden
   * Returns the index of the last instance of the specified Class
   *
   * @param cboSource the JComboBox.
   * @param className the Class to look for.
   * @return int the index of the last instance.
   * @status hidden
   */
  public static int lastIndexOf(JComboBox cboSource, Class className) {
    int intLastIndex = -1;
    if ((cboSource != null) && (className != null)) {
      int intMax = cboSource.getItemCount();
      // Loop through all objects.
      for (int i = intMax - 1; i >= 0; i--) {
        if (cboSource.getItemAt(i).getClass() == className) {
          intLastIndex = i;
          break;
        }
      }
    }
    return intLastIndex;
  }

  /**
   * @hidden
   * Returns the index of the specified String in a JComboBox.
   *
   * @param cboSource the JComboBox.
   * @param strValue the String to look for.
   * @return int the index of the String.
   * @status hidden
   */
  public static int indexOfString(JComboBox cboSource, String strValue) {
    if ((cboSource != null) && (strValue != null)) {
      int intMax = cboSource.getItemCount();
      Object objCurrent;

      for (int i = 0; i < intMax; i++) {
        objCurrent = cboSource.getItemAt(i);
        // For the DimensionMember, we want to check if its internal
        // ID matches the string, not its display value.
        if (objCurrent instanceof DimensionMember) {
          DimensionMember dimValue = (DimensionMember)objCurrent;
          if ((dimValue.getDimMemberID()).equals((strValue))) {
            return i;
          }
        } else if ((objCurrent.toString()).equals((strValue))) {
          return i;
        }
      }
    }
    return -1;
  }

  /**
   * @hidden
   * Returns the index of the specified String in a Vector.
   *
   * @param vector the Vector.
   * @param strValue the String to look for.
   * @return int the index of the String.
   * @status hidden
   */
  public static int indexOfString(Vector vector, String strValue) {
    if ((vector != null) && (strValue != null)) {
      int intMax = vector.size();
      Object objCurrent;

      for (int i = 0; i < intMax; i++) {
        objCurrent = vector.elementAt(i);
        // For the DimensionMember, we want to check if its internal
        // ID matches the string, not its display value.
        if (objCurrent instanceof DimensionMember) {
          DimensionMember dimValue = (DimensionMember)objCurrent;
          if ((dimValue.getDimMemberID()).equals((strValue))) {
            return i;
          }
        } else if ((objCurrent.toString()).equals((strValue))) {
          return i;
        }
      }
    }
    return -1;
  }


  /**
   * @hidden
   * Replaces all instances of the source string by the target string
   *
   * @param strParse The string containing the source string.
   * @param strSource The string to replace.
   * @param strTarget The string to replace the source string with.
   *
   * @return The resulting string after the operation.
   *
   * @status hidden
   */
  public static String replace(String strParse, String strSource, 
                               String strTarget) {
    int nIndex = -1;
    String strParseCopy = null;
    String strSearch = null;

    if (strParse == null || strSource == null || strTarget == null)
      return null;

    strParseCopy = new String();
    strSearch = new String(strParse);

    while (true) {
      nIndex = strSearch.indexOf(strSource);
      if (nIndex < 0) {
        strParseCopy = strParseCopy.concat(strSearch);
        break;
      }

      strParseCopy = strParseCopy.concat(strSearch.substring(0, nIndex));
      strParseCopy = strParseCopy.concat(strTarget);

      strSearch = strSearch.substring(nIndex + strSource.length());
    }

    return strParseCopy;
  }

  // Sets the borders for components of this container object.

  public static void setBorders(Container target) {
    int intChildren = target.getComponentCount();

    // Apply standard border around JComponent.
    for (int i = 0; i < intChildren; i++) {
      Component c = target.getComponent(i);
      if (c instanceof Container) {
        setBorders((Container)c);
      }
      if (c instanceof JComponent) {
        ((JComponent)c).setAlignmentX(Component.LEFT_ALIGNMENT);

        if (c instanceof JLabel) {
          ((JLabel)c).setBorder(new EmptyBorder(0, 0, 3, 10));
        }
      }
    }
  }

  /**
   * @hidden
   * Finds the parent Window of the given component, and sets the cursor to 
   * the given cursor.    
   *
   * @param comp reference to the component contained in the Window
   * @param predefCursor int constant for the predefined cursor, constants can 
   *        be found in java.awt.Frame
   */
  public static void setParentWindowCursor(Component comp, int predefCursor) {
    // Find parent Window
    if (comp != null) {
      Window parentWindow = SwingUtilities.windowForComponent(comp);

      if (parentWindow != null) {
        // Set the cursor on the parent Window
        parentWindow.setCursor(Cursor.getPredefinedCursor(predefCursor));
      } else {
        // Set the cursor on the component
        comp.setCursor(Cursor.getPredefinedCursor(predefCursor));
      }
    }
  }

  /**
   * @hidden
   * Displays the dialog for showing dimension members.
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }*/

  /**
   * @hidden
   * Displays the dialog for showing dimension members.
   *
   * @param parent The parent Dialog.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Dialog parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog(parent, guiContext, strDimension, strHierarchy,
                strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }*/

  /**
   * @hidden
   * Displays the dialog for showing dimension members.
   *
   * @param parent The parent Frame.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*static public DimensionMember showMemberListDialog (
                                  Frame parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog(parent, guiContext, strDimension, strHierarchy,
                strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Dialog.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Dialog parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                null, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Frame.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Frame parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                null, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Dialog.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Dialog parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Frame.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Frame parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection,
                                  boolean blnMoreEnabled)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Dialog.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Dialog parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }*/

  /**
   * Displays the dialog for showing dimension members.
   *
   * @hidden
   *
   * @param parent The parent Frame.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @status hidden
   */
  // blm - step code moved to dvt-olap
  /*    static public DimensionMember showMemberListDialog (
                                  Frame parent,
                                  GuiContext guiContext,
                                  String strDimension,
                                  String strHierarchy,
                                  Vector vLevels,
                                  String strShowMeasureMode,
                                  String strDisplayLabel,
                                  String strTitle,
                                  String strDescription,
                                  Component centerOver,
                                  BIFilter filter,
                                  String strInitialSelection)
        {
        return showMemberListDialog((Window)parent, guiContext, strDimension, strHierarchy,
                vLevels, strShowMeasureMode, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSelection, false);
        }
  */
  /**
   * Displays the dialog for showing dimension members.
   *
   * @param parent The parent Window.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strShowMeasureMode The show measure mode property.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @hidden
   */
  // blm - step code moved to dvt-olap
  /*    static private DimensionMember showMemberListDialog (
                                   Window parent,
                                   GuiContext guiContext,
                                   String strDimension,
                                   String strHierarchy,
                                   Vector vLevels,
                                   String strShowMeasureMode,
                                   String strDisplayLabel,
                                   String strTitle,
                                   String strDescription,
                                   Component centerOver,
                                   BIFilter filter,
                                   String strInitialSelection,
                                   boolean blnMoreEnabled)
        {
        boolean bRetVal = false;

        if (guiContext == null          ||
            strDimension == null        ||
            strDimension.length() == 0  ||
            guiContext.getMetadataManager() == null)
            {
            return null;
            }

        bRetVal =
            DataUtils.isMeasureDimension ("", guiContext.getMetadataManager (),
                strDimension);

        if (strShowMeasureMode == null)
            {
            strShowMeasureMode = BuilderContext.APPLY_MEASURE_FILTER;
            }

        if ((bRetVal) && (strShowMeasureMode.equals (BuilderContext.APPLY_MEASURE_FILTER)))
            {
            return showMeasureDimensionMemberListDialog (parent, guiContext,
                strDimension, strDisplayLabel, strTitle, strDescription,
                    centerOver, filter, strInitialSelection);
            }
        else
            {
            return showDimensionMemberListDialog (parent, guiContext,
                strDimension, strHierarchy, vLevels, strDisplayLabel, strTitle, strDescription,
                    centerOver, filter, strInitialSelection, blnMoreEnabled);
            }
        }
*/

  /**
   * @hidden
   * Makes all the specified components of the same width
   *
   * @param listComponents The list of components to be made the same width.
   *
   * @status hidden
   */
  public static void updateComponentWidth(Vector listComponents) {
    JComponent component = null;
    Dimension compSize = null;
    int nIndex = -1;
    int nCurCompWidth = -1;
    int nMaxCompWidth = -1;
    Object compObject = null;
    String strText = null;

    if (listComponents == null || listComponents.size() == 0)
      return;

    nMaxCompWidth = nCurCompWidth = 0;

    // Determine the maximum width of the component text
    for (nIndex = 0; nIndex < listComponents.size(); nIndex++) {
      compObject = listComponents.elementAt(nIndex);
      if (compObject == null || !(compObject instanceof JComponent))
        continue;

      component = (JComponent)compObject;

      strText = getComponentText(component);
      if (null == strText)
        continue;

      nCurCompWidth = 
          component.getToolkit().getFontMetrics(component.getFont()).stringWidth(strText);

      if (nCurCompWidth > nMaxCompWidth)
        nMaxCompWidth = nCurCompWidth;
    }

    // Add some blank space for legibility
    nMaxCompWidth += 3;

    // Set the height of all the components in the list.
    for (nIndex = 0; nIndex < listComponents.size(); nIndex++) {
      compObject = listComponents.elementAt(nIndex);
      if (compObject == null || !(compObject instanceof JComponent))
        continue;

      component = (JComponent)compObject;

      compSize = 
          new Dimension(nMaxCompWidth, component.getPreferredSize().height);

      component.setMaximumSize(compSize);
      component.setMinimumSize(compSize);
      component.setPreferredSize(compSize);
    }
  }

  /**
   * @hidden
   * Returns the MDObject contained in this object.
   *
   * @return MDObject - MDObject in the object.
   * @status hidden
   */
  public static MDObject getMDObject(Object object) {
    object = getObject(object);
    if ((object != null) && (object instanceof MDObject)) {
      return (MDObject)object;
    }
    return null;
  }

  /**
   * @hidden
   * Returns the Object contained in this object.
   *
   * @return Object - Object in the object.
   * @status hidden
   */
  public static Object getObject(Object object) {
    if (object != null) {
      if (object instanceof DefaultMutableTreeNode) {
        return getObject(((DefaultMutableTreeNode)object).getUserObject());
      }
      if (object instanceof BISearchResult) {
        return ((BISearchResult)object).getObject();
      }
      return object;
    }
    return null;
  }

  /**
   * @hidden
   * Returns the type of the given object.
   *
   * @return String - The type.
   * @status new
   */
  public static String getObjectType(Object object) {
    if (object != null) {
      if (object instanceof DefaultMutableTreeNode) {
        return getObjectType(((DefaultMutableTreeNode)object).getUserObject());
      }
      if (object instanceof MDObject) {
        return ((MDObject)object).getObjectType();
      }
      if (object instanceof BISearchResult) {
        return ((BISearchResult)object).getObjectType();
      }
    }
    return null;
  }

  /*
   * @hidden
   *
   * Retrieves the label representation of the object based on the underlying
   * display member label type.
   *
   * @param object A <code>Object</code> to retrieve the string representation
   *        for.
   * @param strDisplayType A <code>String</code> that contains the
   *        display member label type.
   *
   * @return <code>String</code> which contains the label representation of the
   *         specified <code>Object</code>.
   *
   * @status hidden
   */
  public static String toString(Object object, String strDisplayType) {
    return toString(object, strDisplayType, null);
  }

  /*
   * @hidden
   *
   * Retrieves the label representation of the object based on the underlying
   * display member label type.
   *
   * @param object A <code>Object</code> to retrieve the string representation
   *        for.
   * @param strDisplayType A <code>String</code> that contains the
   *        display member label type.
   * @param metadataManagerServices A <code>MetadataManagerServices</code>
   *        value used to retrieve metadata.
   *
   * @return <code>String</code> which contains the label representation of the
   *         specified <code>Object</code>.
   *
   * @status hidden
   */
   public static String toString(Object object, String strDisplayType, 
                                MetadataManagerServices metadataManagerServices) {
    if (object != null) {
      if (object instanceof DefaultDirTreeNode) {
        return toString(((DefaultDirTreeNode)object).getSearchResult(), 
                        strDisplayType, metadataManagerServices);
      }

      if (object instanceof DefaultMutableTreeNode) {
        return toString(((DefaultMutableTreeNode)object).getUserObject(), 
                        strDisplayType, metadataManagerServices);
      }

      if (object instanceof MDObject) {
        return ((MDObject)object).toString(strDisplayType);
      }

      if (object instanceof BISearchResult) {
        if (object instanceof MetadataManagerSearchResultImpl) {
          String strType = 
            ((MetadataManagerSearchResultImpl)object).getObjectType();

          /** gek 11/03/06
            if (MM.CALCULATION.equals (strType)) {
              // gek 10/10/03 Add support for ShortCuts
              //
              // If necessary, update the attributes to reflect those of the
              // target when a shortcut is specified
              Attributes attributes =
                DataUtils.getShortCutAttributes ((BISearchResult) object, metadataManagerServices);

              return MDCalcAttributes.getLabel (attributes, strDisplayType, null);
            }
            else if ( (MM.FOLDER.equals(strType)) || (MM.SELECTION.equals(strType)) ) {
              return ((BISearchResult)object).getLabel();
            }
            */
          if ((MM.FOLDER.equals(strType)) || (MM.SELECTION.equals(strType))) {
            return ((BISearchResult)object).getLabel();
          }
        }

        return toString(((BISearchResult)object).getObject(), strDisplayType);
      }
    }

    return null;
  }

  /**
   * @hidden
   *
   * Retrieves the label representation of the object based on the underlying
   * display member label type.
   *
   * @param object A <code>Object</code> to retrieve the string representation
   *        for.
   * @param componentContext A <code>ComponentContext</code> that contains the
   *        underlying display member label type and <code>MetadataManager</code>.
   *
   * @return <code>String</code> which contains the label representation of the
   *         specified <code>Object</code>.
   *
   * @status hidden
   */
  public static String toString(Object object, 
                                ComponentContext componentContext) {
    String strObjectType = getObjectType(object);

    if ((MM.MEASURE.equals(strObjectType)) || 
        (MM.CALCULATION.equals(strObjectType))) {
      return toString(object, componentContext.getDisplayMemberLabelType(), 
                      componentContext.getMetadataManager());
    }

    return toString(object, componentContext.getDisplayLabelType(), 
                    componentContext.getMetadataManager());
  }

  /**
   * @hidden
   *
   * Retrieves the <code>MetadataManager</code> unique runtime ID associated
   * with the specified <code>Object</code>.
   *
   * @param object A <code>Object</code> to retrieve the <code>MetadataManager</code>
   *        unique runtime ID.
   * @param blnLoadShortcut Used to determine if a shortcut's object should be loaded
   *        and its id returned, or if the id of the shortcut's id should be returned.
   * @param errorHandler A <code>ErrorHandler</code> used to process errors.
   *
   * @return <code>String</code> which contains the <code>MetadataManager</code>
   * unique runtime ID associated with the specified <code>Object</code>.
   *
   * @status hidden
   */
  public static String getUniqueID(Object object, boolean blnLoadShortcut, 
                                   ErrorHandler errorHandler) {
    String strUniqueID = null;

    if (object != null) {
      if (object instanceof DefaultMutableTreeNode) {
        strUniqueID = 
            getUniqueID(((DefaultMutableTreeNode)object).getUserObject(), 
                        errorHandler);
      } else if (object instanceof MDObject) {
        strUniqueID = ((MDObject)object).getUniqueID();
      } else if (object instanceof BISearchResult) {
        try {
          // Retrieve the attributes associated with the BISearchResult
          Attributes attributes = ((BISearchResult)object).getAttributes();
          if (attributes != null) {
            // Determine if this object represents a short cut
            if ((blnLoadShortcut) && (DataUtils.isShortCut(attributes))) {
              // Retrieve the shortcut's target MDObject
              MDObject mdObject = 
                (MDObject)((BISearchResult)object).getObject();
              if (mdObject != null) {
                strUniqueID = mdObject.getUniqueID();
              }
            } else {
              /** gek 11/03/06
                // Attempt to retrieve the MetadataManager unique ID from
                // attributes.
                strUniqueID =
                  MDCalcAttributes.getUniqueID (attributes, errorHandler);
                */
            }
          }
        }

        catch (Exception e) {
          e.printStackTrace();
        }
      }
    }

    return strUniqueID;
  }

  /**
   * @hidden
   *
   * Retrieves the <code>MetadataManager</code> unique runtime ID associated
   * with the specified <code>Object</code>.
   *
   * @param object A <code>Object</code> to retrieve the <code>MetadataManager</code>
   *        unique runtime ID.
   * @param errorHandler A <code>ErrorHandler</code> used to process errors.
   *
   * @return <code>String</code> which contains the <code>MetadataManager</code>
   * unique runtime ID associated with the specified <code>Object</code>.
   *
   * @status hidden
   */
  public static String getUniqueID(Object object, ErrorHandler errorHandler) {
    return getUniqueID(object, true, errorHandler);
  }

  public static MDDimension[] getDimensions(Object object, 
                                            MetadataManagerServices metadataManagerServices, 
                                            ErrorHandler errorHandler) {
    if (object != null) {
      if (object instanceof DefaultMutableTreeNode) {
        return getDimensions(((DefaultMutableTreeNode)object).getUserObject(), 
                             metadataManagerServices, errorHandler);
      }
      if (object instanceof MDMeasure) {
        try {
          return ((MDMeasure)object).getDimensions();
        } catch (MetadataManagerException mme) {
          errorHandler.error(mme, "Utils", "getDimensions");
        }
      }
      if (object instanceof BISearchResult) {
        String strObjectType = getObjectType(object);
        /** gek 11/03/06
                if (MM.CALCULATION.equals(strObjectType)) {
                    return MDCalcAttributes.getDimensions(metadataManagerServices, ((BISearchResult)object).getAttributes(), errorHandler);
                }
                */

        if (MM.MEASURE.equals(strObjectType)) {
          return getDimensions(getObject(object), metadataManagerServices, 
                               errorHandler);
        }
      }
    }
    return null;
  }

  //-------------------------------------------------------------------
  // NON PUBLIC METHODS
  //-------------------------------------------------------------------

  /**
   * Displays the dialog for showing dimension members of non "measure dimension"
   * measures.
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   */
  // blm - step code moved to dvt-olap
  /*    static protected DimensionMember showDimensionMemberListDialog (
                                     GuiContext guiContext,
                                     String strDimension,
                                     String strHierarchy,
                                     String strDisplayLabel,
                                     String strTitle,
                                     String strDescription,
                                     Component centerOver,
                                     BIFilter filter,
                                     String strInitialSel,
                                     boolean blnMoreEnabled)
        {
        return showDimensionMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                null, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSel, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members of non "measure dimension"
   * measures.
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   */
  // blm - step code moved to dvt-olap
  /*    static protected DimensionMember showDimensionMemberListDialog (
                                     GuiContext guiContext,
                                     String strDimension,
                                     String strHierarchy,
                                     Vector vLevels,
                                     String strDisplayLabel,
                                     String strTitle,
                                     String strDescription,
                                     Component centerOver,
                                     BIFilter filter,
                                     String strInitialSel,
                                     boolean blnMoreEnabled)
        {
        return showDimensionMemberListDialog((Frame)null, guiContext, strDimension, strHierarchy,
                vLevels, strDisplayLabel, strTitle, strDescription,
                centerOver, filter, strInitialSel, blnMoreEnabled);
        }*/

  /**
   * Displays the dialog for showing dimension members of non "measure dimension"
   * measures.
   *
   * @param parent The parent Window.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * @param strHierarchy The hierarchy associated with the dimension.
   * @param vLevels The levels associated with the hierarchy.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param filter The filter for the displayed list.
   * @param strInitialSel The initial selection for the list of dimension members.
   * @param blnMoreEnabled True if "More..." should be displayed
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   */
  // blm - step code moved to dvt-olap
  /*    static private DimensionMember showDimensionMemberListDialog (
                                    Window parent,
                                    GuiContext guiContext,
                                    String strDimension,
                                    String strHierarchy,
                                    Vector vLevels,
                                    String strDisplayLabel,
                                    String strTitle,
                                    String strDescription,
                                    Component centerOver,
                                    BIFilter filter,
                                    String strInitialSel,
                                    boolean blnMoreEnabled)
        {
        boolean                 bResetCursor    = false;
        Cursor                  waitCursor      = null;
        DimensionListDialog     dimListDlg      = null;
        OLAPDimensionListPanel  dimListPanel    = null;
        DimensionMember         dimMember       = null;
        DimensionMember         dimension       = null;
        Frame                   parentFrame     = null;
        int                     nRetVal         = -1;
        String                  strSelectedItem = null;

        if (guiContext == null                      ||
            strDimension == null                    ||
            strDimension.length() == 0              ||
            guiContext.getMetadataManager() == null ||
            guiContext.getQueryContext() == null)
            {
            return null;
            }

        // Default to the long label
        if (strDisplayLabel == null)
        {
            strDisplayLabel =LayerMetadataMap.LAYER_METADATA_LONGLABEL;
        }
        else
        {
            strDisplayLabel = DataUtils.mapToMetadataMapType(strDisplayLabel);
        }


        if (centerOver != null)
            parentFrame = findParentFrame (centerOver);

        // Set the wait cursor.
        waitCursor = Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR);
        if (parentFrame != null && parentFrame.getCursor () != waitCursor)
            {
            parentFrame.setCursor (waitCursor);
            bResetCursor = true;
            }

        QueryAccessUtilities qau =
            new QueryAccessUtilities(guiContext.getQueryContext().createQueryAccess(),
                null, guiContext.getMetadataManager().getErrorHandler());

        QueryAccessDimensionModel qadm =
            new QueryAccessDimensionModel (qau, strDimension, strHierarchy, vLevels,
                guiContext.getMetadataManager());

        if (parent instanceof Dialog) {
            dimListDlg = new DimensionListDialog((Dialog)parent, qadm, centerOver, true);
        }
        else if (parent instanceof Frame) {
            dimListDlg = new DimensionListDialog((Frame)parent, qadm, centerOver, true);
        }
        else {
            dimListDlg = new DimensionListDialog((Frame)null, qadm, centerOver, true);
        }
        if (guiContext instanceof ComponentContext) {
          ComponentContext componentContext = (ComponentContext)guiContext;
          dimListDlg.getDimensionListPanel().setLabelType(componentContext.getDisplayMemberLabelType());

          // gek 12/10/03 Fix Bug 3274067: Error using non-hierarchical dimension
          //              in share calc.
          //
          //              Make sure that we check for situations where a hierarchy
          //              might not be present.

          //              This can occur for instance when a measure such as Budget
          //              is dimensioned by dimensions like Division and Line Items
          //              that contain no hierarchy but represent valid scenarios.
          HierLevelComponent hierLevelComponent =
            dimListDlg.getDimensionListPanel().getHierLevelComponent();

          if (hierLevelComponent != null) {
            hierLevelComponent.setDisplayLabelType (componentContext.getDisplayLabelType());
          }

          if (componentContext instanceof BuilderContext) {
            BuilderContext builderContext = (BuilderContext)componentContext;
            dimListDlg.setHelpProvider(builderContext.getHelpProvider());
            dimListDlg.setLocale(builderContext.getLocale());
          }
        }

        // gek 08/26/01 Fix Bug 1920289: Index calculation GUI does not match
        //              design.  Add ability to specify hierarchy.
           // dimListDlg.setHelpProvider(guiContext.getHelpProvider());
                dimListDlg.getDimensionListPanel().setHierarchy(strHierarchy);
           // dimListDlg.setLocale(guiContext.getLocale());
        dimListDlg.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        dimListPanel = dimListDlg.getDimensionListPanel ();
        // dimListPanel.getDimensionList().setModel(qadm);

        if (dimListPanel != null)
            {
            dimListPanel.setCountLabelVisible (false);
            // Allow user to modify hierarchy
            dimListPanel.setToolbarVisible (true);
            dimListPanel.setHierarchyVisible (true);
            HierLevelComponent hierLevelComponent =
              dimListPanel.getHierLevelComponent();

            if (hierLevelComponent != null) {
              hierLevelComponent.setMoreEnabled (blnMoreEnabled);
            }

            if (strDescription != null)
                dimListPanel.setDescription (strDescription);

            if (strTitle != null)
                dimListDlg.setTitle (strTitle);
            }

        // Set the default cursor.
        if (parentFrame != null && bResetCursor)
            {
            parentFrame.setCursor (
                Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
            bResetCursor = false;
            }

        if (dimListPanel == null)
            return null;

        // Display the dialog.
        nRetVal = dimListDlg.display ();
        if (nRetVal == StandardDialog.CANCEL)
        {
            qau.getQueryAccess().release();
            return null;
        }

        //strSelectedItem = dimListPanel.getSelectedMember ();
        strSelectedItem = dimListDlg.getSelectedMemberUsingDataAccess(qadm.getDataAccess());

        // gek 08/26/01 Fix Bug 1920289: Index calculation GUI does not match design.
        //              Add ability to specify hierarchy.
        String strTargetType =
          dimListDlg.getSelectedMemberUsingDataAccess(qadm.getDataAccess(), strDisplayLabel);

        strHierarchy =
          dimListDlg.getDimensionListPanel().getHierarchy();

        String strLevelID = dimListDlg.getSelectedMemberUsingDataAccess(qadm.getDataAccess(), MetadataMap.METADATA_LEVEL);
        String strLevelName = dimListDlg.getSelectedMemberUsingDataAccess(qadm.getDataAccess(), MetadataMap.METADATA_LEVEL_NAME);

        dimMember =
          new DimensionMember(strSelectedItem, strTargetType, strHierarchy, strLevelID, strLevelName);

        qau.getQueryAccess().release();
        if (strSelectedItem == null || strSelectedItem.length() == 0)
            return null;

        // Set the wait cursor.
        if (parentFrame != null && parentFrame.getCursor () != waitCursor)
            {
            parentFrame.setCursor (waitCursor);
            bResetCursor = true;
            }

        // Set the default cursor.
        if (parentFrame != null && bResetCursor)
            {
            parentFrame.setCursor (
                Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));

            bResetCursor = false;
            }

        return dimMember;
        }
*/

  /**
   * @hidden
   * Displays the dialog for showing dimension members of "measure dimension"
   * only.
   *
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * This parameter is an Unique ID.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param listFilterDimensions The list of dimensions used for filtering the
   * displayed list of measures.
   * @param strInitialSel The initial selection for the list of dimension members.
   * This parameter is an OLAPI ID.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @return DimensionMember describing the
   */
  public static DimensionMember showMeasureDimensionMemberListDialog(GuiContext guiContext, 
                                                                     String strDimension, 
                                                                     String strDisplayLabel, 
                                                                     String strTitle, 
                                                                     String strDescription, 
                                                                     Component centerOver, 
                                                                     BIFilter filter, 
                                                                     String strInitialSel) {
    return showMeasureDimensionMemberListDialog((Frame)null, guiContext, 
                                                strDimension, strDisplayLabel, 
                                                strTitle, strDescription, 
                                                centerOver, filter, 
                                                strInitialSel);
  }

  /**
   * @hidden
   * Displays the dialog for showing dimension members of "measure dimension"
   * only.
   *
   * @param parent The parent Dialog.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * This parameter is an Unique ID.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param listFilterDimensions The list of dimensions used for filtering the
   * displayed list of measures.
   * @param strInitialSel The initial selection for the list of dimension members.
   * This parameter is an OLAPI ID.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @return DimensionMember describing the
   */
  public static DimensionMember showMeasureDimensionMemberListDialog(Dialog parent, 
                                                                     GuiContext guiContext, 
                                                                     String strDimension, 
                                                                     String strDisplayLabel, 
                                                                     String strTitle, 
                                                                     String strDescription, 
                                                                     Component centerOver, 
                                                                     BIFilter filter, 
                                                                     String strInitialSel) {
    return showMeasureDimensionMemberListDialog(parent, guiContext, 
                                                strDimension, strDisplayLabel, 
                                                strTitle, strDescription, 
                                                centerOver, filter, 
                                                strInitialSel);
  }

  /**
   * @hidden
   * Displays the dialog for showing dimension members of "measure dimension"
   * only.
   *
   * @param parent The parent Frame.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * This parameter is an Unique ID.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param listFilterDimensions The list of dimensions used for filtering the
   * displayed list of measures.
   * @param strInitialSel The initial selection for the list of dimension members.
   * This parameter is an OLAPI ID.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @return DimensionMember describing the
   */
  public static DimensionMember showMeasureDimensionMemberListDialog(Frame parent, 
                                                                     GuiContext guiContext, 
                                                                     String strDimension, 
                                                                     String strDisplayLabel, 
                                                                     String strTitle, 
                                                                     String strDescription, 
                                                                     Component centerOver, 
                                                                     BIFilter filter, 
                                                                     String strInitialSel) {
    return showMeasureDimensionMemberListDialog(parent, guiContext, 
                                                strDimension, strDisplayLabel, 
                                                strTitle, strDescription, 
                                                centerOver, filter, 
                                                strInitialSel);
  }

  /**
   * @hidden
   * Displays the dialog for showing dimension members of "measure dimension"
   * only.
   *
   * @param parent The parent Window.
   * @param guiContext The GuiContext instance.
   * @param strDimension The dimension name according to the display label type.
   * This parameter is an Unique ID.
   * @param strDisplayLabel The display label for the items.
   * @param strTitle The title of the dialog.
   * @param strDescription The description to be displayed for the dialog.
   * @param centerOver The component to center the dialog over.
   * @param bifilter The list of dimensions used for filtering the
   * displayed list of measures.
   * @param strInitialSel The initial selection for the list of dimension members.
   * This parameter is an OLAPI ID.
   *
   * @return A DimensionMember object containing the selected dimension member.
   * The object also contains the display label type of the dimension member.
   *
   * @return DimensionMember describing the
   */
  private static DimensionMember showMeasureDimensionMemberListDialog(Window parent, 
                                                                      GuiContext guiContext, 
                                                                      String strDimension, 
                                                                      String strDisplayLabel, 
                                                                      String strTitle, 
                                                                      String strDescription, 
                                                                      Component centerOver, 
                                                                      BIFilter bifilter, 
                                                                      String strInitialSel) {
    boolean bResetCursor = false;
    boolean bRetVal = false;
    Cursor waitCursor = null;
    MeasureListDialog measureListDlg = null;
    MeasureListPanel measureListPanel = null;
    DimensionMember measure = null;
    DimensionMember measureDimension = null;
    Frame parentFrame = null;
    int nRetVal = -1;
    String strSelectedItem = null;

    if (guiContext == null || guiContext.getMetadataManager() == null) {
      return null;
    }

    // Default to the long label
    if (strDisplayLabel == null)
      strDisplayLabel = LayerMetadataMap.LAYER_METADATA_LONGLABEL;

    // Validate that the dimension is a "measure dimension"
    bRetVal = 
        DataUtils.isMeasureDimension("", guiContext.getMetadataManager(), strDimension);

    if (!bRetVal)
      return null;

    if (centerOver != null)
      parentFrame = findParentFrame(centerOver);

    // Set the wait cursor.
    waitCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);

    if (parentFrame != null && parentFrame.getCursor() != waitCursor) {
      parentFrame.setCursor(waitCursor);
      bResetCursor = true;
    }

    // gek 01/25/02 Allow BIFilter to be passed to MeasureListDialog
    if (parent instanceof Dialog) {
      measureListDlg = 
          new MeasureListDialog((Dialog)parent, guiContext.getMetadataManager(), 
                                centerOver, null, true, bifilter);
    } else if (parent instanceof Frame) {
      measureListDlg = 
          new MeasureListDialog((Frame)parent, guiContext.getMetadataManager(), 
                                centerOver, null, true, bifilter);
    } else {
      measureListDlg = 
          new MeasureListDialog((Frame)null, guiContext.getMetadataManager(), 
                                centerOver, null, true, bifilter);
    }

    if (guiContext instanceof ComponentContext) {
      ComponentContext componentContext = (ComponentContext)guiContext;
      measureListDlg.getMeasureListPanel().setDisplayLabelType(componentContext.getDisplayLabelType());
      if (componentContext instanceof BuilderContext) {
        BuilderContext builderContext = (BuilderContext)componentContext;
        measureListDlg.setHelpProvider(builderContext.getHelpProvider());
        measureListDlg.setLocale(builderContext.getLocale());
      }
    }

    measureListPanel = measureListDlg.getMeasureListPanel();
    if (measureListPanel != null) {
      if (strDescription != null)
        measureListPanel.setDescription(strDescription);

      if (bifilter != null)
        measureListPanel.setFilter(bifilter);

      if (strTitle != null)
        measureListDlg.setTitle(strTitle);

      measureListPanel.expandTree(strInitialSel);
    }

    // Set the default cursor.
    if (parentFrame != null && bResetCursor) {
      parentFrame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

      bResetCursor = false;
    }

    if (measureListPanel == null)
      return null;

    // Display the dialog.
    nRetVal = measureListDlg.display();
    if (StandardDialog.CANCEL == nRetVal)
      return null;

    strSelectedItem = measureListPanel.getSelectedMeasure();
    if (strSelectedItem == null || strSelectedItem.length() == 0)
      return null;

    // Set the wait cursor.
    if (parentFrame != null && parentFrame.getCursor() != waitCursor) {
      parentFrame.setCursor(waitCursor);
      bResetCursor = true;
    }

    // Convert the Unique id to the specifed label type
    measure = 
        DataUtils.getMeasureLabel(guiContext.getMetadataManager(), LayerMetadataMap.LAYER_METADATA_NAME, 
                                  strDisplayLabel, strSelectedItem);

    // Set the default cursor.
    if (parentFrame != null && bResetCursor) {
      parentFrame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

      bResetCursor = false;
    }

    return measure;
  }

  /**
   * @hidden
   * Does a depth-first search to find the first focusable component
   * in a component which may or may be a container.
   *
   * @status new
   */
  public static Component getFirstFocusableComponent(Component component) {
    if (component instanceof Container) {
      for (int i = 0; i < ((Container)component).getComponentCount(); i++) {
        Component comp = 
          getFirstFocusableComponent(((Container)component).getComponent(i));

        if (comp != null)
          return comp;
      }

      if (component.isFocusTraversable())
        return component;
    } else {
      if (component.isFocusTraversable())
        return component;
    }

    return null;
  }

  /**
   * @hidden
   * Retrieves a list of available Time Dimensions.
   *
   * @param metadataManager The <code>MetadataManager</code> object from which
   *                        to retrieve the dimensions.
   * @return A <code>Vector</code> value that contains the list of available
   *         Time dimensions.
   *
   * @throws MetadataManagerException if metadata could not be retrieved
   *
   * @status hidden
   */
  public static Vector getTimeDimensions(MetadataManager metadataManager) throws MetadataManagerException {
    return getTimeDimensions(metadataManager, null);
  }

  /**
   * @hidden
   *
   * Retrieves a list of available Time Dimensions.
   *
   * @param metadataManager The <code>MetadataManager</code> object from which
   *                        to retrieve the dimensions.
   * @param strMeasureID The <code>String</code> ID of the measure used
   *                     to filter time dimension by.  If this value is not
   *                     null, only time dimensions associated with the measure
   *                     are returned, otherwise all time dimensions are returned.
   * @return A <code>Vector</code> value that contains the list of available
   *         Time dimensions.
   *
   * @throws MetadataManagerException if metadata could not be retrieved
   *
   * @status hidden
   */
  public static Vector getTimeDimensions(MetadataManager metadataManager, 
                                         String strMeasureID) throws MetadataManagerException {

    return getTimeDimensions((MetadataManagerServices)metadataManager, 
                             strMeasureID);
  }

  /**
   * @hidden
   *
   * Retrieves a list of available Time Dimensions.
   *
   * @param metadataManager The <code>MetadataManager</code> object from which
   *                        to retrieve the dimensions.
   * @param strMeasureID The <code>String</code> ID of the measure used
   *                     to filter time dimension by.  If this value is not
   *                     null, only time dimensions associated with the measure
   *                     are returned, otherwise all time dimensions are returned.
   * @return A <code>Vector</code> value that contains the list of available
   *         Time dimensions.
   *
   * @throws MetadataManagerException if metadata could not be retrieved
   *
   * @status hidden
   */
  public static Vector getTimeDimensions(MetadataManagerServices metadataManager, 
                                         String strMeasureID) throws MetadataManagerException {
    return DataUtils.getTimeDimensions(metadataManager, strMeasureID);
  }

  /**
   * @hidden
   */
  public static void expandPath(JTree tree, String strPath) {
    if ((tree != null) && (strPath != null)) {
      StringTokenizer tokenizer = new StringTokenizer(strPath, "/");
      DefaultMutableTreeNode node;
      while (tokenizer.hasMoreTokens()) {
        node = getNode(getRoot(tree), tokenizer.nextToken());
        if (node != null) {
          tree.expandPath(new TreePath((node.getPath())));
        }
      }
    }
  }

  /**
   * @hidden
   */
   public static String getLowestCommonPath(MetadataManagerServices mm, 
                                           Vector mdObjectIDs, 
                                           ErrorHandler errorHandler) {
    String strLowestCommonPath = null;
    if ((mm != null) && (mdObjectIDs != null)) {
      Object object;
      MDObject mdObject;
      for (Enumeration e = mdObjectIDs.elements(); e.hasMoreElements(); ) {
        object = e.nextElement();
        if (object != null) {
          mdObject = 
              QueryBuilderUtils.getMDObject(mm, object.toString(), null, errorHandler);
          if (mdObject != null) {
            strLowestCommonPath = 
                getStartingOverlap(strLowestCommonPath, mdObject.getPath());
          }
        }
      }
    }
    return strLowestCommonPath;
  }

  /**
   * @hidden
   */
  public static String getLowestCommonPath(MetadataManagerServices mm, 
                                           String strObjectID, 
                                           ErrorHandler errorHandler) {
    if (strObjectID != null) {
      Vector mdObjectIDs = new Vector(1);
      mdObjectIDs.addElement(strObjectID);
      return getLowestCommonPath(mm, mdObjectIDs, errorHandler);
    }
    return null;
  }

  /**
   * @hidden
   */
  public static DefaultMutableTreeNode getNode(JTree tree, String strTarget) {
    return getNode(getRoot(tree), strTarget);
  }

  /**
   * @hidden
   */
  public static DefaultMutableTreeNode getRoot(JTree tree) {
    if (tree != null) {
      TreeModel treeModel = tree.getModel();
      if (treeModel != null) {
        Object o = treeModel.getRoot();
        if ((o != null) && (o instanceof DefaultMutableTreeNode)) {
          return (DefaultMutableTreeNode)o;
        }
      }
    }
    return null;
  }

  /**
   * Private methods.
   */

  private static DefaultMutableTreeNode getNode(DefaultMutableTreeNode node, 
                                                String strTarget) {
    DefaultDirTreeNode thisNode;
    Object object;
    for (Enumeration e = node.preorderEnumeration(); e.hasMoreElements(); ) {
      object = e.nextElement();
      if ((object != null) && (object instanceof DefaultDirTreeNode) && 
          (strTarget != null)) {
        thisNode = (DefaultDirTreeNode)object;
        if (strTarget.equals(thisNode.getFullPathName())) {
          return thisNode;
        }
      }
    }
    return null;
  }

  private static String getStartingOverlap(String s1, String s2) {
    if (s1 != null) {
      if (s2 != null) {
        int i;
        int c1;
        int c2;
        int intMax = Math.min(s1.length(), s2.length());
        for (i = 0; i < intMax; i++) {
          c1 = s1.charAt(i);
          c2 = s2.charAt(i);
          if ((c1 != c2) && (i == 0)) {
            return null;
          }
        }
        return s1.substring(0, i);
      }
      return s1;
    }
    return s2;
  }
  
  /**
   * 
   * If the input string is already a valid java identifer, then use it.
   * Otherwise, create a valid java identifier by using "_" to reply in
   * valid java identifier
   * 
   * @param s
   * @return
   */
  public static String makeJavaIdentifier(String s, Map<String, String> changeMap) {
      // Null identifiers are not valid
      if (s == null || s.length() == 0)
      {
        return s;
      }
      
      StringBuffer javaIdentifier = new StringBuffer();
      final int length = s.length();
      boolean isValid = false;
      for(int i=0; i < length; i++) {
        isValid = false;
        
        if( i == 0)  {
            if(Character.isJavaIdentifierStart(s.charAt(i)))
              isValid = true;
        }
        else
        {
            if( Character.isJavaIdentifierPart(s.charAt(i)))
              isValid = true;
        }
        
        if( isValid )
          javaIdentifier.append(s.charAt(i));
        else
          javaIdentifier.append('_');
      }
      
      String retVal = javaIdentifier.toString();
      // Allow caller to preserve the original ID if a map is passed in 
      if (!retVal.equals(s) && changeMap != null)
          changeMap.put(retVal, s);
      return retVal;
  }
}
