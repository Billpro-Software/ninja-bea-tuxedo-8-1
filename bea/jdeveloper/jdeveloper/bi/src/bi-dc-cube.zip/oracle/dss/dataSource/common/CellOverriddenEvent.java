/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.QDR;

/**
 * Informs listeners that a cell override operation has occurred.
 *
 * @status Documented
 */
public class CellOverriddenEvent extends CellOverrideEvent
{

/**
 * Constructor for this class.
 *
 * @param source  The source of the event, that is, the object that fired the
 *                event.
 * @param row     The row of the cell that was edited.
 * @param col     The column of the cell that was edited.
 * @param page    The page of the cell that was edited.
 * @param data    The new data in the cell that was edited.
 * @param qdr     The QDR object that represents the cell that was edited.
 *
 * @status Documented
 */
    public CellOverriddenEvent(Object source, long row, long col, long page, Object data, QDR qdr) {
        super(source, row, col, page, data, qdr);
    }

}