/**
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil;

import java.text.MessageFormat;

import java.util.Locale;
import java.util.ResourceBundle;

import oracle.dss.util.BIBaseException;

/**
 * @hidden
 * 
 * This class provides methods that can be used to handle common Exception 
 * tasks. 
 *
 * @status hidden
 */

public class ExceptionUtils extends BIBaseException {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**
   * @hidden
   * 
   * Base name for Calculation resources
   *
   * @status hidden
   */
  public final static String CALCULATION_CLIENT_BUNDLE =
    "oracle.dss.calculation.client.resource.CalculationClientBundle";

  /**
   * @hidden
   * 
   * Calculation Loading Exception
   *
   * @status hidden
   */
  public static final String EXC_LOAD_CALC_ID = "DVT-15026";

  /**
   * @hidden
   * 
   * Base name for Thin resources
   *
   * @status hidden
   */
/*  public final static String THIN_BEANS_BUNDLE =
    "oracle.dss.thin.resource.ThinBeansBundle";
*/
  /**
   * @hidden
   * 
   * Thin Calculation Loading Exception
   *
   * @status hidden
   */
  public static final String EXC_THIN_LOAD_CALC_ID = "19508";

  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  /**
   * @hidden
   * 
   * The <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @status hidden
   */
  private transient Object[] m_objMergeArray = null;

  /**
   * @hidden
   * 
   * The <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @status hidden
   */
  private transient Locale m_locale = null;

  /**
   * @hidden
   * 
   * Specifies the class name of the resource bundle used for message retrieval.
   *
   * @status hidden
   */
  private transient String m_strResourceBundleName = null;

  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * @hidden
   *
   * Constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated error string in the 
   *        resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   * @param throwable  A <code>Throwable</code> exception that represents the
   *        previous exception to carry (may be null).
   * @param strResourceBundleName A <code>String</code> which represents the 
   *        class name of the resource bundle used for message retrieval.
   * @param locale A <code>Locale</code> used for localization.  If null, the
   *        default locale is used.
   *
   * @status hidden
   */
  public ExceptionUtils (String strErrorCode, Throwable throwable, 
                            String strResourceBundleName, Locale locale) {
    super (strErrorCode, throwable);
    setResourceBundleName (strResourceBundleName);
    setLocale (locale);
  }

  /**
   * @hidden
   *
   * Constructor.
   *
   * @param strErrorCode A <code>String</code> that represents the error code
   *        that is the key used to look up the associated error string in the resource bundle.
   *
   *        If the error associated with the error code is not found,
   *        then the <code>getMessage</code> method retrieves the original error code.
   * @param throwable  A <code>Throwable</code> exception that represents the
   *                   previous exception to carry (may be null).
   * @param objMergeArray A <code>Object[]</code> to merge with the error message.
   * @param strResourceBundleName A <code>String</code> which represents the 
   *        class name of the resource bundle used for message retrieval.
   * @param locale A <code>Locale</code> used for localization.  If null, the
   *        default locale is used.
   * 
   * @status hidden
   */
  public ExceptionUtils (String strErrorCode, Throwable throwable, 
    Object[] objMergeArray, String strResourceBundleName, Locale locale) {
    super (strErrorCode, throwable);
    setMergeArray (objMergeArray);
    setResourceBundleName (strResourceBundleName);
    setLocale (locale);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Retrieves the error message.
   * If the error associated with the original error code is not found,
   * then this method retrieves the original error code.
   *
   * The message is formatted as follows:
   * ErrorCode <space> ErrorString
   *
   * For example: DVT-1500 MetadataManager not set
   *
   * @return <code>String</code> that represents the formatted error message.
   *
   * @status documented
   */
  public String getMessage() {
    // Retrieve the initial Error code
    String strErrorCode = super.getMessage();

    if (strErrorCode != null) {
      // Retrieve our error string
      String strError = 
        getResourceString (getResourceBundleName(), strErrorCode, getLocale());
 
      if (strError != null) {
        // Create our new error message
        //  ErrorCode <space> ErrorString
        //  DVT-1500 MetadataManager not set
        StringBuffer strBuffer = new StringBuffer (strErrorCode);
        strBuffer.append (" ");

        // Determine if any objects needs to be merged
        Object[] objMergeArray  = getMergeArray();
        if (objMergeArray != null) {
          strError = MessageFormat.format (strError, objMergeArray);
        }

        return strBuffer.append (strError).toString();
      }
    }

    return strErrorCode;
  }

  /**
   * @hidden
   * 
   * Attempts to retrieve the resource string associated with the specified
   * base name and key.
   *
   * @param strResourceClass A <code>String</code> value that represents the 
   *        class name of the resource bundle.
   * @param strKey A <code>String</code> value that represents the key to look
   *        up within the resource bundle.
   * @param locale A <code>String</code> value that determines the language
   *        of the associated resource.
   *
   * @return <code>String</code> which represents the resource string associated
   *         with the specified base name and key.  If a resource bundle cannot
   *         be found, the original key is returned.
   *
   * @status hidden
   */
  public static String getResourceString (String strBaseName, String strKey, Locale locale) {

    // Set up Locale
    if (locale == null) {
      locale = Locale.getDefault();  
    }
    
    // Attempt to retrieve the resource bundle
    ResourceBundle resourceBundle = ResourceBundle.getBundle (strBaseName, locale);

    // Attempt to retrieve the string associated with the key
    if (resourceBundle != null) {
      return resourceBundle.getString(strKey);
    }

    // Return the key value if resource bundle could not be found
    return strKey;
  }

  /**
   * Retrieves the locale used for localization.
   *
   * @return <code>Locale</code> used for localization.
   *
   * @status New
   */
  public Locale getLocale() {
    return (m_locale == null) ? Locale.getDefault() : m_locale;
  }
 
  /**
   * Specifies the locale used for localization.
   *
   * @param locale A <code>Locale</code> used for localization.
   *
   * @status New
   */
  public void setLocale (Locale locale) {
    m_locale = locale;    
  }
 
  /**
   * Retrieves the class name of the resource bundle used for message retrieval.
   *
   * @return <code>String</code> which represents the class name of the resource 
   *         bundle used for message retrieval.
   *
   * @status New
   */
  public String getResourceBundleName() {
    return m_strResourceBundleName;
  }
 
  /**
   * Specifies the class name of the resource bundle used for message retrieval.
   *
   * @param strResourceBundleName A <code>String</code> which represents the 
   *        class name of the resource bundle used for message retrieval.
   *
   * @status New
   */
  public void setResourceBundleName (String strResourceBundleName) {
    m_strResourceBundleName = strResourceBundleName;    
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////
  
  /**
   * @hidden 
   *
   * Specifies the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @param objMergeArray A <code>Object[]</code> to merge with the exception's error message.
   *
   * @status protected
   */
  protected void setMergeArray (Object[] objMergeArray) {
    m_objMergeArray = objMergeArray;
  }

  /**
   * @hidden 
   *
   * Retrieves the <code>Object[]</code> that is to be merged with the exception's
   * error message.
   *
   * @return <code>Object[]</code> which is to be merged with the exception's
   *         error message.
   * @status protected   
   */
  protected Object[] getMergeArray() {
    return m_objMergeArray;
  }
 
  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

}
