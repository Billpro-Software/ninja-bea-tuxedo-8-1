/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.bicontext;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Vector;

/**
 * @hidden
 */
public class BISortUtils
{
    /*
     * An empty constructor. Just to instantiate the class and call sortSearchRestuls method.
     * This constructor is added in order to avoid having sortSearchResults method static
     * (don't want to worry about garbage collection and memory leaks).
     *
     * @hidden
     */
    public BISortUtils()
    {
    }

    /*
     * Returns a vector of BISearchResult objects sorted.
     *
     * @param searchResults a <code>Vector</code> of <code>BISearchResult</code> objects.
     * @param comp          an implementation of <code> Comparator</code> interface
     *                     (for sorting <code>BISearchResult</code> objects
     *                     returned from searching in <code>BIContext</code>,
     *                     implementatino of interface <code>BIComparator</code> is expected
     *
     * @hidden
     */
    public Vector sortSearchResults(Vector     searchResults,
                                    Comparator comp)
    {
        // Convert the vector of BISearchResult objects into an array and call
        // a standard Java sort method with a custom Comparator. Convert sorted
        // array back to Vector before returning it.
        Object[] arr = searchResults.toArray();
        Arrays.sort(arr, comp);
        // clear the vector
        searchResults = new Vector(arr.length);
        for (int i = 0; i < arr.length; i++)
            searchResults.addElement(arr[i]);
        return searchResults;
    }
}
