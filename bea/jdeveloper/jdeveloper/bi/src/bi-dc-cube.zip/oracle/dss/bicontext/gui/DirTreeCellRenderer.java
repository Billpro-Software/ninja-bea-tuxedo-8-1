/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.plaf.basic.BasicGraphicsUtils;

import oracle.bali.ewt.graphics.ImageUtils;

import oracle.dss.util.gui.component.tree.ComponentTreeNode;
import oracle.dss.util.persistence.PersistableConstants;

/**
 * @hidden
 * TreeCellRenderer especially for DirTreeNode
 */
public class DirTreeCellRenderer extends DefaultTreeCellRenderer
{
   /**
    * Constructor
    */
    public DirTreeCellRenderer()
    {
        super();
        setHorizontalAlignment(JLabel.LEFT);
    }

    /**
     * Configures the renderer based on the passed in components.
     * The value is set from messaging value with toString().
     * The foreground color is set based on the selection and the icon
     * is set based on on leaf and expanded.
     * See javadoc for TreeCellRenderer
     */
    public Component getTreeCellRendererComponent(JTree tree,
												  Object value,
												  boolean selected,
												  boolean expanded,
												  boolean leaf,
												  int row,
												  boolean hasFocus)
	{
        super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

        if (value instanceof ComponentTreeNode)
        {
            ComponentTreeNode obj = (ComponentTreeNode) value;
            setIcon(obj.getOpenIcon());
        }
        
        if (value instanceof DirTreeNode)
        {
            DirTreeNode obj = (DirTreeNode) value;
            setText(obj.getName());

            if (obj.isDisable())
            {
                ImageIcon _icon = (ImageIcon)obj.getOpenIcon();
                Image _image = _icon.getImage();
                _icon = new ImageIcon(ImageUtils.createDisabledImage(_image));
                setIcon(_icon);
            }

            Object userObj = obj.getSearchResult();
            if (userObj != null)
                setToolTipText(userObj.toString());

            if (PersistableConstants.FOLDER.equals(obj.getObjectType()))
            {
                if (expanded)
                    setIcon(IconManager.getIcon("openFolder"));
                else
                    setIcon(IconManager.getIcon("closeFolder"));                
            }
        }

        return this;
    }
}
