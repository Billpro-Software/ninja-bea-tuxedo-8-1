/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Vector;
import java.util.Locale;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.ModificationItem;

import oracle.dss.bicontext.BISearchControls;
import oracle.dss.bicontext.Privilege;

import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * @hidden
 */
public interface MetadataProvider
{
  /************************************************************************
  * Methods for populating the Cache
  ************************************************************************/
    // High Priority
    public MDContentBag getChildren(MDObject mdObject) throws MetadataManagerException;

    // High Priority
    public MDContentBag getRelatives(MDObject mdObject) throws MetadataManagerException;

   /************************************************************************
    * Methods to query the cache and driver.
    ************************************************************************/
	// This method will first check the cache (if client, then the server side).
	// If it doesn't find it in the cache, it will go to the driver and create
	// an MDObject and it will return the MDObject.
    // Low Priority
    public MDObject getMDObject (PropertyBag properties) throws MetadataManagerException;

   /************************************************************************
    * Methods to update the cache and the drivers.
    ************************************************************************/
    // Save an MDObject. This operation may go all the way
    // to the driver and possibly to the source platform.
    // High Priority for Persistence
    public MDObject setMDObject( MDObject mdObject, Attributes attributes ) throws MetadataManagerException;

    public int renameMDObject( MDObject mdObject, Name newName ) throws MetadataManagerException;
    public int modifyMDObject( MDObject mdObject, ModificationItem[] items ) throws MetadataManagerException;

	// remove the MDObject from the client, server side cache and the driver.
    // High Priority for Persistence
	public int removeMDObject( MDObject mdObject ) throws MetadataManagerException;

    // High Priority for Persistence
	public int removeAllChildren ( MDObject mdObject ) throws MetadataManagerException;

	// set a relation
	public int setRelatedMDObject(MDObject firstObject,	MDObject secondObject, String relation) throws MetadataManagerException;

	// remove a relation
	public int removeRelatedMDObject(MDObject firstObject, MDObject secondObject, String relation) throws MetadataManagerException;

	// refreshes all the cached properties on the client and server side.
	// This call will synchronize all the objects with the source platform.
	// The existing cache will be replced by the refreshed items.
    // High Priority for Persistence
	public MDObject refresh(MDObject mdObject, int depth) throws MetadataManagerException;

	// Support for Copy move operations.
	// Copy one object as another object's dependent
    // High Priority for Persistence
	public MDObject copy (MDObject objectToBeCopied, MDObject newParent, PropertyBag properties) throws MetadataManagerException;

	// Move one object as a dependent of another object.
    // High Priority for Persistence
	public int move (MDObject objectToBeMoved, MDObject newParent, PropertyBag properties) throws MetadataManagerException;

    public Vector search (MDObject mdObject, Attributes attributes, BISearchControls controls) throws MetadataManagerException;
    public Vector search (String uniqueID, Attributes attributes, BISearchControls controls) throws MetadataManagerException;

   /************************************************************************
    * Operations on the objects that only exist on the source platform.
    ************************************************************************/
	// get the driver specific objects from the driver
    // High Priority for MDM
	public Object getDriverSpecificObject( PropertyBag properties, Object object ) throws MetadataManagerException;

	// set the driver specific objects from the driver
    // Medium Priority for MDM
	public int setDriverSpecificObject( Object object, PropertyBag properties) throws MetadataManagerException;

	// remove the driver specific objects at the driver
    // Medium Priority for MDM
	public int removeDriverSpecificObjects( PropertyBag properties ) throws MetadataManagerException;

   /************************************************************************
    * Support for Security
    ************************************************************************/
	// Add entries
    // High Priority for Persistence
	public boolean addEntries (MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException;

	// Remove Entries
    // High Priority for Persistence
	public boolean removeEntries (MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException;

	// Set Entries
    // High Priority for Persistence
	public boolean setEntries (MDFolder folder, Name name, Vector entries, boolean cascadeToSubFolders, boolean cascadeToObjects) throws MetadataManagerException;

	// Entries
    // High Priority for Persistence
	public Vector entries (MDFolder folder, Name name) throws MetadataManagerException;

	// Get All Users
    // High Priority for Persistence
	public Vector getAllUsers () throws MetadataManagerException;

    public Privilege getPrivilege (MDFolder folder, Name name) throws MetadataManagerException;

	// Free all the contents and the object itself
	public int free ( MDObject mdObject) throws MetadataManagerException;

	public void setLocale(Locale locale);

	public Locale getLocale();

    public MDObject getMDObjectUsingFullPath(String path) throws MetadataManagerException;

    public Attributes getAttributes(MDObject mdObject, String[] attrIds, int flag) throws MetadataManagerException;

    public boolean getFeature(String feature);

    // New methods
    public void renameMDObject( MDFolder mdFolder, Name oldName, Name newName ) throws MetadataManagerException;
    public void modifyMDObject( MDFolder mdFolder, Name name, ModificationItem[] items ) throws MetadataManagerException;
    public void removeMDObject( MDFolder mdFolder, Name name, boolean isFolder ) throws MetadataManagerException;
    public void copy (MDFolder mdFolder, Name objectToBeCopied, MDFolder newParent, PropertyBag properties) throws MetadataManagerException;
    public void move (MDFolder mdFolder, Name objectToBeMoved, MDFolder newParent, PropertyBag properties) throws MetadataManagerException;
    public Vector search (MDFolder mdFolder, Name name, Attributes attributes, BISearchControls controls) throws MetadataManagerException;
    public Attributes getAttributes(MDFolder mdFolder, Name name, String[] attrIds, int flag) throws MetadataManagerException;    
    public Vector listAssociates(MDFolder mdFolder, Name relativeSourceName, String[] attrsToReturn, Attribute identifier) throws MetadataManagerException;
    public void setObjectInstanceClassName(String type, String clsName);
    public MDItemFolder[] getJoinableItemFolders(MDFolder folder, MDItemFolder itemFolder, boolean searchSubContext);
}