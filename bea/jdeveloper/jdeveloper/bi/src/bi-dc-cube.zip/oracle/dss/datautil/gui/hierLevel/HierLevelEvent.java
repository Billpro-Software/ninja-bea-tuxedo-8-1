/*
 * HierLevelEvent.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * @hidden
 */
public class HierLevelEvent extends EventObject
{
    // Current Hierarchy setting
    private String m_strHierarchy = null;
    // The display name for the hierarchy
	private String m_strHierName = null;
	
    // Vector of current levels
    private Vector m_vLevels = null;
	// Vector of level display names
	private Vector m_vLevelNames = null;
	
    // Fomratted text description of the levels and hierarchy setting
    private String m_strDescription = null;

    /**
    * "NEW"
    * Constructor.
    * @param source      - Object which fired this Event
    * @param hierarchy   - String uniquely identifying the Hierarchy of this Step
    * @param hierName    - The display name of the hierarchy
    * @param levels      - Vector of Strings uniquely identifying the levels
    * @param levelNames  - Vector of the level display names
    * @param description - String description of the levels and hierarchy setting
    *
    */
    public HierLevelEvent(Object source, String hierarchy, String hierName, Vector levels, Vector levelNames, String description)
    {
        super(source);
        m_strHierarchy = hierarchy;
        m_strHierName = hierName;
        m_vLevels = levels;
        m_vLevelNames = levelNames;
        m_strDescription = description;
    }


    // ----- Accessor Methods ------

    /**
     * "NEW"
     * Gets the current hierarchy.
     *
     * @return String representing the current hierarchy
     */
     public String getHierarchy()
     {
        return (m_strHierarchy);
     }

	/**
     * "NEW"
     * Gets the display name of the current hierarchy.
     *
     * @return hierarchy display name.
     */
     public String getHierarchyDisplayName()
     {
        return (m_strHierName);
     }


    /**
     * "NEW"
     * Gets the levels of the object.
     *
     * @return a Vector of the String unique names for the levels
     */
     public Vector getLevels()
     {
        return (m_vLevels);
     }

	/**
     * "NEW"
     * Gets the display descriptions for the levels.
     *
     * @return a Vector of the level descriptions
     */
     public Vector getLevelDisplayNames()
     {
        return (m_vLevelNames);
     }



     /**
     * "NEW"
     * Gets the formatted description of the current hierarchy/level setting.
     *
     * @return a description of the current level and hierarchy setting.
     */
     public String getDescription()
     {
        return (m_strDescription);
     }

     
}