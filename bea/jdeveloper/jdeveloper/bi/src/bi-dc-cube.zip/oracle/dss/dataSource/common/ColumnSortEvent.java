/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ColumnSortEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     08/17/05 - Move many BICommon files back to Beans 
    jramanat    07/29/05 - jramanat_column_sort_common
    jramanat    07/28/05 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/common/ColumnSortEvent.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.dataSource.common;

import oracle.dss.selection.sortWrapper.ColumnSortWrapper;

/**
 * Base class to distinguish column sort events.
 *
 * @status New
 */
public abstract class ColumnSortEvent extends QueryEvent {
  // Fields
  /**
   * @hidden
   * @serial list of column sorts
   * @status protected
   */
  protected ColumnSortWrapper[] m_sorts;

  /**
   * @hidden
   * @serial were these sorts removed?
   * @status protected
   */
  protected boolean m_removed = false;

  /**
   * Constructs the event.
   * 
   * @param source     The source of the event, that is, a reference to the
   *                   object that fired the event.
   * @param filters An array of changed <code>ColumnSortWrapper</code> objects.
   * @param removed    <code>true</code> if the <code>ColumnSortWrapper</code> objects
   *                   were removed, <code>false</code> if they were not.
   *
   * @status documented
   */
  public ColumnSortEvent(Object source, ColumnSortWrapper[] sorts, boolean removed) {
    super(source);    
    m_sorts = sorts;
    m_removed = removed;
  }    
  
  /**
   * Retrieves the list of changed <code>ColumnSortWrapper</code> objects.
   *
   * @return An array of changed <code>ColumnSortWrapper</code> objects.
   *
   * @status New
   */
  public ColumnSortWrapper[] getColumnSorts() {
    return m_sorts;
  }    
}