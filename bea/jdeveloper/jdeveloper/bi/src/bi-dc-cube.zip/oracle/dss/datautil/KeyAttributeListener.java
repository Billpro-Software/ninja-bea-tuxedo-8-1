/*
 * KeyAttributeListener.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil; 

import java.util.EventListener;

/**
 * @hidden
 * KeyAttributeListener
 *
 * @status New
 */
 
public interface KeyAttributeListener extends EventListener
{
    /**
     * Called when a KeyAttribute name value pair is available.
     * 
     * @status New
     */
    public void keyAttributeAvailable ( KeyAttributeEvent keyAttributeEvent );
}    