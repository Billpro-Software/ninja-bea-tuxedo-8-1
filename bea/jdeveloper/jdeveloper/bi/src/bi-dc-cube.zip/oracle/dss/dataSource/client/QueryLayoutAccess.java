/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryLayoutAccess.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:13 kmchorto Exp $
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.client;

import java.util.Vector;

import oracle.dss.dataSource.common.InvalidMetadataException;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.util.LayoutAccess;
import oracle.dss.util.DataDirector;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataSource;
import oracle.dss.util.Utility;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.DataDirectorListener;
import oracle.dss.util.DataChangedEvent;
import oracle.dss.util.DataAvailableEvent;
import oracle.dss.util.WaitDataAvailableEvent;

import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.util.EdgeOutOfRangeException;
import oracle.dss.util.LayerOutOfRangeException;
import oracle.dss.util.LayoutAccess2;
import oracle.dss.util.PollingRequiredEvent;

/**
 * @hidden
 * Query LayoutAccess implementation
 * @status New
 */
public class QueryLayoutAccess extends Object implements LayoutAccess2
{
    /**
     * Data Source reference
     */
    protected transient Query m_query   = null;

    protected transient boolean m_relational = false;

   /**
    * Layout data access
    */
   protected transient DataAccess m_layoutDA = null;
   protected transient DataDirector m_layoutDD = null;
   
    // Layout data source reference
    private transient LayoutDataSource m_lds = null;
    
    // List of current measures
    private String[] m_measures = null;

    // Temporary data access if needed
    private transient DataAccess m_da = null;
    
    /**
     * Constructor.
     */
    public QueryLayoutAccess(Query ds, boolean relational) {
        m_query = ds;
        m_lds = new LayoutDataSource(ds);
        m_measures = ds.getMeasures();
        m_relational = relational;
    }
    
    /**
     * Turn on and off cursor evaluation or other performance flags as
     * defined by the implementer.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param on turn on if <code>true</code>
     * @status New
     */
    public void setCursorEvaluation(boolean on)
    {
        try {
            m_lds.setCursorEvaluation(on);
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    // javadoc from interface
    public void resetItems(String dataItems[], String[] items) throws Exception
    {        
    }

    /**
     * @hidden
     * Return LayoutDataSource
     *
     */
    protected LayoutDataSource getLayoutDataSource()
    {
        return m_lds;
    }
    
    /**
     * Return the singleton object used to track layout changes in this LayoutAccess.
     *
     * @return Object that implements oracle.dss.util.DataSource, from which callers can obtain DataDirector/DataAccess objects that provide the structure of the current dimension layout.
     * @status New
     */
     public DataSource getDataSource() {
        DataSource ds = (DataSource)m_lds.getDataSource();
        if (m_layoutDA == null) {
            listenToLayoutQuery();
        }
        return ds;
     }

    /**
     * Update (or create if necessary) the layout data source based on a new list of measures.  These measure names should be a subset of the ones returned by using getMeasures with a MetadataMap.METADATA_VALUE type.
     * Note this method may throw a QueryRuntimeException.
     * 
     * @param measures New measures to use in layout data source.
     * @status New
     */
    public void setMeasures(String[] measures)
    {
        try
        {
            setItems(measures, getItems(LayerMetadataMap.LAYER_METADATA_NAME));
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    // Determine a list of items in newItems that are not in origItems, and vice versa
    protected String[][] getOldAndNewItems(String[] origItems, String[] newItems) throws InvalidMetadataException
    {
        String[][] retVal = new String[2][];
        retVal[0] = new String[0];
        retVal[1] = new String[0];
        if (newItems == null && origItems == null)
            return retVal;
        
        if (newItems == null)
        {
            // Removing all
            retVal[1] = origItems;  
            return retVal;
        }
        
        if (origItems == null)
        {
            // Adding all
            retVal[0] = newItems;
            return retVal;
        }
        
        // Mixture?
        // Check each new item to see if it's an old item
        retVal[0] = getDifferentList(newItems, origItems);
        // Check each old item to see if it's a new item
        retVal[1] = getDifferentList(origItems, newItems);
        return retVal;
    }
    
    protected String[] getDifferentList(String[] items, String[] list) throws InvalidMetadataException
    {
        Vector changes = null;
        if (items == null)
            return null;
        for (int i = 0; i < items.length; i++)
        {
            boolean bFound = false;
            for (int j = 0; j < list.length; j++)
            {
                if (list[j].equals(items[i]))
                {
                    // Found it: don't put it in the list
                    bFound = true;
                    break;
                }
            }
            String measDim = _getMeasureDimension();            
            // Ignore the measure dim
            if (!bFound && !items[i].equals(measDim))        
            {
                // Add to the "change" list
                if (changes == null)
                    changes = new Vector();
                changes.addElement(items[i]);
            }
        }
        if (changes == null)
            return new String[0];
            
        return (String[])changes.toArray(new String[] {});
    }
    
    /**
     * Converts the label types into database constants.
     *
     * @status New
     */
    private static String mapToDatabaseId ( String strLabelType )
    {
        if ( strLabelType.equalsIgnoreCase ( MetadataMap.METADATA_VALUE) )
        {
            return MM.UNIQUE_ID;
        }
        if (strLabelType.equalsIgnoreCase(MetadataMap.METADATA_DISPLAYNAME))
        {
            return MM.OBJECT_NAME;
        }
        else if ( strLabelType.equalsIgnoreCase ( MetadataMap.METADATA_LONGLABEL ) )
        {
            return MM.LONG_LABEL;
        }
        else if ( strLabelType.equalsIgnoreCase ( MetadataMap.METADATA_MEDIUMLABEL ) )
        {
            return MM.MEDIUM_LABEL;
        }
        else if ( strLabelType.equalsIgnoreCase ( MetadataMap.METADATA_SHORTLABEL ) )
        {
            return MM.SHORT_LABEL;
        }
        // For all other cases assume olapi id
        return MM.UNIQUE_ID;
    }
    
    /**
     * Get the list of measures chosen for this query available for layout.
     * Note this method may throw a QueryRuntimeException
     *
     * @param type MetadataMap type of labels given to the measures returned.
     * @return List of measures available in the layout query.
     * @status New
     */
    public String[] getMeasures(String type) {
        String[] measures = m_lds.getDataSource().getDataItems();
        
        return processItems(measures, type);
    }
    
    protected String[] processItems(String[] measures, String type)
    {
        if (measures == null) {
            return null;
        }
        
        if (type.equals(MetadataMap.METADATA_VALUE)) {
            return measures;
        }
        else if (measures != null)
        {                        
            String[] retList = new String[measures.length];
            for (int m = 0; m < measures.length; m++)
            {
                MDObject meas = null;
                try
                {
                    meas = (MDObject)m_query.getMDObject(MM.UNIQUE_ID, measures[m], MM.OBJECT);
                }
                catch (MetadataManagerException mme)
                {
                    throw new QueryRuntimeException(mme.getMessage(), mme);
                }
                if (meas != null)
                {
                    retList[m] = meas.toString(mapToDatabaseId(type));
                }
            }
            return retList;
		}
		return null;
    }

    /**
     * Set a specific layout expressed in a two-dimensional array
     * (edges x layers).  Each element of the array represents a value
     * returned by dataAccess.getLayerMetadata(edge, layer, LayerMetadataMap.LAYER_METADATA_NAME)
     * and is placed in the array argument in the new location that the element
     * should have after setting the new layout.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param layout two dimensional array of getLayerMetadata(edge, layer, LayerMetadataMap.LAYER_METADATA_NAME)
     *               values in their new location.  The first dimension of this argument represents
     *               edges, and the second represents the layers within those edges
     *               Any edges that should not have elements should have their place held
     *               with a zero element (zero layer) subarray at the edge location.
     * @status New
     */
    public void setLayout(String[][] layout)
    {
        if (m_measures == null)
            return;
          
        try
        {
            m_lds.getDataSource().layout(layout);
        }
        catch (Exception e) 
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    // javadoc from interface
    public String[][] getLayout()
    {            
        return m_lds.getDataSource().getLayout();
    }
    
    // javadoc from interface
    public int getMaxEdge()
    {
        return DataDirector.max_edge;
    }

    private boolean _emptyReturnValue(String[][] retVal)
    {
        if (retVal == null || retVal.length == 0)
            return true;
        if (retVal.length == 1)
            return retVal[0] == null || retVal[0].length == 0;
        for (int i = 0; i < retVal.length; i++)
        {
            if (retVal[i] != null && retVal[i].length > 0)
                return false;
        }
        return true;
    }
    
  // javadoc from interface
  public void setItems(String[] dataItems, String[] items) throws Exception
  {
/*      if ((dataItems == null) || (dataItems.length == 0))
      {
          if (m_measures != null && m_measures.length > 0 && m_lds.getDataSource() != null)
          {        
              try
              {
                  m_lds.getDataSource().removeCubeMeasures(m_measures);
                  m_lds.setEmpty(true);
              }        
              catch (Exception e)
              {
                  throw new QueryRuntimeException(e.getMessage(), e);
              }
          }      
          m_measures = null;
          if (items == null)
          {
              // This wants to be empty: we're done
              return;
          }
      }*/
      if (dataItems == null && items == null)
          m_lds.setEmpty(true);
    
      m_measures = dataItems;
    
      try
      {
          // Make sure that the layout Query creates a new query, 
          // if one does not exist at this point
          m_lds.getDataSource();
    
          if (m_lds.isEmpty())
          {        
              if (items == null)
              {
                  // Create a new cube query
                  m_lds.getDataSource().setItems(dataItems, null);
              }
              else
              {
                  // Create a new item query
                  m_lds.getDataSource().initQuery(null, dataItems, items);
              }
          
              m_lds.setEmpty(false);
        }
        else
        {
            if (!Utility.compareListsExact (dataItems, m_lds.getDataSource().getMeasures()) || 
                !Utility.compareListsExact(items, m_lds.getDataSource().getItems()))
            {          
                Boolean val = (Boolean)m_lds.getDataSource().isSupported(QueryCapabilities.MEASURE_DIMENSION_SELECTION, null);
            
                if (val != null && val.booleanValue())
                {
                    String measDim = _getMeasureDimension();
            
                    if (measDim != null)
                    {
                // blm - Selection code moved to dvt-olap
//              Selection sel = new Selection(_getMeasureDimension());
              //MemberStep ms = new MemberStep(_getMeasureDimension());
              //ms.setInitial(true);

              //for (int i = 0; i < m_measures.length; i++) {
//                ms.addMember(dataItems[i]);
              //}
              //sel.addStep(ms);
              //m_lds.getDataSource().applySelection(sel);
                    }
                    else
                    {
                        m_lds.getDataSource().setItems(dataItems, items);
                    }
                }
                else
                {
                    m_lds.getDataSource().setItems(dataItems, items);
            // Not empty, no meas dim to modify
            /*// Need to determine which items are new, and which are old
            // Get the original list
            String[] origDataItems = m_lds.getDataSource().getDataItems();
            String[] origItems = m_lds.getDataSource().getItems();

            String[][] addRemoveDataItems = 
              getOldAndNewItems(origDataItems, dataItems);

            String[][] addRemoveItems = null;
              addRemoveItems = getOldAndNewItems(origItems, items);

            // Special case: are the data items changed, but nothing is specifically there to add or remove?
            // i.e., the order changed?
              // Also special in that if there are no added items but there are old items, we leave the old ones
            if (dataItems == null)
                dataItems = new String[0];
            if (origDataItems == null)
                origDataItems = new String[0];
            if (!Utility.compareListsExact (dataItems, origDataItems) && _emptyReturnValue(addRemoveDataItems))
            {
                // Now figure out the items to set...
                if (addRemoveItems != null && addRemoveItems.length > 0)
                {
                    if (addRemoveItems[0] != null && addRemoveItems[0].length > 0)
                    {
                        // Some to add, some to remove
                        if (addRemoveItems[1] != null && addRemoveItems[1].length > 0)
                            m_lds.getDataSource().removeItems(addRemoveItems[1]);
                        m_lds.getDataSource().setItems(dataItems, addRemoveItems[0]);
                    }
                    else
                    {
                        // None to add...suspicious, just use old list to keep things the same, and preserve
                        // layout!
                        String[][] oldLayout = m_lds.getDataSource().getLayout();
                        m_lds.getDataSource().setItems(dataItems, origItems);
                        m_lds.getDataSource().layout(oldLayout);
                    }
                }
                else
                    m_lds.getDataSource().setItems(dataItems, items);
                return;
            }
              
            String[] tempDataItems = null;    
              String[] tempItems = null;
            if (addRemoveDataItems != null && addRemoveDataItems.length > 0 && addRemoveDataItems[0] != null && addRemoveDataItems[0].length > 0)
                tempDataItems = addRemoveDataItems[0];
              else
                tempDataItems = new String[0];
            if (addRemoveItems != null && addRemoveItems.length > 0 && addRemoveItems[0] != null && addRemoveItems[0].length > 0)
                tempItems = addRemoveItems[0];
              else
                tempItems = new String[0];
              if (tempDataItems != null || tempItems != null)
                m_lds.getDataSource().addItems (tempDataItems, tempItems);

                tempDataItems = null;
              if (addRemoveDataItems != null && addRemoveDataItems.length > 1 && addRemoveDataItems[1] != null && addRemoveDataItems[1].length > 0)
                  tempDataItems = addRemoveDataItems[1];
              else
                tempDataItems = new String[0];
              tempItems = null;
              if (addRemoveItems != null && addRemoveItems.length > 0 && addRemoveItems[1] != null && addRemoveItems[1].length > 0)
                  tempItems = addRemoveItems[1];
              else
                tempItems = new String[0];
            String[] combined = 
              Utility.combineArrays (tempDataItems, tempItems);

            if (combined != null && combined.length > 0)
              m_lds.getDataSource().removeItems(combined);*/
                }
            }
        }
    }    
    catch (Exception e)
    {
        throw new QueryRuntimeException (e.getMessage(), e);
    }
      if (dataItems == null && items == null)
          m_lds.setEmpty(true);
  }

  // javadoc from interface
    public String[] getItems(String type)
    {
        return processItems(m_lds.getDataSource().getItems(), type);    
    }
    
    // javadoc from interface
    public String[] getDataItems(String type)
    {
        return processItems(m_lds.getDataSource().getDataItems(), type);
    }
    
    /**
     * Return the edge (as defined in the DataDirector interface) indicating the location of the currently-defined "measure dimension" in the layout query.
     *
     * @return Edge indicating measure dimension location.
     * @status New
     */
    public int getMeasureEdge() {
        DimInfo di = findEdgeandLayer(null);
        
        if (di != null)
            return di.getEdge();
        return -1;
    }

    /**
     * Determine if the dimension at the given edge and layer is of the
     * type specified by the given constant.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param edge the edge whose dimension should be checked
     * @param layer the layer within the edge whose dimension should be checked
     * @param type the type constant (defined in LayoutAccess, such as LayoutAccess.TIME_DIMENSION)
     *             against which to check the dimension at layer,edge
     *
     * @return <code>true</code> if the dimension at edge, layer is of the special
     *         type given by type.
     *
     * @see LayoutAccess#TIME_DIMENSION
     * @throws EdgeOutOfRangeException if the given edge is illegal for the current data
     * @throws LayerOutOfRangeException if the given layer is illegal for the current data
     * @status New
     */
    public boolean isSpecialDimension(int edge, int layer, String type) throws EdgeOutOfRangeException, LayerOutOfRangeException
    {
        if (type != null)
        {
            if (type.equals(LayoutAccess.TIME_DIMENSION))
            {
                // Get the dimension ID from this layer and edge
                String dim = (String)getLayoutDA().getLayerMetadata(edge, layer, LayerMetadataMap.LAYER_METADATA_NAME);
                if (dim != null)
                {
                    try
                    {
                        // Find this dimension in the metadata manager
                        MDDimension mdDim = (MDDimension)m_query.getMDObject(MM.UNIQUE_ID, dim, MM.DIMENSION);
                        if (mdDim != null)
                        {
                            // Check its time flag
                            return mdDim.isTimeDimension();
                        }
                    }
                    catch (MetadataManagerException mme)
                    {
                        throw new QueryRuntimeException(mme.getMessage(), mme);
                    }
                }
            }
            if (type.equals(LayoutAccess.MEASURE))
            {
                try
                {
                    if (edge == -1 || layer == -1)
                    {
                        return false;
                    }
                    return _isItem(edge, layer, null);
                }
                catch (Exception e)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }
        return false;
    }

    // javadoc from interface
    public int getItemEdge(String item)
    {
        DimInfo di = findEdgeandLayer(item);
        
        return di.getEdge();
    }
    

    // javadoc from interface
    public int getItemLayer(String item, int edge)
    {
        DimInfo di = findEdgeandLayer(item);
        
        return di.getDepth();
    }

    /**
     * Return the layer indicating the location (along with the getMeasureEdge()) of the currently-defined "measure dimension" in the layout query.
     *
     * @return Layer indicating measure dimension location.
     * @status New
     */
     public int getMeasureLayer() {
        DimInfo di = findEdgeandLayer(null);
        
        return di.getDepth();
     }

    /**
     * Clean up the LayoutAccess implementation.  To be called by users
     * when they no longer need the LayoutAccess object
     * @status New
     */
    public void release() {
        m_lds.release();
    }         
    
    /**
     * @hidden
     * Return true if the underlying layout data source has been initialized
     */
    public boolean isInitialized() {
        return m_lds.isInitialized();
    }    
    
   private String _getMeasureDimension() throws InvalidMetadataException
   {
        return m_query.getMeasureDim();
   }    
   
    protected DataAccess getLayoutDA() {
        if (m_layoutDA == null) {
            listenToLayoutQuery();
        }
        return m_layoutDA;
    }
    
    // Adds listeners to the layout Query
    private void listenToLayoutQuery()
    {
        DataSource ds = m_lds.getDataSource();
        if (ds != null)
        {
            if (m_layoutDD == null)
            {
                if (m_relational)
                {
                    m_layoutDD = ds.createRelationalDataDirector();
                }
                else
                {
                    m_layoutDD = ds.createCubeDataDirector();
                }

                if (m_layoutDD != null)
                {
                    m_layoutDD.addDataDirectorListener(new DataDirectorListener()
                    {
                        public void viewDataChanged(DataChangedEvent e)
                        {
                            m_layoutDA = e.getDataAccess();
                        }
                        public void viewDataAvailable(DataAvailableEvent e)
                        {
                            m_layoutDA = e.getDataAccess();
                        }
                        public void waitDataAvailable(WaitDataAvailableEvent e) {}
                        public void pollingRequired(PollingRequiredEvent e) {}
                    });
                }
            }
        }
    }


    private boolean _isItem(int edge, int depth, String itemToFind) throws MetadataManagerException, InvalidMetadataException, EdgeOutOfRangeException, LayerOutOfRangeException
    {
        String item = (String)getLayoutDA().getLayerMetadata(edge, depth,
                        LayerMetadataMap.LAYER_METADATA_NAME);
        if (itemToFind != null)
            return itemToFind.equals(item);
        String measDim = _getMeasureDimension();
        if (m_relational)
        {
            // Determine if item found is a measure
            if (item != null)
            {
                MDObject obj  = m_query.getMetadataManager().
                    getMDObject(MM.UNIQUE_ID, item, MM.MEASURE);
                return measDim.equals(item) || (obj != null && obj instanceof MDMeasure);
            }
            return false;
        }
        else
        {
            return measDim.equals(item);
        }
    }


    // Find this dim's information
    private DimInfo findEdgeandLayer(String item)
        {
        int edge, depth;
        try
            {
            for (edge = 0; edge < getLayoutDA().getEdgeCount(); edge++)
                {
                for (depth = 0; depth < getLayoutDA().getLayerCount(edge); depth++)
                    {
                    if (_isItem(edge, depth, item))
                        {
                            DimInfo di = new DimInfo(edge, depth);
                            return di;
                        }
                    }
                }
            }
        
        catch (Exception e) 
            {
            // Something is very wrong
            }
        
        return null;
        }    
        
    /**
     *  Information about each particular dimension for a given set of data and layout
     *  that we might not want to refind or recalculate.
     *  @status New
     */
    protected class DimInfo extends Object 
        {
        public DimInfo(int e, int d) 
            {
            super();
            
            setEdge(e);
            setDepth(d);
            }
        
        public void setEdge(int e) 
            {
            edge = e;
            }
        
        public int getEdge() 
            {
            return edge;
            }        
        
        public void setDepth(int d) 
            {
            depth = d;
            }
        
        public int getDepth() 
            {
            return depth;
            }

        protected int edge  = -1;
        protected int depth = -1;
        }                        
}
