/**
 * TreeNodeRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.component.tree;

import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.UIManager;

import oracle.dss.datautil.gui.Utils;

/**
 * @hidden
 * 
 * <pre>
 * TreeNodeRenderer class is used to render the tree so that the leaf icon is 
 * set to null and so the openIcon and closedIcon are set to the Discoverer icons 
 * if they are null (as they are for the OLAF).
 * 
 * This code was migrated from oracle.dss.datautil.StandardTreeCellRenderer.
 * </pre>
 *
 * @since   11.0.0.0.5
 * @status  new
 * 
 * MODIFIED    (MM/DD/YY)
 *    gkellam   09/21/05 - 
 * 
 */

public class TreeNodeRenderer extends DefaultTreeCellRenderer {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  /**  
   * @hidden
   * 
   * The location of default <code>Class</code> specified is used as a base 
   * to access an image.
   * 
   * For instance "oracle.dss.datautil.gui.ComponentContext.class" would specify
   * a base path of "oracle\dss\datautil\gui".
   * 
   * @status hidden
   */
  public static Class DEFAULT_CLASS_ICON_BASE_PATH = 
    oracle.dss.datautil.gui.ComponentContext.class;  

  /////////////////////
  //
  // Members
  //
  /////////////////////
  
  /**
   * @hidden
   * 
   * Open icon image used in the tree.
   * 
   * If null, values should be picked up from:
   * UIManager.get ("Tree.openIcon")
   * 
   * @status hidden
   */
  private ImageIcon m_imageIconOpen = null;

  /**
   * @hidden
   * 
   * Closed icon image used in the tree.
   * 
   * If null, values should be picked up from:
   * UIManager.get ("Tree.closedIcon")
   * 
   * @status hidden
   */
  private ImageIcon m_imageIconClosed = null;

  /**
   * @hidden
   * 
   * Leaf icon image used in the tree.
   * 
   * If null, values should be picked up from:
   * UIManager.get ("Tree.leafIcon")
   * 
   * @status hidden
   */
  private ImageIcon m_imageIconLeaf = null;
  
  /**  
   * @hidden
   * 
   * The location of <code>Class</code> specified is used as a base 
   * to access an image.
   * 
   * For instance "oracle.dss.datautil.gui.ComponentContext.class" would specify
   * a base path of "oracle\dss\datautil\gui".
   * 
   * @status hidden
   */
  private Class m_classIconBasePath = DEFAULT_CLASS_ICON_BASE_PATH;  

  /**
   * @hidden
   * 
   * Relative path to open icon image to be used in the tree.
   * 
   * @status hidden
   */
  private String m_strPathIconOpen = null;

  /**
   * @hidden
   * 
   * Relative path to closed icon image to be used in the tree.
   * 
   * @status hidden
   */
  private String m_strPathIconClosed = null;

  /**
   * @hidden
   * 
   * Relative path to leaf icon image to be used in the tree.
   * 
   * @status hidden
   */
  private String m_strPathIconLeaf = null;
  
  /**
   * @hidden
   * 
   * Determines whether the contents of the <code>TreeNodeRenderer</code> have
   * been initialized.  Value is <code>true</code> if the contents have been 
   * initialized and <code>false</code> otherwise.
   * 
   * @status hidden
   */
  private boolean m_bInitialized = false;
  
  /////////////////////
  //
  // Constructors
  //
  ///////////////////// 
  
  /**
   * <pre>
   * Default <code>TreeNodeRenderer</code> constructor.
   * 
   * By default, the following open, closed and leaf icons are used respectively: 
   *   getDefaultOpenIcon()
   *   getDefaultClosedIcon()
   *   getDefaultLeafIcon()
   * </pre>
   *
   * @status new
   */
  public TreeNodeRenderer() {
    super();
  }

  /**
   * <pre>
   * <code>TreeNodeRenderer</code> constructor.
   * 
   * The classIconBasePath and each strPathIcon are combined to detertmine the 
   * location of the appropriate icon to load.
   * </pre>
   * 
   * @param classIconBasePath A <code>Class</code> whose location 
   *        is used as a base to access an image.  
   *        For instance "oracle.dss.datautil.gui.ComponentContext.class" would specify
   *        a base path of "oracle\dss\datautil\gui".
   * @param strPathIconOpen A <code>String</code> which represents the relative 
   *        path to open icon image to be used in the tree.  Uses 
   *        getDefaultOpenIcon() if null.
   * @param strPathIconClosed A <code>String</code> which represents the relative 
   *        path to closed icon image to be used in the tree. Uses 
   *        getDefaultClosedIcon()) if null.
   * @param strPathIconLeaf A <code>String</code> which represents the relative 
   *        path to leaf icon image to be used in the tree. Uses 
   *        getDefaultLeafIcon() if null.
   * 
   * @status new
   */
  public TreeNodeRenderer (Class classIconBasePath, String strPathIconOpen, 
                           String strPathIconClosed, String strPathIconLeaf) {
    super();

    setClassIconBasePath (classIconBasePath);
    
    if (strPathIconOpen != null) {
      setPathIconOpen (strPathIconOpen);
    }       
        
    if (strPathIconClosed != null) {
      setPathClosedOpen (strPathIconClosed);
    }
    
    if (strPathIconLeaf != null) {
      setPathLeafOpen (strPathIconLeaf);
    }
  }

  /**
   * <pre>
   * <code>TreeNodeRenderer</code> constructor.
   * 
   * The classIconBasePath and each strPathIcon are combined to detertmine the 
   * location of the appropriate icon to load.
   * </pre>
   * 
   * @param imageIconOpen A <code>ImageIcon</code> which represents the 
   *        open icon image to be used in the tree. Uses 
   *        getDefaultOpenIcon() if null.
   * @param imageIconClosed A <code>ImageIcon</code> which represents the 
   *        closed icon image to be used in the tree.  Uses 
   *        getDefaultClosedIcon() if null.
   * @param imageIconLeaf A <code>ImageIcon</code> which represents the 
   *        leaf icon image to be used in the tree.  Uses 
   *        getDefaultLeafIcon() if null.
   * 
   * @status new
   */
  public TreeNodeRenderer (ImageIcon imageIconOpen, ImageIcon imageIconClosed, 
                           ImageIcon imageIconLeaf) {
    super();
    
    setOpenIcon (imageIconOpen);
    setClosedIcon (imageIconClosed);
    setLeafIcon (imageIconLeaf);
  }
  
  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * <pre>
   * Configures the renderer based on the passed in components.
   * The value is set from messaging the tree with
   * <code>convertValueToText</code>, which ultimately invokes
   * <code>toString</code> on <code>value</code>.
   * 
   * The foreground color is set based on the selection and the icon
   * is set based on on leaf and expanded.
   *
   * Overriding the getTreeCellRendererComponent call to set the right icons.
   * </pre>
   * 
   * @param jTree A <code>JTree</code>.
   * @param objValue A <code>Object</code>.
   * @param bIsSelected A <code>boolean</code>.
   * @param bIsExpanded A <code>boolean</code>.
   * @param bIsLeaf A <code>boolean</code>.
   * @param nRow A <code>int</code>.
   * @param bHasFocus A <code>boolean</code>.
   * 
   * @return <code>Component</code> representing the update component.
   * 
   * @status new
   */
  public Component getTreeCellRendererComponent (JTree jTree, Object objValue,
    boolean bIsSelected, boolean bIsExpanded, boolean bIsLeaf, int nRow, boolean bHasFocus) {
    Component renderer = null;
     
    // Determine if we need to initialize the contents   
    if (!isInitialized()) {
      setInitialized (initContents());
    }
      
    if (getImageIconOpen() != null) {
      setOpenIcon (getImageIconOpen());
    }
    
    if (getImageIconClosed() != null) {
      setClosedIcon (getImageIconClosed()); 
    }

    if (getImageIconLeaf() != null) {
      setLeafIcon (getImageIconLeaf()); 
    }
    
    // Delegate to superclass  
    renderer = 
      super.getTreeCellRendererComponent (jTree, objValue, bIsSelected, bIsExpanded, 
        bIsLeaf, nRow, bHasFocus);
        
    return renderer;
  }

  /**  
   * <pre>
   * The location of <code>Class</code> specified is used as a base 
   * to access an image.
   * 
   * For instance "oracle.dss.datautil.gui.ComponentContext.class" would specify
   * a base path of "oracle\dss\datautil\gui".
   * </pre>
   *
   * @param classIconBasePath A <code>Class</code> used as a base to access images.
   *
   * @status new
   */
  public void setClassIconBasePath (Class classIconBasePath) {
    m_classIconBasePath = classIconBasePath;
  }

  /**  
   * <pre>
   * The location of <code>Class</code> specified is used as a base 
   * to access an image.
   * 
   * For instance "oracle.dss.datautil.gui.ComponentContext.class" would specify
   * a base path of "oracle\dss\datautil\gui".
   * </pre>
   *
   * @return A <code>Class</code> used as a base to access images.
   *
   * @status new
   */
  public Class getClassIconBasePath() {
    return m_classIconBasePath;
  }

  /**  
   * <pre>
   * Specifies the relative path to the open icon image to be used in the tree. 
   * For example, "images/folder-o.gif"
   * </pre>
   *
   * @param strPathIconOpen A <code>String</code> which represents the relative 
   *        path to the open icon image to be used in the tree.
   *
   * @status new
   */
  public void setPathIconOpen (String strPathIconOpen) {
    m_strPathIconOpen = strPathIconOpen;
  }

  /**  
   * <pre>
   * Retrieves the relative path to the open icon image to be used in the tree. 
   * For example, "images/folder-o.gif"
   * </pre>
   *
   * @return <code>String</code> which represents the relative path to the open 
   *         icon image to be used in the tree.
   *
   * @status new
   */
  public String getIconOpenPath() {
    return m_strPathIconOpen;
  }

  /**  
   * <pre>
   * Specifies the relative path to the closed icon image to be used in the tree. 
   * For example, "images/folder-o.gif"
   * </pre>
   *
   * @param strPathIconClosed A <code>String</code> which represents the relative 
   *        path to the closed icon image to be used in the tree.
   *
   * @status new
   */
  public void setPathClosedOpen (String strPathIconClosed) {
    m_strPathIconClosed = strPathIconClosed;
  }

  /**  
   * <pre>
   * Retrieves the relative path to the closed icon image to be used in the tree. 
   * For example, "images/folder-c.gif"
   * </pre>
   *
   * @return <code>String</code> which represents the relative path to the closed 
   *         icon image to be used in the tree.
   *
   * @status new
   */
  public String getIconClosedPath() {
    return m_strPathIconClosed;
  }

  /**  
   * <pre>
   * Specifies the relative path to the leaf icon image to be used in the tree. 
   * For example, "images/folder-o.gif"
   * </pre>
   *
   * @param strPathIconLeaf A <code>String</code> which represents the relative 
   *        path to the leaf icon image to be used in the tree.
   *
   * @status new
   */
  public void setPathLeafOpen (String strPathIconLeaf) {
    m_strPathIconLeaf = strPathIconLeaf;
  }

  /**  
   * <pre>
   * Retrieves the relative path to the leaf icon image to be used in the tree. 
   * For example, "images/folder-o.gif"
   * </pre>
   *
   * @return <code>String</code> which represents the relative path to the leaf 
   *         icon image to be used in the tree.
   *
   * @status new
   */
  public String getIconLeafPath() {
    return m_strPathIconLeaf;
  }

  /**  
   * <pre>
   * Specifies the open icon image to be used in the tree. 
   * </pre>
   *
   * @param imageIconOpen A <code>IconImage</code> which represents the open 
   *        icon image to be used in the tree.
   *
   * @status new
   */
  public void setImageIconOpen (ImageIcon imageIconOpen) {
    m_imageIconOpen = imageIconOpen;
  }

  /**  
   * <pre>
   * Retrieves the open icon image to be used in the tree.  
   * </pre>
   *
   * @return <code>ImageIcon</code> which represents the the open icon image to 
   *         be used in the tree.  
   *
   * @status new
   */
  public ImageIcon getImageIconOpen() {
    return m_imageIconOpen;
  }

  /**  
   * <pre>
   * Specifies the closed icon image to be used in the tree. 
   * </pre>
   *
   * @param imageIconClosed A <code>IconImage</code> which represents the closed 
   *        icon image to be used in the tree.
   *
   * @status new
   */
  public void setImageIconClosed (ImageIcon imageIconClosed) {
    m_imageIconClosed = imageIconClosed;
  }

  /**  
   * <pre>
   * Retrieves the closed icon image to be used in the tree.  
   * </pre>
   *
   * @return <code>ImageIcon</code> which represents the the closed icon image to 
   *         be used in the tree.  
   *
   * @status new
   */
  public ImageIcon getImageIconClosed() {
    return m_imageIconClosed;
  }

  /**  
   * <pre>
   * Specifies the leaf icon image to be used in the tree. 
   * </pre>
   *
   * @param imageIconLeaf A <code>IconImage</code> which represents the leaf 
   *        icon image to be used in the tree.
   *
   * @status new
   */
  public void setImageIconLeaf (ImageIcon imageIconLeaf) {
    m_imageIconLeaf = imageIconLeaf;
  }

  /**  
   * <pre>
   * Retrieves the leaf icon image to be used in the tree.  
   * </pre>
   *
   * @return <code>ImageIcon</code> which represents the the leaf icon image to 
   *         be used in the tree.  
   *
   * @status new
   */
  public ImageIcon getImageIconLeaf() {
    return m_imageIconLeaf;
  }

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * Determines whether the contents of the <code>TreeNodeRenderer</code> have
   * been initialized.
   * 
   * @return <code>boolean</code> which is <code>true</code> if the contents
   *         have been initialized and <code>false</code> otherwise.
   * 
   * @status hidden
   */
  protected boolean isInitialized() {
    return m_bInitialized;
  }

  /**
   * Determines whether the contents of the <code>TreeNodeRenderer</code> have
   * been initialized.
   * 
   * @param bInitialized A <code>boolean</code> which is <code>true</code> 
   *        if the contents have been initialized and <code>false</code> otherwise.
   * 
   * @status hidden
   */
  protected void setInitialized (boolean bInitialized) {
    m_bInitialized = bInitialized;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * Initialize the contents of the <code>TreeNodeRenderer</code>.
   * 
   * @return <code>boolean</code> which is <code>true</code> if the contents
   *         could be initialized successfully and <code>false</code> otherwise
   * 
   * @status hidden
   */
  private boolean initContents() {
    // Simply return if we have already been initialized
    if (isInitialized()) {
      return true;
    }

    // Determine the base class path used to retrieve the images
	  Class classIconBasePath = getClassIconBasePath();
	  
    try {
      if ((getIconOpenPath() != null) && (getIconOpenPath().length() > 0)) { 
        setImageIconOpen (new ImageIcon (
          Utils.getImageResource (classIconBasePath, getIconOpenPath())));
        /*
        if (UIManager.get ("Tree.openIcon") == null) {
          setImageIconOpen (new ImageIcon (
            Utils.getImageResource (classIconBasePath, getIconOpenPath())));
        }
        */
      }
    }
    
    catch (Exception exception) {
      return false;
    }
    
	  try {
	    if ((getIconClosedPath() != null) && (getIconClosedPath().length() > 0)) { 
	      setImageIconClosed (new ImageIcon (
	        Utils.getImageResource (classIconBasePath, getIconClosedPath())));
        /*
        if (UIManager.get ("Tree.closedIcon") == null) {
	        setImageIconClosed (new ImageIcon (
	          Utils.getImageResource (classIconBasePath, getIconClosedPath())));
	      }
        */
	    }
	  }
	  
    catch (Exception exception) {
      return false;
    }
    
	  try {
	    if ((getIconLeafPath() != null) && (getIconLeafPath().length() > 0)) { 
	      setImageIconLeaf (new ImageIcon (
	        Utils.getImageResource (classIconBasePath, getIconLeafPath())));
        /*
	      if (UIManager.get ("Tree.leafIcon") == null) {
	        setImageIconLeaf (new ImageIcon (
	          Utils.getImageResource (classIconBasePath, getIconLeafPath())));
        }
        */
      }
	  }

    catch (Exception exception) {
      return false;
    }
    
    return true;
	}
}