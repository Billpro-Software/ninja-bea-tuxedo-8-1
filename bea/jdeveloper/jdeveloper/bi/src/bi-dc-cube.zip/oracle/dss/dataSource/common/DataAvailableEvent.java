/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.DataAccess;

/**
 * Informs listeners that data, metadata, or both is available or revoked.
 * This event is fired generally when a user first creates or recreates a query
 * in a data source.
 *
 * @status Documented
 */
public class DataAvailableEvent extends QueryEvent implements CursorCarryingEvent
{
    /**
     * @hidden
     * Constructor.
     *
     * @param source    The source of the event.
     *
     */
    public DataAvailableEvent(Object source, boolean isAvailable, DataAccess da) {
        super(source);
        
        available = isAvailable;
        dataAccess = da;
    }

    /**
     * Indicates whether data is available or revoked.
     *
     * @return  <code>true</code> if data is available,
     *          <code>false</code> if revoked.
     *
     * @status Documented
     */
    public boolean isAvailable() {
        return available;
    }
    
    /**
     * Retrieves the <code>DataAccess</code> cursor that is available.
     *
     * @return    The <code>DataAccess</code> cursor.
     *
     * @status Documented
     */
    public DataAccess getDataAccess() {
        return dataAccess;
    }

    /**
     * @hidden
     * Set the DataAccess cursor into the event.
     *
     * @param da new DataAccess cursor
     */
    public void setDataAccess(DataAccess da) {
        dataAccess = da;
    }
        
    // Fields
    /**
     * @hidden
     * @serial is data available or revoked?
     */
    protected boolean           available;
    /**
     * @hidden
     * @serial cursor containing the available data
     */
    protected DataAccess dataAccess;
}
