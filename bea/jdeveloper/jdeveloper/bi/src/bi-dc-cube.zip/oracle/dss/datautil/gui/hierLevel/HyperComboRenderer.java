/*
 * HyperComboRenderer.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import oracle.dss.datautil.gui.Utils;
import oracle.dss.datautil.gui.OperatorDisplay;

/**
 * @hidden
 * Begin HyperComboRenderer
 *
 * Extends the DefaultListCellRenderer 
 * to paint the currently selected value as a hyperlink
 */
public class HyperComboRenderer extends DefaultListCellRenderer {    
    // True if the label should be underlined
    private boolean m_blnUnderlined;
    // The JSeparator used for separating the combo box items
    private JSeparator m_separator = new JSeparator();
    // Holds the reference to the HyperLinkCombo.
    private HyperLinkCombo m_hyperLinkCombo;
    
    public HyperComboRenderer(HyperLinkCombo hyperLinkCombo) {
        super();
        m_hyperLinkCombo = hyperLinkCombo;
    }
    
    /*
     * @hidden
     */
    public HyperLinkCombo getHyperCombo() {
        return m_hyperLinkCombo;
    }
    
    // Modifier for the underline property
    public void setUnderlined(boolean isUnderlined) {
        m_blnUnderlined = isUnderlined;
    }
    
    // Accessor for the underline property
    public boolean isUnderlined() {
        return m_blnUnderlined;
    }
    
    // Override the paint() method to draw the underline
    public void paint(Graphics g) {
        // Get the text to be painted
        String text = this.getText();
        
        // Control the painting of the hyperlink
        if ((text != null) && isUnderlined()) {
            Color oldColor = g.getColor();
            
            // Calculate the line position
            int width = getSize().width;
            int height = getSize().height;
            
            // Calculate the beginning and ending of the text
            FontMetrics metrics = g.getFontMetrics();
            int x = width/2 - metrics.stringWidth(text)/2;
            int y = metrics.getAscent();
            
            // Fill the background
            g.setColor(getBackground());
            g.fillRect(0, 0, width, height);

            // Draw the text and underline in the foreground color
            g.setColor(getForeground());
            // Draw the text
            //g.drawString(text, x, y);
            g.drawString(text, x, y-1);
            // Draw the underline
            //g.drawLine(x, y+1, width-x, y+1);
            g.drawLine(x, y, width-x, y);
            
            // Return to the old color
            g.setColor(oldColor);
        }
        // Paint the other items in the usual way
        else {
            super.paint(g);
        }
    }

    // Override the getListCellRendererComponent() 
    // to set the underlined property when pinting the currently selected item
    public Component getListCellRendererComponent(
         JList list,
         Object value,
         int index,
         boolean isSelected,
         boolean cellHasFocus) {
        
        // Display the value as underlined if the combo is in the hyperlink mode
        setUnderlined((index == -1) && m_hyperLinkCombo.isHyperLink());
        
        // If Value is the separator, return the JSeparator
        if ((value != null) && value.equals(HyperLinkCombo.SEPARATOR)) {
             return (m_separator);
        }
        else {
            // If Value is an operator with a long and short display options:
            if (m_hyperLinkCombo.isHyperLink() && (value instanceof OperatorDisplay)) {
                OperatorDisplay operatorDisplayValue = (OperatorDisplay)value;
                if (index == -1) { // if this value is to appear at the top.
                    // Display only a symbol for selected values
                    operatorDisplayValue.setDisplayJustSymbol(true);
                }
                else {
                    // Display the operator symbol and its description
                    operatorDisplayValue.setDisplayJustSymbol(false);
                }
            }
             
            Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            component.setEnabled(!m_hyperLinkCombo.getDisabledItems().contains(m_hyperLinkCombo.getModel().getElementAt(index)));
            return component;
        }
    } 
}
//=================================
// End HyperLinkRenderer
//