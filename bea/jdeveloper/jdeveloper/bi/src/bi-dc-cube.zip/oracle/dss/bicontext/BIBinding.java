/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import javax.naming.Binding;

/**
 * @hidden
 * The BIBinding class is an extension to the JNDI Binding class with an additional
 * methods for specifying and retrieving the object type
 *
 * @see javax.naming.Binding
 * @status New
 */
public class BIBinding extends Binding implements ObjectLoaderTarget
{
    private String m_type;
    private transient ObjectLoader m_loader;

    public BIBinding(String name, Object obj, String type)
    {
        super(name, obj);
        m_type = type;
    }

    

    public BIBinding(String name, String className, Object obj, String type)
    {
        super(name, className, obj);
        m_type = type;
    }

    

    public String getObjectType()
    {
        return m_type;
    }

    public void setObjectType(String type)
    {
        m_type = type;
    }

    public void setObjectLoader(ObjectLoader loader)
    {
        m_loader = loader;
    }

    /**
     * @hidden
     */
    public ObjectLoader getObjectLoader()
    {
        return m_loader;
    }

    public Object getObjectDefinition()
    {
        return getObject();
    }
}