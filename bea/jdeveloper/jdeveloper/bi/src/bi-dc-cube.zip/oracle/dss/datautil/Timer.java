/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 *  @hidden
 *
 *  <pre>
 *  Timer
 *	
 *	Support for basic timer profiling.<br>
 *
 *  This is very similar to XPTIMER in X4WTOOLS.  It allows the user
 *  to create timers which measure interval and total time.  The
 *  timers can be started, restarted, stopped and checked at various
 *  intervals.  Options are also provided to control the debug output.<br>
 *
 *  Available Options:
 *  OPTION_DATE:        Show date stamp                
 *  OPTION_TIME:        Show time stamp               
 *  OPTION_INTERVAL:    Show interval time (in milliseconds)
 *  OPTION_TOTAL:       Show total time (in milliseconds)    
 *  OPTION_NAME:        Show timer name   
 *  OPTION_ALL:         Turn on all options    
 *  OPTION_DATE:        Show date stamp options   
 *  OPTION_DEFAULT:     Show default options (interval, total, name)   
 *    It is also possible to set the indent level to make output easier 
 *    to read. <br>
 *
 *  </pre>
 *
 *  @see        oracle.dss.datautil
 *  @version    0.1 13 Jan 1999
 *  @author     Guy Kellam (gek)
 *  @modified   Robert Alexander 10/27
 *              -can only start if stopped.
 *              -can only stop if started.
 *              -stops at the "level" started.
 *
 */

public class Timer extends Object {
        
  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Debug flags

  // Setting DEBUG to false turns off all debugging 'System.out.println'
  // statements.  This should be the default for release code!

  // Setting DEBUG to true turns on lots of debugging 'System.out.println'
  // statements.  This is helpful for debugging!

  public final static boolean DEBUG = false;
  
  // Setting ON to false turns off all timing 'System.out.println'
  // statements.  This should be the default for release code!

  // Setting ON to true turns on lots of timing 'System.out.println'
  // statements.  This is helpful for debugging!
  
  public final static boolean ON = false;

	//
  // State literals
  //

  public final static int STATE_START      = 0;
  public final static int STATE_INTERVAL   = 1;
  public final static int STATE_STOP       = 2;
  public final static int STATE_RESTART    = 3;

  //
  // Format Options
  //

  // Show date stamp
  public final static int OPTION_DATE     = 0x0001;               
  
  // Show time stamp
  public final static int OPTION_TIME     = 0x0002;               
  
  // Show interval time (in milliseconds) 
  public final static int OPTION_INTERVAL = 0x0004;
  
  // Show total time (in milliseconds) 
  public final static int OPTION_TOTAL    = 0x0008;
  
  // Show timer name 
  public final static int OPTION_NAME     = 0x0010;
  
  // Show all options 
  public final static int OPTION_ALL      = OPTION_DATE       | 
                                            OPTION_TIME       | 
                                            OPTION_INTERVAL   | 
                                            OPTION_TOTAL      |
                                            OPTION_NAME;
  
  // Show date stamp options
  public final static int OPTION_DATE_TIME = OPTION_DATE      | 
                                             OPTION_TIME;
  
  // Show default options
  public final static int OPTION_DEFAULT  = OPTION_INTERVAL   | 
                                            OPTION_NAME;

  // Indent literals
  public final static int INDENT_SPACES   = 3;    // Spaces/indent level
 
  //
  // String literals
  //

  private final static String OUTPUT_NEWLINE       = "\n";
  private final static String OUTPUT_INTERVAL      = "Interval ";
  private final static String OUTPUT_PAREN_OPEN    = "[";
  private final static String OUTPUT_PAREN_CLOSE   = "]";
  private final static String OUTPUT_RESTART       = "Restart  ";
  private final static String OUTPUT_SPACE         = " ";
  private final static String OUTPUT_START         = "Start    ";
  private final static String OUTPUT_STATE         = "State: ";
  private final static String OUTPUT_STOP          = "Stop     ";
  private final static String OUTPUT_TAB           = "\t";
  private final static String OUTPUT_TIME_INTERVAL = "Interval: ";
  private final static String OUTPUT_TIME_TOTAL    = "Total    ";
  private final static String OUTPUT_TIMER         = "Timer ";
  private final static String OUTPUT_TIMER_UNIT    = "ms";
  private final static String OUTPUT_DESCRIPTION   = "Description: ";
  private final static String OUTPUT_TOTAL         = "Total: ";

  private final static String DEFAULT_TIMER_NAME = "BI Beans";
 
  /////////////////////
  //
  // Member Variables
  //
  /////////////////////

  private String  m_strName       = null;             // Timer name
  private Date    m_dateLast      = null;             // Last date
  private long    m_lTotal        = 0;                // Total tick count
  private boolean m_bStarted      = false;            // Timer started flag
  private boolean m_bEnable       = true;             // Output enabled
  private int     m_nIndentLevel  = 0;                // Indent level
  private int     m_nIndentSpaces = INDENT_SPACES;    // Number spaces per indent
  private long    m_lOptions      = OPTION_DEFAULT;   // Format options 
  
  private int     m_intStartStack = 0;                // Start "level"
  static private  Timer m_timer   = null;             // Singleton Timer object
   
  /////////////////////
  //
  // Constructors
  //
  /////////////////////

  /**
   * <pre>
   * Timer
   * 	Constructor for Timer class.<br>
   *
   *  Example:
   *    Timer timer = new Timer ("My Timer!", OPTION_DEFAULT);
   * </pre>
   *
   * @param strName a <code>String</code> which represents the timer's name
   * @param lOptions a <code>long</code> which represents the formatting options
   */
  public Timer (String strName, long lOptions) {
    setName (strName);    
    setOptions (lOptions);
  }

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * <pre>
   * getTimer 
   * 	Gets the singleton timer object.<br>
   *
   * Example:
   * 	Timer timer = Timer.getTimer();
   * </pre>
   *
   * @return <code>Timer</code> which represents current time object.
   */
  static public Timer getTimer() {
    if (m_timer == null) {
      m_timer = new Timer (getDefaultTimerName(), Timer.OPTION_DEFAULT);
    }

	  return m_timer;
  }

  /**
   * <pre>
   * getName 
   *   Gets the timer name.<br>
   *
   * Example:
   *   String strNamed = getName();
   * </pre>
   *
   * @return <code>String</code> which represent's the timers's name. 
   */
	public String getName() {
		return m_strName;     
  }

  /**
   * <pre>
   * setName 
   *   Sets the timer name.<br>
   *
   * Example:
   *   setName (strName);
   * </pre>
   *
   * @param strName a <code>String</code> which represent's the timers's name. 
   */
  public void setName (String strName) {
    m_strName = strName;    
  }

  /**
   * <pre>
   * getEnable 
   *   Determines whether timer is enabled.<br>
   *
   * Example:
   *   boolean bEnabled = getEnable();
   * </pre>
   *
   * @return <code>boolean</code> which is <code>true</code> if the timer is 
   *         enabled and <code>false</code> otherwise. 
   */
  public boolean getEnable() {
    return m_bEnable;     
  }

  /**
   * <pre>
   * setEnable 
   *   Determines whether timer is enabled.<br>
   *
   * Example:
   *   setEnable (true);
   * </pre>
   *
   * @param bEnable a <code>boolean</code> which is <code>true</code> if the 
   *        timer should be enabled and <code>false</code> otherwise     
   */
  public void setEnable (boolean bEnable) {
    m_bEnable = bEnable;    
  }

  /**
   * <pre>
   * getIndentLevel 
   *   Gets indent level.<br>
   *
   * Example:
   *   int nIndentLevel = getIndentLevel();
   * </pre>
   *
   * @return <code>int</code> which represents the indent level. 
   */
  public int getIndentLevel() {
    return m_nIndentLevel;     
  }

  /**
   * <pre>
   * setIndentLevel 
   *   Sets the indent level.<br>
   *
   * Example:
   *   setIndentLevel (3);
   * </pre>
   *
   * @param nIndent a <code>int</code> which represents the indent level. 
   */
  public void setIndentLevel (int nIndentLevel) {
    m_nIndentLevel = nIndentLevel;    
  }

  /**
   * <pre>
   * getIndentSpaces 
   *   Gets number of spaces per indent.<br>
   *
   * Example:
   *   int nIndentSpaces = getIndentSpaces();
   * </pre>
   *
   * @return <code>int</code> which represents the number of spaces per indent. 
   */
  public int getIndentSpaces() {
    return m_nIndentSpaces;     
  }

  /**
   * <pre>
   * setIndentSpaces 
   *   Sets the number of spaces per indent.<br>
   *
   * Example:
   *   setIndentSpaces (5);
   * </pre>
   *
   * @param nIndentSpaces a <code>int</code> which represents the number of spaces 
   *        per indent. 
   */
  public void setIndentSpaces (int nIndentSpaces) {
    m_nIndentSpaces = nIndentSpaces;    
  }

  /**
   * <pre>
   * getOptions 
   *   Gets the formatting options.<br>
   *
   * Example:
   *   long lOptions = getOptions();
   * </pre>
   *
   * @return <code>long</code> which represents the formatting options. 
   */
  public long getOptions() {
	  return m_lOptions;     
  }

  /**
   * <pre>
   * setOptions 
   *   Sets the formatting options.<br>
   *
   * Example:
   *   setOptions (OPTION_TIME_STAMP);
   * </pre>
   *
   * @param lOptions a <code>long</code> which represents the format options to set 
   */
  public void setOptions (long lOptions) {
    m_lOptions = lOptions;    
  }

  /**
   * <pre>
   * getLastDate 
   *  Gets the last timer date.<br>
   *
   * Example:
   *   Date date = getLastDate();
   * </pre>
   *
   * @return <code>Date</code> which represents the last date. 
   */
  public Date getLastDate() {
    return m_dateLast;     
  }

  /**
   * <pre>
   * getTotal 
   *   Gets the total time.<br>
   *
   * Example:
   *   long lTotal = getTotal();
   * </pre>
   *
   * @return <code>long</code> which represents the the number of milliseconds 
   *         since January 1, 1970 00:00:00 GMT represented by this date. 
   */
  public long getTotal() {
    return m_lTotal;    
  }

  /**
   * <pre>
   * setTotal 
   *   Sets the total time since timer was started.<br>
   *
   * Example:
   *   setTotal(lTime);
   * </pre>
   *
   * @param lTime a <code>long</code> which sets the date to represent the 
   *        specified number of milliseconds since January 1, 1970 00:00:00 GMT. 
   */
  public void setTotal (long lTime) {
    m_lTotal = lTime;    
  }

  /**
   * <pre>
   * getStarted 
   *   Determines if timer has been started.<br>
   *
   * Example:
   *   boolean bStarted = getStarted();
   * </pre>
   *
   * @return <code>boolean</code> which is <code>true</code> if timer has beem
   *         started, and <code>false</code> otherwise. 
   */
  public boolean getStarted() {
    return m_bStarted;    
  }

  /**
   * <pre>
   * start 
   *   Starts the timer.<br>
   *
   * Example:
   *   start ("My timer!");
   * </pre>
   *
   * @param strDescription a <code>String<code> which represents the description. 
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful
   *         and <code>false</code> othewise
   */
  public boolean start (String strDescription) {
    m_intStartStack++;

    if (!getStarted()) {
      setLastDate (new Date()); 
      setTotal (0);
      setStarted (true);

      // Output the result
      formatOutput (OUTPUT_START, 0, strDescription, getLastDate());

      return true;
    }
    else {
			return false;
  	}
	}

  /**
   * <pre>
   * interval 
   *   Determines timer interval.<br>
   *
   * Example:
   *   interval ("My timer!");
   * </pre>
   *
   * @param strDescription a <code>String<code> which represents the description. 
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful
   *         and <code>false</code> othewise
   */
  public boolean interval (String strDescription) {
    // If we haven't started a timer yet, bail.     
    if (!getStarted())
      return false;
        
    // Determine the amount of time that has lapsed since last
    // timer event.
    long lInterval = updateTimer();
    
    // Save the running total
    setTotal (getTotal() + lInterval);
    
    // Output the result
    formatOutput (OUTPUT_INTERVAL, lInterval, strDescription, getLastDate());

    return true;
  }

  /**
   * <pre>
   * stop 
   *   Stops the timer and outputs final interval.<br>
   *
   * Example:
   *   stop ("My timer!");
   * </pre>
   *
   * @param strDescription a <code>String<code> which represents the description. 
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful
   *         and <code>false</code> othewise
   */
  public boolean stop (String strDescription) {
    m_intStartStack--;

    if (m_intStartStack < 0) {
      m_intStartStack = 0;
    }

    if ((getStarted()) && (m_intStartStack == 0)) {       
      // Determine the amount of time that has lapsed since last
      // timer event.
      long lInterval = updateTimer();

      // Save the running total
      setTotal (getTotal() + lInterval);

      // Output total amount of time since last time event
      formatOutput (OUTPUT_STOP, lInterval, strDescription, getLastDate());

      // Output total amount of time since timer was started
      formatOutput (OUTPUT_TOTAL, getTotal(), strDescription, getLastDate());

      // Timer has been stopped
      setStarted (false);
      
      return true;
    }
  	else {
    	return false;
  	}
	}

  /**
   * <pre>
   * restart 
   *   Restarts a stopped timer and retains the total time.<br>
   *
   * Example:
   *   restart ("My timer!");
   * </pre>
   *
   * @param strDescription a <code>String<code> which represents the description. 
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful
   *         and <code>false</code> othewise
   */
  public boolean restart (String strDescription) {
    // Determine the amount of time that has lapsed since last
    // timer event.
    long lInterval = updateTimer();
        
    // Output result    
    formatOutput (OUTPUT_RESTART, lInterval, strDescription, getLastDate());

    // Timer has started
    setStarted (true);

    return true;
  }

  /**
   * <pre>
   * formatTimeDate 
   *  Formats the time/date based on timer formatting options.<br>
   *
   * Example:
   *   formatTimeDate (date);
   * </pre>
   *
   * @param date a <code>Date</code> which represents the date to format. 
   * @param nStyle a <code>int</code> which represents the date style. 
   * @param locale a <code>Locale</code> that represnts the date locale.
   * 
   * @return <code>String</code> which represent the formatted date string.     
   */
     
  public String formatDateTime (Date date, int nStyle, Locale locale) {
    StringBuffer strOutput = new StringBuffer();
    
    // Determine if date is being used
    long lDateUsed = OPTION_DATE_TIME & getOptions();
    
    if ((date != null) && (lDateUsed != 0)) {
      DateFormat dateFormat = null;
      
      switch ((int)lDateUsed) {
        case OPTION_DATE_TIME:
          dateFormat = DateFormat.getDateTimeInstance (nStyle, nStyle, locale);
          break;
        
        case OPTION_DATE:
          dateFormat = DateFormat.getDateInstance (nStyle, locale);
          break;
            
        case OPTION_TIME:
          dateFormat = DateFormat.getTimeInstance (nStyle, locale);
          break;
      }    
            
      dateFormat.setTimeZone (TimeZone.getTimeZone("EST"));

      strOutput.append (OUTPUT_PAREN_OPEN);
      strOutput.append (dateFormat.format (date));
      strOutput.append (OUTPUT_PAREN_CLOSE);
      strOutput.append (OUTPUT_SPACE);
    }             
    
    return strOutput.toString();
  }

  /**
   * Sample timing method.
   *
   * @param strArguments a <code>String[]</code> array which represents the 
   *        command line arguments.
   */

  public static void main (String strArguments[]) {
    // Create a timer using the default output options     
    Timer timer = new Timer ("Loops!", OPTION_DEFAULT);
    
    // Start the loop
    timer.start ("Loop1 is starting.");
    
    for (int i = 0; i < 20000; i++) {
	    // Check an interval     
	    if (i == 10000)
        timer.interval ("Loop1 has gone half way!");
    }    
    
    // End the loop
    timer.stop ("Loop1 has ended.");

    // Set the indent level to make second loop easier to see
    timer.setIndentLevel (2);
    
    // Set the number of spaces per indent (default is 3)
    timer.setIndentSpaces (2);
    
    // Change the format options
    timer.setOptions (OPTION_TIME | OPTION_TOTAL);
    
    // Start the second loop
    timer.restart ("Loop2 is starting.");
    
    for (int i = 0; i < 50000; i++) {
      // Check an interval     
      if (i == 25000)
        timer.interval ("Loop2 has gone half way!");
    }    
    
    // End the loop
    timer.stop ("Loop2 has ended.");
	}

  /////////////////////
  //
  // Protected Methods
  //
  /////////////////////

  /**
   * <pre>
   * formatOutput 
   *   Formats timer output string.<br>
   * </pre>
   *
   * @param strState a <code>String</code> which represents the timer state.
   * @param lInterval a <code>long</code> which represents the timer interval.
   * @param strDescription a <code>String</code> which represents the description. 
   * @param date a <code>Date</code> which represents the date to display. 
   * 
   * @return <code>boolean</code> which is <code>true</code> if successful
   *         and <code>false</code> othewise
   */
  protected boolean formatOutput (String strState, long lInterval, 
                                String strDescription, Date date) {
    long   lOptions   = getOptions();    
    StringBuffer strOutput = new StringBuffer(OUTPUT_NEWLINE);
    
    // Determine if timer is enabled
    if (getEnable()) {
      // Determine if there is any indenting
      int nSpaces = getIndentLevel() * getIndentSpaces();
      for (int nIndex = 0; nIndex < nSpaces; ++nIndex)
        strOutput.append (OUTPUT_SPACE);
          
      // Determine if date is being used
      strOutput.append (formatDateTime (date, DateFormat.MEDIUM, Locale.US));               

      // Determine if timer name is being used
      if ((getName() != null) && ((lOptions & OPTION_NAME) != 0)) {
        strOutput.append (OUTPUT_TIMER);
        strOutput.append (OUTPUT_PAREN_OPEN);
        strOutput.append (getName());
        strOutput.append (OUTPUT_PAREN_CLOSE);
        strOutput.append (OUTPUT_TAB);
      }
            
      // Output state information
      strOutput.append (OUTPUT_STATE);
      strOutput.append (strState);
      strOutput.append (OUTPUT_TAB);
      
      // Determine if interval value is being used
      if ((lOptions & OPTION_INTERVAL) != 0) {     
        strOutput.append (OUTPUT_TIME_INTERVAL);
        strOutput.append (lInterval);
        strOutput.append (OUTPUT_TIMER_UNIT);  
        strOutput.append (OUTPUT_TAB);    
      }
          
      // Determine if total value is being used        
      if ((lOptions & OPTION_TOTAL) != 0) {     
        strOutput.append (OUTPUT_TIME_TOTAL);
        strOutput.append (getTotal());
        strOutput.append (OUTPUT_TIMER_UNIT);  
        strOutput.append (OUTPUT_TAB);                
      }
      
      // Add description
      if (strDescription != null) {
        strOutput.append (OUTPUT_DESCRIPTION);
        strOutput.append (strDescription);
      }

      strOutput.append (OUTPUT_SPACE);

      // Output result
      System.out.println (strOutput);
    }    
    
    return true;
  }

  /**
   * Retrieves the default <code>Timer</code> name.
   *
   * @return <code>String</code> which represents the default timer name.
   */
  protected static String getDefaultTimerName() {
    return DEFAULT_TIMER_NAME;
  }

  /////////////////////
  //
  // Private Methods
  //
  /////////////////////

  /**
   * <pre>
   * setLastDate 
   *   Sets the last timer date.<br>
   *
   * Example:
   *   setLastDate(date);
   * </pre>
   *
   * @param date a <code>Date</code> which represents the last date. 
   */
  private void setLastDate (Date date) {
    m_dateLast = date;    
  }
  
  /**
   *  <pre>
   *  setStarted 
   *      Determines if timer is started.<br>
   *
   *  Example:
   *      setStarted (true);
   *  </pre>
   *
   *      @param  bStarted    Determines if timer is started. 
   *      @return None     
   */
  private void setStarted (boolean bStarted) {
	  m_bStarted = bStarted;    
  }

  /**
   * <pre>
   * updateTimer 
   *   Updates the timer, returning interval.<br>
   *
   * Example:
   *   updateTimer ();
   * </pre>
   *
   * @param  None    No parameters. 
   * @return Timer interval     
   */
  private long updateTimer() {
    // Determine the amount of time that has lapsed since last
    // timer event.
    Date dateCurrent = new Date();
    Date dateLast    = getLastDate();
    long lInterval   = dateCurrent.getTime() - dateLast.getTime();

    // Save current as last
    setLastDate (dateCurrent);

    return lInterval;
  }
}