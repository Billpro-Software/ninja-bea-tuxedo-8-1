/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;

import java.util.Locale;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;

import oracle.dss.util.persistence.Persistable;

/**
 * The read only subset of {@link BIContext}.
 *
 * @status new
 */
public interface ReadOnlyBIContext extends ReadOnlyDirContext
{
    /**
     * Refreshes the entries in the current folder.
     * This is a way to notify the context to refresh
     * its cache, if it has a cache.
     * Refreshing the cache allows subsequent calls to <code>search</code>,
     * <code>list</code>, and <code>listBinding</code> to reflect the new
     * changes.
     *
     * @throws    NamingException If a naming error occurs.
     *
     * @status reviewed
     */
    public void refresh() throws NamingException;

    /**
     * Retrieves the access control list for this context.
     * The access control list is a list of permissions.
     *
     * @return The access control list for this context.
     *
     * @throws    NamingException If there is a problem with the name.
     *
     * @status documented
     */
    public Acl getAcl() throws NamingException;

     /**
     * Searches a folder for objects with attribute values that match specific
     * selection criteria.
     * By default, this method returns all predefined (that is, fixed)
     * attributes, such as OBJECT_TYPE, TIME_DATE_CREATED, and so on.
     * If you specify a <code>searchControl</code> parameter, then this method
     * returns only the specific attributes that you request in the
     * <code>setReturningAttributes</code> method of the
     * <code>BISearchControls</code> object.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The selection criteria for attributes of the
     *                      objects that you want to find.
     * @param  searchControls Optional search controls. Use a
     *                       <code>BISearchControls</code> object to specify
     *                       controls such as search scope, sorting option,
     *                       attributes to be returned in the search results,
     *                       and whether a filter is to be applied to the
     *                       final search results.
     *                       This parameter can be <code>null</code>.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in the
     *         <code>setReturningAttributes</code> method of
     *         <code>BISearchControls</code>, and the name of the object,
     *         relative to the folder specified in <code>name</code>.
     *
     * @throws NamingException If a naming error occurs.
     *
     * @see BISearchControls
     *
     * @status documented
     */
    public NamingEnumeration search(String name, Attributes matchingAttributes, SearchControls searchControls) throws NamingException;

    /**
     * Searches a folder for objects with attribute values that match specific
     * selection criteria.
     * By default, this method returns all predefined (that is, fixed)
     * attributes, such as OBJECT_TYPE, TIME_DATE_CREATED, and so on.
     * If you specify a <code>searchControl</code> parameter, then this method
     * returns only the specific attributes that you request in the
     * <code>setReturningAttributes</code> method of the
     * <code>BISearchControls</code> object.
     *
     * @param  name         The name of the folder to search.
     * @param  matchingAttributes  The selection criteria for attributes of the
     *                      objects that you want to find.
     * @param  searchControl Optional search controls. Use a
     *                       <code>BISearchControls</code> object to specify
     *                       controls such as search scope, sorting option,
     *                       attributes to be returned in the search results,
     *                       and whether a filter is to be applied to the
     *                       final search results.
     *                       This parameter can be <code>null</code>.
     *
     * @return An enumeration of <code>SearchResult</code> objects. The search
     *         results contain the attributes that you requested in
     *         <code>setReturningAttributes</code> method of
     *         <code>BISearchControls</code>, and the name of the object,
     *         relative to the folder specified in <code>name</code>.
     *
     * @throws NamingException If a naming error occurs.
     *
     * @see BISearchControls
     *
     * @status documented
     */
    public NamingEnumeration search(Name name, Attributes matchingAttributes, SearchControls searchControl) throws NamingException;


    /**
     * Updates a <code>Persistable</code> object or folder from the
     * BI Beans Catalog. Use this method to reuse an already-loaded
     * <code>Persistable</code> object. This method applies the XML from the
     * BI Beans Catalog to a <code>Persistable</code> that is already loaded
     * in memory.
     *
     * @param name         The name of the object that is to be loaded.
     *                     Do not pass <code>null</code>.
     * @param persistable  The <code>Persistable</code> that is to be
     *                     reused.
     *
     * @return      The requested object or folder.
     *              The object implements the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException  If <code>name</code> is <code>null</code>
     *                                 or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException       If any other naming error occurs.
     *
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(String name, Persistable persistable) throws NamingException;

    /**
     * Updates a <code>Persistable</code> object or folder from the
     * BI Beans Catalog. Use this method to reuse an already-loaded
     * <code>Persistable</code> object. This method applies the XML from the
     * BI Beans Catalog to a <code>Persistable</code> that is already loaded
     * in memory.
     *
     * @param name         The name of the object that is to be loaded.
     *                     Do not pass <code>null</code>.
     * @param persistable  The <code>Persistable</code> that is to be
     *                     reused.
     *
     * @return      The requested object or folder.
     *              The object implements the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException if any other naming error occurs.
     *
     * @see oracle.dss.util.persistence.Persistable
     *
     * @status Documented
     */
    public Object lookup(Name name, Persistable persistable) throws NamingException;

    /**
     * Updates a <code>Persistable</code> object or folder from the
     * BI Beans Catalog and provides arguments for initializing the object as
     * it is loaded. Use this method to reuse an already-loaded
     * <code>Persistable</code> object. This method applies the XML from the
     * BI Beans Catalog to a <code>Persistable</code> that is already loaded
     * in memory.
     *
     * @param name        The name of the object that is to be loaded.
     *                    Do not pass <code>null</code>.
     * @param persistable The <code>Persistable</code> that is to be
     *                    reused.
     * @param args        Arguments for initializing the
     *                    <code>Persistable</code> as it is loaded.
     *                    For details, see the initialize method of the
     *                    <code>Persistable</code> interface.
     *
     * @return      The requested object or folder.
     *              The object implements the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException if any other naming error occurs.
     *
     * @see oracle.dss.util.persistence.Persistable#initialize
     *
     * @status Documented
     */
    public Object lookup(String name, Persistable persistable, Hashtable args) throws NamingException;

    /**
     * Updates a <code>Persistable</code> object or folder from the
     * BI Beans Catalog and provides arguments for initializing the object as
     * it is loaded. Use this method to reuse an already-loaded
     * <code>Persistable</code> object. This method applies the XML from the
     * BI Beans Catalog to a <code>Persistable</code> that is already loaded
     * in memory.
     *
     * @param name        The name of the object that is to be loaded.
     *                    Do not pass <code>null</code>.
     * @param persistable The <code>Persistable</code> that is to be
     *                    reused.
     * @param args        Arguments for initializing the
     *                    <code>Persistable</code> as it is loaded.
     *                    For details, see the initialize method of the
     *                    <code>Persistable</code> interface.
     *
     * @return      The requested object or folder.
     *              The object implements the <code>Persistable</code> interface.
     *
     * @throws BIInvalidNameException If <code>name</code> is <code>null</code>
     *               or empty.
     * @throws BINameNotFoundException If the object or folder cannot be found.
     * @throws BINamingException       If any other naming error occurs.
     *
     * @see oracle.dss.util.persistence.Persistable#initialize
     *
     * @status Documented
     */
    public Object lookup(Name name, Persistable persistable, Hashtable args) throws NamingException;

   /**
     * Retrieves the locale for this context.
     *
     * @return The locale setting for this context, or the
     *         the system default locale, if not locale has been explicitly
     *         set.
     *
     * @status documented
     */
    public Locale getLocale();

    /**
     * Specifies the locale used by this context.
     * The scope of this setting is up to the implementor.
     * It may apply to all context in the system, or only to this context.
     * Setting the locale updates all <code>PersistenceManager</code>
     * instances with the new locale setting.
     *
     * @param locale The locale to set.
     *
     * @status documented
     */
    public void setLocale(Locale locale);


  /**
     * Retrieves the <code>Vector</code> of entries from the access control list
     * of the specified object.
     *
     * @param name The name of the object.
     *
     * @return A <code>Vector</code> of entries from the access control list
     *         of the specified object.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to list entries
     *            of the specified object.
     *
     * @status Documented
     */
    public Vector entries(Name name) throws NamingException;

    /**
     * Retrieves the <code>Vector</code> of entries from the access control list
     * of the specified object.
     *
     * @param name The name of the object.
     *
     * @return A <code>Vector</code> of entries from the access control list
     *         of the specified object.
     *
     * @throws NamingException If there is a naming problem. For example,
     *            this method might throw a <code>NamingException</code> if
     *            the caller does not have sufficient privilege to list entries
     *            of the specified object.
     *
     * @status Documented
     */
    public Vector entries(String name) throws NamingException;

    /**
     * Retrieves a <code>Vector</code> that contains all the <code>User</code>
     * objects from the BI Beans Catalog.
     *
     * @return A <code>Vector</code> of all the <code>User</code> objects from
     *         the BI Beans Catalog.
     *
     * @throws NamingException If an error has occurred.
     *
     * @status Documented
     */
    public Vector getAllUsers() throws NamingException;

    /**
     * Retrieves the highest privilege that the caller has, either as a user or
     * as a member of a group, on the specified object.
     *
     * @param name The name of the object.
     *
     * @return The highest privilege of the caller, either as a user or as a
     *         member of a group, on the specified object. This value
     *         is one of the constants in
     *         <code>oracle.dss.bicontext.Privilege</code>.
     *
     * @see Privilege#LIST
     * @see Privilege#ADD_FOLDER
     * @see Privilege#READ
     * @see Privilege#WRITE
     * @see Privilege#FULL_CONTROL
     *
     * @status Documented
     */
    public Privilege getPrivilege(Name name) throws NamingException;

    /**
     * Retrieves the highest privilege that the caller has, either as a user or
     * as a member of a group, on the specified object.
     *
     * @param name The name of the object.
     *
     * @return The highest privilege of the caller, either as a user or as a
     *         member of a group, on the specified object. This value
     *         is one of the constants in
     *         <code>oracle.dss.bicontext.Privilege</code>.
     *
     * @see Privilege#LIST
     * @see Privilege#ADD_FOLDER
     * @see Privilege#READ
     * @see Privilege#WRITE
     * @see Privilege#FULL_CONTROL
     *
     * @status Documented
     */
    public Privilege getPrivilege(String name) throws NamingException;

    /**
     * Return true if the feature is supported by the registered
     * storage manager.
     * @see BIConstants#ACL
     * @see BIConstants#WRITE
     * @hidden
     */
    public boolean getFeature(String feature);


    /**
     * Mark the beginning of a reading a consistent set objects.  A
     * {@link ReadConsistencyException} will be thrown if any
     * object has been modified after the first object is read.
     * The end of the set should be marked by calling
     * endConsistentRead.  If endConsistentRead is omitted, the next
     * startConsistentRead will automatically terminate the previous
     * consistent read set.
     * <p>
     * If outside the boundary of a consistent read set, each
     * individual read is considered a self contained consistent read
     * set and so a ReadConsistencyException is never thrown.
     * @see #endConsistentRead()
     */
    public void startConsistentRead();

    /**
     * Mark the end of a consistent read set.
     * @see #startConsistentRead()
     */
    public void endConsistentRead();


}
