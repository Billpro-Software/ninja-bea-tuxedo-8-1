/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Constants (bit sets) that specify exclusions for a drill in a query.
 *
 * @status Documented
 */
public interface DrillConstants
{
    /**
     * Bit identifier that excludes members of intervening levels during a
     * drill.
     *
     * @status Documented
     */
    public static final int DRILL_EXCLUDE_RANGE = 0;
    
    /**
     * Bit identifier that excludes siblings of the target dimension value
     * (also known as dimension member) during a drill.
     *
     * @status Documented
     */
    public static final int DRILL_EXCLUDE_SIBLINGS = 1;
    
    /**
     * Bit identifier that excludes the dimension value (also known as
     * dimension member) that is specified in a drill.
     *
     * @status Documented
     */
    public static final int DRILL_EXCLUDE_SELF = 2;

    /**
     * Bit identifier that indicates that the last level
     * drill should be undone ("drill back")
     *
     * @status New
     */
    public static final int DRILL_BACK = 3;

    /**
     * Specifies a drill by relative level to the top of the specified
     * hierarchy.
     *
     * @status Documented
     */
    //public static final int DRILL_TO_ROOT = Integer.MIN_VALUE;    
}
