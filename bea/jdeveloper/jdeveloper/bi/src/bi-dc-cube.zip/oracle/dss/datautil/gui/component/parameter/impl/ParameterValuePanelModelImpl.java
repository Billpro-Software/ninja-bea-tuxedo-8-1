/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/impl/ParameterValuePanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     12/20/06 - 
    jramanat    11/29/05 - Creation
 */

package oracle.dss.datautil.gui.component.parameter.impl;

import java.util.Arrays;
import java.util.Vector;

import oracle.dss.dataSource.client.QueryManager;
import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.datautil.gui.component.ComponentContext;
import oracle.dss.datautil.gui.component.parameter.ParameterValuePanelModel;
import oracle.dss.selection.parameter.ItemValueParameter;
import oracle.dss.util.Utility;
import oracle.dss.util.parameters.Parameter;
import oracle.dss.util.parameters.ParameterValueManager;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/parameter/impl/ParameterValuePanelModelImpl.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public class ParameterValuePanelModelImpl implements ParameterValuePanelModel {

  private ComponentContext m_context;
  private Query[] m_queries;
  private String[] m_labels;
  private String m_sharedLabel;
  private Parameter[] m_sharedParameters;
  private Parameter[][] m_privateParameters;

  /**
   * Empty Constructor
   */
  public ParameterValuePanelModelImpl(ComponentContext context) {
    setComponentContext(context);
  }
  
  /**
   * Constructor that takes an array of Queries for which parameter values are needed
   * 
   * @param queries The Queries
   * @param labels The header labels for the Queries
   * @param sharedLabel The header label for Parameters shared among Queries
   */
  public ParameterValuePanelModelImpl(ComponentContext context, Query[] queries, String[] labels, String sharedLabel) {
    setComponentContext(context);
    setQueries(queries, labels, sharedLabel);
  }
  
  /**
   * Specifies an array of Queries for which parameter values are needed
   * 
   * @param queries The Queries
   * @param labels The header labels for the Queries
   * @param sharedLabel The header label for Parameters shared among Queries
   */
  public void setQueries(Query[] queries, String[] labels, String sharedLabel) {
    m_queries = queries;
    m_labels = labels;
    m_sharedLabel = sharedLabel;
    updateParameters();
  }
  
  /**
   * Specifies the ComponentContext for this model
   * 
   * @param context The ComponentContext
   */
  public void setComponentContext(ComponentContext context) {
    m_context = context;
  }

  /**
   * Retrieves the ComponentContext for this model
   * 
   * @return The ComponentContext
   */
  public ComponentContext getComponentContext() {
    return m_context;
  }

  public Parameter[] getSharedParameters() {
    return m_sharedParameters;
  }

  /**
   * Specifies the parameters to be prompted for in the "Shared" section.  This
   * overrides the parameters derived from the specified Queries
   * 
   * @param parameters The parameters to prompt for
   */
  public void setSharedParameters(Parameter[] parameters) {
    m_sharedParameters = parameters;
  }
  
  public int getPrivateCount() {
    if (m_queries == null) {
      return 0;
    }
    return m_queries.length;
  }
  
  public Parameter[] getPrivateParameters(int index) {
    return m_privateParameters[index];
  }
  
  /**
   * Specifies the parameters to be prompted for in a particular section.  This
   * overrides the parameters derived from the specifed Queries.
   * 
   * @param index The index of the query to override
   * @param parameters The parameters to prompt for
   */
  public void setPrivateParameters(int index, Parameter[] parameters) {
    m_privateParameters[index] = parameters;
  }

  public void setSharedValue(Parameter parameter, Object value) {
    if (m_queries != null && m_queries.length > 0) {
        if (((QueryManager)m_queries[0].getQueryManager()).getParameterValueManager() != null)
        {
            ((QueryManager)m_queries[0].getQueryManager()).getParameterValueManager().setValue(parameter, value == null ? ParameterValueManager.UNSPECIFIED : value);
        }
    }
  }

  public Object getSharedValue(Parameter parameter) {
    if (m_queries != null && m_queries.length > 0) {
        Object value = null;
        if (((QueryManager)m_queries[0].getQueryManager()).getParameterValueManager() != null)
        {
            value = ((QueryManager)m_queries[0].getQueryManager()).getParameterValueManager().getValue(parameter);
        }
        if (value == ParameterValueManager.UNSPECIFIED) {
            return null;
        }
        else if (value == null) {
        return parameter.getDefaultValue();
      }
      else {
        return value;
      }
    }
    return null;
  }
  
  public void setPrivateValue(int index, Parameter parameter, Object value) {
    if (m_queries[index].getParameterValueManager() != null)
        m_queries[index].getParameterValueManager().setValue(parameter, value == null ? ParameterValueManager.UNSPECIFIED : value);
  }
  
  public Object getPrivateValue(int index, Parameter parameter) {
    Object value = m_queries[index].getParameterValueManager().getValue(parameter);
    if (value == ParameterValueManager.UNSPECIFIED) {
      return null;
    }
    else if (value == null) {
      return parameter.getDefaultValue();
    }
    else {
      return value;
    }    
  }

  public String getSharedLabel() {
    return m_sharedLabel;
  }

  public String getPrivateLabel(int index) {
    return m_labels[index];
  }

  private void updateParameters() {
    if (m_queries == null || m_queries.length == 0) {
      m_sharedParameters = null;
      m_privateParameters = null;
      return;
    }
    Vector sharedParameters = new Vector();
    Vector privateParameters = new Vector();
    for (int i = 0; i < m_queries.length; i++) {
      Parameter[] params = m_queries[i].getParameters();
      privateParameters.add(Utility.copyArrayToVector(params));
    }
    for (int i = 0; i < privateParameters.size(); i++) {
      Vector params = (Vector)privateParameters.get(i);
      Vector updatedParams = new Vector();
      for (int j = 0; j < params.size(); j++) {
        Parameter param = (Parameter)params.get(j);
        if (!sharedParameters.contains(param)) {
          if (m_queries[i].usesParameter(param) || (i == privateParameters.size() - 1)) {
            updatedParams.add(param);
          }
          else {
            boolean shared = false;
            for (int k = i + 1; k < privateParameters.size(); k++) {
              Vector v = (Vector)privateParameters.get(k);
              if (v.contains(param)) {
                shared = true;
                sharedParameters.add(param);
                break;
              }
            }
            if (!shared) {
              updatedParams.add(param);
            }
          }
        }
      }
      privateParameters.set(i, updatedParams);
    }
    m_sharedParameters = (Parameter[])sharedParameters.toArray(new Parameter[sharedParameters.size()]);
    m_privateParameters = new Parameter[privateParameters.size()][];
    for (int i = 0; i < m_privateParameters.length; i++) {
      Vector params = (Vector)privateParameters.get(i);
      m_privateParameters[i] = (Parameter[])params.toArray(new Parameter[params.size()]);
    }
  }
  
  public void apply() {
    if (m_queries != null) {
      for (int i = 0; i < m_queries.length; i++) {
        try {
          m_queries[i].refresh(QueryConstants.REFRESH_REBUILD);
        }
        catch (QueryException e) {
          m_context.getErrorHandler().error(e, getClass().getName(), "apply");
        }
      }
    }
  }
}