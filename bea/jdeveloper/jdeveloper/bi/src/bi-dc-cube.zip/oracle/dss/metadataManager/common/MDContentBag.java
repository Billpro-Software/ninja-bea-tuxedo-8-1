/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.lang.Object;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.Property;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.metadataUtil.OrderedHashtable;

/*
	Content Bag contains a hashtable of mdObjects (key)
	andStrings represents the relation or context.
*/
/**
 * @hidden
 */
public class MDContentBag implements Serializable {
  /************************************************************************
  * Private members
  ************************************************************************/
  //  PropertyBag    	- PropertyBag (Key)
  //  String 					- Name
  private  OrderedHashtable m_ContentBag = null;

  /************************************************************************
  * Public Methods
  ************************************************************************/
	//Default Constructor
    public MDContentBag() {
        m_ContentBag = new OrderedHashtable();
    }

    public MDContentBag( int initialCapacity ) {
        m_ContentBag = new OrderedHashtable( initialCapacity );
    }
  /************************************************************************
  * Public Methods
  ************************************************************************/

    public int size(){
        return m_ContentBag.size();
    }

    public PropertyBag[] getContents(){
        if ( size() == 0)
            return null;
        PropertyBag[] mdObjects = new PropertyBag[size()];
        Enumeration enumer = m_ContentBag.keys();
        for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
            mdObjects[i] = (PropertyBag) enumer.nextElement();
        }
        return mdObjects ;
    }

    public Enumeration keys() {
        return m_ContentBag.keys();
    }

    public String getRelation( PropertyBag propertyBag ) {
        return (String) m_ContentBag.get( (Object) propertyBag );
    }

    public static MDContentBag filterContentBag( MDContentBag contentBag, String relation ){
        if ( ( relation == null ) || ( contentBag == null ))
            return contentBag;
        if ( contentBag.size() == 0)
            return null;
        MDContentBag _contentBag = new MDContentBag();
        Enumeration enumer = contentBag.keys();
        while(enumer.hasMoreElements()){
            PropertyBag propertyBag = (PropertyBag) enumer.nextElement();
            if( relation.equals ( contentBag.getRelation ( propertyBag ) ) ) {
                _contentBag.setContentItem( propertyBag, relation );
            }
        }
        if ( _contentBag.size() > 0 )
            return _contentBag;
        return null;
    }

	public static MDContentBag filterContentBag( MDContentBag contentBag, Property property ){
		if ( ( property == null ) || ( contentBag == null ))
			return contentBag;
		if ( contentBag.size() == 0)
			return null;
		MDContentBag _contentBag = new MDContentBag();
		Enumeration enumer = contentBag.keys();
		int i = 0;
		for ( i = 0 ; enumer.hasMoreElements() ; i++ ) {
			PropertyBag propertyBag = (PropertyBag) enumer.nextElement();
			if ( (propertyBag.contains( property))){
				_contentBag.setContentItem( propertyBag, property.getName() );
			}
		}
		if ( i == 0 )
			return null;
		return _contentBag;
	}

	public static PropertyBag[] getPropertyBagArray ( MDContentBag contentBag ){
		if ( contentBag == null )
			return null;
		int count = contentBag.size();
		if ( count == 0 )
			return null;
		PropertyBag[] props = new PropertyBag[count];
		Enumeration enumer = contentBag.keys();
		for ( int i = 0 ; ((enumer.hasMoreElements()) && ( i < count )) ; i++ ) {
			props[i] = (PropertyBag) enumer.nextElement();
		}
		return props;
	}

    public PropertyBag[] getContents( Property property ){
        MDContentBag contentBag = filterContentBag ( getContentBag(), property );
        if ( contentBag == null )
            return null;
        if ( contentBag.size() == 0)
            return null;
        return getPropertyBagArray ( contentBag );
    }

    public PropertyBag[] getContents( String relation ){
        MDContentBag contentBag = filterContentBag ( getContentBag(), relation );
        if ( contentBag == null )
            return null;
        if ( contentBag.size() == 0)
            return null;
        return getPropertyBagArray ( contentBag );
    }

    public PropertyBag[] getContents( String relation, Property property ){
        if(relation == null && property == null) {
            return getPropertyBagArray(getContentBag());
        }
        Enumeration enumer = m_ContentBag.keys();
        MDContentBag contentBag = new MDContentBag();
        if(relation != null && property != null)
        {
            while(enumer.hasMoreElements())
            {
                PropertyBag tmp = (PropertyBag)enumer.nextElement();
                if(relation.equals((String)m_ContentBag.get(tmp)) &&
                   tmp.contains(property)) {
                    contentBag.setContentItem(tmp, relation);
                }
            }
        }
        else if(property != null) {
            while(enumer.hasMoreElements())
            {
                PropertyBag tmp = (PropertyBag)enumer.nextElement();
                if(tmp.contains(property)) {
                    contentBag.setContentItem(tmp, (String)m_ContentBag.get(tmp));
                }
            }
        }
        else if(relation != null) {
            while(enumer.hasMoreElements())
            {
                PropertyBag tmp = (PropertyBag)enumer.nextElement();
                if(relation.equals((String)m_ContentBag.get(tmp))){
                    contentBag.setContentItem(tmp, relation);
                }
            }
        }

        if( contentBag == null )
            return null;
        if ( contentBag.size() == 0)
            return null;
        return getPropertyBagArray ( contentBag );
    }

	public PropertyBag getContentItem( String relation, Property property ){
		PropertyBag[] props = getContents ( relation, property );
		if (( props != null ) && ( props.length > 0 )) {
			PropertyBag p =  props[0];
			return p;
		}
		return null;
	}

	public void setContentItem( PropertyBag propertyBag, String relation  ){
		m_ContentBag.put ( (Object) propertyBag, (Object) relation );
		return;
	}

    public void resetContentItem( PropertyBag propertyBag,  String propertyName ) {
        // no-op logic
/*
        if( ( propertyBag == null ) || ( propertyName == null ))
            return;

        Enumeration enumer = m_ContentBag.keys();
        PropertyBag obj = null;
        while( enumer.hasMoreElements() ) {
            obj = (PropertyBag)enumer.nextElement();
            String strItem = obj.getStrPropertyValue(propertyName);
            String strBag = propertyBag.getStrPropertyValue(propertyName);
            if ( (strItem != null) && ( strBag != null) && ( strItem.equals (strBag) )) {
                String relation = (String)m_ContentBag.get( obj );
                setContentItem( propertyBag, relation );
                break;
            }
        }
*/
    }

	public void removeContentItem( PropertyBag propertyBag ) {
		m_ContentBag.remove ( (Object) propertyBag );
		return;
	}

	public void removeContents( String relation ) {
		PropertyBag[] mdObjects = getContents ( relation );
		for ( int i = 0; ( ( mdObjects != null) && ( mdObjects.length > 0) ); ){
			removeContentItem( mdObjects[i] );
		}
		return;
	}

	public void removeContents( String relation, Property property ) {
		PropertyBag[] mdObjects = getContents ( relation, property );
		for ( int i = 0; ( ( mdObjects != null) && ( mdObjects.length > 0) ); ){
			removeContentItem ( mdObjects[i] );
		}
		return;
	}

	public void removeAll() {
        m_ContentBag.clear();
	}

	public OrderedHashtable getContentTable(){
		return m_ContentBag;
	}

    public MDContentBag getContentBag(){
        MDContentBag _bag = new MDContentBag();
        _bag.setContentTable ( m_ContentBag );
        return _bag;
    }

	public void setContentTable( OrderedHashtable contentTable ){
		m_ContentBag = contentTable;
		return;
	}

  public static MDContentBag mergeContentBags ( MDContentBag firstBag, MDContentBag secondBag ) {
    if (( firstBag == null ) && ( secondBag == null ))
      return null;

    if (( firstBag == null ) || ( secondBag == null )) {
      firstBag = ((firstBag != null) && ( firstBag.size() > 0)) ? firstBag : secondBag ;
      return firstBag;
    }

    OrderedHashtable firstTable = firstBag.getContentTable();
    OrderedHashtable secondTable = secondBag.getContentTable();
    firstTable = mergeHashtables ( firstTable, secondTable );
    if (( firstTable != null ) && ( firstTable.size() > 0 )) {
      firstBag.setContentTable ( firstTable );
      if ( firstBag.size() > 0 )
        return firstBag;
    }
    return null;
  }

  public static OrderedHashtable mergeHashtables ( OrderedHashtable firstTable, OrderedHashtable secondTable ) {
    if (( firstTable == null ) && ( secondTable == null ))
      return null;

    if (( firstTable == null ) || ( secondTable == null )) {
      firstTable = ((firstTable != null) && ( firstTable.size() > 0 )) ? firstTable : secondTable ;
      return firstTable;
    }

    Enumeration enumer = secondTable.keys();
    while( enumer.hasMoreElements() ) {
      Object obj = enumer.nextElement();
      firstTable.put ( obj, secondTable.get ( obj ) );
    }
    if ( firstTable.size() > 0)
      return firstTable;
    return null;
  }

  public void print( int type ) {
    if ( size() == 0)
      return;
    Enumeration enumer = m_ContentBag.keys();
    for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
      PropertyBag prop = (PropertyBag) enumer.nextElement();
      String str = (String) m_ContentBag.get( prop );
      System.out.println ( "=====Item[" + (i+1) + "] : ID("
          + prop.getStrPropertyValue ( "Object ID" )
          + ") Type(" + prop.getStrPropertyValue ( "object_type")
          + ") Relation(" + str
          + ") Unique_ID(" + prop.getStrPropertyValue ( "Olapi Metadata ID")
          + ") Name(" + prop.getStrPropertyValue ( "Name") + ")" );
      if ( type == 1 ) {
        System.out.println ( "-------No. Properties = " + prop.size() );
        prop.print();
      }
    }
    return;
  }

    public void free() {
        removeAll();
        m_ContentBag = null;
        return;
    }
}
