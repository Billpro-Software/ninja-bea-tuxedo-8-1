/**
 * $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/client/QueryClient.java /main/280 2008/11/26 18:42:06 bmoroze Exp $
 *
 * Copyright (c) 2000, 2008, Oracle and/or its affiliates.All rights reserved. 
 */
package oracle.dss.dataSource.client;

import java.lang.reflect.Constructor;
import oracle.dss.connection.common.BISession;

import oracle.dss.dataSource.common.ColumnSortChangedEvent;
import oracle.dss.dataSource.common.ColumnSortChangingEvent;
import oracle.dss.dataSource.common.CubeDataDirectorImpl;
import oracle.dss.dataSource.common.DataAvailableEvent;
import oracle.dss.dataSource.common.DataChangedEvent;
import oracle.dss.dataSource.common.DataFilterChangedEvent;
import oracle.dss.dataSource.common.DataFilterChangingEvent;
import oracle.dss.dataSource.common.Delegate;
import oracle.dss.dataSource.common.IllegalOperationException;
import oracle.dss.dataSource.common.InvalidDimensionException;
import oracle.dss.dataSource.common.ItemDrillRequestedEvent;
import oracle.dss.dataSource.common.ItemDrillRequestingEvent;
import oracle.dss.dataSource.common.LayoutChangedEvent;
import oracle.dss.dataSource.common.NoQueryDefinedException;
import oracle.dss.dataSource.common.QueryListener;
import oracle.dss.dataSource.common.QueryState;
import oracle.dss.dataSource.common.StateChangedEvent;
import oracle.dss.dataSource.common.QueryConstants;
import oracle.dss.datautil.QueryAccess;
import oracle.dss.datautil.QueryEditor;
import oracle.dss.metadataManager.common.MDItem;
import oracle.dss.selection.dataFilter.BaseDataFilter;
import oracle.dss.selection.dataFilter.DataFilter;
import oracle.dss.selection.dataFilter.CompoundDataFilter;
import oracle.dss.selection.dataFilter.RangeDataFilter;
import oracle.dss.selection.dataFilter.TopBottomDataFilter;
import oracle.dss.selection.sortWrapper.ColumnSortWrapper;
import oracle.dss.util.BIBaseException;
import oracle.dss.util.DataDirector;
import oracle.dss.util.LayoutAccess;

import java.util.BitSet;
import java.util.Vector;
import java.util.Hashtable;
import java.text.MessageFormat;

import javax.swing.event.UndoableEditListener;

import oracle.dss.dataSource.common.Query;
import oracle.dss.dataSource.common.QueryEvent;
import oracle.dss.dataSource.common.QueryUtil;
import oracle.dss.dataSource.common.QueryException;
import oracle.dss.dataSource.common.QueryBusyException;
import oracle.dss.dataSource.common.OperationQueue;
import oracle.dss.dataSource.common.EventList;
import oracle.dss.dataSource.common.StateChangingEvent;
import oracle.dss.dataSource.common.DataChangingEvent;
import oracle.dss.dataSource.common.LayoutChangingEvent;
import oracle.dss.dataSource.common.StateChangeEvent;
import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.IllegalArgException;
import oracle.dss.dataSource.common.InvalidMetadataException;
import oracle.dss.dataSource.common.MapSupport;
import oracle.dss.dataSource.common.BaseOperationQueue;
import oracle.dss.dataSource.common.QueryRuntimeException;
import oracle.dss.dataSource.common.DimTree;
import oracle.dss.dataSource.common.Node;
import oracle.dss.dataSource.common.RecoveryInfo;

import oracle.dss.util.LayoutAccess2;
import oracle.dss.util.Utility;
import oracle.dss.util.QDR;
import oracle.dss.util.DataAccess;
import oracle.dss.util.DataMap;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.MetadataMap;
import oracle.dss.util.Operation;
import oracle.dss.util.Parameter;
import oracle.dss.util.parameters.ParameterValueManager;
import oracle.dss.util.persistence.AggregateInfo;
import oracle.dss.util.persistence.XMLContext;
import oracle.dss.util.persistence.BIPersistenceException;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.transform.BaseNode;
import oracle.dss.util.xml.ObjectNode;
import oracle.dss.util.xml.NoSuchPropertyException;
import oracle.dss.util.StatusInfo;

import oracle.dss.selection.OlapQDR;

import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataManager.common.MetadataManagerServices;
import oracle.dss.connection.client.Connection;
import oracle.dss.dataSource.common.CommonDataDirector;
import oracle.dss.metadataManager.client.MetadataManager;
import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDMeasure;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.PropertyBag;
import oracle.dss.selection.dataFilter.VariableSettingDataFilter;
import oracle.dss.util.transform.BaseProjection;

/**
 * Implements the DataSource API from the client perspective.
 * This object is the Query Java Bean. To create a <code>QueryClient</code>
 * object, take one of the following actions:
 * <ul> <li>
 * Use the <code>createQuery</code> factory method of a
 * <code>QueryManager</code> object that resides on the client tier.
 * This action implicitly sets the QueryManager property of the
 * <code>QueryClient</code> object. </li>
 * <li>
 * Use a constructor of this QueryClient class. If the constructor does not
 * specify the <code>QueryManager</code> that should track the
 * <code>QueryClient</code>, then you must explicitly set the QueryManager
 * property of the <code>QueryClient</code>. </li>
 * <eul>
 *
 */
public class QueryClient extends Query
{
    /////////////////////
    //
    // Member Variables
    //
    /////////////////////

    // Backing QueryManager instance
    private QueryManager  m_queryManager  = null;

    // Temporary state storage to stage for middle tier
    private transient boolean m_noEvalOnReload = false;
    private transient boolean m_needsPropSync = false;
    
    protected final String DIRECT_OLAPI_PLUGGABLE = "OLA";
//    protected final String SBA_SQL_PLUGGABLE = "SBASQL";
    protected final String SBA_XML_PLUGGABLE = "SBAXML";

    
    /**
     * @internal
     * Current pluggable
     */
    protected QueryInterface m_qi = new NullQueryInterfaceImpl(this);

    /**
     * @internal
     */
    protected ParameterValueManager m_pvm = null;
    
    /////////////////////
    //
    // Constructors
    //
    /////////////////////
    /**
     * Constructs a <code>QueryClient</code> object without specifying the
     * <code>QueryManager</code> object that will track it.
     * This <code>QueryClient</code> object will not have state or evaluate
     * until its QueryManager property is specified.
     *
     * 
     */
    public QueryClient()
    {
        super();
        m_listeners = new ClientListenerLists();
        m_opQueue = new OperationQueue(isAutoUpdate(), null, this, m_listeners);
        setID(assignNewGUID());
        registerPluggables();
    }

    /**
     * Constructs a <code>QueryClient</code> object and specifies the
     * <code>QueryManager</code> object that will track the
     * <code>QueryClient</code>.
     *
     * @throws Exception Error encountered bringing back query after persistence
     *
     * 
     */
    public QueryClient(QueryManager qm) throws Exception
    {
        this();
        setQueryManager(qm);
        // Should redo this to make sure it's initialized in the QM context
//        m_mapSupport = new MapSupport(this);
    }

    
    /**
     * Cancels the current operation operation.
     *
     * 
     */
    public void cancel()
    {
        try
        {
            m_qi.cancel();
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    /**
     * Adds a listener to this <code>Query</code> object.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param l The listener that is to be added.
     *
     * @status Needs change
     */
    public void addQueryListener(QueryListener l) {
        // Don't add if already there
        if (m_listeners.listeners.indexOf(l) > -1)
            return;
            
        
        // If data is available, fire an event
        try
        {
            DataAccess da = generateDataAccess((DataDirector)null, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
            DataDirector dd = m_qi.getDataDirector(da);
            if (dd == null)
                dd = new CubeDataDirectorImpl(this, getCubeDataDirectorFromImpl());

            m_listeners.add(l, dd);
            if (!firePollingRequired(l, null))
            {
                l.dataAvailable(new DataAvailableEvent(this, isDataAvailable(), da));
            }
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e);
        }
    }

    // javadoc from interface
    public Object getQueryObject()
    {
        return m_qi.getQueryObject();
    }

   /**
    * Specifies the current page if pages are shared among listeners.
    *
    * @param page    Page number to share among listeners.
    * @param qdrPage QDR version of the page.
    *
    * 
    */
   public void setCurrentPage(long page, QDR qdrPage)
   {
      setCurrentPage(page, qdrPage, null);
   }
   
   /**
     * @internal
     * @param page
     * @param qdrPage
     * @param dd
     */
   public void setCurrentPage(long page, QDR qdrPage, CommonDataDirector dd)
   {
        try
        {
            checkQueryBusy(false);
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
      
        Parameter[] params = new Parameter[] {new Parameter(new Long(page), Long.class), new Parameter(qdrPage, QDR.class), new Parameter(dd, CommonDataDirector.class)};

        EventList el = new EventList();
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PAGE_CHANGE));

        try
        {
            queueOperation(getOpQueue(), "_setCurrentPage", params, true, null, "setCurrentPage", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            setCurrentOperation(null);
            throw new QueryRuntimeException(e.getMessage(), e);
        }    
        finally
        {
            setCurrentOperation(null);
        }
    }

   
   /**
     * @internal 
     * @throws oracle.dss.dataSource.common.QueryException
     * @param queue
     * @param before
     * @param userOp
     * @param qdrPage
     * @param page
     */
    public void _setCurrentPage(long page, QDR qdrPage, CommonDataDirector dd, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
       _getQueryState().getPropertySupport().setCurrentPage(page, qdrPage);
       try
       {
            m_qi.setCurrentPage(page, qdrPage);
            addToUndo(queue, userOp, before, _getQueryState());
            BitSet edges = new BitSet(3);
            edges.set(DataDirector.PAGE_EDGE);
            queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.PAGE_CHANGE, null, dd != null ? dd.getWrapper() : null));                        
       }
       catch (QueryException e)
       {
           throw new QueryRuntimeException(e.getMessage(), e);
       }
       finally
       {
           setCurrentOperation(null);
       }
   }
   
               
    /**
     * @internal
     */
    protected Delegate getCubeDataDirectorFromImpl()
    {
        return m_qi == null ? null : m_qi.createCubeDataDirector();        
    }
    
    /**
     * @internal
     */
    protected Delegate getRelationalDataDirectorFromImpl()
    {
        return m_qi == null ? null : m_qi.createRelationalDataDirector();
    }

    // javadoc from interface
    public Object isSupported(int capability, Object data) throws QueryException
    {
        return m_qi.isSupported(capability, data);
    }

    // javadoc from interface
    public int pivotCheck(String source, String target, int flags) throws QueryException
    {
        return m_qi.pivotCheck(source, target, flags);
    }

    // javadoc from interface
    public int swapCheck(String source, String target) throws QueryException
    {
        return m_qi.swapCheck(source, target);
    }

    // javadoc from interface
    public BaseProjection getProjection(String layerMetadataType) throws QueryException
    {
        return m_qi.getProjection(layerMetadataType);
    }

    /**
     * @internal
     */
    public String getMeasureDim(String layerMetadataType) throws InvalidMetadataException
    {
        MDDimension dim = getMeasureDimObj();
        if (dim != null)
        {
            return QueryUtil.getLayerMetadata(layerMetadataType, dim);
        }            
        return null;        
    }
    
    /**
     * @internal
     * Generate a DataAccess
     */
    public DataAccess generateDataAccess(DataDirector dd, int changeType) throws QueryException
    {
        if (m_qi != null)
        {
            DataAccess[] da2 = generateDataAccess(new DataDirector[] {dd}, changeType);
            if (da2 != null && da2.length > 0)
                return da2[0];
        }
        return null;
    }
    

    /**
     * @internal
     * Return a data director given a data access
     */
    protected DataDirector getDataDirector(DataAccess da)
    {
        return m_qi.getDataDirector(da);
    }

    /**
     * @internal
     */
     protected DataAccess[] generateDataAccess(DataDirector[] dd, int changeType) throws QueryException
     {
         return m_qi.generateDataAccess(dd, changeType);
     }
    
    /**
     * @internal
     * Register default pluggables for Query interface SPI
     */
    protected void registerPluggables()
    {
        Hashtable hash = new Hashtable();
//        hash.put("oracle.dss.dataSource.client.QueryInterface", "oracle.dss.dataSource.olap.client.OLAPQueryInterfaceImpl");
        //registerImplementation(DIRECT_OLAPI_PLUGGABLE, hash);
//        hash = new Hashtable();
        //hash.put("oracle.dss.dataSource.client.QueryInterface", "oracle.dss.dataSource.et.client.ETOLAPQueryInterfaceImpl");
        //registerImplementation(MM.MDM, hash);
        //hash = new Hashtable();
        //hash.put("oracle.dss.dataSource.client.QueryInterface", "oracle.dss.dataSource.et.client.RelationalQueryInterfaceImpl");
        //registerImplementation(MM.EUL, hash);
        //hash = new Hashtable();
        //hash.put("oracle.dss.dataSource.client.QueryInterface", "oracle.dss.dataSource.bi.client.SBASQLQueryInterfaceImpl");
        //registerImplementation(SBA_SQL_PLUGGABLE, hash);
        hash = new Hashtable();
        hash.put("oracle.dss.dataSource.client.QueryInterface", "oracle.dss.dataSource.bi.client.SBAXMLQueryInterfaceImpl");
        registerImplementation(SBA_XML_PLUGGABLE, hash);
    }

 
    /**
     * 
     * @throws oracle.dss.dataSource.common.InvalidMetadataException
     * @throws oracle.dss.metadataManager.common.MetadataManagerException
     * @return 
     */
    protected MDObject getDataSourceObj(String ID) throws MetadataManagerException, InvalidMetadataException
    {
        if (ID != null && ID.equals(getMeasureDim()))
        {
            // We don't want to use the measure dim as any kind of data source obj
            return null;
        }
        MDObject obj = getMetadataManager().getMDObject(MM.UNIQUE_ID, ID, MM.OBJECT);
        // Check if it has a valid data source
        if (obj != null && getMDObjectDataSourceValid(obj))
            return obj;
        return null;
    }

    /**
     * @internal
     */
  // blm - Selection code moved to dvt-olap
/*    protected MDObject getDataSourceObj(Selection[] sels) throws MetadataManagerException, InvalidMetadataException
    {
        if (sels == null)
            return null;
            
        for (int i = 0; i < sels.length; i++)
        {
            // Special case for measure
            if (sels[i].getDimension().equals(getMeasureDim()))
            {
                // Use the members in the other type of getDataSourceObj instead
                int count = sels[i].getStepCount();
                for (int step = 0; step < count; i++)
                {
                    if (sels[i].getStep(i) instanceof MemberStep)
                    {
                        MemberStep ms = ((MemberStep)sels[i].getStep(i));
                        Vector members = ms.getMembers();
                        if (members != null)
                        {
                            String[] membs = (String[])members.toArray(new String[]{});
                            MDObject obj = getDataSourceObj(membs, null);
                            if (obj != null && getMDObjectDataSourceValid(obj))
                                return obj;
                        }
                    }
                }
            }
            MDObject obj = getMetadataManager().getMDObject(MM.UNIQUE_ID, sels[i].getDimension(), MM.OBJECT);
            // Check if it has a valid data source
            if (obj != null && getMDObjectDataSourceValid(obj))
                return obj;
        }
        return null;
    }
  */  
    protected boolean getMDObjectDataSourceValid(MDObject obj)
    {
        if (obj.getDatasource() != null)
            return true;
            
        // Check if this is worthwhile
        if (isOLAP() || m_qi instanceof NullQueryInterfaceImpl)
            return true;
        
        return false;
    }
    
    /**
     * @internal
     */
    public void eventHelper(QueryEvent e)
    {
        getCurrentQueue().eventHelper(e);
    }

  /**
   * @internal
   */
  protected MDObject getDataSourceObj(String[] ids, String[][] items)
    throws MetadataManagerException, InvalidMetadataException {
    MDObject mdobj = null;
    if (ids != null) {
      for (int i = 0; i < ids.length; i++) {
        mdobj = getDataSourceObj(ids[i]);
        
        if (mdobj != null)
          return mdobj;
      }
    }
    if (items != null) {
      for (int e = 0; e < items.length; e++) {
        
        if (items[e] != null) {
        
          for (int l = 0; l < items[e].length; l++) {
            mdobj = getDataSourceObj(items[e][l]);
        
            if (mdobj != null)
              return mdobj;
          }
        }
      }
    }

    return null;
  }

  /**
     * @internal
     * Retrieve an MDObject from the cache or MetadataManager object.
     *
     * @param  strID a <code>String</code> value that represents the metadata
     *         manager ID.
     * @param  strValue a <code>String</code> value that represents the runtime
     *         value of the metadata object we are trying to find.
     * @param  strType a <code>String</code> value that represents the
     *         MetadataManager type.
     *
     * @return <code>MDObject</code> which represents the metadata object
     *          associated with the specified values.
     *
     * @throws <code>MetadataManagerException</code> if metadata object can't
     *         be found.
     *
     * @status hidden
     */
    public MDObject getMDObject (String strID, String strValue, String strType)
                                    throws MetadataManagerException {
      return getMDObject (strID, strValue, strType, false, null, true);                                    
    }

    /**
     * @internal
     */
    public boolean isMeasure(String dim)
    {
        try
        {
            return getMeasureDim().equals(dim);
        }
        catch (InvalidMetadataException ime)
        {
            throw new QueryRuntimeException(ime.getMessage(), ime);
        }
    }
    
    /**
     * @internal
     * 
     * Retrieve an <code>MDObject</code> from the cache or <code>MetadataManager<code>.
     *
     * @param strID a <code>String</code> value that represents the metadata
     *        manager ID.
     * @param strValue a <code>String</code> value that represents the runtime
     *        value of the metadata object we are trying to find.
     * @param strType a <code>String</code> value that represents the
     *        MetadataManager type.
     * @param bAddNull a <code>boolean</code> value that is <code>true</code>
     *        when null values should be added to the cache and <code>false</code>
     *        otherwise.
     * @param obj add the given object to the cache without doing a lookup at all, if not null.
     *
     * @return <code>MDObject</code> which represents the metadata object
     *          associated with the specified values.
     *
     * @throws <code>MetadataManagerException</code> if <code>MDObject</code> 
     *         object cannont be found.
     *
     * @status hidden
     */
    public MDObject getMDObject (String strID, String strValue, String strType,
                            boolean bAddNull, MDObject obj, boolean dontCheckMM) throws MetadataManagerException {

      // Try to get the value locally...if we can't call the server side because some 
      // things may be cached there only      
      MDObject mdObject = super.getMDObject(strID, strValue, strType, bAddNull, obj, false);
      
/*      if (mdObject == null)
      {
          // We always want to execute this immediately: informational
          OperationQueue tempQueue = generateTempOpQueue();
          if (tempQueue == null)
          {
                return null;
          }
          Parameter[] params = {new Parameter(strID, String.class), new Parameter(strValue, String.class), 
                                new Parameter(strType, String.class), new Parameter(new Boolean(bAddNull), Boolean.class),
                                new Parameter(obj, MDObject.class), new Parameter(new Boolean(false), Boolean.class)};
          try {
              mdObject = (MDObject)tempQueue.addOperation(new Operation("getMDObject", params, false));
          }
          catch (IllegalArgumentException iae) {
              throw iae;
          }
          catch (Throwable e) {
              // Unknown
              throw new QueryRuntimeException(e.getMessage(), e);              
          }
          if (!isDesignTime() && isProxySet())
          {
              mdObject = getQueryManagerProxy().getMDObject(getID(), strID, strValue, strType, bAddNull, obj, false);
          }
          
          
          if (mdObject != null)
          {
              // Special case: fetched from the server side--store it locally
              super.getMDObject(strID, strValue, strType, bAddNull, mdObject, false);
          }
      }*/
      return mdObject;
    }

    /**
     * @internal
     */
/*    public void setMDCACHE(boolean value) throws Exception
    {
        MDCACHE = value;
        if (isProxySet()) {
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return;
            }
            Parameter[] params = {new Parameter(new Boolean(value), Boolean.class)};
            try {
                tempQueue.addOperation(new Operation("setMDCACHE", params, true));
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                {
                    throw (Exception)e;
                }
            }
        }
    }*/

    /**
     * Specifies the QueryManager property for this
     * <code>QueryClient</code> object.
     *
     * @param qm   An instance of a <code>QueryManager</code> object.
     *
     * @throws Exception Error encountered bringing back query after
     *                   persistence.
     *
     * 
     */
    public void setQueryManager(oracle.dss.dataSource.common.QueryManager qm) throws Exception
    {
        try
        {
            _setQueryManager((QueryManager)qm, true, false);
        }
        catch (Throwable e)
        {
            if (e instanceof Exception)
            {
                throw (Exception)e;
            }
        }
    }



    
    /**
     * @internal
     */
    protected QueryManager _getQueryManager()
    {
        return (QueryManager)getQueryManager();
    }

/*    private void _reestablishFromPersistence() throws Throwable
    {
        if (m_persistentStateSet)
        {
            // Now we need to send over state to this query's counterpart
            if (isProxySet() && m_xml != null)
            {
//                getQueryManagerProxy().setXML(getID(), m_XMLContext, m_xml, m_aggregateInfo);
                m_XMLContext = null;
                m_xml = null;
                m_aggregateInfo = null;
            }

            if (getMetadataManager() != null)
            {
                // Database is set: we can restart
                _databaseSet(_getQueryManager().isDatabaseAvailable());
            }
        }
    }
*/

    /**
     * @internal
     */
    protected void _setQueryManager(QueryManager qm, boolean add, boolean persistence) throws Throwable
    {
        try
        {
            // We know this does not throw any exceptions
            super.setQueryManager(qm);
        }
        catch (Exception e)
        {
        }
        setParameterValueManager(qm.getParameterValueManager());
        setProperties(qm.getProperties());
        setDebugMode(qm.isDebugMode());
        setAllowDivideByZero(qm.isAllowDivideByZero());
        setSQLDump(qm.getSQLDump());
        setQuerySQLType(qm.getQuerySQLType());
        setQueryValueOnly(qm.isQueryValueOnly());
        setSelfCalcTotals(qm.isSelfCalcTotals());
        m_QADebugMode = qm.isQADebugMode();
//        setPrintQueryState(qm.isPrintQueryState());
        setSeparatePage(qm.isSeparatePage());
        setAnnotationsAllowed(qm.areAnnotationsAllowed());
        if (!persistence)
        {
            setHierarchicalDrilling(qm.isHierarchicalDrilling());
            setFetchSize(qm.getFetchSize());
            setFetchPageEdge(qm.getFetchPageEdge());
            setAsymmetricDrilling(qm.isAsymmetricDrilling());
            setDrillWithFilteredChildren(qm.isDrillWithFilteredChildren());
        }

        m_queryManager = qm;
        if (add)
        {
            _getQueryManager().addQuery(this);
        }
        //getOpQueue().setProxy(getQueryManagerProxy());
        getOpQueue().setQueryManager(qm);

        //_reestablishFromPersistence();
    }


    /**
     * Retrieves a reference to the <code>QueryManager</code> object
     * that tracks this <code>QueryClient</code> object.
     *
     * @return   A reference to a <code>QueryManager</code> object or
     *           <code>null</code>.
     *
     * 
     */
    public oracle.dss.dataSource.common.QueryManager getQueryManager()
    {
        return m_queryManager;
    }

    /**
     * Indicates whether the Query validates XML against its DTD.
     *
     * @param validate <code>true</code> if XML is validated;
     *                 <code>false</code> if the Query applies XML without
     *                 testing for validity.
     *
     * 
     */
    public void setXMLValidated(boolean validate)
    {
        super.setXMLValidated(validate);
    }

    /**
     * @internal
     */
    protected DataDirector[] getDataDirectors()
    {
        return super.getDataDirectors();
    }
    
    /**
     *  @internal
     * @return 
     */
 /*   protected boolean _validate(String xml) throws BIPersistenceException
    {
        m_persistentStateSet = true;
       try
        {
            
            if (isXMLValidated())
            {
                XMLObjectReader _xmlReader = new XMLObjectReader(xml);
                try
                {
                    _xmlReader.setValidationMode(true);
                    _xmlReader.setDTD("/oracle/dss/dataSource/common/Query.dtd", "Query");
                }
                catch (BIParseException bipe)
                {
                    //If there is an exception here, the DTD is incorrect
                    getErrorHandler().log(bipe.toString(), getClass().getName(), "setXMLAsString");
                    getErrorHandler().log("Syntax error in DTD in line number " + bipe.getLineNumber() 
                                                        + ", column number " + bipe.getColumnNumber(), getClass().getName(), "setXMLAsString");
                    throw bipe;                                                                                                                
                }
                catch (oracle.dss.util.xml.BIXMLException xmle)
                {
                    throw new BIPersistenceException(xmle.getMessage(), (Exception)xmle.getPreviousException());
                }
            }
            return true;
        }
        catch (BIParseException bipe)
        {
            //If there is an exception here, the XML is incorrect
            getErrorHandler().log(bipe.toString(), getClass().getName(), "setXMLAsString");
            getErrorHandler().log("Syntax error in XML in line number " + bipe.getLineNumber()
                                                + ", column number " + bipe.getColumnNumber(), getClass().getName(), "setXMLAsString");
            getErrorHandler().log(xml, getClass().getName(), "setXMLAsString");
            getErrorHandler().log("Error starts at:", getClass().getName(), "setXMLAsString");
            getErrorHandler().log(xml.substring(bipe.getColumnNumber()), getClass().getName(), "setXMLAsString");
        }
        catch (oracle.dss.util.xml.BIXMLException xmle2)
        {
            throw new BIPersistenceException(xmle2.getMessage(), (Exception)xmle2.getPreviousException());
        }
        catch (QueryRuntimeException e)
        {
            throw new BIPersistenceException(e.getMessage(), e);
        }
        return false;        
    }*/
    /**
     * @internal
     * Set the XML representation of the query.
     *
     * @param xml a <code>String</code> value that represents the
     *        xml string that we wish to initialize query with.
     */
    public boolean setXMLAsString(String xml) throws BIPersistenceException
    {
        return super.setXMLAsString(xml);

    }

    /**
     * @internal
     * Return SQL for query
     *
     * @param edge edge for which to get information (may include more than one edge)
     * @param type OLAP Services ExpressGenerationInfo type
     * @return text of OLAP Services SQL, if available
     * @throws QueryException if there is an error getting the SQL
     */
/*    public String getQuerySQL(int edge, long type) throws QueryException
    {
        String sql = null;
        if (isProxySet())
        {
            // We always want to execute this immediately: informational
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return null;
            }
            Parameter[] params = {new Parameter(new Integer(edge), Integer.class), new Parameter(new Long(type), Long.class)};
            try
            {
                sql = (String)tempQueue.addOperation(new Operation("getQuerySQL", params, false));
            }
            catch (Throwable e)
            {
                if (e instanceof QueryException)
                    throw (QueryException)e;
            }
        }
        return sql;
    }
*/


    /**
     * @internal
     * Sets whether page dimensions are fetched separately, if possible.
     *
     * @param separate if <code>true</code>, the page dimensions are fetched separately.  If not, they are fetched together.
     */
/*    public void setSeparatePageDimensions(boolean separate)
    {
            super.setSeparatePageDimensions(separate);
    }*/

    /**
     * @internal
     * Sets whether this query only generates query SQL.
     *
     * @param sqlOnly if <code>true</code>, only SQL is available, and the cursors do not have size or valid data.
     */
/*    public void setSQLOnly(boolean sqlOnly)
    {
        if (isProxySet())
        {
            super.setSQLOnly(sqlOnly);
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return;
            }
            Parameter[] params = {new Parameter(new Boolean(sqlOnly), Boolean.class)};
            try {
                tempQueue.addOperation(new Operation("setSQLOnly", params, true));
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }
    }*/

    /**
     * Specifies a list of measures and creates a default cube for the query.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param measures The list of measures to use to make a default cube.
     *
     * 
     */
    public void setMeasures(String[] measures)
    {
        try
        {
            checkQueryBusy(false);
            super.setMeasures(measures);
            
            if (measures != null && measures.length == 0)
            {
                measures = null;
            }
            if (measures == null)
            {
                // Bad argument
                setCurrentOperation(null);
                throw new IllegalArgException(getResourceString("dimensions and measures arguments must not both be null in initQuery"), 2, null);
            }        
            try
            {
                _initCubeQuery(null, measures, null, null);
            }
            catch (Exception e)
            {
                exceptionThrower2(e);
            }
            finally
            {
                setCurrentOperation(null);
            }
        }
        catch (Exception e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    // javadoc from interface
    public synchronized void setItems(String[] dataItems, String[] items) throws QueryException
    {        
        checkQueryBusy(false);
        try
        {
            setupQueryInterfaceImpl(getDataSourceObj(dataItems, new String[][]{items}));
        }
        catch (MetadataManagerException e)
        {
            throw new InvalidMetadataException(e.getMessage(), (String)null, e);
        }
        
        if (dataItems != null && dataItems.length == 0)
        {
            dataItems = null;
        }
        if (items != null && items.length == 0)
        {
            items = null;
        }
        Parameter[] params = {new Parameter(dataItems, String[].class), new Parameter(items, String[].class)};
        EventList el = new EventList();
        el.addElement(getSelectionChangeEvent(dataItems));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));
        
        Operation oper = new Operation("setItems", params, true);
        try
        {
            queueOperation(getOpQueue(), "_setItems", params, true, null, "setItems", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
      
    /**
     * @internal
     */
     public void _setItems(String[] dataItems, String[] items, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
     {        
         setCurrentOperationAndQueue(userOp, queue);
         
         // Use current layout for item placement, if possible
         BitSet edges = null;
         try
         {
             DimTree dt = _getQueryState().getDimTree();
             String[][] layout = dt == null ? null : Node.getStringArray(dt.getDimTree());
             edges = m_qi.setItems(dataItems, items, layout);
         }
         catch (CloneNotSupportedException e)
         {
             throw new CloneException(e.getMessage(), e);
         }
         
         addToUndo(queue, userOp, before, _getQueryState());
         if (edges == null)
         {
             queue.eventHelper(new DataAvailableEvent(this, true, null));
         }
         else
         {
             queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
         }        
     }

    /**
     * @internal
     */
    protected boolean areFiltersChanged(BaseDataFilter[] newFilters)
    {
        BaseDataFilter[] currentFilters = getDataFilters();        
        if (QueryUtil.compareArrays(newFilters, currentFilters))
        {
            // No change
            return false;
        }
        return true;
    }
    
    /**
     * @internal
     */
    protected boolean areColumnSortsChanged(ColumnSortWrapper[] newSorts) {
      ColumnSortWrapper[] currentSorts = getColumnSorts();        
      if (QueryUtil.compareArrays(newSorts, currentSorts)) {
        // No change
        return false;
      }
      return true;
    }

    /**
     * @internal
     */
/*    protected boolean areItemSortsChanged(ItemSortWrapper[] newSorts) {
      ItemSortWrapper[] currentSorts = getItemSorts();
      if (QueryUtil.compareArrays(newSorts, currentSorts)) {
        // No change
        return false;
      }
      return true;
    }*/
    
    // javadoc from interface
    public void setDataFilters(BaseDataFilter[] filters) throws QueryException
    {        
        checkQueryBusy(false);
        
        // Make sure there is really a change
        if (!areFiltersChanged(filters))
            return;
        
        Parameter[] params = {new Parameter(filters, BaseDataFilter[].class)};

        EventList el = new EventList();
        el.addElement(new DataFilterChangingEvent(this, filters));

        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));

        try
        {
            queueOperation(getOpQueue(), "_setDataFilters", params, true, null, "setDataFilters", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            setCurrentOperation(null);
            exceptionThrower2(e);
        }    
        finally
        {
            setCurrentOperation(null);
        }
    }

    /**
     * @internal
     * Determine if data filters were removed 
     */
    protected boolean wereFiltersRemoved(BaseDataFilter[] oldSet, BaseDataFilter[] newSet)
    {
        if (newSet == null && oldSet == null)
            return false;
            
        if (newSet == null && oldSet != null && oldSet.length > 0)
            return true;
            
        if ((oldSet == null || oldSet.length == 0) && newSet != null && newSet.length > 0)
            return false;
            
        return oldSet.length > newSet.length;
    }
    
    /**
     * @internal
     * Determine if column sorts were removed 
     */
    protected boolean wereColumnSortsRemoved(ColumnSortWrapper[] oldSet, ColumnSortWrapper[] newSet) {
      if (newSet == null && oldSet == null)
        return false;
          
      if (newSet == null && oldSet != null && oldSet.length > 0)
        return true;
          
      if ((oldSet == null || oldSet.length == 0) && newSet != null && newSet.length > 0)
        return false;
          
      return oldSet.length > newSet.length;
    }
    
    /**
     * @internal
     * Determine if item sorts were removed 
     */
/*    protected boolean wereItemSortsRemoved(ItemSortWrapper[] oldSet, ItemSortWrapper[] newSet) {
      if (newSet == null && oldSet == null)
        return false;
          
      if (newSet == null && oldSet != null && oldSet.length > 0)
        return true;
          
      if ((oldSet == null || oldSet.length == 0) && newSet != null && newSet.length > 0)
        return false;
          
      return oldSet.length > newSet.length;
    }*/
    
    protected boolean setupInterfaceImplBasedOnDataFilter(BaseDataFilter[] filters) throws MetadataManagerException, InvalidMetadataException
    {
        // Check to see if this type of filter has an item
        if (filters != null)
        {
            for (int i = 0; i < filters.length; i++)
            {
                String item = null;
                if (filters[i] instanceof DataFilter)
                {
                    item = ((DataFilter)filters[i]).getItem();
                }
                else if (filters[i] instanceof TopBottomDataFilter)
                {
                    item = ((TopBottomDataFilter)filters[i]).getItem();
                }
                else if (filters[i] instanceof RangeDataFilter)
                {
                    item = ((RangeDataFilter)filters[i]).getItem();                    
                }
                else if (filters[i] instanceof VariableSettingDataFilter)
                {
                    // Need to use the first MM item as the "source item"
                    PropertyBag propBag = new PropertyBag();
                    propBag.setStrPropertyValue( MDU.OBJECT_TYPE, MM.ITEM);
                    MDObject[] obj = ((MetadataManager)getMetadataManager()).getMDObjects(propBag);
                    if (obj != null && obj.length > 0)
                        item = obj[0].getUniqueID();
                }
                else if (filters[i] instanceof CompoundDataFilter)
                {
                    if (setupInterfaceImplBasedOnDataFilter(((CompoundDataFilter)filters[i]).getDataFilters()))
                        return true;
                }
                if (item != null)
                {
                    MDObject mdobj = getDataSourceObj(new String[] {item}, null);
                    if (mdobj == null)
                    {
                        // This is bad: invalid dim
                        throw new InvalidDimensionException(MessageFormat.format(getQueryManager().getResourceString("Invalid dimension specified"), new String[] {item}), new String[] {item}, null);                
                    }
                    setupQueryInterfaceImpl(mdobj);
                    return true;                  
                }
            }
        }
        return false;
    }
    
    /**
     * @internal
     * Called from applyQueryEditor
     * @throws oracle.dss.dataSource.common.QueryException
     * @param filters
     * @param queue
     */
    protected void _setDataFilters(BaseOperationQueue queue, BaseDataFilter[] filters) throws QueryException
    {    
        // Must check for a change again because it could be called from query editor application
        if (!areFiltersChanged(filters))
            return;
                    
        Parameter[] params = {new Parameter(filters, BaseDataFilter[].class)};
        try
        {
            queueOperation(queue, "_setDataFilters", params, true, null, "setDataFilters", params, _getQueryState(), new EventList());
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }              
        finally
        {
            setCurrentOperation(null);
        }
    }    
    
    /**
     * @internal
     */
    public void _setDataFilters(BaseDataFilter[] filters, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);

        try
        {
            setupInterfaceImplBasedOnDataFilter(filters);
        }
        catch (MetadataManagerException e)
        {
            throw new QueryException(e.getMessage(), e);
        }

        // First, remove all parameters (we only have them on data filters right now)
        oracle.dss.util.parameters.Parameter[] params = getParameters();
        if (params != null)
            for (int i = 0; i < params.length; i++)
                removeParameter(params[i]);
        
        // Suck in any parameters
        if (filters != null)
        {            
            oracle.dss.util.parameters.Parameter[] p = null;
            for (int i = 0; i < filters.length; i++)
            {
                p = filters[i].getParameters();
                if (p != null)
                    for (int j = 0; j < p.length; j++)
                        setParameter(p[j]);
            }
        }
        
        BitSet edges = m_qi.setDataFilters(filters);
        queue.eventHelper(new DataFilterChangedEvent(this, filters, wereFiltersRemoved(before.getDataFilters(), filters)));
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));    
        setCurrentOperation(null);
    }    
    
    // javadoc from interface
    public BaseDataFilter[] getDataFilters()
    {
        return _getQueryState().getDataFilters();
    }    
    /*
    public BaseDataFilter[] getDataFilters(String layerMetadataType)
    {
        BaseDataFilter[] dataFilters = getDataFilters();
        if (layerMetadataType != LayerMetadataMap.LAYER_METADATA_NAME && dataFilters != null && layerMetadataType != null)
        {
            BaseDataFilter[] retDataFilter = new BaseDataFilter[dataFilters.length];
            MDObject obj = null;
            for (int i = 0; i < dataFilters.length; i++)
            {
                if (dataFilters[i] instanceof ItemDataFilter)
                {
                    try
                    {
                        // Translate item ID to desired type
                        retDataFilter[i] = (BaseDataFilter)dataFilters[i].clone();
                        obj = getMDObject(MM.UNIQUE_ID, ((ItemDataFilter)dataFilters[i]).getItem(), MM.OBJECT);
                        String newName = QueryUtil.getLayerMetadata(layerMetadataType, obj);
                        if (newName != null)
                            ((ItemDataFilter)retDataFilter[i]).setItem(newName);                            
                    }
                    catch (Exception e)
                    {
                        throw new QueryRuntimeException(e.getMessage(), e);
                    }
                }
                else
                    retDataFilter[i] = dataFilters[i];
            }
            return retDataFilter;
        }
        return dataFilters;
    }
    */
/*    public void setDataFilters(BaseDataFilter[] dataFilters, String layerMetadataType) throws QueryException
    {
        if (layerMetadataType != LayerMetadataMap.LAYER_METADATA_NAME && dataFilters != null && layerMetadataType != null)
        {
            BaseDataFilter[] newDataFilter = new BaseDataFilter[dataFilters.length];
            MDObject obj = null;
            for (int i = 0; i < dataFilters.length; i++)
            {
                if (dataFilters[i] instanceof ItemDataFilter)
                {
                    try
                    {
                        // Translate type name to ID
                        newDataFilter[i] = (BaseDataFilter)dataFilters[i].clone();
                        String mmType = DataUtils.mapToMetadataManagerId(layerMetadataType);
                        obj = getMDObject(mmType, ((ItemDataFilter)dataFilters[i]).getItem(), MM.OBJECT);
                        if (obj != null)
                            ((ItemDataFilter)newDataFilter[i]).setItem(obj.getUniqueID());                            
                    }
                    catch (Exception e)
                    {
                        throw new QueryRuntimeException(e.getMessage(), e);
                    }
                }
                else
                    newDataFilter[i] = dataFilters[i];
            }
            setDataFilters(newDataFilter);
            return;
        }
        setDataFilters(dataFilters);
    }
    */
    public ColumnSortWrapper[] getColumnSorts() {
      return _getQueryState().getColumnSorts();
    }

/*    public ItemSortWrapper[] getItemSorts() {
      return _getQueryState().getItemSorts();
    }*/

    // javadoc from interface
    public void setColumnSorts(ColumnSortWrapper[] sorts) throws QueryException {        
      checkQueryBusy(false);
      
      // Make sure there is really a change
      if (!areColumnSortsChanged(sorts))
          return;
      
      Parameter[] params = {new Parameter(sorts, ColumnSortWrapper[].class)};

      EventList el = new EventList();
      el.addElement(new ColumnSortChangingEvent(this, sorts));

      el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));

      try {
        queueOperation(getOpQueue(), "_setColumnSorts", params, true, null, "setColumnSorts", params, _getQueryState(), el);
      }
      catch (Throwable e) {
        setCurrentOperation(null);
        exceptionThrower2(e);
      }    
      finally {
        setCurrentOperation(null);
      }
    }

    // javadoc from interface
/*    public void setItemSorts(ItemSortWrapper[] sorts) throws QueryException {        
      checkQueryBusy(false);
      
      // Make sure there is really a change
      if (!areItemSortsChanged(sorts))
          return;
      
      Parameter[] params = {new Parameter(sorts, ItemSortWrapper[].class)};

      EventList el = new EventList();
      el.addElement(new ItemSortChangingEvent(this, sorts));

      el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));

      try {
        queueOperation(getOpQueue(), "_setItemSorts", params, true, null, "setItemSorts", params, _getQueryState(), el);
      }
      catch (Throwable e) {
        setCurrentOperation(null);
        exceptionThrower2(e);
      }    
      finally {
        setCurrentOperation(null);
      }
    }*/

    /**
     * @internal
     * Called from applyQueryEditor
     * @throws oracle.dss.dataSource.common.QueryException
     * @param sorts
     * @param queue
     */
    protected void _setColumnSorts(BaseOperationQueue queue, ColumnSortWrapper[] sorts) throws QueryException {    
      // Must check for a change again because it could be called from query editor application
      if (!areColumnSortsChanged(sorts))
        return;
          
      Parameter[] params = {new Parameter(sorts, ColumnSortWrapper[].class)};
      try {
        queueOperation(queue, "_setColumnSorts", params, true, null, "setColumnSorts", params, _getQueryState(), new EventList());
      }
      catch (Throwable e) {
        exceptionThrower2(e);
      }              
      finally {
        setCurrentOperation(null);
      }
    }    
    
    /**
     * @internal
     * Called from applyQueryEditor
     * @throws oracle.dss.dataSource.common.QueryException
     * @param sorts
     * @param queue
     */
/*    protected void _setItemSorts(BaseOperationQueue queue, ItemSortWrapper[] sorts) throws QueryException {    
      // Must check for a change again because it could be called from query editor application
      if (!areItemSortsChanged(sorts))
        return;
          
      Parameter[] params = {new Parameter(sorts, ItemSortWrapper[].class)};
      try {
        queueOperation(queue, "_setItemSorts", params, true, null, "setItemSorts", params, _getQueryState(), new EventList());
      }
      catch (Throwable e) {
        exceptionThrower2(e);
      }              
      finally {
        setCurrentOperation(null);
      }
    }    */
    
    /**
     * @internal
     */
    public void _setColumnSorts(ColumnSortWrapper[] sorts, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException {
      setCurrentOperationAndQueue(userOp, queue);      
      BitSet edges = m_qi.setColumnSorts(sorts);
      queue.eventHelper(new ColumnSortChangedEvent(this, sorts, wereColumnSortsRemoved(before.getColumnSorts(), sorts)));
      addToUndo(queue, userOp, before, _getQueryState());
      queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
      setCurrentOperation(null);
    }    

    /**
     * @internal
     */
/*    public void _setItemSorts(ItemSortWrapper[] sorts, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException {
      setCurrentOperationAndQueue(userOp, queue);      
      BitSet edges = m_qi.setItemSorts(sorts);
      queue.eventHelper(new ItemSortChangedEvent(this, sorts, wereItemSortsRemoved(before.getItemSorts(), sorts)));
      addToUndo(queue, userOp, before, _getQueryState());
      queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
      setCurrentOperation(null);
    }    */

    // Add operation to queue if necessary
    private Object queueOperation(BaseOperationQueue queue, String privRoutine, Parameter[] privParams, boolean generatesCursor, QueryEvent event, String routine, Parameter[] params, QueryState before, EventList el) throws Throwable
    {
        //m_beforeState = before;
        // Make sure it's a copy (separated from the real current state)
        before = (QueryState)before.clone(this);
        if (queue == null)
            queue = getOpQueue();
            
        if (event != null)
            queue.eventHelper(event);

        // Add the user operation and state on to the true private call's parameter list if there
        Operation userOp = null;
        if (routine != null) {
            userOp = new Operation(routine, params, generatesCursor);
        }
        Operation operation = new Operation(privRoutine, privParams, generatesCursor);
        if (userOp != null && before != null) {
            Parameter[] opParams = privParams;
            int length = opParams == null ? 0 : opParams.length;
            Parameter[] newParams = new Parameter[length+3];
            // Copy old parameters
            for (int i = 0; i < length; i++) {
                newParams[i] = opParams[i];
            }
            newParams[length] = new Parameter(userOp, Operation.class);
            newParams[length+1] = new Parameter(before, QueryState.class);
            newParams[length+2] = new Parameter(queue, BaseOperationQueue.class);
            operation = new Operation(privRoutine, newParams, generatesCursor);
        }
        if (queue != null)
        {
            if (queue instanceof OperationQueue)
                return ((OperationQueue)queue).addOperation(operation, el);
            else
                return queue.addOperation(operation);
        }
        else
            return getOpQueue().addOperation(operation, el);
    }
    
    // javadoc from interface
    public String[] getDataItems()
    {
        return  _getQueryState().getMeasures();
        
/*        if (!isDesignTime() && isProxySet())
        {
            // We always want to execute this immediately: informational
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return null;
            }
            String[] measures = null;
            try {
                measures = (String[])tempQueue.addOperation(new Operation("getDataItems", null, false));
            }
            catch (IllegalArgumentException iae) {
                throw iae;
            }
            catch (Throwable e) {
                // Unknown
                throw new QueryRuntimeException(e.getMessage(), e);
            }
            m_propSupport.setMeasures(measures);
        }
        return m_propSupport.getMeasures();*/
    }
    
    // javadoc from superclass
    public String[] getMeasures()
    {
        return getDataItems();
    }

        
    // javadoc from interface
    public String[] getItems()
    {
        Vector items = new Vector();
/*        // Merge measure state + layout items
        String[] dataItems = getDataItems();
        if (dataItems != null)
        {
            for (int i = 0; i < dataItems.length; i++)
                items.addElement(dataItems[i]);
        }*/
        String[][] layout = getLayout();
        if (layout != null)
        {
            for (int e = 0; e < layout.length; e++)
            {
                if (layout[e] != null)
                {
                    for (int l = 0; l < layout[e].length; l++)
                    {       
                        // No duplicates and nothing in list of data items
                        if (items.indexOf(layout[e][l]) == -1 && !inDataItems(layout[e][l]))
                            items.addElement(layout[e][l]);
                    }
                }
            }
        }
        return (String[])items.toArray(new String[]{});
    }

    private boolean inDataItems(String id)
    {
        if (id == null)
            return false;
        
        String[] dataItems = getDataItems();
        if (dataItems != null)
        {
            for (int i = 0; i < dataItems.length; i++)
                if (id.equals(dataItems[i]))
                    return true;
        }
        return false;
    }
    
    /**
     * Updates the implementing <code>Query</code> with the state changes
     * (that is, <code>Selection</code> information) in the specified
     * <code>QueryAccess</code> object.
     * It is the responsibility of the <code>QueryContext</code> implementor
     * (that is, the QueryManager for the BI beans) to initialize itself using
     * the <code>QueryAccess</code> state or reasonable defaults, if necessary.
     *
     * @param qa     The <code>QueryAccess</code> object to use for update.
     * @param update <code>true</code> if the caller is finished with updating
     *               the <code>QueryContext</code> and the
     *               <code>Query</code> is free to run a query based on
     *               the new state;
     *               <code>false</code> if the caller is not finished with the
     *               updates.
     *
     * @return <code>true</code> if the update is successful;
     *         <code>false</code> if the update is not successful.
     *
     * 
     */
    public boolean applyQueryAccess(QueryAccess qa, boolean update) 
    {
        return _applyCommonQueryEditorAccess((CommonQueryEditor)qa, update);
    }

    protected boolean _applyCommonQueryEditorAccess(CommonQueryEditor qa, boolean update)
    {
        boolean didntUpdateHere = true;
        // blm - Selection code moved to dvt-olap
/*        Enumeration sels = qa.getSelections();

        Selection[] selarray = null;
        Selection measSel = null;
        if (sels != null)
        {
            Vector sellist = new Vector();
            CommonQueryEditor.SelCursor sc = null;

            int count = 0;
            while (sels.hasMoreElements()) 
                {
                sc = (CommonQueryEditor.SelCursor)sels.nextElement();
                Selection sel = sc.getSelection();
                if (sel != null && qa.isSelectionSet(sel.getDimension(), 0) && !sel.equals(findSelection(sel.getDimension()))) {
                    if (sel.getCombinedStepCount() > 0) {
                        try
                        {
                            if (sel.getDimension().equals(getMeasureDim())) {
                                // Tag measure dimension in case we need to initialize
                                measSel = sel;
                            }
                        }
                        catch (InvalidMetadataException mme)
                        {
                            getErrorHandler().log(mme.toString(), getClass().getName(), "applyQueryAccess");
                            return false;
                        }
                        try {
                            sellist.addElement(sel.clone());
                        }
                        catch (CloneNotSupportedException cnse) {
                            getErrorHandler().log(cnse.toString(), getClass().getName(), "applyQueryAccess");
                            return false;
                        }                        
                    }
                }
    
            }
            selarray = (Selection[])Utility.copyVectorToArray(sellist);                
        }
  */      
        try {
            // blm - Selection code moved to dvt-olap
/*            if (selarray != null && selarray.length > 0 ) 
            {
                for (int sel = 0; sel < selarray.length; sel++) {
                    selarray[sel].removeAllPropertyChangeListeners();
                }
                didntUpdateHere = false;
                _applySelections(_getAccessOperationQueue(), selarray, update);
            }*/
            if (qa instanceof QueryEditor)
            {
                if (((QueryEditor)qa).isDataFilterSet(0))
                {
                    // Apply data filters
                    if (!update)
                    {
                        _getAccessOperationQueue().setAutoUpdate(false);
                    }
                    _setDataFilters(_getAccessOperationQueue(), ((QueryEditor)qa).getDataFilters(0));
                    didntUpdateHere = false;
                }
            }
            if (update) {
                // blm - Selection code moved to dvt-olap
/*                if (findSelection(getMeasureDim()) == null) {
                    // Must initialize
                    // Get measure list
                    if (measSel != null) {
                        MeasureStepEvaluator mse = new MeasureStepEvaluator(measSel, this);
                        Vector list = mse.getList();
                        String[] measList = null;
                        if (list != null)
                        {
                            measList = new String[list.size()];
                            for (int i = 0; i < measList.length; i++)
                            {
                                measList[i] = (String)list.elementAt(i);
                            }
                            didntUpdateHere = false;
                            _initCubeQuery(_getAccessOperationQueue(), measList, null, null);
                        }
                    }
                }*/
                
                if (didntUpdateHere && (m_accessOperationQueue != null && m_accessOperationQueue.isUpdatePending()))
                {
                    _refresh(_getAccessOperationQueue());
                }
            }
        }                    
        catch (Throwable e) {
            getErrorHandler().log(e.toString(), getClass().getName(), "applyQueryAccess");
            return false;
        }                                
        
        return true;        
    }
    
    // javadoc from interface
    public boolean applyQueryEditor(QueryEditor qe, boolean update) throws BIBaseException
    {
        boolean retVal = _applyCommonQueryEditorAccess((QueryEditorImpl)qe, false);
        return retVal && applyLayoutAccess((QueryEditorImpl)qe, update);
    }
    
    // javadoc from interface
    public QueryEditor createQueryEditor()
    {
        return new QueryEditorImpl(this);
    }

    /**
     * Creates an implementation of the <code>LayoutAccess</code> interface
     * that presents data with a cube layout.
     *
     * @return An object that implements the <code>LayoutAccess</code>
     *         interface.
     *
     * @status New
     */
    public LayoutAccess createCubeLayoutAccess()
    {
        return new QueryLayoutAccess(this, false);
    }

    /**
     * Creates an implementation of the <code>LayoutAccess</code> interface
     * that presents data with a relational (table) layout.
     *
     * @return An object that implements the <code>LayoutAccess</code>
     *         interface.
     *
     * @status New
     */
    public LayoutAccess createRelationalLayoutAccess()
    {
        return new QueryLayoutAccess(this, true);
    }  

    private QueryLayoutAccess getQueryLayoutAccess(LayoutAccess la)
    {
        if (la instanceof QueryLayoutAccess)
        {
            return (QueryLayoutAccess)la;
        }
        else
        {
            return ((QueryEditorImpl)la).m_la;
        }        
    }

    // blm - Selection code moved to dvt-olap
/*    private boolean supportsMeasureSelections() throws QueryException
    {
        Boolean val = (Boolean)isSupported(QueryCapabilities.MEASURE_DIMENSION_SELECTION, null);
        if (val != null)
        {
            return val.booleanValue();
        }
        return false;
    }
    
    private Selection getMeasureSelection(boolean supportsMeasureSelections) throws QueryException
    {
        if (supportsMeasureSelections && getMeasureDim() != null)
        {
            // This type trades in measure sels
            return findSelection(getMeasureDim());
        }
        return null;
    }
*/
    // Return column sorts if any, and if this is tabular, and if they're different
    private ColumnSortWrapper[] getColumnSortsFromLayoutAccessQuery(Query query)
    {
//        if (Boolean.TRUE.equals(query.getProperty(QueryConstants.PROPERTY_TABULAR_QUERY)))
//        {
            ColumnSortWrapper[] newSorts = query.getColumnSorts();
            if (areColumnSortsChanged(newSorts))
            {
                return newSorts;
            }
//        }
        return null;
    }

    private String[][] getLayoutFromLayoutAccessQuery(Query query)
    {
        String[][] newLayout = query.getLayout();
        String[][] layout = getLayout();
        if (newLayout != null && !QueryUtil.compareStringArrays(newLayout, layout))
            return newLayout;
            
        return null;
    }
    
    private void refreshLayoutAccess() throws Throwable
    {
        if (m_accessOperationQueue != null && m_accessOperationQueue.isUpdatePending())
        {
            _refresh(_getAccessOperationQueue());
        }
    }
    
    /**
     * Updates the implementing <code>Query</code> with the changed layout
     * information in the specified <code>LayoutAccess</code> object.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param la      <code>LayoutAccess</code> object to use for the update.
     *                The update will be applied to the
     *                <code>LayoutContext</code>.
     *
     * @param update  <code>true</code> if the caller is finished with all
     *                the updates and the <code>Query</code> should do
     *                what is necessary to <I>run</I> the query with the new
     *                layout state;
     *                <code>false</code> if the caller is not finished with
     *                the updates.
     *
     * @status Needs change
     */
    public boolean applyLayoutAccess(LayoutAccess la, boolean update)
    {
        try
        {
            // Gather the facts
            QueryLayoutAccess dsla = getQueryLayoutAccess(la);
            Query laQuery = null;
            if (dsla.isInitialized())
            {
                laQuery = (Query)dsla.getDataSource();
            }
            
            // Are we previously inited...if we have a data item list or a layout we're inited
            boolean existingQuery = getMeasures() != null || getLayout() != null;
            
            // blm - Selection code moved to dvt-olap
            // Do we use measure selections at all?
/*            boolean supportsMeasureSelections = supportsMeasureSelections();
            
            // Do we have a measure selection, if so what is it?  
            Selection measSel = getMeasureSelection(supportsMeasureSelections);        */
            
            // List of measures as they are in the LayoutAccess, and are they different?
            String[] newMeasures = la.getMeasures(MetadataMap.METADATA_VALUE);
            boolean measuresChanged = !Utility.compareListsExact(newMeasures, getMeasures());
            String[] newItems = null;
            if (la instanceof LayoutAccess2)
                newItems = ((LayoutAccess2)la).getItems(MetadataMap.METADATA_VALUE);
            boolean itemsChanged = !Utility.compareListsExact(newItems, getItems());
            
            String[][] newLayout = null;
            ColumnSortWrapper[] newSorts = null;
            if (laQuery != null)
            {
                // Layout from LayoutAccess query
                newLayout = getLayoutFromLayoutAccessQuery(laQuery);
                // Table sorts from LayoutAccess query
                newSorts = getColumnSortsFromLayoutAccessQuery(laQuery);
            }
            
            // Check if autoupdate is on
            boolean autoUpdate = _getAccessOperationQueue().isAutoUpdate();
            // Turn it off
            if (!autoUpdate)
                _getAccessOperationQueue().setAutoUpdate(false);
                
            // Set if query is dirty by some change here
            boolean queryDirty = true;
            
            // Get sorts in there
            if (newSorts != null)
            {
                _setColumnSorts(_getAccessOperationQueue(), newSorts);                
                queryDirty = true;
            }
            
            // Get new layout/new measures in there, if not new
            if (existingQuery)
            {
                // blm - Selection code moved to dvt-olap
/*                if (measSel != null)
                {
                    // We have the meas sel, so use the layout method for layouts, and the measure sel for measure list change
                    if (newLayout != null)
                    {
                        queryDirty = true;
                        _layout(_getAccessOperationQueue(), newLayout, update);
                    }
                    if (newMeasures != null)
                    {
                        queryDirty = true;
                        // blm - Selection code moved to dvt-olap
                        Selection sel = new Selection(getMeasureDim());
                        MemberStep ms = new MemberStep(sel.getDimension());
                        ms.setInitial(true);
                        for (int i = 0; i < newMeasures.length; i++) {
                            ms.addMember(newMeasures[i]);
                        }
                        sel.addStep(ms);
                        Selection[] sels = new Selection[1];
                        sels[0] = sel;
                        _applySelections(_getAccessOperationQueue(), sels, update);
                    }
                }
                else
                {*/
                    // No measure selection: use init query to get it all in there
                    if (newMeasures != null)
                    {
                        // New measures
                        if (newLayout != null)
                        {
                            // new everything
                            _initCubeQuery(_getAccessOperationQueue(), newMeasures, Utility.flattenArray(newLayout), newLayout);
                        }
                        else
                        {
                            // New measures only
                            if (newItems != null)
                                _initCubeQuery(_getAccessOperationQueue(), newMeasures, newItems, getLayout());                            
                            else
                                _initCubeQuery(_getAccessOperationQueue(), newMeasures, Utility.flattenArray(getLayout()), getLayout());                                                        
                        }
                    }
                    else
                    {
                        // No new measures
                        if (newLayout != null)
                        {
                            _initCubeQuery(_getAccessOperationQueue(), getMeasures(), Utility.flattenArray(newLayout), newLayout);
                        }
                    }
                }
            //}
            
            // Now we're done: either init if new query or refresh
            if (update)
            {
                if (existingQuery)
                {
                    if (!queryDirty)
                    {
                        // We didn't dirty the query, but we're supposed to take care of updates before this call
                        refreshLayoutAccess();
                    }
                }
                else
                {
                    // Brand new query: use the init to get the measures & layout in there
                    _initCubeQuery(_getAccessOperationQueue(), newMeasures, Utility.flattenArray(newLayout), newLayout);
                }
            }
            
            // Turn auto update back on to execute what we've done
            if (m_accessOperationQueue.isUpdatePending())
                m_accessOperationQueue.setAutoUpdate(true);     
                
            return true;
        }
        catch (Throwable e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    /**
     * Updates the implementing <code>Query</code> with the changed layout
     * information in the specified <code>LayoutAccess</code> object.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param la      <code>LayoutAccess</code> object to use for the update.
     *                The update will be applied to the
     *                <code>LayoutContext</code>.
     *
     * @param update  <code>true</code> if the caller is finished with all
     *                the updates and the <code>Query</code> should do
     *                what is necessary to <I>run</I> the query with the new
     *                layout state;
     *                <code>false</code> if the caller is not finished with
     *                the updates.
     *
     * @status Needs change
     */
/*    public boolean applyLayoutAccess(LayoutAccess la, boolean update) {
        QueryLayoutAccess dsla = null;
        if (la instanceof QueryLayoutAccess)
        {
            dsla = (QueryLayoutAccess)la;
        }
        else
        {
            dsla = ((QueryEditorImpl)la).m_la;
        }        
        Query query = null;
        String[][] newLayout = null;
        boolean didntUpdateHere = true;
        if (dsla.isInitialized()) {
            query = (Query)dsla.getDataSource();
            newLayout = query.getLayout();
        }

        try {
            boolean mustInit = false;
            Boolean val = (Boolean)isSupported(QueryCapabilities.MEASURE_DIMENSION_SELECTION);
            Selection measSel = null;
            if (val != null && val.booleanValue())
            {
                // This type trades in measure sels
                if (getMeasureDim() != null)
                {
                    measSel = findSelection(getMeasureDim());
                    mustInit = (measSel == null);
                }
                else if (getMeasures() == null)
                {
                    mustInit = true;
                }
            }
            else
            {
                // No measure sels & layout
                mustInit = (getMeasures() == null) && (getLayout() == null);
            }
            String[] measList = la.getMeasures(MetadataMap.METADATA_VALUE);
            
            if (update && mustInit)
            {
                // Must initialize
                // Use measure list
                if (measList != null && measList.length > 0)
                {
                    didntUpdateHere = false;
                    _initCubeQuery(_getAccessOperationQueue(), measList, newLayout);
                }
            }
            String[][] layout = getLayout();
            boolean measureChange = measList != null && !Utility.compareListsExact(measList, getMeasures());
            if (newLayout != null && layout != null && !QueryUtil.compareStringArrays(newLayout, layout)) {
                didntUpdateHere = false;
                // Now check for measure changes
                if (measureChange)
                _layout(_getAccessOperationQueue(), newLayout, update);
            }
            // Apply changes to the measure selection, if applicable (if there was no preexisting measure selection,
            // don't bother because we already created the cube
            if (measList != null && didntUpdateHere)
            {                
                if (measureChange)
                {
                    if (measSel != null)
                    {
                        Selection sel = new Selection(getMeasureDim());
                        MemberStep ms = new MemberStep(sel.getDimension());
                        ms.setInitial(true);
                        for (int i = 0; i < measList.length; i++) {
                            ms.addMember(measList[i]);
                        }
                        sel.addStep(ms);
                        Selection[] sels = new Selection[1];
                        sels[0] = sel;
                        didntUpdateHere = false;
                        _applySelections(_getAccessOperationQueue(), sels, update);
                    }
                    else
                    {
                        // No measure sel, but need to update measure list
                        _initCubeQuery(_getAccessOperationQueue(), measList, getLayout());
                    }
                }
            }
            if (query != null) {
              if (Boolean.TRUE.equals(query.getProperty(QueryConstants.PROPERTY_TABULAR_QUERY))) {
                ColumnSortWrapper[] newSorts = query.getColumnSorts();
                if (areColumnSortsChanged(newSorts)) {
                  didntUpdateHere = false;
                  _setColumnSorts(_getAccessOperationQueue(), newSorts);
                }
              }
            }
            if (update) {
                if (didntUpdateHere && (m_accessOperationQueue != null && m_accessOperationQueue.isUpdatePending()))
                {
                    _refresh(_getAccessOperationQueue());
                }
//                updateAccessOperationQueue();
                if (m_accessOperationQueue.isUpdatePending())
                    m_accessOperationQueue.setAutoUpdate(true);
            }        
                
        }                
        catch (Throwable e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        return true;
    }*/

    /**
     * Clones this <code>Query</code> and provides the performance option
     * of bypassing cursor evaluation. If the EvaluateCursor property is set to
     * false, then the <code>Query</code> does not ask the OLAP API to create a
     * cursor based on the user's API calls. The caller of this method still
     * gets the full set of events along with the "cursors" but these cursors
     * will not have any data or metadata values in them. The cursors will
     * contain only basic edge, layer level wireframe information (such as the
     * dimensions and where they are located in the layout).
     *
     * @param evaluateCursor <code>true</code> if this clone should have cursor
     *                       evaluation turned on (this is the default value);
     *                       <code>false</code> if this clone does not require
     *                       cursor evaluation.
     *
     * @return A newly-created copy of the <code>Query</code>.
     *
     * @throws CloneNotSupportedException   If a <code>Query</code>
     *                                      can not be cloned.
     *
     * @see #isEvaluateCursor
     * @see #setEvaluateCursor
     *
     * 
     */
    public Object clone(boolean evaluateCursor) throws CloneNotSupportedException {
        QueryClient query = null;
        try
        {
            query = (QueryClient)_clone(evaluateCursor);
            query.setQueryManager(getQueryManager());
            // Must make sure interface is set up
            Constructor cons = m_qi.getClass().getConstructor(new Class[] {Query.class});
            if (!(m_qi instanceof NullQueryInterfaceImpl))
            {
                DimTree dt = query._getQueryState().getDimTree();
                query.setupQueryInterfaceImpl(query.getDataSourceObj(query._getQueryState().getMeasures(), dt == null ? null : Node.getStringArray(dt.getDimTree())));
            }
            query.m_qi.loadQuery();
        }
        catch (Exception e)
        {
            throw new CloneNotSupportedException(e.getMessage());
        }

        _getQueryManager().addQuery(query);
        return query;
    }

    // javadoc from superclass
    protected boolean isOLAP()
    {
        /*try
        {
            Class cl = Class.forName("oracle.dss.dataSource.olap.client.OLAPQueryInterfaceImpl");
            return m_qi.getClass().equals(cl);
        }
        catch (ClassNotFoundException e)
        {            
        }*/
        return false;
    }

    /**
     * @internal
     */
    protected Query _clone(boolean evaluateCursor) throws CloneNotSupportedException, QueryException, MetadataManagerException
    {
        return super._clone(evaluateCursor);
    }

    /**
     * Controls actual cursor evaluation. The default setting for the
     * EvaluateCursor property is <code>true</code>. If this setting is changed
     * to <code>false</code>, then the clone(boolean) method bypasses cursor
     * evaluation when copying a <code>Query</code>.
     *
     * @param evalCursor Indicates whether cursors should be evaluated for a
     *                   <code>Query</code>.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public void setEvaluateCursor(boolean evalCursor) throws QueryException, MetadataManagerException {
        super.setEvaluateCursor(evalCursor);
        if (evalCursor)
        {
            m_noEvalOnReload = false;
        }
/*        if (!isDesignTime() && isProxySet()) {
            // We always want to execute this immediately
            Parameter[] params = {new Parameter(new Boolean(m_propSupport.isEvaluateCursor()), Boolean.class)};
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return;
            }
            Operation oper = new Operation("setEvaluateCursor", params, true);
            try {
                tempQueue.addOperation(oper);
            }
            catch (Throwable e)
            {
                exceptionThrower(e);
            }
        }*/
    }
    
    /**
     * Drills to a relative level of the specified hierarchy accepting
     * a value's parent for optimization of drill steps later.
     *
     * @param dimension    The dimension to drill.
     * @param value        The dimension value, also known as the
     *                     dimension member, to drill.
     * @param hierarchy    The target hierarchy for the drill.
     * @param delta        The relative number of levels to traverse within the
     *                     specified hierarchy. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param valueParent  Value's parent dimension value; used for
     *                     optimizing later potential drill up requests.
	   * @param queryParent  The item from the original query members under
     *                     which this drill occurs.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent) throws QueryException, MetadataManagerException
    {
        //drill(dimension, value, hierarchy, delta, valueParent, queryParent, -1, null);
    }

    /**
     * Drills to a relative level of the specified hierarchy accepting
     * a value's parent for optimization of drill steps later.
     *
     * @param dimension    The dimension to drill.
     * @param value        The dimension value, also known as the
     *                     dimension member, to drill.
     * @param hierarchy    The target hierarchy for the drill.
     * @param delta        The relative number of levels to traverse within the
     *                     specified hierarchy. Positive numbers drill down,
     *                     negative numbers drill up.
     * @param valueParent  Value's parent dimension value; used for
     *                     optimizing later potential drill up requests.
     * @param queryParent  The item from the original query members under
     *                     which this drill occurs.
     * @param parentQDR    An optional OlapQDR that specifies
     *                     dimension/member pairs that limit where this
     *                     drill (down) should take place
     *                     (parents of the target).
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent, OlapQDR parentQDR) throws QueryException, MetadataManagerException
    {
        //drill(dimension, value, hierarchy, delta, valueParent, queryParent, -1, parentQDR);
    }


    // javadoc from interface
    public synchronized void drill(String dimension, String value, String hierarchy, int delta, String valueParent, String queryParent, int levelDepth, OlapQDR parentQDR) throws QueryException, MetadataManagerException
    {
        //drill(dimension, new String[] {value}, new String[] {hierarchy}, new int[] {delta}, new boolean[] {false}, new String[] {valueParent}, new String[] {queryParent}, new int[] {levelDepth}, new OlapQDR[] {parentQDR});
    }

    // javadoc from interface
    public void drill(String dimension, String[] target, String[] hierarchy, int[] delta, boolean[] above, String[] valueParent, String[] queryAncestor, int[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {
/*        checkQueryBusy(true);
        
        Integer deltas[] = null;
        if (delta != null)        
        {
            deltas = new Integer[delta.length];
            for (int i = 0; i < deltas.length; i++)
                deltas[i] = new Integer(delta[i]);
        }
        Boolean aboves[] = null;
        if (above != null)
        {
            aboves = new Boolean[above.length];
            for (int i = 0; i < aboves.length; i++)
                aboves[i] = new Boolean(above[i]);                
        }
        Integer levelDepths[] = null;
        if (levelDepth != null)
        {
            levelDepths = new Integer[levelDepth.length];
            for (int i = 0; i < levelDepths.length; i++)
                levelDepths[i] = new Integer(levelDepth[i]);
        }
        Parameter[] params = {new Parameter(dimension, String.class),
                              new Parameter(target, String[].class),
                              new Parameter(hierarchy, String[].class),
                              new Parameter(deltas, Integer[].class),
                              new Parameter(aboves, Boolean[].class),
                              new Parameter(valueParent, String[].class),
                              new Parameter(queryAncestor, String[].class),
                              new Parameter(levelDepths, Integer[].class),
                              new Parameter(parentQDR, OlapQDR[].class)};
        EventList el = new EventList();
        el.addElement(new DrillRequestingEvent(this, dimension, target, hierarchy, delta, above, valueParent, queryAncestor, levelDepth, parentQDR));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.DRILL_CHANGE));
//        capturePageStatebyCursor(dimension);

        try {
            queueOperation(getOpQueue(), "_drill", params, true, null, "drill", params, _getQueryState(), el);
        }
        catch (Throwable e) {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }*/
    }

    /**
     * @internal
     */
    public void _drill(String dimension, String[] value, String[] hierarchy, Integer[] delta, Boolean[] above, String[] valueParent, String[] queryParent, Integer[] levelDepth, OlapQDR[] parentQDR, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
/*        setCurrentOperationAndQueue(userOp, queue);
        
        m_qi.drill(dimension, value, hierarchy, delta, above, valueParent, queryParent, levelDepth, parentQDR);

        BitSet edges = new BitSet(3);
        QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, dimension, false);

        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.DRILL_CHANGE, null));                        */
    }    
    
    /**
     * Drills to specified level of the specified hierarchy.
     *
     * @param dimension The dimension to drill.
     * @param value     The dimension value (also known as member) to drill.
     * @param hierarchy The name of the target hierarchy.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * 
     */
    public synchronized void drill(String dimension, String value, String hierarchy, String level, int action, BitSet flags) throws QueryException, MetadataManagerException
    {
        //drill(dimension, value, hierarchy, level, action, flags, null);
    }

    /**
     * @internal
     * Drills to specified level of the specified hierarchy.
     *
     * @param dimension The dimension to drill.
     * @param value     The dimension value (also known as member) to drill.
     * @param hierarchy The name of the target hierarchy.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @param data     Extra metadata/data
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * @status hidden
     */
    public synchronized void drill(String dimension, String value, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException, MetadataManagerException
    {
        //drill(dimension, value, null, hierarchy, level, action, flags, data);
    }

    /**
     * Drills to specified level of the specified hierarchy.
     *
     * @param dimension The dimension to drill.
     * @param value     The dimension value (also known as member) to drill.
     * @param valueLevel The dimension value's level.
     * @param hierarchy The name of the target hierarchy.
     * @param level     The number of the target level to traverse to.
     * @param action    The selection step action (<code>Step.ADD</code>,
     *                  <code>Step.KEEP</code>, <code>Step.REMOVE</code>, or
     *                  <code>Step.SELECT</code>).
     * @param flags     A list of optional flags. These flags are drill
     *                  constants that begin with the prefix DRILL_EXCLUDE_
     *                  and are found in
     *                 <code>oracle.dss.dataSource.common.DrillConstants</code>.
     * @param data     Extra metadata/data
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_RANGE
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SELF
     * @see oracle.dss.dataSource.common.DrillConstants#DRILL_EXCLUDE_SIBLINGS
     * @see oracle.dss.selection.step.Step#ADD
     * @see oracle.dss.selection.step.Step#KEEP
     * @see oracle.dss.selection.step.Step#REMOVE
     * @see oracle.dss.selection.step.Step#SELECT
     *
     * @status new
     */
    public synchronized void drill(String dimension, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data) throws QueryException, MetadataManagerException
    {
/*        checkQueryBusy(true);
        
        BitSet fl = flags;
        if (fl == null)
        {
            fl = new BitSet();
        }
        Parameter[] params = {new Parameter(dimension, String.class),
                              new Parameter(value, String.class),
                              new Parameter(valueLevel, String.class),
                              new Parameter(hierarchy, String.class),
                              new Parameter(level, String.class),
                              new Parameter(new Integer(action), Integer.class),
                              new Parameter(fl, BitSet.class),
                              new Parameter(data, Object.class)};
        EventList el = new EventList();
        el.addElement(new DrillRequestingEvent(this, dimension, value, hierarchy, level, action, flags));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.DRILL_CHANGE));
//        capturePageStatebyCursor(dimension);

        try {
            queueOperation(getOpQueue(), "_drill", params, true, null, "drill", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }*/
    }

    /**
     * @internal
     * @throws oracle.dss.metadataManager.common.MetadataManagerException
     * @throws oracle.dss.dataSource.common.QueryException
     * @param queue
     * @param before
     * @param userOp
     * @param data
     * @param flags
     * @param action
     * @param level
     * @param hierarchy
     * @param valueLevel
     * @param value
     * @param dimension
     */
    public void _drill(String dimension, String value, String valueLevel, String hierarchy, String level, int action, BitSet flags, Object data, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, MetadataManagerException
    {
/*        setCurrentOperationAndQueue(userOp, queue);
    
        m_qi.drill(dimension, value, valueLevel, hierarchy, level, action, flags, data);
        
        BitSet edges = new BitSet(3);
        QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, dimension, false);
                
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.DRILL_CHANGE, null));                                */
    }


    public void drill(String dimension, String[] target, String[] hierarchy, String[] level, boolean[] above, String[] valueParent, String[] queryAncestor, int[] levelDepth, OlapQDR[] parentQDR) throws QueryException
    {        
    }

    // javadoc from interface
    public void drill(String item, int onEdge, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags) throws QueryException
    {    
        checkQueryBusy(true);
        
        Parameter[] params = {new Parameter(item, String.class),
                              new Parameter(new Integer(onEdge), Integer.class),
                              new Parameter(target, QDR[].class),
                              new Parameter(drillPath, String[].class),
                              new Parameter(drillTarget, String[].class),
                              new Parameter(flags, BitSet.class)};
        EventList el = new EventList();
        el.addElement(new ItemDrillRequestingEvent(this, item, target, drillPath, drillTarget, flags));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.DRILL_CHANGE));

        try {
            queueOperation(getOpQueue(), "_drill", params, true, null, "drill", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }    
    }

    /**
     * @internal
     */
    public void _drill(String item, int onEdge, QDR[] target, String[] drillPath, String[] drillTarget, BitSet flags, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
    
        m_qi.drill(item, onEdge, target, drillPath, drillTarget, flags);
        
        BitSet edges = new BitSet(3);
        QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, item, false);
                
        queue.eventHelper(new ItemDrillRequestedEvent(this, item, target, drillPath, drillTarget, flags));
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.DRILL_CHANGE, null));                                        
    }
    
   /**
    * Arranges the layout of dimensions along the query's edges.
    *
    * @param dimensions An array of dimension layout arrays.
    *
    * @return <code>true</code> if the operation is successful;
    *         <code>false</code> if the operation is not successful.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
    *
    * 
    */
   public synchronized Boolean layout(String[][] dimensions) throws QueryException, MetadataManagerException
   {
        checkQueryBusy(true);
        return _layout(m_opQueue, dimensions, true);
   }

    /**
     * @internal
     */
   protected Boolean _layout(BaseOperationQueue queue, String[][] dimensions, boolean processCompletely) throws QueryException, MetadataManagerException
   {
        Parameter[] params = {new Parameter(dimensions, String[][].class), new Parameter(new Boolean(processCompletely), Boolean.class)};

        EventList el = new EventList();
        el.addElement(new LayoutChangingEvent(this, dimensions));
        QueryState currentState = _getQueryState();
        if (currentState != null && currentState.getDimTree() != null && dimensions != null)
        {
            // Try the preswap ourselves so the event can get pre-info about it
            DimTree newTree = new DimTree(Node.getNodeArray(dimensions, null, null), null);

            // Generate the after selection list
            // blm - Selection code moved to dvt-olap
/*            SelectionList after = newTree.adjustTotalSteps((SelectionList)currentState.getSelections().clone());

            TotalChangingEvent tce = (TotalChangingEvent)getTotalEvent(currentState.getSelections(), after, currentState.getDimTree(), newTree, true);
            if (tce != null)
            {
                el.addElement(tce);
            }*/
        }
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));

//        capturePageStatebyCursor((String[])null);

        Boolean retVal = new Boolean(false);
        try
        {
            retVal = (Boolean)queueOperation(getOpQueue(), "_layout", params, true, null, "layout", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
        return retVal;
   }
   
    public void _pivot(String source, String target, int flags, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        BitSet edges = m_qi.pivot(source, target, flags);
        
        if (edges == null)
        {
            setCurrentOperation(null);
            Parameter[] params = {new Parameter(source, String.class),
                            new Parameter(target, String.class),
                            new Parameter(new Integer(flags), Integer.class)};                            
            throw new IllegalOperationException(getQueryManager().getResourceString("Illegal pivot operation"), new Operation("pivot", params, true));            
        }
        
        try
        {
            queue.eventHelper(new LayoutChangedEvent(this, edges, source, target, Node.getStringArray(_getQueryState().getDimTree().getDimTree()), flags));
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE, null));                        
    }

   /**
    * @internal
    */
   public Boolean _layout(String[][] dimensions, boolean processCompletely, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
   {
        setCurrentOperationAndQueue(userOp, queue);
        
        BitSet edges = m_qi.layout(dimensions);
        
/*        if (dimensions == null)
        {
            m_beforeState.setDimTree(null);
            return new Boolean(true);
        }*/
        
        queue.eventHelper(new LayoutChangedEvent(this, edges, dimensions));
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE, null));                        

        return new Boolean(edges != null);
   }

    // javadoc from interface
    public String[][] getLayout(String layerMetadataType)
    {
        // Get the base layout
        String[][] layout = getLayout();
        
        // Now convert the type if it isn't NAME
        if (layout == null || (layerMetadataType != null && layerMetadataType.equals(LayerMetadataMap.LAYER_METADATA_NAME)))
            return layout;
        
        // Make a copy
        layout = (String[][])layout.clone();
        MDObject obj = null;
        for (int e = 0; e < layout.length; e++)
        {
            if (layout[e] != null)
            {
                for (int l = 0; l < layout[e].length; l++)
                {
                    try
                    {
                        obj = getMDObject(MM.UNIQUE_ID, layout[e][l], MM.OBJECT);
                        layout[e][l] = QueryUtil.getLayerMetadata(layerMetadataType, obj);
                    }
                    catch (MetadataManagerException ex)
                    {
                        throw new QueryRuntimeException(ex.getMessage(), ex);
                    }
                }
            }
        }
        return layout;
    }
    
   /**
    * Retrieves the current layout of dimensions in the query as a
    * two-dimensional <code>String</code>.
    * Note this method may throw a QueryRuntimeException.
    *
    * @return The current layout of dimensions in the query.
    *
    * 
    */
   public String[][] getLayout() {
        BaseNode[][] nodes = null;
        try
        {
            DimTree dt =  _getQueryState().getDimTree();
            if (dt == null)
                return null;
                
            nodes = dt.getDimTree();
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        if (nodes != null)
        {
            return Node.getStringArray(nodes);
        }
        return null;
        // We always want to execute this immediately: informational
        /*OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
            return null;
        }
        try {
            return (String[][])tempQueue.addOperation(new Operation("getLayout", null, false));
        }
        catch (IllegalArgumentException iae) {
            throw iae;
        }
        catch (Throwable e) {
            // Unknown
            throw new QueryRuntimeException(e.getMessage(), e);
        }*/
   }

    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*   public TotalEvent getTotalEvent(SelectionList before, SelectionList after, DimTree beforeLayout, DimTree afterLayout, boolean changing) throws CloneException, InvalidMetadataException, InvalidTotalException
   {

        // Validate
        String dim = afterLayout.validateTotals(after, getMeasureDim());
        if (dim != null)
        {
            throw new InvalidTotalException(getResourceString("Cannot total the measure dimension"), dim, InvalidTotalException.INVALID_TOTAL_MEASURE_EDGE, null);
        }

        Vector selDiffs = after.getSelectionDiffs(before);

        // The change results here are selections derived from the post-change list
        if (selDiffs == null)
        {
            return null;
        }
        Vector totalsChanged = new Vector();
        Vector changeList = new Vector();
        Enumeration sels = selDiffs.elements();
        while (sels.hasMoreElements())
        {
            Selection sel = (Selection)sels.nextElement();
            if (sel != null)
            {
                // Was it an insertion, change, or deletion?
                if (sel.getTotalStep() != null)
                {
                    // Can only be an insertion or change
                    // Which one?  If the old selection had a total, then it's a change
                    Selection oldSel = before.find(sel.getDim());
                    if (oldSel != null)
                    {
                        boolean isChange = (oldSel.getTotalStep() != null);
                        TotalStep ts = null;
                        try
                        {
                            ts = (TotalStep)sel.getTotalStep().clone();
                        }
                        catch (CloneNotSupportedException e)
                        {
                            throw new CloneException(e.getMessage(), e);
                        }
                        if (ts.isAllLayers())
                        {
                            // Find the location of this dim in the *old* layout
                            ts.setLayer(afterLayout.getNode(ts.getEdge(), new Node(sel.getDimension())));
                        }
                        totalsChanged.addElement(ts);
                        changeList.addElement(new Integer(isAutoUpdate() ? (isChange ? TotalChangingEvent.TOTAL_CHANGED : TotalChangingEvent.TOTAL_INSERTED) : TotalChangingEvent.TOTAL_UNKNOWN));
                    }
                }
                else
                {
                    // Can only be a deletion
                    // Get the total step from the previous selection
                    Selection oldSel = before.find(sel.getDim());
                    if (oldSel != null && oldSel.getTotalStep() != null)
                    {
                        TotalStep ts = null;
                        try
                        {
                            ts = (TotalStep)oldSel.getTotalStep().clone();
                        }
                        catch (CloneNotSupportedException e)
                        {
                            throw new CloneException(e.getMessage(), e);
                        }
                        // Make sure the layer is set
                        if (ts.isAllLayers())
                        {
                            // Find the location of this dim in the *old* layout
                            ts.setLayer(beforeLayout.getNode(ts.getEdge(), new Node(oldSel.getDimension())));
                        }
                        totalsChanged.addElement(ts);
                        changeList.addElement(new Integer(isAutoUpdate() ? TotalChangingEvent.TOTAL_REMOVED : TotalChangingEvent.TOTAL_UNKNOWN));
                    }
                }
            }
        }

        TotalStep[] totals = null;
        int[] changeArr = null;
        if (totalsChanged != null && totalsChanged.size() > 0)
        {
            totals = (TotalStep[])Utility.copyVectorToArray(totalsChanged);
        }
        else
        {
            return null;
        }
        if (totals != null)
        {
            changeArr = new int[totals.length];
            for (int i = 0; i < changeList.size(); i++)
            {
                Integer val = (Integer)changeList.elementAt(i);
                changeArr[i] = val.intValue();
            }
        }
        else
        {
            return null;
        }

        TotalEvent event = null;
        if (changing)
        {
            event = new TotalChangingEvent(this, totals, changeArr, TotalEvent.TOTAL_CHANGE_LAYOUT);
        }
        else
        {
            event = new TotalChangedEvent(this, totals, changeArr, TotalEvent.TOTAL_CHANGE_LAYOUT);
        }
        return event;
   }    


  */  


   /**
    * Performs the specified pivot operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension (if an edge is empty, then this
    *                     parameter must be a number that indicates the target
    *                     edge).
    * @param flags        A constant that indicates the type of pivot. Use
    *                     <code>PivotConstants.PIVOT_AFTER</code> or
    *                     <code>PivotConstants.PIVOT_BEFORE</code>.
    *                     
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
    *
    * @see oracle.dss.dataSource.common.PivotConstants#PIVOT_AFTER
    * @see oracle.dss.dataSource.common.PivotConstants#PIVOT_BEFORE
    *
    * 
    */
   public synchronized void pivot(String source, String target, int flags) throws QueryException, MetadataManagerException {
        checkQueryBusy(true);
        Parameter[] params = {new Parameter(source, String.class),
                              new Parameter(target, String.class),
                              new Parameter(new Integer(flags), Integer.class)};


        EventList el = new EventList();
        el.addElement(new LayoutChangingEvent(this, source, target, flags));
        try
        {
            QueryState currentState = _getQueryState();
            if (currentState != null && currentState.getDimTree() != null)
            {
                // Try the prepivot ourselves so the event can get pre-info about it
                DimTree newTree = (DimTree)currentState.getDimTree().clone();
                QueryUtil.doPivot(source, target, flags, newTree);
                // Generate the after selection list
                // blm - Selection code moved to dvt-olap
/*                SelectionList after = newTree.adjustTotalSteps((SelectionList)currentState.getSelections().clone());
                TotalChangingEvent tce = (TotalChangingEvent)getTotalEvent(currentState.getSelections(), after, currentState.getDimTree(), newTree, true);
                if (tce != null)
                {
                    el.addElement(tce);
                }*/
            }
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));
//        capturePageStatebyCursor((String[])null);

        try
        {
            queueOperation(getOpQueue(), "_pivot", params, true, null, "pivot", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
   }


   /**
    * Performs the specified swap operation.
    *
    * @param source       The source dimension.
    * @param target       The target dimension.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
    *
    * 
    */
   public synchronized void swap(String source, String target) throws QueryException, MetadataManagerException {
        checkQueryBusy(true);
   
        Parameter[] params = {new Parameter(source, String.class),
                              new Parameter(target, String.class)};

        EventList el = new EventList();
        el.addElement(new LayoutChangingEvent(this, source, target));
        try
        {
            QueryState currentState = _getQueryState();
            if (currentState != null && currentState.getDimTree() != null)
            {
                // Try the preswap ourselves so the event can get pre-info about it
                DimTree newTree = (DimTree)currentState.getDimTree().clone();
                QueryUtil.doSwap(source, target, newTree);
                // blm - Selection code moved to dvt-olap
/*                // Generate the after selection list
                SelectionList after = newTree.adjustTotalSteps((SelectionList)currentState.getSelections().clone());
                TotalChangingEvent tce = (TotalChangingEvent)getTotalEvent(currentState.getSelections(), after, currentState.getDimTree(), newTree, true);
                if (tce != null)
                {
                    el.addElement(tce);
                }*/
            }
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));

//        capturePageStatebyCursor((String[])null);

        try
        {
            queueOperation(getOpQueue(), "_swap", params, true, null, "swap", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
   }

    /**
     * @internal
     */
    public void _swap(String source, String target, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
        setCurrentOperationAndQueue(userOp, queue);
        

        BitSet edges = m_qi.swap(source, target);

        if (edges == null)
        {
            String routine = "swap";
            Parameter[] params = {new Parameter(source, String.class),
                            new Parameter(target, String.class)};
            throw new IllegalOperationException(getQueryManager().getResourceString("Illegal swap operation"), new Operation(routine, params, true));
        }

        try
        {
            queue.eventHelper(new LayoutChangedEvent(this, edges, source, target, Node.getStringArray(_getQueryState().getDimTree().getDimTree())));
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE, null));        
    }

   /**
    * Performs the specified edge swap operation.
    *
    * @param source A constant that represents the source edge. Use one of the
    *               constants that ends with _EDGE in
    *               <code>oracle.dss.util.DataDirector</code>.
    * @param target A constant that represents the target edge. Use one of the
    *               constants that ends with _EDGE in
    *               <code>oracle.dss.util.DataDirector</code>.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
    *
    * @see oracle.dss.util.DataDirector#COLUMN_EDGE
    * @see oracle.dss.util.DataDirector#DATA_ELEMENT_EDGE
    * @see oracle.dss.util.DataDirector#PAGE_EDGE
    * @see oracle.dss.util.DataDirector#ROW_EDGE
    *
    * 
    */
   public synchronized void swapEdges(int source, int target)  throws QueryException, MetadataManagerException {
        checkQueryBusy(true);
        Parameter[] params = {new Parameter(new Integer(source), Integer.class),
                              new Parameter(new Integer(target), Integer.class)};

        EventList el = new EventList();
        el.addElement(new LayoutChangingEvent(this, source, target));
        try
        {
            QueryState currentState = _getQueryState();
            if (currentState != null && currentState.getDimTree() != null)
            {
                // Try the preswap ourselves so the event can get pre-info about it
                DimTree newTree = (DimTree)currentState.getDimTree().clone();
                newTree.swapEdge(source, target, true);
                // Generate the after selection list
                // blm - Selection code moved to dvt-olap
/*                SelectionList after = newTree.adjustTotalSteps((SelectionList)currentState.getSelections().clone());
                TotalChangingEvent tce = (TotalChangingEvent)getTotalEvent(currentState.getSelections(), after, currentState.getDimTree(), newTree, true);
                if (tce != null)
                {
                    el.addElement(tce);
                }*/
            }
        }
        catch (CloneNotSupportedException e)
        {
            throw new CloneException(e.getMessage(), e);
        }
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE));
        if (source != DataDirector.PAGE_EDGE && target != DataDirector.PAGE_EDGE) {
//            capturePageStatebyCursor((String[])null);
        }

        try {
            queueOperation(getOpQueue(), "_swapEdges", params, true, null, "swapEdges", params, _getQueryState(), el);
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
   }

    /**
     * @internal
     */
    public void _swapEdges(int source, int target, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
        
        m_qi.swapEdges(source, target);
        
        BitSet edges = new BitSet(3);
        edges.set(source);
        edges.set(target);
        
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.PIVOT_CHANGE, null));        
    }
    
    /**
     * Applies the information from the specified <code>Selection</code> object
     * to the corresponding <code>Selection</code> object in this
     * <code>Query</code>.
     *
     * @param selection The <code>Selection</code> to be applied.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized void applySelection(Selection selection) throws QueryException, MetadataManagerException {
        checkQueryBusy(false);
        if (selection == null) {
            throw new IllegalArgException(getResourceString("Selection argument must not be null"), 1, null);
        }
        applySelections(new Selection[] {selection});
    }*/

    /**
     * Removes the specified <code>Selection</code> object from
     * this <code>Query</code>.
     *
     * @param selection The <code>Selection</code> to remove.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public void removeSelection(Selection selection) throws QueryException, MetadataManagerException
    {
        if (selection == null) {
            throw new IllegalArgException(getResourceString("Selection argument must not be null"), 1, null);
        }
        checkQueryBusy(true);
        Parameter[] params = {new Parameter(selection, Selection.class)};

        EventList el = new EventList();
        el.addElement(new SelectionChangingEvent(this, new Selection[] {selection}, true));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));
        Operation oper = new Operation("removeSelection", params, true);
        try {
            queueOperation(getOpQueue(), "_removeSelection", params, true, null, "removeSelection", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void _removeSelection(Selection selection, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
        
        BitSet edges = m_qi.removeSelection(selection);
        
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new SelectionChangedEvent(this, new Selection[] {selection}, true));
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
    }*/
    
    /**
     * Applies the information from the given <code>Selection</code> objects to
     * the corresponding <code>Selection</code> objects in this
     * <code>Query</code>.
     *
     * @param selections The <code>Selection</code> objects to apply.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized void applySelections(Selection[] selections) throws QueryException, MetadataManagerException {
        checkQueryBusy(false);
        _applySelections(m_opQueue, selections, true);
    }*/

    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    protected void _applySelections(BaseOperationQueue queue, Selection[] selections, boolean processCompletely) throws QueryException, MetadataManagerException {
        checkQueryBusy(false);
        if (selections != null)
        {
            String[] items = new String[selections.length];
            for (int i = 0; i < items.length; i++)
                items[i] = selections[i].getDimension();
            MDObject mdObj = getDataSourceObj(items, null);
            if (mdObj == null)
            {
                mdObj = getDataSourceObj(selections);
                if (mdObj == null)
                {
                    // This is bad: invalid dim
                    throw new InvalidDimensionException(MessageFormat.format(getQueryManager().getResourceString("Invalid dimension specified"), items), items, null);                
                }
            }
            setupQueryInterfaceImpl(mdObj);
        }
        Parameter[] params = {new Parameter(selections, Selection[].class), new Parameter(new Boolean(false), Boolean.class), new Parameter(new Boolean(processCompletely), Boolean.class)};

        EventList el = new EventList();
        el.addElement(new SelectionChangingEvent(this, selections));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));
        if (selections != null) {
            String[] names = new String[selections.length];
            for (int i = 0; i < selections.length; names[i] = selections[i++].getDimension());
//            capturePageStatebyCursor(names);
        }
        try
        {
            queueOperation(getOpQueue(), "_applySelections", params, true, null, "applySelections", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void _applySelections(Selection[] sels, boolean totals, boolean processCompletely, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
                
        boolean reinit = false;
        String[] measures = _getQueryState().getMeasures();
        if (measures == null || measures.length == 0)
        {
            reinit = true;
        }
      
        Selection selection = null;
        boolean changeDimensionality = false;
        Selection[] selections = null;
        SelectionList oldSelections = null;
        SelectionList currSels = _getQueryState().getSelections();
        if (currSels !=  null)
        {
          oldSelections = (SelectionList)currSels.clone();
        }
        String[] oldMeas = null;
        if (measures != null)
        {
            oldMeas = (String[])measures.clone();
        }
        if (sels == null)
        {
            _getQueryState().setSelections(new SelectionList());
        }
        else
        {
            selections = new Selection[sels.length];
            for (int sel = 0; sel < sels.length; sel++)
            {   
                try
                {    
                    selection = (Selection)sels[sel].clone();
                    if (selection.clearDrillStep())
                    {
                        // Erase all drilling: modification of basic selection for dimension
                        selection.setDrillStep(null);
                        selection.removeAllDrillLevelSteps();
                    }
    
                    // Clear the default step, if the first step has changed
                    Selection oldSel = null;
                    if (selection.getDimension() == null)
                    {
                        oldSel = currSels.find(selection.getDimensions());
                    }
                    else
                    {
                        oldSel = currSels.find(selection.getDimension());
                    }
                    if (oldSel != null && oldSel.getStepCount() > 0)
                    {
                        Step oldFirstStep = oldSel.getStep(0);
                        if (selection.getStepCount() > 0)
                        {
                            Step newFirstStep = selection.getStep(0);
                            if (!oldFirstStep.equals(newFirstStep))
                            {
                                // First step has changed due to user: clear this flag forever
                                selection.setFirstStepDefault(false);
                            }
                        }
                  }

                  selection.setClearDrillStep(true);
                  selections[sel] = selection;
            }
            catch (CloneNotSupportedException e)
            {
                throw new CloneException(e.getMessage(), e);
            }
            // Transfer any totalstep from the old selection here to the new selection
            // unless we're coming in from total setting
            if (!totals)
            {
                if (oldSelections != null && selection != null)
                {
                    Selection oldSel = oldSelections.find(selection.getDim());
                    if (oldSel != null)
                    {
                        TotalStep oldTotal = oldSel.getTotalStep();
                        selection.setTotalStep(oldTotal);
                    }
                }
            }
        }
    }
      
      if (processCompletely)
      {
          // Check if the current layout meshes as far as asymmetry with the new selections
          DimTree dimensions = _getQueryState().getDimTree();
          if (dimensions != null && !dimensions.isLayoutAcceptable(currSels, null, null))
          {
                _getQueryState().setMeasures(oldMeas);
                _getQueryState().setSelections(oldSelections);
                throw new IllegalOperationException(getQueryManager().getResourceString("Illegal asymmetric selection applied"), userOp);
          }
      }

        BitSet edges = m_qi.applySelections(selections);

        queue.eventHelper(new SelectionChangedEvent(this, selections));        
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
    }
*/
    /**
     * Retrieves a reference to the complete collection of
     * <code>Selection</code> objects for this <code>Query</code>.
     * Each <code>Selection</code> corresponds to an underlying dimension
     * (including the Measure dimension).
     * The <code>Query</code> is registered as a listener to  all the
     * <code>Selection</code> objects in the collection, such that changes to
     * any one of them are captured as <code>Query</code> operations.
     *
     * @return The list of <code>Selection</code> objects.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public java.util.List getAllSelections()
    {
        SelectionList sels = _getQueryState().getSelections();
        
        return sels == null ? null : (java.util.List)sels.clone();
    }*/

    // Check to see if a query is defined
    /**
     * @internal
     */
    protected void checkForQuery() throws QueryException {
        if (_getQueryState().getDimTree() == null) {
            throw new NoQueryDefinedException(getQueryManager().getResourceString("No query defined"));
        }
    }

    /**
     * @internal
     * Determine if the query is busy with a current operation
     */
    protected void checkQueryBusy(boolean checkForQuery) throws QueryException
    {
        if (checkForQuery)
            checkForQuery();
            
        if (getCurrentOperation() != null)
            throw new QueryBusyException();
    }

    /**
     * Retrieves a <code>Selection</code> object that corresponds to the
     * specified dimension. The <code>Query</code> is registered as a
     * listener to this object so that changes to the underlying list of
     * <code>Step</code> objects are captured as <code>Query</code>
     * operations.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param dimension The dimension for which to return the current
     *                  <code>Selection</code> object.
     *
     * @return The <code>Selection</code> object that corresponds to the
     *         specified dimension.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection findSelection(String dimension)
    {
        try
        {
            Selection sel = _findSelection(dimension);
            return sel != null ? (Selection)sel.clone() : null;
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }

    private Selection _findSelection(Object dimensions)
    {
        if (dimensions == null)
        {
            throw new IllegalArgumentException(getQueryManager().getResourceString("Invalid dimension in findSelection"));
        }
        // We always want to execute this immediately: informational
        return  _getQueryState() != null &&  _getQueryState().getSelections() != null ?  _getQueryState().getSelections().find(dimensions) : null;
    }
*/
    /**
     * Retrieves a <code>Selection</code> object that corresponds to the
     * specified dimensions. The <code>Query</code> is registered as a
     * listener to this object so that changes to the underlying list of
     * <code>Step</code> objects are captured as <code>Query</code>
     * operations.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param dimension The dimensions for which to return the current
     *                  <code>Selection</code> object.
     *
     * @return The <code>Selection</code> object that corresponds to the
     *         specified dimensions.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public Selection findSelection(java.util.List dimensions)
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Selection retVal = null;
        try {
            retVal = (Selection)tempQueue.addOperation(new Operation("findSelection", new Parameter[] {new Parameter(dimensions, java.util.List.class)}, false));
        }
        catch (IllegalArgumentException iae) {
            throw iae;
        }
        catch (Throwable e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        return retVal;
    }
*/

    /**
     * Checks a given <code>MDObject</code> (measures are the only
     * type of <code>MDObject</code> checked at this time) and determines
     * whether the query makes use of the object in its selections
     * or measure list.
     * Note: This method may throw a QueryRuntimeException.
     *
     * @param object <code>MDObject</code> that represents the object to check.
     *
     * @return <code>true</code> if the query uses the object;
     *         <code>false</code> if the query does not use the object.
     *
     * 
     */
/*    public Boolean isDependentOn(MDObject object)
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Boolean retVal = new Boolean(false);
        try
        {
            retVal = (Boolean)tempQueue.addOperation(new Operation("isDependentOn", new Parameter[] {new Parameter(object, MDObject.class)}, false));
        }
        catch (Throwable e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        return retVal;
    }*/


    
    /**
     * @internal
     */
/*    public Vector getMemberLevel(String hierarchy)
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Vector retVal = null;
        try
        {
            retVal = (Vector)tempQueue.addOperation(new Operation("getMemberLevel", new Parameter[] {new Parameter(hierarchy, String.class)}, false));
        }
        catch (Throwable e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        return retVal;
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void setMemberLevel(String hierarchy, MemberStep step)
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return;
        }
        try
        {
            tempQueue.addOperation(new Operation("setMemberLevel", new Parameter[] {new Parameter(hierarchy, String.class), new Parameter(step, MemberStep.class)}, false));
        }
        catch (Throwable e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
*/    
    /**
     * Specifies a <code>Selection</code> object to be used as the starting
     * "universe" corresponding to the specified dimension. This action
     * invalidates any existing query and
     * overrides any MetadataManager bean universes for the specified dimension.
     * Note that universe Selections may not be set for the measure dimension.
     *
     * @param dimension The dimension for which to set the universe.
     * @param selection The <code>Selection</code> object to set as the
     *                  universe.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized void setUniverseSelection(String dimension, Selection selection) throws MetadataManagerException, QueryException {
        checkQueryBusy(false);
    
        if (dimension == null) {
            throw new IllegalArgException(getResourceString("Dimension argument must not be null in setUniverse"), 1, null);
        }
        Parameter[] params = {new Parameter(dimension, String.class), new Parameter(selection, Selection.class)};

        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, dimension, selection);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE);
        el.addElement(dce);
        try {
            queueOperation(getOpQueue(), "_setUniverseSelection", params, true, null, "setUniverseSelection", params, _getQueryState(), el);
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally 
        {
            setCurrentOperation(null);
        }
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void _setUniverseSelection(String dimension, Selection sel, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        _getQueryState().getPropertySupport().setUniverseSelection(dimension, sel);
        
        queue.eventHelper(new StateChangedEvent(this, dimension, sel));
        
        // Determine list of edges based on dimension that's changing, if any
        BitSet edges = new BitSet(3);
        if (dimension == null) {
            edges.set(DataDirector.ROW_EDGE);
            edges.set(DataDirector.COLUMN_EDGE);
            edges.set(DataDirector.PAGE_EDGE);
        }
        else {
            QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, dimension, false);
        }
        
        Selection selection = _getQueryState().getSelections().find(dimension);
        m_qi.applySelections(new Selection[] {selection});
        
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                                
    }
  */  
    /**
     * Retrieves the <code>Selection</code> object that is being used as the
     * starting "universe" corresponding to the specified dimension.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param dimension The dimension for which to return the universe
     *                  <code>Selection</code> object.
     *
     * @return The <code>Selection</code> object, if there is one;
     *         <code>null</code> if there is no <code>Selection</code> object
     *         that is being used as the starting "universe".
     *
     * @throws IllegalArgException    If arguments are invalid.
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
 /*public synchronized Selection getUniverseSelection(String dimension) throws IllegalArgException {
        if (dimension == null) {
            throw new IllegalArgException(getResourceString("Invalid dimension in getUniverseSelection"), 1, null);
        }
        return _getQueryState().getPropertySupport().getUniverseSelection(dimension);
    }
*/
    /**
     * Sets the specified <code>TotalStep</code> to enable row or column totals
     * on the specified dimension in the query.
     *
     * @param dimension The dimension on which to set the row or column total.
     * @param totalStep The <code>TotalStep</code> that contains information  
     *                  about the row or column total.  If <code>null</code>,
     *                  then any <code>TotalStep</code> set for the given 
     *                  dimension is cleared.
     *                  
     * @return <code>true</code> if successful, <code>false</code> if 
     *         unsuccessful or user canceled via event.
     *         
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.selection.step.TotalStep
     * 
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized boolean setTotal(String dimension, TotalStep totalStep) throws QueryException, MetadataManagerException
    {
        checkQueryBusy(false);
        if (dimension == null)
        {
            throw new IllegalArgException(getResourceString("Dimension argument must not be null in setTotal"), 1, null);
        }
        Parameter[] params = {new Parameter(dimension, String.class), new Parameter(totalStep, TotalStep.class), new Parameter(new Integer(-1), Integer.class)};

        // We need to grab the old selection
        Selection selection = findSelection(dimension);
        EventList el = new EventList();
        el.addElement(getTotalEvent(new TotalStep[] {totalStep}, new Selection[] {selection}, _getQueryState().getDimTree(), isAutoUpdate()));
        el.addElement(new SelectionChangingEvent(this, new Selection[] {selection}));
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE);
        el.addElement(dce);
        Object retVal = null;
        try {
            retVal = queueOperation(getOpQueue(), "_setTotal", params, true, null, "setTotal", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
        if (retVal != null && retVal instanceof ConsumedOperations)
        {
            return false;
        }
        return true;
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void _setTotal(String dimension, TotalStep totalStep, int edge, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, MetadataManagerException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        int layerCount = 1;
        int layerStart = -1;
        boolean allLayers = false;
        DimTree dt = _getQueryState().getDimTree();
        if (edge == DataDirector.ROW_EDGE || edge == DataDirector.COLUMN_EDGE)
        {
            // This is an all layer total step: we need to update the selections through the layout
            layerCount = dt.getNodeCount(edge);
            layerStart = 0;
            allLayers = true;
        }
        else
        {
            // Find the given dimension in the layout
            layerStart = dt.getNode(new Node(dimension));
            edge = dt.getEdge(new Node(dimension));
        }
        SelectionList oldSels = (SelectionList)_getQueryState().getSelections().clone();
        Selection[] sels = null;
        sels = dt.applyTotalSteps(_getQueryState().getSelections(), totalStep, edge, layerStart, layerCount, allLayers);

        // Do validation
        String dim = dt.validateTotals(_getQueryState().getSelections(), getMeasureDim());
        if (dim != null)
        {
            // Put back the state
            _getQueryState().setSelections(oldSels);
            throw new InvalidTotalException(getResourceString("Cannot total the measure dimension"), dim, InvalidTotalException.INVALID_TOTAL_MEASURE_EDGE, null);
        }
        if (sels == null && layerCount == 1 && totalStep != null)
        {
            // This is a single (non all) set: for a special case of inserting an existing
            // total to "turn on" a view, process it anyway
            sels = new Selection[1];
            sels[0] = findSelection(totalStep.getDimension());
            sels[0].setClearDrillStep(false);
        }

        TotalStep[] totalSteps = null;
        int[] changes = null;
        Selection[] eventSels = null;
        if (sels != null)
        {
            totalSteps = new TotalStep[sels.length];
            changes = new int[sels.length];
            eventSels = new Selection[sels.length];
            for (int s = 0; s < sels.length; s++)
            {
                Selection oldSel = oldSels.find(sels[s].getDimension());
                TotalStep ts = sels[s].getTotalStep();
                if (ts == null)
                {
                    // Find the old selection to get what's deleted
                    ts = oldSel.getTotalStep();
                    try
                    {
                        eventSels[s] = (Selection)sels[s].clone();
                        totalSteps[s] = (TotalStep)ts.clone();
                    }
                    catch (CloneNotSupportedException e)
                    {
                        throw new CloneException(e.getMessage(), e);
                    }
                    if (totalSteps[s].getEdge() > -1 && totalSteps[s].getLayer() == -1)
                    {
                        // This is an all case: mark the layer with the actual layer
                        // for the event
                        totalSteps[s].setLayer(_getQueryState().getDimTree().getNode(totalSteps[s].getEdge(), new Node(eventSels[s].getDimension())));
                    }
                    changes[s] = TotalEvent.TOTAL_REMOVED;
                }
                else
                {
                    try
                    {
                        eventSels[s] = (Selection)sels[s].clone();
                        totalSteps[s] = (TotalStep)ts.clone();
                    }
                    catch (CloneNotSupportedException e)
                    {
                        throw new CloneException(e.getMessage(), e);
                    }
                    if (totalSteps[s].getEdge() > -1 && totalSteps[s].getLayer() == -1)
                    {
                        // This is an all case: mark the layer with the actual layer
                        // for the event
                        totalSteps[s].setLayer(_getQueryState().getDimTree().getNode(totalSteps[s].getEdge(), new Node(eventSels[s].getDimension())));
                    }
                    changes[s] = oldSel.getTotalStep() == null ? TotalEvent.TOTAL_INSERTED : TotalEvent.TOTAL_CHANGED;
                }
            }
            eventHelper(new TotalChangedEvent(this, totalSteps, changes, TotalEvent.TOTAL_CHANGE_SET));
            eventHelper(new SelectionChangedEvent(this, sels));
            _applySelections(sels, true, true, userOp, before, getOpQueue());
        }
    }
    
    // This method to create the total changing event must combine the total that is being
    // set with any changes in other totals due to rotation, etc.
    private TotalChangingEvent getTotalEvent(TotalStep[] newTotals, Selection[] selChange, DimTree layout, boolean isAutoUpdate) throws QueryException
    {
        Vector totals = new Vector();
        Vector changes = new Vector();

        for (int i = 0; i < newTotals.length; i++)
        {
            TotalStep oldTotal = null;
            if (selChange != null && selChange[i] != null)
            {
                oldTotal = selChange[i].getTotalStep();
            }

            if (!isAutoUpdate)
            {
                // We can't know anything about the nature of the total change because the
                // query state off which it's based could be inaccurate
                totals.addElement(newTotals[i]);
                changes.addElement(new Integer(TotalEvent.TOTAL_UNKNOWN));
            }
            else
            {
                if (newTotals[i] != null)
                {
                // We're either setting a new total or changing to this total
                    totals.addElement(newTotals[i]);
                    if (oldTotal != null)
                    {
                        changes.addElement(new Integer(TotalEvent.TOTAL_CHANGED));
                    }
                    else
                    {
                        changes.addElement(new Integer(TotalEvent.TOTAL_INSERTED));
                    }
                }
                else
                {
                    // This is a deletion.  Put the clone in because any "changes" via the event
                    // to this object won't matter
                    if (oldTotal != null)
                    {
                        try
                        {
                            TotalStep ts = (TotalStep)oldTotal.clone();
                            if (ts.isAllLayers())
                            {
                                Node n = new Node(selChange[i].getDimension());
                                ts.setLayer(layout.getNode(layout.getEdge(n), n));
                            }
                            totals.addElement(ts);
                            changes.addElement(new Integer(TotalEvent.TOTAL_REMOVED));
                        }
                        catch (CloneNotSupportedException e)
                        {
                            throw new CloneException(e.getMessage(), e);
                        }
                    }
                }
            }
        }

        TotalStep[] totalSteps = new TotalStep[totals.size()];
        int[] charray = new int[changes.size()];
        if (charray.length != totalSteps.length)
        {
            // Something's wrong
            throw new QueryException(null, null);
        }

        for (int i = 0; i < totalSteps.length; i++)
        {
            totalSteps[i] = (TotalStep)totals.elementAt(i);
            charray[i] = ((Integer)changes.elementAt(i)).intValue();
        }
        return new TotalChangingEvent(this, totalSteps, charray, TotalEvent.TOTAL_CHANGE_SET);
    }
*/
    /**
     * Retrieves the <code>TotalStep</code> object that is currently set for the
     * specified dimension, if any.  Returns <code>null</code> otherwise.
     *
     * @param The dimension for which the <code>TotalStep</code> will
     *        be retrieved.
     *
     * @return The <code>TotalStep</code> object;
     *         <code>null</code> if there is no <code>TotalStep</code> for the
     *         specified dimension.
     *
     * @throws IllegalArgException If arguments are invalid.
     * @throws QueryException If there was a problem getting the 
     *                        <code>TotalStep</code>
     *
     * @see oracle.dss.selection.step.TotalStep
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*     public synchronized TotalStep getTotal(String dimension) throws IllegalArgException, QueryException
     {
        if (dimension == null)
        {
            throw new IllegalArgException(getResourceString("Invalid dimension in getTotal"), 1, null);
        }
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        TotalStep retVal = null;
        Operation oper = new Operation("getTotal", new Parameter[] {new Parameter(dimension, String.class)}, false);
        try {
            retVal = (TotalStep)tempQueue.addOperation(oper);
        }
        catch (IllegalArgumentException iae)
        {
            throw iae;
        }
        catch (Throwable e)
        {
            if (e instanceof QueryException)
                throw (QueryException)e;
            else
                throw new QueryException(e.getMessage(), e);
        }
        return retVal;
    }
*/
    /**
     * @internal
     * Sets the specified <code>TotalStep</code> to enable row or column totals
     * on the specified edge and layer in the query.
     *
     * @param edge      The edge on which to set the row or column total.
     * @param layer     The layer on which to set the row or column total.
     * @param totalStep The <code>TotalStep</code> that ontains information 
     *                  about the row or column total.  If <code>null</code>,
     *                  then any <code>TotalStep</code> set for the given edge 
     *                  and layer is cleared.
     *                  
     * @return <code>true</code> if successful, <code>false</code> if 
     *         unsuccessful or user canceled via event.  Setting
     *         a total on a page edge results in an unsuccessful call.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.selection.step.TotalStep
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized boolean setTotal(int edge, int layer, TotalStep totalStep) throws QueryException, MetadataManagerException
    {
        checkQueryBusy(false);
        Parameter[] params = {new Parameter(new Integer(edge), Integer.class), new Parameter(new Integer(layer), Integer.class), new Parameter(totalStep, TotalStep.class)};

        // Disallow page
        if (edge > DataDirector.ROW_EDGE)
        {
            return false;
        }
        
        // Look up the dimension at the given edge and layer
        int layerStart = layer;
        int layerEnd = layer+1;
        if (layer == DataDirector.TOTAL_ALL_LAYERS)
        {
            layerStart = 0;
            layerEnd = _getQueryState().getDimTree().getNodeCount(edge);
        }

        TotalStep[] tsList = new TotalStep[layerEnd-layerStart];
        Selection[] selList = new Selection[layerEnd-layerStart];
        if (totalStep != null)
        {
            totalStep.setEdge(edge);
            totalStep.setLayer(layer);
        }

        for (int l = layerStart; l < layerEnd; l++)
        {
            int index = l-layerStart;

            // We need to grab the old selection
            selList[index] = getSelectionForEdgeLayer(edge, l, getResourceString("Bad edge argument"), getResourceString("Bad layer argument"));
            if (totalStep != null)
            {
                try
                {
                    tsList[index] = (TotalStep)totalStep.clone();
                }
                catch (CloneNotSupportedException e)
                {
                    throw new CloneException(e.getMessage(), e);
                }
                if (selList[index] != null)
                {
                    tsList[index].setDimension(selList[index].getDimension());
                    tsList[index].setHierarchy(selList[index].getHierarchy());
                }

                // Poke the totalstep with the edge and layer
                tsList[index].setEdge(edge);
                tsList[index].setLayer(l);
            }
        }
        EventList el = new EventList();
        el.addElement(getTotalEvent(tsList, selList, _getQueryState().getDimTree(), isAutoUpdate()));
        el.addElement(new SelectionChangingEvent(this, selList));
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE);
        el.addElement(dce);
        Object retVal = null;
        try {
            retVal = queueOperation(getOpQueue(), "_setTotal", params, true, null, "setTotal", params, _getQueryState(), el);
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);            
        }
        if (retVal != null && retVal instanceof ConsumedOperations)
        {
            return false;
        }
        return true;
    }
*/
    /**
     * @internal
     */
     // blm - Selection code moved to dvt-olap
/*    public void _setTotal(int edge, int layer, TotalStep ts, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, MetadataManagerException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        // Look up the dimension at the given edge and layer
        Selection selection = null;
        String dim = null;
        if (layer != DataDirector.TOTAL_ALL_LAYERS)
        {
            selection = getSelectionForEdgeLayer(edge, layer, getResourceString("Bad edge argument"), getResourceString("Bad layer argument"));
            dim = selection.getDimension();
        }        
        _setTotal(dim, ts, edge, userOp, before, queue);
    }
  */  
    /**
     * @internal
     * Retrieves the <code>TotalStep</code> object that is currently set for the
     * specified edge and layer, if any.  Returns <code>null</code> otherwise.
     *
     * @param edge The edge for which the <code>TotalStep</code> will
     *        be retrieved.
     * @param layer The layer for which the <code>TotalStep</code> will
     *        be retrieved.
     *
     * @return The <code>TotalStep</code> object;
     *         <code>null</code> if there is no <code>TotalStep</code> for the
     *         specified dimension.
     *
     * @throws IllegalArgException If arguments are invalid.
     * @throws QueryException      If there was a problem getting the 
     *                             <code>TotalStep</code>.
     *
     * @see oracle.dss.selection.step.TotalStep
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * 
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public synchronized TotalStep getTotal(int edge, int layer) throws IllegalArgException, QueryException
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        TotalStep retVal = null;
        Operation oper = new Operation("getTotal", new Parameter[] {new Parameter(new Integer(edge), Integer.class), new Parameter(new Integer(layer), Integer.class)}, false);
        try {
            retVal = (TotalStep)tempQueue.addOperation(oper);
        }
        catch (IllegalArgumentException iae)
        {
            throw iae;
        }
        catch (Throwable e)
        {
            if (e instanceof QueryException)
                throw (QueryException)e;
            else
                throw new QueryException(e.getMessage(), e);
        }
        return retVal;
    }
*/
    /**
     * Adds one or more measures to an existing query.  Creates the query if one
     * does not yet exist.
     *
     * @param measures An array of the names of the measures to add.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void addCubeMeasures(String[] measures) throws QueryException, MetadataManagerException {
        checkQueryBusy(true);
        
        Parameter[] params = {new Parameter(measures, String[].class), new Parameter(null, String[].class)};
        EventList el = new EventList();
        // blm - Selection code moved to dvt-olap
        el.addElement(getSelectionChangeEvent(measures));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));
        
        Operation oper = new Operation("addCubeMeasures", params, true);
        try {
            queueOperation(getOpQueue(), "_addCubeMeasures", params, true, null, "addCubeMeasures", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
    
    /**
     * @internal
     */
    public void _addCubeMeasures(String[] measures, String[] items, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
        
        BitSet edges = m_qi.addItems(measures, items);
        
        addToUndo(queue, userOp, before, _getQueryState());
        if (edges == null)
        {
            queue.eventHelper(new DataAvailableEvent(this, true, null));
        }
        else
        {
            queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
        }        
    }
    
    public synchronized void addItems(String[] dataItems, String[] items) throws QueryException
    {        
        checkQueryBusy(true);
        
        Parameter[] params = {new Parameter(dataItems, String[].class), new Parameter(items, String[].class)};
        EventList el = new EventList();
        el.addElement(getSelectionChangeEvent(dataItems));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));
        
//        capturePageStatebyCursor(getMeasureDim());

        Operation oper = new Operation("addItems", params, true);
        try {
            queueOperation(getOpQueue(), "_addCubeMeasures", params, true, null, "addItems", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
    
    /**
     * Requests that the types in the specified <code>DataMap</code> be added
     * to the types iin the DataMap of the <code>Query</code>.
     * These types will be included in subsequent cursors.
     * Note this method may throw a QueryRuntimeException.
     *
     * @param map The <code>DataMap</code> object that contains the
     *            types to be added.
     *
     * 
     */
    public synchronized void applyDataMap(DataMap map) {
        try
        {
            checkQueryBusy(false);
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        
        // Create a temporary map support object so we can check if we can avoid this call altogether beyond this point
        MapSupport tempMS = (MapSupport) _getQueryState().getMapSupport().clone();
        if (!tempMS.applyDataMap(map))
        {
            return;
        }
        Parameter[] params = {new Parameter(map, DataMap.class)};
        
        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, null, map, StateChangeEvent.DATA_MAP);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        try {
            if (!dce.isConsumed() && !sce.isConsumed()) {
                 _getQueryState().getMapSupport().applyDataMap(map);
                queueOperation(getOpQueue(), "_applyDataMap", params, true, null, "applyDataMap", params, _getQueryState(), el);
            }
        }
        catch (Throwable e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        finally
        {
            setCurrentOperation(null);
        }                
    }
    
    /**
     * @internal
     */
    public void _applyDataMap(DataMap map, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        queue.eventHelper(new StateChangedEvent(this, null, map, StateChangeEvent.DATA_MAP));
        BitSet edges = new BitSet(3);
        
        m_qi.applyDataMap(map);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, null));                        
    }
    
    /**
     * Requests that the specified <code>MetadataMap</code> types for the
     * specified dimension be added to the types in the MetadataMap of the
     * <code>Query</code>.
     * These <code>MetadataMap</code> types will be included in subsequent
     * cursors.
     *
     * @param dimension The dimension to which this map should be applied.
     * @param map       The MetadataMap that contains the desired types.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void applyMetadataMap(String dimension, MetadataMap map) throws QueryException, MetadataManagerException
    {
        checkQueryBusy(false);
        // Create a temporary map support object so we can check if we can avoid this call altogether beyond this point
        MapSupport tempMS = (MapSupport) _getQueryState().getMapSupport().clone();
        if (!tempMS.applyMetadataMap(dimension, isTimeDimension(dimension), map))
        {
            return;
        }
        Parameter[] params = {new Parameter(dimension, String.class),
                              new Parameter(map, MetadataMap.class)};
        
        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, dimension, map, StateChangeEvent.METADATA_MAP);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, false, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        Operation oper = new Operation("applyMetadataMap", params, true);
        try {
            if (!dce.isConsumed() && !sce.isConsumed()) {
                 _getQueryState().getMapSupport().applyMetadataMap(dimension, isTimeDimension(dimension), map);
                queueOperation(getOpQueue(), "_applyMetadataMap", params, true, null, "applyMetadataMap", params, _getQueryState(), el);
            }
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
    }

    /**
     * @internal
     */
    public void _applyMetadataMap(String dimension, MetadataMap map, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        try
        {
            queue.eventHelper(new StateChangedEvent(this, dimension, _getQueryState().getMapSupport().getMetadataMap(dimension, isTimeDimension(dimension)), StateChangeEvent.METADATA_MAP));
        }
        catch (MetadataManagerException e)
        {
            exceptionThrower2(e);
        }
        // Determine list of edges based on dimension that's changing, if any
        BitSet edges = new BitSet(3);
        if (dimension == null) {
            edges.set(DataDirector.ROW_EDGE);
            edges.set(DataDirector.COLUMN_EDGE);
            edges.set(DataDirector.PAGE_EDGE);
        }
        else {
            QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, dimension, false);
        }        
        
        m_qi.applyMetadataMap(dimension, map);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, null));                        
    }

    /**
     * Requests that the specified <code>MetadataMap</code> types be added to
     * the types in the MetadataMap of the <code>Query</code>.
     * These <code>MetadataMap</code> types will be included in subsequent
     * cursors.
     *
     * @param edge A constant that represents the edge to which the new
     *             <code>MetadataMap</code> types will be applied.
     *             The valid constants
     *             (<code>COLUMN_EDGE</code>, <code>PAGE_EDGE</code>,
     *             <code>ROW_EDGE</code>) are found in
     *             <code>oracle.dss.util.DataDirector</code>.
     * @param map  The <code>MetadataMap</code> object that contains the
     *             desired types.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#DATA_ELEMENT_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     *
     * 
     */
    public synchronized void applyMetadataMap(int edge, MetadataMap map) throws QueryException, MetadataManagerException
    {
        checkQueryBusy(false);
        // Create a temporary map support object so we can check if we can avoid this call altogether beyond this point
        MapSupport tempMS = (MapSupport) _getQueryState().getMapSupport().clone();
        if (!tempMS.applyMetadataMap(edge, map))
        {
            return;
        }
        Parameter[] params = {new Parameter(new Integer(edge), Integer.class),
                              new Parameter(map, MetadataMap.class)};

        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, edge, map, StateChangeEvent.METADATA_MAP);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, false, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        Operation oper = new Operation("applyMetadataMap", params, true);
        try {
            if (!dce.isConsumed() && !sce.isConsumed()) {
                 _getQueryState().getMapSupport().applyMetadataMap(edge, map);
                queueOperation(getOpQueue(), "_applyMetadataMap", params, true, null, "applyMetadataMap", params, _getQueryState(), el);
            }
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }            
        finally
        {
            setCurrentOperation(null);
        }
    }    
    
    /**
     * @internal
     */
    public void _applyMetadataMap(int edge, MetadataMap map, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        queue.eventHelper(new StateChangedEvent(this, edge, _getQueryState().getMapSupport().getMetadataMap(edge), StateChangeEvent.METADATA_MAP));
        // Determine list of edges based on dimension that's changing, if any
        BitSet edges = new BitSet(3);
        edges.set(edge);

        m_qi.applyMetadataMap(edge, map);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, null));                        
    }
    
    /**
     * Creates a query that is based on one or more specified Measures. The
     * dimensionality of the resultant query will be based upon the superset of
     * the dimensionality of the Measures; optionally, the caller can also
     * describe the default layout of the dimensions along the edges of the
     * query.
     *
     * @param items     The name or names of the items.
     * @param dimensions   Optional array of dimension layout arrays.
     *
     * @throws QueryException            If a cursor cannot be created for this
     *                                   query.
     * @throws IllegalArgumentException  If one or more of the arguments is
     *                                   invalid.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void initCubeQuery(String[] items, String[][] dimensions) throws QueryException, IllegalArgumentException, MetadataManagerException {
        checkQueryBusy(false);
            
        if (dimensions != null && dimensions.length == 0)
        {
            dimensions = null;
        }
        if (items != null && items.length == 0)
        {
            items = null;
        }
        if (items == null)
        {
            // Bad argument
            setCurrentOperation(null);
            throw new IllegalArgException(getResourceString("measure argument must not be null in initCubeQuery"), 2, null);
        }        
        
        // Special check for MDItem data items with no items: throw exception
        for (int i = 0; i < items.length; i++)
        {
            MDObject obj = getMDObject(MM.UNIQUE_ID, items[i], MM.OBJECT);
            if (obj instanceof MDItem)
            {
                Parameter[] params = {new Parameter(items, String[].class),
                                      new Parameter(dimensions, String[][].class)};
                
                throw new IllegalOperationException(getResourceString("initCubeQuery invalid for item-based queries"), new Operation("initCubeQuery", params, true));
            }
        }
        
        _initCubeQuery(null, items, null, dimensions);
        
        setCurrentOperation(null);
    }
        
    /**
     * @internal
     * @throws oracle.dss.metadataManager.common.MetadataManagerException
     * @throws java.lang.IllegalArgumentException
     * @throws oracle.dss.dataSource.common.QueryException
     * @param dimensions
     * @param items
     * @param dataItems
     * @param queue
     */
    protected void _initCubeQuery(BaseOperationQueue queue, String[] dataItems, String[] items, String[][] dimensions) throws QueryException, IllegalArgumentException, MetadataManagerException
    {    
        setupQueryInterfaceImpl(getDataSourceObj(dataItems, dimensions));
        Parameter[] params = {new Parameter(dataItems, String[].class),
                              new Parameter(items, String[].class),
                              new Parameter(dimensions, String[][].class)};
        try
        {
            queueOperation(queue, "_initCubeQuery", params, true, null, "initCubeQuery", params, _getQueryState(), new EventList());
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }              
        finally
        {
            setCurrentOperation(null);
        }
    }

    /**
     * @internal
     */
    protected void setupQueryInterfaceImpl(MDObject obj)
    {        
        if (obj == null)
            return;
        
        // Load the queryinterface implementation
        String type = null;
        if (obj.getDatasource() != null) {
            type = obj != null ? ((Connection)obj.getDatasource()).getDatasourceType() : null;
            if (MM.SBA.equals(type)) {
/*              if (Boolean.TRUE.equals(getProperty(QueryConstants.PROPERTY_EXECUTE_SQL_QUERY))) {
                type = SBA_SQL_PLUGGABLE;
              }
              else {*/
                type = SBA_XML_PLUGGABLE;
              //}
            }
        }
        else {
            type = DIRECT_OLAPI_PLUGGABLE;
        }
        if (type != null)
        {
            QueryInterface qi = (QueryInterface)loadPluggable(type, QueryInterface.class.getName());
            if (qi != null)
            {
                if (m_qi == null || (m_qi != null && qi.getClass() != m_qi.getClass()))
                {
                    m_qi = qi;   
                    m_currentDataSource = (Connection)obj.getDatasource();
                    if (m_queryState != null)
                    {
                        try
                        {
                            m_queryState.setMeasureDim(getMeasureDim());
                        }
                        catch (InvalidMetadataException e)
                        {
                            throw new QueryRuntimeException(e.getMessage(), e);
                        }
                    }
                    updateDataDirectors();
                }
            }
        }
    }
    
    /**
     * @internal
     */
    public void _initCubeQuery(String[] measures, String[] items, String[][] dimensions, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
        
        // Clear out item list and dimtree
        m_queryState.setMeasures(null);
        m_queryState.setDimTree(null);
        
        m_qi.setItems(measures, items, dimensions);
        
        addToUndo(queue, userOp, before, _getQueryState());
        queue.eventHelper(new DataAvailableEvent(this, !getQueryManager().isMetadataManagerNotAvailable(), null));        
        setCurrentOperation(null);
    }

    // javadoc from interface
    public StatusInfo startExecution() throws QueryException
    {
        return getStatus(true);
    }

    // javadoc from interface
    public StatusInfo getStatus() throws QueryException
    {
        return getStatus(false);
    }
    
    protected StatusInfo getStatus(boolean startExecution) throws QueryException
    {
        StatusInfo retVal = m_qi.getStatus(startExecution);
        if (retVal == null)
            return null;
            
        if (retVal.getStatus().equals(StatusInfo.DATASOURCE_COMPLETE))
        {
            // Time to clear the queue, put the return value into status, finish the events, and return
            retVal.setReturnValue(getCurrentReturnValue());
            if (_getQueryState().getPropertySupport().getPropertyAsBoolean(QueryConstants.PROPERTY_AUTO_FIRE_EVENTS))
            {
                fireEvents();
                setCurrentOperation(null);
            }
            setCurrentReturnValue(null);
        }
        if (retVal.getStatus().equals(StatusInfo.DATASOURCE_ERROR))
        {
            Exception e = retVal.getException();
            throw new QueryException(e != null ? e.getMessage() : null, e);
        }
        return retVal;
    }

    /**
     * @internal
     */
    public BISession getSession()
    {
        if (m_queryManager != null)
            return m_queryManager.getSession();
        return null;
    }

    /**
     * @internal
     */
    protected void _refresh(BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
        Parameter[] params = {new Parameter(new Boolean(false), Boolean.class)};

        Operation oper = new Operation("refresh", params, true);
        try {
            queue.addOperation(oper);
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }
    }

    // javadoc from interface

  public synchronized void initQuery (String[][] layout, String[] dataItems, String[] items)
    throws QueryException, 
           IllegalArgumentException, MetadataManagerException {
    
    checkQueryBusy(false);
    
    if (layout != null && layout.length == 0) {
      layout = null;
    }
    
    if (dataItems != null && dataItems.length == 0) {
      dataItems = null;
    }
    
    if (items != null && items.length == 0) {
      items = null;
    }
    
    if (layout == null && (dataItems == null || items == null)) {
    
      MDObject mdObject = getMDObject (dataItems, null, items);
      if (mdObject == null) {
        throw new IllegalArgException (
          getResourceString ("dimensions and measures arguments must not both be null in initQuery"), 
            1, null);
      }
    }

    Parameter[] params = { 
      new Parameter(layout, String[][].class), new Parameter (dataItems, String[].class), 
      new Parameter(items, String[].class) 
    };
    
    try {
      queueOperation (getOpQueue(), "_initQuery", params, true, null, 
        "initQuery", params, _getQueryState(), new EventList());
    }
    
    catch (Throwable e) {
      exceptionThrower2(e);
    }
    
    finally {
      setCurrentOperation(null);
    }
  }

  // javadoc from interface
    public synchronized void initQuery(String[][] items, String[] dataItems) throws QueryException, IllegalArgumentException, MetadataManagerException
    {
        initQuery(items, dataItems, null);
    }

  /**
     * @internal
     */
  public void _initQuery (String[][] dimensions, String[] dataItems, 
    String[] items, Operation userOp, QueryState before, BaseOperationQueue queue) 
      throws QueryException, 
        IllegalArgumentException, MetadataManagerException {
    /*        
     if (dimensions == null && items == null)
        {
            setupQueryInterfaceImpl(getDataSourceObj(dataItems, null));
            dimensions = m_qi.getDefaultLayout(dataItems, items);
        }
        else
        {
    */
    
    MDObject mdObject = getMDObject (dataItems, dimensions, items);
    setupQueryInterfaceImpl (mdObject);
    
    if (items == null) {
      // Use dims as items
      items = Utility.flattenArray(dimensions);
    }
    //}
    
    _initCubeQuery(dataItems, items, dimensions, userOp, before, queue);
  }

  /**
     * If called after a Query fails to evaluate after a persistence
     * lookup, recover will return an object containing a code
     * and a list of names or IDs found to cause the failure.
     * recover will optionally attempt to modify and refresh the Query
     * to avoid the failure.
     * recover will optionally return information about dimensions that
     * caused no data conditions.
     *
     * @param fix if <code>true</code>, recover will attempt to
     * 		modify and refresh the Query to avoid the failure
     * @param nodata if <code>true</code>, recover will
     * 		determine which dimensions caused a no data
     * 		condition and return this information
     *
     * @return A <code>RecoverInformation</code> object, containing
     * 		an error code and possible metadata IDs found to have
     * 		caused a load failure.
     *
     * @throws QueryException if an error occurs
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status New
     */
    public RecoveryInfo recover(boolean fix, boolean nodata) throws QueryException, MetadataManagerException
    {
        /*Parameter[] params = {new Parameter(new Boolean(fix), Boolean.class), new Parameter(new Boolean(nodata), Boolean.class)};

        EventList el = new EventList();
        if (fix)
        {
            el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE));
        }
            
//        capturePageStatebyCursor((String[]) null);

        Operation oper = new Operation("recover", params, true);
        try
        {
            return (RecoveryInfo)getOpQueue().addOperation(oper, el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }*/
        return null;
    }

    // javadoc from interface
    // blm - Selection code moved to dvt-olap
/*    public synchronized Selection migrateToUnique(Selection sel) throws QueryException
    {
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(sel, Selection.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("migrateToUnique", params, true);
        try
        {
            return (Selection)tempQueue.addOperation(oper);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        return null;        
    }

    // javadoc from interface
    public synchronized Step migrateToUnique(Step step) throws QueryException
    {        
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(step, Step.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("migrateToUnique", params, true);
        try
        {
            return (Step)tempQueue.addOperation(oper);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        return null;        
    }

    // javadoc from interface
    public synchronized Boolean migrateToUnique() throws QueryException
    {
        // We always want to execute this immediately
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return new Boolean(false);
        }
        Operation oper = new Operation("migrateToUnique", null, true);
        try {
            return (Boolean)tempQueue.addOperation(oper);
        }
        catch (Throwable e) {
            exceptionThrower2(e);
        }
        return new Boolean(false);
    }
*/
    /**
     * Validates the entire <code>Query</code> with OLAP API.
     *
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.ValidationObject
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType) throws MetadataManagerException, QueryException
    {
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(new Integer(validationType), Integer.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("validate", params, true);
        try {
            ValidationObject vo = (ValidationObject)tempQueue.addOperation(oper);
            vo.setQuery(this);
            vo._convertTokens();
            return vo;
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        return null;
    }
*/

    /**
     * Validates the an entire edge with the OLAP API
     *
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param edge           The edge to validate. To specify an edge, use one
     *                       of the constants that end with _EDGE in
     *                       <code>oracle.dss.util.DataDirector</code>.
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.ValidationObject
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, int edge) throws MetadataManagerException, QueryException
    {
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(new Integer(validationType), Integer.class),
                              new Parameter(new Integer(edge), Integer.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("validate", params, true);
        try {
            ValidationObject vo = (ValidationObject)tempQueue.addOperation(oper);
            vo.setQuery(this);
            vo._convertTokens();
            return vo;
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        return null;
    }
    
  */  
    /**
     * Validates a Selection with the OLAP API.
     *
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param selection      The Selection to validate.
     *
     * @return <code>ValidationObject</code> indicating results of validation
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.ValidationObject
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Selection selection) throws MetadataManagerException, QueryException
    {
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(new Integer(validationType), Integer.class),
                              new Parameter(selection, Selection.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("validate", params, true);
        try {
            ValidationObject vo = (ValidationObject)tempQueue.addOperation(oper);
            vo.setQuery(this);
            vo._convertTokens();
            return vo;
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        return null;
    }
  */  
    
    /**
     * Validates a specific Step with the OLAP API.
     *
     * @param validationType OR-able constants indicating types of
     *                       validation to perform. Use the constants from the
     *                       <code>ValidationObject</code> class.
     * @param step           The Step to validate.
     *
     * @return <code>ValidationObject</code> that indicates the results of
     *         validation.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @see oracle.dss.dataSource.common.ValidationObject
     *
     * 
     */
     // blm - Selection code moved to dvt-olap
/*    public ValidationObject validate(int validationType, Step step) throws MetadataManagerException, QueryException
    {
        // We always want to execute this immediately
        Parameter[] params = {new Parameter(new Integer(validationType), Integer.class),
                              new Parameter(step, Step.class)};
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
              return null;
        }
        Operation oper = new Operation("validate", params, true);
        try {
            ValidationObject vo = (ValidationObject)tempQueue.addOperation(oper);
            vo.setQuery(this);
            vo._convertTokens();
            return vo;
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        return null;
    }
*/
    /**
     * Signals the <code>Query</code> to execute pending operations in
     * sequence.
     *
     * @throws Exception If any middle tier exception occurs.
     *
     * 
     */
    public synchronized void update() throws Exception
    {
        checkQueryBusy(true);    
        try {
            m_opQueue.update();
        }
        catch (Throwable e)
        {
            throw QueryUtil.getException(e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
    

    /**
     * Removes one or more measures from an existing query.  The dimensionality
     * of the query is updated as appropriate.
     *
     * @param measures List of measures to remove.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void removeCubeMeasures(String[] measures) throws QueryException, MetadataManagerException {
        checkQueryBusy(true);
        Parameter[] params = {new Parameter(measures, String[].class)};
        EventList el = new EventList();
        el.addElement(getSelectionChangeEvent(measures));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.SEL_CHANGE));

//        capturePageStatebyCursor(getMeasureDim());
        try {
            queueOperation(getOpQueue(), "_removeCubeMeasures", params, true, null, "removeCubeMeasures", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower(e);
        }            
        finally
        {
            setCurrentOperation(null);
        }        
    }

    /**
     * @internal
     */
    public void _removeCubeMeasures(String[] measures, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException, IllegalArgumentException, MetadataManagerException
    {        
        setCurrentOperationAndQueue(userOp, queue);
        
        BitSet edges = m_qi.removeItems(measures);
        
        addToUndo(queue, userOp, before, _getQueryState());
        if (edges == null)
        {
            queue.eventHelper(new DataAvailableEvent(this, false, null));
        }
        else
        {
            queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.SEL_CHANGE, null));                        
        }        
    }
         
    /**
     * @internal
     * Specifies a map that determines the allowable set of <code>DataMap</code>
     * values for this query for all clients of this <code>Query</code>.  The previous
     * (often default) map is replaced.
     *
     * @param map The map that contains the desired data types.
     *
     * @status New
     */
/*    public void setSupportedDataMap(DataMap map)
    {
        if (isProxySet()) {
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return;
            }
            Parameter[] params = {new Parameter(map, DataMap.class)};
            try {
                tempQueue.addOperation(new Operation("setSupportedDataMap", params, false));
            }
            catch (Throwable e)
            {
                throw new QueryRuntimeException(e.getMessage(), e);
            }
        }

         _getQueryState().getMapSupport().setSupportedDataMap(map);
    }
*/
    /**
     * Specifies a data map that determines the data to be fetched for all
     * clients and all subsequent cursors for this query. (Note: This method
     * resets cumulative <code>applyDataMap</code> operations; generally called
     * only on a clone of the <code>Query</code>.)
     * Note this method may throw a QueryRuntimeException.
     *
     * @param map The <code>DataMap</code> object that contains the desired
     *            data map types.
     *
     * 
     */
    public synchronized void setDataMap(DataMap map) {
        try
        {
            checkQueryBusy(false);
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        // Create a temporary map support object so we can check if we can avoid this call altogether beyond this point
        MapSupport tempMS = (MapSupport) _getQueryState().getMapSupport().clone();
        if (!tempMS.setDataMap(map))
        {
            return;
        }
        Parameter[] params = {new Parameter(map, DataMap.class)};
        
        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, null, map, StateChangeEvent.DATA_MAP);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        
        try {
            if (!dce.isConsumed() && !sce.isConsumed())
            {
                _getQueryState().getMapSupport().setDataMap(map);
                queueOperation(getOpQueue(), "_setDataMap", params, true, null, "setDataMap", params, _getQueryState(), el);
            }
        }
        catch (Throwable e) {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        finally
        {
            setCurrentOperation(null);
        }        
    }
    
    /**
     * @internal
     */
    public void _setDataMap(DataMap map, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        queue.eventHelper(new StateChangedEvent(this, null, _getQueryState().getMapSupport().getDataMap(), StateChangeEvent.DATA_MAP));
        BitSet edges = new BitSet(3);
        
        m_qi.setDataMap(map);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, null));                        
    }
    
    /**
     * Specifies a metadata map that determines the metadata to be fetched
     * for all clients and all subsequent cursors for this query. (Note: This
     * method resets cumulative <code>applyMetadataMap</code> operations;
     * generally called only on a clone of the <code>Query</code>.)
     *
     * @param dimension The dimension for which the metadata map will be set.
     * @param map       The <code>MetadataMap</code> object that contains the
     *                  desired metadata map types.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void setMetadataMap(String dimension, MetadataMap map) throws QueryException, MetadataManagerException
    {
        checkQueryBusy(false);
        // Create a temporary map support object so we can check if we can avoid this call altogether beyond this point
        MapSupport tempMS = (MapSupport) _getQueryState().getMapSupport().clone();
        if (!tempMS.setMetadataMap(dimension, map))
        {
            return;
        }
        Parameter[] params = {new Parameter(dimension, String.class),
                              new Parameter(map, MetadataMap.class)};

        EventList el = new EventList();
        StateChangingEvent sce = new StateChangingEvent(this, dimension, map, StateChangeEvent.METADATA_MAP);
        el.addElement(sce);
        DataChangingEvent dce = new DataChangingEvent(this, false, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        try {
            if (!dce.isConsumed() && !sce.isConsumed())
            {
                 _getQueryState().getMapSupport().setMetadataMap(dimension, map);
                queueOperation(getOpQueue(), "_setMetadataMap", params, true, null, "setMetadataMap", params, _getQueryState(), el);
            }
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }                        
    }

    /**
     * @internal
     */
    public void _setMetadataMap(String dimension, MetadataMap map, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        try
        {
            queue.eventHelper(new StateChangedEvent(this, dimension, _getQueryState().getMapSupport().getMetadataMap(dimension, isTimeDimension(dimension)), StateChangeEvent.METADATA_MAP));
        }
        catch (MetadataManagerException e)
        {
            exceptionThrower2(e);
        }
        // Determine list of edges based on dimension that's changing, if any
        BitSet edges = new BitSet(3);
        if (dimension == null) {
            edges.set(DataDirector.ROW_EDGE);
            edges.set(DataDirector.COLUMN_EDGE);
            edges.set(DataDirector.PAGE_EDGE);
        }
        else {
            QueryUtil.setDirtyEdgeBit(_getQueryState().getDimTree(), edges, dimension, false);
        }   
        
        m_qi.setMetadataMap(dimension, map);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE, null));                        
    }
    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object.
     *
     * @param rebuild       <code>true</code>, refreshes the structural elements
     *                      of the query such as calculations;
     *                      <code>false</code> performs a minimal refresh.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void refresh(boolean rebuild) throws QueryException, MetadataManagerException
    {
        refresh(rebuild ? QueryConstants.REFRESH_REBUILD : QueryConstants.REFRESH_ALL);
    }    
    
    /**
     * Refreshes all cursors and/or structures of this <code>Query</code> object, as with <code>refresh(true)</code>,
     * although this method also reloads saved selections.
     *
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * @status New
     */
    public synchronized void refreshAll() throws QueryException, MetadataManagerException
    {
        refresh(QueryConstants.REFRESH_ALL);
    }
    
    protected void setupQueryInterfaceImpl() throws InvalidMetadataException, MetadataManagerException
    {
        setupQueryInterfaceImpl(getDataSourceObj(getDataItems(), getLayout()));
    }
    
    // javadoc from interface
    public void refresh(int type) throws QueryException
    {
        checkQueryBusy(false);
    
        Parameter[] params = {new Parameter(new Integer(type), Integer.class)};
        EventList el = new EventList();
        DataChangingEvent dce = new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE);
        el.addElement(dce);
//        capturePageStatebyCursor((String[])null);
        
        try
        {
                queueOperation(getOpQueue(), "_refresh", params, true, null, "refresh", params, _getQueryState(), el);
        }
        catch (Throwable e)
        {
            exceptionThrower2(e);
        }
        finally
        {
            setCurrentOperation(null);
        }                        
    }
    
    /**
     * @internal
     */
    public void _refresh(int type, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        try
        {
            setupQueryInterfaceImpl();
        }
        catch (Exception e)
        {
            throw new QueryException(e.getMessage(), e);
        }
        setCurrentOperationAndQueue(userOp, queue);
        
        if (type == QueryConstants.REFRESH_REBUILD || type == QueryConstants.REFRESH_ALL)
        {
            // Throw out client side cache
            m_mdObjectCache.clear();                        
        }
        BitSet edges = new BitSet(3);
        edges.set(DataDirector.ROW_EDGE);
        edges.set(DataDirector.COLUMN_EDGE);
        edges.set(DataDirector.PAGE_EDGE);
        
        m_qi.refresh(type);
        
        queue.eventHelper(new DataChangedEvent(this, true, edges, oracle.dss.util.DataChangedEvent.DRILL_CHANGE, null));                        
    }
    
    /**
     * Restores the <code>Query</code> to a previous state in this session.
     *
     * @param state A state marker (also known as a token or a cookie) that was
     *              retrieved previously from <code>getQueryState</code>.
     * @throws QueryException           If there is a problem fetching data
     *                                  after this operation.
     * @throws MetadataManagerException If an error occurred using the
     *                                  MetadataManager bean.
     *
     * 
     */
    public synchronized void setQueryState(QueryState state) throws QueryException, MetadataManagerException {
        checkQueryBusy(false);
        
        Parameter[] params = {new Parameter(state, QueryState.class)};
        EventList el = new EventList();
        el.addElement(new StateChangingEvent(this, StateChangeEvent.STATE));
        el.addElement(new DataChangingEvent(this, true, oracle.dss.util.DataChangedEvent.UNKNOWN_CHANGE));
        try {
                queueOperation(getOpQueue(), "_setQueryState", params, true, null, "setQueryState", params, _getQueryState(), el);
        }
        catch (Throwable e) {
            exceptionThrower(e);
        }
        finally
        {
            setCurrentOperation(null);
        }                                
    }

    /**
     * @internal
     */
    public void _setQueryState(QueryState state, Operation userOp, QueryState before, BaseOperationQueue queue) throws QueryException
    {
        setCurrentOperationAndQueue(userOp, queue);
        
        m_queryState = (QueryState)state.clone(this);
        
        m_qi.loadQuery();
        
        eventHelper(new StateChangedEvent(this, null, before, StateChangeEvent.STATE));
        eventHelper(new DataChangedEvent(this, oracle.dss.util.DataChangedEvent.SETSTATE_CHANGE, null));        
    }
    
    /**
     * Retrieves a state marker (also known as a token or cookie) that
     * represents the current <code>Query</code> state. Later, in the
     * same session, this state marker can be used as the parameter for
     * <code>setQueryState</code> to restore the state of this
     * <code>Query</code>.
     *
     * @return The state marker (token or cookie) that represents the current
     *         state of this <code>Query</code>.
     *
     * @throws CloneException If the state can not be duplicated.
     *
     * 
     */
    public synchronized QueryState getQueryState() throws CloneException {
/*        if (!isDesignTime() && isProxySet()) {
            QueryState state = getQueryManagerProxy().getQueryState(getID());
            QueryState newState = (QueryState)state.clone(this);
            return newState;
        }*/
            return (QueryState)_getQueryState().clone(this);
    }

    /**
     * Adds a Swing-compatible undo listener to the Query.
     *
     * @param l Listener to add.
     *
     * 
     */
    public void addUndoableEditListener(UndoableEditListener l)
    {
        ((ClientListenerLists)m_listeners).addUndoableEditListener(l);
    }

    /**
     * Removes a Swing-compatible undo listener from the Query
     *
     * @param l Listener to removex
     *
     * 
     */
    public void removeUndoableEditListener(UndoableEditListener l)
    {
        ((ClientListenerLists)m_listeners).removeUndoableEditListener(l);
    }
    
    /**
     * Closes any open <code>Query</code> middle tier references for
     * proper clean up.
     *
     * 
     */
    public synchronized void close() {
        super.close();
        
        try
        {
            m_qi.release();        
        }
        catch (QueryException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }
        _getQueryManager().removeQuery(this);        
    }

    /**
     * @internal
     * Sync up middle tier and server state
     */
    protected void syncQuery() throws CloneNotSupportedException
    {
        m_persistentStateSet = true;
        m_needsPropSync = true;
        //syncMapProp();
    }



    /**
     * @internal
     * Method to replace a selection without reevaluating
     */
     // blm - Selection code moved to dvt-olap
/*    public void replSel(String dimension, Selection sel) throws Exception
    {
        // We always want to execute this immediately: informational
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
            return;
        }
        Selection retVal = null;
        try {
            retVal = (Selection)tempQueue.addOperation(new Operation("replSel", new Parameter[] {new Parameter(dimension, String.class), new Parameter(sel, Selection.class)}, false));
        }
        catch (IllegalArgumentException iae) {
            throw iae;
        }
        catch (Throwable e)
        {
            if (e instanceof Exception)
            {
                throw (Exception)e;
            }
        }
    }
*/
            
     //WritebackWorker interface implementations

     /**
     * Sends the writeback changes in the QDRoverride collection to update the
     * database server.
     * Note: This method must complete successfully before the
     * <code>commit</code> method can be called to update the actual database.
     *
     * @param qdrCollection Contains a QDR override for each cell that was
     *                      edited.
     *
     * @throws QueryException If any error occurs during the operation.
     *
     * @see #commit
     *
     * 
     */

    //take a QDRoverride Collection, write it back to the database
/*    public boolean submit(java.util.List qdrCollection) throws QueryException
    {
        if (qdrCollection == null) {
            throw new IllegalArgException(getResourceString("qdrCollection argument must not be null in submit"), 1, null);
        }
        Parameter[] params = {new Parameter(qdrCollection, java.util.List.class)};

        EventList el = new EventList();

       // We always want to execute this immediately
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
            return false;
        }
        Operation oper = new Operation("submit", params, true);
        boolean retVal = true;
        try {
            Boolean returnval = (Boolean)tempQueue.addOperation(oper, el);
            if (returnval != null)
            {
                retVal = returnval.booleanValue();
            }
        }
        catch (Throwable e) {

            if (e instanceof QueryException)
                throw (QueryException)e;
            else
                throw new QueryException(e.getMessage(), e);
        }


        return retVal;
   }*/

   /**
     * Updates the actual database with changes that have been posted to the
     * database server by the <code>submit</code> method.
     * Note: If a database is open in read-only mode, then the
     * <code>commit</code> method will not succeed.
     *
     * @throws QueryException If any error occurs during the operation.
     *
     * @see #submit
     *
     * 
     */
/*   public boolean commit() throws QueryException
   {
        Parameter[] params = {};

        EventList el = new EventList();

        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
            return false;
        }
        Operation oper = new Operation("commit", params, false);
        try {
            tempQueue.addOperation(oper, el);
        }
        catch (Throwable e) {
            if (e instanceof QueryException)
                throw (QueryException)e;
            else
                throw new QueryException(e.getMessage(), e);
        }

        return true;
   }*/

    /**
     * @internal
     *
     * roolback all the changes made to the database.
     * this method may not available ( depends on the support of database)
     * in term of express, when the connection is closed, all the changes are discarded
     * automatically if not committed. other than this, express does not seem to provide
     * a way to roolback the changes.
    */
/*   public boolean rollBackChanges()
   {
        // Not implemented yet!
        return false;
   }

  public void setAutoSubmit( boolean bValue)
  {
        if (!isDesignTime() && isProxySet())
        {
            super.setAutoSubmit(bValue);
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return;
            }
            Parameter[] params = {new Parameter(new Boolean(bValue), Boolean.class)};
            try {
                tempQueue.addOperation(new Operation("setAutoSubmit", params, true));
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }   
    }
    */
    /**
     * Controls whether operations should be sent to the middle tier for
     * immediate processing or accumulated in a pending operations queue.
     * Warning: Certain error checking or results in events that are fired  
     * before an operation executes may be different or inaccurate when 
     * auto update is false.
     *
     * @param b <code>true</code> sends each operation for immediate processing;
     *          <code>false</code> lets operations accumulate in a pending
     *          operations queue.
     *
     * @throws Any of the exceptions that are contained in the operations
     *         that are currently in the queue.
     *
     * 
     */
    public synchronized void setAutoUpdate(boolean b) throws Exception
    {
        if (b)
            checkQueryBusy(true);
        super.setAutoUpdate(b);
        
        try {
            // Change operation queue status
            m_opQueue.setAutoUpdate(b);
        }
        catch (Throwable e) {
            throw QueryUtil.getException(e);
        }
        finally
        {
            if (b)
                setCurrentOperation(null);
        }
    }

    /**
     * Specifies the default number of dimensions to put on a column for
     * default layouts.
     *
     * @param numCol The number of dimensions to put on the column for default
     *               layouts.
     *
     * 
     */
    public void setDefaultColumnCount(int numCol)
    {
        super.setDefaultColumnCount(numCol);
    }

    /**
     * Specifies the default number of dimensions to put on a row for default
     * layouts.
     *
     * @param numRow The number of dimensions to put on the row for default
     *               layouts.
     *
     * 
     */
    public void setDefaultRowCount(int numRow)
    {
        super.setDefaultRowCount(numRow);
    }

   /**
     * @internal
     * Indicates whether OLAP Services SQL should be dumped out with each Query update
     *
     * @param type Value greater than zero indicates that printouts should be produced using
     *             the given OLAP Services getGenerationInfo type.
     */
    public void setSQLDump(long type) {
        super.setSQLDump(type);
    }
/*    public void setWritebackValidator(String SPLPrgName)
    {
        if (isProxySet())
        {
            super.setWritebackValidator(SPLPrgName);
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                  return;
            }
            Parameter[] params = {new Parameter(new String(SPLPrgName), String.class)};
            try {
                tempQueue.addOperation(new Operation("setWritebackValidator", params, true));
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }   
    }*/
    /**
     * Indicates whether hierarchical drilling should be used exclusively f
     *
     * @param hierDrill <code>true</code> to always use hierarchical drilling
     */
    public void setHierarchicalDrilling(boolean hierDrill)
    {
        super.setHierarchicalDrilling(hierDrill);
    }    

   /**
     * Indicates whether query state printouts should be produced on every 
     * query operation.
     *
     * @param mode <code>true</code> produces state printouts on
     *             server;
     *             <code>false</code> does not produce state printouts.
     *             
     *             
     */
/*    public void setPrintQueryState(boolean mode) {
        super.setPrintQueryState(mode);
        if (!isDesignTime() && isProxySet()) {
            getQueryManagerProxy().setPrintQueryStateQuery(getID(), mode);
        }
    }*/


    /**
     * Indicates whether asymmetric drilling should be used
     *
     * @param asymmetric <code>true</code> to use asymmetric drilling
     */
    public void setAsymmetricDrilling(boolean asymmetric)
    {
        super.setAsymmetricDrilling(asymmetric);
    }

    /**
     * Indicates whether pages are fetched as separate cursors
     *
     * @param separate code>true</code> to separate page cursors from the 
     * data cursor
     * 
     * 
     */
    public void setSeparatePage(boolean separate)
    {
        super.setSeparatePage(separate);
    }

    /**
     * @internal
     * Set whether or not to filter children when drilling down.
     * 
     * @param all		If <code>true</code>, drill children may be 
     * filtered by the query.  If 
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * The default value is <code>true</code>.
     * 
     * @status New
     */
    public void setDrillWithFilteredChildren(boolean filter)
    {
        super.setDrillWithFilteredChildren(filter);
    }

    /**
     * Sets fetch buffer size
     *
     * @param size Integer that indicates the number of values to fetch per
     *             buffer read for cursors.  -1 turns partial fetching off
     *             and fetches the entire cursor.
     *
     * 
     */
    public void setFetchSize(int size)
    {
        super.setFetchSize(size);
    }

    /**
     * Sets whether entire page edges are fetched.  Default is <code>true</code>.
     *
     * @param fullfetch if <code>true</code>, the page edge is fully fetched.  If not, partial fetching applies.
     */
    public void setFetchPageEdge(boolean fullfetch)
    {
        super.setFetchPageEdge(fullfetch);
    }

    /**
     * Specifies the suppression (none, NA, zero, or both NA and zero) for an
     * edge of this <code>Query</code> when data is fetched.
     *
     * @param index    A constant that represents the edge of interest.
     *                 Valid edge constants are found
     *                 in <code>oracle.dss.util.DataDirector</code>.
     * @param suppress Identifies the kind of suppression.
     *                 Valid suppression constants are
     *                 found in <code>oracle.dss.util.DataDirector</code>.
     *
     * @throws ArrayIndexOutOfBoundsException If <code>index</code> is invalid.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * 
     */
    public void setSuppressionState(int index, int suppress) throws ArrayIndexOutOfBoundsException {
        super.setSuppressionState(index, suppress);
    }
    
    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero)
     * to use for this <code>Query</code> when data is fetched.
     *
     * @param suppress An array that identifies the kind of suppression for
     *                 each edge in a Query. The edge constants in
     *                 <code>oracle.dss.util.DataDirector</code> provide an
     *                 index into the array to identify column, row, or page
     *                 edge.
     *                 Valid suppression constants are
     *                 found in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#COLUMN_EDGE
     * @see oracle.dss.util.DataDirector#PAGE_EDGE
     * @see oracle.dss.util.DataDirector#ROW_EDGE
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * 
     */
    public void setSuppressionState(int[] suppress)
    {
        super.setSuppressionState(suppress);

    }

    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero) on
     * the column edge of the query when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid suppression constants are
     *                 found in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * 
     */
    public void setSuppressColumns(int suppress) {
        super.setSuppressColumns(suppress);
    }


    /**
     * Specifies the suppression state (none, NA, zero, or both NA and zero) on
     * the row edge of a query when data is fetched.
     *
     * @param suppress Identifies the kind of suppression.
     *                 Valid suppression constants are
     *                 found in <code>oracle.dss.util.DataDirector</code>.
     *
     * @see oracle.dss.util.DataDirector#NO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_SUPPRESSION
     * @see oracle.dss.util.DataDirector#ZERO_SUPPRESSION
     * @see oracle.dss.util.DataDirector#NA_ZERO_SUPPRESSION
     *
     * 
     */
    public void setSuppressRows(int suppress) {
        super.setSuppressRows(suppress);
    }

    /**
     * @internal
     */
    public void setProperties(Hashtable properties)
    {
        super.setProperties(properties);
    }

   public void setProperty(String property, Object value) throws Exception
   {
        super.setProperty(property, value);
        
        // Let interface handle any special updates, etc.
        m_qi.setProperty(property, value);
   }

   /**
    * Specifies whether page changes are transmitted among listeners.
    * By default, if there are multiple listeners of any kind on a
    * <code>Query</code>, then a change to the page edge of the query by
    * one listener will be transmitted to the cursors of all the other
    * listeners. (Each listener has its own copy of the cursor on the
    * client side.)
    *
    * @param b <code>true</code> indicates that page changes should be shared
    *          among all listeners;
    *          <code>false</code> indicates that a page change by one listener
    *          will not be shared among the other listeners.
    *
    * 
    */
   public void setSharePage(boolean b)
   {
        super.setSharePage(b);
   }

   /**
    * Specifies the current page if pages are shared among listeners.
    *
    * @param page    Page number to share among listeners.
    * @param qdrPage QDR version of the current page.
    *
    * 
    */
   public void setCurrentPage(int page, QDR qdrPage)
   {
        super.setCurrentPage(page, qdrPage);
   }

   /**
    * Returns the current page number if shared among listeners
    * Note this method may throw a QueryRuntimeException.
    *
    * @return Page number that is shared among listeners
    *
    * 
    */
   public int getCurrentPage()
   {
/*        try
        {
            // Cube cursor relies on this: must be synced in case we're in an update mode from setting state
            syncMapProp();
        }
        catch (CloneNotSupportedException e)
        {
            throw new QueryRuntimeException(e.getMessage(), e);
        }*/
        return (int)_getQueryState().getPropertySupport().getCurrentPage();
   }

    
    /**
     * @internal
     */
    protected boolean isDataAvailable() {
        if (getMetadataManager() == null)
        {
            return false;
        }
        return m_qi.isDataAvailable();
    }

    /**
     * @internal
     */
/*   protected boolean createDefaultAndNotify(DataDirectorListener l, QueryDataDirector d) throws MetadataManagerException, QueryException
   {
        if (!isDesignTime())
        {
            return super.createDefaultAndNotify(l, d);
        }
        return false;
   }*/

    /********** Persistable interface ********************/
    
    /**
     * @internal
     */
    public void initialize(Hashtable env)
    {
/*        setPersistableEnvironment(env);
        if (env != null)
        {
            // Look for QueryManagers
            QueryManager qmc = (QueryManager)env.get(QUERY_MANAGER);
            if (qmc != null)
            {
                try
                {
                    // Found: set it 
                    _setQueryManager(qmc, false, true);
                }
                catch (Throwable e)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
            if (env.containsKey(PersistableConstants.PERSISTENCE_ERRORHANDLER))
            {
                _getQueryManager().addErrorHandler((ErrorHandler)(env.get(PersistableConstants.PERSISTENCE_ERRORHANDLER)));
            }
            if (env.containsKey(PersistableConstants.PERSISTENCE_LOCALE))
            {
                _getQueryManager().setLocale((Locale)(env.get(PersistableConstants.PERSISTENCE_LOCALE)));
            }
            if (env.containsKey(Query.NO_EVALUATE_ON_LOAD))
            {
                Boolean val = (Boolean)env.get(Query.NO_EVALUATE_ON_LOAD);
                if (val.booleanValue())
                {
                    try
                    {
                        m_noEvalOnReload = true;
                        super.setEvaluateCursor(false);
                    }
                    catch (Exception e)
                    {
                        throw new QueryRuntimeException(e.getMessage(), e);
                    }
                }
            }
        }*/
    }

   /**
    * @internal
    */
    public void setXML(XMLContext context, Object node)
    {
      super.setXML(context, node);
      ObjectNode root = (ObjectNode)node;

      String version = PRE_STAMP_VERSION;
      try
      {
        version = root.getPropertyValueAsString("Version");
        // Check if matches: should match the only version we've ever put out so far
        /*if (version != null && !version.equals(getVersion()))
        {
            getErrorHandler().log("XML version mismatch: " + version + " found.  Expected " + getVersion(), getClass().getName(), "setXML");
        }*/
      }
      catch (NoSuchPropertyException e)
      {
        // Ignore: leave set as pre stamp version
      }

/*      try {
        m_bDataWanted = root.getPropertyValueAsBoolean("DataWanted");
      }

      catch (NoSuchPropertyException e) {
        throw new QueryRuntimeException(
          _getQueryManager().getResourceString("Could not find property"), e);
      }*/

      QueryState state = null;
      try
      {
            state = new QueryState(this, getMeasureDim());
      }
      catch (InvalidMetadataException ime)
      {
          throw new QueryRuntimeException(ime.getMessage(), ime);
      }
      state.setXML(context, root.getPropertyValueAsObjectNode(PersistableConstants.XMLNS + ":QueryState", true));
      m_queryState = state;

//      setMeasureList(state.getMeasures());
      //setDimensionTree(state.getDimTree());
      ObjectNode properties = root.getPropertyValueAsObjectNode(PersistableConstants.XMLNS + ":Properties", true);
      if(properties != null)
        _getQueryState().getPropertySupport().setXML(context, properties);
      MapSupport tempSupport = (MapSupport)_getQueryState().getMapSupport().clone();
      ObjectNode maps = root.getPropertyValueAsObjectNode(PersistableConstants.XMLNS + ":Maps", true);
      if(maps != null)
        _getQueryState().getMapSupport().setXML(context, maps);
      
/*        try
        {
            ContainerNode layerMetadataContainer = root.getContainer(XML_SETLAYERMETADATA);
            if (layerMetadataContainer != null)
            {
                Enumeration entries = layerMetadataContainer.getContainedObject();
                while (entries.hasMoreElements())
                {
                    ObjectNode on = (ObjectNode)entries.nextElement();
                    if (on != null)
                    {   
                        String key = on.getPropertyValueAsString(XML_SETLAYERMETADATA_KEY);
                        Object data = Utility.PropertyType.retrieveData(on, XML_SETLAYERMETADATA_VALUE, XML_SETLAYERMETADATA_TYPE);
                        m_layerMetadata.put(key, data);
                    }
                }
            }
        }
        catch (NoSuchPropertyException e)
        {            
        }*/
      
      m_persistentStateSet = true;
    }
    


    /**
     * @internal
     */
    public String getTagName()
    {
        return XMLName;
    }
    

   /**
    * @internal
    */
/*   public void makeAnonymous()
   {
        if (!isDesignTime() && isProxySet()) {
            // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return;
            }
            try
            {
                tempQueue.addOperation(new Operation("makeAnonymous", null, true));
            }
            catch (Throwable e)
            {
                if (e instanceof Exception)
                {
                    throw new QueryRuntimeException(e.getMessage(), e);
                }
            }
        }
   }
*/
   /**
    * Return the current state in XML of the query.  This does not include
    * persistable components such as selections or calculations.
    *
    * @return String containing the Query's XML, if available.
    * @throws Exception thrown in case of an error
    * @status New
    */
   public String getXMLString() throws Exception
   {
        return getXMLAsString();
   }

   /**
    * @internal
    */
    public Object getXML(XMLContext retCons)
    {
      ObjectNode root = (ObjectNode)super.getXML(retCons);
      root.addProperty("Version", m_version);

      /** gek 11/03/06
      try
      {
          if (!areWeMigrating())
          {
            Vector results = QueryUtil.walkPersistableStructuresMemberLevels(_getQueryState(), getQueryManager());
            if (results != null)
            {
                  getErrorHandler().log("MEMBER LEVEL NOT SET: " + Selection.condenseMessages(results), getClass().getName(), "getXML");
            }
            root.addProperty("AreMemberLevelPropertiesSet", results == null);
          }
      }
      catch (Exception e)
      {
          throw new QueryRuntimeException(e.getMessage(), e);
      }
      */
      
      // Current state
      // Don't save selections with current state
      QueryState state = null;
        // Note: The state so that we can update its measures
        state = _getQueryState();

      state.setSelectionsInXML(false);
    
      //state.setMeasures(updateMeasures(state.getMeasures(), MEASURE_RUNTIME_TO_AGG));     No need to "fix up" anymore

      root.addProperty((ObjectNode)state.getXML(retCons));
      state.setSelectionsInXML(true);

      // Property values
      if(_getQueryState().getPropertySupport().isDefaultChanged())
        root.addProperty((ObjectNode)_getQueryState().getPropertySupport().getXML(retCons));

      // Map support
      if(_getQueryState().getMapSupport().isDefaultChanged())
        root.addProperty((ObjectNode)_getQueryState().getMapSupport().getXML(retCons));

      // Save setlayermetadata table
/*      if (m_layerMetadata.size() > 0)
      {
            ContainerNode propContainer = new ContainerNode(XML_SETLAYERMETADATA);
            Enumeration props = m_layerMetadata.keys();
            while (props.hasMoreElements())
            {
                String key = (String)props.nextElement();
                Object value = m_layerMetadata.get(key);
                propContainer.addContainedObject(getLayerMetadataXML(key, value));
            }
            root.addContainer(propContainer);
      }*/
      
      return root;
    }        

    //private static final String XML_SETLAYERMETADATA = "SetLayerMetadata";
    //private static final String XML_SETLAYERMETADATA_ENTRY = "SLMEntry";
    //private static final String XML_SETLAYERMETADATA_KEY = "SLMKey";
    //private static final String XML_SETLAYERMETADATA_TYPE = "SLMType";
    //private static final String XML_SETLAYERMETADATA_VALUE = "SLMValue";    
    
/*    private ObjectNode getLayerMetadataXML(String key, Object value)
    {
        String type = Utility.PropertyType.getType(value);
        if (type != null)
        {
            ObjectNode node = new ObjectNode(XML_SETLAYERMETADATA_ENTRY);
            node.addProperty(XML_SETLAYERMETADATA_KEY, key);
            Utility.PropertyType.storeData(node, value, XML_SETLAYERMETADATA_VALUE, XML_SETLAYERMETADATA_TYPE);
            return node;
        }
        return null;
    }
    
    private String getLayerMetadataKey(String itemID, String type)
    {
        return itemID + "," + type;        
    }    */

    /**
     * @internal
     * Store overridden layer metadata info
     */
/*    protected synchronized void setLayerMetadata(String itemID, String type, Object data) throws Exception
    {
        if (data == null)
            m_layerMetadata.remove(getLayerMetadataKey(itemID, type));
        else
            m_layerMetadata.put(getLayerMetadataKey(itemID, type), data);
            
        // Fire data changed
        m_listeners.fireDataChangedEvent(new DataChangedEvent(this, oracle.dss.util.DataChangedEvent.LAYER_METADATA_CHANGE, null));
    }*/
    
    /**
     * @internal
     * Retrieve overridden layer metadata info
     */
/*    protected Object getLayerMetadata(String itemID, String type) 
    {
        return m_layerMetadata.get(getLayerMetadataKey(itemID, type));        
    }*/
        
    /**
     * @internal
     *
     * Retrieves an array of <code>AggregateInfo</code> values based on position.
     *
     * @param  nPosition a <code>int</code> value that is represents the
     *         aggregate position to retrieve data from.
     *
     * @return  A <code>AggregateInfo[]</code> array associated with the specified
     *          position.
     * @status protected
     */

    protected AggregateInfo[] _getPersistableComponents(int nPosition) throws MetadataManagerException, InvalidMetadataException, CloneNotSupportedException
    {
        // Initialize the AggregateInfo count
        int nCount = 0;

        // Determine size of aggregate list based on the number of selections
        // blm - Selection code moved to dvt-olap
/*        AggregateInfo[] aggregateInfo = new AggregateInfo[_getQueryState().getSelections().size()];

        // Aggregate each selection
        Iterator iter = _getQueryState().getSelections().iterator();
        while (iter.hasNext()) {

          Selection selection = null;

          selection = (Selection) iter.next();

          // Store the selection at the specified position
          aggregateInfo[nCount] = new AggregateInfo((Persistable)selection, nPosition);

          // Increment the AggregateInfo count
          nCount++;
        }

      // Return the AggregateInfo array
      return aggregateInfo;*/
        return null;
    }

    /**
     * @internal
     */
    public AggregateInfo[] getPersistableComponents()
    {
        try
        {
            AggregateInfo[] aggregateInfos = _getPersistableComponents(0);
            //clear(m_aggregatedMeasures);
            return aggregateInfos;
        }
        catch (Exception e)
        {
            //clear(m_aggregatedMeasures);
            throw new QueryRuntimeException(e.getMessage(), e);
        }
    }
    
    /**
     * @internal
     *
     *  Loads persisted aggregate components such as selections and calculations.
     *
     */
    public void setPersistableComponents (AggregateInfo[] aggregates) {
      // If no aggregates have been specified, simply return
      if ( m_queryManager == null) {
        return;
      }

      // blm - Selection code moved to dvt-olap
/*    if (aggregates != null)
    {
      // Initialize the list of selections
      SelectionList selections = new SelectionList();

      Vector tempSels = new Vector();

     boolean oldAggregates = false;
     
      // Load each aggregated object
      for (int i = 0; i < aggregates.length; i++) {
        Persistable persistable = aggregates[i].getPersistable();

        // Process selections
        if (persistable instanceof Selection) {

          // Update the integer list of levels from names, if available
          ((Selection)persistable).generateLevelDepths(this);
          
          tempSels.addElement(persistable);
        }
        else {
          // Process calculations
          oldAggregates = true;
          //_loadCalcStep (aggregates[i]);
        }
      }


      Enumeration sels = tempSels.elements();
      while (sels.hasMoreElements()) {
            Persistable persistable = (Persistable) sels.nextElement();

            // Add this to the list of selections
            selections.add(persistable);
      }
      
      _getQueryState().setSelections(selections);
    }
*/
        try
        {
            setCurrentQueue(getOpQueue());
            QueryState state = _getQueryState();
            setupQueryInterfaceImpl(getDataSourceObj(state.getMeasures(), Node.getStringArray(state.getDimTree().getDimTree())));
            m_qi.loadQuery();
            getOpQueue().eventHelper(new DataAvailableEvent(this, true, null));        
        }
        catch (Throwable e)
        {
            // Throw this out as a persistence exception
            if (e instanceof Exception)
            {
                e.printStackTrace();
                throw new QueryRuntimeException(e.getMessage(), (Exception)e);
            }
            else
            {
                throw new QueryRuntimeException(e.getMessage(), null);
            }
        }    
    }    
    
    /**
     * @internal
     * Indicates that the parent QueryManager's Database property has been set
     */
/*    public void _databaseSet(boolean available) throws Throwable
    {
        if (available)
        {
            m_mdObjectCache = new Hashtable();
        }
        if (m_persistentStateSet && available)
        {
            syncQuery();
            m_persistentStateSet = false;
            if (m_noEvalOnReload)
            {
//                m_noEvalOnReload = false;
                setEvaluateCursor(false);
            }
            // We always want to execute this immediately
            // If we've held operations pending a proxy, and auto update has not been set by the user, then
            // put the restart on the front of the main queue and use it.  Otherwise, use a temp queue
            // Suspend the default query processing in case of error
            setDefaultQuery(false);
            Operation op = new Operation("_restartFromPersistence", null, true);
            if (getOpQueue().areOpsHeldForProxy() && getOpQueue().isAutoUpdate())
            {
                getOpQueue().insertOperation(op, 0);
            }
            else
            {
                OperationQueue tempQueue = generateTempOpQueue();
                if (tempQueue == null)
                {
                    return;
                }
                tempQueue.addOperation(op);
            }
        }
    }*/

    /**
     * Returns the current MetadataManager that is set on the QueryManager for
     * this Query.
     *
     * @return The MetadataManager.
     *
     * 
     */
    public MetadataManagerServices getMetadataManager()
    {
        return _getQueryManager() != null && _getQueryManager().getMetadataManager() != null ? _getQueryManager().getMetadataManager() : null;
    }
    

    /**
     * @internal
     */
/*    public MDDimension[] dimensionalityOfMeasures(MDMeasure[] measures, String type) throws InvalidMeasureException
    {
        try
        {        
            return getMM().dimensionalityOfMeasures(measures, type);
        }
        catch (MetadataManagerException mme)
        {
            throw new InvalidMeasureException(MessageFormat.format(getResourceString("Invalid measure specified"), new String[] {measures[0].getUniqueID()}), new String[] {measures[0].getUniqueID()}, mme);
        }
    }*/



   /**
     * @internal
     * Is this a ROLAP connection?
     */
/*    public boolean isROLAP()
    {
        MetadataManager mm = (MetadataManager)_getQueryManager().getMetadataManager();
        Connection conn = (Connection)_getQueryManager().getConnection();
        if (mm == null || conn == null)
        {
            return false;
        }
        String server = conn.getServerType();
        if (server != null && server.equals(OLAPSERVER))
        {
            return true;
        }
        return false;
    }
*/
    // Are we in design time
    /**
     * @internal
     */
/*    protected boolean isDesignTime()
    {
        //return Beans.isDesignTime();
        return false;
    }*/
    

    private OperationQueue getOpQueue()
    {
        return (OperationQueue)m_opQueue;
    }
    
    private OperationQueue generateTempOpQueue()
    {
        // Query must be closed here if this is null
        if (getOpQueue() != null)
        {
            return new OperationQueue(true, getQueryManager(), this, m_listeners);
        }
        return null;            
    }
    
    /**
     * @internal
     *
     * Determines whether the specified dimensions represents a time dimension.
     *
     * @param vTimeDimensions a <code>Vector</code> value that represents the
     *        time dimensions to search.
     * @param strDimension a <code>String</code> that represents the time
     *        dimension to search for.
     *
     * @return <code>boolean</code> which is <code>true</code> when the dimension
     *         represents a time dimension and <code>false</code> otherwise.
     */
/*    protected boolean isTimeDimension (Vector vTimeDimensions, String strDimension) {
      // Check for null values
      if (vTimeDimensions == null || strDimension == null)
        return false;

      String strTimeDimension = null;

      // Enumerate over all of the time dimensions
      Enumeration enumeration = vTimeDimensions.elements() ;
      while (enumeration.hasMoreElements()) {
        strTimeDimension = (String)enumeration.nextElement();

        // If the dimension represents a time dimension, simply return true
        if (strTimeDimension.equals (strDimension))
          return true;
      }

      // The dimension is not a time dimension
      return false;
    }
    
    // Determine if the query manager proxy is set
    private boolean isProxySet()
    {
        return false;
    }*/


	/*****************************************
   * Implementation of interfaces:         *
   * oracle.dss.thin.beans.ThinBeanState   *
   * oracle.dss.thin.beans.ThinBean        *
   * oracle.dss.thin.beans.CheckpointState *
   *****************************************/

/*	public void setBaseState() {
    try {
      establishBaseState();
    }
    catch (ThinException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }
  }
  
  public void establishBaseState() throws ThinException {
    if (!isDesignTime() && isProxySet()) {
      // Always execute immediately
        OperationQueue tempQueue = generateTempOpQueue();
        if (tempQueue == null)
        {
            return;
        }
      try {
        tempQueue.addOperation(new Operation("setBaseState", null, true));                
      }
      catch (Throwable e) {
        throw new ThinException(e.getMessage(), e);
      }
    }
  }

  public void setState(String state) {
    try {
      setStateString(state);
    }
    catch (ThinException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }
  }

  public void setStateString(String state) throws ThinException {
    if (!isDesignTime() && isProxySet()) {
      // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return;
            }
      Parameter[] params = {new Parameter(state, String.class)};
			try {
        m_needsPropSync = true;
        tempQueue.addOperation(new Operation("setState", params, false));
        //syncMapProp();
      }
      catch (Throwable e) {
        throw new ThinException(e.getMessage(), e);
      }
    }
	}

	public String getState() {
    String state = null;
    try {
      state = getStateString();
    }
    catch (ThinException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }
    return state;
  }

  public String getStateString() throws ThinException {
    String state = null;        
		if (!isDesignTime() && isProxySet()) {
      // We always want to execute this immediately: informational
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return null;
            }
      try {
        state = (String)tempQueue.addOperation(new Operation("getState", null, false));
      }
      catch (IllegalArgumentException iae) {
        throw iae;
      }
      catch (Throwable e) {
        throw new ThinException(e.getMessage(), e);
      }
    }      
		return state;
	}

  public void checkpointState() {
    try {
      establishCheckpointState();
    }
    catch (ThinException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }
  }

  public void establishCheckpointState() throws ThinException {
    if (!isDesignTime() && isProxySet()) {
      // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return;
            }
      try {
        tempQueue.addOperation(new Operation("checkpointState", null, true));
      }
      catch (Throwable e) {
        throw new ThinException(e.getMessage(), e);
      }
    }
  }
  
  public void setCheckpointState(String state) throws ThinException {
    setCheckpointStateString(state);
  }

  public void setCheckpointStateString(String state) throws ThinException {
    if (!isDesignTime() && isProxySet()) {
      // Always execute immediately
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return;
            }
      Parameter[] params = {new Parameter(state, String.class)}; 			
			try {
        tempQueue.addOperation(new Operation("setCheckpointState", params, false));
      }
      catch (Throwable e) {
        // Unknown
        throw new ThinException(e.getMessage(), e);
      }        
    }
  }
  
  public String getCheckpointState() {
    String state = null;
    try {
      state = getCheckpointStateString();
    }
    catch (ThinException e) {
      throw new QueryRuntimeException(e.getMessage(), e);
    }
    return state;
  }

  public String getCheckpointStateString() throws ThinException {
    String state = null;      
		if (!isDesignTime() && isProxySet()) {
      // We always want to execute this immediately: informational
            OperationQueue tempQueue = generateTempOpQueue();
            if (tempQueue == null)
            {
                return null;
            }
      try {
        state = (String)tempQueue.addOperation(new Operation("getCheckpointState", null, false));
      }
      catch (IllegalArgumentException iae) {
        throw iae;
      }
      catch (Throwable e)	{
        throw new ThinException(e.getMessage(), e);
      }
    }        
		return state;
  }
  */
  // ParameterManager interface
  public boolean usesParameter(oracle.dss.util.parameters.Parameter parameter) {
    return _getQueryState().usesParameter(parameter);
  }

    public void removeParameter(oracle.dss.util.parameters.Parameter parameter)
    {
        _getQueryState().removeParameter(parameter);
    }

    public oracle.dss.util.parameters.Parameter getParameter(String name)
    {
        return _getQueryState().getParameter(name);
    }
    
    public void setParameter(oracle.dss.util.parameters.Parameter parameter)
    {
        _getQueryState().setParameter(parameter);
    }
    
  public oracle.dss.util.parameters.Parameter[] getParameters() {
    return _getQueryState().getParameters();
  }

/*  private ParameterValueMappingManager _getParameterValue() {
    return _getQueryState().getParameterValue();
  }
  // ParameterValueMappingManager interface (all delegated to impl)
  public void clearValue(oracle.dss.util.parameters.Parameter parameter) {
    _getParameterValue().clearValue(parameter);
  }
  
  public void setValue(oracle.dss.util.parameters.Parameter parameter, Hashtable value, ParameterMap map) {      
    _getParameterValue().setValue(parameter, value, map);
  }

  public void setValue(oracle.dss.util.parameters.Parameter parameter, Object value) {
    _getParameterValue().setValue(parameter, value);
  }
  
  public Hashtable getValue(oracle.dss.util.parameters.Parameter parameter, ParameterMap map) {
    return _getParameterValue().getValue(parameter, map);
  }
  
  public Object getValue(oracle.dss.util.parameters.Parameter parameter) {
    return _getParameterValue().getValue(parameter);
  }
  */
  public void setParameterValueManager(ParameterValueManager pvm) {
    m_pvm = pvm;
  }
  
  public ParameterValueManager getParameterValueManager() {
      if (m_pvm != null)
            return m_pvm;
      // Fall back to QM
      return _getQueryManager().getParameterValueManager();
  }
/*
  public void setOverridePrompt(oracle.dss.util.parameters.Parameter parameter, String prompt) {      
    _getParameterValue().setOverridePrompt(parameter, prompt);
  }
  
  public String getOverridePrompt(oracle.dss.util.parameters.Parameter parameter) {
    return _getParameterValue().getOverridePrompt(parameter);
  }

  public void removeMappedParameter(oracle.dss.util.parameters.Parameter parameter) {
    _getParameterValue().removeMappedParameter(parameter);
  }

  public oracle.dss.util.parameters.Parameter[] getMappedParameters() {
    return _getParameterValue().getMappedParameters();
  }

  public boolean isMappedParameter(oracle.dss.util.parameters.Parameter parameter) {
    return _getParameterValue().isMappedParameter(parameter);
  }

  public void addMappedParameter(oracle.dss.util.parameters.Parameter parameter) {
    _getParameterValue().addMappedParameter(parameter);
  }
*/
  /**
   * Attempt to find a <code>MDObject</code> from the specified id lists.
   * 
   * @param strDataItemIDs A <code>String[]</code> of data item IDs.
   * @param strDimensionIDs A <code>String[][]</code> of dimension IDs.
   * @param strItemIDs A <code>String[]</code> of item IDs.
   * 
   * @return <code>MDObject</code> representing the first object found.
   * 
   * @throws <code>InvalidMetadataException</code>
   * @throws <code>MetadataManagerException</code>
   * 
   * @status hidden
   */
  protected MDObject getMDObject (String[] strDataItemIDs, String[][] strDimensionIDs, String[]strItemIDs) 
    throws InvalidMetadataException,  MetadataManagerException {
    
    // Look though the measures and dimensions first
    MDObject mdObject = getDataSourceObj (strDataItemIDs, strDimensionIDs);
    if (mdObject == null) {
      // If not found, look through the items
      mdObject = getDataSourceObj (strItemIDs, null);   
    }
  
    return mdObject;
  }
}
