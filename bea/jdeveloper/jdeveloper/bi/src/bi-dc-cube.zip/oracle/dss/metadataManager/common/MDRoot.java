/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.metadataManager.common;

// Imports
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import oracle.dss.util.ErrorHandler;
import oracle.dss.metadataUtil.*;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MetadataProvider;
import oracle.dss.metadataManager.common.MetadataManagerException;

/**
 * The root folder in the MetadataManager.
 *
 * @status Reviewed
 */
public class MDRoot extends MDFolder {

  // ConnectionString - Key (String)
  // DatabaseString - Value (String)
  // Currently, sharing a connection by two drivers not allowed.
  // That needs to be implemented later.
	private Hashtable m_StringMap = null;

  // DatabaseString -Key (String)
  // Status - Value (Integer)
	private Hashtable m_AttachStatusTable = null;

  // Primary Index
  private OrderedHashtable m_PrimaryIndex = null;
  
  // temporary fix. This need to be removed
  //public MDIndex m_MDIndex = null;

  private int m_PerformanceFlag = MM.DEMO_DATABASE;

  /************************************************************************
  * Public methods
  ************************************************************************/
    /**
     * @hidden
     * Constructor that does not specify environment properties or an
     * error handler.
     * Application developers should never construct a root folder, because
     * the <code>MetadataManager</code> automatically constructs a root folder.
     * To get the root folder, call the <code>getMDRoot</code> method of the
     * MetadataManager.
     *
     * @see oracle.dss.metadataManager.client.MetadataManager#getMDRoot
     *
     * @status hidden
     */
    public MDRoot() {
        super();
        m_Parent = null;
        setObjectType(MM.ROOT);
    }

    /**
     * @hidden
     * Constructor that specifies environment properties and an error handler.
     * Environment properties are defined in the <code>Context</code>
     * interface in JNDI.
     *
     * @param env  Environment properties for this root folder.
     * @param handler  The error handler for this root folder.
     *
     * @status hidden
     */
    public MDRoot( Hashtable hashTable,  ErrorHandler eh) {
        super();
        setObjectType(MM.ROOT);
    }

   	/**
     * @hidden
     * Constructor that specifies the MetadataManager, a name, a parent,
     * and environment variables for this root folder.
     *
     * @param mmServices   The <code>MetadataManagerServices</code> that this
     *                     root folder exists in.
     * @param rootName     A name for this root folder.
     * @param parent       The parent of this root folder.
     * @param env          Environment properties.
     * @param handler      The error handler for this root folder.
     *
     * @status hidden
     */
    public MDRoot( MetadataManagerServices mmServices,
                   String                  rootName,
                   MDObject                parent,
                   Hashtable               env,
                   ErrorHandler            handler  ) {
        super( mmServices, rootName, parent, env, handler );
        setObjectType(MM.ROOT);
    }


    /**
     * Retrieves the folders in this root folder.
     *
     * @return The <code>MDFolder</code> objects that this folder contains.
     *
     * @throws MetadataManagerException If the connection fails during the
     *          execution of this method or if there is a problem listing
     *          the objects on the server.
     *
     * @status Reviewed
     */
    public MDFolder[] getFolders() throws MetadataManagerException {
        return MDFolder.getFolderArray(getChildren(MM.FOLDER));
    }


    /**
     * @hidden
     * Specifies a subfolder of this folder.
     *
     * @param folder  The subfolder to add to this folder.
     *
     * @return A constant that represents success or failure.
     *         Possible constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
  public int setFolder(MDFolder folder ) {
    if (folder == null) {
      return MDU.FAILURE;
    }
    setChild(folder, MM.FOLDER);
    return MDU.SUCCESS;
  }

    /**
     * @hidden
     * Specifies multiple subfolders of this folder.
     *
     * @param folders The subfolders to add to this folder.
     *
     * @return A constant that represents success or failure.
     *         Possible constants are listed in the See Also section.
     *
     * @see oracle.dss.metadataUtil.MDU#SUCCESS
     * @see oracle.dss.metadataUtil.MDU#FAILURE
     *
     * @status hidden
     */
    public int setFolders(MDFolder[] folders) {
      if ( (folders == null) || (folders.length == 0) ) {
        return MDU.FAILURE;
      }
      for (int i=0; i<folders.length; i++) {
        setChild(folders[i], MM.FOLDER);
      }
      return MDU.SUCCESS;
    }

     /**
     *
     * @hidden
     *
     */
  public OrderedHashtable getPrimaryIndex() {
    return m_PrimaryIndex;
  }

     /**
     *
     * @hidden
     *
     */
    public void setPerformanceTuning( int flag ) {
        m_PerformanceFlag = flag;
    }

     /**
     *
     * @hidden
     *
     */
    public int getPerformanceTuning() {
        return m_PerformanceFlag;
    }

     /**
     *
     * @hidden
     *
     */
  public void setPrimaryIndex( OrderedHashtable primaryIndex) {
    m_PrimaryIndex = primaryIndex;
  }

     /**
     *
     * @hidden
     *
     */
  public void setStrings( String connectionString,	String	databaseString ) {
    if ( ( connectionString == null ) ||
         ( connectionString.equals("") ) )
      return;
    if ( databaseString == null )
      databaseString = new String ( "" );          

    if ( m_StringMap == null )
      m_StringMap = new Hashtable();

    if ( m_StringMap.containsKey( connectionString ) ) {
      if (( databaseString.equals("")) || ( m_StringMap.contains( databaseString ) )) {
        return;
      }
    }
    m_StringMap.put(connectionString, databaseString);
		return;
  }

     /**
     *
     * @hidden
     *
     */
  public Hashtable getStringMap() {
    return m_StringMap;
  }

     /**
     *
     * @hidden
     *
     */
  public void setStringMap( Hashtable stringMap) {
    m_StringMap = stringMap;
    return;
  }

     /**
     *
     * @hidden
     *
     */
	public String getConnectionString ( String databaseString ) {
   if ( databaseString == null )
      databaseString = new String ( "" ); 
    if (( m_StringMap == null ) || (!m_StringMap.contains(databaseString)))
      return null;
    Enumeration enumer = m_StringMap.keys();
    for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
      String key = (String) enumer.nextElement();
      String element = (String) m_StringMap.get((Object)key);
      if ( element.equals ( databaseString ) )
        return key;
    }
    return null;
	}

     /**
     *
     * @hidden
     *
     */
    public String getDatabaseString ( String connectionString ) {
        if (( m_StringMap == null ) || (connectionString == null) || (!m_StringMap.containsKey(connectionString))) {
            return null;
        }
        String databaseString = (String) m_StringMap.get(connectionString);
        return databaseString;
    }

     /**
     *
     * @hidden
     *
     */
	public String[] getDatabaseStrings() {
    if ( ( m_StringMap == null ) || ( m_StringMap.size() == 0) )
      return null;
    int count = m_StringMap.size();
    String[] strs = new String[count];
    Enumeration enumer = m_StringMap.elements();
    for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
      strs[i] = (String) enumer.nextElement();
    }
    return strs;
	}

     /**
     *
     * @hidden
     *
     */
  public String[] getConnectionStrings() {
    if ( ( m_StringMap == null ) || ( m_StringMap.size() == 0) )
      return null;
    int count = m_StringMap.size();
    String[] strs = new String[count];
    Enumeration enumer = m_StringMap.keys();
    for ( int i = 0; enumer.hasMoreElements() ; i++ ) {
      strs[i] = (String) enumer.nextElement();
    }
    return strs;
  }


     /**
     *
     * @hidden
     *
     */
  public String[] getConnectionStrings ( String databaseString ) {
    //to do
    return null;
  }

     /**
     *
     * @hidden
     *
     */
  public String[] getDatabaseStrings ( String connectionString ) {
    //to do
    return null;
  }

     /**
     *
     * @hidden
     *
     */
	public void setAttachStatus( String databaseString, int status ){
    if ( m_AttachStatusTable == null )
      m_AttachStatusTable = new Hashtable();
		m_AttachStatusTable.put ( (Object) databaseString, (Object) (new Integer( status )) );		
		return;
  }

     /**
     *
     * @hidden
     *
     */
  public String[] getDatabaseStrings( int status ) {
		//to do
		return null;
  }

     /**
     *
     * @hidden
     *
     */
	public int getAttachStatus( String databaseString ){
    if ( m_AttachStatusTable == null )
      return 0;
		Integer in = (Integer) m_AttachStatusTable.get ( (Object) databaseString );
		if ( in != null )
			return in.intValue();
		return 0;
  }

     /**
     *
     * @hidden
     *
     */
	public boolean isAttached(){
		if ( getAttachStatus() == MM.ATTACHED )
			return true;
		return false;
  }

     /**
     *
     * @hidden
     *
     */
  public String getMetadataManagerName() {
		return getStrPropertyValue( MM.OBJECT_NAME );
  }
  
     /**
     *
     * @hidden
     *
     */
  public void setMetadataManagerName(String name) {
		setStrPropertyValue( MM.OBJECT_NAME, name, MDU.UI_VISIBLE | MDU.UI_WRITE );
  }

     /**
     *
     * @hidden
     *
     */
  public int getAttachStatus() {
		return getIntPropertyValue( MM.ATTACH_STATUS );
  }

     /**
     *
     * @hidden
     *
     */
  public void setAttachStatus( int status ) {
		setIntPropertyValue( MM.ATTACH_STATUS, status, MDU.UI_VISIBLE  );
  }

     /**
     *
     * @hidden
     *
     */
  public int getConnectionStatus() {
    return getIntPropertyValue( MM.CONNECTION_STATUS );
  }

     /**
     *
     * @hidden
     *
     */
  public void setConnectionStatus( int status ) {
    setIntPropertyValue( MM.CONNECTION_STATUS, status, MDU.UI_VISIBLE  );
  }

     /**
     *
     * @hidden
     *
     */
  public int free() {
		super.free();
		return MDU.FAILURE;
  }

     /**
     *
     * @hidden
     *
     */
  public MDMeasure[] measuresOfDimensions(MDDimension[] dimensions, String flags)
                                                throws MetadataManagerException
  {
    if (( dimensions == null ) || ( 0 == dimensions.length ) )   
      return null;

    Vector dbVector = new Vector ();
    for (int i = 0; (( dimensions != null ) && ( i < dimensions.length )) ; i ++ ) {
      dbVector = getCombinedVector ( (MDObject[]) dimensions[i].getMeasures(), dbVector, flags ) ;  
    }
    return (MDMeasure[]) getMDObjectsFromVector ( dbVector );  
  }

  /**
     This method will provide the dimensionality of one or a set of measures. 
     The flags can be used to specify it should be a union or intersection.
   */
     /**
     *
     * @hidden
     *
     */
  public MDDimension[] dimensionalityOfMeasures(MDMeasure[] measures, String flags)
                                                throws MetadataManagerException
  {
    if (( measures == null ) || ( 0 == measures.length ) )
      return null;

    Vector dbVector = new Vector ();
    for (int i = 0; (( measures != null ) && ( i < measures.length )) ; i ++ ) {
      if(measures[i] != null)
        dbVector = getCombinedVector ( (MDObject[]) measures[i].getDimensions(), dbVector , flags ) ;
    }
    return (MDDimension[]) getMDObjectsFromVector ( dbVector );
  }

     /**
     *
     * @hidden
     *
     */
  public Vector getCombinedVector ( MDObject[] mdObjects, Vector vec, String flag ) {
    if ( mdObjects == null || 0 >= mdObjects.length )
      return vec;
    
    Vector vector = new Vector();
    MDObject mdObject = null;
    if ( flag.equals( MM.UNION) ){
      for (int i = 0; (( vec != null ) && ( i < vec.size() )) ; i ++ ) {
        mdObject = (MDObject) vec.elementAt(i) ;
        vector.addElement ( mdObject );
      }
      for (int i = 0; (( mdObjects != null ) && ( i < mdObjects.length )) ; i ++ ) {
        vector = addIfNotDuplicate ( mdObjects[i], vector );
      }
    }
    else if ( flag.equals( MM.INTERSECTION) ) {
      for (int i = 0; (( vec != null ) && ( i < vec.size() )) ; i ++ ) {
        mdObject = (MDObject) vec.elementAt(i) ;
        for ( int j = 0 ; (( mdObjects != null ) && ( j < mdObjects.length )); j++ ) {
          if ( mdObject.getObjectID() == mdObjects[i].getObjectID() ) {
            vector = addIfNotDuplicate ( mdObjects[i], vector );
          }  
        }  
      }
    }
    return vector;
  }
  
     /**
     *
     * @hidden
     *
     */
  public Vector addIfNotDuplicate ( MDObject dbObj, Vector vec ) {
    MDObject mdObject = null;
    for (int i = 0; (( vec != null ) && ( i < vec.size() )) ; i ++ ) {
      mdObject = (MDObject) vec.elementAt(i) ;
      if ( dbObj.getObjectID() == mdObject.getObjectID() ) {
        return vec;
      }
    }
    vec.addElement(dbObj);
    return vec;
  }
   
     /**
     *
     * @hidden
     *
     */
  MDObject[] getMDObjectsFromVector ( Vector vec ) {
    return (MDObject[])oracle.dss.util.Utility.copyVectorToArray(vec);
  }

	
     /**
     *
     * @hidden
     *
     */
	public MDObject getMDObjectByName(String strObject, String strObjectType)
                                                throws MetadataManagerException
    {
		if (strObjectType.equals(MM.FOLDER)) {
			return (MDObject)getFolderByName(strObject); 
		}
		else if (strObjectType.equals(MM.MEASURE)) {
			return (MDObject)getMeasureByName(strObject);
		}
		else if (strObjectType.equals(MM.SELECTION)) {
			return (MDObject)getSelectionByName(strObject);
		}
		else if (strObjectType.equals(MM.COMPONENT)) {
			return (MDObject)getComponentByName(strObject);
		}
		else if (strObjectType.equals(MM.DIMENSION)) {
			return (MDObject)getDimensionByName(strObject);
		}
		else if (strObjectType.equals(MM.ATTRIBUTE)) {
			return (MDObject)getAttributeByName(strObject);
		}
		else if (strObjectType.equals(MM.HIERARCHY)) {
			return (MDObject)getHierarchyByName(strObject);
		}
		else if (strObjectType.equals(MM.LEVEL)) {
			return (MDObject)getLevelByName(strObject);
		}
		return null;
	}
		
     /**
     *
     * @hidden
     *
     */
	public MDDimension getMeasureDimension() throws MetadataManagerException {
		return (MDDimension)getFirstChild(MM.MEASURE_DIMENSION);
	}
	
     /**
     *
     * @hidden
     *
     */
	public int setMeasureDimension(MDDimension dimension) {
  		if (dimension == null) {
  			return (MDU.FAILURE);
  		}
      setChild ( dimension, MM.MEASURE_DIMENSION ); 
		return MDU.SUCCESS;
	}

     /**
     *
     * @hidden
     *
     */
	public MDFolder getFolder(String strFolder, String strLabelType) throws MetadataManagerException {
		MDFolder[] folders = getFolders();
		if (folders != null) { 
			MDFolder folder;
			for (int i=0; i<folders.length; i++) {
				folder = folders[i];
				if (folder.toString(strLabelType).equals(strFolder)) {		
					return folder;
				}
			}
		}
		return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDFolder getFolderByName(String strFolder)
                                                throws MetadataManagerException
    {
		return getFolder(strFolder, MM.OLAPI_METADATA_ID);
	}

     /**
     *
     * @hidden
     *
     */
	public MDMeasure getMeasure(String strMeasure, String strLabelType)
                                                throws MetadataManagerException
    {
		MDMeasure[] measures = getMeasures();
		if (measures != null) {
			MDMeasure measure;
			for (int i=0; i<measures.length; i++) {
				measure = measures[i];		
				if (measure.toString(strLabelType).equals(strMeasure)) {
					return measure;
				}
			}
		}
		return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDMeasure getMeasureByName(String strMeasure)
                                                throws MetadataManagerException
    {
		return getMeasure(strMeasure, MM.OLAPI_METADATA_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDSelection getSelection(String strSelection, String strLabelType)
                                                throws MetadataManagerException
    {
		MDSelection[] selections = getSelections();
		if (selections != null) {
			MDSelection selection;
			for (int i=0; i<selections.length; i++) {
				selection = selections[i];
				if (selection.toString(strLabelType).equals(strSelection)) {
					return selection;
				}
			}
		}
		return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDSelection getSelectionByName(String strSelection)
                                                throws MetadataManagerException
    {
		return getSelection(strSelection, MM.OLAPI_METADATA_ID);
	}	
	
     /**
     *
     * @hidden
     *
     */
	public MDDimension getDimension(String strDimension, String strLabelType)
                                                throws MetadataManagerException
    {
		MDDimension[] dimensions = getDimensions();
		if (dimensions != null) {
			MDDimension dimension;
			for (int i=0; i<dimensions.length; i++) {
				dimension = dimensions[i];
				if (dimension.toString(strLabelType).equals(strDimension)) {		
					return dimension;
				}
			}
		}
		return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDDimension getDimensionByName(String strDimension)
                                                throws MetadataManagerException
    {
		return getDimension(strDimension, MM.OLAPI_METADATA_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDComponent getComponent(String strComponent, String strLabelType)
                                                throws MetadataManagerException
    {
		MDComponent[] components = getComponents();
		if (components != null) {
			MDComponent component;
			for (int i=0; i<components.length; i++) {
				component = components[i];
				if (component.toString(strLabelType).equals(strComponent)) {		
					return component;
				}
			}
		}
		return null;
	}

     /**
     *
     * @hidden
     *
     */
	public MDComponent getComponentByName(String strComponent)
                                                throws MetadataManagerException
    {
		return getComponent(strComponent, MM.OLAPI_METADATA_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttribute(String strAttribute, String strLabelType)
                                                throws MetadataManagerException
    {
	 	MDDimension[] dimensions = getDimensions();
	 	if (dimensions != null) {
	 		MDAttribute attribute;
		 	for (int i=0; i<dimensions.length; i++) {
				attribute = getAttribute(strAttribute, dimensions[i], strLabelType);
				if (attribute != null) {
					return attribute;
				}
		 	}
	 	}
	 	return null;
	}

     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttributeByName(String strAttribute)
                                                throws MetadataManagerException
    {
		return getAttribute(strAttribute, MM.UNIQUE_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttributeByName(String strAttribute, String strDimension)
                                                throws MetadataManagerException
    {
		return getAttribute(strAttribute, strDimension, MM.UNIQUE_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttribute(String strAttribute,
                                    String strDimension,
                                    String strLabelType)
                                    throws MetadataManagerException
    {
		return getAttribute(strAttribute, getDimensionByName(strDimension), strLabelType);
	}

     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttribute(String strAttribute, MDDimension dimension, String strLabelType)
                                                throws MetadataManagerException
    {
		if ( (strAttribute != null) && (dimension != null) && (strLabelType != null) ) {
		 	MDAttribute[] attributes = dimension.getAttributes();
		 	if (attributes != null) {
		 		MDAttribute attribute;
			 	for (int i=0; i<attributes.length; i++) {
			 		attribute = attributes[i];
		 			if (attribute.toString(strLabelType).equals(strAttribute)) {
		 				return attribute;
		 			}
	  			}
		 	}
		}
	 	return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDAttribute getAttributeByName(String strAttribute,
                                          MDDimension dimension)
                                          throws MetadataManagerException
    {
		return getAttribute(strAttribute, dimension, MM.UNIQUE_ID);
	}

     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchy(String strHierarchy, String strLabelType)
                                                throws MetadataManagerException
    {
	 	MDDimension[] dimensions = getDimensions();
	 	if (dimensions != null) {
	 		MDHierarchy hierarchy;
		 	for (int i=0; i<dimensions.length; i++) {
				hierarchy = getHierarchy(strHierarchy, dimensions[i], strLabelType);
				if (hierarchy != null) {
					return hierarchy;
				}
		 	}
	 	}
	 	return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchyByName(String strHierarchy)
                                                throws MetadataManagerException
    {
		return getHierarchy(strHierarchy, MM.UNIQUE_ID);
	}

     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchyByName(String strHierarchy,
                                          String strDimension)
                                          throws MetadataManagerException
    {
		return getHierarchy(strHierarchy, strDimension, MM.UNIQUE_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchy(String strHierarchy,
                                    String strDimension,
                                    String strLabelType)
                                    throws MetadataManagerException
    {
		return getHierarchy(strHierarchy, getDimensionByName(strDimension), strLabelType);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchy(String strHierarchy, MDDimension dimension, String strLabelType)
                                                throws MetadataManagerException
    {
		if ( (strHierarchy != null) && (dimension != null) && (strLabelType != null) ) {
		 	MDHierarchy[] hierarchies = dimension.getHierarchies();
		 	if (hierarchies != null) {
		 		MDHierarchy hierarchy;
			 	for (int i=0; i<hierarchies.length; i++) {
			 		hierarchy = hierarchies[i];
		 			if (hierarchy.toString(strLabelType).equals(strHierarchy)) {
		 				return hierarchy;
		 			}
	  		}
		 	}
		}
	 	return null;
	}

     /**
     *
     * @hidden
     *
     */
	public MDHierarchy getHierarchyByName(String strHierarchy,
                                          MDDimension dimension)
                                          throws MetadataManagerException {
		return getHierarchy(strHierarchy, dimension, MM.UNIQUE_ID);
	}


     /**
     *
     * @hidden
     *
     */
  public MDLevel getLevelByName(String strLevel)
              throws MetadataManagerException {
    //return getLevel(strLevel, MM.UNIQUE_ID);
    return null;
  }
  
     /**
     *
     * @hidden
     *
     */
  	public MDLevel getLevel(String strLevel, MDHierarchy hierarchy, String strLabelType)
                                             throws MetadataManagerException {
  		if ( (strLevel != null) && (hierarchy != null) && (strLabelType != null) ) {
			MDLevel[] levels = hierarchy.getLevels();
			if (levels != null) {
				MDLevel level;
			 	for (int i=0; i<levels.length; i++ ) {
			 		level = levels[i];
		 			if (level.toString(strLabelType).equals(strLevel)) {
		 				return level;
		 			}
			 	}
	  		}
  		}
	 	return null;
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDLevel getLevelByName(String strLevel, MDHierarchy hierarchy)
                                throws MetadataManagerException {
		return getLevel(strLevel, hierarchy, MM.OLAPI_METADATA_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
	public MDLevel getLevelByName(String strLevel,
                                  String strDimension,
                                  String strHierarchy)
                                   throws MetadataManagerException {
		return getLevel(strLevel, getHierarchyByName(strHierarchy, getDimensionByName(strDimension)), MM.OLAPI_METADATA_ID);
	}
	
     /**
     *
     * @hidden
     *
     */
    public MDObject getMDObjectByPath(String strPath, MetadataManagerServices services, MDRoot root) throws MetadataManagerException {
    	if (strPath == null || strPath.equals("")) {
    		return root;
    	}
    	PropertyBag propertyBag = new PropertyBag();
    	Property property = new Property();
    	property.setStrValue(MM.PATH, strPath, MDU.UI_ALL);
    	propertyBag.setProperty(property);
    	return services.getMDObject(propertyBag);
    }

  /************************************************************************
  * Private methods
  ************************************************************************/
}