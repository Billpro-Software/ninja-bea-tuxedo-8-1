/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.connection.common;

// Imports
import oracle.dss.metadataUtil.BaseEvent;

/**
 * Describes changes in the status of a connection.
 *
 * @status documented
 */
public class ConnectionEvent extends BaseEvent {

  /**
   * Constructor.
   *
   * @param source     The source of this event.
   * @param isConsumable <code>true</code> if this event can be consumed,
   *                     <code>false</code> if it cannot be consumed.
   *
   * @status documented
   */
  public ConnectionEvent( Object source, boolean isConsumable ) {
    super( source, isConsumable );
  }
}