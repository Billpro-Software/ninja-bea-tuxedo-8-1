/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/RowIteratorProjection.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    bmoroze     09/11/09 - XbranchMerge bmoroze_bug-8879459 from main
    bmoroze     10/31/06 - Move files back to oracle.dss.util
    bmoroze     08/24/06 - 
    jramanat    06/14/06 - 
    bmoroze     05/17/06 - 
    jramanat    05/04/06 - Creation
 */

package oracle.dss.dataSource.bi.client;

import java.util.Enumeration;
import java.util.Hashtable;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

import oracle.dss.dataSource.client.CloneableRowIterator;
import oracle.dss.dataSource.client.Layer;
import oracle.dss.dataSource.client.MetadataBasedMember;
import oracle.dss.dataSource.common.CloneException;
import oracle.dss.dataSource.common.Query;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.QDR;
import oracle.dss.util.transform.DataCellInterface;
import oracle.dss.util.transform.LayerInterface;
import oracle.dss.util.transform.LayerInterfaceWrapper;
import oracle.dss.util.transform.MemberInterface;
import oracle.dss.util.transform.QDRLite;
import oracle.dss.util.transform.RowProjection;
import oracle.dss.util.transform.RowIterator;
import oracle.dss.util.transform.TransformException;
import oracle.dss.util.transform.TransformRuntimeException;

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/dataSource/bi/client/RowIteratorProjection.java /st_jdevadf_patchset_ias/2 2009/09/18 11:31:47 bmoroze Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

public class RowIteratorProjection implements RowProjection {
  protected Query m_query = null;
  protected CloneableRowIterator m_iterator = null;
  protected SBADataTable m_dataTable = null;
    protected String m_layerType = null;
    protected Hashtable<String, String> m_layerNameLookup = null;
    protected boolean m_firstHandOut = true;
    protected Layer m_dataLayer = null;
    protected Map<String, LayerInterface> m_layers = new HashMap<String, LayerInterface>();

  protected RowIteratorProjection() {
    super();
  }
    
  public RowIteratorProjection(CloneableRowIterator iterator, Query q) 
  {
      this(iterator, q, null, LayerMetadataMap.LAYER_METADATA_NAME, null);
  }

    public RowIteratorProjection(CloneableRowIterator iterator, Query q, SBADataTable dataTable, String layerMetadataType, Hashtable<String, String> layerNameLookup)
    {
        m_iterator = iterator;
        m_query = q;
          m_layerType = layerMetadataType;
          m_layerNameLookup = layerNameLookup;
        setDataTable(dataTable);
    }
    
    protected void setDataTable(SBADataTable dataTable)
    {
        m_dataTable = dataTable;
    }
    
  public MemberInterface[] getDataItems() {
    if (m_query != null) {
      String[] dataItems = m_query.getDataItems();
      if (dataItems != null && dataItems.length > 0) {
        MemberInterface[] members = new MemberInterface[dataItems.length];
        for (int i = 0; i < dataItems.length; i++) {
          try {
            members[i] = new MetadataBasedMember(dataItems[i], m_query.getMeasureDim(), m_query);
          }
          catch (TransformException e) {
            throw new TransformRuntimeException(e.getMessage(), e);
          }
        }
        return members;
      }
    }
    return null;
  }
  
  public RowIterator getRowIterator() {
      // For efficiency, first hand out the originally given iterator--any subsequent calls get a copy so they're reset
    if (m_firstHandOut)
    {
        m_firstHandOut = false;
        return m_iterator;
    }
    if (m_iterator != null)
        return (RowIterator)m_iterator.clone();
    return null;
  }
  
  public LayerInterface getDataLayer()  {
    try {
//        if (m_layerType != null && !m_layerType.equals(LayerMetadataMap.LAYER_METADATA_NAME))
        //{
            // Account for this...
            if (m_dataLayer == null)
            {
	            MDObject obj = m_query.getMeasureDimObj();
        	    m_dataLayer = new Layer(obj, m_query._getQueryState());
            }
            return m_dataLayer;
    }
    catch (TransformException e) {
      throw new TransformRuntimeException(e.getMessage(), e);
    }
  }
  
  public String[][] getLayout()  {
    return m_query.getLayout(m_layerType);
  }
  
  public LayerInterface getLayer(String layer) {
    try {
        LayerInterface li = m_layers.get(layer);
        if (li == null)
        {
            li = new LayerInterfaceWrapper(new Layer(m_query.getMDObject(MM.UNIQUE_ID, translateLayerName(layer), MM.OBJECT), m_query.getQueryState()), m_layerType);
            m_layers.put(layer, li);
        }
        return li;
    }
    catch (MetadataManagerException e) {
      throw new TransformRuntimeException(e.getMessage(), e);
    }
    catch (CloneException ce) {
      throw new TransformRuntimeException(ce.getMessage(), ce);
    }
  }
  
  public String[] getIgnoredColumns()
  {
      return null;
  }

    private String translateLayerName(String layer)
    {
        if (m_layerNameLookup != null)
        {
            // layer is not unique ID
            return m_layerNameLookup.get(layer);
        }        
        return layer;
    }
    
  // translate QDR dimensions into raw IDs
  private Map<String, Object> translateQDR(Map<String, Object> qdrInt)
  {
      if (qdrInt instanceof QDR)
      {
          QDR qdr = (QDR)qdrInt;
          QDR newQDR = new QDR(qdr.getMeasureDim());
          Enumeration dims = qdr.getDimensions();
          String oldDim = null;
          while (dims.hasMoreElements())
          {             
              oldDim = (String)dims.nextElement();
              newQDR.addDimMemberPair(translateLayerName(oldDim), qdr.getDimMember(oldDim));
          }
          return newQDR;
      }
      else if (qdrInt instanceof QDRLite)
      {
          QDRLite qdr = (QDRLite)qdrInt;
          QDRLite newQDR = new QDRLite(qdr.getMeasureDim());
          Iterator<String> dims = qdr.getColumns().iterator();
          String oldDim = null;
          while (dims.hasNext())
          {             
              oldDim = dims.next();
              newQDR.addDimMemberPair(translateLayerName(oldDim), qdr.getDimMember(oldDim));
          }
          return newQDR;
      }
      return qdrInt;
  }
    
  public DataCellInterface getData(Map<String, Object> qdr)
  {
      return m_dataTable.getData(translateQDR(qdr));
  }
}
