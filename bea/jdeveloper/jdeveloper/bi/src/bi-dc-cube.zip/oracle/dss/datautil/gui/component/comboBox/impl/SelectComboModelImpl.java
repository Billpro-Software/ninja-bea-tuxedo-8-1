/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.datautil.gui.component.comboBox.impl;

import java.util.ArrayList;

import javax.swing.ListModel;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import oracle.dss.datautil.gui.component.models.SelectModel;
import oracle.dss.util.gui.component.comboBox.TreeListComboModel;

public class SelectComboModelImpl implements TreeListComboModel {
    
    TreeModel m_treeModel;
    SelectModel m_selectModel;
        
    public SelectComboModelImpl(SelectModel selectModel) {
        m_selectModel = selectModel;
    }
    
    /**
     * Retrieves the TreeModel
     * 
     * @return the TreeModel
     */
    public TreeModel getTreeModel(){
        if (m_treeModel == null) {
            m_treeModel = new DefaultTreeModel(m_selectModel.getTreeRoot());
        }
        return m_treeModel;
    }
     
    /**
     * Retrieves the ListModels
     * 
     * @return an array of ListModels
     */
    public ListModel[] getListModels() {
        return new ListModel[0];
    }
    
    public ArrayList getSelectFilters() {
        return m_selectModel.getSelectFilters();
    }
    
    public boolean isMultiSelect(){
        return m_selectModel.isMultiSelect();
    }
}
    

