/* $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/save/resource/SaveBundle.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $ */

/* Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jramanat    01/09/06 - Creation
 */

/**
 *  @version $Header: dsstools/modules/dvt-cube/src/oracle/dss/datautil/gui/component/save/resource/SaveBundle.java /st_jdevadf_patchset_ias/1 2009/09/28 08:30:15 kmchorto Exp $
 *  @author  jramanat
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.dss.datautil.gui.component.save.resource;

import java.util.ListResourceBundle;

public class SaveBundle extends ListResourceBundle {

  public static final String NAME = "Name";
  public static final String AUTONAME = "Autoname";
  public static final String DESCRIPTION = "Description";
  public static final String SAVE_IN = "SaveIn";
  public static final String SAVE_IN_CURRENT_WORKBOOK = "SaveInCurrentWorkbook";
  public static final String SELECT_FOLDER = "SelectFolder";
  
  static final Object[][] m_resources = {
    {NAME, "Name"},
    {AUTONAME, "Autoname"},
    {DESCRIPTION, "Description"},
    {SAVE_IN, "Save In"},
    {SAVE_IN_CURRENT_WORKBOOK, "Current Workbook"},
    {SELECT_FOLDER, "Select Folder..."},
  };
  
  public Object[][] getContents() {
    return m_resources;
  }  
}
