/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil;

/**
 * Listener for events that users of a <code>QueryAccess</code> object may want
 * to respond to.
 *
 * @status Documented
 */
public interface QueryAccessListener
{
    /**
     * Called when either the available selection or the selected
     * selection of a <code>QueryAccess</code> object is changed with a
     * resulting change in the corresponding DataAccess cursor.
     *
     * @param e The SelectionChangedEvent, which gives access to the new
     *          selection.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
/*    public void selectionChanged(SelectionChangedEvent e);*/
    
    /**
     * Called when both a selection change occurs in one of the
     * <code>DataAccess</code> cursors of a <code>QueryAccess</code> and a
     * client requests the changed cursor. In a <code>QueryAccess</code>, there
     * are the following cursors:
     * <ul>
     * <li>available selection cursor</li>
     * <li>selected selection cursor</li>
     * </ul>
     *
     * @param e The DataAccessChangedEvent that gives access to the new
     *          <code>DataAccess</code> object.
     *
     * @status Documented
     */
    public void dataAccessChanged(DataAccessChangedEvent e);
    
    /**
     * Called when the dimensionality of a <code>QueryAccess</code> has
     * changed.
     *
     * @param e The DimensionsChangedEvent, which describing the dimensionality
     *          change.
     *
     * @status Documented
     */
    public void dimensionsChanged(DimensionsChangedEvent e);    
}