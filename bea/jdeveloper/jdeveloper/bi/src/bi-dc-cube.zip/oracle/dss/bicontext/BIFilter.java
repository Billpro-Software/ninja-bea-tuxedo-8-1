/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.bicontext;
import java.io.Serializable;

/**
 * A custom filter for filtering each of the search results after the main search
 * is finished.  The filtering is performed on the server, so any implementation 
 * class must be available on the server classpath.  
 *
 * @status New
 */
public interface BIFilter extends Serializable
{
    /**
     * Determines whether to include a particular search result in the
     * final search outcome.
     *
     * @param   result The result to evaluate.
     * @return  <code>true</code> if <code>result</code> should be included,
     *          <code>false</code> otherwise
     * @status New
     */
    boolean evaluate(BISearchResult result);
}
