/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Informs listeners when changes to one or more <code>Selection</code> objects
 * have been requested. A listener can call the <code>consume</code> method
 * of this event to veto the changes.
 *
 * @status Documented
 */
public class SelectionChangingEvent extends SelectionEvent implements Consumable
{
    /**
     * Constructs the event.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param selections A list of the <code>Selection</code> objects for which
     *                   changes were requested.
     *
     * @status Documented
     */
     // blm - Selection code moved to dvt-olap
    public SelectionChangingEvent(Object source/*, Selection[] selections*/) {
        super(source, /*selections, */false);
    }    
    
   /**
     * Constructs the event.
     * 
     * @param source     The source of the event, that is, a reference to the
     *                   object that fired the event.
     * @param selections A list of the <code>Selection</code> objects for which
     *                   changes were requested.
     * @param removed    Were these selections removed?
     *
     * @status New
     */
    public SelectionChangingEvent(Object source, /*Selection[] selections, */boolean removed) {
        super(source, /*selections, */removed);
    }    
        
    /**
     * Consumes this event.
     *
     * @status Documented
     */
    public void consume() {
        super.consume();
    }
    
    /**
     * Indicates whether this event has been consumed.
     *
     * @return <code>true</code> if the event was consumed;
     *         <code>false</code> if not.
     *
     * @status Documented
     */
    public boolean isConsumed() {
        return super.isConsumed();
    }        
}
