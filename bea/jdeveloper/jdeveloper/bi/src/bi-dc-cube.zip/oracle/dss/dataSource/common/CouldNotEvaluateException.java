/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

/**
 * Thrown if a query could not be evaluated on lookup
 *
 * @status New
 */
public class CouldNotEvaluateException extends QueryException
{
    /**
     * @hidden
     */
    protected String m_queryID = null;

    /**
     * Constructor.
     *
     * @param s  Message to display.
     * @param flag  Flag indicating reason for evaluation error, if known (future use)
     * @param data  Flag-dependent data field indicating reason for evaluation error, if known (future use)
     * @param queryID   ID of query in QueryManager
     * @param e  Previous exception to carry (may be null).
     *
     * @status New
     */
    public CouldNotEvaluateException(String s, int flag, Object data, String queryID, Throwable e) {
        super(s, e);
        m_queryID = queryID;
    }

    /**
     * Constructor.
     *
     * @param s  Message to display.
     * @param flag  Flag indicating reason for evaluation error, if known (future use)
     * @param data  Flag-dependent data field indicating reason for evaluation error, if known (future use)
     * @param queryID   ID of query in QueryManager
     * @param e  Previous exception to carry (may be null).
     * @deprecated
     *
     * @status New
     */
    public CouldNotEvaluateException(String s, int flag, Object data, int queryID, Throwable e) {
        super(s, e);
    }
    
    /**
     * Get the query ID
     *
     * @return ID of query in QueryManager
     * @deprecated
     */
    public int getQueryID()
    {
        return -1;
    }
    
    /**
     * Get the query ID
     * @return Query ID of query
     */
    public String getID()
    {
        return m_queryID;        
    }
}