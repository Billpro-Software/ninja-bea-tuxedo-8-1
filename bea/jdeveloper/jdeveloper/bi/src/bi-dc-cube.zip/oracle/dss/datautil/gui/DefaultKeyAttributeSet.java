/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/

package oracle.dss.datautil.gui;

import java.awt.Color;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import oracle.dss.datautil.KeyAttributeEvent;
import oracle.dss.datautil.KeyAttributeListener;
import oracle.dss.datautil.KeyAttributeSetHashtableImpl;

/**
 * @hidden
 * Methods that are used to set atttributes for specified values.
 *
 * @status hidden
 */

public class DefaultKeyAttributeSet implements KeyAttributeSet, KeyAttributeListener
{
    //-------------------------------------------------------------------------
    // NON PUBLIC CONSTANTS
    //-------------------------------------------------------------------------

    /**
     * The standard tokens supported by the parser.
     * 
     * @status private
     */
    private final Object m_arStandardTokens [ ] = 
    { 
        StyleConstants.Bold,
        StyleConstants.FontFamily,
        StyleConstants.FontSize,
        StyleConstants.Foreground,
        StyleConstants.Italic,
        StyleConstants.Underline
    };
    
    //-------------------------------------------------------------------------
    // NON PUBLIC MEMBERS
    //-------------------------------------------------------------------------

    /**
     * The Hashtable implementation of the KeyAttributeSet methods.
     *
     * @status protected
     */
    protected KeyAttributeSetHashtableImpl m_hashTableImpl = null;
        
    //-------------------------------------------------------------------------
    // CONSTRUCTOR
    //-------------------------------------------------------------------------

    /**
     * Constructs a default DefaultKeyAttributeSet object.
     *
     * @status hidden
     */
    public DefaultKeyAttributeSet ( )
    {
        m_hashTableImpl = new KeyAttributeSetHashtableImpl ( );
    }
    
    //-------------------------------------------------------------------------
    // PUBLIC METHODS
    //-------------------------------------------------------------------------
    
    /**
     * @hidden
     * Initializes the contents of the object using the specified resource
     * file
     *
     * @param strResourceFilePath The specified resource file path.
     *
     * @return The initialized contents of the file.
     *
     * @status hidden
     */
    public Object [ ] getStandardTokens (  )
    {
        return m_arStandardTokens;
    }
    
    /**
     * @hidden
     * Initializes the contents of the object using the specified resource
     * file
     *
     * @param strResourceFilePath The specified resource file path.
     *
     * @return The initialized contents of the file.
     *
     * @status hidden
     */
    public boolean initializeContents ( String strResourceFilePath )
    {
        boolean bRetVal = false;

        m_hashTableImpl.addKeyAttributeListener ( this );                
                
        bRetVal = m_hashTableImpl.initializeContents ( strResourceFilePath );
        
        m_hashTableImpl.removeKeyAttributeListener ( this ); 
                                      
        return bRetVal;
    }
    
    //-------------------------------------------------------------------------
    // Start implementation of KeyAttributeListener interface
    //-------------------------------------------------------------------------
    
    /**
     * @hidden
     * Called when a KeyAttribute name value pair is available.
     * 
     * @status hidden
     */
    public void keyAttributeAvailable ( KeyAttributeEvent keyAttributeEvent )
    {
        parseAttribute ( keyAttributeEvent.getAttributeSet ( ),
                         keyAttributeEvent.getAttributeKey ( ),
                         keyAttributeEvent.getAttributeValue ( ) );
    }
    
    //-------------------------------------------------------------------------
    // End implementation of KeyAttributeListener interface
    //-------------------------------------------------------------------------
    
    //-------------------------------------------------------------------------
    // Start implementation of KeyAttributeSet interface
    //-------------------------------------------------------------------------
    
    /**
     * @hidden
     * Retrieves the list of key objects that contain the specified attribute name
     * and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     *
     * @return The list of key objects
     *
     * @status hidden
     */
    public Vector getAttributeNameList ( Object attribFind, Object attribValue )
    {
        return m_hashTableImpl.getAttributeNameList ( attribFind, attribValue );
    }
    
    /**
     * @hidden
     * Retrieves the attributes of the specified key object
     * The attributes of key that have null names cannot be retrieved.
     *
     * @param key  The name of the key.
     *
     * @return The <code>AttributeSet</code> object.
     *                   
     * @status hidden
     */
    public AttributeSet getKeyAttributes ( String key )
    {
        Hashtable keyAttributes = null;

        keyAttributes = m_hashTableImpl.getKeyAttributes ( key );
        if ( null == keyAttributes )
            return null;
            
        return toAttributeSet ( keyAttributes );
    }
    
    /**
     * @hidden
     * Retrieves the value of an attribute for the specified key object
     *
     * @param key The name of the key.
     * @param attribute The attribute for the specified key.
     *
     * @return The value for the specified attribute.
     *                   
     * @status hidden
     */
    public Object getKeyAttributeValue ( String key, Object attribute )
    {
        return m_hashTableImpl.getKeyAttributeValue ( key, attribute );            
    }
    
    /**
     * @hidden
     * Retrieves the immutable list of key objects.
     *
     * @return The <code>AttributeSet</code> object.
     *                   
     * @status hidden
     */
    public AttributeSet getKeyList ( )
    {
        Hashtable keyList = null;
        
        keyList = m_hashTableImpl.getKeyList ( );
        if ( null == keyList )
            return null;
        
        return toAttributeSet ( keyList );
    }            

    /**
     * @hidden
     * Adds, modifies, or removes an attribute for any key object that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *                   
     * @status hidden
     */
    public boolean updateAttribute ( Object attribFind, Object attribValue, 
                                     Object name, Object value, int actionType )
    {                                  
        return m_hashTableImpl.updateAttribute ( 
                               attribFind, attribValue, name, value, actionType );
    }
    
    /**
     * @hidden
     * Adds, modifies, or removes a set of attributes for any key that
     * contains the specified attribute name and attribute value.
     *
     * @param attribFind The name of the attribute that the key is to contain.
     * @param attribValue The value of the attribute that the key is to contain.
     * @param attribSet The <code>AttributeSet</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateAttributeSet ( Object attribFind, Object attribValue, 
                                        AttributeSet attribSet, int actionType )
    {                                     
        Hashtable newAttributeSet = null;
        
        newAttributeSet = toHashtable ( attribSet );
        if ( null == newAttributeSet )
            return false;
        
        return m_hashTableImpl.updateAttributeSet ( 
                               attribFind, attribValue, newAttributeSet, actionType );
    }
    
    /**
     * @hidden
     * Adds, modifies, or removes an attribute for a specified key.
     *
     * @param key The name of the key.
     * @param name The name of the attribute to add, modify, or remove.
     * @param value The value of the attribute to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateKeyAttribute ( String key, Object name, 
                                        Object value, int actionType )
    {                                       
        return m_hashTableImpl.updateKeyAttribute ( key, name, value, actionType );
    }                                   

    /**
     * @hidden
     * Adds, modifies, or removes a set of attributes for a specified key. 
     *
     * @param key The name of the key.
     * @param attribSet The <code>AttributeSet</code> object that contains the set of
     * attributes to add, modify, or remove.
     * @param actionType A constant that represents the add, modify, or remove action.
     * The valid constants are:
     * <ul>
     * <li> KEYATTRIBUTESET_ATTRIBADD</li>
     * <li> KEYATTRIBUTESET_ATTRIBREMOVE</li>
     * </ul>
     *
     * @return <code>true</code> if the add, modify, or remove action was successful,
     * <code>false</code> if it was not.
     *
     * @see #KEYATTRIBUTESET_ATTRIBADD
     * @see #KEYATTRIBUTESET_ATTRIBREMOVE
     *
     * @status hidden
     */
    public boolean updateKeyAttributeSet ( String key, AttributeSet attribSet, int actionType )
    {
        Hashtable newAttributeSet = null;
        
        newAttributeSet = toHashtable ( attribSet );
        if ( null == newAttributeSet )
            return false;
        
        return m_hashTableImpl.updateKeyAttributeSet ( 
                               key, newAttributeSet, actionType );
    }                                       
    
    //-------------------------------------------------------------------------
    // End implementation of KeyAttributeSet interface
    //-------------------------------------------------------------------------

    //-------------------------------------------------------------------------
    // NON PUBLIC METHODS
    //-------------------------------------------------------------------------

    /**
     * Builds a Attribute Set representation of the specified hashtable.
     *
     * @param attributeSet The attribute set.
     *
     * @status protected
     */
    protected AttributeSet toAttributeSet ( Hashtable attributeSet )
    {
        Enumeration         attributeNames  = null;
        Object              attribute       = null, value = null;
        SimpleAttributeSet  newAttributeSet = null;
        
        if ( null == attributeSet )
            return null;
        
        newAttributeSet = new SimpleAttributeSet ( );
        attributeNames = attributeSet.keys ( );
        while ( attributeNames.hasMoreElements ( ) )
        {
            attribute = attributeNames.nextElement ( );
            value = attributeSet.get ( attribute );
            if ( attribute != null && value != null )
                newAttributeSet.addAttribute ( attribute, value );
        }
        
        return newAttributeSet;
    }        

    /**
     * Builds a hashtable representation of the specified attribute set.
     *
     * @param attributeSet The attribute set.
     *
     * @status protected
     */
    protected Hashtable toHashtable ( AttributeSet attributeSet )
    {
        Hashtable   newAttributeSet = null;
        Enumeration attributeNames  = null;
        Object      attribute       = null, value = null;
        
        if ( null == attributeSet )
            return null;
        
        newAttributeSet = new Hashtable ( );
        attributeNames = attributeSet.getAttributeNames ( );
        while ( attributeNames.hasMoreElements ( ) )
        {
            attribute = attributeNames.nextElement ( );
            value = attributeSet.getAttribute ( attribute );
            if ( attribute != null && value != null )
                newAttributeSet.put ( attribute, value );
        }
        
        return newAttributeSet;
    }        

    /**
     * Parse the key value pair and add it to the attribute set 
     *
     * @status protected
     */
    protected boolean parseAttribute ( Hashtable attributeSet, 
                                       String strKey, String strValue )
    {
        boolean bRetVal = false;
        
        if ( null == attributeSet || 
             null == strKey || 0 == strKey.length ( ) ||
             null == strValue || 0 == strValue.length ( ) )
        {
            return false;
        }

        try 
        {
            if ( strKey.equalsIgnoreCase ( StyleConstants.Bold.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.Bold, 
                                   new Boolean ( strValue ) );
                bRetVal = true;
            }            
            else if ( strKey.equalsIgnoreCase ( StyleConstants.FontFamily.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.FontFamily, 
                                   new String ( strValue ) );
                bRetVal = true;
            }            
            else if ( strKey.equalsIgnoreCase ( StyleConstants.FontSize.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.FontSize, 
                                   new Integer ( strValue ) );
                bRetVal = true;
            }            
            else if ( strKey.equalsIgnoreCase ( StyleConstants.Foreground.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.Foreground,
                                   new Color ( Integer.parseInt ( strValue ) ) );
                bRetVal = true;
            }            
            else if ( strKey.equalsIgnoreCase ( StyleConstants.Italic.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.Italic, 
                                   new Boolean ( strValue ) );
                bRetVal = true;
            }            
            else if ( strKey.equalsIgnoreCase ( StyleConstants.Underline.toString ( ) ) )
            {
                attributeSet.put ( StyleConstants.Underline, 
                                   new Boolean ( strValue ) );
                bRetVal = true;
            }            
            else
            {
                attributeSet.put ( new String ( strKey ), new String ( strValue ) );                                
                bRetVal = true;
            }            
        }
        catch ( Exception exception )
        {
            bRetVal = false;
        }       
        
        return bRetVal;
    }
    
}