/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.metadataManager.common.MDDimension;
import oracle.dss.metadataManager.common.MDObject;
import oracle.dss.util.DataDirector;
import oracle.dss.util.Utility;
import java.lang.reflect.Array;
import oracle.dss.util.xml.ContainerNode;
import java.util.Vector;
import java.util.List;
import java.util.Enumeration;

import oracle.dss.metadataManager.common.MetadataManagerException;
import oracle.dss.metadataManager.common.MM;
import oracle.dss.metadataUtil.MDU;
import oracle.dss.metadataUtil.UserObject;
import oracle.dss.util.LayerMetadataMap;
import oracle.dss.util.persistence.PersistableConstants;
import oracle.dss.util.transform.BaseNode;
import oracle.dss.util.xml.ObjectNode;

/**
 * @hidden
 * Common utilities for data source client and server
 *
 * @status Documented
 */
public class QueryUtil extends Object
{
    /**
     * @hidden
     * Clone a Java 2 list
     */
/*    public static List cloneList(List listToClone) throws CloneNotSupportedException {
        if (listToClone == null) {
            return null;
        }
        List list = null;
        try
        {
            list = (List)listToClone.getClass().newInstance();
        }
        catch (Exception e)
        {
            return null;
        }

        Iterator items = listToClone.iterator();
        VectorClone vc = null;
        while (items.hasNext()) {
            vc = (VectorClone)items.next();
            list.add(vc.clone());
        }
        return list;
    }*/

     // Do the swap on a given DimTree
    public static boolean doSwap(String source, String target, DimTree newTree) throws CloneException
    {
        // Swap the edges
        String tempSource = source == null ? null : source;
        String tempTarget = target == null ? null : target;
        boolean bSuccess = false;
        bSuccess = newTree.swap(new Node(tempSource),
                                        new Node(tempTarget), true);
        return bSuccess;
    }

    /**
     * @hidden
     * @throws oracle.dss.dataSource.common.CloneException
     * @return 
     * @param newTree
     * @param flags
     * @param target
     * @param source
     */
    public static boolean doPivot(String source, String target, int flags, DimTree newTree) throws CloneException
    {
        // Move the edges
        String tempSource = source == null ? null : source;
        String tempTarget = target == null ? null : target;
        BaseNode sourceNode = source == null ? null : new Node(tempSource);
        BaseNode targetNode = target == null ? null : new Node(tempTarget);
        boolean bSuccess = false;
        bSuccess = newTree.move(sourceNode, targetNode,
                                        flags == PivotConstants.PIVOT_AFTER, true);
        return bSuccess;
    }    



    /**
     * @hidden
     * Clone a Java 2 list
     */
/*    public static java.util.List cloneList(java.util.List listToClone) throws CloneNotSupportedException {
        if (listToClone == null) {
            return null;
        }
        java.util.List list = null;
        try
        {
            list = (java.util.List)listToClone.getClass().newInstance();
        }
        catch (Exception e)
        {
            return null;
        }

        java.util.Iterator items = listToClone.iterator();
        VectorClone vc = null;
        while (items.hasNext()) {
            vc = (VectorClone)items.next();
            list.add(vc.clone());
        }
        return list;
    }
*/

    

    // Create an exception class out of a throwable
    public static Exception getException(Throwable e) {
        if (e instanceof Exception) {
            return (Exception)e;
        }
        return new Exception(e.toString());
    }

    /**
     * @hidden
     */
    public static boolean setDirtyEdgeBit(DimTree dimensions, java.util.BitSet edges, Object dimNames, boolean changeDimensionality) {
        if (changeDimensionality)
        {
            for (int i = 0; i < edges.size(); i++)
            {
                edges.set(i);
            }
            return true;
        }
        if (dimensions == null)
        {
            return false;
        }
        int edge = -1;
        if (dimNames instanceof Vector)
        {
            List dims = convertVectorToList((Vector)dimNames);
            edge = dimensions.getEdgeForTuple(dims);
        }
        else
        {
            edge = dimensions.getEdge(new Node((String)dimNames));
        }
        if (edge > -1)
        {
            edges.set(edge);
        }
        return edge >= DataDirector.PAGE_EDGE;
    }
    
    /**
     * @hidden
     * Convert a Vector into a list
     *
     * @param v Vector to convert
     * @return List
     */
    public static java.util.List convertVectorToList(Vector v) {
        if (v == null) {
            return null;
        }
        
        java.util.List retList = new java.util.ArrayList();
        Enumeration e = v.elements();
        while (e.hasMoreElements()) {
            retList.add(e.nextElement());
        }
        return retList;
    }
    
    /**
     * @hidden
     * Convert a List into a Vector
     *
     * @param list list to convert
     * @return Vector
     */
/*    public static Vector convertListToVector(List list) {
        if (list == null) {
            return null;
        }
        
        Vector retV = new Vector();
        Iterator iter = list.iterator();
        while (iter.hasNext()) {
            retV.addElement(iter.next());
        }
        return retV;
    }*/

    /**
     * @hidden
     * Convert a List into a Vector
     *
     * @param list list to convert
     * @return Vector
     */
/*    public static Vector convertListToVector(java.util.List list) {
        if (list == null) {
            return null;
        }

        Vector retV = new Vector();
        java.util.Iterator iter = list.iterator();
        while (iter.hasNext()) {
            retV.addElement(iter.next());
        }
        return retV;
    }*/

    /**
     * @hidden
     * Put the contents of a List into an array and return it
     *
     * @param list list contents to put into an array
     * @return array containing list contents
     * @status New
     */
    public static Object[] copyListToArray(java.util.List list) {
        if (list == null) {
            return null;
        }
        int size = list.size();
        if (size == 0)
            return null;
        Object[] ret = (Object[])Array.newInstance(list.get(0).getClass(), list.size());
        for (int i = 0; i < list.size(); i++) {
            ret[i] = list.get(i);
        }
            
        return ret;
    }


/*    public static void setMDObjectProperty(MDObject obj, String name, Object value)
    {
        obj.setProperty(name, value, 0, 0);
    } 

    public static Object getMDObjectProperty(MDObject obj, String name)
    {
        Property prop = obj.getProperty(name);
        if (prop != null)
            return prop.getObjValue();
        return null;
    }
*/

    /**
     * @hidden
     * Return an XML-ized string array for persistence in an object with the given name
     *
     * @param name name to put on the object
     * @param list string array to store
     * @return persistence object
     */
     public static ContainerNode getXMLStringArray(String name, String elementName, String[] list) {
         ContainerNode container = new ContainerNode(PersistableConstants.XMLNS + ":" + name);
         container.addProperty("name", name.toLowerCase());
         if (list != null) {
             for (int i = 0; i < list.length; i++) {
                 ObjectNode node = new ObjectNode(PersistableConstants.XMLNS + ":" + elementName);
                 node.addProperty("name", list[i]);
                 container.addContainedObject(node);
                 //container.addContainedObject(new PropertyNode(elementName, list[i]));
             }
         }
         return container;
     }
    
    /**
     * @hidden
     * Return a string array from its XML representation
     *
     * @param XML object representation
     * @return string array
     */
    public static String[] getStringArrayFromXML(ContainerNode container) {
        Vector temp = new Vector();
        ObjectNode prop;
        Enumeration values = container.getContainedObject();
        while (values.hasMoreElements()) {
            prop = (ObjectNode)values.nextElement();
            try {
              temp.addElement(prop.getPropertyValueAsString("name"));
            }catch(Exception e){}
        }
        return (String[])Utility.copyVectorToArray(temp);
    }

    /**
     * @hidden
     * Return the first measure in the database as a default
     */
/*    public static String getFirstMeasure(MDMeasure[] measures) {
        // Get first measure
        if (measures != null && measures.length > 0) {                        
            return measures[0].getUniqueID();
        }
        return null;
    }*/
     
    /**
     * @hidden
     * Compare two two-dimensional string arrays for exact match
     */
    public static boolean compareStringArrays(String[][] s1, String[][] s2) {
        if (s1 == null && s2 == null) {
            return true;
        }
        if (s1 == null || s2 == null) {
            return false;
        }
        if (s1.length != s2.length) {
            return false;
        }
        for (int i = 0; i < s1.length; i++) {
            if (!compareStringVectors(s1[i], s2[i])) {
                return false;
            }
        }
        return true;
    }
    

    
    
    /**
     * @hidden
     * Output OLAPI trail information
     *
     */
/*    public static void olapiOutput(QueryState state, QueryManagerInterface qm, String msg)
    {
        if (state.getPropertySupport().getProperty(QueryConstants.PROPERTY_DEBUG_MODE).equals(new Boolean(true)))
        {
            qm.getErrorHandler().trace("OLAPI:: " + msg, "", "");
        }
    }    

        
    protected static final String UNIQUE_SEPARATOR = "::";
    protected static final String UNIQUE_DEFAULT_NAME = "DEFAULT";
    public static final int UNIQUE_ID = 0;
    public static final int UNIQUE_LEVEL = 1;
    public static final int UNIQUE_HIER = 2;*/
    
    /**
     * @hidden
     * Construct OLAPI unique value ID without using OLAPI
     */
/*    public static String getUniqueValue(String value, String hier, String level)
    {
        if (hier == null)
            hier = UNIQUE_DEFAULT_NAME;
        if (level == null)
            level = UNIQUE_DEFAULT_NAME;
        return hier + UNIQUE_SEPARATOR + level + UNIQUE_SEPARATOR + value;
    }
    
    public static String getLocalValue(String uniqueValue, int part)
    {   
        // Find first separator
        int pos1 = uniqueValue.indexOf(UNIQUE_SEPARATOR);
        
        // No separators: must be ID value straight up
        if (pos1 == -1)
        {
            switch (part)
            {
                case UNIQUE_ID:
                    return uniqueValue;
                default:
                    return null;
            }
        }
            
        int sepLength = UNIQUE_SEPARATOR.length();
        // find second separator if there was a first separator
        int pos2 = uniqueValue.indexOf(UNIQUE_SEPARATOR, pos1+sepLength);
        if (pos2 == -1)
        {
            // No second separator: means hier and value
            switch (part)
            {
                case UNIQUE_ID:
                    return uniqueValue.substring(pos1+sepLength);
                case UNIQUE_HIER:
                    return uniqueValue.substring(0, pos1-1);
                case UNIQUE_LEVEL:
                    return null;
            }
        }
        // We have it all
        switch (part)
        {
            case UNIQUE_ID:
                return uniqueValue.substring(pos2+sepLength);
            case UNIQUE_HIER:
                return uniqueValue.substring(0, pos1-1);
            case UNIQUE_LEVEL:
                return uniqueValue.substring(pos1+sepLength, pos2-1);
        }
        return null;
    }*/
    

    public static String getLayerMetadata(String type, MDObject obj)
    {
        if (type == null || obj == null)
        {
            return null;
        }
        if (type.equals(LayerMetadataMap.LAYER_METADATA_NAME))
            return obj.getUniqueID();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL))
            return obj.getLongLabel();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_DISPLAYNAME))
            return obj.getName();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL))
            return obj.getShortLabel();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_MEDIUMLABEL))
            return obj.getMediumLabel();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_LONGLABEL_PLURAL) && obj instanceof MDDimension)
            return ((MDDimension)obj).getLongPluralLabel();
        if (type.equals(LayerMetadataMap.LAYER_METADATA_SHORTLABEL_PLURAL) && obj instanceof MDDimension)
            return ((MDDimension)obj).getShortPluralLabel();
        return null;
    }

    
    /**
     * @hidden
     * Compare two string arrays for exact match
     */
    public static boolean compareStringVectors(String[] s1, String[] s2) {
        if (s1 == s2) {
            return true;
        }
        if (s1 == null || s2 == null) {
            return false;
        }
        if (s1.length != s2.length) {
            return false;
        }
        for (int i = 0; i < s1.length; i++) {
            if (!s1[i].equals(s2[i])) {
                return false;
            }
        }
        return true;
    }
    
    // Build list of strings from array for error reporting
/*    public static String strList(String[] list) {
        String l = "";
        if (list == null) {
            return l;
        }
        for (int m = 0; m < list.length; m++) {
            l += list[m] + ",";
        }
        return l;
    }    
*/
    /**
     * @deprecated As of 2.8.0.50, should be using SavedSelectionStep
     */
     // blm - Selection code moved to dvt-olap
/*    public static Selection loadFavorite(FavoriteStep fs, QueryFunctions query) throws BCJException
    {
       Selection sel = fs.getSelection();
       try
       {
           String favoritePath = fs.getSelectionID();
           if (query != null && sel == null && favoritePath != null && !favoritePath.equals(""))
           {
                // Try to load the selection from the MetadataManager
                sel = (Selection)query.getMetadataManager().getMDRoot().lookup(favoritePath);
                fs.setSelection(sel);
           }
       }
       catch (javax.naming.NamingException e)
       {
           throw new BCJException(e.getMessage(), e);
       }
       return sel;
    }*/



    // Convert a list of MDDimensions to a list of nodes
/*    public static Node[] convertFromMDDimensions(Vector dimList)
    {
        Node[] newList = new Node[dimList.size()];
        for (int i = 0; i < newList.length; i++) {
            String name = ((MDDimension)dimList.elementAt(i)).getUniqueID();
            newList[i] = new Node(name);
        }

        return newList;
    }*/
    
   /**
     * Compare two arrays and return true if they are exactly equal except for order
     *
     * @param list1 first list to compare
     * @param list2 second list to compare
     * @return true if the lists' contents are equal
     */
    public static boolean compareArrays(Object[] list1, Object[] list2) {
        if (list1 == list2)
            return true;
            
        if (list1 == null || list2 == null)
            return false;
            
        // Note: this could use a faster algorithm but for now, it's being used
        // to compare dimension lists so it shouldn't be that slow
        if (list1.length != list2.length)
            return false;
            
        boolean found = false;
        // Scan the first list
        for (int i = 0; i < list1.length; i++) {
            for (int j = 0; j < list2.length; j++)
                if (list2[j].equals(list1[i])) {
                    found = true;
                    break;
                }
            if (!found)
                return false;
            found = false;                
        }
        return true;
    }    

    // Return a List set of dependent dimension lists based on dimension layout
    // blm - Selection code moved to dvt-olap
/*    public static List[][] getDependentDimensionLayout(String[][] dims, SelectionList sels)
    {
        if (dims == null)
        {
            return null;
        }
        List[][] depLayout = new List[dims.length][];
        for (int edge = 0; edge < dims.length; edge++) {
            if (dims[edge] != null) {
                depLayout[edge] = new List[dims[edge].length];
                for (int node = 0; node < dims[edge].length; node++) {
                    depLayout[edge][node] = getDependentDimensions(dims[edge][node], sels);
                }
            }
        }
        return depLayout;
    }



    // Return a boolean set of asymmetric flags based on dimension layout
    public static boolean[][] getAsymLayout(String[][] dims, SelectionList sels)
    {
        if (dims == null) {
            return null;
        }
        boolean[][] asymLayout = new boolean[dims.length][];
        for (int edge = 0; edge < dims.length; edge++) {
            if (dims[edge] != null) {
                asymLayout[edge] = new boolean[dims[edge].length];
                for (int node = 0; node < dims[edge].length; node++) {
                    asymLayout[edge][node] = isAsymmetric(dims[edge][node], sels);
                }
            }
        }
        return asymLayout;
    }

    public static List getDependentDimensions(String dim, SelectionList sels)
    {
        Selection sel = sels.find(dim);
        if (sel == null) {
            return null;
        }
        return QueryUtil.convertVectorToList(sel.getDependentDimensions());
    }

    // Is a selection asymmetric?
    public static boolean isAsymmetric(String dim, SelectionList sels)
    {
        // Check for dependent selections
        Selection sel = sels.find(dim);
        return (sel != null && sel.isAsymmetric());
    }
    

    // Merge two measure lists and create the union of them
    public static String[] mergeMeasures(int action, String[] newMeasures, String[] oldMeasures)
    {
        if (action == Step.SELECT)
            return newMeasures;
            
        // Put old measures into a vector
        Vector oldMeas = Utility.copyArrayToVector(oldMeasures);
        switch (action) {
            case Step.ADD:
                for (int meas = 0; meas < newMeasures.length; meas++) {
                    // Check each new measure against the old list
                    if (oldMeas.indexOf(newMeasures[meas]) == -1) {
                        // Not found: add it
                        oldMeas.addElement(newMeasures[meas]);
                    }                    
                }
                return (String[])Utility.copyVectorToArray(oldMeas);
            case Step.REMOVE:            
                for (int meas = 0; meas < newMeasures.length; meas++)
                    oldMeas.removeElement(newMeasures[meas]);                    
                return (String[])Utility.copyVectorToArray(oldMeas);
        }
        
        return null;
    }    
   
    // Determine if the given object (list, string, selection) represents the measure
    public static boolean isMeasure(MetadataFunctions metadata, Object obj) throws InvalidMetadataException
    {
        if (obj instanceof Selection)
        {
            return isMeasure(metadata, ((Selection)obj).getDim());
        }
        else if (obj instanceof String)
        {
            return metadata.isMeasure((String)obj);
        }
        // Tuple step can't be the measure selection
        return false;
    }    
  */  
    // Determine if a given dimension is in the tree
    /*public static boolean isDimInTree(String dimName, DimTree dimensions)
    {
        if (dimensions == null)
            return false;

        return dimensions.getNode(new Node(dimName)) > -1;
    } */   
    
    
    // blm - Selection code moved to dvt-olap
     // Return a list of tuple-type selections
/*    public static List getTupleSelections(List selections)
    {
        List retList = new ArrayList();
        if (selections != null)
        {
            Iterator sels = selections.iterator();
            Selection sel = null;
            while (sels.hasNext())
            {
                sel = (Selection)sels.next();
                if (sel.isTupleSelection())
                {
                    retList.add(sel);
                }
            }
        }
        return retList;
    }
*/
    
    // Certain fallback selection
    // blm - Selection code moved to dvt-olap
/*    public static Step getFallbackSelection(String dimension, MDHierarchy hierarchy, DimTree layout, MetadataManagerServices mm, QueryManagerInterface qm, QueryFunctions query) throws InvalidStepArgException, InvalidMetadataException
    {
        // Can't do this on ET tier (mm will be null)--can't handle backup sel for null measure selection
        if (mm != null && getMeasureID(mm).equals(dimension))
        {
            // If we're given a layout, we can't just take the first one: we must take the first one whose
            // dimensionality is completely covered by the layout we have, if data is desired
            MemberStep step = new MemberStep(dimension);
            step.setInitial(true);
            if (layout != null)
            {
                // Check each measure in the available measure list until we find one where
                // every dimension is present in the layout
                MDMeasure[] measures = query.getMMMeasures();
                MDDimension[] dimList = null;
                for (int i = 0; i < measures.length; i++)
                {
                    try
                    {
                        dimList = mm.dimensionalityOfMeasures(new MDMeasure[] {measures[i]}, MM.UNION);
                    }
                    catch (MetadataManagerException mme)
                    {
                        throw new InvalidMeasureException(MessageFormat.format(qm.getResourceString("Invalid measure specified"), new String[] {measures[i].getUniqueID()}), measures[i].getUniqueID(), mme);
                    }
                    if (dimList != null)
                    {
                        boolean bNotFound = false;
                        for (int d = 0; d < dimList.length; d++)
                        {
                            BaseNode n = layout.getNode(dimList[d].getUniqueID());
                            if (n == null)
                            {
                                // Can't find it: this measure isn't acceptable
                                bNotFound = true;
                                break;
                            }
                        }
                        if (bNotFound)
                        {
                            continue;
                        }
                        // We made it through: every dimension in the list is covered in our
                        // layout.  Use this measure and return
                        step.addMember(measures[i].getUniqueID());
                        return step;
                    }
                }
            }
            else
            {
                String meas = QueryUtil.getFirstMeasure(query.getMMMeasures());
                if (meas != null)
                {
                    step.addMember(meas);
                }
            }
            return step;
        }
        FirstLastStep step = new FirstLastStep(dimension);
        step.setFirstLastType(FirstLastStep.FIRST);
        step.setNumValues(new Integer(1));
        if (hierarchy != null)
        {
            // Do first one at first level
            // Get first level
            MDLevel[] levels = null;
            try
            {
                levels = hierarchy.getLevels();
            }
            catch (MetadataManagerException mme)
            {
                throw new InvalidHierarchyException(mme.getMessage(), hierarchy.getUniqueID(), dimension, null, mme);
            }
            String level = null;
            if (levels != null && levels.length > 0)
            {
                AllStep allStep = new AllStep(dimension);
                allStep.setHierarchy(hierarchy.getUniqueID());
                level = levels[0].getUniqueID();
                Vector vLevels = new Vector();
                vLevels.addElement(level);
                allStep.setLevels(vLevels);
                return allStep;
            }
            else
            {
                // value based hierarchy
                FamilyStep fs = new FamilyStep(dimension, hierarchy.getUniqueID(), FamilyStep.OP_FIRSTANCESTORS, null, false);
                return fs;
            }
        }

        return step;
    }    
    
    // Assign a default step to this selection: return true if it was measure
    public static boolean assignDefault(Selection sel, DimTree layout, MetadataManagerServices mm, QueryManagerInterface qm, QueryFunctions query) throws InvalidStepArgException, MetadataManagerException, QueryException {
        // Create an olapi definition temporarily to evaluate the step: in reality, generate a step and
        // add it to the selection object
        // Select top three

        // gek 9/29/99 Specify the default hierarchy for the default selection
        Step genstep = null;
        if (mm != null)
        {
//            m_query.debugOutput("Getting hierarchy information from OLAPI...");
            MDDimension dimension =
                (MDDimension)mm.getMDObject(MM.UNIQUE_ID, sel.getDimension(), MM.DIMENSION);

            if (dimension != null)
            {
                MDHierarchy hierarchy = dimension.getDefaultHierarchy();
                if (hierarchy != null)
                {
                    // Do first one at first level
                    // Get first level
                    MDLevel[] levels = hierarchy.getLevels();
                    String level = null;
                    if (levels != null && levels.length > 0)
                    {
                        level = levels[0].getUniqueID();
                        AllStep step = new AllStep(sel.getDimension());
                        sel.setHierarchy (hierarchy.getUniqueID());
                        step.setHierarchy(hierarchy.getUniqueID());
                        Vector levelList = new Vector();
                        levelList.addElement(level);
                        step.setLevels(levelList);
                        genstep = step;
                    }
                    else
                    {
                        genstep = getFallbackSelection(sel.getDimension(), hierarchy, layout, mm, qm, query);
                        if (hierarchy != null)
                        {
                            sel.setHierarchy(hierarchy.getUniqueID());
                        }
                    }
                }
                else
                {
                    genstep = getFallbackSelection(sel.getDimension(), hierarchy, layout, mm, qm, query);
                    if (hierarchy != null)
                    {
                        sel.setHierarchy(hierarchy.getUniqueID());
                    }
                }
            }
            else
            {
                throw new InvalidDimensionException(MessageFormat.format(qm.getResourceString("Invalid dimension specified"), new String[] {sel.getDimension()}), sel.getDimension(), null);
            }

            boolean isMeasure = getMeasureID(mm).equals(dimension);
            sel.addStep(genstep);
            if (!isMeasure)
            {
                sel.setFirstStepDefault(true);
                //query.setDefaultsGenerated(true);
            }
            return isMeasure;
        }
        return false;
    }
  */  
    // Return the correct map for the given dimension name and edge
/*    public static MetadataMap getMetadataMap(String dimname, int edge, MetadataMap map, QueryState state) throws MetadataManagerException
    {
        MetadataMap tempMap = null;
        if (map != null) {
            tempMap = map;
        }
        else {
            // Start specific, fall back
            tempMap = state.getMapSupport().getMetadataMap(dimname, state.isTimeDimension(dimname));
            if (tempMap == null)
                tempMap = state.getMapSupport().getMetadataMap(edge);
            if (tempMap == null)
            {
                // If no specific metadata for time, check if dim is time
                // and add in the time specific metadata
                tempMap = state.getMapSupport().getMetadataMap(null, state.isTimeDimension(dimname));
            }
        }
        return tempMap;
    }
    */
    
    /**
     * @hidden
     * Determine if we're suppressing anything locally (rows or columns)
     */
/*    public static boolean isNASuppressedLocally(QueryState state, QueryManagerInterface qm)
    {
        return areColumnsSuppressedLocally(state, qm) || areRowsSuppressedLocally(state, qm);        
    }
    */
    /**
     * @hidden
     */
/*    protected static boolean localSuppressionOn(QueryState state, QueryManagerInterface qm)
    {
        boolean localSuppressionOn = QueryConstants.DEFAULT_SUPPRESS_NA_LOCALLY;
        Object obj = state.getPropertySupport().getProperty(QueryConstants.PROPERTY_SUPPRESS_NA_LOCALLY);
        if (obj instanceof Boolean)
        {
            localSuppressionOn = ((Boolean)obj).booleanValue();
        }        
        return localSuppressionOn && !VersionCheck.is102(qm);
    }
    */
    /**
     * @hidden
     * Determine if columns are suppressed locally, currently
     */
/*    public static boolean areColumnsSuppressedLocally(QueryState state, QueryManagerInterface qm)
    {
        return edgeSuppressedLocally(DataDirector.COLUMN_EDGE, state, qm);
    }*/

    /**
     * @hidden
     * Determine if rows are suppressed locally, currently
     */
    /*public static boolean areRowsSuppressedLocally(QueryState state, QueryManagerInterface qm)
    {
        return edgeSuppressedLocally(DataDirector.ROW_EDGE, state, qm);
    }*/
    
    /**
     * @hidden
     */
/*    public static boolean edgeSuppressedLocally(int edge, QueryState state, QueryManagerInterface qm)
    {
        if (localSuppressionOn(state, qm))
            return state.getPropertySupport().getSuppressionState(edge) != DataDirector.NO_SUPPRESSION;
            
        return false;
    }*/
    
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public static Vector walkPersistableStructuresMemberLevels(Selection sel, QueryState state) throws SelectionException
    {
        return sel.areMemberLevelPropertiesSet(state, sel.getDimension(), sel.getHierarchy(), null);        
    }*/
    
    /**
     * @hidden
     */
     // blm - Selection code moved to dvt-olap
/*    public static Vector walkPersistableStructuresMemberLevels(Step step, QueryState state) throws SelectionException
    {
        return step.areMemberLevelPropertiesSet(state, step.getDimension(), step.getHierarchy(), null);
    }
    
    

    public static boolean hierDrillOnSel(Selection sel, DimTree dimensions, QueryState state, QueryManagerInterface qm) throws QueryException, SelectionException, MetadataManagerException, InvalidStepArgException
    {
        if (state.getPropertySupport().isHierarchicalDrilling())
        {
            // Always true
            return true;
        }
        // If we can have asymmetric drilling, and there is more than one dimension in this cube,
        // then we can't do hier drilling unless forced
        if (state.getPropertySupport().isAsymmetricDrilling() && dimensions.getTotalNodes() > 1)
        {
            // If we can have asymmetry, then we can't have hierarchical drills unless forced
            // by the options
            return false;
        }
        Vector stepGroups = new Vector();
        stepGroups.addElement(StepAnalyzer.getSteps(sel, true, state, qm));
        return (StepAnalyzer.isHierarchical((Vector)stepGroups.elementAt(0), state, qm) && !StepAnalyzer.anyAdds(sel) && !sel.hasAsymmetricDrill());
    }
     
*/
    public static String dumpState(String location, Object selobj, QueryState state, MetadataFunctions metadataManager)
        {
        /** gek 11/03/06
        String classname = CubeCursor.class.getName();
        */
      
        String routine = "dumpState";
            // blm - Selection code moved to dvt-olap
/*        List sels = new ArrayList();
        if (selobj instanceof Selection) {
            sels.add(selobj);
        }
        else
            sels = state.getSelections();*/
        String message = "===========MIDDLE TIER QUERY STATE===========\n";
        message += "In " + location + ":\n";
            // blm - Selection code moved to dvt-olap
/*        message += "Selections:\n";
        if (sels != null)
        {
            Iterator sel = sels.iterator();
            while (sel.hasNext())
                message += sel.next() + "\n";
        }*/
        message += "\nMeasures:\n";
        Vector calcList = new Vector();
        if (state.getMeasures() != null)
            for (int meas = 0; meas < state.getMeasures().length; meas++)
            {
                message += state.getMeasures()[meas] + "\n";

                try
                {
                    // Get the MDobject
                    if (metadataManager != null)
                    {
                        MDObject mdobj = metadataManager.getMDObject(MM.UNIQUE_ID, state.getMeasures()[meas], MM.MEASURE);
                        if (mdobj != null)
                        {
                            // Retrieve the CalcStep wrapper
                            UserObject userObject =
                                mdobj.getUserObject (MM.PERSISTENCE_OBJECT, MDU.PERSISTENCE);

                            // Retrieve the actual CalcStep object
                            // blm - Selection code moved to dvt-olap
/*                            if (userObject != null)
                            {
                                if (userObject.getObject() instanceof Step)
                                {
                                    Step step = (Step) userObject.getObject();
                                    if (step != null)
                                    {
                                        calcList.addElement(step);
                                    }
                                }
                            }*/
                        }
                    }
                }
                catch (MetadataManagerException mme)
                {
                }
            }
        if (calcList.size() > 0)
        {
            message += "\nCalculations:\n";
            Enumeration calcs = calcList.elements();
            while (calcs.hasMoreElements())
            {
                message += calcs.nextElement().toString() + "\n";
            }
        }
        message += "\nDimension Layout:\n";
        if (state.getDimTree() != null)
            message += state.getDimTree().toString() + "\n";
        if (state.getPropertySupport() != null)
        {
            message += state.getPropertySupport().toString() + "\n";
        }
        message += "===========END STATE===========\n";
        return message;
        }

}