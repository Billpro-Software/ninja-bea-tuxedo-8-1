/* Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
All rights reserved. */
package oracle.dss.metadataManager.server.drivers;

import java.util.Hashtable;
import javax.naming.Name;
import javax.naming.directory.Attributes;
import oracle.dss.metadataManager.common.MDFolder;
import oracle.dss.metadataManager.common.MetadataManagerException;

public interface WritableDriver
{
    // to be remove (temporary to fix bug#2799435)
    public MDFolder getMDFolderUsingFullPath(String fullPath) throws MetadataManagerException;

    // new methods
    public Attributes bind(MDFolder folder, Name name, Object object, Attributes attributes, String bindOption) throws MetadataManagerException;
    public Object lookup(MDFolder folder, Name name, Hashtable args, Attributes options) throws MetadataManagerException;
}