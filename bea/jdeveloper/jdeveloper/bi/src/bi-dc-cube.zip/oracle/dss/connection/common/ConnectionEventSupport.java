// Copyright (c) 2000, 2009, Oracle and/or its affiliates. 
// All rights reserved. 

/**
 * Support class for firing connection events.  Connection bean class can
 * instantiate this class and fire desired events.
 *
 * @status New
 */

package oracle.dss.connection.common;

import java.util.Vector;
import java.lang.Class;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

/**
 * @hidden
 */
public class ConnectionEventSupport {

   private Vector listeners;
   private Object source;

  /**
   * Constructor
   *
   * @param sourceBean    Bean that instantiates the ConnectionEventSupport.
   *
   * @status New
   */
  public ConnectionEventSupport( Object sourceBean ) {
    listeners = new Vector();
    source = sourceBean;
  }

  /**
   * Adds a Connect listener
   *
   * @param listener    Listener that wants to register with Connection bean
   *
   * @status New
   */
  public synchronized void addConnectionListener( ConnectionListener listener ) {
    if( !listeners.contains( listener ) )
      listeners.addElement( listener );
  }

  /**
   * remove a Connect listener
   *
   * @param listener    Listener that do not wants to listen to Connection events
   *
   * @status New
   */
  public synchronized void removeConnectionListener( ConnectionListener listener ) {
    if( listeners.contains( listener ) )
      listeners.removeElement( listener );
  }

  /**
   * Fires connecting event
   *
   * @status New
   */
  public void fireConnectingEvent() {
    fireConnectionEvent( "connecting", false );
  }

  /**
   * Fires connected event
   *
   * @status New
   */
  public void fireConnectedEvent() {
    fireConnectionEvent( "connected", false );
  }

  /**
   * Fires disconnecting event
   *
   * @return      <code>true</code> if event was consumed
   *              <code>false</code> if event was not consumed
   * @status New
   */
  public boolean fireDisconnectingEvent() {
    return fireConnectionEvent( "disconnecting", true );
  }

  /**
   * Fires disconnected event
   *
   * @status New
   */
  public void fireDisconnectedEvent() {
    fireConnectionEvent( "disconnected", false );
  }

  /**
   * @hidden
   * Helper method for firing events
   *
   * @param methodName    Method that needs to be called to fire event
   * @param isConsumable  <code>true</code> if event is consumable
   *                      <code>false</code> if event is not consumable
   *
   * @return      <code>true</code> if event was consumable and was consumed
   *              <code>false</code> if event was not consumable and was not consumed
   * @status New
   */
  private boolean fireConnectionEvent( String methodName, boolean isConsumable ) {
    ConnectionEvent event = new ConnectionEvent( source, isConsumable );

    Vector tempLst;
    synchronized( source ){
      tempLst = (Vector) listeners.clone();
    }

    int listenersCount = tempLst.size();

    for( int i = 0; i < listenersCount; i++ ) {
      ConnectionListener listener = (ConnectionListener) tempLst.elementAt(i);
      if( methodName.equals( "connecting" ) )
        listener.connecting( event );
      else if( methodName.equals( "connected" ) )
        listener.connected( event );
      else if( methodName.equals( "disconnecting" ) ) {
        listener.disconnecting( event );
        if( isConsumable && event.isConsumed() )
          return true;
      }
      else if( methodName.equals( "disconnected" ) )
        listener.disconnected( event );
    }
    return false;
  }
}
