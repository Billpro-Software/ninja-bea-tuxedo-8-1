/*
 * HyperLinkLabel.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 *
 */

package oracle.dss.datautil.gui.hierLevel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.event.MouseInputAdapter;

/**
 * @hidden
 */
public class HyperLinkLabel extends JLabel {
    // The property determining whether the label is enabled
    // If this property is true, label looks like a hyperlink
    // the mouse pointer over the label becomes a hand pointer, and the
    // popup is enabled
    private boolean m_blnIsEnabled = true;
    
    // The popup menu which is displayed when the label is clicked on
    protected JPopupMenu m_editMenu = null;

    // Colors used for painting this control
    private Color m_focusForeColor = UIManager.getColor("ComboBox.selectionForeground");
    private Color m_focusBackColor = UIManager.getColor("ComboBox.selectionBackground");
    private Color m_hyperForeColor = Color.blue;  
    private Color m_lblBackColor1 = UIManager.getColor("Panel.background");
    private Color m_lblBackColor2 = UIManager.getColor("ComboBox.background");
    
   
    /**
    * "NEW"
    * Constructor which creates a hyper-link label which pops up a menu when clicked.
    *
    */
    public HyperLinkLabel() {
        super();
        // Set the label properties
        setOpaque(true);
        setBorder(null);
        setDoubleBuffered(true);
        setEnabled(true);
        setRequestFocusEnabled(true);
        
        // Initialize the popup menu
        m_editMenu = new JPopupMenu();
        m_editMenu.setDoubleBuffered(true);  
        
        // Create and add the listeners
        HyperMouseInputListener mouseInputListener = new HyperMouseInputListener();
        addMouseListener(mouseInputListener);
        addMouseMotionListener(mouseInputListener);
        addFocusListener(new HyperFocusListener());
        registerKeyboardActions();
    }

    /**
    * "NEW"
    * Constructor which creates a hyper-link label with the given text.
    *
    * @param text to be displayed in the label
    */
    public HyperLinkLabel(String text) {
        this();
        super.setText(text);
    }

	
   /** "NEW"
    * Sets the boolean property determining if the hyperlink label is enabled.
    * If yes, the label displays its text as blue and underlined, the popup menu
    * is displayed when the mouse is pressed on the label, and the mouse pointer changes
    * to a hand when the mouse is over the label.
    * Otherwise, the label displays its text as a regular JLabel, and
    * the popup menu does not display.
    *
    * @param isEnabled the boolean value of the enabled property
    */
    public void setEnabled(boolean isEnabled) {
        if (m_blnIsEnabled != isEnabled) {
            m_blnIsEnabled = isEnabled;
            // Do not request the focus, if disabled
            setRequestFocusEnabled(isEnabled);
            // Reset the keyboard actions
	    	resetKeyboardActions();
	    	if (isEnabled) {
        		registerKeyboardActions();
        	}
            repaint();
        }
    }
    
    /**
    * "NEW"
    * Adds the given component to the HyperLinkLabel's JPopup.
    *
    * @param c - Component to be added to the popup
    */
    public void setContents(Component c) {
        m_editMenu.removeAll();
        m_editMenu.add(c);
    }
     
    /**
    * "NEW"
    * The paint method is overriden to display the label's text as blue and underlined.
    */
    public void paint(Graphics g) {
        Color foreColor = m_hyperForeColor;
        Color bkgColor = m_lblBackColor1 != null ? m_lblBackColor1 : m_lblBackColor2;
        
        // Save the old Color
        Color oldColor = g.getColor();
        
        // Get the dimensions
        int width = getSize().width;
        int height = getSize().height;
        FontMetrics metrics = g.getFontMetrics();
        String text = getText();
        
        if (m_blnIsEnabled) {
            // If focused, draw the label with the selection colors
            if (hasFocus() && !m_editMenu.isVisible()) {
                foreColor = m_focusForeColor;
                bkgColor = m_focusBackColor;
            }
            // Fill the background
            g.setColor(bkgColor);
            g.fillRect(0, 0, width, height);
            
            // Draw the foreground
            g.setColor(foreColor);
            // Center the text String
            int x = width/2 - metrics.stringWidth(text)/2;
            int y = metrics.getAscent();
            
            // Draw the text 
            g.drawString(text, x, y);
            // Draw the blue underline
            g.drawLine(x, y+1, width-x, y+1);
            // Reset the old Color
            g.setColor(oldColor);
        }
        else {
            // Draw the text using the usual label style
            super.paint(g);
        }
    }
    
    
    /**
    * "NEW"
    * This method is overriden from the superclass, to allow the 
    * HyperLinkLabel to have keyboard focus.
    */
    public boolean isFocusTraversable() {
		// Allow focus traversal only if enabled
		return (m_blnIsEnabled);
	}


    // Registers the keyboard actions to which the hyperlink reacts
    protected void registerKeyboardActions() { 
        // Register the actions to display the popup menu
           
        // Register the "Space" keystroke
        registerKeyboardAction(new MenuShowAction(), 
            KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), 
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT); 
            
        // Register the "ALT+Down" keystroke
        registerKeyboardAction(new MenuShowAction(), 
            KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, KeyEvent.ALT_MASK), 
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT); 
            
        // Register the actions to hide the popup menu
           
        // Register the "ESC" keystroke
        registerKeyboardAction(new MenuHideAction(), 
            KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), 
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT); 
            
        // Register the "ALT+Up" keystroke
        registerKeyboardAction(new MenuHideAction(), 
            KeyStroke.getKeyStroke(KeyEvent.VK_UP, KeyEvent.ALT_MASK), 
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    // Toggles the display of the edit popup
    protected void toggleDisplayEditMenu() {
        if (m_editMenu != null) {
            if (m_editMenu.isVisible()) {
                hideEditMenu();
            }
            else {
                showEditMenu();
            }
        }   
    }
    
    // Displays the edit menu and selects the currently displayed item
    protected void showEditMenu() {
        if (!m_editMenu.isVisible()) {
            m_editMenu.show(this, 0, this.getBounds().height);
        }
    }
    
    // Hides the edit menu and returns the focus to the label
    protected void hideEditMenu() {
        if (m_editMenu.isVisible()) {
            m_editMenu.setVisible(false);
            this.requestFocus();
        }
    }


    // Listener for the mouse input events on the label
    private class HyperMouseInputListener extends MouseInputAdapter {
        // When mouse is pressed, toggle the display of the popup menu
        public void mousePressed(MouseEvent e) {
        	if (m_blnIsEnabled) {
            	HyperLinkLabel.this.requestFocus();
		        toggleDisplayEditMenu();
            }
        }
        
        // When mouse enters the label, change the cursor to "hand", unless the label is not a hyperlink
        public void mouseEntered(MouseEvent e) {
			// Set the cursor to hand, if enabled
            if (m_blnIsEnabled) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            else {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        }
        // When the mouse exits the label, set the cursor back to default
        public void mouseExited(MouseEvent e) {
        	// Set the cursor back to default
            setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        }
    }
    
    // FocusListener on the hyperlink label
    private class HyperFocusListener implements FocusListener {
		public void focusLost(FocusEvent e) {
            //System.out.println("Focus lost on the HyperLinkLabel.");
			repaint();	
		}
		
		public void focusGained(FocusEvent e) {
		    //System.out.println("Focus gained on the HyperLinkLabel.");
        	repaint();
		}
	}
	
	// The show action called when the user presses the "Space" or "ALT+Down"
	// on the focused hyperlink label
	private class MenuShowAction extends AbstractAction {
		public void actionPerformed(ActionEvent e) {
			showEditMenu();	
		}
	}
    
    // The show action called when the user presses the "ESC" or "ALT+Up"
    // on the focused hyperlink label
    private class MenuHideAction extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            hideEditMenu();    
        }
    }
}