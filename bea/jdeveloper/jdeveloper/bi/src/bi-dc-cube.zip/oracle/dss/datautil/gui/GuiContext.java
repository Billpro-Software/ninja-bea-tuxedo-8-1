/*
** Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
** All rights reserved. 
**
*/
package oracle.dss.datautil.gui;

import java.awt.Frame;

import oracle.dss.metadataManager.client.MetadataManager;

import oracle.dss.datautil.QueryContext;

//HBR: Persistence removal
//import oracle.dss.persistence.persistencemanager.common.PersistenceManager;
      
/**
 * Contains methods that common data-utility graphical user interface   
 * objects require for instantiation, often in conjunction with <code>QueryBuilder</code> 
 * or <code>CalcBuilder</code>.
 *
 * @status Documented
 */
public interface GuiContext
    {    
    /**
     * Specifies the <code>MetadataManager</code> object.
     *
     * @param metadataManager The <code>MetadataManager</code> object.
     *
     * @status Documented
     */
    public void setMetadataManager (MetadataManager metadataManager);

    /**
     * Retrieves the <code>MetadataManager</code> object.
     *
     * @return The <code>MetadataManager</code> object.
     *         
     * @status Documented
     */
    public MetadataManager getMetadataManager ();
    
    /**
     * Specifies the parent <code>Frame</code> object.
     *
     * @param  frameParent The parent <code>Frame</code> object.
     *
     * @status Documented
     * @deprecated As of 2.6.0.4, replaced by {@link oracle.dss.datautil.gui.ComponentContext#setParent(Component)}.
     */
    public void setParentFrame (Frame frameParent);

    /**
     * Retrieves the parent <code>Frame</code> object.
     *
     * @return The parent <code>Frame</code> object.
     *
     * @status Documented
     * @deprecated As of 2.6.0.4, replaced by {@link oracle.dss.datautil.gui.ComponentContext#getParent}.
     */
    public Frame getParentFrame ();
    
    /**
     * Retrieves the <code>QueryContext</code> object.
     *
     * @return The <code>QueryContext</code> object.
     *
     * @status Documented
     */
    public QueryContext getQueryContext ();

    /**
     * Specifies the <code>QueryContext</code> object.
     *
     * @param  queryContext The <code>QueryContext</code> object.
     *
     * @status Documented
     */
    public void setQueryContext (QueryContext queryContext);
    }