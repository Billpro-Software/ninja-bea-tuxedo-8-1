/*
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */
package oracle.dss.dataSource.common;

import oracle.dss.util.DataDirector;

/**
 * Constants that are used to set control flag defaults, etc.
 * for the Query component.
 *
 * @status New
 */
public interface QueryConstants
{
    /**
     * Allow dividing by zero to occur, returning NA
     * @status New
     */
    public static final String PROPERTY_ALLOW_DIVIDE_BY_ZERO = "dividebyzero";
    
    
    /**
     * Default setting for setAllowDivideByZero.
     * Allow divide by zero to return NA
     *
     * @status New
     */
    public static final boolean DEFAULT_ALLOW_DIVIDE_BY_ZERO = true;

    /**
     * @hidden
     * Default setting for local NA suppression
     */
    public static final boolean DEFAULT_SUPPRESS_NA_LOCALLY = true;

    /**
     * @hidden
     * Step default property.  The value should be an instance of <code>DefaultStepTable</code>.
     */
    public static final String PROPERTY_STEP_DEFAULTS = "StepDefaults";

    /**
     * @hidden
     * Are dimension calcs supported?  The value should be a <code>Boolean</code>.  No setting
     * indicates false.
     */
    public static final String PROPERTY_DIMENSIONCALCS_SUPPORTED = "DimensionCalcsSupported";

    /**
     * @hidden
     * Should the query perform NA/Zero suppression in the cursor on the client?
     */
    public static final String PROPERTY_SUPPRESS_NA_LOCALLY = "LocalNASuppression";
    
    /**
     * Should the query operate asynchronously or synchronously?
     * 
     * @status New
     */
    public static final String PROPERTY_ASYNCHRONOUS = DataDirector.PROP_ASYNCHRONOUS;
    
    /**
     * Default setting for the asynchronous property.
     *
     * @status New
     */
    public static final boolean DEFAULT_ASYNCHRONOUS = false;
    
    /**
     * Indicates whether asymmetric drilling should be used.
     * 
     * @status New
     */
    public static final String PROPERTY_ASYMMETRIC_DRILLING = "AsymmetricDrilling";
    
    /**
     * Default setting for the PROPERTY_ASYMMETRIC_DRILLING.
     *
     * @status New
     */
    public static final boolean DEFAULT_ASYMMETRIC_DRILLING = true;    
    
    /**
     * Indicates whether events are automatically fired upon successful operation completion.
     * 
     * @status New
     */
    public static final String PROPERTY_AUTO_FIRE_EVENTS = DataDirector.PROP_AUTO_FIRE_EVENTS;
    
    /**
     * Default setting for the PROPERTY_AUTO_FIRE_EVENTS property.
     *
     * @status New
     */
    public static final boolean DEFAULT_AUTO_FIRE_EVENTS = true;    
    
    /**
     * Indicates whether drill children may be 
     * filtered by the query.  If 
     * <code>false</code>, all children of a target will be shown
     * on a drill down regardless of the query.
     * 
     * @status New
     */
    public static final String PROPERTY_DRILL_WITH_FILTERED_CHILDREN = "DrillWithFilteredChildren";
    
    /**
     * Default setting for PROPERTY_DRILL_WITH_FILTERED_CHILDREN.
     * 
     * @status New
     */
    public static final boolean DEFAULT_DRILL_WITH_FILTERED_CHILDREN = true;
    
    /**
     * Indicates the number of values to fetch per buffer read.
     * 
     * @status New
     */
    public static final String PROPERTY_FETCH_SIZE = "FetchSize";
    
    /**
     * Default setting for PROPERTY_FETCH_SIZE.
     * 
     * @status New
     */
    public static final int DEFAULT_FETCH_SIZE = 1000;    
    
    /**
     * Indicates the Query should be treated as a special item LOV query.
     * 
     * @status New
     */
    public static final String PROPERTY_LOV = "LOVQuery";
    
    /**
     * Default setting for PROPERTY_LOV.
     * 
     * @status New
     */
    public static final boolean DEFAULT_LOV = false;       
    
    /**
     * Indicates whether hierarchical ordering after drilling should be used.
     * 
     * @status New
     */
    public static final String PROPERTY_HIERARCHICAL_DRILLING = "HierarchicalDrilling";
    
    /**
     * Default setting for the PROPERTY_HIERARCHICAL_DRILLING.
     *
     * @status New
     */
    public static final boolean DEFAULT_HIERARCHICAL_DRILLING = false;   
    
    /**
     * Indicates whether the Query's cursors should optionally support mode
     * 
     * @status New
     */
    public static final String PROPERTY_OUTLINE = "Outline";
    
    /**
     * Default setting for the PROPERTY_OUTLINE.
     *
     * @status New
     */
    public static final boolean DEFAULT_OUTLINE = false;      
    
    /**
     * Indicates whether this query should only provide the SQL its execution would generate, rather than
     * actual cursor data.
     * 
     * @status New
     */
    public static final String PROPERTY_SQL_ONLY = "SQLOnly";
    
    /**
     * Default setting for PROPERTY_SQL_ONLY.
     * 
     * @status New
     */
    public static final boolean DEFAULT_SQL_ONLY = false;
    
    /**
     * Indicates whether this query should generate results appropriate to a table view.
     * 
     * @status New
     */
    public static final String PROPERTY_TABULAR_QUERY = DataDirector.PROP_TABULAR;
    
    /**
     * Default setting for PROPERTY_TABULAR_QUERY.
     * 
     * @status New
     */
    public static final boolean DEFAULT_TABULAR_QUERY = false;    
    
    /**
     * Allows user to set custom Data service instance on the BISession
     *
     * @status New
     */
    public static final String DATA_REMOTE = "DataRemote";
    
    /**
     * @hidden
     * Are totals self calculated in the cursor?
     */
    public static final String PROPERTY_IS_SELF_CALC_TOTALS = "SelfCalcTotals";
    
    /**
     * @hidden
     * Default self calc totals value
     */
    public static final boolean DEFAULT_IS_SELF_CALC_TOTALS = true;
    
    /**
     * Debug mode?
     */
    public static final String PROPERTY_DEBUG_MODE = "DebugMode";
    
    /**
     * Default debug mode
     */
    public static final boolean DEFAULT_DEBUG_MODE = false;
    
    /**
     * @hidden
     * Are annotations allowed?
     */
    public static final String PROPERTY_ALLOW_ANNOTATIONS = "AllowAnnotations";
    
    /**
     * @hidden
     * Default annotations allowed
     */
    public static final boolean DEFAULT_ALLOW_ANNOTATIONS = false;
    
    /**
     * Print query state
     */
    public static final String PROPERTY_PRINT_QUERY_STATE = "PrintQueryState";
    
    /**
     * Default print query state
     */
    public static final boolean DEFAULT_PRINT_QUERY_STATE = false;
    
    /**
     * @hidden
     * Does this query ignore all extra metadata such as labels, etc., and return only member ID
     */
    public static final String PROPERTY_VALUE_ONLY = "QueryValueOnly";
    
    /**
     * @hidden
     * Default value only
     */
    public static final boolean DEFAULT_VALUE_ONLY = false; 
    
    /**
     * @hidden
     * Query SQL type (OLAPI)
     */
    public static final String PROPERTY_SQL_TYPE = "SQLType";
    
    /**
     * @hidden
     * Default SQL type
     */
    public static final long DEFAULT_SQL_TYPE = 0;    
    
    /**
     * @hidden
     * Dump this type of SQL with every update?
     */
    public static final String PROPERTY_SQL_DUMP = "SQLDumpType";
    
    /**
     * @hidden
     * Default SQL dump type
     */
    public static final long DEFAULT_SQL_DUMP = 0;        
    
   /**
     * Auto submit writeback cell changes?
     */
    public static final String PROPERTY_AUTO_SUBMIT = "AutoSubmit";
    
    /**
     * Default auto submit
     */
    public static final boolean DEFAULT_AUTO_SUBMIT = false;    

    /**
      * Place drilled down members above or below target?
      */
     public static final String PROPERTY_DRILL_MEMBERS_ABOVE = "DrillMembersAbove";
     
     /**
      * Default drill members above
      */
     public static final boolean DEFAULT_DRILL_MEMBERS_ABOVE = false;    

    /**
     * Set the QueryManager one-off DataAccess cache upper limit
     */
    public static final String PROPERTY_DATAACCESS_CACHE_COUNT = "DataAccessCache";

    /**
     * Disable default step fallback behavior in QueryAccess to improve
     * performance.  This value is a <code>Boolean</code>
     */
    public static final String PROPERTY_DISABLE_DEFAULT_STEP_FALLBACK = "DisableDefaultStepFallback";

    /**
     * @hidden
     * Default setting for disabling default step fallback
     */
    public static final boolean DEFAULT_DISABLE_DEFAULT_STEP_FALLBACK = false;

    /**
     * @hidden
     * Default setting for DataAccess one-off cache upper limit
     */
    public static final int DEFAULT_DATAACCESS_CACHE_COUNT = 25;
    
    /**
     * Refresh the entire query, reloading all catalog metadata, etc.
     */
    public static final int REFRESH_ALL = 0;
    
    /**
     * Refresh the query, rebuilding query structures but not reloading metadata
     */
    public static final int REFRESH_REBUILD = 1;
    
    /**
     * Refresh the query's cursors
     */
    public static final int REFRESH_CURSORS = 2;
    
    /**
     * @hidden
     * Cache prefix for allstep default member caching
     */
    public static final String ALL_STEP_MEMBERS_PREFIX = "ALLSTEPMEMBERS_";
    
    /**
     * @hidden
     */
    public static final String PROPERTY_EXECUTE_XML_QUERY = "ExecuteXMLQuery";

}
