/*
 * ExceptionListener.java
 *
 * Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
 * All rights reserved. 
 */

package oracle.dss.datautil;

import oracle.dss.util.ErrorHandlerCallback;

/**
 *
 * @hidden
 *
 * Interface for exception listeners.
 *
 * Beans that call the exception listener implement the
 * <code>ExceptionListenerCallback</code> interface.
 * <P>
 *
 * By default, the beans that require exception listener support register a default
 * handler that implements this interface.
 *
 * To replace the default exception listener with your implementation of this
 * interface, you call the <code>addExceptionListener</code> method of the bean.
 *
 * @see ExceptionListenerCallback
 *
 * @status New
 */

 public interface ExceptionListener extends ErrorHandlerCallback {

  /////////////////////
  //
  // Constants
  //
  /////////////////////

  // Start of RESPONSE literals

  /**
   *
   * Return value that represents a positive response.
   *
   * @status New
   */
  public static final int YES = 0;

  /**
   * Return value that represents an ignored response.
   *
   * This value should be returned when an error or event is ignored or not
   * processed.
   *
   * @status New
   */

  public static final int NONE = 1;

  /**
   * Return value that represents a negative response.
   *
   * @status New
   */

  public static final int NO = -1;

  /**
   * Return value that represents a user-defined response.
   * Users can define values between USER_START and USER_END.
   *
   * @status New
   */

  public static final int USER_START = 100;

  /**
   * Return value that represents a user-defined response.
   * Users can define values between USER_START and USER_END.
   *
   * @status New
   */

  public static final int USER_END = 1000;

  // End of RESPONSE literals

  // Start of OPTION literals

  /**
   * Do not process exception.
   *
   * @status New
   */
  public static final int OPTION_NONE       = 0x00;

  /**
   * Process exception.
   *
   * @status New
   */
  public static final int OPTION_EXCEPTION  = 0x01;

  /**
   * Process event.
   *
   * @status New
   */
  public static final int OPTION_EVENT      = 0x02;


  /**
   * Process all options.
   *
   * @status New
   */
  public static final int OPTION_ALL        = 0xFF;

  // End of OPTION literals

  /////////////////////
  //
  // Public Methods
  //
  /////////////////////

  /**
   * Responds to trapped exception.
   *
   * <code>ExceptionListenerCallback</code> implementations call this method when
   * an exception is required in response to an exception.
   *
   * @param throwable  a <code>Throwable</code> value that represents the exception
   *                   to process.
   * @param strClass   A <code>String</coce> which is the name of the class in
   *                   which the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   * @param strRoutine A <code>String> which is the name of the routine in which
   *                   the exception was caught.
   *                   Implementers of the <code>ExceptionListenerDialogCallback</code>
   *                   interface are not required to pass this parameter,
   *                   and you are not required to do anything with the parameter.
   *
   * @return           <code>int</code> value which represents a positive response
   *                   when zero and a negative response when non-zero.
   *
   * @see #YES
   * @see #NO
   * @see #NONE
   *
   * @status New
   */
  public int processException (Throwable throwable, String strClass, String strRoutine);
}

