/*
 * @(#)ChooseJavaVM.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;
import java.util.Vector;
import java.io.File;

/**
 * <p>ChooseJavaVM allows the user to choose whether they would like to install a Java Virtual
 * Machine (VM) specifically for the application being installed, or instead run the application 
 * against a VM already installed on their system.</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ChooseJavaVM extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys

	private int currentSelection = 0;
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
		InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);

		String bodyText = cccp.substitute("$CHOOSE_JAVA_VM_BODY$");
		String prompt = cccp.substitute("$CHOOSE_JAVA_VM_PROMPT$");
		String installJRE = cccp.substitute("$CHOOSE_JAVA_VM_INSTALL_JRE$");
		String manualChoice = cccp.substitute("$CHOOSE_JAVA_VM_SPECIFY_JRE$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ChooseJavaVM.header");
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ChooseJavaVMConsole.choicePrompt");
		}
		
		if (installJRE == null || installJRE.trim().equals(""))
		{
			installJRE = cccp.getValue("ChooseJavaVMUI.installCb");
		}

		if (manualChoice == null || manualChoice.trim().equals(""))
		{
			manualChoice = cccp.getValue("ChooseJavaVMUI.selectCb");
		}

		cu.wprintln(bodyText);

		Vector vmList = new Vector();
		
		//
		// if: we can install a bundled VM make that the first option in the choice list.
		//
		if (ir.getBundledJREStatus() != ir.CAN_NOT_INSTALL_JRE)
		{
			vmList.addElement(installJRE);
			vmList.addElement("");
		}
		
		//
		// get the list of system VMs from the installer.
		//
		Vector foundVMList = ir.getJavaVMList();

		//
		// add the system vm list to the vm list to be presented to the user.
		//
		for (int i = 0; i < foundVMList.size(); i++)
		{
			vmList.addElement(foundVMList.elementAt(i));
		}
		
		//
		// finally create an option to have the user manually enter the path to a system VM.
		//
		vmList.addElement("");
		vmList.addElement(manualChoice);

		boolean proceed = false;
		int userChoice = 0;
		do
		{
			IASys.out.println();

			//
			// Choose Java VM -- the current selection is always the default (item 1 if first pass thru).
			//
			userChoice = cu.createChoiceListAndGetValue(prompt, vmList, currentSelection);

			//
			// if: the user chose to install the bundled Java VM.
			//
			if (((String)vmList.elementAt(userChoice)).equals(installJRE))
			{
				proceed = true;
				try
				{
					if (!ir.installBundledJRE(true))
					{
						IASys.out.println(cccp.getValue("ChooseJavaVMConsole.errorStr1"));
					}
				}
				catch (CannotInstallJREException e)
				{
					IASys.out.println(cccp.getValue("ChooseJavaVMConsole.errorStr1"));
					IASys.out.println(cccp.getValue("GenericConsoleStrings.exception") + " " + e);
				}
			}
			//
			// else if: the user chose to supply a path to a VM.
			//
			else if (((String)vmList.elementAt(userChoice)).equals(manualChoice))
			{
				//
				// Get the path to a system VM as supplied by the user.
				//
				String tempPrompt = cu.promptAndGetValue(cccp.getValue("ChooseJavaVMConsole.pathPrompt"));
				
				//
				// Create a file object based on that path.
				//
				File tempFile = new File(tempPrompt);
				
				String tempFileString;
				String tempFileLower;
				
				//
				// Get the absolute path to the object that the user specified.
				//
				try
				{
					tempFileString = tempFile.getCanonicalPath();
				}
				catch (Exception e)
				{
					tempFileString = tempFile.getAbsolutePath();
				}

				tempFileLower = tempFileString.toLowerCase();
				
				//
				// Make a loose attempt at validating that the supplied path points to a Java executable,
				// that the path is not to a directory, and that the path to the executable exists.
				//
				if ((tempFileString.indexOf("java") != -1 || tempFileString.indexOf("jre") != -1 || tempFileString.indexOf("jview") != -1)
				    && tempFile.exists() 
				    && !tempFile.isDirectory())
				{					
					IASys.out.println();	
					
					//
					// Confirm that the path supplied is the correct path.
					//
					proceed = cu.promptAndYesNoChoice(cccp.getValue("ChooseJavaVMConsole.pathPrompt") 
														+ tempFileString + ".\n"
														+ cccp.getValue("GenericConsoleStrings.isThisCorrect"));

					//
					// set the Java VM and add the new VM to the VM list.
					//
					if (proceed)
					{
						if(!ir.setJavaVM(tempFileString))
						{
							IASys.out.println(cccp.getValue("ChooseJavaVMConsole.errorStr2"));
						}						
						
						int tempIndex = vmList.indexOf(tempFileString);
						if (tempIndex != -1)
						{
							userChoice = tempIndex;
						}
						else
						{
							foundVMList.addElement(tempFileString);
							userChoice -= 1;  // adding a new element and stepping back one to select it.
						}
					}
				}
				else
				{
					String badVMMessage = cccp.getValue("ChooseJavaVMUI.showBadVMDialog().message");
					
					IASys.out.println();
					IASys.out.println(badVMMessage);
					            
					proceed = false; 
				}
			}
			//
			// else: the user chose a VM from the supplied list of system VMs.
			//
			else 
			{
				proceed = true;
				if(!ir.setJavaVM((String)vmList.elementAt(userChoice)))
				{
					IASys.out.println(cccp.getValue("ChooseJavaVMConsole.errorStr2"));
				}
			}
		
		} while (!proceed);
		
		currentSelection = userChoice;
	}
	
	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$CHOOSE_JAVA_VM_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("ChooseJavaVM.Title");
		}
		
		return title;
	}
}
