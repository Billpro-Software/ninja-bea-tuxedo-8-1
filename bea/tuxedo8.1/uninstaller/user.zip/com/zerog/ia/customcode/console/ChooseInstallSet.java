/*
 * @(#)ChooseInstallSet.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;
import java.util.Vector;

/**
 * <p>ChooseInstallSet allows users to choose which install set will be installed on their 
 * machine. For example, this could be a Typical or Minimal install.</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ChooseInstallSet extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys

	//
	// Get the services that we will need
	//
	ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
	InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		String bodyText = cccp.substitute("$CHOOSE_INSTALL_SET_BODY$");
		String prompt = cccp.substitute("$CHOOSE_INSTALL_SET_PROMPT$");
		String customize = cccp.substitute("$CHOOSE_INSTALL_SET_CUSTOMIZE$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ChooseInstallSetConsole.description");
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ChooseInstallSetConsole.prompt");
		}
		
		//
		// get the install sets whose rules currently evaluate to true from the installer.
		//
		Vector installSets = ir.getInstallSets();
		
		//
		// if the IA Variable to allow bundle customization is set...
		//
		String customizeString = cccp.getValue("ChooseInstallSetUI.customizeBttn") + "...";
		if (customize != null && customize.trim().equalsIgnoreCase("true"))
		{
			//
			// Add the option to customize the install.
			//
			installSets.addElement("");
			installSets.addElement(customizeString);
		}
		
		cu.wprintln(bodyText);
		IASys.out.println();

		//
		// check to see if there is a default install set.
		//
		String defaultInstallSetString = ir.getDefaultInstallSet();
		int defaultInstallSetIndex = -1;
		if (defaultInstallSetString != null)
		{
			defaultInstallSetIndex = installSets.indexOf(defaultInstallSetString); 
		}
		
		//
		// Choose Install Sets
		//
		int userChoice = cu.createChoiceListAndGetValue(prompt, installSets, defaultInstallSetIndex);

		//
		// if: the use chose an actual install set.
		//
		if (!(((String)installSets.elementAt(userChoice)).equals(customizeString)))
		{
			//
			//set the chosen install set.
			//
			if(!ir.setChosenInstallSet((String)installSets.elementAt(userChoice)))
			{
				IASys.out.println(cccp.getValue("ChooseInstallSetUI.errorStr"));
			}
		}
		else
		{
			IASys.out.println();
			promptForInstallBundle();
		}
	}
	

	/**
	 * <p>This method allows users to customize their install by choosing the individual install
	 * bundles to be installed.</p>
	 */
	private void promptForInstallBundle() throws PreviousRequestException
	{
		String bodyText = cccp.substitute("$CHOOSE_INSTALL_SET_BODY$");
		String prompt = cccp.substitute("$CHOOSE_INSTALL_BUNDLE_PROMPT$");

		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ChooseInstallSetConsole.bundleDescription");
		}

		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ChooseInstallSetConsole.bundlePrompt");
		}
		
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// get the install bundles whose rules currently evaluate to true from the installer.
		//
		Vector installBundles = ir.getInstallBundles();
		
		//
		// prompt the user to choose the install sets to install.
		//
		int[] userChoices = cu.createChoiceListAndGetMultipleValues(prompt, installBundles);
		String installBundleString =  "";
		
		//
		// construct the string that represents the choice of bundles that the user has specified.
		//
		for (int i = 0; i < userChoices.length; i++)
		{
			installBundleString += (String)installBundles.elementAt(i) + ",";
		}
		
		//
		// set the chosen install bundles.
		// 
		if (!ir.setChosenInstallBundles(installBundleString))
		{
			IASys.out.println(cccp.getValue("ChooseInstallSetConsole.bundleErrorStr"));
		}
	}



	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$CHOOSE_INSTALL_SET_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("ChooseInstallSet.Title");
		}
		
		return title;
	}
}
