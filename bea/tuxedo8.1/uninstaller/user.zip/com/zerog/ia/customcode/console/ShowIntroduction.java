/*
 * @(#)ShowIntroduction.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;

/**
 * <p>ShowIntroduction displays basic introductory text describing the product to 
 * be installed.</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ShowIntroduction extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);

		String bodyText = cccp.substitute("$SHOW_INTRODUCTION_BODY$");
		String prompt = cccp.substitute("$SHOW_INTRODUCTION_PROMPT$");
		String productName = cccp.substitute("$PRODUCT_NAME$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("IntroConsole.DisplayText1") 
						+ productName 
						+ cccp.getValue("IntroConsole.DisplayText2");
		}
		
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("GenericConsoleStrings.enterToContinue");
		}
				
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// pause and wait for the user to press enter to continue.
		//
		cu.enterToContinue(prompt);
	}
	
	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$SHOW_INTRODUCTION_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("Intro.Title");
		}
		
		return title;
	}
}
