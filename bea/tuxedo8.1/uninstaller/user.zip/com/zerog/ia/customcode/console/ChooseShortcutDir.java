/*
 * @(#)ChooseShortcutDir.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;
import java.util.Vector;
import java.io.File;

/**
 * <p>ChooseShortcutDir allows users to choose the folder where shortcuts to each installed
 * application will be created.</p> 
 *
 * <p>Shortcuts are also known as aliases on the Macintosh platform, and links on Unix platform.</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ChooseShortcutDir extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys

	private String defaultShortcutDir = null;
	private String currentShortcutDir = null;
	private boolean currentIsDefault = true;
	private int listPadding = 0;
	private int currentSelection = 0;
	private int userChoice = 0;
	
	private String prompt;
	private String pathPrompt;
	private String defaultLocation;
	private String currentLocation;
	private String otherLocation;

	//
	// Get the services that we will need
	//
	private ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
	private InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);
	private static String osName = System.getProperty("os.name");

	public void executeConsoleAction() throws PreviousRequestException
	{
		prompt = cccp.substitute("$CHOOSE_SHORTCUT_DIR_PROMPT$");
		pathPrompt = cccp.substitute("$CHOOSE_SHORTCUT_DIR_PATH_PROMPT$");
		defaultLocation = cccp.getValue("ShortcutLocConsole.defaultLoc");
		currentLocation = cccp.getValue("ShortcutLocConsole.currentLoc");
		otherLocation = cccp.getValue("ShortcutLocConsole.specifyAlternateLoc");

		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (prompt == null || prompt.trim().equals(""))
		{
			prompt = cccp.getValue("ShortcutLocConsole.choicePrompt");
		}
		
		if (pathPrompt == null || pathPrompt.trim().equals(""))
		{
			pathPrompt = cccp.getValue("ShortcutLocConsole.pathPrompt");
		}

		//
		// Get the default shortcut directory.
		//
		if (defaultShortcutDir == null)
		{
			defaultShortcutDir = ir.getShortcutDirectory();
		}
		
		//
		// Set the current shortcut directory (if not set).
		//
		if (currentShortcutDir == null)
		{
			currentShortcutDir = defaultShortcutDir;
		}		
		
		if (osName != null)
		{
			osName = osName.toLowerCase();
		}
		
		if (currentIsDefault)
		{
			listPadding = 0;
		}
		else
		{
			listPadding = 1;
		}
		
		//
		// Switch based on the destination platform.
		//
		if (osName != null && osName.indexOf("windows") != -1)
		{
			winShortcutConsole();
		}
		else if (osName != null && osName.indexOf("mac") != -1)
		{
			//macShortcutConsole();
		}
		else
		{
			otherShortcutConsole();
		}
	}
	
	/**
	 * Display the ChooseShortcutDir console UI for the Windows platform
	 */
	public void winShortcutConsole() throws PreviousRequestException
	{			
		String bodyText = cccp.substitute("$WIN_CHOOSE_SHORTCUT_DIR_BODY$");
		
		//
		// Get the localized string for the choice constants.
		//
		String desktop = cccp.getValue("ShortcutLocUI.WinUI.desktopCb");
		String startMenu = cccp.getValue("ShortcutLocUI.WinUI.startMenuCb");
		String programGroup = cccp.getValue("ShortcutLocUI.WinUI.newGroupCb");
		String doNotCreate = cccp.getValue("ShortcutLocUI.PlatformUI.WIN32.noneCb");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ShortcutLoc.WIN32.aboveCaption");;
		}
		
		String productName = cccp.substitute("$PRODUCT_NAME$");
				
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// Create and populate the array that will be used for the step's choice list.
		// 'listPadding' is used to dynamically change the overall size of the array 
		// (allowing a current selection that does not correlate with one of the defaults
		// in the list).
		//
		String[] options = new String[7 + listPadding];
		String[] paths = new String[7 + listPadding];
		
		options[0] = defaultLocation + defaultShortcutDir;
		paths[0] = defaultShortcutDir;
		
		if (!currentIsDefault)
		{
			options[1] = currentLocation + currentShortcutDir;
			paths[1] = currentShortcutDir;
		}
		
		options[1 + listPadding] = programGroup + " " + productName;
		paths[1 + listPadding] = cccp.substitute("$WIN_PROGRAMS_MENU$" + "\\" + productName);

		options[2 + listPadding] = desktop;
		paths[2 + listPadding] = cccp.substitute("$DESKTOP$");

		options[3 + listPadding] = startMenu;
		paths[3 + listPadding] = cccp.substitute("$WIN_START_MENU$");

		options[4 + listPadding] = otherLocation;
		paths[4 + listPadding] = null;

		options[5 + listPadding] = null;
		paths[5 + listPadding] = null;

		options[6 + listPadding] = doNotCreate;
		paths[6 + listPadding] = null;
		
		String shortcutDir = "";
		userChoice = 0;
		boolean proceed = false;

		do 
		{
			proceed = false;
			IASys.out.println();
	
			//
			// Choose the shortcut directory -- the current selection is always the default 
			// (item 1 if first pass thru).
			//	
			userChoice = cu.createChoiceListAndGetValue(prompt, options, currentSelection);
			userChoice -= listPadding;
			
			switch (userChoice)
			{
				case -1: // default shortcut dir.
				case 1:  // program group.
				case 2:  // on the desktop.
				case 3:  // start menu.
					currentIsDefault = true;
					// Note that there is no break here.
				case 0:  // default shourtcut dir or current shortcut dir.
					proceed = true;
					shortcutDir = paths[userChoice + listPadding];
					
					//
					// Adjust for the presence of a current selection.
					//
					if (userChoice == -1)
					{
						userChoice = 0;
					}
					else if (userChoice == 0)
					{
						if (!currentIsDefault)
						{
							userChoice = 1;
						}
					}
				break;
				
				case 4:  // specify a path.
					proceed = true;
					shortcutDir = getShortcutPathFromUser(pathPrompt, paths);
					
					if (shortcutDir == null)
					{
						proceed = false;
					}
				break;
				
				case 6: // do not create shortcuts.
					proceed = true;
					currentIsDefault = true;
					shortcutDir = cccp.substitute("$DO_NOT_INSTALL$");
				break;
			}
					
		} while (!proceed);
		
		currentSelection = userChoice;

		ir.setShortcutDirectory(shortcutDir);
		currentShortcutDir = shortcutDir;
	} 

	/**
	 * Display the ChooseShortcutDir console UI for the Other platforms (e.g., Unix).
	 */
	private void otherShortcutConsole() throws PreviousRequestException
	{			
		String bodyText = cccp.substitute("$UNIX_CHOOSE_SHORTCUT_DIR_BODY$");
		
		//
		// Get the localized string for the choice constants.
		//
		String homeDir = cccp.getValue("ShortcutLocUI.SolarisUI.homeCb");
		String doNotCreate = cccp.getValue("ShortcutLocUI.PlatformUI.WIN32.noneCb");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("ShortcutLoc.UNIX.aboveCaption");
		}
		
		cu.wprintln(bodyText);
		IASys.out.println();
		
		//
		// Create and populate the array that will be used for the step's choice list.
		// 'listPadding' is used to dynamically change the overall size of the array 
		// (allowing a current selection that does not correlate with one of the defaults
		// in the list).
		//
		String[] options = new String[5 + listPadding];
		String[] paths = new String[5 + listPadding];
		
		options[0] = defaultLocation + defaultShortcutDir;
		paths[0] = defaultShortcutDir;

		if (!currentIsDefault)
		{
			options[1] = currentLocation + currentShortcutDir;
			paths[1] = currentShortcutDir;
		}

		options[1 + listPadding] = homeDir;
		paths[1 + listPadding] = cccp.substitute("$UNIX_USER_HOME$");

		options[2 + listPadding] = otherLocation;
		paths[2 + listPadding] = null;

		options[3 + listPadding] = null;
		paths[3 + listPadding] = null;

		options[4 + listPadding] = doNotCreate;
		paths[4 + listPadding] = null;
		
		String shortcutDir = "";
		userChoice = 0;
		boolean proceed = false;
		do 
		{
			proceed = false;
			IASys.out.println();
	
			//
			// Choose the shortcut directory -- the current selection is always the default 
			// (item 1 if first pass thru).
			//	
			userChoice = cu.createChoiceListAndGetValue(prompt, options, currentSelection);
			userChoice -= listPadding;
			
			switch (userChoice)
			{
				case -1: // default shortcut dir.
				case 1:  // home directory.
					currentIsDefault = true;
					// Note that there is no break here.
				case 0:  // default shourtcut dir or current shortcut dir.
					proceed = true;
					shortcutDir = paths[userChoice + listPadding];

					//
					// Adjust for the presence of a current selection.
					//
					if (userChoice == -1)
					{
						userChoice = 0;
					}
					else if (userChoice == 0)
					{
						if (!currentIsDefault)
						{
							userChoice = 1;
						}
					}
				break;
				
				case 2:  // specify a path.
					proceed = true;
					shortcutDir = getShortcutPathFromUser(pathPrompt, paths);
					
					if (shortcutDir == null)
					{
						proceed = false;
					}
				break;
				
				case 4:   // do not create shortcuts.
					proceed = true;
					currentIsDefault = true;
					shortcutDir = cccp.substitute("$DO_NOT_INSTALL$");
				break;
			}
					
		} while (!proceed);
		
		currentSelection = userChoice;

		ir.setShortcutDirectory(shortcutDir);
		currentShortcutDir = shortcutDir;
	}

	/**
	 * <p>Prompts the user to manually enter and confirm a shortcut directory.</p>
	 */
	private String getShortcutPathFromUser(String pathPrompt, String[] paths) 
		throws PreviousRequestException
	{
		String shortcutDir = cu.promptAndGetValue(pathPrompt);
			
		IASys.out.println();
		
		//
		// Create a File object so that we can determine the absolute path.
		//
		java.io.File shortcutDirectory = new java.io.File(shortcutDir);

		try
		{
			shortcutDir = shortcutDirectory.getCanonicalPath();
		}
		catch (Exception e)
		{
			shortcutDir = shortcutDirectory.getAbsolutePath();
		}

		//
		// Confirm the choice.
		//
		boolean proceed = cu.promptAndYesNoChoice(cccp.getValue("ShortcutLocConsole.shortcutDirIsStr") 
													+ shortcutDir + "\n"
													+ cccp.getValue("GenericConsoleStrings.isThisCorrect"));		

		if (proceed)
		{
			currentIsDefault = false;
			userChoice = 1;
			boolean samePath = false;
			
			//
			// Determine if the supplied path matches one of the default paths.
			//
			for (int i = 0; i < paths.length; i++)
			{
				if (paths[i] != null)
				{
					if (osName != null && osName.indexOf("windows") != -1)
					{
						//
						// Filenames are case-insensitive on Win32 systems.
						//
						samePath = paths[i].equalsIgnoreCase(shortcutDir);
					}
					else
					{
						//
						// Filenames are case-sensitive on Unix systems.
						//
						samePath = paths[i].equals(shortcutDir);
					}
			
					if (samePath)
					{
						userChoice = i;
						
						if (currentIsDefault || (!currentIsDefault && i != 1))
						{
							currentIsDefault = true;
						}
							
						break;
					}
				}
			}
		}
		else
		{
			//
			// return null if we did not get a verified shortcut directory.
			//
			shortcutDir = null;
		}
		
		return shortcutDir;
	}

	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$CHOOSE_SHORTCUT_DIR_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			if (osName != null)
			{
				osName = osName.toLowerCase();
			}
			
			if (osName != null && osName.indexOf("windows") != -1)
			{
				title = cccp.getValue("ShortcutLoc.Win32Title");
			}
			else if (osName != null && osName.indexOf("mac") != -1)
			{
				title = cccp.getValue("ShortcutLoc.MacOSTitle");
			}
			else
			{
				title = cccp.getValue("ShortcutLoc.SolarisTitle");
			}
		}
		
		return title;
	}
}
