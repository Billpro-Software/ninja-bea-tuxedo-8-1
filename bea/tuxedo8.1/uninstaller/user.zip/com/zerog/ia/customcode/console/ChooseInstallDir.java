/*
 * @(#)ChooseInstallDir.java 0.9 10.02.2000
 *
 * MMA
 *
 */
package com.zerog.ia.customcode.console;

import com.zerog.ia.api.pub.*;
import java.util.Vector;
import java.io.File;
import java.io.PrintStream;
import java.io.FileOutputStream;

/**
 * <p>ChooseInstallDir allows users to choose the folder where the product will be installed.</p>
 *
 * @version 1.0, 03 October 2000
 * @author Zero G
 */
public class ChooseInstallDir extends CustomCodeConsoleAction
{
	//
	// The following are set before executeConsoleAction() is called.
	//
	// CustomCodeConsoleProxy cccp;

	//
	// The following provide static access to console input and output
	// 
	// IASys

	private String defaultInstallDir = null;
	private String currentInstallDir = null;
	private static String osName = System.getProperty("os.name");
	
	/**
	 * <p>This method gets called when the installer is ready to display the console 
	 * action.  Most, if not all, of the console input and output should orginate
	 * from the call into this action via this method.</p>
	 */
	public void executeConsoleAction() throws PreviousRequestException
	{
		//
		// Get the services that we will need
		//
		ConsoleUtils cu = (ConsoleUtils)cccp.getService(ConsoleUtils.class);
		InstallerResources ir = (InstallerResources)cccp.getService(InstallerResources.class);

		String bodyText = cccp.substitute("$CHOOSE_INSTALL_DIR_BODY$");
		String prompt1 = cccp.substitute("$CHOOSE_INSTALL_DIR_PROMPT_1$");
		String prompt2 = cccp.substitute("$CHOOSE_INSTALL_DIR_PROMPT_2$");
		String defaultDir = cccp.substitute("$CHOOSE_INSTALL_DIR_DEFAULT_STR$");
		String currentDir = cccp.substitute("$CHOOSE_INSTALL_DIR_CURRENT_STR$");
		
		//
		// if the text for elements of this step were not specified in an IA Variable, 
		// get the defaults from the installer's locale resources.
		//
		if (bodyText == null || bodyText.trim().equals(""))
		{
			bodyText = cccp.getValue("InstallDirUI.aboveLbl");
		}
		
		if (prompt1 == null || prompt1.trim().equals(""))
		{
			prompt1 = cccp.getValue("InstallDirConsole.prompt");
		}

		if (prompt2 == null || prompt2.trim().equals(""))
		{
			prompt2 = cccp.getValue("InstallDirConsole.promptWithDefault");
		}

		if (defaultDir == null || defaultDir.trim().equals(""))
		{
			defaultDir = cccp.getValue("InstallDirConsole.defaultDirStr");
		}

		if (currentDir == null || currentDir.trim().equals(""))
		{
			currentDir = cccp.getValue("InstallDirConsole.chosenDirStr");
		}
		
		//
		// determine the default install folder
		//
		if (defaultInstallDir == null)
		{
			defaultInstallDir = ir.getInstallDirectory().trim();
		}
				
		//
		// determine the current install folder
		//
		if (currentInstallDir == null)
		{
			currentInstallDir = defaultInstallDir;
		}

		cu.wprintln(bodyText);
		IASys.out.println();
		IASys.out.println("  " + defaultDir + defaultInstallDir);
		
		//
		// Determine if the current install directory and the default are the same.
		//
		boolean currentIsDefault = true;
		if (osName != null && osName.indexOf("windows") != -1)
		{
			currentIsDefault = currentInstallDir.trim().equalsIgnoreCase(defaultInstallDir);
		}
		else
		{
			currentIsDefault = currentInstallDir.trim().equals(defaultInstallDir);
		}

		if (!currentIsDefault)
		{
			IASys.out.println();
			IASys.out.println("->" + currentDir + currentInstallDir);			
		}

		String installDir = "";
		boolean proceed = false;
		do 
		{
			IASys.out.println();
	
			//
			// prompt the user for the location of the install folder.
			//
			if (currentIsDefault)
			{
				installDir = cu.promptAndGetValue(prompt1, false);
			}
			else
			{
				installDir = cu.promptAndGetValue(prompt2, false);
			}
			
			//
			// if: the user just pressed enter, then they may have accepted the default 
			// install directory (or the current install directory).
			//
			if (installDir == null || installDir.trim().equals(""))
			{
				if (currentIsDefault)
				{
					installDir = defaultInstallDir;
				}
				else
				{
					installDir = currentInstallDir;
				}
				
				proceed = true;
			}
			//
			// else: they provided a path to the install directory.
			//
			else
			{
				if (installDir.trim().equalsIgnoreCase("default"))
				{
					installDir = defaultInstallDir;
				} 
				
				//
				// create a file object from the supplied path.
				//
				java.io.File installDirectory = new java.io.File(installDir);
				
				//
				// if: the path to the install directory is not an existing file (rather than a directory)
				//     on the target system.
				//
				if (!installDirectory.isFile())
				{
					try
					{
						installDir = installDirectory.getCanonicalPath();
					}
					catch (Exception e)
					{
						installDir = installDirectory.getAbsolutePath();
					}

					IASys.out.println();
				
					proceed = cu.promptAndYesNoChoice(cccp.getValue("InstallDirConsole.installDirIsStr") 
														+ installDir + "\n" 
														+ cccp.getValue("GenericConsoleStrings.isThisCorrect"));
				}
				//
				// else: inform the user that the installer cannot install to the location of a file.
				//
				else
				{
					proceed = false;
					
					IASys.out.println();
					IASys.out.println(cccp.getValue("InstallDirConsole.suppliedPathStr"));
					IASys.out.println();
					IASys.out.println("   " + installDir);
					IASys.out.println();
					IASys.out.println(cccp.getValue("InstallDirConsole.cannotOverwriteStr"));
				}		
			}
			
			//
			// if: everything seems okay at the moment.
			// 
			if (proceed)
			{
				//
				// check the permissions on the desired install location.
				//
				proceed = checkInstallPermissions(installDir);
				
				//
				// if: we did not have permissions.
				//
				if (!proceed)
				{
					IASys.out.println();
					cu.wprintln(cccp.getValue("InstallDirUI.alertDialog.text"));
				}
			}
											
		} while (!proceed);
		
		//
		// set the new install directory.
		//
		ir.setInstallDirectory(installDir);
		
		currentInstallDir = installDir;
	}

	/**
	 * <p>This method checks the write permissions for a given path.</p>
	 */
	private boolean checkInstallPermissions(String installDir)
	{
		boolean validPermissions = true;
		
		//
		// See if we can write to this directory
		//
		File tmp = new File(installDir);
		String fileSep = System.getProperty("file.separator");
		
		while(!tmp.exists())
		{
			int i = tmp.getPath().lastIndexOf(fileSep);
			
			if ( i > -1 )
			{
				tmp = new File( tmp.getPath().substring( 0, i) );
			}
			else
			{
				break;
			}
		}
		
		
		tmp.mkdirs();
		
		try
		{
			File testWriteFile = new File(tmp.getPath() + fileSep + "ia_test");
			
			int count = 1;
			
			while(testWriteFile.exists())
			{
				//
				// create a testfile that doesn't already exist
				//
				testWriteFile = new File(tmp.getPath() + fileSep + "test" + count);
				count++;
			}

			PrintStream out = new PrintStream(new FileOutputStream(testWriteFile));
			
			out.println("I can write here!");
			
			out.close();
			testWriteFile.delete();
			
			validPermissions = true;
		}
		catch(Exception e)
		{
			validPermissions = false;
		}
		
		return validPermissions;
	}
	
	/**
	 * <p>This method returns the String to be displayed on the installation
	 * step of which this Console action will be contained.</p>
	 */
	public String getTitle()
	{
		String title = cccp.substitute("$CHOOSE_INSTALL_DIR_TITLE$");
		
		//
		// if a title was not specified in an IA Variable, get the default title 
		// from the installer's locale resources.
		//
		if (title == null || title.trim().equals(""))
		{
			title = cccp.getValue("InstallDir.Title");
		}
		
		return title;
	}
}
